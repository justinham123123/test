# 2017.08.13 21:51:11 CST
# Embedded file name: build\bdist.win32\egg\serv\core\tasks\pack_sync.py
from collections import deque
from datetime import datetime
import time
import logging
from serv.lib.utilities import helper_methods
from serv.configuration import cfg
from serv.storage.database.primary import database as db
from serv.configuration.constants import PACK_SYNC_CYCLE
from serv.lib.cherrypy.i18n_tool import ugettext as _

class Pack_Synchroniser:
    """
    Synchronises packs with schedules, ensures schedules contain the most up to date pack info
    """

    def __init__(self, core):
        self.core = core
        self.sync_stamp = time.time() - PACK_SYNC_CYCLE
        self.sync_history = deque(maxlen=20)

    def sync(self):
        """
        Function periodically looks at recently modified packs and re-syncs
        any affected POS Sessions and Schedules.
        """
        old_stamp = self.sync_stamp
        self.sync_stamp = time.time()
        pack_uuids = []
        packs = db.Session.query(db.Pack).filter(db.Pack.last_modified > old_stamp)
        pack_count = packs.count()
        if pack_count > 0:
            sync_info = {'packs': {},
             'pos': 0,
             'manual': 0,
             'stamp': helper_methods.format_timestamp(time.time())}
            min_stamp = None
            max_stamp = None
            screens = set()
            screen_identifiers = set()
            placeholders = set()
            for pack in packs:
                pack_info = pack.to_dict()
                pack_uuids.append(pack_info['uuid'])
                issuer = pack.issuer if pack.issuer != None else 'unknown'
                state = 'modified' if pack.created < old_stamp else 'new'
                if not sync_info['packs'].has_key(state):
                    sync_info['packs'][state] = {}
                if not sync_info['packs'][state].has_key(issuer):
                    sync_info['packs'][state][issuer] = 0
                sync_info['packs'][state][issuer] += 1
                placeholders.add(pack_info['placeholder_uuid'])
                if pack_info.get('date_from'):
                    min = time.mktime(datetime.strptime(pack_info['date_from'], '%Y-%m-%d').timetuple())
                    if not min_stamp or min_stamp > min:
                        min_stamp = min
                if pack_info.get('date_to'):
                    max = time.mktime(datetime.strptime(pack_info['date_to'], '%Y-%m-%d').timetuple())
                    if not max_stamp or max_stamp < max:
                        max_stamp = max
                for uuid in pack_info.get('screens'):
                    screens.add(uuid)
                    try:
                        screen_identifiers.add(self.core.screens[uuid]['identifier'])
                    except KeyError:
                        pass

            if cfg.core_auto_schedule_resync.get():
                sync_info['manual'] = self.core.scheduling_service.reschedule(min_stamp, max_stamp, list(screens), placeholders=list(placeholders), pack_uuids=pack_uuids, publish=False)['data']['count']
                sync_info['pos'] = self.core.pos.resync_mappings(min_stamp, max_stamp, list(screen_identifiers), list(placeholders), pack_uuids, trigger=_('Pack') + ' ' + _('Update'))['data']['count']
            else:
                self.core.pos.resync_mappings(min_stamp, max_stamp, list(screen_identifiers), list(placeholders), pack_uuids, trigger=_('Pack') + ' ' + _('Update'))
            self.sync_history.append(sync_info)
        logging.getLogger('marker_clip_templating').info('Pack sync: sunc [%s] packs: %s', pack_count, pack_uuids)
        return
# okay decompyling ./core/tasks/pack_sync.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:12 CST
