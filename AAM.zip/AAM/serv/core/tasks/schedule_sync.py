# 2017.08.13 21:51:13 CST
# Embedded file name: build\bdist.win32\egg\serv\core\tasks\schedule_sync.py
import copy
import json
import logging
import itertools
import re
import time
import cherrypy
import socket
from collections import deque
from datetime import datetime, timedelta
from serv.lib.utilities import config
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_, or_, not_
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities.date_utils import local_datetime_to_posix, posix_to_local_datetime
from serv.configuration import cfg
from serv.core.devices.base import scheduling as base_scheduling, playback as base_playback
from serv.storage.database.primary import database as db
from sqlalchemy.orm import joinedload
import bisect
from serv.lib.utilities.helper_methods import marker_clip_templating_log, get_playlist_cpl_uuids, get_transfer_time
LOW_PRIORITY = 'LOW_PRIORITY'
NOT_PLAYABLE = 'NOT_PLAYABLE'

class Schedule_Synchroniser:
    """
    Synchronises server schedules with any POS/Bookend mappings the user makes.
    """

    def __init__(self, core):
        self.core = core
        self.syncing = False
        self.waiting = False
        self.changes = {}
        self.modified_pos_sessions = set()
        self.progress = 0
        self.last_sync = 0
        self.enabled_devices = []
        self.errors = deque(maxlen=10)
        self.messages = []
        self.current_status = _('Waiting')
        self.checklist = {}
        self.interfering_schedules = {}
        self.manual_reschedule_list = {}

    @db.close_session
    def sync(self):
        """
        Method description goes here..
        """

        def update_devices_to_sync():
            """Updates 'self.enabled_devices' list
            """
            core_enabled_devices = self.core.get_devices([], base_playback.Playback)[0]
            for device_uuid in core_enabled_devices:
                device = self.core.devices[device_uuid]
                screen_number = self.core.screens[device.device_configuration['screen_uuid']]['identifier']
                if device.device_status['alive']:
                    self.enabled_devices.append(device_uuid)
                else:
                    self._log(_('Waiting, Screen %s is unreachable') % screen_number, log_stmt='Warning - Screen %s: unreachable, skipping sync.' % screen_number, error=True, log=True)

        self.progress = 0
        self.checklist = [{'msg': _('Checked device configuration'),
          'done': False},
         {'msg': _('Deleted previous Schedules'),
          'done': False},
         {'msg': _('Queued CPL and Playlist Transfers'),
          'done': False},
         {'msg': _('Created new Playlists'),
          'done': False},
         {'msg': _('Created new Schedules'),
          'done': False},
         {'msg': _('Done'),
          'done': False}]
        try:
            self.core.schedule_lock.acquire()
            self._log(_('Sync Started'), start=True)
            self.changes = {}
            self.modified_pos_sessions = set()
            self.progress = 0
            self.syncing = True
            self.waiting = False
            self.potentially_redundant_template_playlists = {}
            self.synced_without_error = True
            self.enabled_devices = []
            self.marker_clip_templating = False
            self.preshow_trimming = False
            if cfg.marker_clip_templating():
                self.reschedule_devices = []
                for schedule in self.manual_reschedule_list:
                    if self.manual_reschedule_list[schedule]['device'] not in self.reschedule_devices:
                        self.reschedule_devices.append(self.manual_reschedule_list[schedule]['device'])

                self.marker_clip_templating = True
                self.preshow_end_placeholder = cfg.marker_clip_preshow_end().upper()
                if cfg.preshow_trimming_enabled():
                    self.preshow_trimming = True
            update_devices_to_sync()
            self.checklist[0]['done'] = True
            if cfg.pos_enabled.get():
                self._get_modified()
                self._delete_pos_schedules()
                self.progress = 15
                self._queue_actions()
                self.progress = 25
                self.checklist[1]['done'] = True
                self._do_actions()
                self.progress = 45
                self.checklist[2]['done'] = True
                self._add_unassigned_pos_schedules()
                self.progress = 50
            self._delete_manual_schedules()
            if self.marker_clip_templating:
                self._create_marker_playlists_for_templates()
            else:
                self._create_playlists_for_templates()
            self.checklist[3]['done'] = True
            self.progress = 55
            self._create_schedules_for_templates()
            self.progress = 75
            try:
                self._add_bookends()
                self.progress = 95
            except Exception as ex:
                self._log(_('Unknown error while adding Bookends'), log_stmt='Exception during schedule sync when adding bookends - CLEAN UP CATCH SPECIFIC ISSUES: [%s]' % str(ex), log=True, error=True)

            self._remove_redundant_templated_playlists()
            self._check_show_start_cue_configuration()
            self._fill_in_missing_playlist_info()
            self.checklist[4]['done'] = True
            if cfg.pos_enabled.get():
                self.core.pos.service.update_mapping_overview()
            db.Session.commit()
            self._update_modified_hash()
            if self.synced_without_error:
                self.errors = deque(maxlen=10)
            self.checklist[5]['done'] = True
        except Exception as ex:
            logging.critical('Schedule Sync terminated prematurely', exc_info=True)
            self._log(_('Unknown error during scheduling [%s]' % str(ex)), log_stmt='Exception during schedule sync: [%s]' % str(ex), log=True, error=True)
        finally:
            self.syncing = False
            self._log(_('Sync Complete'))
            self.core.schedule_lock.release()
            self.last_sync = time.time()
            db.Session.remove()
            self.progress = 100
            if self.marker_clip_templating:
                for device_uuid in self.reschedule_devices:
                    self.core.devices[device_uuid].scheduling_information['last_updated'] = None

        return

    def _log(self, message, log_stmt = None, log = False, start = False, sub_msg = False, error = False):
        if log:
            logging.info(log_stmt, exc_info=bool(error))
        if len(self.messages) > 1000:
            self.messages = []
        else:
            self.messages.append({'message': message,
             'time': str(datetime.now().strftime('%H:%M:%S')),
             'start': start,
             'sub_msg': sub_msg,
             'error': error})
        if error:
            if message not in self.errors:
                self.errors.append(message)
            self.synced_without_error = False
        else:
            self.current_status = message

    def wait(self):
        self.waiting = True
        self.syncing = False
        self.progress = 0
        for item in self.checklist:
            item['done'] = False

    def status(self):
        """
        Returns the current  sync messages list, and then resets the list to empty
        :returns: a list of the messages
        """
        output = {'syncing': self.syncing,
         'waiting': self.waiting,
         'messages': copy.copy(self.messages),
         'errors': list(self.errors),
         'progress': self.progress,
         'checklist': self.checklist}
        self.messages = []
        return output

    def short_status(self):
        output = {'syncing': self.syncing,
         'waiting': self.waiting,
         'message': self.current_status if not self.waiting else _('Waiting for LMS'),
         'errors': list(self.errors),
         'progress': self.progress,
         'checklist': self.checklist}
        return output

    def _get_modified(self):
        pos_items = db.Session.query(db.POSItem).filter(db.POSItem.modified == True).all()
        for pos_item in pos_items:
            if pos_item.is_target_configured():
                self.modified_pos_sessions.add(pos_item.uuid)

        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.device_uuid.in_(self.enabled_devices), db.Schedule.pos.has(or_(db.POSItem.state == 'deleted', and_(db.POSItem.state == 'unassigned', db.POSItem.modified == True))))).all()
        for schedule in schedules:
            self.modified_pos_sessions.add(schedule.pos.uuid)

    def _update_modified_hash(self):
        self.changes = {'stamp': time.time(),
         'changes': {}}
        if len(self.modified_pos_sessions) > 0:
            pos_items = db.Session.query(db.POSItem).filter(db.POSItem.uuid.in_(list(self.modified_pos_sessions))).all()
            for pos_item in pos_items:
                scheduled = True if pos_item.schedule and (pos_item.schedule[0].device_schedule_id != None or pos_item.playlist_uuid == None and pos_item.placeholder_type != None) else False
                self.changes['changes'][pos_item.uuid] = {'state': pos_item.state,
                 'message': pos_item.message,
                 'scheduled': scheduled}

        return

    def _queue_actions(self):
        pos_items = db.Session.query(db.POSItem).filter(and_(db.POSItem.modified == True, or_(db.POSItem.playlist_uuid != None, db.POSItem.placeholder_type != None))).options(joinedload('external_device_map'))
        self.pos_actions = []
        self.interfering_schedules = {}
        count = 0
        total = pos_items.count()
        for pos_item in pos_items:
            count = count + 1
            if pos_item.is_target_configured():
                device_uuid = pos_item.external_device_map.device_uuid
                pos_action = {'is_template': self.__is_template(self.core.get_lms_id(), pos_item.playlist_uuid),
                 'playlist_uuid': pos_item.playlist_uuid,
                 'start': pos_item.start,
                 'start_stamp': time.mktime(pos_item.start.timetuple()),
                 'device_uuid': device_uuid,
                 'pos_duration': pos_item.overall_duration,
                 'id': pos_item.uuid,
                 'feature_title': pos_item.feature_title,
                 'transfer_not_before': pos_item.transfer_not_before}
                if pos_item.placeholder_type:
                    pos_action['placeholder_duration'] = pos_item.feature_duration
                    pos_action['placeholder_type'] = pos_item.placeholder_type
                else:
                    pos_action['placeholder_duration'] = None
                    pos_action['placeholder_type'] = None
                self.pos_actions.append(pos_action)
                pos_start_timestamp = time.mktime(pos_item.start.timetuple())
                pos_end_timestamp = time.mktime(pos_item.end.timetuple())
                schedules_in_the_way = db.Session.query(db.Schedule).filter(and_(db.Schedule.device_uuid == device_uuid, db.Schedule.device_uuid.in_(self.enabled_devices), or_(db.Schedule.pos_id == pos_item.uuid, and_(db.Schedule.pos_id == None, or_(and_(pos_start_timestamp >= db.Schedule.start_timestamp, pos_start_timestamp <= db.Schedule.end_timestamp), and_(pos_end_timestamp >= db.Schedule.start_timestamp, pos_end_timestamp <= db.Schedule.end_timestamp), and_(db.Schedule.start_timestamp >= pos_start_timestamp, db.Schedule.start_timestamp <= pos_end_timestamp), and_(db.Schedule.end_timestamp >= pos_start_timestamp, db.Schedule.end_timestamp <= pos_end_timestamp)))))).all()
                self.interfering_schedules[pos_item.uuid] = []
                for schedule in schedules_in_the_way:
                    sch = {'schedule_uuid': schedule.uuid,
                     'device_uuid': device_uuid,
                     'schedule': schedule.to_dict()}
                    if schedule.is_template:
                        sch['playlist_uuid'] = schedule.device_playlist_uuid
                    self.interfering_schedules[pos_item.uuid].append(sch)

            else:
                pos_item.message = _('No configured Screen Server found for screen id: %s') % pos_item.screen_identifier
            pos_item.set_modified()
            pos_item.modified = False
            if count % 20 == 0:
                db.Session.commit()
            self.progress += count / total * 10

        db.Session.commit()
        return

    def _clear_interferences(self, pos_id):
        schedules = self.interfering_schedules[pos_id]
        for schedule in schedules:
            try:
                db_schedule = db.Session.query(db.Schedule).filter(db.Schedule.uuid == schedule['schedule_uuid']).first()
                if db_schedule:
                    cherrypy.core.schedule_validation.remove_validation(db_schedule)
                    cherrypy.engine.publish('ccpush', 'schedule_delete', {'uuid': schedule['schedule_uuid']})
                    for map in db_schedule.show_attribute_maps:
                        db.Session.delete(map)

                    db.Session.delete(db_schedule)
            except Exception as e:
                pass

            device = self.core.devices[schedule['device_uuid']]
            sch_id = schedule['schedule']['device_schedule_id']
            if sch_id in device.scheduling_information:
                schedule['info'] = device.scheduling_information[sch_id]
                if hasattr(device, 'cached_schedule_info'):
                    device.cached_schedule_info[sch_id] = device.scheduling_information[sch_id]
                del device.scheduling_information[sch_id]
            if 'playlist_uuid' in schedule:
                self.potentially_redundant_template_playlists[schedule['playlist_uuid']] = schedule['device_uuid']

        db.Session.commit()

    def _remove_interferences(self, pos_id):
        success = True
        message = ''
        schedules = self.interfering_schedules[pos_id]
        for schedule in schedules[:]:
            if schedule['schedule']['device_schedule_id']:
                success, message = self.core.devices[schedule['device_uuid']].scheduling_delete(schedule['schedule']['device_schedule_id'])
                if success:
                    schedules.remove(schedule)

        if not len(schedules):
            del self.interfering_schedules[pos_id]
        return (success, message)

    def _restore_interferences(self, pos_id):
        db.Session.query(db.Schedule).filter(db.Schedule.pos_id == pos_id).delete('fetch')
        if pos_id in self.interfering_schedules:
            schedules = self.interfering_schedules[pos_id]
            for schedule in schedules:
                device = self.core.devices[schedule['device_uuid']]
                sch_id = schedule['schedule']['device_schedule_id']
                sch = db.Schedule()
                for key, val in schedule['schedule'].iteritems():
                    if key == 'templating_issues':
                        val = json.dumps(val)
                    setattr(sch, key, val)

                db.Session.add(sch)
                if 'info' in schedule:
                    device.scheduling_information[sch_id] = schedule['info']

            try:
                db.Session.commit()
            except IntegrityError:
                logging.critical('Tried to add duplicate schedule(s) to db for pos [%s]. This should NEVER happen.', pos_id, exc_info=True)
                for schedule in schedules:
                    logging.error('Violating schedule: [%s]', schedule)

            del self.interfering_schedules[pos_id]

    def _do_actions(self):
        """
        Performs the following:
        
            1. Deletes Interfering schedules
                - as stored in 'interfering_schedules'  during _queue_actions()
        
            2. Generate list of potententially unused playlists (from autocreations)
             - Wait for deletions to complete
        
            3. for each queued action in pos_actions (from _queue_actions() )
                    - if a playlist is specified, transfer it to the server and wait for completion
        
            4. Recalculate start times
        
        """
        self._log(_('Scheduling POS Sessions'), log_stmt='Executing POS Actions', log=True)
        self.progress += 10
        action_errors = {}
        count = 0
        total = len(self.pos_actions)
        for pos_action in self.pos_actions:
            pos_id = pos_action['id']
            self._clear_interferences(pos_id)
            try:
                error = False
                log_stmt = ''
                message = ''
                if not self.core.devices[pos_action['device_uuid']].device_status['alive']:
                    message = _('Error communicating with device')
                    action_errors[pos_action['id']] = message
                    self._log(message, log_stmt=log_stmt, error=True, sub_msg=True, log=True)
                    continue
                result = {}
                if len(self.pos_actions) - count > 0:
                    self._log(_('Scheduling POS Sessions: %s remaining') % str(len(self.pos_actions) - count), sub_msg=True)
                else:
                    self._log(_('POS Sessions scheduled'), sub_msg=True)
                if not pos_action['is_template']:
                    device_uuid = pos_action.get('device_uuid')
                    playlist_uuid = pos_action.get('playlist_uuid')
                    if not playlist_uuid:
                        schedule_object = {'start_time': pos_action['start_stamp'],
                         'playlist_id': None,
                         'type': 'pos',
                         'pos_duration': pos_action['pos_duration'],
                         'pos_id': pos_action['id'],
                         'placeholder_duration': pos_action['pos_duration'],
                         'placeholder_type': pos_action['placeholder_type']}
                        ok, msg = self._remove_interferences(pos_id)
                        if ok:
                            action_id = self.core._action(self.core.devices[pos_action['device_uuid']].scheduling_add_helper, schedule_object)
                            result = self._wait_for_single_action(action_id, pos_action['device_uuid'], _('Scheduling Session [%s]') % pos_action['id'])
                        else:
                            result['success'] = False
                            result['message'] = msg
                        if not result['success']:
                            error = True
                            message = _('Error scheduling POS Session: [%s]') % result['message']
                            log_stmt = 'Error scheduling POS Session: [%s]' % result['message']
                    else:
                        transfer_time = get_transfer_time(pos_action['start_stamp'], pos_action['transfer_not_before'])
                        messages = self.core.playlist_service.transfer(self.core.get_lms_id(), [device_uuid], [playlist_uuid], transfer_time)
                        playlist_transfer_action_id = None
                        playlist_transfer_errors = []
                        for action in messages:
                            if 'playlist_id' in action:
                                if 'action_id' in action:
                                    playlist_transfer_action_id = action['action_id']
                                elif 'type' in action and action['type'] == 'error':
                                    error = True
                                    playlist_transfer_errors.append(action['message'])

                        if playlist_transfer_action_id:
                            result = self._wait_for_single_action(playlist_transfer_action_id, device_uuid, _('Transferring playlist [%s]') % playlist_transfer_action_id)
                            if not result['success']:
                                message = _('Error transferring playlist: [%s]') % result['message']
                                log_stmt = 'Error in transferring the playlist: %s' % str(result)
                        elif playlist_transfer_errors:
                            message = _('Error transferring playlist: [%s]') % '; '.join(playlist_transfer_errors)
                            log_stmt = 'Error transferring playlist: [%s]. Error: [%s]' % (playlist_uuid, '; '.join(playlist_transfer_errors))
                        else:
                            message = _('Unknown error transferring playlist')
                            log_stmt = 'Unknown error transferring playlist'
                        playlists = self.core.playlist_service.playlist(device_ids=[device_uuid], playlist_ids=[playlist_uuid])[0]
                        if not error:
                            if device_uuid not in playlists or playlist_uuid not in playlists[device_uuid] or 'error_messages' in playlists[device_uuid][playlist_uuid]:
                                error = True
                                message = _('Cannot find selected playlist for: %s') % pos_action['feature_title']
                                log_stmt = 'Cannot find selected playlist for: %s' % pos_action['feature_title']
                                if playlists.has_key(pos_action['device_uuid']) and playlists[pos_action['device_uuid']].has_key(playlist_uuid) and playlists[pos_action['device_uuid']][playlist_uuid].has_key('error_messages'):
                                    message = message + ' :%s' % playlists[pos_action['device_uuid']][playlist_uuid]['error_messages']
                                    log_stmt = log_stmt + ' :%s' % playlists[pos_action['device_uuid']][playlist_uuid]['error_messages']
                            schedule_object = None
                            if not error:
                                pos_action['start'] = self.calculate_new_start_time(playlists[pos_action['device_uuid']][playlist_uuid]['playlist'], pos_action['start'])
                                if pos_action['placeholder_type'] or playlist_uuid:
                                    schedule_object = {'start_time': time.mktime(pos_action['start'].timetuple()),
                                     'playlist_id': playlist_uuid,
                                     'type': 'pos',
                                     'pos_duration': pos_action['pos_duration'],
                                     'pos_id': pos_action['id'],
                                     'placeholder_duration': pos_action['placeholder_duration'],
                                     'placeholder_type': pos_action['placeholder_type']}
                            if not error:
                                if schedule_object:
                                    ok, msg = self._remove_interferences(pos_id)
                                    if ok:
                                        action_id = self.core._action(self.core.devices[pos_action['device_uuid']].scheduling_add_helper, schedule_object)
                                        result = self._wait_for_single_action(action_id, pos_action['device_uuid'], _('Scheduling Session [%s]') % pos_action['id'])
                                    else:
                                        result = {'success': False,
                                         'message': msg}
                                else:
                                    result = {'success': False,
                                     'message': message}
                            if result and not result['success']:
                                error = True
                                message = _('Error scheduling POS schedule: [%s]') % result['message']
                                log_stmt = 'Error scheduling POS schedule: [%s]' % result['message']
                        else:
                            lms_playlist = {}
                            lms_id = self.core.get_lms_id()
                            playlists = self.core.playlist_service.playlist(device_ids=[lms_id], playlist_ids=[pos_action['playlist_uuid']])[0]
                            if playlists.has_key(lms_id) and playlists[lms_id].has_key(pos_action['playlist_uuid']) and not playlists[lms_id][pos_action['playlist_uuid']].has_key('error_messages'):
                                lms_playlist = playlists[lms_id][pos_action['playlist_uuid']]
                            self.core.devices[pos_action['device_uuid']].scheduling_add_job_helper({'type': 'pos',
                             'start_time': time.mktime(pos_action['start'].timetuple()),
                             'source_playlist_uuid': pos_action['playlist_uuid'],
                             'placeholder_type': pos_action['placeholder_type'],
                             'placeholder_duration': pos_action['placeholder_duration'],
                             'pos_id': pos_action['id'],
                             'pos_duration': pos_action['pos_duration']})
                        action_errors[pos_action['id']] = error and message
                        self._log(message, log_stmt=log_stmt, error=True, sub_msg=True, log=True)
                elif message:
                    self._log(message, log_stmt=log_stmt, sub_msg=True, log=True)
            except Exception as ex:
                logging.error(str(ex))
                action_errors[pos_action['id']] = str(ex)
                self._log(_('Error scheduling POS Session [%s]') % pos_action['id'], log_stmt='Error scheduling POS Session [%s]' % pos_action['id'], log=True, error=True)
            finally:
                count = count + 1
                self.progress += count / total * 10

        if len(action_errors.keys()) > 0:
            erroneous_pos_items = db.Session.query(db.POSItem).filter(db.POSItem.uuid.in_(action_errors.keys())).all()
            count = 0
            for pos_item in erroneous_pos_items:
                count = count + 1
                restore = False
                if pos_item.uuid in self.interfering_schedules:
                    for sch in self.interfering_schedules[pos_item.uuid]:
                        if sch['schedule']['device_playlist_uuid']:
                            restore = True

                pos_item.add_error(action_errors[pos_item.uuid])
                if restore:
                    pos_item.state = 'warning'
                    self._restore_interferences(pos_item.uuid)
                else:
                    pos_item.state = 'error'
                if count % 20 == 0:
                    db.Session.commit()

        db.Session.commit()
        return

    def _delete_manual_schedules(self):
        action_map = {}
        if self.manual_reschedule_list:
            if self.marker_clip_templating and self.preshow_trimming:
                additional_schedules_to_reschedule = []
                for device_uuid in self.reschedule_devices:
                    schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.is_template == True, db.Schedule.start_timestamp > time.time() + cfg.core_auto_schedule_resync_gap_minutes.get() * 60, db.Schedule.start_timestamp < time.mktime((datetime.now() + timedelta(hours=cfg.marker_clip_schedule_timeframe())).timetuple()), db.Schedule.device_uuid == device_uuid)).order_by(db.Schedule.start_timestamp)
                    reschedule_next_schedule = False
                    for schedule in schedules:
                        if schedule.uuid not in self.manual_reschedule_list.keys() and reschedule_next_schedule:
                            additional_schedules_to_reschedule.append(schedule.uuid)
                            reschedule_next_schedule = False
                        elif schedule.uuid in self.manual_reschedule_list.keys():
                            reschedule_next_schedule = True

                if len(additional_schedules_to_reschedule):
                    marker_clip_templating_log('Rescheduling additional schedules %s' % additional_schedules_to_reschedule)
                all_schedules_to_reschedule = self.manual_reschedule_list.keys() + additional_schedules_to_reschedule
                schedules = db.Session.query(db.Schedule).filter(db.Schedule.uuid.in_(all_schedules_to_reschedule)).all()
            else:
                schedules = db.Session.query(db.Schedule).filter(db.Schedule.uuid.in_(self.manual_reschedule_list.keys())).all()
            for schedule in schedules:
                device_uuid = schedule.device_uuid
                delete_action = self.core._action(self.core.devices[device_uuid].scheduling_delete_helper, schedule.uuid, remove_database_schedule=False)
                if device_uuid not in action_map:
                    action_map[device_uuid] = []
                action_map[device_uuid].append(delete_action)

            for device_uuid in action_map:
                self._wait_for_multiple_actions(action_map[device_uuid], device_uuid, _('Deleting Manual Schedules'))

            for schedule in schedules:
                schedule.device_playlist_uuid = None
                schedule.device_schedule_id = None
                schedule.device_playlist_duration = None
                schedule.templating_issues = None

            db.Session.commit()
            self.manual_reschedule_list = {}
        return

    def _delete_pos_schedules(self):
        """ Deletes Schedules from the database which have a associated POS Item
        which has been unassigned or marked for deletion
        """
        self._log(_('Deleting POS Schedules'), log_stmt='Deleting POS Schedules', log=True)
        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.device_uuid.in_(self.enabled_devices), db.Schedule.pos.has(or_(db.POSItem.state == 'deleted', and_(db.POSItem.state == 'unassigned', db.POSItem.modified == True)))))
        action_map = {}
        count = 0
        total = schedules.count()
        schedules = schedules.all()
        for schedule in schedules:
            count = count + 1
            if schedule.uuid and schedule.pos.is_target_configured():
                device_uuid = schedule.pos.external_device_map.device_uuid
                if device_uuid not in action_map:
                    action_map[device_uuid] = []
                delete_action = self.core._action(self.core.devices[device_uuid].scheduling_delete_helper, schedule.uuid)
                action_map[device_uuid].append(delete_action)
                if schedule.is_template:
                    self.potentially_redundant_template_playlists[schedule.device_playlist_uuid] = device_uuid
                message = _('POS Schedule [%s] marked for deletion') % schedule.uuid
            else:
                message = _('Cannot delete POS Schedule [%s] because screen does not have a screen server') % schedule.uuid
                schedule.pos.message = 'Cannot delete POS Schedule [%s] because screen does not have a screen server' % schedule.uuid
            self._log(message, sub_msg=True)
            if not count % 20:
                db.Session.commit()
            self.progress += count / total * 5

        db.Session.commit()
        for device_uuid in action_map:
            self._wait_for_multiple_actions(action_map[device_uuid], device_uuid, _('Deleting POS Schedules'))

        self.progress += 5

    def _add_unassigned_pos_schedules(self):
        """
        Assigns all unassigned pos items to AUTO playlist creation
        """
        self._log(_('Adding new POS Schedules'), log_stmt='Adding Unassigned POS Schedules', log=True)
        pos_items = db.Session.query(db.POSItem).filter(or_(and_(or_(db.POSItem.state != 'deleted', db.POSItem.modified == True), db.POSItem.playlist_uuid == None, db.POSItem.placeholder_type == None, not_(db.POSItem.schedule.any())), and_(not_(db.POSItem.schedule.any()), db.POSItem.state == 'error'))).options(joinedload('external_device_map'))
        count = 0
        if pos_items.count() > 0:
            self._log(_('Adding new POS Sessions, %s remaining') % str(pos_items.count()), sub_msg=True)
        else:
            self._log(_('POS Sessions added'), sub_msg=True)
        for pos_item in pos_items:
            if pos_item.is_target_configured():
                schedule = db.Schedule(screen_uuid=pos_item.external_device_map.device.screen.uuid, device_uuid=pos_item.external_device_map.device_uuid, display_name=pos_item.feature_title, start_timestamp=time.mktime(pos_item.start.timetuple()), end_timestamp=time.mktime(pos_item.end.timetuple()), type='pos', pos_duration=pos_item.overall_duration, pos_id=pos_item.uuid)
                db.Session.add(schedule)
                schedule_dict = schedule.to_dict()
                schedule_dict['start_date'] = pos_item.start.strftime('%Y-%m-%d')
                schedule_dict['start_time'] = pos_item.start.strftime('%H:%M:%S')
                schedule_dict['end_date'] = pos_item.end.strftime('%Y-%m-%d')
                schedule_dict['end_time'] = pos_item.end.strftime('%H:%M:%S')
                schedule_dict['duration'] = schedule.end_timestamp - schedule.start_timestamp
                cherrypy.engine.publish('ccpush', 'schedule_save', schedule_dict)
                pos_item.modified = False
                if pos_item.state != 'error':
                    pos_item.state = 'unassigned'
                    pos_item.message = _('Session has not been assigned to a Playlist or Placeholder')
                count = count + 1
                if count % 5 == 0:
                    if pos_items.count() - count > 0:
                        self._log(_('Adding new POS Sessions, %s remaining') % str(pos_items.count()), sub_msg=True)
                    else:
                        self._log(_('New POS Sessions added'), sub_msg=True)
                if count % 20 == 0:
                    db.Session.commit()

        db.Session.commit()
        return

    def transfer_playlists_and_content(self, action_map, transfers):
        """
        Initiates the transfer of playlist content and playlists to the devices
        specified in the action_map and transfers dictionaries.
        :param action_map:  dict
        :param transfers: list
        :returns: None
        """
        if transfers:
            self._log(_('Starting Transfers'), sub_msg=True)
            for transfer in transfers:
                self.__transfer_playlist_content(transfer['device_uuid'], transfer['playlist'], transfer['start_timestamp'], transfer['pos_transfer_not_before'])

        if action_map:
            self._log(_('Creating Playlists'), sub_msg=True)
            for device_uuid in action_map:
                self._wait_for_multiple_actions(action_map[device_uuid], device_uuid, _('Creating POS Playlists'))

    def _create_playlists_for_templates(self):
        """Creates screen playlists for all future schedules on enabled devices.
        """
        self._log(_('Creating Playlists'), log_stmt='Creating final Playlists for templates', log=True)
        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.is_template == True, db.Schedule.device_playlist_uuid == None, db.Schedule.device_schedule_id == None, db.Schedule.start_timestamp > time.time(), db.Schedule.device_uuid.in_(self.enabled_devices)))
        lms_device_id = self.core.get_lms_id()
        lms_playlists = []
        if self.core.devices[lms_device_id].device_configuration['enabled']:
            lms_playlists = self.core.playlist_service.playlist(device_ids=[lms_device_id])[0][lms_device_id]
        db.Session.query(db.ExternalShowAttributeMap).filter(db.ExternalShowAttributeMap.show_attribute_uuid != None).all()
        action_map = {}
        transfers = []
        transfer_devices = {}
        count = 0
        total = schedules.count()
        for schedule in schedules:
            count += 1
            screen = self.core.screens[schedule.screen_uuid]
            pos_transfer_not_before = None
            try:
                if schedule.source_playlist_uuid == 'auto' or schedule.source_playlist_uuid in lms_playlists and 'error_messages' not in lms_playlists[schedule.source_playlist_uuid]:
                    show_attributes = []
                    pos_item = None
                    if schedule.type == 'pos':
                        pos_item = db.Session.query(db.POSItem).get(schedule.pos_id)
                        if not pos_item:
                            logging.warning('Unable to locate the Schedules POS Item.  Schedule: {0}, Pos: {1}'.format(schedule.uuid, schedule.pos_id))
                            continue
                        pos_transfer_not_before = pos_item.transfer_not_before
                        show_start_time = pos_item.start
                        show_attributes = pos_item.valid_show_attribute_uuids()
                    else:
                        show_start_time = datetime.fromtimestamp(schedule.start_timestamp)
                        show_attributes = [ map.show_attribute_uuid for map in schedule.show_attribute_maps if map != None ]
                    if schedule.source_playlist_uuid == 'auto':
                        screen_playlist = self.core.playlist_service.auto_create_playlist(pos_item=pos_item, show_attributes=show_attributes)
                        if not screen_playlist:
                            if schedule.pos:
                                schedule.pos.add_error(_('Unknown error creating playlist'))
                                schedule.pos.state = 'error'
                                logging.error('Unknown error creating playlist for pos_item: {0}'.format(schedule.pos_id))
                            else:
                                logging.error('Unknown error creating playlist for schedule: {0}'.format(schedule.uuid))
                            schedule.error = True
                            continue
                    else:
                        source_playlist = copy.deepcopy(lms_playlists[schedule.source_playlist_uuid]['playlist'])
                        screen_playlist = self.core.playlist_service.create_screen_playlist(source_playlist, show_attributes, screen, show_start_time, pos_item)
                    screen_playlist['title'] = self._create_scheduled_playlist_title(screen_playlist['title'], show_attributes, show_start_time, screen['identifier'], screen['title'], pos_item=pos_item)
                    screen_playlist['playlist']['title'] = screen_playlist['title']
                    screen_playlist['text'] = screen_playlist['title']
                    screen_playlist['playlist']['text'] = screen_playlist['text']
                    schedule.device_playlist_uuid = screen_playlist['id']
                    schedule.error = False
                    templating_issues = screen_playlist.get('templating_issues', [])
                    if templating_issues:
                        schedule.templating_issues = json.dumps(templating_issues)
                        if self.core.playlist_service.has_template_problems(screen_playlist['playlist']):
                            schedule.error = True
                    if schedule.device_uuid not in action_map:
                        action_map[schedule.device_uuid] = []
                    action_map[schedule.device_uuid].append(self.core._action(self.core.devices[schedule.device_uuid].playlist_save_helper, screen_playlist['playlist'], schedule.uuid))
                    device_playlists = self.core.devices[schedule.device_uuid]._device_get_playlist_information()
                    for playlist_uuid in device_playlists:
                        if playlist_uuid != 'last_updated':
                            if device_playlists[playlist_uuid]['title'] == screen_playlist['title']:
                                if not self.potentially_redundant_template_playlists.has_key(playlist_uuid):
                                    self.potentially_redundant_template_playlists[playlist_uuid] = schedule.device_uuid

                    schedule.start_timestamp = time.mktime(self.calculate_new_start_time(screen_playlist['playlist'], show_start_time).timetuple())
                    transfers.append({'device_uuid': copy.copy(schedule.device_uuid),
                     'playlist': screen_playlist,
                     'start_timestamp': copy.copy(schedule.start_timestamp),
                     'pos_transfer_not_before': pos_transfer_not_before})
                    db_playlist_item = db.GeneratedPlaylist(uuid=screen_playlist['id'], start_timestamp=schedule.start_timestamp)
                    db.Session.add(db_playlist_item)
                    transfer_devices[copy.copy(schedule.device_uuid)] = True
                else:
                    if schedule.source_playlist_uuid not in lms_playlists:
                        error_message = _('Playlist [%s] was not found') % schedule.source_playlist_uuid
                    else:
                        error_message = lms_playlists[schedule.source_playlist_uuid]['error_messages']
                    schedule.error = True
                    self._log(_('Could not create schedule [%s]: [%s]') % (schedule.uuid, error_message), log_stmt='Could not create schedule [%s]: [%s]' % (schedule.uuid, error_message), error=True, log=True, sub_msg=True)
                    if schedule.pos_id:
                        if schedule.pos:
                            schedule.pos.add_error(error_message)
                            schedule.pos.state = 'error'
                        else:
                            self._log(_('POS Session [%s] has been deleted for schedule [%s]') % (schedule.pos_id, schedule.uuid), log_stmt='POS Session [%s] has been deleted for schedule [%s]' % (schedule.pos_id, schedule.uuid), error=True, log=True)
            except Exception as ex:
                error_message = str(ex)
                self._log(_('Error creating playlist for schedule [%s]: [%s]') % (schedule.uuid, error_message), log_stmt='Error creating playlist for schedule [%s]: [%s]' % (schedule.uuid, error_message), error=True, log=True)
                if schedule.pos:
                    schedule.pos.add_error(error_message)
                    schedule.pos.state = 'error'
            finally:
                if count % 20 == 0:
                    db.Session.commit()
                self.progress += count / total * 10
                if schedule.pos and schedule.pos.state == 'error' and schedule.pos_id in self.interfering_schedules:
                    schedule.pos_state = 'warning'

        db.Session.commit()
        self.transfer_playlists_and_content(action_map, transfers)
        self.progress += 10
        return

    def get_cpls_to_trim_from_playlist(self, playlist, max_preshow_duration = None, missing_or_invalid_cpls = []):
        """
        Returns a list of cpl info dicts for cpls that were inserted into the playlist from pack(s) but
        must be deleted in order for the preshow duration of the playlist to not exceed
        the max_preshow_duration or because they are missing/corrupt.
        If max_preshow_duration is None, only missing or corrupt cpls will be returned.
        Each dict contains the playlist index of the cpl and the pack index info of the cpl (both the index of the pack
        in the list of packs inserted and the index of the cpl within that pack)
        If a trimming weight was given in the pack, this is used to decide the order in which
        cpls should be removed.
        If no trimming weight was given in pack, cpls should be removed from first in
        pack to last.
        If the pack had a trimming weight for some cpls but not others, only cpls
        with the trimming weights will be removed.
        """
        offset_pack_found = False
        duration = 0
        cpl_indexes_to_remove = []
        for template_info in reversed(playlist['templating_issues']):
            if template_info.get('placeholder_type') != 'pack':
                continue
            if 'offset_cpl_index' in template_info:
                offset_pack_found = True
            elif not offset_pack_found and template_info['last_cpl_spl_index']:
                number_of_cpls_inserted = len(template_info['inserted_ids'])
                position_of_last_pack_cpl = template_info['last_cpl_spl_index']
                pack_index = number_of_cpls_inserted - 1
                for x in xrange(position_of_last_pack_cpl, position_of_last_pack_cpl - number_of_cpls_inserted, -1):
                    if playlist['playlist']['events'][x]['cpl_id'] in missing_or_invalid_cpls:
                        cpl_indexes_to_remove.append({'playlist_index': x,
                         'pack_index': (playlist['templating_issues'].index(template_info), pack_index)})
                        pack_index -= 1

            if template_info['inserted_ids'] and offset_pack_found:
                number_of_cpls_inserted = len(template_info['inserted_ids'])
                position_of_last_pack_cpl = template_info['last_cpl_spl_index']
                clip_list = []
                trimming_weight = False
                pack_index = number_of_cpls_inserted - 1
                for x in xrange(position_of_last_pack_cpl, position_of_last_pack_cpl - number_of_cpls_inserted, -1):
                    if 'trimming_weight' in playlist['playlist']['events'][x]:
                        trimming_weight = True
                    clip_list.append({'event': playlist['playlist']['events'][x],
                     'playlist_index': x,
                     'pack_index': pack_index})
                    pack_index -= 1

                if trimming_weight:
                    clip_list = sorted(clip_list, key=lambda clip: clip['event'].get('trimming_weight', None))
                for clip in clip_list:
                    if clip['event']['cpl_id'] in missing_or_invalid_cpls:
                        cpl_indexes_to_remove.append({'playlist_index': clip['playlist_index'],
                         'pack_index': (playlist['templating_issues'].index(template_info), clip['pack_index'])})
                        continue
                    if max_preshow_duration:
                        duration += clip['event']['duration_in_seconds'] or 0
                        if duration > max_preshow_duration and (not trimming_weight or trimming_weight and 'trimming_weight' in clip['event']):
                            cpl_indexes_to_remove.append({'playlist_index': clip['playlist_index'],
                             'pack_index': (playlist['templating_issues'].index(template_info), clip['pack_index'])})

        return cpl_indexes_to_remove

    def trim_cpls_from_playlist(self, playlist, cpl_indexes_to_remove):
        """
        Removes the cpls corresponding to the given cpl info dicts from the playlist.
        Updates the templating issues metadata of the schedule to reflect the deletions from
        the playlist.
        """
        last_preshow_cpl_uuid_index = self.get_last_preshow_cpl_index(playlist['templating_issues'])
        new_offset_cpl_index = last_preshow_cpl_uuid_index
        for cpl_info in sorted(cpl_indexes_to_remove, key=lambda cpl: cpl['playlist_index'], reverse=True):
            playlist['duration_in_seconds'] = playlist['duration_in_seconds'] - int(playlist['playlist']['events'][cpl_info['playlist_index']]['duration_in_seconds'] or 0)
            playlist['duration_in_frames'] = playlist['duration_in_frames'] - playlist['playlist']['events'][cpl_info['playlist_index']]['duration_in_frames']
            del playlist['playlist']['events'][cpl_info['playlist_index']]
            del playlist['content_ids'][cpl_info['playlist_index']]
            if cpl_info['playlist_index'] <= new_offset_cpl_index:
                if new_offset_cpl_index:
                    new_offset_cpl_index = new_offset_cpl_index - 1
                else:
                    new_offset_cpl_index = None
            del playlist['templating_issues'][cpl_info['pack_index'][0]]['inserted_ids'][cpl_info['pack_index'][1]]

        playlist['playlist']['duration_in_seconds'] = playlist['duration_in_seconds']
        playlist['playlist']['duration_in_frames'] = playlist['duration_in_frames']
        for info in playlist['templating_issues']:
            if 'offset_cpl_index' in info:
                info['offset_cpl_index'] = new_offset_cpl_index

        return playlist

    def _compile_trimming_report(self, trimmed_cpls, bad_cpl_uuids, spl, report):
        for cpl_trim_detail in trimmed_cpls:
            spl_index = cpl_trim_detail['playlist_index']
            if spl_index in report['trimmed_indices']:
                continue
            templating_issues_index = cpl_trim_detail['pack_index'][0]
            cpl = spl['playlist']['events'][spl_index]
            cpl_uuid = cpl['cpl_id']
            reason = NOT_PLAYABLE if cpl_uuid in bad_cpl_uuids else LOW_PRIORITY
            report.setdefault(templating_issues_index, []).append(dict(cpl_uuid=cpl_uuid, content_title=cpl.get('text'), reason=reason, trim_time=time.time(), index_in_pack=cpl_trim_detail['pack_index'][1]))
            report['trimmed_indices'].add(spl_index)

    def _create_marker_playlists_for_templates(self):
        self._log(_('Creating Playlists'), log_stmt='Creating final Playlists for templates', log=True)
        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.is_template == True, db.Schedule.device_playlist_uuid == None, db.Schedule.device_schedule_id == None, db.Schedule.start_timestamp > time.time(), db.Schedule.device_uuid.in_(self.enabled_devices))).order_by(db.Schedule.start_timestamp)
        lms_device_id = self.core.get_lms_id()
        lms_playlists = []
        if self.core.devices[lms_device_id].device_configuration['enabled']:
            lms_playlists = self.core.playlist_service.playlist(device_ids=[lms_device_id])[0][lms_device_id]
        count = 0
        total = schedules.count()
        if total:
            action_map = {}
            transfers = []
            missing_or_invalid_cpl_uuids = set()
            if self.preshow_trimming:
                schedule_uuids_device_uuids = [ (schedule.uuid, schedule.device_uuid, schedule.end_timestamp) for schedule in schedules ]
                split_to_lists = zip(*schedule_uuids_device_uuids)
                schedule_ids = split_to_lists[0]
                device_ids = split_to_lists[1]
                schedule_cutoff_timestamp = time.mktime((datetime.now() + timedelta(hours=cfg.marker_clip_schedule_timeframe())).timetuple())
                schedules_not_resyncing = db.Session.query(db.Schedule.uuid, db.Schedule.device_uuid, db.Schedule.end_timestamp).filter(and_(db.Schedule.start_timestamp > time.time(), db.Schedule.start_timestamp < schedule_cutoff_timestamp, db.Schedule.device_uuid.in_(device_ids), not_(db.Schedule.uuid.in_(schedule_ids)))).order_by(db.Schedule.end_timestamp.asc()).all()
                devices_schedules_end_timestamps = {}
                for schedule in schedules_not_resyncing:
                    devices_schedules_end_timestamps.setdefault(schedule.device_uuid, []).append(schedule.end_timestamp)

            for schedule in schedules:
                count += 1
                screen = self.core.screens[schedule.screen_uuid]
                report = dict(trimmed_indices=set())
                try:
                    if schedule.source_playlist_uuid in lms_playlists and 'error_messages' not in lms_playlists[schedule.source_playlist_uuid]:
                        schedule_pst = schedule.published_show_time
                        show_start_time = datetime.fromtimestamp(schedule_pst)
                        source_playlist = copy.deepcopy(lms_playlists[schedule.source_playlist_uuid]['playlist'])
                        screen_playlist = self.core.playlist_service.create_screen_playlist(source_playlist, [], screen, show_start_time, None)
                        screen_playlist['title'] = self._create_scheduled_playlist_title(source_playlist['title'], [], show_start_time, '', screen['title'], pos_item=None)
                        screen_playlist['playlist']['title'] = screen_playlist['title']
                        screen_playlist['text'] = screen_playlist['title']
                        screen_playlist['playlist']['text'] = screen_playlist['text']
                        schedule.device_playlist_uuid = screen_playlist['id']
                        schedule.error = False
                        if schedule.device_uuid not in action_map:
                            action_map[schedule.device_uuid] = []
                        pre_trimmed_playlist = copy.deepcopy(screen_playlist)
                        max_preshow_duration = None
                        cpls_to_trim = []
                        if self.preshow_trimming:
                            last_preshow_cpl_uuid_position = self.get_last_preshow_cpl_index(screen_playlist['templating_issues'])
                            if last_preshow_cpl_uuid_position != None:
                                closest_end_time = None
                                if schedule.device_uuid in devices_schedules_end_timestamps:
                                    closest_end_time = self.get_closest_schedule_end_time(schedule.end_timestamp, devices_schedules_end_timestamps[schedule.device_uuid])
                                minimum_gap_minutes = cfg.preshow_trimming_minimum_schedule_gap()
                                if closest_end_time:
                                    max_preshow_duration = schedule_pst - (closest_end_time + minimum_gap_minutes * 60)
                                    cpls_to_trim = self.get_cpls_to_trim_from_playlist(screen_playlist, max_preshow_duration, missing_or_invalid_cpl_uuids)
                                    if cpls_to_trim:
                                        cpl_uuids_to_trim = [ screen_playlist['playlist']['events'][cpl_info['playlist_index']]['cpl_id'] for cpl_info in cpls_to_trim ]
                                        trimming_log = 'Trimming CPLs from playlist %s on screen %s: %s' % (screen_playlist['id'], screen['title'], cpl_uuids_to_trim)
                                        self._compile_trimming_report(cpls_to_trim, missing_or_invalid_cpl_uuids, pre_trimmed_playlist, report)
                                        screen_playlist = self.trim_cpls_from_playlist(screen_playlist, cpls_to_trim)
                                    else:
                                        trimming_log = 'No excess pack CPLS in playlist %s on screen %s' % (screen_playlist['id'], screen['title'])
                        action_id = self.core._action(self.core.devices[schedule.device_uuid].playlist_save_helper, pre_trimmed_playlist['playlist'])
                        self._wait_for_single_action(action_id, schedule.device_uuid, _('Transferring playlist [%s]') % action_id)
                        playlist_pack_cpls = self.get_pack_cpl_uuids(screen_playlist['templating_issues'])
                        invalid_cpls = self.core.devices[schedule.device_uuid].get_playlist_missing_or_invalid_cpl_uuids(pre_trimmed_playlist['playlist']['id'])
                        invalid_pack_cpls = invalid_cpls.intersection(playlist_pack_cpls)
                        if invalid_pack_cpls:
                            added_to_invalid_list = False
                            for cpl in invalid_cpls:
                                cpl_valid = False
                                if cpl in self.core.contents and self.core.contents[cpl].valid_on_device(self.core.get_lms_id()):
                                    cpl_valid = True
                                else:
                                    for device_uuid in self.core.devices:
                                        device_conf = self.core.devices[device_uuid].device_configuration
                                        if device_conf['enabled'] and device_conf['type'] == 'gdc' and device_uuid != schedule.device_uuid:
                                            try:
                                                cpl_validation = self.core.devices[device_uuid].validate_cpl(cpl)
                                            except Exception:
                                                logging.error('Error getting cpl validation info for %s from %s', cpl, device_uuid, exc_info=True)
                                                continue

                                            if not cpl_validation['success']:
                                                cpl_valid = True
                                                for cpl_error in cpl_validation['response']:
                                                    if cpl_error['code'] != 3:
                                                        cpl_valid = False
                                                        break

                                                if cpl_valid:
                                                    break
                                            else:
                                                cpl_valid = True
                                                break

                                if not cpl_valid:
                                    added_to_invalid_list = True
                                    missing_or_invalid_cpl_uuids.add(cpl)

                            if added_to_invalid_list:
                                cpls_to_trim = self.get_cpls_to_trim_from_playlist(pre_trimmed_playlist, max_preshow_duration, missing_or_invalid_cpl_uuids)
                                if cpls_to_trim:
                                    cpl_uuids_to_trim = [ pre_trimmed_playlist['playlist']['events'][cpl_info['playlist_index']]['cpl_id'] for cpl_info in cpls_to_trim ]
                                    trimming_log = 'Trimming CPLs from playlist %s on screen %s: %s' % (pre_trimmed_playlist['id'], screen['title'], cpl_uuids_to_trim)
                                    self._compile_trimming_report(cpls_to_trim, missing_or_invalid_cpl_uuids, pre_trimmed_playlist, report)
                                    screen_playlist = self.trim_cpls_from_playlist(pre_trimmed_playlist, cpls_to_trim)
                                else:
                                    trimming_log = 'No excess pack CPLS in playlist %s on screen %s' % (pre_trimmed_playlist['id'], screen['title'])
                        if cpls_to_trim:
                            marker_clip_templating_log(trimming_log)
                        action_map[schedule.device_uuid].append(self.core._action(self.core.devices[schedule.device_uuid].playlist_save_helper, screen_playlist['playlist']))
                        templating_issues = screen_playlist.get('templating_issues', [])
                        for index, packfo in enumerate(itertools.ifilter(lambda t: t.get('placeholder_type') == 'pack', templating_issues)):
                            packfo['trimmed_cpls'] = report.get(index, [])

                        if templating_issues:
                            schedule.templating_issues = json.dumps(templating_issues)
                            if self.core.playlist_service.has_template_problems(screen_playlist['playlist']):
                                schedule.error = True
                        device_playlists = self.core.devices[schedule.device_uuid]._device_get_playlist_information()
                        for playlist_uuid in device_playlists:
                            if playlist_uuid != 'last_updated':
                                if device_playlists[playlist_uuid]['title'] == screen_playlist['title']:
                                    if not self.potentially_redundant_template_playlists.has_key(playlist_uuid):
                                        self.potentially_redundant_template_playlists[playlist_uuid] = schedule.device_uuid

                        schedule.start_timestamp = round(self.calculate_marker_clip_schedule_start_time(screen_playlist, schedule_pst))
                        if self.preshow_trimming:
                            schedule.end_timestamp = schedule.start_timestamp + screen_playlist['playlist']['duration_in_seconds']
                            if schedule.device_uuid in devices_schedules_end_timestamps:
                                bisect.insort(devices_schedules_end_timestamps[schedule.device_uuid], schedule.end_timestamp)
                            else:
                                devices_schedules_end_timestamps[schedule.device_uuid] = [schedule.end_timestamp]
                        transfers.append({'device_uuid': copy.copy(schedule.device_uuid),
                         'playlist': screen_playlist,
                         'start_timestamp': copy.copy(schedule.start_timestamp),
                         'pos_transfer_not_before': None})
                        db_playlist_item = db.GeneratedPlaylist(uuid=screen_playlist['id'], start_timestamp=schedule.start_timestamp)
                        db.Session.add(db_playlist_item)
                    else:
                        if schedule.source_playlist_uuid not in lms_playlists:
                            error_message = _('Playlist [%s] was not found') % schedule.source_playlist_uuid
                        else:
                            error_message = lms_playlists[schedule.source_playlist_uuid]['error_messages']
                        schedule.error = True
                        self._log(_('Could not create schedule [%s]: [%s]') % (schedule.uuid, error_message), log_stmt='Could not create schedule [%s]: [%s]' % (schedule.uuid, error_message), error=True, log=True, sub_msg=True)
                except Exception as ex:
                    error_message = str(ex)
                    self._log(_('Error creating playlist for schedule [%s]: [%s]') % (schedule.uuid, error_message), log_stmt='Error creating playlist for schedule [%s]: [%s]' % (schedule.uuid, error_message), error=True, log=True)
                finally:
                    if count % 20 == 0:
                        db.Session.commit()
                    self.progress += count / total * 10

            db.Session.commit()
            self.transfer_playlists_and_content(action_map, transfers)
        self.progress += 10
        return

    def calculate_new_start_time(self, playlist, start_time):
        show_start_offset = self.find_show_start_offset(playlist)
        if show_start_offset > 0:
            show_start_offset = show_start_offset - show_start_offset % 60
            start_time = start_time - timedelta(seconds=show_start_offset)
        return start_time

    def get_closest_schedule_end_time(self, schedule_end_timestamp, device_schedules_end_timestamps):
        """
        Loops through the device's schedule end timestamps assigning the end stamp,
        until we reach one that is greater than this schedule start timestamp.
        This assumes the schedule PST does not occur before the end of the last schedule,
        so it finds the last schedule before it that doesn't clash with it
        """
        closest_end_time = None
        for schedule_end_time in device_schedules_end_timestamps:
            if schedule_end_time < schedule_end_timestamp:
                closest_end_time = schedule_end_time

        return closest_end_time

    def get_last_preshow_cpl_index(self, templating_info):
        """
        Returns the position of the last cpl of the pre-show given the 'templating_issues'
        info of a playlist/schedule.
        Returns None if there was no PST marker clip placeholder in the playlist, if an empty pack was
        was matched to the PST marker clip placeholder or if a matching pack was not found.
        """
        last_preshow_cpl_uuid_position = None
        for template_info in templating_info:
            if self.preshow_end_placeholder == template_info['text']:
                last_preshow_cpl_uuid_position = template_info['offset_cpl_index'] if 'offset_cpl_index' in template_info else None

        return last_preshow_cpl_uuid_position

    def get_pack_cpl_uuids(self, templating_info):
        pack_cpl_uuids = set()
        for template_info in templating_info:
            if template_info.get('placeholder_type') != 'pack':
                continue
            pack_cpl_uuids = pack_cpl_uuids.union(set(template_info['inserted_ids']))

        return pack_cpl_uuids

    def get_duration_of_events_to_position(self, cpl_index, playlist_events):
        """
        Returns the duration from the beginning of the playlist to the cpl in given position inclusive.
        """
        duration = 0
        position = 0
        for event in playlist_events:
            duration = duration + (event['duration_in_seconds'] if event['duration_in_seconds'] else 0)
            if position == cpl_index:
                break
            position += 1

        return duration

    def calculate_marker_clip_schedule_start_time(self, screen_playlist, published_show_time):
        """
        Calculates the schedule start time based on the contraint that the
        published show time needs to coincide with the end of the EPS or LPS pack (depending on config).
        """
        last_preshow_cpl_uuid_position = self.get_last_preshow_cpl_index(screen_playlist['templating_issues'])
        if last_preshow_cpl_uuid_position == None:
            return published_show_time
        else:
            offset = self.get_duration_of_events_to_position(last_preshow_cpl_uuid_position, screen_playlist['playlist']['events'])
            start_time = published_show_time - offset
            return start_time

    def find_show_start_offset(self, playlist):
        """
        :param playlist: a playlist dictionary
        :returns: int, seconds
        """
        position = 0
        show_start_offset = 0
        for event in playlist['events']:
            for automation in event['automation']:
                try:
                    automation_config = db.Session.query(db.AutomationConfiguration).filter(db.AutomationConfiguration.automation_name == automation['name']).one()
                    if automation_config.has_flag('show_start'):
                        if automation['type_specific'].has_key('offset_in_seconds') and automation['type_specific'].has_key('offset_from'):
                            if automation['type_specific']['offset_from'] == 'start':
                                show_start_offset = position + automation['type_specific']['offset_in_seconds']
                            elif automation['type_specific']['offset_from'] == 'end':
                                show_start_offset = position + event['duration_in_seconds'] - automation['type_specific']['offset_in_seconds']
                            return show_start_offset
                except NoResultFound:
                    continue

            if event.has_key('duration_in_seconds') and event['duration_in_seconds']:
                position += event['duration_in_seconds']

        return 0

    def _create_schedules_for_templates(self):
        self._log(_('Scheduling Playlists'), log_stmt='Scheduling playlists', log=True)
        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.device_playlist_uuid != None, db.Schedule.device_schedule_id == None, db.Schedule.start_timestamp > time.time(), db.Schedule.device_uuid.in_(self.enabled_devices)))
        action_map = {}
        count = 0
        total = schedules.count()
        device_playlists = {}
        for schedule in schedules:
            count += 1
            if schedule.device_uuid not in device_playlists:
                device_playlists[schedule.device_uuid] = self.core.devices[schedule.device_uuid].get_playlist_uuid_list().get('playlist_uuid_list', [])
            skip = False
            if schedule.pos and schedule.device_playlist_uuid not in device_playlists[schedule.device_uuid]:
                restore = False
                if schedule.pos_id in self.interfering_schedules:
                    for sch in self.interfering_schedules[schedule.pos_id]:
                        if sch['schedule']['device_playlist_uuid']:
                            restore = True

                if restore:
                    schedule.pos.state = 'warning'
                else:
                    schedule.pos.state = 'error'
                    schedule.pos.message = _('Cannot find specified Playlist on the screen server')
                if schedule.pos_id in self.interfering_schedules:
                    self._restore_interferences(schedule.pos_id)
                skip = True
            if not skip:
                try:
                    action_map.setdefault(schedule.device_uuid, [])
                    schedule_object = {'start_time': schedule.start_timestamp,
                     'playlist_id': schedule.device_playlist_uuid,
                     'type': 'pos' if schedule.pos_id else 'manual',
                     'schedule_db_uuid': schedule.uuid,
                     'pos_id': schedule.pos_id}
                    if schedule.pos_id in self.interfering_schedules:
                        ok, msg = self._remove_interferences(schedule.pos_id)
                        if not ok:
                            raise Exception(msg)
                    action = self.core._action(self.core.devices[schedule.device_uuid].scheduling_add_helper, schedule_object)
                    action_map[schedule.device_uuid].append(action)
                except Exception as ex:
                    message = _('Unknown error scheduling Playlist')
                    schedule.error = True
                    if schedule.pos:
                        schedule.pos.add_error(message)
                        schedule.pos.state = 'error'
                    self._log(message, log_stmt='Unknown error scheduling playlist for POS session', log=True, error=True)

            if count % 20 == 0:
                db.Session.commit()
            self.progress += count / total * 10

        db.Session.commit()
        for device_uuid in action_map:
            self._wait_for_multiple_actions(action_map[device_uuid], device_uuid, _('Scheduling Playlists'))

        self.progress += 10
        return

    def _remove_redundant_templated_playlists(self):
        for playlist_uuid in self.potentially_redundant_template_playlists:
            device_uuid = self.potentially_redundant_template_playlists[playlist_uuid]
            if device_uuid != self.core.get_lms_id() and device_uuid in self.enabled_devices:
                schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.device_uuid == device_uuid, db.Schedule.device_playlist_uuid == playlist_uuid))
                if schedules.count() == 0:
                    self.core.playlist_service.delete([playlist_uuid], [device_uuid])

    def _check_show_start_cue_configuration(self):
        self._log(_('Checking Show Start Configuration'), log_stmt='Checking Show Start Configuration', log=True)
        current_config = {}
        automation_configs = db.Session.query(db.AutomationConfiguration).join(db.AutomationConfiguration._flags).filter(db.AutomationFlag.name == 'show_start')
        for cue in automation_configs:
            current_config[copy.copy(cue.automation_name)] = True

        cues_added = []
        cues_removed = []
        sessions_to_be_updated = []
        if hasattr(self, 'show_start_cues_configuration'):
            for cue_name in self.show_start_cues_configuration:
                if not current_config.has_key(cue_name):
                    cues_removed.append(cue_name)

            for cue_name in current_config:
                if not self.show_start_cues_configuration.has_key(cue_name):
                    cues_added.append(cue_name)

        if len(cues_added) > 0 or len(cues_removed) > 0:
            self._log(_('Updating Show Start Configuration'), log_stmt='Show Start Configuration has changed. Adjusting schedules accordingly', sub_msg=True, log=True)
            playlist_uuids = {}
            for schedule in db.Session.query(db.Schedule).filter(db.Schedule.type == 'pos').all():
                if not playlist_uuids.has_key(schedule.device_playlist_uuid):
                    playlist_uuids[schedule.device_playlist_uuid] = []
                playlist_uuids[schedule.device_playlist_uuid].append(schedule.pos)

            playlists = self.core.playlist_service.playlist(playlist_ids=playlist_uuids.keys())[0]
            for device_uuid in playlists:
                for playlist_uuid in playlists[device_uuid]:
                    playlist = playlists[device_uuid][playlist_uuid].get('playlist', {})
                    for event in playlist.get('events', []):
                        for automation in event.get('automation', []):
                            if automation.get('name', None) in cues_added or automation.get('name', None) in cues_removed:
                                sessions_to_be_updated.extend(playlist_uuids.get(playlist_uuid, ()))

            count = 0
            for session in sessions_to_be_updated:
                count = count + 1
                if session is not None and session.state == 'assigned' and session.start > datetime.now() and (session.playlist_uuid != None or session.placeholder_type != None):
                    session.modified = True
                    self._log(_('Adjusting POS session: [%s]') % str(session.uuid), log_stmt='Moving POS session: [%s]' % str(session.uuid), log=True, sub_msg=True)
                if count % 20 == 0:
                    db.Session.commit()

            db.Session.commit()
        self.show_start_cues_configuration = current_config
        return

    def __transfer_playlist_content(self, device_uuid, playlist, start_timestamp, not_before = None):
        transfer_time = get_transfer_time(start_timestamp, not_before)
        content_uuids = set(get_playlist_cpl_uuids(playlist['playlist']))
        for cpl_uuid in content_uuids:
            if not self.core.contents.valid_on_device(cpl_uuid, device_uuid, code=0):
                self.core.content_service.transfer_content('Auto', device_uuid, cpl_uuid, transfer_time, playlist['playlist']['id'])

    def __is_template(self, device_uuid, playlist_uuid):
        if playlist_uuid == 'auto':
            return True
        playlists = self.core.playlist_service.playlist(device_ids=[device_uuid], playlist_ids=[playlist_uuid])[0]
        is_template = False
        if playlists.has_key(device_uuid) and playlists[device_uuid].has_key(playlist_uuid) and not playlists[device_uuid][playlist_uuid].has_key('error_messages'):
            playlist = playlists[device_uuid][playlist_uuid]
            is_template = self.core.playlist_service.is_template(playlist['playlist'])
        return is_template

    def _wait_for_multiple_actions(self, actions, device_id, action_type):
        iterations = 0
        device = self.core.devices[device_id]
        screen = self.core.screens[device.device_configuration['screen_uuid']]['identifier']
        if actions:
            while len(actions) > 0 and iterations < 180:
                actions_copy = actions[:]
                for action in actions_copy:
                    if device.messages.has_key(action):
                        actions.remove(action)
                        if not device.messages[action]['success']:
                            self._log(_('Error %s : [%s] ') % (action_type, device.messages[action]['message']), log_stmt='Error %s : [%s] ' % (action_type, device.messages[action]['message']), error=True, sub_msg=True, log=True)

                iterations = iterations + 1
                if len(actions) > 0:
                    self._log(_('%s: %s remaining on Screen %s') % (action_type, str(len(actions)), screen), sub_msg=True)
                else:
                    self._log(_('%s: Updated Screen %s') % (action_type, screen), sub_msg=True)
                time.sleep(1)

    def _wait_for_single_action(self, action_id, device_id, action_type):
        iterations = 0
        device = self.core.devices[device_id]
        screen = self.core.screens[device.device_configuration['screen_uuid']]['identifier']
        while iterations < 1000:
            if action_id and device.messages and device.messages.has_key(action_id):
                return device.messages[action_id]
            time.sleep(0.1)
            iterations = iterations + 1
            if iterations % 5 == 0:
                self._log(_('%s: Screen %s') % (action_type, screen), sub_msg=True)

        return {'success': False,
         'message': 'Timed out waiting for actions to complete'}

    def __get_bookend_start_stamp(self, start, offset, duration = None):
        if duration != None:
            raw_stamp = start - offset - duration
        else:
            raw_stamp = start + offset
        raw_datetime = datetime.fromtimestamp(raw_stamp)
        return time.mktime(datetime(raw_datetime.year, raw_datetime.month, raw_datetime.day, raw_datetime.hour, raw_datetime.minute, raw_datetime.second, 0).timetuple())

    def _add_bookends(self):
        self._log(_('Processing Bookend Schedules'), log_stmt='Processing Bookend Schedules', log=True)
        start_active = cfg.core_bookend_start_active.get()
        end_active = cfg.core_bookend_end_active.get()
        ignore_list = []
        if start_active == True:
            start_spl_offset = cfg.core_bookend_start_spl_offset()
            start_spl_uuid = cfg.core_bookend_start_spl_uuid()
            ignore_list.append(start_spl_uuid)
            if self.core.devices[self.core.get_lms_id()]._device_get_playlist_information([start_spl_uuid])[start_spl_uuid].has_key('error_messages'):
                self._log(_('Configured Start of Day playlist was not found: [%s]') % start_spl_uuid, log_stmt='Configured Start of Day playlist was not found: [%s]' % start_spl_uuid, log=True, error=True)
                start_active = False
                cfg.core_bookend_start_active.set(False)
                cfg.core_bookend_start_spl_uuid.set('')
                config.save()
        if end_active == True:
            end_spl_offset = cfg.core_bookend_end_spl_offset()
            end_spl_uuid = cfg.core_bookend_end_spl_uuid()
            ignore_list.append(end_spl_uuid)
            if self.core.devices[self.core.get_lms_id()]._device_get_playlist_information([end_spl_uuid])[end_spl_uuid].has_key('error_messages'):
                self._log(_('Configured End of Day playlist was not found: [%s]') % end_spl_uuid, log_stmt='Configured End of Day playlist was not found: [%s]' % end_spl_uuid, log=True, error=True)
                end_active = False
                cfg.core_bookend_end_active.set(False)
                cfg.core_bookend_end_spl_uuid.set('')
                config.save()
        schedules_to_delete = {}
        schedules_to_add = {}
        playlists_to_transfer = {}
        device_ids, device_errors = self.core.get_devices([], base_scheduling.Scheduling)
        if start_active or end_active:
            today = datetime.today()
            current_timestamp = local_datetime_to_posix(today, cfg.timezone())
            if today.hour < 4:
                start_of_today = local_datetime_to_posix(datetime(today.year, today.month, today.day - 1, 4, 0, 0, 0), cfg.timezone())
            else:
                start_of_today = local_datetime_to_posix(datetime(today.year, today.month, today.day, 4, 0, 0, 0), cfg.timezone())
            for device_id in self.enabled_devices:
                self._log(_('Analysing Bookends for Screen [%s]') % self.core.devices[device_id].device_configuration['screen_identifier'])
                playlists_to_transfer[device_id] = {}
                schedules_to_delete[device_id] = {}
                schedules_to_add[device_id] = []
                device = self.core.devices[device_id]
                scheduled_days = {}
                schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.device_uuid == device_id, db.Schedule.start_timestamp > start_of_today, or_(db.Schedule.device_schedule_id != None, db.Schedule.placeholder_type != None, db.Schedule.source_playlist_uuid != None))).order_by(db.Schedule.start_timestamp).all()
                for schedule in schedules:
                    if schedule.device_playlist_uuid in ignore_list and schedule.type in ('bookend_start', 'bookend_end'):
                        schedules_to_delete[device_id][schedule.start_timestamp] = {'uuid': schedule.uuid,
                         'device_playlist_uuid': schedule.device_playlist_uuid,
                         'type': schedule.type}
                    else:
                        schedule_dt = posix_to_local_datetime(schedule.start_timestamp, cfg.timezone())
                        date = schedule_dt if schedule_dt.hour > 4 else schedule_dt - timedelta(days=1)
                        date_key = str(date.date())
                        if not scheduled_days.has_key(date_key):
                            scheduled_days[date_key] = {}
                        if not scheduled_days[date_key].has_key('start'):
                            scheduled_days[date_key]['start'] = copy.copy(schedule.start_timestamp)

                schedules = sorted(schedules, key=lambda schedule: schedule.end_timestamp)
                schedules.reverse()
                for schedule in schedules:
                    if schedule.device_playlist_uuid in ignore_list:
                        if not schedule.type in ('bookend_start', 'bookend_end'):
                            schedule_dt = posix_to_local_datetime(schedule.start_timestamp, cfg.timezone())
                            date = schedule_dt if schedule_dt.hour > 4 else schedule_dt - timedelta(days=1)
                            date_key = str(date.date())
                            if not scheduled_days.has_key(date_key):
                                scheduled_days[date_key] = {}
                            scheduled_days[date_key]['end'] = scheduled_days[date_key].has_key('end') or copy.copy(schedule.end_timestamp)

                if start_active:
                    start_playlist = self.core.playlist_service.playlist(playlist_ids=[start_spl_uuid], device_ids=[self.core.get_lms_id()])[0][self.core.get_lms_id()][start_spl_uuid]['playlist']
                if end_active:
                    end_playlist = self.core.playlist_service.playlist(playlist_ids=[end_spl_uuid], device_ids=[self.core.get_lms_id()])[0][self.core.get_lms_id()][end_spl_uuid]['playlist']['duration_in_seconds']
                for day in scheduled_days:
                    if start_active:
                        start_schedule_time = self.__get_bookend_start_stamp(scheduled_days[day]['start'], start_spl_offset, start_playlist['duration_in_seconds'])
                        if schedules_to_delete[device_id].has_key(start_schedule_time) and schedules_to_delete[device_id][start_schedule_time]['device_playlist_uuid'] == start_spl_uuid and schedules_to_delete[device_id][start_schedule_time]['type'] == 'bookend_start':
                            schedules_to_delete[device_id].pop(start_schedule_time)
                        elif current_timestamp < start_schedule_time:
                            schedules_to_add[device_id].append({'playlist_uuid': start_spl_uuid,
                             'schedule_time': start_schedule_time,
                             'type': 'bookend_start'})
                            playlists_to_transfer[device_id][start_spl_uuid] = True
                    if end_active:
                        end_schedule_time = self.__get_bookend_start_stamp(scheduled_days[day]['end'], end_spl_offset)
                        if schedules_to_delete[device_id].has_key(end_schedule_time) and schedules_to_delete[device_id][end_schedule_time]['device_playlist_uuid'] == end_spl_uuid and schedules_to_delete[device_id][end_schedule_time]['type'] == 'bookend_end':
                            schedules_to_delete[device_id].pop(end_schedule_time)
                        elif current_timestamp < end_schedule_time:
                            schedules_to_add[device_id].append({'playlist_uuid': end_spl_uuid,
                             'schedule_time': end_schedule_time,
                             'type': 'bookend_end'})
                            playlists_to_transfer[device_id][end_spl_uuid] = True

            db.Session.remove()
        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.type.in_(['bookend_start', 'bookend_end']), db.Schedule.device_uuid.in_(self.enabled_devices))).all()
        for schedule in schedules:
            if not schedules_to_delete.has_key(schedule.device_uuid):
                schedules_to_delete[schedule.device_uuid] = {}
            if schedule.type == 'bookend_start' and (not start_active or schedule.device_playlist_uuid != start_spl_uuid):
                schedules_to_delete[schedule.device_uuid][schedule.start_timestamp] = {'uuid': schedule.uuid}
            if schedule.type == 'bookend_end' and (not end_active or schedule.device_playlist_uuid != end_spl_uuid):
                schedules_to_delete[schedule.device_uuid][schedule.start_timestamp] = {'uuid': schedule.uuid}

        transfer_action_map = {}
        self._log(_('Transferring Bookend Content'))
        for device_id in playlists_to_transfer:
            if not transfer_action_map.has_key(device_id):
                transfer_action_map[device_id] = []
            if len(playlists_to_transfer[device_id]) > 0:
                self._log(_('Transferring Bookend Playlists to: [%s]') % self.core.devices[device_id].device_configuration['screen_identifier'], log_stmt='Transferring bookend playlists to: [%s]' % self.core.devices[device_id].device_configuration['screen_identifier'], log=True, sub_msg=True)
                messages = self.core.playlist_service.transfer(self.core.get_lms_id(), [device_id], playlists_to_transfer[device_id], str(datetime.now()))
                for message in messages:
                    if message.has_key('playlist_id'):
                        if message.has_key('action_id'):
                            transfer_action_map[device_id].append(message['action_id'])

        for device_id in transfer_action_map:
            self._wait_for_multiple_actions(transfer_action_map[device_id], device_id, _('Transferring missing CPLs for Bookend Playlists'))

        deletion_action_map = {}
        self._log(_('Checking existing Bookends'))
        for device_id in schedules_to_delete:
            if not deletion_action_map.has_key(device_id):
                deletion_action_map[device_id] = []
            for schedule_to_delete in schedules_to_delete[device_id]:
                sched_obj = schedules_to_delete[device_id][schedule_to_delete]
                self._log(_('Deleting Bookend Schedule from [%s] : %s') % (self.core.devices[device_id].device_configuration['screen_identifier'], sched_obj['uuid']), log_stmt='Deleting Bookend schedule from [%s] : %s' % (self.core.devices[device_id].device_configuration['screen_identifier'], sched_obj['uuid']), log=True, sub_msg=True)
                deletion_action_map[device_id].append(self.core._action(self.core.devices[device_id].scheduling_delete_helper, sched_obj['uuid']))

        for device_id in deletion_action_map:
            self._wait_for_multiple_actions(deletion_action_map[device_id], device_id, _('Deleting Bookend Schedules'))

        addition_action_map = {}
        self._log(_('Scheduling new Bookends'))
        for device_id in schedules_to_add:
            if not addition_action_map.has_key(device_id):
                addition_action_map[device_id] = []
            if len(schedules_to_add[device_id]) > 0:
                self._log(_('Scheduling new Bookends on: [%s]') % self.core.devices[device_id].device_configuration['screen_identifier'], log_stmt='Scheduling new Bookends on: [%s]' % self.core.devices[device_id].device_configuration['screen_identifier'], log=True, sub_msg=True)
            for schedule_to_add in schedules_to_add[device_id]:
                schedule_object = {'start_time': schedule_to_add['schedule_time'],
                 'playlist_id': schedule_to_add['playlist_uuid'],
                 'type': schedule_to_add['type']}
                addition_action_map[device_id].append(self.core._action(self.core.devices[device_id].scheduling_add_helper, schedule_object))

        for device_id in addition_action_map:
            self._wait_for_multiple_actions(addition_action_map[device_id], device_id, _('Scheduling new Bookends'))

        return

    def _fill_in_missing_playlist_info(self):
        commit = False
        for schedule in db.Session.query(db.Schedule).filter(db.Schedule.display_name == _('Unknown Playlist')).all():
            try:
                schedule.display_name = self.core.devices[schedule.device_uuid].playlist_information[schedule.device_playlist_uuid]['playlist']['title']
                commit = True
            except:
                pass

        if commit:
            db.Session.commit()

    def _create_scheduled_playlist_title(self, original_playlist_title, show_attributes, play_date, screen_identifier, screen_title = '', manual_pattern = None, manual_date_format = None, pos_item = None):
        """
        Creates a playlist title suitable for a new playlist being scheduled - when given the original playlist title,
        a list of show attributes, playdate and screen_id.
        :param original_playlist_title: string, a playlists title (ea playlist on lms, for example)
        :param show_attributes: list of show attributes for this schedule
        :param play_date:
        :param screen_identifier: string, a screen identifier. E.g. '1'    (not uuid)
        :param screen_name: string, a screen name. (optional)
        :param manual_pattern: string, naming pattern override
        :param manual_date_format: string, date format pattern override
        :param pos_item: a db.POSItem type for this show. It is needed for weeks to work.
        :returns: string, name to use for new playlist
        """
        if not original_playlist_title:
            raise AssertionError
            three_d = '3D' in show_attributes
            hoh = 'HOH' in show_attributes
            hfr = 'HFR' in show_attributes
            regex = re.compile('{([a-zA-Z0-9][a-zA-Z0-9_]+)(?::([0-9]*))?}')
            if manual_pattern:
                naming_pattern = manual_pattern
            else:
                naming_pattern = cfg.core_templated_playlist_name.get()
            date_format = manual_date_format and manual_date_format
        else:
            date_format = cfg.core_templated_playlist_date_format.get()
        param_match = regex.findall(naming_pattern)
        ret = naming_pattern
        for param, length in param_match:
            lowerparam = param.lower()
            calculated_value = ''
            remove_placeholder = False
            if lowerparam == '3d':
                if three_d:
                    calculated_value = '3D'
                else:
                    remove_placeholder = True
            elif lowerparam == 'hoh':
                if hoh:
                    calculated_value = 'HOH'
                else:
                    remove_placeholder = True
            elif lowerparam == 'hfr':
                if hfr:
                    calculated_value = 'HFR'
                else:
                    remove_placeholder = True
            elif lowerparam == 'original_playlist_title':
                calculated_value = original_playlist_title
            elif lowerparam == 'scheduled_playback_date':
                calculated_value = play_date.strftime(date_format)
            elif lowerparam == 'generate_date':
                calculated_value = datetime.now().strftime(date_format)
            elif lowerparam == 'screen_identifier':
                calculated_value = screen_identifier
            elif lowerparam == 'screen_title':
                calculated_value = screen_title
            elif lowerparam == 'screenonly':
                calculated_value = 'C' + screen_identifier
            elif lowerparam == 'weekonly':
                if pos_item and pos_item.week_number:
                    if re.match('W\\d\\d', original_playlist_title) != None:
                        remove_placeholder = True
                    else:
                        calculated_value = 'W' + str(pos_item.week_number)
                else:
                    remove_placeholder = True
            elif lowerparam == 'weekscreen':
                if pos_item and pos_item.week_number:
                    if re.match('W\\d\\dC\\d\\d', original_playlist_title) != None:
                        remove_placeholder = True
                    else:
                        calculated_value = 'W' + str(pos_item.week_number) + 'C' + screen_identifier
                else:
                    remove_placeholder = True
            try:
                parsed_length = int(length)
            except ValueError as e:
                parsed_length = None

            if parsed_length:
                calculated_value = calculated_value[:parsed_length]
            if calculated_value:
                ret = re.sub('{' + param + '[:0-9]*}', calculated_value, ret)
            elif remove_placeholder:
                ret = re.sub('{' + param + '[:0-9]*}[._\\- :]?', '', ret)

        return ret

    def create_scheduled_playlist_title_testing(self, manual_pattern, manual_date_format):
        try:
            fakepositem = db.POSItem()
            fakepositem.week_number = self.core.pos_service.week_number()[0][0]
            test_title = self._create_scheduled_playlist_title('PLAYLISTNAME', ['3D', 'HFR', 'HOH'], datetime.now() + timedelta(hours=2), '6', 'Screen F', manual_pattern, manual_date_format, pos_item=fakepositem)
        except Exception as e:
            logging.error(str(e))
            return False

        return test_title
# okay decompyling ./core/tasks/schedule_sync.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:20 CST
