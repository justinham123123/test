# 2017.08.13 21:51:12 CST
# Embedded file name: build\bdist.win32\egg\serv\core\tasks\reconcile_logs.py
"""
Handles log reconciliation, i.e. the merging of
LiveLogs and LogFilePlayouts into Playbacks.
We already have Playback templates for each LiveLog,
thus we can merge LogFilePlayouts with Playbacks directly.

Naming convention in this module:
- Playback -> pldb.Playback       (former TMSPlaybackLog)
- SMPTE    -> pldb.LogFilePlayout (the parsed SMPTE log)

Query for debugging merging on a database level
(shows everything that should potentially loosely match):

    select (lfp.start_time-p.start) as start_diff, (lfp.end_time-p.end) as end_diff, lfp.id, p.uuid
    from log_file_playout as lfp
    join playback as p on lfp.cpl_uuid=p.cpl_uuid -- potential matches
    join log_file as lf on lfp.log_file_uuid=lf.uuid
    where p.device_ip_address = lf.device_ip_address
    and (lfp.start_time-p.start) < 7 and (lfp.start_time-p.start) > -120 -- start margin
    and (lfp.end_time-p.end) < 130 and (lfp.end_time-p.end) > -60 -- end margin
    order by p.start asc;
"""
import json
import logging
import itertools
from serv.configuration import cfg
import time
from serv.storage.database.playback import database as pldb
from sqlalchemy import func
from sqlalchemy.orm import joinedload
LEVEL_UNHACKABLE = -5
LEVEL_HACKED_END = -4
LEVEL_HACKED_START = -3
LEVEL_DUPLICATE = -2
LEVEL_UNKNOWN = -1
LEVEL_NO_MATCH = 0
LEVEL_BUGGY_MATCH = 1
LEVEL_BAGGY_MATCH = 2
LEVEL_LOOSE_MATCH = 3
LEVEL_TIGHT_MATCH = 4
CODE_TIGHT_MATCH = 0
CODE_INTERMISSION_MATCH = 1
CODE_LOOSE_MATCH = 8
CODE_SMPTE_NO_END_TIME = 101
CODE_SMPTE_NO_START_TIME = 102
CODE_EARLY_START = 201
CODE_LATE_START = 202
CODE_EARLY_END = 203
CODE_LATE_END = 204
CODE_BAGGY_MATCH = 205
CODE_START_AND_END_OFF = 300
CODE_PLAYBACK_CREATED_FROM_SMPTE = 301
LOOSE_MARGIN = 100

def _log(level, msg, *args, **kwargs):
    logging.getLogger('logmanager').log(level, msg, *args, **kwargs)


def _add_remaining_smptes(ip, remaining_smptes, cpl_metadata_getter, added_smptes):
    """
    Creates playbacks for each SMPTE log that could not be matched to a playback.
    We need to consider duplicates (from crypt/uncrypt logfiles), in two scenarios:
    e.g.1. Smpte from crypt log matched tightly to a playback, other from the uncrypt didn't because
      although it was the same playout, the log had a missing end time so was skipped by the reconciler
      since it already found a good match for that playback,
      this means one (tight match) will be in added_smptes, whilst the other buggy one is in remaining_smptes
      This is why we unfortunately have to check against all added smptes
    e.g.2. No playbacks were available so BOTH duplicates are in remaining_smptes,
      but the FIRST one is the best, thanks to smart ordering in the _handle_remaining_smptes fn
    In both cases, the second worse playout will be skipped, but marked as duplicate-matched
      to the playback matched to by its better twin.
    """

    def get_duplicate_playback_id(smpte):
        """ If duplicate, returns playback_uuid of match, else returns None """

        def is_match(t1, t2):
            return None not in (t1, t2) and abs(t1 - t2) < 900

        for added_smpte in added_smptes:
            if added_smpte.log_file.unencrypted != smpte.log_file.unencrypted and added_smpte.cpl_uuid == smpte.cpl_uuid and (is_match(added_smpte.start_time, smpte.start_time) or is_match(added_smpte.end_time, smpte.end_time)):
                return added_smpte.playback_uuid

        return None

    for smpte_log in remaining_smptes:
        dup = get_duplicate_playback_id(smpte_log)
        if dup:
            _mark_smpte_matched_to_playback(smpte_log, dup, LEVEL_DUPLICATE)
            continue
        meta = cpl_metadata_getter(smpte_log.cpl_uuid)
        content_kind = meta.get('content_kind')
        duration = meta.get('duration_in_seconds', 0)
        if smpte_log.end_time and smpte_log.start_time:
            duration = smpte_log.end_time - smpte_log.start_time
            error_level = LEVEL_NO_MATCH
        elif duration and not smpte_log.end_time:
            smpte_log.end_time = smpte_log.start_time + duration
            error_level = LEVEL_HACKED_END
        elif duration and not smpte_log.start_time:
            smpte_log.start_time = smpte_log.end_time - duration
            error_level = LEVEL_HACKED_START
        else:
            error_level = LEVEL_UNHACKABLE
        playback = pldb.Playback()
        playback.start = smpte_log.start_time
        playback.end = smpte_log.end_time
        playback.duration = duration
        playback.screen_identifier = smpte_log.log_file.screen_identifier
        playback.dnqualifier = smpte_log.log_file.dnqualifier
        playback.device_ip_address = ip
        playback.serial = smpte_log.log_file.serial
        playback.complex_identifier = cfg.complex_name()
        playback.feature_cpl_uuid = None
        playback.cpl_uuid = smpte_log.cpl_uuid
        playback.live_log_uuid = None
        playback.merge_error_code = CODE_PLAYBACK_CREATED_FROM_SMPTE
        if meta:
            playback.meta = json.dumps(meta)
        if content_kind:
            playback.content_kind = content_kind
        pldb.Session.add(playback)
        pldb.Session.flush()
        _mark_smpte_matched_to_playback(smpte_log, playback.uuid, error_level)
        added_smptes.append(smpte_log)

    return


def _combine_split_playbacks(playbacks, smpte_logs):
    """
    Combine the split playbacks (not yet implemented)
    This should be handled by live logs merging (when live logs are flushed)
    So this fn is likely to remain unneeded.
    """
    pass


def _find_and_handle_intermission_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes):
    """
    Run the intermission scan multiple times (as long as we found intermission match).
    This allows to match duplicate SMPTEs to intermissions. Since matched SMPTEs
    get removed from the list of SMPTEs to scan, successive intermission scans
    only see SMPTEs that have not been matched yet.
    """
    is_intermission_match = False
    is_intermission_match_current = True
    while is_intermission_match_current:
        is_intermission_match_current = _intermission_scan(playback, smptes_c_and_d_checked[:], smpte_logs, lm, added_smptes)
        is_intermission_match = is_intermission_match or is_intermission_match_current

    return is_intermission_match


def _intermission_scan(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes):
    """
    Find an intermission match if there is one. This routine also handles "slotins",
    which are SMPTE log entries that occur during the intermission
    (however, they are filtered out at the moment).
    
    The algorithm works in a greedy first-match manner, which means
    as soon as it finds a SMPTE that matches to the current
    playout transition state, it takes it. After every match,
    it tries to find a match for the next playout transition state, etc..
    """
    is_intermission_match = False
    potential_intermission = False
    intermission_step = 0
    state_changes = None
    matches = []
    if playback.live_log and playback.live_log.state_changes:
        state_changes = json.loads(playback.live_log.state_changes)
        state_changes = sorted(state_changes, key=lambda e: e['time'])

    def smpte_starts_before_playback_ends(smpte_log):
        return smpte_log.start_time is None or smpte_log.start_time - lm.ABSMIN_TIGHT_MARGIN < playback.end

    for smpte_log in itertools.takewhile(smpte_starts_before_playback_ends, smptes_c_and_d_checked):
        state_start_match, state_end_match = lm.get_tight_state_match(state_changes, intermission_step, smpte_log)
        if state_start_match:
            state_match = state_end_match
            if not state_match:
                continue
            start_match, end_match = lm.get_tight_match(playback, smpte_log)
            if state_match and start_match:
                potential_block_start = not end_match
                if state_match and not start_match:
                    potential_block_end = end_match
                    match = potential_block_start and _handle_intermission_match(playback, smpte_log, smpte_logs, added_smptes)
                    matches.append(match)
                    potential_intermission = True
                    intermission_step += 1
                    continue
                match = potential_intermission and potential_block_end and _handle_intermission_match(playback, smpte_log, smpte_logs, added_smptes)
                matches.append(match)
                is_intermission_match = True
                break
            match = potential_intermission and _handle_intermission_match(playback, smpte_log, smpte_logs, added_smptes)
            matches.append(match)
            intermission_step += 1
            continue

    if is_intermission_match:
        _add_intermission_matches(matches)
    return is_intermission_match


def _find_and_handle_tight_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes):
    """
    If a tight match is found, call the handle match method
    """
    is_tight_match_current = False
    is_tight_match_any = False

    def smpte_starts_before_playback_ends(smpte_log):
        return smpte_log.start_time is None or smpte_log.start_time - lm.ABSMIN_TIGHT_MARGIN < playback.end

    for smpte_log in itertools.takewhile(smpte_starts_before_playback_ends, smptes_c_and_d_checked):
        start_match, end_match = lm.get_tight_match(playback, smpte_log)
        if start_match:
            is_tight_match_current = end_match
            is_tight_match_any = is_tight_match_any or is_tight_match_current
            is_tight_match_current and _handle_match(playback, smpte_log, smpte_logs, LEVEL_TIGHT_MATCH, CODE_TIGHT_MATCH, added_smptes)
            is_tight_match_current = False

    return is_tight_match_any


def _find_and_handle_loose_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes):
    """
    If a loose match is found, call the handle match method
    """
    is_loose_match_current = False
    is_loose_match_any = False

    def smpte_starts_before_playback_ends(smpte_log):
        return smpte_log.start_time is None or smpte_log.start_time - lm.ABSMIN_LOOSE_MARGIN < playback.end

    for smpte_log in itertools.takewhile(smpte_starts_before_playback_ends, smptes_c_and_d_checked):
        is_loose_match_current = lm.get_loose_match(playback, smpte_log)
        if not is_loose_match_any:
            is_loose_match_any = is_loose_match_current
            is_loose_match_current and _handle_match(playback, smpte_log, smpte_logs, LEVEL_LOOSE_MATCH, CODE_LOOSE_MATCH, added_smptes)
            is_loose_match_current = False

    return is_loose_match_any


def _find_and_handle_baggy_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes):
    """
    If a loose match is found, call the handle match method
    """
    is_baggy_match_current = False
    is_baggy_match_any = False

    def smpte_starts_before_playback_ends(smpte_log):
        return smpte_log.start_time is None or smpte_log.start_time - lm.ABSMIN_BAGGY_MARGIN < playback.end

    for smpte_log in itertools.takewhile(smpte_starts_before_playback_ends, smptes_c_and_d_checked):
        is_baggy_match_current = lm.get_baggy_match(playback, smpte_log)
        if not is_baggy_match_any:
            is_baggy_match_any = is_baggy_match_current
            is_baggy_match_current and _handle_match(playback, smpte_log, smpte_logs, LEVEL_BAGGY_MATCH, CODE_BAGGY_MATCH, added_smptes)
            is_baggy_match_current = False

    return is_baggy_match_any


def _find_and_handle_buggy_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes):
    """
    If the corresponding SMPTE log is found but either the start time or end time is off,
    call the handle buggy match method
    """
    is_buggy_match_current = False
    is_buggy_match_any = False
    for smpte_log in smptes_c_and_d_checked:
        is_buggy_match_current, error_code = lm.get_buggy_match(playback, smpte_log)
        if not is_buggy_match_any:
            is_buggy_match_any = is_buggy_match_current
            is_buggy_match_current and _handle_buggy_match(playback, smpte_log, smpte_logs, error_code, added_smptes)
            is_buggy_match_current = False

    return is_buggy_match_any


def _get_potential_matches(playback, smpte_logs):
    """
    Returns the SMPTE log entries where
    the CPL uuids match to the playout.
    """
    return [ smpte for smpte in smpte_logs if smpte.cpl_uuid == playback.cpl_uuid ]


def _get_smpte_logs(ip):
    """
    Returns ALL unmerged SMPTE playouts
    """
    playouts = pldb.Session.query(pldb.LogFilePlayout).filter(pldb.LogFilePlayout.deleted == False, pldb.LogFilePlayout.playback_uuid == None, pldb.LogFile.device_ip_address == ip).join(pldb.LogFile, pldb.LogFile.uuid == pldb.LogFilePlayout.log_file_uuid).order_by(pldb.LogFilePlayout.start_time).options(joinedload(pldb.LogFilePlayout.log_file))
    return playouts.all()


def _get_playbacks(ip):
    """
    Returns ALL unmerged playbacks (i.e. created from LiveLogs)
    """
    playbacks = pldb.Session.query(pldb.Playback).filter(pldb.Playback.device_ip_address == ip, pldb.Playback.deleted == False, pldb.Playback.merge_error_code == None).order_by(pldb.Playback.start).options(joinedload(pldb.Playback.live_log))
    return playbacks.all()


def _mark_smpte_matched_to_playback(smpte_log, playback_uuid, confidence_level):
    smpte_log.playback_uuid = playback_uuid
    smpte_log.merge_confidence_level = confidence_level
    pldb.Session.add(smpte_log)


def _update_playback_record(playback, smpte_log, merge_code):
    playback.merge_error_code = max(playback.merge_error_code, merge_code)
    playback.set_modified()
    if playback.intermission_start is None and playback.merge_error_code < CODE_BAGGY_MATCH:
        if smpte_log.start_time:
            playback.start = smpte_log.start_time
        if smpte_log.end_time:
            playback.end = smpte_log.end_time
        playback.duration = playback.end - playback.start
    return


def _handle_match(playback, smpte_log, smpte_logs, confidence_level, match_level, added_smptes):
    """
    A match is found, so add the SMPTE Log file id to the corresponding TMS Log
    and add this to the db session.
    The smpte log is removed from the list to speed up processing.
    """
    _update_playback_record(playback, smpte_log, match_level)
    _mark_smpte_matched_to_playback(smpte_log, playback.uuid, confidence_level)
    smpte_logs.remove(smpte_log)
    added_smptes.append(smpte_log)
    _log(0, 'Found match: %s <-> %s (L: %d / E: %d)', playback.uuid, smpte_log.id, confidence_level, playback.merge_error_code)


def _handle_buggy_match(playback, smpte_log, smpte_logs, error_code, added_smptes):
    """
    Create a mapping and store the confidence level alongside
    the error code suggesting the kind of buggy match.
    """
    _update_playback_record(playback, smpte_log, error_code)
    _mark_smpte_matched_to_playback(smpte_log, playback.uuid, LEVEL_BUGGY_MATCH)
    smpte_logs.remove(smpte_log)
    added_smptes.append(smpte_log)
    _log(0, 'Found buggy match: %s <-> %s (L: %d / E: %d)', playback.uuid, smpte_log.id, LEVEL_BUGGY_MATCH, playback.merge_error_code)


def _handle_intermission_match(playback, smpte_log, smpte_logs, added_smptes):
    """
    This is called for every intermission match pair found.
    """
    smpte_logs.remove(smpte_log)
    added_smptes.append(smpte_log)
    return (smpte_log, playback)


def _add_intermission_matches(matches):
    """
    Add lfp to playout mapping for each intermission match found.
    This is called after a complete intermission scan.
    """
    for smpte_log, playback in matches:
        playback.merge_error_code = max(playback.merge_error_code, CODE_INTERMISSION_MATCH)
        playback.set_modified()
        _log(logging.DEBUG, 'Found intermission match: %s <-> %s', playback.uuid, smpte_log.id)
        _mark_smpte_matched_to_playback(smpte_log, playback.uuid, LEVEL_TIGHT_MATCH)


def _handle_remaining_smpte_logs(screen, smpte_logs, cpl_metadata_getter, added_smptes):
    """
    Creates new TMS logs from the SMPTE logs
    that had no equivalent playback.
    """
    remaining = len(smpte_logs)
    if remaining:
        offset = time.time()
        smpte_logs.sort(key=lambda s: s.start_time or offset + (s.end_time or offset))
        _add_remaining_smptes(screen, smpte_logs, cpl_metadata_getter, added_smptes)
        return remaining
    return 0


def _handle_no_match(playback, error_code):
    """
    Write a log message that no match was found.
    """
    playback.merge_error_code = error_code
    playback.set_modified()
    _log(0, 'No match for playback: %s', playback.uuid)


def reconcile_logs(ip, logmanager_cpl_metadata_getter, log_score = False):
    """
    The publicly available method that takes the start and end times
    as arguments and matches the TMS and SMPTE logs that fit in this time window.
    
    :param ip:                  (string) Device IP of the device to reconcile logs for.
    :param log_score:           (bool) Whether to compute and log reconciliation scores (precision/recall).
                                       This is time consuming, for debugging purposes only.
    
    :returns: (bool) Whether playbacks have been added
                      from remaining unmatched log file playouts.
    """
    lm = _LogMatcher()
    playbacks = _get_playbacks(ip)
    smpte_logs = _get_smpte_logs(ip)
    _combine_split_playbacks(playbacks, smpte_logs)
    added_smptes = []
    counts = {'tight': 0,
     'loose': 0,
     'intermission': 0,
     'buggy': 0,
     'baggy': 0,
     'no': 0}
    _log(logging.INFO, 'Attempting to merge %d SMPTE playouts with %d LiveLogs', len(smpte_logs), len(playbacks))
    for playback in playbacks:
        is_tight_match = False
        is_loose_match = False
        is_intermission_match = False
        is_buggy_match = False
        smptes_c_and_d_checked = _get_potential_matches(playback, smpte_logs)
        if not smptes_c_and_d_checked:
            _handle_no_match(playback, CODE_START_AND_END_OFF)
            counts['no'] += 1
            continue
        is_tight_match = _find_and_handle_tight_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes)
        if not is_tight_match:
            is_loose_match = _find_and_handle_loose_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes)
        if not is_tight_match:
            if not is_loose_match:
                is_intermission_match = _find_and_handle_intermission_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes)
            is_buggy_match = is_tight_match or is_loose_match or is_intermission_match or _find_and_handle_buggy_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes)
        counts['tight'] += int(is_tight_match)
        counts['loose'] += int(is_loose_match)
        counts['intermission'] += int(is_intermission_match)
        counts['buggy'] += int(is_buggy_match)

    for playback in itertools.ifilter(lambda p: p.merge_error_code is None, playbacks):
        smptes_c_and_d_checked = _get_potential_matches(playback, smpte_logs)
        is_baggy_match = _find_and_handle_baggy_match(playback, smptes_c_and_d_checked, smpte_logs, lm, added_smptes)
        counts['baggy'] += int(is_baggy_match)
        if not is_baggy_match:
            _handle_no_match(playback, CODE_START_AND_END_OFF)
            counts['no'] += 1

    counts['remaining_smpte'] = len(smpte_logs)
    _log(logging.DEBUG, 'Handling remaining SMPTEs')
    smptes_added = _handle_remaining_smpte_logs(ip, smpte_logs, logmanager_cpl_metadata_getter, added_smptes)
    _log(logging.INFO, 'Finished merging livelogs. Match stats: %s', counts)
    pldb.Session.commit()
    if log_score:
        score, base = compute_score()
        logging.info('========== RECONCILIATION SCORE ==========')
        logging.info('Precision:', score[0])
        logging.info('Recall:   ', score[1])
        logging.info('F1-Score: ', score[2])
        logging.info('TP:', base[0])
        logging.info('FP:', base[1])
        logging.info('FN:', base[2])
        logging.info('==========================================')
    return smptes_added > 0


def compute_score():
    """
    Computes precision, recall and F1-score between
    TMS playback logs and parsed SMPTE logs.
    :returns: (precision, recall, f1_score), (tp, fp, fn)
    """
    fp = pldb.Session.query(func.count(pldb.Playback.uuid)).outerjoin(pldb.LogFilePlayout, pldb.LogFilePlayout.playback_uuid == pldb.Playback.uuid).filter(pldb.LogFilePlayout.playback_uuid == None, pldb.Playback.deleted == False).scalar()
    tp = pldb.Session.query(func.count(pldb.Playback.uuid)).join(pldb.LogFilePlayout, pldb.LogFilePlayout.playback_uuid == pldb.Playback.uuid).filter(pldb.Playback.deleted == False).scalar()
    fn = pldb.Session.query(func.count(pldb.LogFilePlayout.id)).filter(pldb.LogFilePlayout.playback_uuid == None, pldb.LogFilePlayout.deleted == False).scalar()
    precision = tp / float(tp + fp) if tp + fp else 0
    recall = tp / float(tp + fn) if tp + fn else 0
    f1_score = 2 * tp / float(2 * tp + fp + fn) if tp + fp + fn else 0
    return ((precision, recall, f1_score), (tp, fp, fn))


class _LogMatcher(object):
    """
    Contains the parameters and methods for checking if a playback
    has a corresponding SMPTE log or not.
    """

    def __init__(self):
        self._set_margins()

    def _set_margins(self):
        self.TIGHT_MARGIN = 0.1
        self.LOOSE_MARGIN = 0.5
        self.BAGGY_MARGIN = 1.0
        self.ABSMIN_TIGHT_MARGIN = 5
        self.ABSMIN_LOOSE_MARGIN = LOOSE_MARGIN
        self.ABSMIN_BAGGY_MARGIN = 1800

    def get_tight_match(self, playback, smpte_log):
        """
        Call the check_match method with the tight params.
        """
        start_match, end_match = self._check_log_match(playback, smpte_log, self.TIGHT_MARGIN, self.ABSMIN_TIGHT_MARGIN)
        return (start_match, end_match)

    def get_loose_match(self, playback, smpte_log):
        """
        Call the check_match method with the loose params.
        """
        start_match, end_match = self._check_log_match(playback, smpte_log, self.LOOSE_MARGIN, self.ABSMIN_LOOSE_MARGIN)
        return start_match and end_match

    def get_baggy_match(self, playback, smpte_log):
        """
        Call the check_match method with the baggy params.
        """
        start_match, end_match = self._check_log_match(playback, smpte_log, self.BAGGY_MARGIN, self.ABSMIN_BAGGY_MARGIN)
        return start_match or end_match

    def get_buggy_match(self, playback, smpte_log):
        """
        This method first checks if there is a corresponding SMPTE log but with
        erroneous data and then returns the corresponding error message along with
        whether it found a match.
        """
        error_code = self._get_error_code(playback, smpte_log)
        if error_code <= CODE_LOOSE_MATCH:
            _log(logging.WARN, 'Expected buggy match, got %s for %s <-> %s', error_code, playback.uuid, smpte_log.id)
        is_match = error_code != CODE_START_AND_END_OFF
        return (is_match, error_code)

    def get_tight_state_match(self, playback_states, step, smpte_log):
        """
        Checks if the playback state start and end times
        do tightly match to the SMPTE start and end times.
        """
        return self._check_state_match(playback_states, step, smpte_log, self.TIGHT_MARGIN, self.ABSMIN_TIGHT_MARGIN)

    def _check_log_match(self, playback, smpte_log, margin, absmin_margin):
        """
        Checks whether the SMPTE Log fits within the error margins and
        returns a two-tuple of booleans. The first one indicates whether the
        start time fits the criteria and second one if end time fits.
        The margins are provided as method parameters.
        """
        return self._check_match((playback.start, playback.end), (smpte_log.start_time, smpte_log.end_time), margin, absmin_margin)

    def _check_state_match(self, playback_states, step, smpte_log, margin, abs_margin):
        """
        Checks if there is a tight match between SMPTE start/stop
        and TMS log state transitions start/stop times.
        This is used to handle intermissions.
        """
        if not playback_states or len(playback_states) <= 2 * step + 1:
            return (False, False)
        state_start = playback_states[2 * step]
        state_end = playback_states[2 * step + 1]
        state_start_time = state_start['time']
        state_end_time = state_end['time']
        state_start_type = state_start['state']
        state_end_type = state_end['state']
        if state_start_type == 'start' and state_end_type in ('pause', 'stop'):
            return self._check_match((state_start_time, state_end_time), (smpte_log.start_time, smpte_log.end_time), margin, abs_margin)
        else:
            return (False, False)

    def _check_match(self, playback_times, smpte_times, margin, absmin_margin):
        """
        Checks whether the SMPTE Log fits within the error margins and
        returns a two-tuple of booleans. The first one indicates whether the
        start time fits the criteria and second one if end time fits.
        The margins are provided as method parameters.
        """

        def is_match(smpte, playback, margin):
            if None not in (smpte, playback):
                return abs(float(smpte) - float(playback)) < margin
            else:
                return False

        playback_start, playback_end = playback_times
        smpte_start, smpte_end = smpte_times
        duration = smpte_end - smpte_start if smpte_start and smpte_end else playback_end - playback_start
        abs_margin = max(duration * margin, absmin_margin)
        start_time_matches = is_match(smpte_start, playback_start, abs_margin)
        end_time_matches = is_match(smpte_end, playback_end, abs_margin)
        return (start_time_matches, end_time_matches)

    def _get_error_code(self, playback, smpte_log):
        """
        Find the correct error code for a buggy match.
        """
        playback_st = playback.start
        playback_et = playback.end
        smpte_st = smpte_log.start_time
        smpte_et = smpte_log.end_time
        start_match, end_match = self._check_log_match(playback, smpte_log, self.LOOSE_MARGIN, self.ABSMIN_LOOSE_MARGIN)
        if start_match and end_match:
            return CODE_LOOSE_MATCH
        else:
            if start_match:
                if smpte_et is None:
                    return CODE_SMPTE_NO_END_TIME
                elif playback_et <= smpte_et - self.ABSMIN_LOOSE_MARGIN:
                    return CODE_EARLY_END
                else:
                    return CODE_LATE_END
            elif end_match:
                if smpte_st is None:
                    return CODE_SMPTE_NO_START_TIME
                elif playback_st <= smpte_st - self.ABSMIN_LOOSE_MARGIN:
                    return CODE_EARLY_START
                else:
                    return CODE_LATE_START
            else:
                return CODE_START_AND_END_OFF
            return
# okay decompyling ./core/tasks/reconcile_logs.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:13 CST
