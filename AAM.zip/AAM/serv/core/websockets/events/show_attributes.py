# 2017.08.13 21:51:27 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\show_attributes.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.services.configuration_service import ConfigurationService

class ShowAttributeHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(ShowAttributeHandler, self).__init__(*args, **kwargs)
        self.configuration_service = ConfigurationService(cherrypy.core)
        self.on('show_attribute_information', self.show_attribute_information)
        self.on('show_attribute_save', self.show_attribute_save)
        self.on('show_attribute_delete', self.show_attribute_delete)
        self.on('exsam_save', self.exsam_save)
        self.on('exsam_unmatch', self.exsam_unmatch)
        self.on('exsam_match', self.exsam_match)

    def show_attribute_information(self, task):
        show_attributes = task['task_data']
        self.configuration_service.synchronize_show_attributes(show_attributes, remove=True)

    def show_attribute_save(self, task):
        show_attribute = task['task_data']
        self.configuration_service.synchronize_show_attributes([show_attribute], remove=False)

    def show_attribute_delete(self, task):
        show_attribute_uuids = task['task_data']
        for sa_uuid in show_attribute_uuids:
            self.configuration_service.delete_show_attribute(sa_uuid)

    def exsam_save(self, task):
        exsam = task['task_data']
        self.configuration_service.save_external_show_attribute_maps([exsam], ccpush=False)

    def exsam_unmatch(self, task):
        ex_sam_uuids = task['task_data']
        for ex_sam_uuid in ex_sam_uuids:
            self.configuration_service.unmatch_show_attribute(ex_sam_uuid)

    def exsam_match(self, task):
        ex_sam_uuids = task['task_data']['ex_sam_uuids']
        show_attribute_uuid = task['task_data']['show_attribute_uuid']
        for ex_sam_uuid in ex_sam_uuids:
            self.configuration_service.match_show_attribute({'show_attr_uuid': show_attribute_uuid,
             'uuid': ex_sam_uuid})
# okay decompyling ./core/websockets/events/show_attributes.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:28 CST
