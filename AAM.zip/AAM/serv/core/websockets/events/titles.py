# 2017.08.13 21:51:28 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\titles.py
import cherrypy
from serv.storage.database.primary import database as db
from serv.core.websockets.handler import EventHandler
from serv.core.services.title_service import TitleService

class TitlesHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(TitlesHandler, self).__init__(*args, **kwargs)
        self.title_service = TitleService(cherrypy.core)
        self.on('title_push', self.title_save)
        self.on('title_save', self.title_save, result_name='title_save_messages')
        self.on('title_edit', self.title_edit)
        self.on('title_delete', self.title_delete)
        self.on('match_external_titles', self.match_external_titles)
        self.on('unmatch_external_title', self.unmatch_external_title)

    def title_save(self, task):
        titles = task['task_data']['titles']
        messages = []
        for title in titles:
            try:
                title_uuid, message = self.title_service.save(title, from_producer=True)
                messages.append({'type': message['type'],
                 'message': message['message'],
                 'uuid': title['uuid']})
            except Exception as e:
                messages.append({'type': 'error',
                 'message': str(e),
                 'uuid': title['uuid']})

        return messages

    def title_edit(self, task):
        title = task['task_data']
        db_title = db.Session.query(db.Title).get(title['uuid'])
        if db_title:
            self.title_service.save(title, from_producer=True)

    def title_delete(self, task):
        title_uuid = task['task_data']
        self.title_service.delete([title_uuid])

    def match_external_titles(self, task):
        self.title_service.match_external_titles(**task['task_data'])

    def unmatch_external_title(self, task):
        self.title_service.unmatch_external_title(**task['task_data'])
# okay decompyling ./core/websockets/events/titles.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:28 CST
