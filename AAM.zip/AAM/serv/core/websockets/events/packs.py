# 2017.08.13 21:51:26 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\packs.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.services.pack_service import PackService

class PacksHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(PacksHandler, self).__init__(*args, **kwargs)
        self.pack_service = PackService(cherrypy.core)
        self.on('pack_save', self.pack_save, result_name='pack_save_messages')
        self.on('pack_delete', self.pack_delete, result_name='pack_delete_messages')

    def pack_save(self, task):
        packs = task['task_data']['packs']
        return self.pack_service.save(packs)

    def pack_delete(self, task):
        pack_uuids = task['task_data']['pack_uuids']
        return self.pack_service.delete(pack_uuids)
# okay decompyling ./core/websockets/events/packs.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:26 CST
