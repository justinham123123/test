# 2017.08.13 21:51:27 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\playlists.py
import cherrypy
from serv.core.websockets.com.protocols import RequestProtocol
from serv.core.websockets.handler import EventHandler
from serv.core.services.playlist_service import PlaylistService

class PlaylistHandler(EventHandler, RequestProtocol):

    def __init__(self, *args, **kwargs):
        super(PlaylistHandler, self).__init__(*args, **kwargs)
        self.playlist_service = PlaylistService(cherrypy.core)
        self.on('detailed_playlist_request', self.detailed_playlist_request)

    def detailed_playlist_request(self, request):
        """
        Handles requests for playlists from Circuit Core.
        """
        request_uuid = request['request_uuid']
        device_uuid = request['data']['device_uuid']
        playlist_uuid = request['data']['playlist_uuid']
        playlist = self.playlist_service.get_playlist_detailed(device_uuid, playlist_uuid)
        self.push_response(request_uuid, {'playlist': playlist})
# okay decompyling ./core/websockets/events/playlists.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:27 CST
