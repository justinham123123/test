# 2017.08.13 21:51:25 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\manager.py
import logging
import cherrypy
from sqlalchemy.exc import IntegrityError
from serv.storage.database.primary import database as db
from serv.core.websockets.dispatch import Dispatcher
from serv.core.websockets.events.packs import PacksHandler
from serv.core.websockets.events.titles import TitlesHandler
from serv.core.websockets.events.templates import TemplateHandler
from serv.core.websockets.events.placeholders import PlaceholdersHandler
from serv.core.websockets.events.macropacks import MacropacksHandler
from serv.core.websockets.events.show_attributes import ShowAttributeHandler
from serv.core.websockets.events.content import ContentHandler
from serv.core.websockets.events.monitoring import MonitoringHandler
from serv.core.websockets.events.log_files import LogFileHandler
from serv.core.websockets.events.device import DeviceHandler
from serv.core.websockets.events.camera import CameraHandler
from serv.core.websockets.events.playback import PlaybackHandler
from serv.core.websockets.events.playlists import PlaylistHandler
from serv.core.websockets.events.projection import ProjectionHandler
from serv.core.websockets.events.scheduling import SchedulingHandler
from serv.core.websockets.events.time import TimeHandler

class EventManager(Dispatcher, PacksHandler, TitlesHandler, PlaceholdersHandler, MacropacksHandler, ShowAttributeHandler, TemplateHandler, ContentHandler, MonitoringHandler, LogFileHandler, DeviceHandler, CameraHandler, PlaybackHandler, PlaylistHandler, ProjectionHandler, SchedulingHandler, TimeHandler):

    def __init__(self, *args, **kwargs):
        super(EventManager, self).__init__(*args, **kwargs)
        self.create_queue('tasks', self.handle_task)

    def dispatch_task(self, event, task):
        """task:
        {
            'task_uuid': '...',
            'task_data': {...}
        }
        """
        self.dispatch('tasks', {'event': event,
         'task': task})

    @db.close_session
    def handle_task(self, job):
        event = job['event']
        task = job['task']
        task_uuid = task['task_uuid']
        results = {}
        success = True
        try:
            logging.debug('Handling task "%s" for event "%s"', task_uuid, event)
            results = self.trigger(event, task)
        except IntegrityError:
            db.Session.rollback()
            logging.error('Integrity error when handling queue event, rollback.', exc_info=True)
            success = False
        except Exception:
            logging.error('Error handling queue event.', exc_info=True)
            success = False
        finally:
            logging.debug('Task "%s" done for event "%s"', task_uuid, event)
            cherrypy.engine.publish('ccpush', 'task_done', {'task_uuid': task_uuid,
             'event': event,
             'success': success,
             'results': results})

    def push_response(self, request_uuid, response_data):
        logging.debug('Pushing response to request %s', request_uuid)
        cherrypy.engine.publish('ccpush', 'request_response', {'request_uuid': request_uuid,
         'data': response_data})
# okay decompyling ./core/websockets/events/manager.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:25 CST
