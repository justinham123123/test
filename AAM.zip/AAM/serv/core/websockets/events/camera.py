# 2017.08.13 21:51:23 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\camera.py
import cherrypy
import base64
from serv.core.websockets.com.protocols import RequestProtocol
from serv.core.websockets.handler import EventHandler
from serv.core.services.camera_service import CameraService

class CameraHandler(EventHandler, RequestProtocol):

    def __init__(self, *args, **kwargs):
        super(CameraHandler, self).__init__(*args, **kwargs)
        self.camera_service = CameraService(cherrypy.core)
        self.on('camera_image_request', self.camera_image_request)

    def camera_image_request(self, request):
        """
        Handles requests for camera images from Circuit Core.
        """
        request_uuid = request['request_uuid']
        device_uuid = request['data']['device_uuid']
        image = self.camera_service.get_image(device_uuid)
        self.push_response(request_uuid, {'image': base64.b64encode(image),
         'device_uuid': device_uuid})
# okay decompyling ./core/websockets/events/camera.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:23 CST
