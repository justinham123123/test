# 2017.08.13 21:51:28 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\time.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.websockets.com.protocols import RequestProtocol

class TimeHandler(EventHandler, RequestProtocol):

    def __init__(self, *args, **kwargs):
        super(TimeHandler, self).__init__(*args, **kwargs)
        self.on('time_request', self.time_request)

    def time_request(self, request):
        """
        Handles request for the current time on the TMs for Circuit Core.
        """
        request_uuid = request['request_uuid']
        time_info = cherrypy.core.get_time()['data']
        self.push_response(request_uuid, time_info)
# okay decompyling ./core/websockets/events/time.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:28 CST
