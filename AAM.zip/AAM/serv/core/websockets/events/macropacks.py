# 2017.08.13 21:51:25 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\macropacks.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.services.macropack_service import MacroPackService

class MacropacksHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(MacropacksHandler, self).__init__(*args, **kwargs)
        self.macropack_service = MacroPackService(cherrypy.core)
        self.on('macropack_placeholder_save', self.macropack_placeholder_save)
        self.on('macropack_placeholder_delete', self.macropack_placeholder_delete)
        self.on('macropack_save', self.macropack_save)
        self.on('macropack_delete', self.macropack_delete)

    def macropack_placeholder_save(self, task):
        placeholders = task['task_data']['macropack_placeholders']
        for placeholder in placeholders:
            self.macropack_service.save_macro_placeholder(placeholder['name'])

    def macropack_placeholder_delete(self, task):
        placeholder_uuids = task['task_data']['macropack_placeholder_uuids']
        self.macropack_service.delete_macro_placeholders(placeholder_uuids)

    def macropack_save(self, task):
        macropacks = task['task_data']['macropacks']
        self.macropack_service.save(macropacks)

    def macropack_delete(self, task):
        macropack_uuids = task['task_data']['macropack_uuids']
        self.macropack_service.delete(macropack_uuids, hard=True)
# okay decompyling ./core/websockets/events/macropacks.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:25 CST
