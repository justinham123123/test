# 2017.08.13 21:51:26 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\playback.py
import cherrypy
from serv.core.websockets.com.protocols import RequestProtocol
from serv.core.websockets.handler import EventHandler
from serv.core.services.playback_service import PlaybackService

class PlaybackHandler(EventHandler, RequestProtocol):

    def __init__(self, *args, **kwargs):
        super(PlaybackHandler, self).__init__(*args, **kwargs)
        self.playback_service = PlaybackService(cherrypy.core)
        self.on('playback_state_request', self.playback_state_request)

    def playback_state_request(self, request):
        """
        Handles request from the current playback state of a list of devices
        from Circuit Core.
        """
        request_uuid = request['request_uuid']
        device_ids = request['data'].get('device_ids', [])
        device_playback_status, device_errors = self.playback_service.state(device_ids)
        self.push_response(request_uuid, {'device_playback_status': device_playback_status,
         'device_errors': device_errors})
# okay decompyling ./core/websockets/events/playback.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:26 CST
