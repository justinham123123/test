# 2017.08.13 21:51:24 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\content.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.services.content_service import ContentService

class ContentHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(ContentHandler, self).__init__(*args, **kwargs)
        self.content_service = ContentService(cherrypy.core)
        self.on('content_delete', self.content_delete)
        self.on('content_transfer', self.content_transfer)
        self.on('content_edit', self.content_edit)
        self.on('kdm_push', self.kdm_push)

    def content_delete(self, task):
        """
        Handles the `content_delete` event from Circuit Core.
        
        Sent when a cpl is targetted for deletion on Circuit Core through the ui.
        """
        cpl_uuid = task['task_data']['cpl_uuid']
        device_ids = task['task_data']['device_ids']
        self.content_service.delete([cpl_uuid], device_ids)

    def content_transfer(self, task):
        """
        Handles the `content_transfer` event from Circuit Core.
        
        Sent when a cpl is targetted for transfer on Circuit Core.
        """
        cpl_uuid = task['task_data']['cpl_uuid']
        device_ids = task['task_data']['device_ids']
        self.content_service.transfer('Auto', device_ids, [cpl_uuid])

    def content_edit(self, task):
        """
        Handles `content_edit` event from Circuit Core.
        
        Sent when cpl metadata is edited on Circuit Core. See the handle_PUT
        method in serv/circuit_core/rest/content.py
        """
        metadata = task['task_data']['metadata']
        self.content_service.save(metadata)

    def kdm_push(self, task):
        """
        Handles `kdm_push` event from Circuit Core.
        
        Sent when a new KDM is added on Circuit Core. See the add_key
        method in serv/core/service/content_service.py
        """
        key = task['task_data']['key']
        device_id = task['task_data'].get('device_id')
        add_to_lms = task['task_data'].get('add_to_lms', True)
        source = task['task_data'].get('source', 'Producer')
        kdm_id, messages = self.content_service.add_key(key, device_id, add_to_lms, source)
        errors = [ msg for msg in messages if msg['type'] == 'error' ]
        if errors:
            cherrypy.engine.publish('ccpush', 'kdm_error', {'kdm_uuid': kdm_id,
             'message': errors[0]['message']})
        else:
            cherrypy.engine.publish('ccpush', 'kdm_dispatch', {'kdm_uuid': kdm_id})
# okay decompyling ./core/websockets/events/content.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:24 CST
