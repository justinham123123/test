# 2017.08.13 21:51:32 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\shared\reference.py
import weakref

class WeakMethod(object):
    """
    Implements weakref functionality for bound and unbound methods.
    """

    def __init__(self, method):
        self._source = unicode(method)
        if method.__self__ is None:
            self.instance = None
        else:
            self.instance = weakref.proxy(method.__self__)
        self.function = weakref.proxy(method.__func__)
        return

    @property
    def __name__(self):
        return self.function.__name__

    @property
    def __self__(self):
        return self.instance

    @property
    def __func__(self):
        return self.function

    def __repr__(self):
        return u'WeakMethod: ' + self._source

    def __call__(self, *args, **kwargs):
        """
        :raises ReferenceError: When the referenced object does not exist anymore
        """
        if self.instance:
            return self.function(self.instance, *args, **kwargs)
        else:
            return self.function(*args, **kwargs)
# okay decompyling ./core/websockets/shared/reference.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:32 CST
