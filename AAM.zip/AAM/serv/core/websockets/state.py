# 2017.08.13 21:51:32 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\state.py
import logging
from threading import Lock

class TransitionError(Exception):
    pass


class StateMachine(object):
    """
    Thread-safe state machine for maintaining shared state.
    """

    def __init__(self, initial_state):
        self.lock = Lock()
        self.state = initial_state

    def __eq__(self, state):
        with self.lock:
            return self.state == state

    def any(self, *states):
        """
        Check whether current is equal to any of the states listed.
        :param states: List of arguments of type STATE (int).
        """
        with self.lock:
            return self.state in states

    def _transition(self, table, t):
        try:
            with self.lock:
                raise self.state in table or AssertionError
                logging.info('State transition %s --[%s]--> %s', self.state, t, table.get(self.state))
                self.state = table[self.state]
        except AssertionError:
            logging.error('State transition %s --[%s]--> %s', self.state, t, table.get(self.state))
            raise TransitionError(t)
# okay decompyling ./core/websockets/state.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:32 CST
