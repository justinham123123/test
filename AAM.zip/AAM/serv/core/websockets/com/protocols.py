# 2017.08.13 21:51:22 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\com\protocols.py


class RequestProtocol(object):

    def push_response(self, request_uuid, response_data):
        raise NotImplementedError('required')
# okay decompyling ./core/websockets/com/protocols.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:22 CST
