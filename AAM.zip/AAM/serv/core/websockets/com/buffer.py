# 2017.08.13 21:51:21 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\com\buffer.py
import time
import logging
from threading import RLock
from cherrypy.process.plugins import BackgroundTask
from serv.core.websockets.shared.reference import WeakMethod

class Full(Exception):
    pass


class Buffer(list):
    """
    Buffer that behaves like a list with a maximum size.
    """

    def __init__(self, size):
        self.size = size

    def append(self, item):
        if self.full():
            raise Full('Buffer of size %s is full' % self.size)
        super(Buffer, self).append(item)

    def empty(self):
        return len(self) == 0

    def full(self):
        return len(self) == self.size

    def clear(self):
        del self[:]


class MessageBuffer(object):
    """
    Message buffer that manages separate buffers of configurable size
    for each event. Flush intervals can also be configured
    on a per-event basis.
    
    Buffers are flushed either when they are full or
    when the flush interval is expired. Interval-based flushes
    are performed by a background timer thread.
    
    Message buffers are thread-safe.
    """
    TIMER_INTERVAL = 5
    DEFAULT_INTERVAL = 5
    DEFAULT_SIZE = 10

    def __init__(self, flush_handler, config, enabled = True):
        """
        Initialize a message buffer.
        
        :param method flush_handler: Callback to call on flush.
            Must provide interface `flush_handler(event, data_list, buffered=True|False)`.
        :param dict config: Event configuration for the buffers::
            {
                'schedule_error_list': {'size': 50, 'interval': 10},
                'automation_update':   {'size': 50, 'interval': 10}
            }
        :param bool enabled: If set to `False` disables buffering for all events.
        """
        self.flush_handler = WeakMethod(flush_handler)
        self.config = config
        self.enabled = enabled
        self.buffers = {}
        self.flush_times = {}
        self.lock = RLock()
        if enabled:
            self._init(config)

    def _init(self, config):
        min_interval = self.TIMER_INTERVAL
        for event, settings in config.iteritems():
            max_size = settings.get('size', self.DEFAULT_SIZE)
            self.buffers[event] = Buffer(max_size)
            config_interval = settings.get('interval', self.DEFAULT_INTERVAL)
            min_interval = min(min_interval, config_interval)

        if min_interval < self.TIMER_INTERVAL:
            logging.warning('Message buffer flush interval set to %d seconds (default is %d).', min_interval, self.TIMER_INTERVAL)
        self.flush_timer = BackgroundTask(max(min_interval, 1), self.flush)

    def _interval(self, event):
        return self.config[event].get('interval', self.DEFAULT_INTERVAL)

    def _last_flush(self, event):
        return self.flush_times.get(event, 0)

    def _time_to_flush(self, event):
        now = time.time()
        interval = self._interval(event)
        last_flush = self._last_flush(event)
        return now - last_flush > interval

    def _set_flush_time(self, event):
        self.flush_times[event] = time.time()

    def start_flush_timer(self):
        self.flush_timer.start()

    def stop_flush_timer(self):
        self.flush_timer.cancel()

    def __contains__(self, event):
        """
        Test whether the buffer for the event exists.
        Only buffers for configured events are created.
        
        :param str event: Name of the buffered event.
        
        :returns: `True` if the event is buffered.
        """
        with self.lock:
            return event in self.buffers

    def size(self, event):
        """
        Get the current size of a buffer for given event name.
        Raises a KeyError when the buffer has not been configured
        for the event.
        
        :param str event: Name of the buffered event.
        
        :raises: KeyError
        """
        with self.lock:
            return len(self.buffers[event])

    def clear(self):
        """
        Clear all buffers if they contain items.
        """
        with self.lock:
            for event, buf in self.buffers.iteritems():
                if buf:
                    logging.debug('Clearing buffer "%s" (contains %d items)', event, len(buf))
                    buf.clear()

    def add(self, event, data):
        """
        Add data item to the buffer for given event.
        Buffers should always be tested if they contain the event
        before data is added (i.e. using `event in buffer`).
        Raises a KeyError when the buffer has not been configured
        for the event.
        
        :param str event: Name of the event to buffer data for.
        :param dict data: Actual data to buffer. Can also be a list
                          which will get flattened when flushed,
                          but this should be avoided if possible.
        
        :raises: KeyError
        """
        with self.lock:
            if self.buffers[event].full():
                self.flush(event, force=True)
            self.buffers[event].append(data)

    def flush(self, event = None, force = False):
        """
        Flush all buffers if their grace period has expired.
        Fires the `flush_handler` given with the constructor.
        Raises a KeyError when the buffer has not been configured
        for the event.
        
        :param str event:   Name of the buffer to flush. If `None`, all
                            non-empty buffers will be flushed if the flush
                            interval is expired (see `force` to force a flush).
        :param bool force:  Whether to force flushing non-empty
                            buffers regardless of interval.
        
        :raises: KeyError
        """
        with self.lock:
            if event:
                buffers = [(event, self.buffers[event])]
            else:
                buffers = self.buffers.iteritems()
            for event, buf in buffers:
                if buf and (self._time_to_flush(event) or force):
                    logging.debug('Flushing %d items for event "%s"', len(buf), event)
                    if isinstance(buf[0], list):
                        data_list = [ l for sublist in buf for l in sublist ]
                    else:
                        data_list = list(buf)
                    self.flush_handler(event, data_list, buffered=True)
                    self._set_flush_time(event)
                    buf.clear()
# okay decompyling ./core/websockets/com/buffer.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:21 CST
