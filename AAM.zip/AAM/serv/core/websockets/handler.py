# 2017.08.13 21:51:28 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\handler.py
import logging
from threading import RLock
from serv.core.websockets.shared.reference import WeakMethod

def check_version(version, required_version):
    """Simple version check handler."""
    return version >= required_version


class EventHandler(object):
    """
    Thread-safe event handler class that implements
    the delegation/event listener pattern.
    """

    def __init__(self):
        self.__trigger_lock = RLock()
        self.__event_map = {}
        self.class_name = self.__class__.__name__
        self.debug = False

    def handles_event(self, event):
        with self.__trigger_lock:
            return event in self.__event_map

    def enable_event_debugging(self, enabled = True):
        self.debug = enabled

    def on(self, event, callback, version = None, result_name = None, debug = False):
        """
        Register an event listener/handler.
        Only a weak reference to the callback is stored.
        
        :param version: Minimum required version for this handler.
                        If None, applies to tms version where no other handler
                        with a version requirement matches (fallback handler).
        """
        with self.__trigger_lock:
            if event not in self.__event_map:
                self.__event_map[event] = {'result_name': result_name,
                 'handlers': [{'debug': debug,
                               'version': version,
                               'callback': WeakMethod(callback)}]}
            else:
                self.__event_map[event]['handlers'].append({'debug': debug,
                 'version': version,
                 'callback': WeakMethod(callback)})
            self.__event_map[event]['handlers'].sort(key=lambda d: d['version'], reverse=True)

    def trigger(self, event, data, version = None):
        """
        Trigger an event with data as parameter.
        
        :returns: Dict of results for each trigger executed.
                  Keys are the result names specified when registering
                  a handler for an event, e.g. with
                  `self.on('pack_save', self.handler_func, result_name='thename')`,
                  results will have {'thename': ...}. Only results from
                  handlers with a result name specified are returned.
        """
        with self.__trigger_lock:
            results = {}
            handlers = []
            result_name = None
            if event in self.__event_map:
                handlers = self.__event_map[event]['handlers']
                result_name = self.__event_map[event]['result_name']
            if handlers:
                for handler in self.__matching_handlers(handlers, version):
                    try:
                        result = self.__trigger(event, handler, data, version)
                        if result_name is not None:
                            results[result_name] = result
                    except TypeError:
                        logging.error(u'[%s] Handler for event "%s" does not support interface.', self.class_name, event, exc_info=True)
                    except ReferenceError:
                        try:
                            self.__event_map[event]['handlers'].remove(handler)
                        except ValueError:
                            pass

            else:
                logging.info(u'[%s] Unknown event: "%s"', self.class_name, event)
            return results
        return

    def __trigger(self, event, handler, data, version):
        if handler['debug']:
            import json
            logging.info(u'Triggering event "%s" (handler: %s / tms: %s) with data:\n%s', event, handler['version'], version, json.dumps(data, indent=2))
        elif self.debug:
            logging.info(u'Triggering event "%s" (handler: %s / tms: %s)', event, handler['version'], version)
        return handler['callback'](data)

    def __matching_handlers(self, handlers, version):
        """
        Generator that yields all handlers that should get fired.
        """
        handle_map = {}

        def handled(handler):
            """Check if a handler has been handled by object source"""
            required_version = handler['version']
            callback = handler['callback']
            source = id(callback.__self__)
            return source in handle_map and handle_map[source] != required_version

        def handle(handler):
            """Mark a handler as handled by object source"""
            required_version = handler['version']
            callback = handler['callback']
            source = id(callback.__self__)
            handle_map[source] = required_version

        for handler in handlers:
            required_version = handler['version']
            if required_version == '*':
                yield handler
            elif check_version(version, required_version) and not handled(handler):
                handle(handler)
                yield handler
            elif not required_version and not handled(handler):
                yield handler
# okay decompyling ./core/websockets/handler.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:29 CST
