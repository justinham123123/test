# 2017.08.13 21:51:29 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\log.py
import logging
import os
import time
import transaction
import ZODB, ZODB.FileStorage
from Queue import Queue, Empty
from threading import Lock, Event, Thread
from ZODB.POSException import ConflictError
from persistent import Persistent
from zc.queue import CompositeQueue
from serv.configuration import cfg

class RetentionLimitReached(Exception):
    pass


class FlushError(Exception):
    pass


class LogEntry(Persistent):
    """
    Item that gets persisted in the log.
    """
    seq_lock = Lock()
    seq_next = 0

    def __init__(self, data):
        self.seq = None
        self.timestamp = time.time()
        self.data = data
        with self.seq_lock:
            self.seq = LogEntry.seq_next
            LogEntry.seq_next += 1
        return


class Log(object):
    """
    Provides a FIFO queue interface to a persistent log.
    Different ZODB-backed storages can be used to persist queue state.
    Supports multi threaded use of transactions via thread-local connections.
    """

    def __init__(self, storage, retention = None, batch_size = 100):
        self.storage = storage
        self.retention = retention
        self.batch_size = batch_size
        self.con = None
        self.root = None
        self.log = None
        self.flushing = False
        return

    def open(self):
        """Open new connection to log."""
        self.con, self.root = self.storage.open()
        self.log = self.root.log

    def close(self):
        """Close connection to log."""
        self.con.close()

    def empty(self):
        """Returns True if log is empty."""
        return not bool(self.log)

    def size(self):
        return len(self.log)

    def put(self, data):
        """
        Put data to end of log (FIFO).
        :param data: Pickle-able python object.
        """
        if self.retention:
            self._check_retention()
        entry = LogEntry(data)
        self.log.put(entry)
        return entry.seq

    def _check_retention(self):
        """
        Check whether retention limit was reached.
        :throws: RetentionLimitReached
        """
        try:
            now = time.time()
            head = self.log[0]
            if abs(now - head.timestamp) > self.retention:
                raise RetentionLimitReached()
        except IndexError:
            pass

    def pop(self):
        """
        Pop entry from head of log.
        :returns: LogEntry
        """
        return self.log.pull()

    def sync(self):
        """Manually synchronize the connection."""
        self.con.sync()

    def commit(self):
        """Commit active transaction."""
        transaction.commit()

    def rollback(self):
        """Abort active transaction."""
        transaction.abort()

    def flush(self):
        """Flush the log until empty."""
        while True:
            try:
                self._batched_flush()
            except ConflictError:
                pass
            else:
                break

    def _batched_flush(self):
        try:
            i = 0
            while self.pop():
                i += 1
                if i % self.batch_size == 0:
                    self.commit()

        except IndexError:
            self.commit()


class LogStorage(object):
    """
    Storage proxy wrapping ZODB database and storage backends.
    Deals with setting up and tearing down databases.
    """

    def __init__(self, name, backend = 'fs'):
        self.name = name
        self.storage = self._get_backend(backend, name)
        self.db = ZODB.DB(self.storage)

    def _get_backend(self, backend_type, name):
        if backend_type == 'fs':
            path = os.path.join(cfg.data_dir(), 'message_log', '{0}.db'.format(name))
            return ZODB.FileStorage.FileStorage(path)
        elif backend_type == 'mem':
            return None
        else:
            raise ValueError('Backend "%s" not supported' % backend_type)
            return None

    def pack(self):
        """Run database pack."""
        self.db.pack()

    def setup(self, block_size = 500):
        """Initialize log data structures (wipes persisted data)."""
        con, root = self.open()
        root.log = CompositeQueue(block_size)
        transaction.commit()

    def open(self):
        """
        Open a connection to the database.
        :returns: (connection, root)
        """
        con = self.db.open()
        root = con.root()
        return (con, root)

    def close(self):
        """Close database connection."""
        self.db.close()

    def drop(self):
        """Delete all storage files."""
        try:
            self.storage.cleanup()
        except AttributeError:
            pass


class LogWorker(Thread):
    """
    Base class for workers interacting with the persistent log.
    """

    def __init__(self, storage, retention = None):
        super(LogWorker, self).__init__(name=self.__class__.__name__)
        self.log = Log(storage, retention=retention)
        self.quit = Event()

    def run(self):
        self.log.open()
        try:
            while not self.quit.is_set():
                self._run()

        except:
            logging.exception('Fatal')
            self.log.rollback()
            raise
        finally:
            self.log.close()
            logging.info('Exit')

    def stop(self):
        self.quit.set()


class LogWriter(LogWorker):
    """
    Writes items from a queue acting as buffer to the persistent log.
    """

    def __init__(self, *args, **kwargs):
        super(LogWriter, self).__init__(*args, **kwargs)
        self.queue = Queue(self.log.batch_size)
        self.flushing = Event()

    def put(self, data):
        self.queue.put(data)

    def dirty(self):
        """Returns True if there is data waiting to be persisted."""
        return not self.queue.empty() or self.flushing.is_set()

    def _run(self):
        self.flushing.set()
        buffer = self._read_buffered()
        if buffer:
            self._write_retry(buffer)
        else:
            self.flushing.clear()
            time.sleep(1)

    def _write_retry(self, buffer):
        retry = True
        while retry:
            try:
                for data in buffer:
                    self.log.put(data)

                self.log.commit()
                self.flushing.clear()
                logging.debug('Wrote %d messages to log', len(buffer))
                retry = False
            except ConflictError:
                self.log.rollback()
                self.flushing.clear()
                time.sleep(0.1)
            except RetentionLimitReached:
                retry = False
                self.log.rollback()
                self.flushing.clear()
                self._retention_reached()

    def _read_buffered(self):
        buffer = []
        try:
            for i in xrange(self.log.batch_size):
                buffer.append(self.queue.get_nowait())

        except Empty:
            pass
        finally:
            return buffer

    def _retention_reached(self):
        return NotImplemented


class LogReader(LogWorker):
    """
    Reads items from the persistent log as soon as they are available.
    Subclass to implement the behaviour on read.
    """

    def __init__(self, *args, **kwargs):
        super(LogReader, self).__init__(*args, **kwargs)
        self.flushing = Event()

    def dirty(self):
        return self.flushing.is_set()

    def can_flush(self):
        """Override to implement check if log can be flushed."""
        raise NotImplementedError('required')

    def flush(self, buffer):
        """
        Override to implement log flush behaviour.
        Use FlushError to cause retry and enforce at-least-once semantics.
        """
        raise NotImplementedError('required')

    def _run(self):
        """
        Implements "at-least-once" semantics for flushing messages from the log.
        Flushing is batched for reasons of I/O performance.
        """
        if not self.can_flush():
            time.sleep(0.1)
            return
        buffer = self._fetch_buffered()
        if buffer:
            try:
                self.flushing.set()
                self.flush(buffer)
                self.log.commit()
            except (ConflictError, FlushError):
                logging.warning('Flush failed, retrying')
                self.log.rollback()
            finally:
                self.flushing.clear()

        else:
            self.log.rollback()
            time.sleep(1)

    def _fetch_buffered(self, bufsize = 100):
        buffer = []
        try:
            for i in xrange(bufsize):
                entry = self.log.pop()
                buffer.append(entry.data)

        except IndexError:
            pass
        finally:
            return buffer
# okay decompyling ./core/websockets/log.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:30 CST
