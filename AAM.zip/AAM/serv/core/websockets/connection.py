# 2017.08.13 21:51:22 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\connection.py
import sys
import time
import logging
from threading import Thread, RLock, Event
from serv.core.websockets.state import TransitionError
from serv.core.websockets.state import StateMachine
from serv.core.websockets.client import Client
from serv.configuration import cfg

class ConnectionState(StateMachine):
    INITIALIZED = 0
    CONNECT = 1
    CONNECTED1 = 2
    APPROVED = 3
    PHASE2 = 4
    CONTINUE = 5
    CONNECTED2 = 6
    FLUSH = 7
    CONTINUED = 8

    def __init__(self):
        super(ConnectionState, self).__init__(ConnectionState.INITIALIZED)

    def connect(self):
        self._transition({ConnectionState.INITIALIZED: ConnectionState.CONNECT,
         ConnectionState.CONNECT: ConnectionState.CONNECT,
         ConnectionState.CONTINUE: ConnectionState.CONTINUE}, 'connect')

    def opened(self):
        self._transition({ConnectionState.CONNECT: ConnectionState.CONNECTED1,
         ConnectionState.CONTINUE: ConnectionState.CONNECTED2}, 'opened')

    def approved(self):
        self._transition({ConnectionState.CONNECTED1: ConnectionState.APPROVED,
         ConnectionState.CONNECTED2: ConnectionState.FLUSH}, 'approved')

    def denied(self):
        self._transition({ConnectionState.CONNECTED1: ConnectionState.CONNECT,
         ConnectionState.CONNECTED2: ConnectionState.CONTINUE}, 'denied')

    def config_synced(self):
        self._transition({ConnectionState.APPROVED: ConnectionState.PHASE2}, 'config_synced')

    def closed(self):
        self._transition({ConnectionState.APPROVED: ConnectionState.CONNECT,
         ConnectionState.CONNECTED1: ConnectionState.CONNECT,
         ConnectionState.PHASE2: ConnectionState.CONTINUE,
         ConnectionState.CONNECTED2: ConnectionState.CONTINUE,
         ConnectionState.FLUSH: ConnectionState.CONTINUE,
         ConnectionState.CONTINUED: ConnectionState.CONTINUE}, 'closed')

    def flushed(self):
        self._transition({ConnectionState.FLUSH: ConnectionState.CONTINUED}, 'flushed')

    def reset(self):
        self._transition({ConnectionState.CONTINUE: ConnectionState.CONNECT,
         ConnectionState.CONNECTED2: ConnectionState.CONNECTED1,
         ConnectionState.CONTINUED: ConnectionState.PHASE2}, 'reset')


class Connection(Thread):
    """
    Wraps websocket instances and manages all interaction with the socket.
    Never attempt to use the socket directly outside of the Connection class.
    """

    def __init__(self, url, transport):
        super(Connection, self).__init__(name='Connection')
        self.lock = RLock()
        self.state = ConnectionState()
        self.quit = Event()
        self.url = url
        self.transport = transport
        self.client = None
        self.failures = 0
        return

    def stop(self):
        self.quit.set()

    def run(self):
        try:
            while not self.quit.is_set():
                try:
                    if self._can_connect():
                        logging.info('Connecting to %s', self.url)
                        self._connect()
                    else:
                        logging.info('Cannot connect yet [%s]', self.url)
                        time.sleep(1)
                except Exception as e:
                    self.cleanup()
                    self._delay_reconnect()
                    logging.error('Error during connect, retrying [%s]', unicode(e))
                finally:
                    wait = min(self.failures, 60)
                    logging.info('Waiting %d seconds until reconnect', wait)
                    time.sleep(wait)

        except:
            logging.exception('Fatal')
            raise
        finally:
            logging.info('Exit')

    def _can_connect(self):
        return self.state.any(ConnectionState.INITIALIZED, ConnectionState.CONNECT, ConnectionState.CONTINUE)

    def _connect(self):
        client = Client(self, self.url, certfile=cfg.wsw_certificate_path(), keyfile=cfg.wsw_private_key_path(), ca_certs=cfg.wsw_ca_certificate_path())
        with self.lock:
            self.client = client
        self.state.connect()
        client.connect()

    def _delay_reconnect(self):
        with self.lock:
            if self.failures < sys.maxint // 2:
                self.failures = self.failures * 2 or 1

    def _reset_reconnect_delay(self):
        with self.lock:
            self.failures = 1

    def push_all(self, messages):
        """
        Push all messages in list to circuit core if possible.
        Discards messages in case of a missing socket.
        Make sure you reset the connection state on error.
        :param list message: List of message bytes to send
        """
        with self.lock:
            if self.client:
                for message in messages:
                    logging.debug('Sending message [%s]', self.url)
                    self.client.send(message)

            else:
                logging.debug('Discarding messages, no socket [%s]', self.url)

    def push(self, message):
        """
        Push message to circuit core if possible.
        Discards messages in case of a missing socket.
        Make sure you reset the connection state on error.
        :param str message: Message bytes to send
        """
        with self.lock:
            if self.client:
                logging.debug('Sending message [%s]', self.url)
                self.client.send(message)
            else:
                logging.debug('Discarding message, no socket [%s]', self.url)

    def connected(self):
        """Whether the connect is connected to circuit core."""
        return self.state.any(ConnectionState.CONNECTED1, ConnectionState.APPROVED, ConnectionState.PHASE2, ConnectionState.CONNECTED2, ConnectionState.FLUSH, ConnectionState.CONTINUED)

    def approved(self):
        """
        Whether the client has been approved by circuit core.
        Includes both first and continued states.
        """
        return self.state.any(ConnectionState.APPROVED, ConnectionState.PHASE2, ConnectionState.FLUSH, ConnectionState.CONTINUED)

    def first_connected(self):
        """
        Whether the connection is in 'first connected' state.
        -> No disconnect after connect or did not reach phase 2 previously.
        """
        return self.state.any(ConnectionState.CONNECTED1, ConnectionState.APPROVED, ConnectionState.PHASE2)

    def continued(self):
        """
        Whether the connection is in 'continued' state.
        -> reconnected after previously reaching phase 2.
        """
        return self.state.any(ConnectionState.CONNECTED2, ConnectionState.FLUSH, ConnectionState.CONTINUED)

    def close(self):
        """Initiate closing handshake."""
        with self.lock:
            self.client.close(reason='Shutting down')

    def terminate(self):
        """Terminate socket."""
        with self.lock:
            self.client.terminate()

    def cleanup(self):
        """Release socket resources."""
        with self.lock:
            s = self.client
            if s:
                s.close_connection()
                if s.stream:
                    s.stream._cleanup()
            self.client = None
        return

    def state_approved(self):
        try:
            self._reset_reconnect_delay()
            self.state.approved()
        except TransitionError:
            pass

    def state_denied(self):
        try:
            self.state.denied()
            self.close()
        except TransitionError:
            pass

    def state_config_synced(self):
        self.state.config_synced()

    def socket_opened(self):
        logging.info('Connection to circuit core established [%s]', self.url)
        self.state.opened()
        self.transport.connection_opened()

    def socket_closed(self, code, reason):
        logging.info('Connection to circuit core lost: %s (%s) [%s]', reason, code, self.url)
        self._delay_reconnect()
        self.state.closed()
        self.transport.connection_closed(code, reason)

    def socket_ponged(self, pong):
        self.transport.connection_ponged(pong)

    def socket_received_message(self, message):
        logging.debug('Received message [%s]', self.url)
        self.transport.connection_received_message(message)
# okay decompyling ./core/websockets/connection.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:23 CST
