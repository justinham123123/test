# 2017.08.13 21:48:54 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\content\watchfolder\watchfolder.py
from collections import deque
from datetime import datetime
from time import time
import logging
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration import cfg
from serv.core.devices.content.logical_drive.logical_drive import LogicalDrive
from serv.lib.utilities.helper_methods import watchfolder_log, info_needs_updating
from serv.lib.utilities.action import SyncAction
import cherrypy

class Watchfolder(LogicalDrive):
    """
    Watchfolder access and control
    """

    def __init__(self, id, device_info):
        super(Watchfolder, self).__init__(id, device_info)
        self.show_expired_kdms = True
        self.auto_delete = True
        self.core = cherrypy.core
        self.target_id = self.core.get_lms_id()
        self.target = None
        self.auto_ingest_sync_status = {'last_updated': None}
        self.watch_log = deque(maxlen=20)
        self.action_log = deque(maxlen=20)
        return

    def auto_ingest_sync(self):
        self._append_to_watch_log('syncstart', _('Scanning Started'))
        self.device_information.set('scanning', True)
        self.target = self.acquire_target()
        if not self.target:
            message = 'Could not acquire target %s' % self.target_id
            logging.warning(message)
            return (False, _('Error automatically ingesting CPL'))
        cpl_uuids = cherrypy.core.contents.get_contents_dict(device_uuid=self.device_id).keys()
        if cpl_uuids and self.core.devices[self.target_id].device_configuration['enabled']:
            own_validation = self.get_content_validation_information(cpl_uuids)['content_validation_dict']
            target_validation = self.target.get_content_validation_information(cpl_uuids)['content_validation_dict']
            target_transfer_state = self.core.content_service.transfer_status([self.target_id], active_only=False)[0][self.target_id]
            target_transfers = target_transfer_state['queue'] + target_transfer_state['active'].values() + target_transfer_state['completed'].values()
            for path in self.dcps:
                for cpl in self.dcps[path]['cpls']:
                    if own_validation.has_key(cpl['uuid']):
                        cpl_uuid = cpl['uuid']
                        missing_asset_uuids = cpl.get('missing_assets', [])
                        validation_info = own_validation[cpl_uuid]
                        if cpl_uuid in target_validation and target_validation[cpl_uuid]['validation_code'] == 0:
                            if self.dcp_complete(cpl_uuid, target_validation):
                                self._append_to_watch_log('delete', _('Ingested CPL removed from watchfolder %s') % cpl_uuid)
                                self._log_action('delete', validation_info['ingest_path'], cpl_uuid, 'CPL')
                                success, message = self.content_delete(cpl_uuid)
                                self.reset_sync()
                            continue
                        missing_assets = False
                        if validation_info['validation_code'] == 1:
                            target_assets = self.target.content_store.get('assets', {})
                            for missing_asset_uuid in missing_asset_uuids:
                                if not target_assets.has_key(missing_asset_uuid) or target_assets[missing_asset_uuid].get('status') != 100:
                                    missing_assets = True
                                    break

                        if validation_info['validation_code'] == 2 or not validation_info['ingest_path'] or missing_assets:
                            self._append_to_watch_log('noaction', _('CPL is corrupt or missing assets %s') % cpl_uuid)
                            continue
                        transfer_exists = False
                        for target_transfer in target_transfers:
                            if target_transfer['content_id'] == cpl_uuid and target_transfer['source'] == self.device_configuration['id']:
                                self._append_to_watch_log('noaction', _('Ingest has been already attempted for CPL %s') % cpl_uuid)
                                transfer_exists = True
                                break

                        if transfer_exists:
                            continue
                        if cpl_uuid not in target_validation or target_validation[cpl_uuid]['validation_code'] in (-1, 1, 2):
                            self._append_to_watch_log('ingest', _('Ingest started for CPL %s') % cpl_uuid)
                            self._log_action('ingest', validation_info['ingest_path'], cpl_uuid, 'CPL')
                            self.core.content_service.transfer(self.device_configuration['id'], [self.target_id], [cpl_uuid])

        self._append_to_watch_log('syncend', _('Scanning Complete'))
        self.auto_ingest_sync_status['last_updated'] = time()
        return (True, 'Done')

    def dcp_complete(self, cpl_uuid, target_validation):
        in_dcp = None
        for key, dcp in self.dcps.items():
            for cpl in dcp['cpls']:
                if cpl['uuid'] == cpl_uuid:
                    in_dcp = key

        dcp_complete = True
        if in_dcp:
            for cpl in self.dcps[in_dcp]['cpls']:
                if not target_validation.has_key(cpl['uuid']) or target_validation[cpl['uuid']]['validation_code'] != 0:
                    dcp_complete = False
                    break

        return dcp_complete

    def _append_to_watch_log(self, action, message):
        if action not in ('syncstart', 'syncend'):
            watchfolder_log(message)
        now = datetime.now()
        self.watch_log.append({'time': str(now.date()) + ' ' + str(now.strftime('%H:%M:%S')),
         'action': action,
         'message': message})

    def _log_action(self, action, path, uuid, action_type):
        now = datetime.now()
        self.action_log.append({'time': str(now.date()) + ' ' + str(now.strftime('%H:%M:%S')),
         'action': action,
         'path': path,
         'uuid': uuid,
         'action_type': action_type})

    def acquire_target(self):
        if self.target_id in self.core.devices and not self.core.devices[self.target_id].sync_status['sync_active']:
            return self.core.devices[self.target_id]
        else:
            return False

    def monitor_device_state(self, *args, **kwargs):
        super(Watchfolder, self).monitor_device_state(*args, **kwargs)
        if info_needs_updating(self.auto_ingest_sync_status, cfg.sync_watchfolder_scan_frequency.get()):
            self._execute_action(SyncAction(self.auto_ingest_sync))
# okay decompyling ./core/devices/content/watchfolder/watchfolder.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:55 CST
