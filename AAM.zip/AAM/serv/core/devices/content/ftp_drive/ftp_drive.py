# 2017.08.13 21:48:50 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\content\ftp_drive\ftp_drive.py
import logging
from serv.lib.dcinema.dcp.file_handlers import FTPHandler
from serv.core.devices.base.mount_point import MountPoint
from serv.configuration.constants import MOUNT_POINT_SCAN_DEPTH
from serv.lib.utilities.action import SyncAction
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
TIMEOUT = 30

def check_response(response_dict):
    if response_dict['response'] == 1:
        return False
    if response_dict.has_key('error'):
        return False
    if response_dict.has_key('error_message'):
        return False
    return True


VALIDATION_CONVERSION = {0: 0,
 1: 2,
 2: 1,
 3: 2}

class FTPDrive(MountPoint):
    """
    FTP drive access and control
    """

    def retrieve_all_contents(self):
        handler = FTPHandler(host=self.device_configuration['ftp_ip'], port=self.device_configuration['ftp_port'], user=self.device_configuration['ftp_username'], passwd=self.device_configuration['ftp_password'], encoding=self.device_configuration.get('encoding', 'utf-8'))
        return self._get_all_digital_cinema_content(handler, self.device_configuration['path'] or '')

    def get_thumbprint(self):
        """
        Here we just add up the "last modified" timestamps of all files to a depth of 8 dirs
        """
        handler = FTPHandler(host=self.device_configuration['ftp_ip'], port=self.device_configuration['ftp_port'], user=self.device_configuration['ftp_username'], passwd=self.device_configuration['ftp_password'], encoding=self.device_configuration.get('encoding', 'utf-8'))
        if self.device_configuration['path'] != None:
            path = self.device_configuration['path']
        else:
            path = '/'
        thumbprint = 0
        max_depth = MOUNT_POINT_SCAN_DEPTH
        for dirpath, dirnames, filenames in handler.walk(path):
            if dirpath.count('/') >= max_depth:
                del dirnames[:]
            for f in filenames:
                try:
                    last_mod_time = handler.last_modified(handler.join(dirpath, f))
                except UnicodeEncodeError:
                    logging.error('Unicode Encode Error while calculating thumbprint. Skipping file.')

                if last_mod_time != None:
                    thumbprint = thumbprint + long(last_mod_time)

        return thumbprint

    def get_device_status(self):
        output = {'error_messages': []}
        return output

    def get_device_information(self):
        output = {'error_messages': []}
        return output

    def content_clear_transfer_history(self):
        """
        Clears the transfer history on the device
        
        Returns a dictionary containing
                    response - the response code sent by the server
        """
        output = {'error_messages': []}
        return (True, output)

    def get_content_video_encoding(self, content_uuid):
        return {'video_encoding': 'UNKNOWN',
         'error_messages': []}

    def transfer_methods(self):
        return ['ftp']

    def get_transfer_ids(self):
        """
        This returns all the transfer ids in the syste,
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                            ]
                        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'transfers': [],
         'error_messages': []}
        return output

    def get_transfer_info(self, transfer_ids):
        """
        This returns all information for specified transfers
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                                state          STRING      - 'initializing', 'queued on server', 'active', 'paused', 'cancelled', 'success', 'failure'
                                description    STRING      - description of the transfer, ie content title
                                type           STRING      - cpl, kdm... 
                                cpl_uuid       STRING      - transferring cpl
                                source         STRING      - source this can be an ipaddress or a description (ie local disk)
                                progress       INTEGER     - % transfer complete
                                message        STRING      - a message elaborating on the transfer_state ('ingest was paused at 15:00')
                            ]
                        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'transfers': [],
         'error_messages': []}
        return output

    def rescan_content(self):
        self.sync()
        return (True, _('FTP folder has been scanned'))

    def test_content_connection(self):
        test_handler = None
        try:
            test_handler = FTPHandler(host=self.device_configuration['ftp_ip'], port=self.device_configuration['ftp_port'], user=self.device_configuration['ftp_username'], passwd=self.device_configuration['ftp_password'], encoding=self.device_configuration.get('encoding', 'utf-8'))
            if self.device_status['error_messages'].has_key('test_content_connection'):
                del self.device_status['error_messages']['test_content_connection']
            return (True, _('OK'))
        except Exception as ex:
            message = str(ex)
            self.device_status['error_messages']['test_content_connection'] = message
            return (False, message)
        finally:
            if test_handler:
                test_handler.close_connection()

        return

    def monitor_device_state(self, *args, **kwargs):
        super(MountPoint, self).monitor_device_state(*args, **kwargs)
        if not self.initial_sync_complete or cfg.auto_sync_ftp_folders() and helper_methods.info_needs_updating(self.drive_storage, cfg.sync_auto_sync_ftp_validity()):
            self._execute_action(SyncAction(self.sync))

    def content_cancel_transfer(self, transfer_id):
        """
        Cancels a transfer on a device.
        
        @param transfer_id  STRING  - transfer identifier
        """
        raise NotImplementedError

    def content_delete(self, content_id):
        """
        Deletes the specified content from the device
        @param content_id              UUID - content identifiers
        """
        raise NotImplementedError

    def content_transfer(self, connection_details, description, cpl_uuid):
        """
        Ingests content onto the device.
        
        @param connection_details      DICT - Must include 'type' key along with type-specific details
                                              e.g. ftp ip, path, user, pass or local path
        @param description             STRING - Human readable desc for the transfer i.e. content_title_text
        @param cpl_uuid                STRING - UUID of CPL to be transferred
        """
        raise NotImplementedError
# okay decompyling ./core/devices/content/ftp_drive/ftp_drive.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:51 CST
