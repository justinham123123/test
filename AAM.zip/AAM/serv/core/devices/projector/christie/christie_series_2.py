# 2017.08.13 21:49:07 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\christie\christie_series_2.py
"""
Implementation of Core2 projection API for Christie series 2 projectors
"""
from serv.core.devices.projector.christie.christie_series_1 import ChristieSeries1
from christie_utils import execute_ascii_command, CMD_POWER, CMD_DOWSER, CMD_LAMP_LIMIT
PROJECTOR_TYPES = ['CP2210',
 'CP2220',
 'CP2230',
 'CP4220',
 'CP4230']

class ChristieSeries2(ChristieSeries1):
    """
    An implementation of Projection for Christie series 2 projectors
    """

    def __init__(self, id, device_info, snmp_manager):
        super(ChristieSeries2, self).__init__(id, device_info, snmp_manager)

    def get_device_status(self):
        """
        Returns the status of the device
        """
        output = {'current_time': None,
         'error_messages': []}
        return output

    def get_device_information(self):
        """
        Returns information regarding the device
        """
        output = {'type': None,
         'error_messages': []}
        projector_type = self._execute_snmp('1.3.6.1.4.1.25766.1.12.1.1.2.1.0', version=2, throw=True)
        if projector_type:
            output['type'] = projector_type
            output['model'] = projector_type
        return output

    def get_projector_status(self):
        """
        Gets the available status values for the projector
        @return 
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        self.response['error_messages'] = []
        lamp_maximum = self._execute_ascii(CMD_LAMP_LIMIT)
        if lamp_maximum:
            try:
                int_lamp_maximum = int(lamp_maximum)
                self.response['api_lamp_life_maximum'] = int_lamp_maximum
            except ValueError:
                pass

        return self.response

    def open_dowser(self):
        """
        Open the dowser
        """
        execute_ascii_command(CMD_DOWSER, self.device_configuration['ip'], self.device_configuration['port'], arg='0')

    def close_dowser(self):
        """
        Close the dowser
        """
        execute_ascii_command(CMD_DOWSER, self.device_configuration['ip'], self.device_configuration['port'], arg='1')

    def power_on(self):
        """
        Turn the projector on
        """
        execute_ascii_command(CMD_POWER, self.device_configuration['ip'], self.device_configuration['port'], arg='1')

    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        execute_ascii_command(CMD_POWER, self.device_configuration['ip'], self.device_configuration['port'], arg='0')

    def lamp_on(self):
        """
        Strike the lamp
        """
        raise NotImplementedError

    def lamp_off(self):
        """
        Turn the lamp off
        """
        raise NotImplementedError
# okay decompyling ./core/devices/projector/christie/christie_series_2.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:07 CST
