# 2017.08.13 21:49:13 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\sony\sony_projector.py
"""
Sony projector functionality implementation
"""
from serv.lib.utilities import xml_utils
from serv.core.devices.base.projection import Projection
from serv.core.devices.sms.sony.sony import SonyDevice
PROJECTOR_STATUS = {'STANDBY': 'Standby',
 'LAMP_OFF': 'Power On',
 'ON': 'Lamp On'}
DOWSER_STATUS = {'true': 'Closed',
 'false': 'Open'}

class SonyProjector(SonyDevice, Projection):

    def __init__(self, id, device_info):
        super(SonyProjector, self).__init__(id, device_info)
        self.response = {}
        self.response['error_messages'] = []

    def get_device_information(self):
        """
        Returns information regarding the device
        """
        output = {}
        dom = self._http_request('config/device/attributes?device=PRJ')
        output['type'] = xml_utils.get_element_value(dom, 'Model')
        output['model'] = xml_utils.get_element_value(dom, 'Model')
        output['firmware_version'] = xml_utils.get_element_value(dom, 'FirmwareVersion')
        return output

    def get_projector_status(self):
        """
        Gets the available status values for the projector
        @return 
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        output = {'error_messages': []}
        dom = self._http_request('command/projector/maintenance/info/get')
        lamp_status = dom.getElementsByTagName('LampStatus')[0]
        output['lamps'] = []
        lamp_on = xml_utils.get_element_value(lamp_status, 'LampOn') == 'true'
        output['lamp_status'] = 'Lamp On' if lamp_on else 'Lamp Off'
        dom = self._http_request('command/projector/maintenance/lamp/info/get')
        lamp_life_status = dom.getElementsByTagName('PrjLampInformation')[0]
        lamp1 = {}
        lamp1['life_used'] = int(xml_utils.get_element_value(lamp_life_status, 'LampHours'))
        lamp1['life_maximum'] = None
        lamp1['life_remaining'] = None
        lamp1['current'] = None
        lamp1['type'] = None
        output['lamps'].append(lamp1)
        dom = self._http_request('status/sms/powerstatus')
        for power_status in dom.getElementsByTagName('PowerStatus'):
            if xml_utils.get_element_value(power_status, 'Device') == 'PRJ':
                projector_status = xml_utils.get_element_value(power_status, 'State')
                output['projector_status'] = PROJECTOR_STATUS.get(projector_status, None)
                break
        else:
            output['projector_status'] = None

        output['dowser_status'] = None
        dom = self._http_request('config/projector/screen/config/get')
        douser_close = xml_utils.get_element_value(dom, 'MasterMuting')
        output['dowser_status'] = DOWSER_STATUS.get(douser_close)
        return output

    def open_dowser(self):
        """
        Open the dowser
        """
        self._http_request('command/projector/shutter/set?state=off')

    def close_dowser(self):
        """
        Close the dowser
        """
        self._http_request('command/projector/shutter/set?state=on')

    def lamp_on(self):
        """
        Strike the lamp
        """
        self._http_request('command/projector/power/set?state=on')

    def lamp_off(self):
        """
        Turn the lamp off
        """
        self._http_request('command/projector/power/set?lamp=off')

    def power_on(self):
        """
        Turn the projector on
        """
        self._http_request('command/projector/power/set?state=on')

    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        self._http_request('command/projector/power/set?state=standby')
# okay decompyling ./core/devices/projector/sony/sony_projector.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:13 CST
