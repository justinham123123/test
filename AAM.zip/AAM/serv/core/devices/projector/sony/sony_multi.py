# 2017.08.13 21:49:12 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\sony\sony_multi.py
from serv.lib.utilities import xml_utils
from serv.core.devices.projector.sony.sony_projector import SonyProjector, PROJECTOR_STATUS, DOWSER_STATUS
MODELS = ['SRX-R515']
DOWSER_STATUS = {'00': 'Closed',
 '01': 'Open'}

def supported_model(model):
    return model.upper() in MODELS


class SonyProjectorMulti(SonyProjector):

    def __init__(self, id, device_info):
        super(SonyProjectorMulti, self).__init__(id, device_info)
        self.response = {}
        self.response['error_messages'] = []

    def has_multiple_lamps(self):
        return True

    def get_projector_status(self):
        output = {'error_messages': []}
        output['lamps'] = []
        output['lamp_status'] = 'Lamp Off'
        for i in xrange(0, 6):
            try:
                dom = self._http_request('/command/projector/maintenance/lamp/info/get?lampId=' + str(i))
                lamp_life_status = dom.getElementsByTagName('PrjLampInformation')[0]
                lamp = {'life_maximum': None,
                 'life_remaning': None,
                 'type': None}
                lamp['life_used'] = int(xml_utils.get_element_value(lamp_life_status, 'HoursOfUse'))
                lamp['current'] = float(xml_utils.get_element_value(lamp_life_status, 'LampPower'))
                output['lamps'].append(lamp)
                lamp_on = xml_utils.get_element_value(lamp_life_status, 'LampOn') == 'true'
                if lamp_on:
                    output['lamp_status'] = 'Lamp On'
            except Exception as e:
                output['error_messages'].append(str(e))

        dom = self._http_request('status/sms/powerstatus')
        for power_status in dom.getElementsByTagName('PowerStatus'):
            if xml_utils.get_element_value(power_status, 'Device') == 'PRJ':
                projector_status = xml_utils.get_element_value(power_status, 'State')
                output['projector_status'] = PROJECTOR_STATUS.get(projector_status, None)
                break
        else:
            output['projector_status'] = None

        output['dowser_status'] = None
        dom = self._http_post_multipart('/status/projector/douser')
        for param in dom.getElementsByTagName('Parameter'):
            if xml_utils.get_element_value(param, 'Name') == 'Douser STATUS':
                output['dowser_status'] = DOWSER_STATUS[xml_utils.get_element_value(param, 'Value')]

        return output


if __name__ == '__main__':
    con = SonyProjectorMulti('', {'ip': '10.58.4.170',
     'port': '443',
     'api_username': 'super',
     'api_password': '0955'})
    con.get_projector_status()
# okay decompyling ./core/devices/projector/sony/sony_multi.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:13 CST
