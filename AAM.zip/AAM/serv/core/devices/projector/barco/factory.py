# 2017.08.13 21:49:06 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\barco\factory.py
"""
This file is meant to cover all the tricks and tweaks of autodetecting a Barco type and instantiating a Device handler class.
"""
import barco_series_1, barco_series_2

def assess_device(device_id, device, snmp_manager):
    device_information = device.get_device_information()
    device.device_configuration['version'] = 'series 1'
    if device_information['type'] not in barco_series_1.PROJECTOR_TYPES:
        device.device_configuration['version'] = 'series 2'
        return barco_series_2.BarcoSeries2(device_id, device.device_configuration, snmp_manager)
    return device
# okay decompyling ./core/devices/projector/barco/factory.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:06 CST
