# 2017.08.13 21:49:06 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\barco\normalizers.py
from serv.core.devices.base.normalizer import DefaultNormalizer
import logging
DOWSER_STATUS = {0: 'Closed',
 1: 'Open',
 2: 'Undetermined'}

class BarcoNormalizer(DefaultNormalizer):

    def __init__(self):
        super(BarcoNormalizer, self).__init__()
        self.add_mapping('projector_status', self.map_projector_status)
        self.add_mapping('dowser_status', DOWSER_STATUS)
        self.add_mapping('lamps', self.enhance_lamps_info)
        self.add_mapping('lamp_status', self.map_lamp_status)

    def map_projector_status(self, value, source):
        if value:
            if ord(value) & 1:
                return 'Power On'
            return 'Power Off'
        else:
            return 'Unknown'

    def map_lamp_status(self, value, source):
        if value:
            if ord(value) & 1:
                return 'Lamp On'
            return 'Lamp Off'
        else:
            return 'Unknown'

    def enhance_lamps_info(self, value, source):
        lamps = value
        for lamp in lamps:
            try:
                lamp['life_remaining'] = int(lamp['life_maximum']) - int(lamp['life_used'])
                lamp['life'] = int(float(lamp['life_used']) / float(lamp['life_maximum']) * 100)
            except Exception as e:
                logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))

        return lamps


class Barco2Normalizer(BarcoNormalizer):

    def __init__(self):
        super(Barco2Normalizer, self).__init__()
        self.add_mapping('projector_status', self.map_projector_status)

    def map_projector_status(self, value, source):
        if value:
            if int(value):
                return 'Power On'
            return 'Power Off'
        else:
            return 'Unknown'
# okay decompyling ./core/devices/projector/barco/normalizers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:06 CST
