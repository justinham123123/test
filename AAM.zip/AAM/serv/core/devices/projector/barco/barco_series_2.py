# 2017.08.13 21:49:06 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\barco\barco_series_2.py
"""
Implementation of Core2 projection API for Barco series 2 projectors
"""
from serv.core.devices.projector.barco.barco_series_1 import BarcoSeries1
from serv.core.devices.projector.barco.normalizers import Barco2Normalizer
PROJECTOR_TYPES = ['DP2K-12C',
 'DP2K-15C',
 'DP2K-20C',
 'DP2K-19B',
 'DP2K-23B',
 'DP2K-32B',
 'DP4K-19B',
 'DP4K-23B',
 'DP4K-32B']

class BarcoSeries2(BarcoSeries1):

    def __init__(self, id, device_info, snmp_manager):
        super(BarcoSeries2, self).__init__(id, device_info, snmp_manager)
        self.normalizer = Barco2Normalizer()

    def get_projector_status(self):
        """
        This is a patch method for the baseclass function setting some things right for series 2
        """
        return self.response
# okay decompyling ./core/devices/projector/barco/barco_series_2.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:06 CST
