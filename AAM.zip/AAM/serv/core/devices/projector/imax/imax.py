# 2017.08.13 21:49:08 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\imax\imax.py
"""
Imax projector
"""
import sys
import logging
import socket
from threading import Lock
from socket import error as socket_error
from serv.core.devices.base.projection import Projection
from serv.lib.network import socket_utils
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.sms.shared import doremi_based_command_helper
from serv.core.devices.sms.imax import imax_commands
from serv.lib.utilities.utils import check_response, synchronized
TIMEOUT = 30
LAMP_STATUS = {0: 'Lamp On',
 1: 'Lamp Off'}

class IMAX(Projection):

    def __init__(self, id, device_info):
        super(Projection, self).__init__(id, device_info)
        self.socket_lock = Lock()
        self.socket = None
        return

    def _execute_command(self, command, data = None):
        """
        Executes an IMAX command remotely on a server
        """

        @synchronized(self.socket_lock)
        def locked_execute(command, data):
            exc_info = {}
            timeout = TIMEOUT
            imax_cmds = imax_commands.__dict__.items()
            cmd_name = [ x[0] for x in imax_cmds if x[1] == command ]
            if len(command) > 4:
                timeout = command[4]
            try:
                if self.socket is None:
                    self.socket = socket_utils.create_open_tls_socket(self.device_configuration['ip'], int(self.device_configuration['port']), self.device_configuration['cert_path'], timeout)
                    logging.debug('Created open socket to Imax server = [%s] socket = [%s]' % (str(self.device_configuration['ip']), str(self.socket)))
                byte_message = doremi_based_command_helper.construct_request(command, data)
                self.socket.sendall(byte_message)
                doremi_based_command_helper.receive_bytes(self.socket, 16)
                length_message = doremi_based_command_helper.receive_bytes(self.socket, 4)
                doremi_based_command_helper.receive_bytes(self.socket, 4)
                data_message = doremi_based_command_helper.receive_bytes(self.socket, doremi_based_command_helper.parse_length(length_message) - 4)
                response = command[3](data_message)
                return response
            except Exception as ex:
                exc_info = sys.exc_info()
                if isinstance(ex, socket_error) or isinstance(ex, IOError):
                    logging.error('Socket Error executing Imax command: server=[%s] command=%s data=[%s] socket=[%s]' % (str(self.device_configuration['ip']),
                     cmd_name,
                     str(data),
                     str(self.socket)))
                else:
                    logging.error('Error executing Imax command: server=[%s] command=%s data=[%s] socket=[%s]' % (str(self.device_configuration['ip']),
                     cmd_name,
                     str(data),
                     str(self.socket)), exc_info=True)
                if self.socket is not None:
                    try:
                        self.socket.shutdown(2)
                        self.socket.close()
                    except Exception as ex:
                        logging.error('Error closing Imax socket:[%s]' % str(ex))

                logging.debug('Closed socket connection to server = [%s] socket =[%s]' % (str(self.device_configuration['ip']), str(self.socket)))
                self.socket = None
                raise exc_info[0], exc_info[1], exc_info[2]
            finally:
                del exc_info

            return

        return locked_execute(command, data)

    def get_device_status(self):
        output = {'error_messages': []}
        time_response = self._execute_command(imax_commands.UTC_GET_TIME)
        if check_response(time_response):
            output['current_time'] = float(time_response['utc_time'])
        else:
            output['error_messages'].append(str(time_response))
        return output

    def test_management_connection(self):
        try:
            self._execute_command(imax_commands.UTC_GET_TIME)
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error [%s]') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error [%s]') % str(ex))

        return (True, _('OK'))

    def get_device_information(self):
        return {'type': None,
         'error_messages': []}

    def get_projector_status(self):
        left = self._execute_command(imax_commands.GET_LAMP_STATUS, 0)
        right = self._execute_command(imax_commands.GET_LAMP_STATUS, 1)
        result = {'error_messages': [],
         'lamp_status': None,
         'projector_status': 'Power On',
         'dowser_status': 'Unknown'}
        if left['lamp_status'] and right['lamp_status']:
            lamp_status = LAMP_STATUS[0]
        elif not left['lamp_status'] and not right['lamp_status']:
            lamp_status = LAMP_STATUS[1]
        else:
            lamp_status = None
        if left['response'] == 0 and right['response'] == 0:
            result['lamp_status'] = lamp_status
        else:
            result['error_messages'].append('Responder unable to process Request')
        return result

    def lamp_on(self):
        """
        Strike the lamp
        """
        raise NotImplementedError

    def lamp_off(self):
        """
        Turn the lamp off
        """
        raise NotImplementedError

    def open_dowser(self):
        """
        Open the dowser
        """
        raise NotImplementedError

    def close_dowser(self):
        """
        Close the dowser
        """
        raise NotImplementedError

    def power_on(self):
        """
        Turn the projector on
        """
        raise NotImplementedError

    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        raise NotImplementedError
# okay decompyling ./core/devices/projector/imax/imax.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:09 CST
