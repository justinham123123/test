# 2017.08.13 21:49:11 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\nec\normalizers.py
from serv.core.devices.base.normalizer import DefaultNormalizer
import logging
PROJECTOR_STATUS = {1: 'Power Off',
 2: 'Power On',
 3: 'Cooling'}
DOWSER_STATUS = {1: 'Open',
 2: 'Closed'}
LAMP_STATUS = {1: 'Lamp Off',
 2: 'Lamp On',
 3: 'Lamp On',
 4: 'Lamp On',
 5: 'Lamp On'}

class NECNormalizer(DefaultNormalizer):

    def __init__(self):
        super(NECNormalizer, self).__init__()
        self.add_mapping('projector_status', PROJECTOR_STATUS)
        self.add_mapping('dowser_status', DOWSER_STATUS)
        self.add_extension('lamp_status', ['lamps'], self.extend_lamp_status)
        self.add_mapping('lamps', self.enhance_lamps_info)

    def enhance_lamps_info(self, value, source):
        lamps = value
        for lamp in lamps:
            try:
                lamp['life_maximum'] = int(lamp['life_remaining']) + int(lamp['life_used'])
                lamp['life'] = int(float(lamp['life_used']) / float(lamp['life_maximum']) * 100)
            except Exception as e:
                logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))

            if 'nec_current' in lamp:
                lamp['current'] = self.fix_decimals(lamp['nec_current'])

        return lamps

    def fix_decimals(self, value, source = None):
        try:
            floatvalue = float(value)
            fixed_value = int(floatvalue / 10.0)
            return fixed_value
        except Exception as e:
            logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))
            return value

    def extend_lamp_status(self, lamps):
        for lamp in lamps:
            try:
                if int(lamp['current']) > 0:
                    return 'Lamp On'
                return 'Lamp Off'
            except Exception as e:
                logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))

            try:
                if int(lamp['wattage']) > 0:
                    return 'Lamp On'
                return 'Lamp Off'
            except Exception as e:
                logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))

            return 'Unknown'

    def extend_lamp_life(self, lamp_life_used, lamp_life_remaining):
        lamp_life_max = int(lamp_life_used) + int(lamp_life_remaining)
        lamp_life = int(float(lamp_life_used) / float(lamp_life_max) * 100)
        return lamp_life


class NEC2Normalizer(NECNormalizer):

    def __init__(self):
        super(NEC2Normalizer, self).__init__()
        self.remove_extension(self.extend_lamp_status)
        self.add_mapping('lamp_status', LAMP_STATUS)


LAMP_MODE = {1: 'Dual',
 2: 'Lamp 1 Only',
 3: 'Lamp 2 Only'}

class NECMultipleNormalizer(DefaultNormalizer):

    def __init__(self):
        super(NECMultipleNormalizer, self).__init__()
        self.add_mapping('projector_status', PROJECTOR_STATUS)
        self.add_mapping('dowser_status', DOWSER_STATUS)
        self.add_mapping('lamp_status', LAMP_STATUS)
        self.add_mapping('lamp_mode', LAMP_MODE)
        self.add_mapping('lamp_output_wattage', self.fix_decimals)
        self.add_mapping('lamp_output_percentage', self.fix_decimals)
        self.add_mapping('lamps', self.enhance_lamps_info)

    def enhance_lamps_info(self, value, source):
        lamps = value
        for lamp in lamps:
            try:
                lamp['life_remaining'] = lamp['life_maximum'] - lamp['life_used']
                lamp['life'] = int(float(lamp['life_used']) / float(lamp['life_maximum']) * 100)
            except Exception as e:
                logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))

        return lamps

    def fix_decimals(self, value, source = None):
        try:
            floatvalue = float(value)
            fixed_value = int(floatvalue / 10.0)
            return fixed_value
        except Exception as e:
            logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))
            return value
# okay decompyling ./core/devices/projector/nec/normalizers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:12 CST
