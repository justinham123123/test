# 2017.08.13 21:49:10 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\nec\nec_series_2_multiple.py
"""
Implementation of Core2 projection API for NEC Dual-lamp projectors
"""
from serv.core.devices.projector.nec.nec_series_2 import NECSeries2
from serv.core.devices.projector.nec.normalizers import NECMultipleNormalizer
PROJECTOR_TYPES = ['nc900c', 'nc900ca', 'Type 2 Dual']
LAMP_OID_MAP = {'common': {'status': '.1.3.6.1.4.1.119.2.3.123.2.7.0',
            'output_wattage': '.1.3.6.1.4.1.119.2.3.123.2.8.1.0',
            'output_percentage': '.1.3.6.1.4.1.119.2.3.123.2.8.2.0',
            'lamp_mode': '.1.3.6.1.4.1.119.2.3.123.2.10.0',
            'warning': '.1.3.6.1.4.1.119.2.3.123.2.9.3.0'},
 '1': {'voltage': '.1.3.6.1.4.1.119.2.3.123.2.8.3.0',
       'usage': '.1.3.6.1.4.1.119.2.3.123.2.9.1.0',
       'remaining': '.1.3.6.1.4.1.119.2.3.123.2.9.4.0',
       'strike_count': '.1.3.6.1.4.1.119.2.3.123.2.9.6.0'},
 '2': {'voltage': '.1.3.6.1.4.1.119.2.3.123.2.8.4.0',
       'usage': '.1.3.6.1.4.1.119.2.3.123.2.9.2.0',
       'remaining': '.1.3.6.1.4.1.119.2.3.123.2.9.5.0',
       'strike_count': '.1.3.6.1.4.1.119.2.3.123.2.9.7.0'}}

class NECSeries2Multiple(NECSeries2):

    def __init__(self, id, device_info, snmp_manager):
        super(NECSeries2Multiple, self).__init__(id, device_info, snmp_manager)
        self.normalizer = NECMultipleNormalizer()

    def has_multiple_lamps(self):
        return True

    def get_projector_status(self):
        """
        Gets the available status values for the projector. All SNMP stuff now moved to Peeping Tom
        @return 
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        self.response['error_messages'] = []
        return self.response
# okay decompyling ./core/devices/projector/nec/nec_series_2_multiple.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:10 CST
