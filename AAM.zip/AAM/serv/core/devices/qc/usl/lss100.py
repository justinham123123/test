# 2017.08.13 21:49:13 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\qc\usl\lss100.py
from serv.core.devices.base.probe import Probe
from datetime import timedelta, datetime
from telnetlib import Telnet
from threading import RLock
import time
import json
import calendar
import re as reg

class LSS100(Probe):
    PROMPT = '\r'

    def __init__(self, uuid, device_info):
        super(LSS100, self).__init__(uuid, device_info)
        self.lock = RLock()
        self.telnet = Telnet()

    def test_management_connection(self):
        return 'software_version' in self.get_device_version_information()

    def get_device_status(self):
        output = {'error_messages': []}
        try:
            output['current_time'] = self.get_device_version_information()
        except Exception as e:
            output['error_messages'] = str(e)

        return output

    def get_device_version_information(self):
        response = {'error_messages': []}
        success, versions = self.execute('lss100.sys.ver')
        response['model'] = 'LSS-100'
        if success:
            versions = versions.split('\t')
            response['circuit_version'] = versions[0]
            response['firmware_version'] = versions[1]
            response['software_version'] = versions[2]
        return response

    def get_device_information(self):
        response = {'error_messages': []}
        versions = self.get_device_version_information()
        response.update(versions)
        return response

    def get_last_log_no(self):
        return self.execute('lss100.sys.log_read')

    def get_log(self, log_no):
        return self.execute('lss100.sys.log_read\t' + str(log_no))

    def get_logs(self, day):
        day_start = datetime(day.year, day.month, day.day)
        day_end = datetime(day.year, day.month, day.day) + timedelta(hours=24)
        day_start = calendar.timegm(day_start.utctimetuple())
        day_end = calendar.timegm(day_end.utctimetuple())
        re = []
        seek, log_no = self.get_last_log_no()
        if not log_no:
            return (False, None)
        else:
            log_no = int(log_no)
            while seek:
                s, log = self.get_log(log_no)
                if not s:
                    break
                log = log.split('\t')
                log_time = int(log[1])
                if log_time > day_end:
                    pass
                elif log_time > day_start and log_time < day_end:
                    name = str(log[2]).lower().replace(' ', '_')
                    if name == 'chromaticity':
                        name = 'chromaticity_{0}'.format(log[6])
                    re.append({'timestamp': log[1],
                     'name': name,
                     'value': log[3],
                     'thresholds': {'type': 'both',
                                    'critical_low': log[4],
                                    'critical_high': log[5]}})
                elif log_time < day_start:
                    seek = False
                log_no -= 1

            if re:
                return (True, re)
            return (False, None)
            return None

    def execute(self, command):
        success = True
        with self.lock:
            self.telnet.open(self.device_configuration['ip'], self.device_configuration['port'], 30)
            command = command.encode('ascii') + '\r'.encode('ascii')
            self.telnet.write(command)
            re = self.telnet.read_until(self.PROMPT, timeout=30)
            self.telnet.close()
        if not re:
            success = False
            return (success, None)
        else:
            re = reg.sub(self.PROMPT, '', re)
            return (success, re)


if __name__ == '__main__':
    con = LSS100('', {'ip': '10.59.228.31',
     'port': '10001'})
# okay decompyling ./core/devices/qc/usl/lss100.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:14 CST
