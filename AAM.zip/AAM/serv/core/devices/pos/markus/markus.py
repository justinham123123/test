# 2017.08.13 21:49:00 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\markus\markus.py
import urllib2, logging
from serv.lib.dcinema.parsers.parsers import parse_markus_pos
from serv.core.devices.base.pos import POS
from serv.lib.cherrypy.i18n_tool import ugettext as _

class Markus(POS):

    def get_schedule(self, start_date, end_date, complex_ids = []):
        """
        Gets a schedule of films for a cinema theatre
        """
        output = {'sessions': [],
         'success': False,
         'messages': [],
         'raw_input': None}
        try:
            if 'nrOfDays' not in self.device_configuration['ip']:
                timeframe = '&nrOfDays=21' if '?' in self.device_configuration['ip'] else '?nrOfDays=21'
                url = self.device_configuration['ip'] + timeframe
            else:
                url = self.device_configuration['ip']
            response = urllib2.urlopen(urllib2.Request(url)).read()
            output['raw_input'] = response
            output['sessions'] = parse_markus_pos(response)
            output['success'] = True
            output['messages'].append({'type': 'success',
             'message': _('POS sync successful')})
        except (urllib2.URLError, IOError):
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed because IP address is incorrect or unreachable')})
            output['raw_input'] = 'POS sync failed, IP address is incorrect or unreachable.'
        except Exception as ex:
            logging.error('There was an error while syncing the POS feed.', exc_info=True)
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed: %s') % str(ex)})
            output['raw_input'] = 'POS sync failed: %s' % str(ex)

        return output

    def test_management_connection(self):
        try:
            urllib2.urlopen(self.device_configuration['ip']).read()
        except (urllib2.URLError, IOError):
            return (False, _('IP address is incorrect or unreachable'))
        except Exception as ex:
            return (False, _('Connection error %s' % str(ex)))

        return (True, _('OK'))
# okay decompyling ./core/devices/pos/markus/markus.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:01 CST
