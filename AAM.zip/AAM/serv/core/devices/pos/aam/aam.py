# 2017.08.13 21:48:55 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\aam\aam.py
"""
Emulated POS adaptor.
"""
import urllib2, logging, subprocess, os, sys
from serv.core.devices.base.pos import POS
from serv.core.devices.sms.aam.aam_utils import execute
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration import cfg
from aamulator import aamulator
from serv.lib.dcinema.parsers.parsers import parse_aamulator_pos
from time import sleep
import json

class AAMulator(POS):

    def __init__(self, id, device_info, core):
        super(AAMulator, self).__init__(id, device_info, core)
        self.process = None
        self.core = core
        if self.device_configuration['enabled']:
            self.startup()
        return

    def startup(self):
        """
        Start emulator process
        """
        if not self.process:
            self.process = subprocess.Popen([cfg.python_executable() if cfg.python_executable() else sys.executable, os.path.join(os.path.dirname(aamulator.__file__), 'aamulator.pyc'), json.dumps({'type': 'pos',
              'screen_count': len(self.core.screens.keys()) + 1,
              'ip': self.device_configuration['ip'],
              'port': self.device_configuration['port'],
              'root_directory': os.path.join(cfg.data_dir(), 'emulation', str(self.device_configuration['port']))})])
            logging.info('POS Emulator enabled [%s]' % str(self.device_configuration['port']))
        else:
            logging.info('POS Emulator already running [%s]' % str(self.device_configuration['port']))
        return (True, '')

    def shutdown(self):
        """
        Kill emulator process
        """
        if self.process:
            self.device_configuration['enabled'] = False
            try:
                self.process.terminate()
            except WindowsError:
                pass

            self.process = None
            logging.info('POS Emulator disabled [%s]' % str(self.device_configuration['port']))
        return (True, '')

    def _execute(self, api, func = None, params = {}):
        return execute(self.device_configuration['ip'], self.device_configuration['port'], api, func=func, params=params, error_list=False)

    def get_schedule(self, start_date, end_date, complex_ids = []):
        """
        Gets a schedule of films for a cinema theatre
        """

        def _get_schedule():
            output = {'sessions': [],
             'success': False,
             'messages': [],
             'raw_input': None}
            try:
                response = self._execute('schedule')
                output['raw_input'] = str(response)
                output['sessions'] = parse_aamulator_pos(response)
                output['success'] = True
                output['messages'].append({'type': 'success',
                 'message': _('POS sync successful.')})
            except (urllib2.URLError, IOError):
                output['success'] = False
                output['messages'].append({'type': 'error',
                 'message': _('POS sync failed, IP address is incorrect or unreachable.')})
                output['raw_input'] = 'POS sync failed, IP address is incorrect or unreachable.'
            except Exception as ex:
                logging.error('There was an error while syncing the POS feed.', exc_info=True)
                output['success'] = False
                output['messages'].append({'type': 'error',
                 'message': _('POS sync failed: %s') % str(ex)})
                output['raw_input'] = 'POS sync failed: %s' % str(ex)

            return output

        output = _get_schedule()
        if not output['success']:
            sleep(5)
            output = _get_schedule()
        return output

    def test_management_connection(self):
        try:
            self._execute('/')
        except (urllib2.URLError, IOError):
            return (False, _('IP address is incorrect or unreachable.'))
        except Exception as ex:
            return (False, _('Connection error [%s]' % str(ex)))

        return (True, _('OK'))
# okay decompyling ./core/devices/pos/aam/aam.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:56 CST
