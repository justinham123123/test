# 2017.08.13 21:49:02 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\onestepahead\onestepahead.py
import urllib2, logging
from serv.lib.dcinema.parsers.parsers import parse_one_step_ahead_pos
from serv.core.devices.base.pos import POS
from serv.lib.cherrypy.i18n_tool import ugettext as _

class OneStepAhead(POS):

    def get_schedule(self, start_date, end_date, complex_ids = []):
        """
        Gets a schedule of films for a cinema theatre
        """
        output = {'sessions': [],
         'success': False,
         'messages': [],
         'raw_input': None}
        try:
            response = urllib2.urlopen(urllib2.Request(self.device_configuration['ip'])).read()
            output['raw_input'] = response
            output['sessions'] = parse_one_step_ahead_pos(response, self.device_configuration['id'])
            output['success'] = True
            output['messages'].append({'type': 'success',
             'message': _('POS sync successful')})
        except (urllib2.URLError, IOError):
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed because IP address is incorrect or unreachable')})
            output['raw_input'] = 'POS sync failed, IP address is incorrect or unreachable.'
        except Exception as ex:
            logging.error('There was an error while syncing the POS feed.', exc_info=True)
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed: %s') % str(ex)})
            output['raw_input'] = 'POS sync failed: %s' % str(ex)

        return output

    def test_management_connection(self):
        try:
            urllib2.urlopen(self.device_configuration['ip']).read()
        except (urllib2.URLError, IOError):
            return (False, _('IP address is incorrect or unreachable'))
        except Exception as ex:
            return (False, _('Connection error %s' % str(ex)))

        return (True, _('OK'))
# okay decompyling ./core/devices/pos/onestepahead/onestepahead.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:02 CST
