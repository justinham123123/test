# 2017.08.13 21:49:03 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\vista\__init__.py
pass
# okay decompyling ./core/devices/pos/vista/__init__.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:03 CST
