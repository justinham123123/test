# 2017.08.13 21:48:56 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\compeso\compeso.py
from datetime import datetime, timedelta, date
from serv.core.devices.base.pos import POS
from urlparse import urlparse
from xml.dom import minidom
from xml.etree import ElementTree
from xml.etree.ElementTree import Element, SubElement, Comment, tostring
import httplib
import socket
import string
from serv.lib.cherrypy.i18n_tool import ugettext as _
SOAP_ENVELOPE = string.Template('<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" xmlns:a="http://www.w3.org/2005/08/addressing">\n    <s:Header>\n        <compeso-username>$username</compeso-username>\n        <compeso-password>$password</compeso-password>\n    </s:Header>\n    <s:Body>\n        $body\n    </s:Body>\n</s:Envelope>\n')

class Compeso(POS):

    def _SOAP_post(self, SOAPAction, xml):
        url = 'http://%s:8180/tmsinterface/' % self.device_configuration['ip']
        parsed_url = urlparse(url)
        host, path = parsed_url.netloc, parsed_url.path
        conn = httplib.HTTPConnection(host)
        headers = {'Host': host,
         'Content-Type': 'text/xml; charset=utf-8',
         'Content-Length': str(len(xml)),
         'Expect': '100-continue',
         'Accept-Encoding': 'gzip, deflate',
         'Connection': 'Keep-Alive',
         'SOAPAction': '"%s"' % SOAPAction}
        conn.request('POST', path, body=xml, headers=headers)
        http_response = conn.getresponse()
        soap_response = http_response.read()
        if http_response.status != 200:
            raise ValueError('Error connecting: %s, %s' % (http_response.status, http_response.reason))
        soap_xml = minidom.parseString(soap_response)
        return soap_xml

    def _execute(self, schema, port, action, args = {}):
        root = Element(action)
        root.set('xmlns', schema)
        for arg in args:
            element = SubElement(root, arg['key'])
            element.text = arg['value']

        body_string = ElementTree.tostring(root, 'utf-8')
        username = self.device_configuration['ftp_username']
        password = self.device_configuration['ftp_password']
        soap_request = SOAP_ENVELOPE.substitute(body=body_string, username=username, password=password)
        soap_response = self._SOAP_post(schema + '/' + port + '/' + action, soap_request)
        body = soap_response.getElementsByTagName('s:Body')
        return body[0]

    def get_validation(self, instanceId, username, password):
        args = []
        args.append({'key': 'instanceId',
         'value': instanceId})
        args.append({'key': 'userName',
         'value': username})
        args.append({'key': 'password',
         'value': password})
        return self._execute('http://compeso.com/tms/2012-02-10', 'ITmsClientAuthentication', 'Validate', args)

    def validate_login(self, instanceId, username, password):
        success = False
        message = ''
        try:
            validation_xml = self.get_validation(instanceId, username, password)
        except Exception as e:
            return (False, str(e))

        validation = validation_xml.getElementsByTagName('ValidateResult')[0].firstChild.data
        if validation == 'OK':
            success = True
            message = 'Credentials OK'
        else:
            success = False
            message = validation
        return (success, message)

    def get_performances(self, instanceId, from_date, to_date):
        args = []
        args.append({'key': 'instanceId',
         'value': instanceId})
        args.append({'key': 'fromDate',
         'value': from_date})
        args.append({'key': 'toDate',
         'value': to_date})
        return self._execute('http://compeso.com/tms/2012-02-10', 'ITmsSchedule', 'GetPerformances', args)

    def parse_compeso_time(self, timestamp):
        return datetime.strptime(timestamp + '000', '%Y-%m-%dT%H:%M:%S%f')

    def parse_performances(self, xml):
        sessions = []
        for session_node in xml.getElementsByTagName('b:PerformanceInfo'):
            audit_node = session_node.getElementsByTagName('b:AuditoriumInfo')[0]
            film_node = session_node.getElementsByTagName('b:FilmInfo')[0]
            center_node = session_node.getElementsByTagName('b:CenterInfo')[0]
            session = {}
            session['id'] = self.get_direct_child(session_node, 'Oid').firstChild.data
            session['feature_title'] = film_node.getElementsByTagName('b:Title')[0].firstChild.data
            session['screen_identifier'] = audit_node.getElementsByTagName('a:Number')[0].firstChild.data
            session['start'] = self.parse_compeso_time(session_node.getElementsByTagName('b:Start')[0].firstChild.data)
            session['overall_duration'] = film_node.getElementsByTagName('b:DurationInMins')[0].firstChild.data
            session['end'] = session['start'] + timedelta(minutes=int(session['overall_duration']))
            session['overall_duration'] = int(session['overall_duration']) * 60
            session['complex_identifier'] = center_node.getElementsByTagName('a:Oid')[0].firstChild.data
            sessions.append(session)

        return sessions

    def get_direct_child(self, xml, tag):
        for node in xml.childNodes:
            if node.localName == tag:
                return node

    def get_schedule(self, start_date, end_date, complex_ids = []):
        output = {'sessions': {},
         'raw_input': '',
         'success': False,
         'messages': []}
        start_date = str(start_date) + 'T00:00:00'
        end_date = str(end_date) + 'T00:00:00'
        try:
            instanceId = self.device_configuration['api_username']
            performances_xml = self.get_performances(instanceId, start_date, end_date)
            sessions = self.parse_performances(performances_xml)
            output['sessions'] = sessions
            output['raw_input'] = performances_xml.toxml()
            output['success'] = True
            return output
        except Exception as e:
            output['messages'].append({'type': 'error',
             'message': _('Failed to get schedules: %s') % str(e)})
            return output

    def test_management_connection(self):
        try:
            try:
                soc = socket.create_connection((self.device_configuration['ip'], 8180))
                soc.shutdown(socket.SHUT_RDWR)
            except socket.timeout:
                return (False, _('Timed out while trying to connect'))
            except (socket.herror, socket.gaierror):
                return (False, _('Unable to find the configured host or address'))
            except socket.error as ex:
                return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
            except Exception as ex:
                return (False, _('Unexpected error %s') % str(ex))

            success, message = self.validate_login(self.device_configuration['api_username'], self.device_configuration['ftp_username'], self.device_configuration['ftp_password'])
            return (success, message)
        finally:
            try:
                soc.close()
            except:
                pass
# okay decompyling ./core/devices/pos/compeso/compeso.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:57 CST
