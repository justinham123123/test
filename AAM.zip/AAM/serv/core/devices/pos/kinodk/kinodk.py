# 2017.08.13 21:49:00 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\kinodk\kinodk.py
from urlparse import urlparse
import logging
import socket
import urllib2
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.base.pos import POS
from serv.lib.dcinema.parsers.parsers import parse_ebillet_feed_pos
from serv.lib.network.soap_utils import SOAPClient
from serv.lib.utilities.xml_utils import iterparse_xml

class KinoDK(POS):

    def __init__(self, id, device_info, core):
        super(KinoDK, self).__init__(id, device_info, core)
        parsed_url = urlparse(self.device_configuration['ip'])
        if not parsed_url.netloc:
            parsed_url = urlparse('//{0}'.format(self.device_configuration['ip']))
        host = parsed_url.netloc
        self.client = KinoDKSOAPClient(host)
        self.path = parsed_url.path
        self.soap_action = 'http://tempuri.org/FFPL_GetPlayList'
        self.namespaces = {'tem': 'http://tempuri.org/'}

    def get_schedule(self, start_date, end_date, complex_ids = None):
        if not complex_ids:
            complex_ids = []
        output = {'sessions': [],
         'success': False,
         'messages': [],
         'raw_input': ''}
        params = {'tem:timeStart': start_date,
         'tem:timeEnd': end_date}
        try:
            schedule_xml = self.client.request(self.path, 'tem:FFPL_GetPlayList', self.soap_action, params=params, namespaces=self.namespaces)
            output['raw_input'] = schedule_xml
            output['sessions'] = parse_ebillet_feed_pos(schedule_xml)
            output['success'] = True
            output['messages'].append({'type': 'success',
             'message': _('POS sync successful')})
        except (urllib2.URLError, IOError):
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed because IP address is incorrect or unreachable')})
            output['raw_input'] = 'POS sync failed, IP address is incorrect or unreachable.'
        except Exception as ex:
            logging.error('There was an error while syncing the POS feed.', exc_info=True)
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed: %s') % str(ex)})
            output['raw_input'] = 'POS sync failed: %s' % str(ex)

        return output

    def test_management_connection(self):
        soc = None
        try:
            try:
                soc = socket.create_connection((self.device_configuration['ip'], 80))
                soc.shutdown(socket.SHUT_RDWR)
            except socket.timeout:
                return (False, _('Timed out while trying to connect'))
            except (socket.herror, socket.gaierror):
                return (False, _('Unable to find the configured host or address'))
            except socket.error as ex:
                return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
            except Exception as ex:
                return (False, _('Unexpected error %s') % str(ex))

            return (True, _('OK'))
        finally:
            if soc:
                soc.close()

        return


class KinoDKSOAPClient(SOAPClient):

    def __init__(self, *args, **kwargs):
        super(KinoDKSOAPClient, self).__init__(*args, **kwargs)

    def parse_response(self, response, **kwargs):

        def loop_function(event, element, loop_vars, **inner_kwargs):
            if event == 'end':
                if element.tag.endswith('playListXml'):
                    loop_vars['result'] = element.text.encode('utf-8')
                element.clear()
            return loop_vars

        parsed_response = iterparse_xml(response, loop_function, {})
        return parsed_response['result']
# okay decompyling ./core/devices/pos/kinodk/kinodk.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:00 CST
