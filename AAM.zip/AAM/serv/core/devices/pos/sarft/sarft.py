# 2017.08.13 21:49:02 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\sarft\sarft.py
import logging
import urlparse
import hashlib, socket
from datetime import datetime, timedelta
from string import Template
from httplib import HTTPConnection
from xml.dom import minidom
from xml.sax.saxutils import unescape
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration import cfg
from serv.core.devices.base.pos import POS
GET_SCHEDULES_SOAP_REQUEST = Template('<?xml version="1.0" encoding="UTF-8"?>\n<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\nxmlns:xsd="http://www.w3.org/2001/XMLSchema"\nxmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">\n<soap:Body>\n<getSchedules xmlns="http://project.crifst.org/tms/smi/2010/POSAPI">\n<TheatreCode>$theatre_code</TheatreCode>\n<BeginDate>$start_date</BeginDate>\n<EndDate>$end_date</EndDate>\n</getSchedules>\n</soap:Body>\n</soap:Envelope>')

class SARFTPOS(POS):
    """
    Adapter for the UCS Chinese PoS system
    """

    def get_schedule(self, start_date, end_date, complex_ids):
        """
        Gets the current list of schedules from the PoS system
        """
        output = {'sessions': [],
         'success': True,
         'messages': [],
         'raw_input': ''}
        split_url = urlparse.urlsplit(self.device_configuration['ip'])
        host = split_url.netloc
        path = split_url.path
        for complex_identifier in complex_ids:
            try:
                soap_request = GET_SCHEDULES_SOAP_REQUEST.substitute(theatre_code=complex_identifier, start_date=start_date, end_date=end_date).encode('utf-8')
                conn = HTTPConnection(split_url.netloc, timeout=100)
                headers = {'Host': host,
                 'Content-Type': 'text/xml; charset=utf-8',
                 'Content-Length': len(soap_request),
                 'SOAPAction': 'http://project.crifst.org/tms/smi/2010/POSAPI/getSchedules'}
                conn.request('POST', path, body=soap_request, headers=headers)
                http_response = conn.getresponse()
                soap_response = unescape(http_response.read().lower())
                output['raw_input'] = soap_response
                conn.close()
                if http_response.status != 200:
                    logging.error('POS sync %s HTTP error %s %s' % (complex_identifier, http_response.status, http_response.reason))
                    output['messages'].append({'type': 'error',
                     'message': 'POS sync %s HTTP error %s %s' % (complex_identifier, http_response.status, http_response.reason)})
                    output['success'] = False
                else:
                    sessions = self._parse_schedules(soap_response.split('<getschedulesresult>')[1].split('</getschedulesresult>')[0])
                    output['sessions'].extend(sessions)
            except Exception as ex:
                output['success'] = False
                output['messages'].append({'type': 'error',
                 'message': _('POS sync failed: %s') % str(ex)})
                logging.error('POS sync %s error' % complex_identifier, exc_info=True)

        return output

    def _parse_schedules(self, xml):
        """
        Parses schedules from the getSchedules SOAP response
        """
        dom = minidom.parseString(xml)
        sessions = []
        default_session_length = cfg.pos_default_session_length() * 60
        schedule_nodes = dom.getElementsByTagNameNS('*', 'schedule')
        if not schedule_nodes:
            return []
        schedule_node = schedule_nodes[0]
        theatre = schedule_node.getAttribute('theatrecode')
        for day_node in schedule_node.getElementsByTagNameNS('*', 'scheduleday'):
            date_str = day_node.getAttribute('date').strip()
            for film_node in day_node.getElementsByTagNameNS('*', 'film'):
                title = film_node.getAttribute('title')
                for performance_node in film_node.getElementsByTagNameNS('*', 'performance'):
                    time_str = performance_node.getAttribute('showtime').strip()
                    screen = performance_node.getAttribute('auditorium')
                    formatted_date_string = time_str if len(time_str) > 8 else date_str + 'T' + time_str
                    if len(formatted_date_string) != 19:
                        logging.error('Dodgy date string [%s] Skipping session [%s %s]' % (formatted_date_string, title, screen))
                        continue
                    start_time = datetime.strptime(formatted_date_string, '%Y-%m-%dT%H:%M:%S')
                    end_time = start_time + timedelta(seconds=default_session_length)
                    id = hashlib.md5(date_str + time_str + ''.join([ str(ord(c)) for c in screen ])).hexdigest()
                    sessions.append({'id': id,
                     'complex_identifier': theatre,
                     'screen_identifier': screen,
                     'feature_title': title,
                     'start': start_time,
                     'end': end_time,
                     'overall_duration': default_session_length,
                     'feature_duration': default_session_length})

        return sessions

    def test_management_connection(self):
        soc = None
        try:
            try:
                soc = socket.create_connection((urlparse.urlsplit(self.device_configuration['ip']).netloc, 8081))
                soc.shutdown(socket.SHUT_RDWR)
            except socket.timeout:
                return (False, _('Timed out while trying to connect'))
            except (socket.herror, socket.gaierror):
                return (False, _('Unable to find the configured host or address'))
            except socket.error as ex:
                return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
            except Exception as ex:
                return (False, _('Unexpected error %s') % str(ex))

            return (True, _('OK'))
        finally:
            if soc:
                soc.close()

        return
# okay decompyling ./core/devices/pos/sarft/sarft.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:03 CST
