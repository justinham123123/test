# 2017.08.13 21:48:59 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\ebillet\ebillet.py
import logging
import urllib2
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.base.pos import POS
from serv.lib.dcinema.parsers.parsers import parse_ebillet_pos

class Ebillet(POS):

    def __init__(self, id, device_info, core):
        super(Ebillet, self).__init__(id, device_info, core)

    def get_schedule(self, start_date, end_date, complex_ids = None):
        if not complex_ids:
            complex_ids = []
        output = {'sessions': [],
         'success': False,
         'messages': [],
         'raw_input': ''}
        try:
            schedule_xml = urllib2.urlopen(urllib2.Request(self.device_configuration['ip']))
            output['raw_input'] = schedule_xml.read()
            output['sessions'] = parse_ebillet_pos(output['raw_input'])
            output['success'] = True
            output['messages'].append({'type': 'success',
             'message': _('POS sync successful')})
        except (urllib2.URLError, IOError):
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed because IP address is incorrect or unreachable')})
            output['raw_input'] = 'POS sync failed, IP address is incorrect or unreachable.'
        except Exception as ex:
            logging.error('There was an error while syncing the POS feed.', exc_info=True)
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed: %s') % str(ex)})
            output['raw_input'] = 'POS sync failed: %s' % str(ex)

        return output

    def test_management_connection(self):
        try:
            urllib2.urlopen(self.device_configuration['ip']).read()
        except (urllib2.URLError, IOError):
            return (False, _('IP address is incorrect or unreachable'))
        except Exception as ex:
            return (False, _('Connection error: %s') % ex)

        return (True, _('OK'))
# okay decompyling ./core/devices/pos/ebillet/ebillet.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:59 CST
