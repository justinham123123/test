# 2017.08.13 21:48:21 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\audio\dolby\dolby_cp750.py
from datetime import datetime
from serv.core.devices.base.audio_controller import AudioController
from telnetlib import Telnet
from threading import RLock
import re as reg
import time
import logging

class DolbyCP750(AudioController):
    PROMPT = '\n\n'
    inputs = [{'id': 'analog',
      'text': 'Analog'},
     {'id': 'dig_1',
      'text': 'Dig 1'},
     {'id': 'dig_2',
      'text': 'Dig 2'},
     {'id': 'dig_3',
      'text': 'Dig 3'},
     {'id': 'dig_4',
      'text': 'Dig 4'},
     {'id': 'last',
      'text': 'Last'},
     {'id': 'mic',
      'text': 'Mic'},
     {'id': 'non_sync',
      'text': 'Non Sync'}]

    def __init__(self, uuid, device_info):
        super(DolbyCP750, self).__init__(uuid, device_info)
        self.lock = RLock()
        self.states = {'mute': {'command': 'cp750.sys.mute',
                  'convert': lambda x: bool(int(x)),
                  'value': None,
                  'requesting': False},
         'input': {'command': 'cp750.sys.input_mode',
                   'convert': lambda x: self.lookup_input(x),
                   'value': None,
                   'requesting': False},
         'volume': {'command': 'cp750.sys.fader',
                    'convert': lambda x: int(x),
                    'value': None,
                    'requesting': False},
         'serial': {'command': 'cp750.sys.serial_number',
                    'convert': None,
                    'value': None,
                    'requesting': False},
         'version': {'command': 'cp750.sysinfo.version',
                     'convert': None,
                     'value': None,
                     'requesting': False},
         'time': {'command': 'cp750.sys.time',
                  'convert': lambda x: float(time.mktime(datetime.strptime(x, '%a %b %d %X %Y').timetuple())),
                  'value': None,
                  'requesting': False}}
        self.device_information['inputs'] = self.inputs
        self.telnet = Telnet()
        return

    def lookup_input(self, input_id):
        for input in self.inputs:
            if input['id'] == input_id:
                return input

    def get_device_status(self):
        output = {'error_messages': []}
        self.update_state('input')
        self.update_state('mute')
        self.update_state('volume')
        return output

    def test_management_connection(self):
        success, result = self.execute(self.states['time']['command'])
        return (success, result)

    def get_device_version_information(self):
        response = {'error_messages': []}
        response['software_version'] = self.get_state('version')
        return response

    def get_device_information(self):
        response = {'error_messages': []}
        response['software_version'] = self.get_device_version_information()['software_version']
        response['serial'] = self.get_serial()
        return response

    def get_input_options(self):
        return self.inputs

    def get_serial(self):
        return self.get_state('serial')

    def get_input(self):
        return self.get_state('input')

    def set_input(self, mode):
        return self.set_state('input', mode)

    def get_volume(self):
        return self.get_state('volume')

    def set_volume(self, volume):
        return self.set_state('volume', str(volume))

    def get_mute(self):
        return self.get_state('mute')

    def set_mute(self, mute):
        return self.set_state('mute', int(mute))

    def update_state(self, state):
        if not self.states[state]['requesting']:
            command = self.states[state]['command'] + ' ?'
            self.states[state]['requesting'] = True
            success, re = self.execute(command)
            self.states[state]['requesting'] = False
            if success:
                re = reg.sub(command, '', re)
                if self.states[state]['convert']:
                    re = self.states[state]['convert'](re)
                self.states[state]['value'] = re

    def set_state(self, state, value):
        command = self.states[state]['command'] + ' ' + str(value)
        success, re = self.execute(command)
        if success:
            success = re == command
        if success:
            if self.states[state]['convert']:
                value = self.states[state]['convert'](value)
            self.states[state]['value'] = value
        return success

    def get_state(self, state):
        return self.states[state]['value']

    def execute(self, command):
        success = True
        with self.lock:
            try:
                self.telnet.open(self.device_configuration['ip'], self.device_configuration['port'], 30)
            except Exception as ex:
                logging.error('Error telnetting [%s] to CP750: %s', command, ex)
                return (False, 'Error: %s' % ex)

            self.telnet.write(command.encode('ascii') + '\r\n'.encode('ascii'))
            re = self.telnet.read_until(self.PROMPT, timeout=30)
            self.telnet.close()
        if not re:
            success = False
            return (success, None)
        else:
            re = reg.sub(self.PROMPT, '', re)
            return (success, re)


if __name__ == '__main__':
    con = DolbyCP750('', {'ip': '10.58.4.236',
     'port': '61408'})
    print con.set_volume(80)
# okay decompyling ./core/devices/audio/dolby/dolby_cp750.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:22 CST
