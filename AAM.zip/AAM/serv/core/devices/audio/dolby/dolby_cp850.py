# 2017.08.13 21:48:22 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\audio\dolby\dolby_cp850.py
import logging
from serv.lib.network.soap_utils import SOAPError
from serv.core.devices.sms.dolby.dolby_utils import DolbySOAPClient, check_response
from serv.core.devices.base.audio_controller import AudioController

class DolbyCP850(AudioController):

    def __init__(self, uuid, device_info):
        super(DolbyCP850, self).__init__(uuid, device_info)
        self.client = DolbySOAPClient(self.device_configuration['ip'], self.device_configuration['port'])
        self.states = {'volume': None,
         'input': None,
         'mute': None}
        return

    def get_device_information(self):
        response = {'error_messages': []}
        response.update(self.get_device_version_information())
        return response

    def test_management_connection(self):
        response = self.get_device_version_information()
        bad = len(response['error_messages']) > 0
        return (bad, response['error_messages'][0] if bad else 'OK')

    def get_device_version_information(self):
        response = {'error_messages': []}
        result = self.execute('getDeviceInfo')
        if check_response(result):
            for kvp in result['keyValuePair']:
                if kvp['key'] == 'Software Version':
                    response['software_version'] = kvp['value']

        else:
            response['error_messages'].append(result['error_message'])
        return response

    def get_device_status(self):
        output = {'error_messages': []}
        self.device_information['inputs'] = self.get_input_options()
        self.update_input()
        self.update_mute()
        self.update_volume()
        return output

    def get_input_options(self):
        result = self.execute('listMacros')
        inputs = []
        if check_response(result):
            for macro in result['macros']:
                inputs.append({'id': int(macro['id']) + 1,
                 'text': macro['name']})

        return inputs

    def update_input(self):
        result = self.execute('getCurrentMacro')
        if check_response(result):
            self.states['input'] = {'id': int(result['macro']['id']) + 1,
             'text': result['macro']['name']}

    def get_input(self):
        return self.states['input']

    def set_input(self, input_id):
        input_id = str(int(input_id) - 1)
        return self.execute('setCurrentMacro', params={'id': input_id})

    def update_volume(self):
        result = self.execute('getGain')
        if check_response(result):
            self.states['volume'] = int(result['gain'])

    def get_volume(self):
        return self.states['volume']

    def set_volume(self, volume):
        return self.execute('setGain', params={'gain': str(volume)})

    def update_mute(self):
        result = self.execute('getMute')
        if check_response(result):
            self.states['mute'] = result['isMuted'] == 'true'

    def get_mute(self):
        return self.states['mute']

    def set_mute(self, mute):
        return self.execute('setMute', params={'shouldBeMuted': str(mute).lower()})

    def execute(self, method, params = None, version = '1_0'):
        path = '/cp/ws/smi/v1/services/SystemManagement/' + method
        action = '/cp/ws/smi/v1/' + method
        namespaces = {'ns0': 'http://www.dolby.com/cp/ws/smi/v' + version}
        try:
            return self.client.request(path, method, action, namespaces=namespaces, params=params)
        except SOAPError as e:
            logging.error('Error on CP850 [{0}] sending command {1}: {2}', self.device_configuration['ip'], method, str(e))


if __name__ == '__main__':
    # con = DolbyCP850('', {'ip': '10.88.2.29', 'port': '9090'})
    con = DolbyCP850('', {'ip': '192.168.1.239', 'port': '9090'})
# okay decompyling ./core/devices/audio/dolby/dolby_cp850.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:22 CST
