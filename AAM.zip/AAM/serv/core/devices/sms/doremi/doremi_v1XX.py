# 2017.08.13 21:49:41 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\doremi\doremi_v1XX.py
"""
A set of functions and classes that implement communication to a Doremi DCP2000 screen server
"""
import os
from serv.core.devices.sms.doremi import doremi
from serv.core.devices.sms.doremi.doremi_commands import GET_CPL_PACKAGE_URI

class DCP2000_v1XX(doremi.DCP2000):
    """
    Doremi DCP2000 screen server access and control
    """

    def __init__(self, id, device_info):
        super(DCP2000_v1XX, self).__init__(id, device_info)

    def get_ingest_path(self, content_uuid):
        package_uri = self._execute_command(GET_CPL_PACKAGE_URI, content_uuid)
        return os.path.split(package_uri['Uri'])[0] + '/' + content_uuid + '.xml'
# okay decompyling ./core/devices/sms/doremi/doremi_v1XX.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:41 CST
