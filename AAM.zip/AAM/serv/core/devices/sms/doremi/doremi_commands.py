# 2017.08.13 21:49:38 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\doremi\doremi_commands.py
"""
Implementations of the Doremi remote API commands
"""
from serv.core.devices.sms.doremi import doremi_handlers
INGEST_ADD_JOB = ((7, 15, 0),
 (7, 16, 0),
 doremi_handlers.ingest_add_job_request_handler,
 doremi_handlers.ingest_add_job_response_handler)
GET_CPL_INFO = ((1, 3, 0),
 (1, 4, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.get_cpl_info_response_handler)
INGEST_CANCEL_JOB = ((7, 23, 0),
 (7, 24, 0),
 doremi_handlers.ingest_cancel_job_request_handler,
 doremi_handlers.response_handler)
INGEST_REMOVE_JOB = ((7, 17, 0),
 (7, 18, 0),
 doremi_handlers.ingest_remove_job_request_handler,
 doremi_handlers.response_handler)
INGEST_GET_JOB_LIST = ((7, 35, 0),
 (7, 36, 0),
 None,
 doremi_handlers.ingest_get_job_list_response_handler)
INGEST_GET_JOB_STATUS = ((7, 29, 0),
 (7, 30, 0),
 doremi_handlers.ingest_get_job_request_handler,
 doremi_handlers.ingest_get_job_status_response_handler)
INGEST_GET_JOB_PROPERTIES = ((7, 27, 0),
 (7, 28, 0),
 doremi_handlers.ingest_get_job_request_handler,
 doremi_handlers.get_spl_xml_response_handler)
RETRIEVE_CPL = ((1, 7, 0),
 (1, 8, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.retrieve_cpl_response_handler)
GET_CPL_LIST = ((1, 1, 0),
 (1, 2, 0),
 None,
 doremi_handlers.get_uuid_list_response_handler)
GET_CPL_SIZE = ((1, 13, 0),
 (1, 14, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.get_cpl_size_response_handler)
VALIDATE_CPL = ((1, 11, 0),
 (1, 12, 0),
 doremi_handlers.validate_item_request_handler,
 doremi_handlers.validate_cpl_response_handler)
DELETE_CPL = ((1, 5, 0),
 (1, 6, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.response_handler)
GET_KDM_LIST = ((2, 1, 0),
 (2, 2, 0),
 None,
 doremi_handlers.get_uuid_list_response_handler)
GET_KDM_INFO = ((2, 3, 0),
 (2, 4, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.get_kdm_info_response_handler)
DELETE_KDM = ((2, 5, 0),
 (2, 6, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.response_handler)
RETRIEVE_KDM = ((2, 7, 0),
 (2, 8, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.retrieve_kdm_response_handler)
STORE_KDM = ((2, 9, 0),
 (2, 10, 0),
 doremi_handlers.store_kdm_request_handler,
 doremi_handlers.response_handler,
 90)
SHOW_PLAYLIST_STATUS = ((3, 27, 0),
 (3, 28, 0),
 None,
 doremi_handlers.show_playlist_status_response_handler)
SHOW_PLAYLIST_STATUS_2 = ((3, 27, 1),
 (3, 28, 1),
 doremi_handlers.show_playlist_status_2_request_handler,
 doremi_handlers.show_playlist_status_2_response_handler)
GET_SPL_LIST = ((3, 1, 0),
 (3, 2, 0),
 None,
 doremi_handlers.get_uuid_list_response_handler)
GET_SPL_INFO = ((3, 3, 0),
 (3, 4, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.get_spl_info_response_handler)
DELETE_SPL = ((3, 5, 0),
 (3, 6, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.response_handler)
LOAD_SPL_BY_UUID = ((3, 9, 0),
 (3, 10, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.response_handler)
CHECK_SPL_LOAD_PROGESS = ((3, 49, 0),
 (3, 50, 0),
 None,
 doremi_handlers.load_spl_progess_handler)
PLAY_SPL = ((3, 11, 0),
 (3, 12, 0),
 None,
 doremi_handlers.response_handler)
PAUSE_SPL = ((3, 13, 0),
 (3, 14, 0),
 None,
 doremi_handlers.response_handler)
EJECT_SPL = ((3, 15, 0),
 (3, 16, 0),
 None,
 doremi_handlers.response_handler)
SKIP_FORWARD = ((3, 17, 0),
 (3, 18, 0),
 None,
 doremi_handlers.response_handler)
SKIP_BACKWARD = ((3, 19, 0),
 (3, 20, 0),
 None,
 doremi_handlers.response_handler)
SKIP_TO_EVENT = ((3, 33, 0),
 (3, 34, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.response_handler)
JUMP_FORWARD = ((3, 21, 0),
 (3, 22, 0),
 doremi_handlers.get_jump_request_handler,
 doremi_handlers.response_handler)
JUMP_BACKWARD = ((3, 23, 0),
 (3, 24, 0),
 doremi_handlers.get_jump_request_handler,
 doremi_handlers.response_handler)
RETRIEVE_SPL = ((3, 29, 0),
 (3, 30, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.get_spl_xml_response_handler)
LOOP_MODE_SPL = ((3, 25, 0),
 (3, 26, 0),
 doremi_handlers.loop_mode_spl_request_handler,
 doremi_handlers.response_handler)
STORE_SPL = ((3, 31, 0),
 (3, 32, 0),
 doremi_handlers.store_spl_request_handler,
 doremi_handlers.response_handler)
VALIDATE_SPL = ((3, 37, 0),
 (3, 38, 0),
 doremi_handlers.validate_item_request_handler,
 doremi_handlers.validate_spl_response_handler)
GET_SHOW_ELEMENT_STATUS = ((0, 3, 43),
 (0, 3, 44),
 None,
 doremi_handlers.response_handler)
GET_LOOP_MODE_SPL = ((3, 35, 0),
 (3, 36, 0),
 None,
 doremi_handlers.get_loop_mode_spl_response_handler)
GET_PRODUCT_INFORMATION = ((5, 1, 0),
 (5, 2, 0),
 None,
 doremi_handlers.get_product_information_response_handler)
GET_PRODUCT_CERTIFICATE = ((5, 3, 0),
 (5, 4, 0),
 doremi_handlers.get_product_certificate_request_handler,
 doremi_handlers.get_product_certificate_response_handler)
CERT_TYPE_JP2K_CURRENT = 0
CERT_TYPE_MPEG2 = 1
API_PROTOCOL_VERSION = ((5, 5, 0),
 (5, 6, 0),
 None,
 doremi_handlers.api_protocol_version_response_handler)
INGEST_GET_EVENT_LIST = ((7, 1, 0),
 (7, 2, 0),
 None,
 doremi_handlers.ingest_get_event_list_response_handler)
INGEST_GET_EVENT_INFO = ((7, 3, 0),
 (7, 4, 0),
 doremi_handlers.ingest_get_event_info_request_handler,
 doremi_handlers.ingest_get_event_info_response_handler)
INGEST_REMOTE_PACKING_LIST = ((7, 5, 0),
 (7, 6, 0),
 doremi_handlers.ingest_remote_packing_list_request_handler,
 doremi_handlers.response_handler)
INGEST_CANCEL = ((7, 7, 0),
 (7, 8, 0),
 None,
 doremi_handlers.response_handler)
INGEST_GET_STATUS = ((7, 9, 0),
 (7, 10, 0),
 None,
 doremi_handlers.ingest_get_status_response_handler)
GET_DATA_DISK_SPACE_USAGE = ((8, 1, 0),
 (8, 2, 0),
 None,
 doremi_handlers.get_data_disk_space_usage_response_handler)
GET_SM_LOG = ((12, 1, 0),
 (13, 2, 0),
 doremi_handlers.get_sm_log_request_handler,
 doremi_handlers.get_sm_log_response_handler,
 300)
GET_MACRO_CUE_LIST = ((10, 1, 0),
 (10, 2, 0),
 None,
 doremi_handlers.get_uuid_list_response_handler)
GET_MACRO_CUE_INFO = ((10, 3, 0),
 (10, 4, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.get_macro_cue_info_response_handler)
EXECUTE_MACRO_CUE = ((10, 1, 0),
 (10, 2, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.execute_macro_cue_response_handler)
GET_TRIGGER_CUE_LIST = ((10, 5, 0),
 (10, 6, 0),
 None,
 doremi_handlers.get_uuid_list_response_handler)
GET_TRIGGER_CUE_INFO = ((10, 7, 0),
 (10, 8, 0),
 doremi_handlers.uuid_request_handler,
 doremi_handlers.get_trigger_cue_info_response_handler)
SNMP_GET = ((8, 3, 0),
 (8, 4, 0),
 doremi_handlers.snmp_get_request_handler,
 doremi_handlers.snmp_get_response_handler)
ADD_SCHEDULE = ((4, 1, 0),
 (4, 2, 0),
 doremi_handlers.add_schedule_request_handler,
 doremi_handlers.add_schedule_response_handler)
ADD_SCHEDULE2 = ((4, 1, 1),
 (4, 2, 1),
 doremi_handlers.add_schedule2_request_handler,
 doremi_handlers.add_schedule_response_handler)
DELETE_SCHEDULE = ((4, 3, 0),
 (4, 3, 0),
 doremi_handlers.delete_schedule_list_request_handler,
 doremi_handlers.response_handler)
GET_SCHEDULE_LIST = ((4, 5, 0),
 (4, 6, 0),
 doremi_handlers.get_schedule_list_request_handler,
 doremi_handlers.get_schedule_list_response_handler)
GET_SCHEDULE_INFO = ((4, 7, 0),
 (4, 8, 0),
 doremi_handlers.get_schedule_info_request_handler,
 doremi_handlers.get_schedule_info_response_handler)
GET_SCHEDULE_INFO2 = ((4, 7, 1),
 (4, 8, 1),
 doremi_handlers.get_schedule_info_request_handler,
 doremi_handlers.get_schedule_info2_response_handler)
GET_CURRENT_SCHEDULE = ((4, 9, 0),
 (4, 10, 0),
 None,
 doremi_handlers.get_long_response_handler)
GET_NEXT_SCHEDULE = ((4, 11, 0),
 (4, 12, 0),
 None,
 doremi_handlers.get_long_response_handler)
GET_TIME_UTC = ((5, 7, 0),
 (5, 8, 0),
 doremi_handlers.get_time_utc_request_handler,
 doremi_handlers.get_time_utc_response_handler)
GET_SCHEDULER_ENABLE = ((4, 15, 0),
 (4, 16, 0),
 None,
 doremi_handlers.get_scheduler_response_handler)
SET_SCHEDULER_ENABLE = ((4, 13, 0),
 (4, 14, 0),
 doremi_handlers.set_scheduler_request_handler,
 doremi_handlers.response_handler)
GET_ASSET_LIST = ((6, 1, 0),
 (6, 2, 0),
 None,
 doremi_handlers.get_asset_list_response_handler)
GET_ASSET_INFO = ((6, 3, 0),
 (6, 4, 0),
 doremi_handlers.get_asset_info_request_handler,
 doremi_handlers.get_asset_info_response_handler)
GET_ASSET_PARENT = ((6, 11, 0),
 (6, 12, 0),
 doremi_handlers.get_asset_parent_request_handler,
 doremi_handlers.get_asset_parent_response_handler)
GET_ASSET_URL = ((6, 9, 0),
 (6, 10, 0),
 doremi_handlers.get_asset_url_request_handler,
 doremi_handlers.get_asset_url_response_handler)
RETRIEVE_ASSET_XML = ((6, 5, 0),
 (6, 6, 0),
 doremi_handlers.retrieve_asset_xml_request_handler,
 doremi_handlers.retrieve_asset_xml_response_handler)
GET_CPL_PACKAGE_URI = ((6, 13, 0),
 (6, 14, 0),
 doremi_handlers.get_cpl_package_uri_request_handler,
 doremi_handlers.get_cpl_package_uri_response_handler)
EXECUTE_MACRO_CUE = ((10, 9, 0),
 (10, 10, 0),
 doremi_handlers.execute_macro_cue_request_handler,
 doremi_handlers.execute_macro_cue_response_handler)
GET_CPL_MARKER = ((1, 15, 0),
 (1, 16, 0),
 doremi_handlers.get_cpl_marker_request_handler,
 doremi_handlers.get_cpl_marker_response_handler)
TERMINATE_TLS = ((14, 5, 0),
 (14, 6, 0),
 None,
 doremi_handlers.terminate_tls_response_handler)
INGEST_GET_LOG_EVENT_COUNT = ((7, 31, 0),
 (7, 32, 0),
 doremi_handlers.ingest_get_log_event_count_request_handler,
 doremi_handlers.ingest_get_log_event_count_info_response_handler)
INGEST_GET_LOG_EVENT = ((7, 33, 0),
 (7, 34, 0),
 doremi_handlers.ingest_get_log_event_request_handler,
 doremi_handlers.ingest_get_log_event_response_handler)
SHUTDOWN = ((5, 23, 0),
 (5, 24, 0),
 doremi_handlers.shutdown_request_handler,
 doremi_handlers.response_handler)
# okay decompyling ./core/devices/sms/doremi/doremi_commands.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:38 CST
