# 2017.08.13 21:49:58 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\sony\sony_sms.py
"""
Python wrapper for the Sony API
"""
import logging
import posixpath
import re
import uuid
from collections import defaultdict
from datetime import date, datetime, timedelta
from string import Template
from StringIO import StringIO
from xml.dom import minidom
from zipfile import ZipFile
import cherrypy
from serv.lib.utilities import xml_utils
from serv.lib.utilities.date_utils import parse_date, parse_simple_duration, seconds_to_simple_duration
from serv.lib.dcinema.dcp.dcp import DCP
from serv.lib.dcinema.dcp.file_handlers import AbstractHandler
from serv.lib.dcinema.parsers.parsers import parse_content_title_text, parse_kdm
from serv.lib.dcinema.parsers.certificate_parsers import parse_device_certificates
from serv.lib.utilities.utils import strip_urn, wrap_urn, certificate_regex
from serv.configuration.constants import HFR_FPS
from serv.lib.utilities import helper_methods
from serv.core.devices.base.scheduling import Scheduling
from serv.core.devices.sms.sony.sony import SonyDevice
from serv.core.devices.sms.sony.sony_utils import SonyError
from serv.core.devices.sms.shared import trans
from serv.lib.cherrypy.i18n_tool import ugettext as _
ASPECT_RATIO = {(1998, 1080): ('F', '2K'),
 (3996, 2160): ('F', '4K'),
 (2048, 8585): ('S', '2K'),
 (4096, 1716): ('S', '4K'),
 (2048, 1080): ('C', '2K'),
 (4096, 2160): ('C', '4K')}
RAID_STATUS_OK = 'NORMAL'
HDD_STATUS_OK = 'GOOD'
PLAYBACK_STATE = {'STOPPED': 'stop',
 'COMPLETED': 'stop',
 'PAUSED': 'pause',
 'PLAYING': 'play'}
TRANSFER_STATE = {'CANCELLED': 'cancelled',
 'IMPORTING': 'active',
 'VALIDATING': 'verifying',
 'SUCCESSFUL': 'success',
 'PAUSED': 'paused',
 'WAITING': 'queued_on_device',
 'ERROR': 'failed'}
STATIC_AUTOMATION = {'AUDIO_ON': {'name': 'Audio On',
              'type': 'sony_cue',
              'duration': 1},
 'AUDIO_OFF': {'name': 'Audio Off',
               'type': 'sony_cue',
               'duration': 1},
 'PREPROCESS_CUE': {'name': 'PreProcessCue',
                    'type': 'sony_cue',
                    'duration': 1},
 'POSTPROCESS_CUE': {'name': 'PostProcessCue',
                     'type': 'sony_cue',
                     'duration': 1},
 'SHUTTER_ON': {'name': 'Douser Closed',
                'type': 'sony_cue',
                'duration': 1},
 'SHUTTER_OFF': {'name': 'Douser Open',
                 'type': 'sony_cue',
                 'duration': 1},
 'POWER_ON': {'name': 'Power On',
              'type': 'sony_cue',
              'duration': 1},
 'POWER_LAMP-OFF': {'name': 'Lamp Off',
                    'type': 'sony_cue',
                    'duration': 1},
 'POWER_STANDBY': {'name': 'Power Standby',
                   'type': 'sony_cue',
                   'duration': 1},
 'GHOSTBUSTER_ON': {'name': 'Ghostbuser On',
                    'type': 'sony_cue',
                    'duration': 1},
 'GHOSTBUSTER_OFF': {'name': 'Ghostbuster Off',
                     'type': 'sony_cue',
                     'duration': 1},
 'INTERMISSION': {'name': 'Sony Intermission',
                  'type': 'intermission',
                  'duration': 1}}
STATIC_AUTOMATION_INFO = {'AUDIO_ON': {'target': 'Media Block',
              'command': 'Audio : On',
              'parameter_name': 'audio',
              'parameter_value': 'on'},
 'AUDIO_OFF': {'target': 'Media Block',
               'command': 'Audio : Off',
               'parameter_name': 'audio',
               'parameter_value': 'off'},
 'PREPROCESS_CUE': {'target': 'Media Block',
                    'command': 'PreProcessCue',
                    'parameter_name': None,
                    'parameter_value': None},
 'POSTPROCESS_CUE': {'target': 'Media Block',
                     'command': 'PostProcessCue',
                     'parameter_name': None,
                     'parameter_value': None},
 'SHUTTER_ON': {'target': 'Projector',
                'command': 'Douser : Closed',
                'parameter_name': 'shutter',
                'parameter_value': 'on'},
 'SHUTTER_OFF': {'target': 'Projector',
                 'command': 'Douser : Open',
                 'parameter_name': 'shutter',
                 'parameter_value': 'off'},
 'POWER_ON': {'target': 'Projector',
              'command': 'Power : On',
              'parameter_name': 'power',
              'parameter_value': 'on'},
 'POWER_LAMP-OFF': {'target': 'Projector',
                    'command': 'Lamp : Off',
                    'parameter_name': 'power',
                    'parameter_value': 'lamp-off'},
 'POWER_STANDBY': {'target': 'Projector',
                   'command': 'Power : Standby',
                   'parameter_name': 'power',
                   'parameter_value': 'standby'},
 'GHOSTBUSTER_ON': {'target': 'Projector',
                    'command': 'Ghostbuster : On',
                    'parameter_name': 'ghostbuster',
                    'parameter_value': 'on'},
 'GHOSTBUSTER_OFF': {'target': 'Projector',
                     'command': 'Ghostbuster : Off',
                     'parameter_name': 'ghostbuster',
                     'parameter_value': 'off'}}
SONY_MESSAGE_WRAPPER = Template('\n<SMSMessage>\n    <MessageHeader>\n        <Id>$id</Id>\n        <Type>$message_type</Type>\n        <Timestamp>$timestamp</Timestamp>\n        <Source>$source</Source>\n    </MessageHeader>\n    <MessageBody>\n        $message_contents\n    </MessageBody>\n</SMSMessage>\n')

def _build_sony_message(message_type, message_contents, id = -1, timestamp = 0, source = 'AAM'):
    """
    Builds an XML message document for a Sony SMS
    """
    return SONY_MESSAGE_WRAPPER.substitute(id=id, timestamp=timestamp, source=source, message_type=message_type, message_contents=message_contents)


SONY_COMMAND_MESSAGE = Template('\n<Command>\n    <Operation>$operation</Operation>\n    <ParameterList>\n        $parameters\n    </ParameterList>\n</Command>\n')
SONY_COMMAND_MESSAGE_PARAMETER = Template('\n<Parameter>\n    <Name>$name</Name>\n    <Value>$value</Value>\n</Parameter>\n')

def _build_command_message(operation, parameters = {}):
    parameter_string = ''.join([ SONY_COMMAND_MESSAGE_PARAMETER.substitute(name=name, value=value) for name, value in parameters.iteritems() ])
    message_contents = SONY_COMMAND_MESSAGE.substitute(operation=operation, parameters=parameter_string)
    return _build_sony_message('Command', message_contents)


SONY_SCHEDULE_MESSAGE = Template('\n<ShowScheduleUpdateList>\n    <ShowScheduleUpdateItem>\n        <Action>$action</Action>\n        <Date>$date</Date>\n        <ShowScheduleDayItem>\n            $schedule_id\n            <Time>$time</Time>\n            <ShowId>urn:uuid:$playlist_uuid</ShowId>\n            $wait_for_trigger\n        </ShowScheduleDayItem>\n    </ShowScheduleUpdateItem>\n</ShowScheduleUpdateList>\n')

def _build_schedule_message(action, start_datetime, playlist_uuid, schedule_id = None):
    message_contents = SONY_SCHEDULE_MESSAGE.substitute(action=action, schedule_id='' if schedule_id is None else '<ScheduleId>urn:uuid:%s</ScheduleId>' % schedule_id, date=start_datetime.strftime('%Y-%m-%d'), time=start_datetime.strftime('%H:%M:%S'), playlist_uuid=playlist_uuid, wait_for_trigger='<WaitForTrigger>false</WaitForTrigger>' if action == 'Add' else '')
    return _build_sony_message('ShowScheduleUpdateList', message_contents)


SONY_TRANSFER_MESSAGE = Template('\n<S2sTransfer>\n    <SourceURI>$uri</SourceURI>\n    <Id>urn:uuid:$pkl_uuid</Id>\n    <TargetMode>DCP</TargetMode>\n    <ServerType>Unknown</ServerType>\n    <Validate>$validate</Validate>\n</S2sTransfer>\n')

def _build_transfer_message(uri, pkl_uuid, validate = True):
    message_contents = SONY_TRANSFER_MESSAGE.substitute(uri=uri, pkl_uuid=pkl_uuid, validate='true' if validate else 'false')
    return _build_sony_message('S2sTransfer', message_contents)


class SonySMS(SonyDevice, Scheduling):
    """
    Implements a Sony SMS API interface
    """
    supported_modes = {'loop_modes': [],
     'schedule_modes': ['schedule_on', 'schedule_off']}

    def __init__(self, device_id, device_info):
        super(SonySMS, self).__init__(device_id, device_info)
        self.eject_required = False
        self.cached_schedule_info = {}

    def _get_server_info(self):
        """
        Returns information regarding the Sony server
        """
        dom = self._http_request('config/device/attributes?device=SMS')
        output = {}
        output['model'] = xml_utils.get_element_value(dom, 'Model')
        output['software_version'] = xml_utils.get_element_value(dom, 'Version')
        output['serial'] = xml_utils.get_element_value(dom, 'SerialNum')
        return output

    def _get_certificates(self):
        """
        Get the certificate of the server
        """
        cert_text = self._http_request('command/mediablock/certificate/download?index=1')
        match = certificate_regex.search(cert_text)
        certs = []
        while match:
            certs.append(match.group(0))
            match = certificate_regex.search(cert_text, match.end())

        return certs

    def _get_raid_status(self):
        """
        Returns information about the status of the server's RAID array
        """
        dom = self._http_request('status/storage/hdd')
        output = {}
        output['RAID'] = xml_utils.get_element_value(dom, 'RAIDStatus') == RAID_STATUS_OK
        for hdd_el in dom.getElementsByTagName('HDDStatus'):
            name = xml_utils.get_element_value(hdd_el, 'Name')
            output[name] = {'status': xml_utils.get_element_value(hdd_el, 'Status') == HDD_STATUS_OK,
             'is_spare': xml_utils.get_element_value(hdd_el, 'IsSpareSlot') == 'true'}

        return output

    def _get_disk_usage(self):
        dom = self._http_request('status/storage/info')
        output = {}
        for file_system_el in dom.getElementsByTagName('MBStorageUsage'):
            name = xml_utils.get_element_value(file_system_el, 'FileSystem')
            output[name] = {'total': int(xml_utils.get_element_value(file_system_el, 'TotalCapacity')),
             'used': int(xml_utils.get_element_value(file_system_el, 'SpaceInUse')),
             'free': int(xml_utils.get_element_value(file_system_el, 'FreeSpace'))}

        return output

    def _get_kdm_uuids(self):
        """
        Returns a list of KDM UUIDs
        """
        dom = self._http_request('content/kdm/info/list')
        kdm_uuids = []
        for kdm_el in dom.getElementsByTagName('KDMItem'):
            for kdmid in xml_utils.get_element_value_list(kdm_el, 'KDMID'):
                uuid = strip_urn(kdmid)
                kdm_uuids.append(uuid)

        return kdm_uuids

    def _get_kdm(self, kdm_uuid):
        """
        Returns the raw xml for the specified KDM
        """
        response = self._http_request('/content/kdm/info?Id=%s' % wrap_urn(kdm_uuid))
        return response

    def _get_cpl_uuids(self):
        """
        Returns a list of CPL UUIDs on the server
        """
        dom = self._http_request('content/cpl/info/list?detailed=false')
        cpl_uuids = [ strip_urn(x) for x in xml_utils.get_element_value_list(dom, 'CPLID') ]
        return cpl_uuids

    def _get_dcp_to_cpl_map(self):
        """
        Uses the storage path from detailed CPL info to map CPLs from their DCP UUIDs (the UUID is in the storage path)
        """
        dcp_cpl_map = defaultdict(dict)
        cpl_info_list = self._http_request('content/cpl/info/list?detailed=true')
        for cpl_el in cpl_info_list.getElementsByTagName('CPLDetails'):
            cpl_uuid = strip_urn(xml_utils.get_element_value(cpl_el, 'ID'))
            cpl_path = xml_utils.get_element_value(cpl_el, 'Path')
            path_parts = cpl_path.split('/')
            try:
                dcp_root_index = path_parts.index('dcp')
                dcp_uuid = path_parts[dcp_root_index + 1]
                cpl_filename = path_parts[dcp_root_index + 2]
            except (ValueError, IndexError):
                pass
            else:
                dcp_cpl_map[dcp_uuid][cpl_uuid] = cpl_filename

        return dcp_cpl_map

    def _get_cpl_dcp_uuid(self, content_uuid):
        """
        Returns the DCP UUID for a CPL by parsing its storage path
        """
        cpl_info = self._http_request('content/cpl/info?Id=urn:uuid:%s' % content_uuid)
        cpl_path = xml_utils.get_element_value(cpl_info, 'Path')
        path_parts = cpl_path.split('/')
        try:
            dcp_root_index = path_parts.index('dcp')
            dcp_uuid = path_parts[dcp_root_index + 1]
        except (ValueError, IndexError):
            raise ValueError('CPL %s storage path cannot be parsed for DCP UUID' % content_uuid)
        else:
            return dcp_uuid

    def _get_playlist_uuids(self):
        playlist_uuids = self._http_request('show/playlist/info/list', elements=['UUID'])
        playlist_uuids = [ strip_urn(x) for x in playlist_uuids ]
        return playlist_uuids

    def _get_playlist(self, playlist_uuid):
        """
        Gets a playlist's xml representation
        NOTE: Returns pre-parsed DOM object unlike similar functions in the other server implementations
        """
        dom = self._http_request('show/playlist/details/info?Id=%s' % wrap_urn(playlist_uuid))
        return dom.getElementsByTagName('ShowPlaylist')[0]

    def _parse_playlist(self, playlist_dom):
        playlist_id = strip_urn(xml_utils.get_element_value(playlist_dom, 'Id'))
        meta_dom = xml_utils.get_child_by_tag(playlist_dom, 'Metadata')
        playlist_title = xml_utils.get_element_value(meta_dom, 'Title')
        playlist_text = xml_utils.get_element_value(meta_dom, 'Annotation')
        playlist_is_3d = False
        playlist_is_hfr = False
        playlist_is_4k = False
        playlist_duration = 0
        events = []
        automation = []
        content_dom = xml_utils.get_child_by_tag(playlist_dom, 'Content')
        offset = 0

        def gen_pattern(duration_in_seconds):
            return {'id': str(uuid.uuid4()),
             'main_id': None,
             'automation': [],
             'type': 'pattern',
             'text': 'Black',
             'edit_rate': [24, 1],
             'duration_in_seconds': duration_in_seconds,
             'duration_in_frames': duration_in_seconds * (24 / 1)}

        for event_dom in xml_utils.get_children_by_tags(content_dom, ['CPLEvent', 'CommandEvent', 'SPLEevent']):
            if event_dom.localName == 'CommandEvent':
                target = xml_utils.get_element_value(event_dom, 'Target')
                try:
                    parameter_dom = event_dom.getElementsByTagName('Parameter')[0]
                except IndexError:
                    parameter = None
                else:
                    parameter = dict(parameter_dom.attributes.items())

                offset_str = xml_utils.get_element_value(event_dom, 'Offset')
                automation_offset = parse_simple_duration(offset_str)
                if parameter is not None and parameter['name'] == 'function':
                    automation_type = 'sony_function'
                    automation_id = parameter['value']
                    automation_name = xml_utils.get_element_value(event_dom, 'Command')[11:]
                elif parameter is not None:
                    automation_type = 'sony_cue'
                    for cue_id, cue_info in STATIC_AUTOMATION_INFO.iteritems():
                        if cue_info['target'] == target and cue_info['parameter_name'] == parameter['name'] and cue_info['parameter_value'] == parameter['value']:
                            automation_id = cue_id
                            automation_name = STATIC_AUTOMATION[automation_id]['name']
                            break
                    else:
                        logging.warning('Unknown Sony command parsed from playlist %s: %s' % (playlist_id, event_dom.toxml()))
                        continue

                else:
                    automation_type = 'sony_cue'
                    automation_id = automation_name = xml_utils.get_element_value(event_dom, 'Command')
                automation.append({'id': automation_id,
                 'name': automation_name,
                 'type': automation_type,
                 'type_specific': {'offset_from': 'start',
                                   'offset_in_seconds': automation_offset,
                                   'action': automation_id}})
            elif event_dom.localName == 'CPLEvent':
                cpl_uuid = strip_urn(xml_utils.get_element_value(event_dom, 'Id'))
                event_offset = parse_simple_duration(xml_utils.get_element_value(event_dom, 'Offset'))
                if event_offset > offset:
                    pattern_duration = event_offset - offset
                    offset += pattern_duration
                    events.append(gen_pattern(pattern_duration))
                try:
                    cpl = cherrypy.core.contents[cpl_uuid]
                except KeyError:
                    content_title_text = None
                    edit_rate = None
                    duration_str = xml_utils.get_element_value(event_dom, 'Duration')
                    duration_in_seconds = parse_simple_duration(duration_str)
                    duration_in_frames = None
                else:
                    content_title_text = cpl['content_title_text']
                    if cpl['edit_rate'] and cpl['edit_rate'][0] is not None and cpl['edit_rate'][1] is not None:
                        edit_rate = (cpl['edit_rate'][0], cpl['edit_rate'][1])
                        playlist_is_hfr |= cpl['edit_rate'][0] > HFR_FPS
                    else:
                        edit_rate = [None, None]
                    duration_in_seconds = float('{0:.3f}'.format(cpl['duration_in_seconds']))
                    duration_in_frames = cpl['duration_in_frames']

                automations = []
                intermission = xml_utils.get_children_by_tags(event_dom, ['Intermission'])
                if intermission:
                    intermission = intermission[0]
                    spl_uuid = strip_urn(xml_utils.get_element_value(event_dom, 'IntervalSPLId'))
                    intermission_offset = parse_simple_duration(xml_utils.get_element_value(event_dom, 'StopPoint'))
                    restart_in_seconds = parse_simple_duration(xml_utils.get_element_value(event_dom, 'RestartPoint'))
                    intermission_duration = parse_simple_duration(xml_utils.get_element_value(event_dom, 'IntervalTime'))
                    spl_title = self.get_playlist_information([spl_uuid])['playlist_info_dict'].get(spl_uuid, {'title': _('Unknown')})['title']
                    automations.append({'id': '0',
                     'name': 'Sony Intermission',
                     'type': 'intermission',
                     'type_specific': {'offset_in_seconds': intermission_offset,
                                       'restart_in_seconds': restart_in_seconds,
                                       'spl_uuid': spl_uuid,
                                       'spl_title': spl_title,
                                       'duration_in_seconds': intermission_duration}})
                events.append({'id': str(uuid.uuid3(uuid.UUID(playlist_id), 'event_%d' % len(events))),
                 'main_id': None,
                 'automation': automations,
                 'cpl_id': cpl_uuid,
                 'type': 'composition',
                 'text': content_title_text,
                 'edit_rate': edit_rate,
                 'duration_in_seconds': duration_in_seconds,
                 'duration_in_frames': duration_in_frames})
                if duration_in_seconds:
                    offset += duration_in_seconds
                    playlist_duration += float(duration_in_seconds)
            elif event_dom.localName == 'SPLEvent':
                spl_uuid = strip_urn(xml_utils.get_element_value(event_dom, 'Id'))
                try:
                    sub_playlist = self.playlist_information[spl_uuid]
                except KeyError:
                    text = None
                    duration_in_seconds = None
                else:
                    text = sub_playlist['title']
                    duration_in_seconds = sub_playlist['duration_in_seconds']

                events.append({'id': str(uuid.uuid3(uuid.UUID(playlist_id), 'event_%d' % len(events))),
                 'main_id': None,
                 'automation': [],
                 'spl_id': spl_uuid,
                 'type': 'playlist',
                 'text': text,
                 'duration_in_seconds': duration_in_seconds,
                 'edit_rate': None,
                 'duration_in_frames': None})
                playlist_duration += duration_in_seconds

        end_pattern = None
        for automation_item in automation:
            cumulative_duration = 0
            for event in events:
                event_duration = event['duration_in_seconds'] if event['duration_in_seconds'] is not None else 0
                if automation_item['type_specific']['offset_in_seconds'] < cumulative_duration + event_duration:
                    automation_item['type_specific']['offset_in_seconds'] -= cumulative_duration
                    if event['type'] in ('composition', 'pattern') and event['edit_rate'] is not None:
                        automation_item['type_specific']['offset_in_frames'] = int(automation_item['type_specific']['offset_in_seconds'] * (1.0 * event['edit_rate'][0] / event['edit_rate'][1]))
                    event['automation'].append(automation_item)
                    break
                else:
                    cumulative_duration += event_duration
            else:
                automation_item['type_specific']['offset_in_seconds'] -= cumulative_duration
                duration = automation_item['type_specific']['offset_in_seconds']
                if not end_pattern:
                    end_pattern = gen_pattern(duration)
                else:
                    end_pattern['duration_in_seconds'] = duration
                automation_item['type_specific']['offset_in_frames'] = int(duration * (1.0 * end_pattern['edit_rate'][0] / end_pattern['edit_rate'][1]))
                end_pattern['automation'].append(automation_item)

        if end_pattern:
            end_pattern['duration_in_frames'] = end_pattern['duration_in_seconds'] * (1.0 * end_pattern['edit_rate'][0] / end_pattern['edit_rate'][1])
            events.append(end_pattern)
        return {'id': playlist_id,
         'title': playlist_title,
         'text': playlist_text,
         'is_3d': playlist_is_3d,
         'is_hfr': playlist_is_hfr,
         'is_4k': playlist_is_4k,
         'duration_in_seconds': playlist_duration,
         'events': events,
         'automation': []}

    def _construct_playlist(self, spl_dict):
        """
        <ShowPlaylist xmlns="http://xmlns.sony.net/d-cinema/spl/2006>
            <Id>urn:uuid:9c28be98-1ecd-4124-a3b1-4fd016b6b9f4</Id>
            <Offset>00:00:00.000</Offset>
            <Duration>00:10:33.000</Duration>
            <DurationWithIntermission>00:10:33.000</DurationWithIntermission>
            <Metadata>
                <Type/>
                <Title>Test</Title>
                <Annotation>This is a test playlist</Annotation>
                <RevisionDate>2012-02-28T10:54:29.252+00:00</RevisionDate>
                <Version/>
                <Language>
                    <Audio/>
                    <Subtitle/>
                </Language>
                <Country/>
                <RatingList/>
                <AspectRatio>-1 -1</AspectRatio>
                <ImageFormat>XYZ</ImageFormat>
                <AudioFormat/>
                <HasIntermission>false</HasIntermission>
            </Metadata>
            <Content>
                <CPLEvent>
                    <Id>urn:uuid:f296a717-f30d-42bd-a238-ad2cc72c4eb3</Id>
                    <Offset>00:00:00.000</Offset>
                    <Duration>00:01:38.000</Duration>
                </CPLEvent>
                <CommandEvent>
                    <Offset>00:01:38.000</Offset>
                    <Duration>00:00:01.000</Duration>
                    <Target>Projector</Target>
                    <Command>Lamp : Off</Command>
                    <Parameter name="power" value="lamp-off" />
                </CommandEvent>
                <CommandEvent>
                    <Offset>00:01:38.000</Offset>
                    <Duration>00:00:01.000</Duration>
                    <Target>Projector</Target>
                    <Command>Lamp : Off</Command>
                    <Parameter name="power" value="lamp-off" />
                </CommandEvent>
                <SPLEvent>
                    <Id>urn:uuid:3f8829a6-e43f-47c7-b577-7d831fa96bc2</Id>
                    <Offset>00:11:30.000</Offset>
                    <Duration>02:22:40.000</Duration>
                </SPLEvent>
            </Content>
        </ShowPlaylist>
        """
        root = minidom.Document()
        spl_element = xml_utils.create_node(root, root, 'ShowPlaylist')
        spl_element.setAttribute('xmlns', 'http://xmlns.sony.net/d-cinema/spl/2006')
        xml_utils.create_node(root, spl_element, 'Id', wrap_urn(spl_dict['id']))
        xml_utils.create_node(root, spl_element, 'Offset', '00:00:00.000')
        xml_utils.create_node(root, spl_element, 'Duration', seconds_to_simple_duration(spl_dict['duration_in_seconds']))
        xml_utils.create_node(root, spl_element, 'DurationWithIntermission', seconds_to_simple_duration(spl_dict['duration_in_seconds']))
        meta_element = xml_utils.create_node(root, spl_element, 'Metadata')
        xml_utils.create_node(root, meta_element, 'Type')
        xml_utils.create_node(root, meta_element, 'Title', spl_dict['title'])
        xml_utils.create_node(root, meta_element, 'Annotation', spl_dict['title'])
        xml_utils.create_node(root, meta_element, 'RevisionDate', datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + '+00:00')
        xml_utils.create_node(root, meta_element, 'Version')
        language_element = xml_utils.create_node(root, meta_element, 'Language')
        xml_utils.create_node(root, language_element, 'Audio')
        xml_utils.create_node(root, language_element, 'Subtitle')
        xml_utils.create_node(root, meta_element, 'Country')
        xml_utils.create_node(root, meta_element, 'RatingList')
        xml_utils.create_node(root, meta_element, 'AspectRatio', '-1 -1')
        xml_utils.create_node(root, meta_element, 'ImageFormat', 'XYZ')
        xml_utils.create_node(root, meta_element, 'AudioFormat')
        xml_utils.create_node(root, meta_element, 'HasIntermission', 'false')
        content_element = xml_utils.create_node(root, spl_element, 'Content')
        offset = 0

        def parse_automations(event, element = None):
            for automation in event['automation']:
                if automation['type'] == 'intermission':
                    if element:
                        intermission_ele = xml_utils.create_node(root, element, 'Intermission')
                        xml_utils.create_node(root, intermission_ele, 'IntervalSPLId', wrap_urn(automation['type_specific']['spl_uuid']))
                        xml_utils.create_node(root, intermission_ele, 'StopPoint', seconds_to_simple_duration(automation['type_specific']['offset_in_seconds']))
                        xml_utils.create_node(root, intermission_ele, 'RestartPoint', seconds_to_simple_duration(automation['type_specific']['restart_in_seconds']))
                        xml_utils.create_node(root, intermission_ele, 'IntervalTime', seconds_to_simple_duration(automation['type_specific']['duration_in_seconds']))
                    continue
                if automation['type_specific']['offset_from'] == 'start':
                    automation_offset = offset + automation['type_specific']['offset_in_seconds']
                elif automation['type_specific']['offset_from'] == 'end':
                    automation_offset = offset + event['duration_in_seconds'] - automation['type_specific']['offset_in_seconds'] if event['duration_in_seconds'] else offset
                if automation['type'] == 'sony_cue':
                    if automation['type_specific']['action'] in STATIC_AUTOMATION_INFO:
                        static_cue_info = STATIC_AUTOMATION_INFO[automation['type_specific']['action']]
                        target = static_cue_info['target']
                        command = static_cue_info['command']
                        parameter = {'name': static_cue_info['parameter_name'],
                         'value': static_cue_info['parameter_value']}
                    else:
                        target = 'Automation System'
                        command = automation['type_specific']['action']
                        parameter = None
                    command_element = xml_utils.create_node(root, content_element, 'CommandEvent')
                    xml_utils.create_node(root, command_element, 'Offset', seconds_to_simple_duration(automation_offset))
                    xml_utils.create_node(root, command_element, 'Duration', '00:00:01.000')
                    xml_utils.create_node(root, command_element, 'Target', target)
                    xml_utils.create_node(root, command_element, 'Command', command)
                    if parameter is not None and parameter['name'] is not None and parameter['value'] is not None:
                        parameter_element = xml_utils.create_node(root, command_element, 'Parameter')
                        parameter_element.setAttribute('name', static_cue_info['parameter_name'])
                        parameter_element.setAttribute('value', static_cue_info['parameter_value'])
                elif automation['type'] == 'sony_function':
                    command_element = xml_utils.create_node(root, content_element, 'CommandEvent')
                    xml_utils.create_node(root, command_element, 'Offset', seconds_to_simple_duration(automation_offset))
                    xml_utils.create_node(root, command_element, 'Duration', '00:00:01.000')
                    xml_utils.create_node(root, command_element, 'Target', 'Projector')
                    xml_utils.create_node(root, command_element, 'Command', 'Function : ' + automation['name'])
                    parameter_element = xml_utils.create_node(root, command_element, 'Parameter')
                    parameter_element.setAttribute('name', 'function')
                    parameter_element.setAttribute('value', automation['type_specific']['action'])

            return

        for event in spl_dict['events']:
            if event['type'] == 'composition':
                cpl_element = xml_utils.create_node(root, content_element, 'CPLEvent')
                xml_utils.create_node(root, cpl_element, 'Id', wrap_urn(event['cpl_id']))
                xml_utils.create_node(root, cpl_element, 'Offset', seconds_to_simple_duration(offset))
                xml_utils.create_node(root, cpl_element, 'Duration', seconds_to_simple_duration(event['duration_in_seconds'] if event['duration_in_seconds'] else 0))
                parse_automations(event, element=cpl_element)
                if event['duration_in_seconds']:
                    offset += event['duration_in_seconds']
            elif event['type'] == 'pattern':
                parse_automations(event)
                if event['duration_in_seconds']:
                    offset += event['duration_in_seconds']
            elif event['type'] == 'playlist':
                sub_spl_element = xml_utils.create_node(root, content_element, 'CPLEvent')
                xml_utils.create_node(root, sub_spl_element, 'Id', wrap_urn(event['spl_uuid']))
                xml_utils.create_node(root, sub_spl_element, 'Offset', seconds_to_simple_duration(offset))
                xml_utils.create_node(root, sub_spl_element, 'Duration', seconds_to_simple_duration(event['duration_in_seconds']))
                offset += event['duration_in_seconds']

        return root.toxml(encoding='utf-8')

    def _get_schedules(self, start = None, end = None):
        if start is None:
            start = date.today() - timedelta(days=14)
        if end is None:
            end = date.today() + timedelta(days=365)
        dom = self._http_request('show/schedule/info/events/list?begin={begin}&end={end}'.format(begin=start.strftime('%Y%m'), end=end.strftime('%Y%m')), timeout=120)
        event_list_dom = xml_utils.get_child_by_tag(dom, 'ShowScheduleEventList')
        schedules = []
        for schedule_dom in xml_utils.get_children_by_tags(event_list_dom, ['ShowScheduleEvent']):
            schedule = {}
            playtime = xml_utils.get_element_value(schedule_dom, 'PlayTime')
            schedule['start_time'] = parse_date(playtime)
            schedule['device_schedule_id'] = strip_urn(xml_utils.get_element_value(schedule_dom, 'ScheduleId'))
            schedule['device_playlist_uuid'] = strip_urn(xml_utils.get_element_value(schedule_dom, 'Id'))
            schedules.append(schedule)

        return schedules

    def get_device_information(self):
        output = {'error_messages': []}
        server_info = self._get_server_info()
        output.update(server_info)
        output.update(parse_device_certificates(self._get_certificates()))
        raid_status = self._get_raid_status()
        output['raid_status'] = [{'name': 'RAID',
          'active': True,
          'degraded': not raid_status['RAID'],
          'status': 'ok' if raid_status['RAID'] else 'error',
          'message': _('OK') if raid_status['RAID'] else _('Error')}]
        disk_usage = self._get_disk_usage()
        output['storage_total'] = disk_usage['DCP']['total']
        output['storage_used'] = disk_usage['DCP']['used']
        output['storage_available'] = disk_usage['DCP']['free']
        return output

    def get_device_version_information(self):
        output = {'error_messages': [],
         'firmware_version': None}
        server_info = self._get_server_info()
        output['software_version'] = server_info['software_version']
        return output

    def server_performance_metrics(self):
        return [self.playback_information['playback_state'], 'transfers: ' + str(len(self.transfer_information.get('transfers', [])))]

    def reboot(self):
        if self.device_information.get('software_version') is not None and self.device_information.get('software_version') >= '2':
            self._http_request('command/sms/shutdown?reboot=true')
        else:
            self._http_request('command/sms/restart')
        return {'error_messages': []}

    def get_key_uuid_list(self):
        output = {'error_messages': [],
         'key_uuid_list': []}
        output['key_uuid_list'] = self._get_kdm_uuids()
        return output

    def get_key_information(self, key_uuids):
        """
        gets key information of a device
        """
        output = {'error_messages': [],
         'key_info_dict': {}}
        for key_uuid in key_uuids:
            kdm_xml = self._http_request('command/mediablock/kdm/download?id=%s' % key_uuid)
            kdm = parse_kdm(kdm_xml, load_from_file=False)
            output['key_info_dict'][key_uuid] = {}
            output['key_info_dict'][key_uuid]['cpl_title'] = kdm['cpl_text']
            output['key_info_dict'][key_uuid]['cpl_uuid'] = kdm['cpl_id']
            output['key_info_dict'][key_uuid]['not_valid_before'] = kdm['start_date']
            output['key_info_dict'][key_uuid]['not_valid_after'] = kdm['end_date']
            output['key_info_dict'][key_uuid]['dnqualifier'] = kdm['dn_qualifier']
            output['key_info_dict'][key_uuid]['status'] = 'ok'

        return output

    def get_key(self, key_uuid):
        """
        gets key xml

        @return
            dict
                xml        DICT
                    xml    STRING
                error_messages          -LIST of errors
        """
        output = {'error_messages': [],
         'xml': {}}
        try:
            output['xml'] = self._http_request('command/mediablock/kdm/download?id=%s' % key_uuid)
        except Exception as ex:
            logging.info('Error getting kdm %s' % key_uuid, exc_info=True)
            output['error_messages'].append(str(ex))

        return output

    def get_transfer_ids(self):
        output = {'error_messages': [],
         'transfers': []}
        dom = self._http_request('content/dcp/command?action=ListImportJobs')
        for job_el in dom.getElementsByTagName('JobProgress'):
            output['transfers'].append(xml_utils.get_element_value(xml_utils.get_child_by_tag(job_el, 'Id')))

        return output

    def get_transfer_info(self, transfer_ids):
        output = {'error_messages': [],
         'transfers': []}
        dom = self._http_request('content/dcp/command?action=ListImportJobs')
        for job_el in dom.getElementsByTagName('JobProgress'):
            import_el = xml_utils.get_child_by_tag(job_el, 'ImportProgress')
            dcp_title = xml_utils.get_element_value(import_el, 'DCPTitle')
            dcp_desc = xml_utils.get_element_value(job_el, 'Title')
            completion_time = xml_utils.get_element_value(import_el, 'CompletionTime')
            source_path = xml_utils.get_element_value(import_el, 'ImportPath')
            source = re.sub('^S:/([0-9.]+)/[-a-z0-9]+/$', '\\1', source_path)
            try:
                content_id = filter(None, source.split('/'))[-1]
            except IndexError:
                content_id = None

            transfer_info = {'server_transfer_id': xml_utils.get_element_value(xml_utils.get_child_by_tag(job_el, 'Id')),
             'state': None,
             'description': dcp_title if dcp_title is not None else dcp_desc,
             'content_id': content_id,
             'type': 'Clip',
             'source': source,
             'progress': int(xml_utils.get_element_value(import_el, 'PercentCompleted')),
             'message': None,
             'end_time': parse_date(completion_time) if completion_time is not None else None}
            state = xml_utils.get_element_value(job_el, 'State')
            if state == 'COMPLETE':
                validation_els = job_el.getElementsByTagName('ValidationProgress')
                states = [ xml_utils.get_element_value(el, 'CompletionStatus') for el in validation_els ]
                states.append(xml_utils.get_element_value(import_el, 'CompletionStatus'))
                for state in ('ERROR', 'IMPORTING', 'VALIDATING', 'SUCCESSFUL'):
                    if state in states:
                        break
                else:
                    state = states[0]

            transfer_info['state'] = TRANSFER_STATE.get(state, 'failed')
            output['transfers'].append(transfer_info)

        return output

    def get_content_uuid_list(self):
        output = {'error_messages': [],
         'content_uuid_list': []}
        output['content_uuid_list'] = self._get_cpl_uuids()
        return output

    def get_content_information(self, content_uuids):
        output = {'error_messages': [],
         'content_info_dict': {}}
        dom = self._http_request('content/cpl/info/list?detailed=true')
        cpls = {}
        for cpl_el in dom.getElementsByTagName('CPLDetails'):
            cpl_uuid = strip_urn(xml_utils.get_element_value(cpl_el, 'ID'))
            cpls[cpl_uuid] = cpl_el

        for content_uuid in content_uuids:
            cpl_info = {'content_title_text': content_uuid,
             'content_kind': 'unknown',
             'edit_rate': [None, None],
             'subtitled': None,
             'subtitle_language': None,
             'playback_mode': None,
             'aspect_ratio': None,
             'duration_in_seconds': 0,
             'duration_in_frames': 0,
             'encrypted': None,
             'xml': None,
             'parsed_info': parse_content_title_text(''),
             'video_encoding': 'UNKNOWN'}
            try:
                cpl_el = cpls[content_uuid]
                cpl_info['content_title_text'] = xml_utils.get_element_value(cpl_el, 'ContentTitle')
                cpl_info['content_kind'] = xml_utils.get_element_value(cpl_el, 'ContentType')
                is_hfr = xml_utils.get_element_value(cpl_el, 'IsHighFrameRate')
                cpl_info['edit_rate'] = [48, 1] if is_hfr == 'true' else [24, 1]
                cpl_info['subtitle_language'] = xml_utils.get_element_value(cpl_el, 'SubtitleLanguage')
                cpl_info['subtitled'] = cpl_info['subtitle_language'] is not None and cpl_info['subtitle_language'] != ''
                cpl_info['playback_mode'] = xml_utils.get_element_value(cpl_el, 'Dimension')
                aspect_el = cpl_el.getElementsByTagName('AspectRatio')[0]
                width = int(xml_utils.get_element_value(aspect_el, 'Width'))
                height = int(xml_utils.get_element_value(aspect_el, 'Height'))
                cpl_info['aspect_ratio'], cpl_info['resolution'] = ASPECT_RATIO.get((width, height), (None, None))
                cpl_info['duration_in_seconds'] = float(xml_utils.get_element_value(cpl_el, 'RunningTime')) / 1000
                cpl_info['duration_in_frames'] = int(cpl_info['duration_in_seconds'] * (1.0 * cpl_info['edit_rate'][0] / cpl_info['edit_rate'][1]))
                cpl_info['encrypted'] = xml_utils.get_element_value(cpl_el, 'EncryptedVideo') == 'true' or xml_utils.get_element_value(cpl_el, 'EncryptedAudio') == 'true'
                cpl_info['parsed_info'] = parse_content_title_text(cpl_info['content_title_text'])
                cpl_info['xml'] = cpl_el
            except Exception as ex:
                logging.error('Error getting cpl information for cpl_id %s' % content_uuid, exc_info=True)
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))

            output['content_info_dict'][content_uuid] = cpl_info

        return output

    def _get_ingest_path(self, dcp_uuid):
        s2s_transfer_info = self._http_request('content/dcp/s2stransferinfo?Id=urn:uuid:' + dcp_uuid, timeout=10)
        pkl_url = xml_utils.get_element_value(s2s_transfer_info, 'PklUri')
        scheme, the_rest = pkl_url.split('//')
        ingest_path = '/'.join(the_rest.split('/')[1:-1])
        return ingest_path

    def get_content_validation_information(self, content_uuids):
        output = {'error_messages': [],
         'content_validation_dict': {}}
        dcp_cpl_map = self._get_dcp_to_cpl_map()
        dcp_info_list = self._http_request('content/dcp/info/list')
        for dcp_el in dcp_info_list.getElementsByTagName('DCPInfo'):
            dcp_info = {}
            dcp_uuid = strip_urn(xml_utils.get_element_value(dcp_el, 'ID'))
            if dcp_uuid in dcp_cpl_map:
                dcp_info['cpl_size'] = int(xml_utils.get_element_value(dcp_el, 'Size'))
                is_imported = xml_utils.get_element_value(dcp_el, 'IsImported') == 'true'
                is_transfered = xml_utils.get_element_value(dcp_el, 'IsTransferred')
                is_playable = xml_utils.get_element_value(dcp_el, 'IsPlayable')
                verify_status = xml_utils.get_element_value(dcp_el, 'VerifyStatus')
                validate_status = xml_utils.get_element_value(dcp_el, 'ValidateStatus')
                if is_transfered is None:
                    is_transfered = is_imported
                if not is_transfered:
                    dcp_info['validation_code'] = 3
                elif validate_status != 'OK':
                    dcp_info['validation_code'] = 5
                elif verify_status == 'NG':
                    dcp_info['validation_code'] = 2
                else:
                    dcp_info['validation_code'] = 0
                ingest_path = None
                try:
                    ingest_path = self._get_ingest_path(dcp_uuid)
                except SonyError as ex:
                    message = 'Getting ingest path threw an error: %s' % repr(ex)
                    if message not in output['error_messages']:
                        output['error_messages'].append(message)
                    ingest_path = None

                for cpl_uuid in dcp_cpl_map[dcp_uuid]:
                    if cpl_uuid in content_uuids:
                        cpl_info = dcp_info.copy()
                        cpl_info['ingest_path'] = None if ingest_path is None else ingest_path + '/' + dcp_cpl_map[dcp_uuid][cpl_uuid]
                        output['content_validation_dict'][cpl_uuid] = cpl_info

        return output

    def get_ingest_path(self, content_uuid):
        dcp_uuid = self._get_cpl_dcp_uuid(content_uuid)
        ingest_path = self._get_ingest_path(dcp_uuid) + '/' + content_uuid + '.xml'
        return ingest_path

    def content_add_key(self, key):
        kdm = parse_kdm(key, load_from_file=False)
        self._http_post_multipart('content/kdm/command/import', files=[('file', 'kdm.xml', key)])
        message = _('KDM saved on %s for CPL %s') % (self.device_configuration['screen_identifier'], kdm['cpl_text'])
        return (True, message)

    def content_cancel_transfer(self, transfer_id):
        transfer_ids = []
        dom = self._http_request('content/dcp/command?action=ListImportJobs')
        for job_el in dom.getElementsByTagName('JobProgress'):
            transfer_ids.append(xml_utils.get_element_value(xml_utils.get_child_by_tag(job_el, 'Id')))

        if transfer_id in transfer_ids:
            msg = _build_command_message('Cancel', {'Id': transfer_id})
            self._http_request('content/dcp/command', msg)
            return (True, _('Transfer cancelled'))
        else:
            return (False, _('Could not find specified transfer: %s') % transfer_id)

    def content_clear_transfer_history(self):
        self._http_request('content/dcp/command?action=RemoveCompletedJobs')
        return (True, _('Transfer history cleared'))

    def content_delete(self, content_id):
        dcp_uuid = self._get_cpl_dcp_uuid(content_id)
        msg = _build_command_message('Delete', {'Id': wrap_urn(dcp_uuid),
         'RemoveKDM': 'false',
         'Force': 'false'})
        self._http_request('content/dcp/command', msg)
        return (True, _('Content deleted'))

    def content_delete_key(self, key_id):
        message = _build_command_message('Delete', {'Id': wrap_urn(key_id),
         'Type': 'KDM'})
        dom = self._http_request('content/kdm/command', message)
        kdm_uuids = self._get_kdm_uuids()
        if key_id in kdm_uuids:
            return (False, _('Unknown error deleting KDM with ID: %s') % key_id)
        else:
            return (True, _('Deleted'))

    def content_transfer(self, connection_details, description, cpl_uuid):
        ingest_path, cpl_xml_file = posixpath.split(connection_details['ingest_path'])
        ingest_url = 'ftp://%s:%s@%s:%d/' % (connection_details['ftp_username'],
         connection_details['ftp_password'],
         connection_details['ftp_ip'],
         connection_details['ftp_port'])
        null_path, ftp_handler = AbstractHandler.get_handler(ingest_url)
        dcp = DCP(ingest_path, ftp_handler)
        pkl_path = posixpath.join(ingest_path, dcp.pkls[0].relative_path)
        if len(dcp.pkls) > 0:
            pkl_uuid = dcp.pkls[0].uuid
            msg = _build_transfer_message(ingest_url + pkl_path, pkl_uuid)
            ret = self._http_request('command/mediablock/dcp/s2stransfer', msg)
            try:
                content_id = filter(None, ingest_path.split('/'))[-1]
            except IndexError:
                content_id = None

            transfer_info = self.get_transfer_info([])['transfers']
            infos = [ x for x in self.get_transfer_info([])['transfers'] if x['content_id'] == content_id and x['state'] == 'active' ]
            if len(infos) == 0:
                infos = [ x for x in self.get_transfer_info([])['transfers'] if x['state'] == 'active' ]
            if len(infos) > 0:
                transfer_id = infos[0]['server_transfer_id']
            else:
                transfer_id = None
                logging.error('We were unable to match the transfer up to an existing transfer. This is for transfer of: %s' % str(connection_details))
            return (True, _('Transfer started'), transfer_id)
        else:
            logging.error('There was an error trying to find the location of the specified DCPs PKL - most likely unicode in the path. THe path:%s' % ingest_path)
            return (True, _('Transfer failed'), None)
            return

    def content_validate(self, cpl_uuid):
        dcp_uuid = self._get_cpl_dcp_uuid(cpl_uuid)
        msg = _build_command_message('Validate', {'Id': wrap_urn(dcp_uuid)})
        self._http_request('content/dcp/command', msg)
        return (True, _('Validation started'))

    def get_playlist_uuid_list(self):
        output = {'error_messages': [],
         'playlist_uuid_list': []}
        output['playlist_uuid_list'] = self._get_playlist_uuids()
        return output

    def get_playlist_information(self, playlist_uuids):
        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for playlist_uuid in playlist_uuids:
            try:
                playlist_dom = self._get_playlist(playlist_uuid)
            except Exception as ex:
                output['error_messages'].append(_('Error getting Playlist information for ID %s: %s') % (playlist_uuid, str(ex)))
            else:
                try:
                    playlist = self._parse_playlist(playlist_dom)
                    output['playlist_info_dict'][playlist_uuid] = {}
                    output['playlist_info_dict'][playlist_uuid]['title'] = playlist['title'] or playlist['text']
                    output['playlist_info_dict'][playlist_uuid]['duration_in_seconds'] = playlist['duration_in_seconds']
                    output['playlist_info_dict'][playlist_uuid]['is_3d'] = playlist['is_3d']
                    output['playlist_info_dict'][playlist_uuid]['is_hfr'] = playlist['is_hfr']
                    output['playlist_info_dict'][playlist_uuid]['is_4k'] = playlist['is_4k']
                    output['playlist_info_dict'][playlist_uuid]['is_pack'] = False
                    output['playlist_info_dict'][playlist_uuid]['playlist'] = playlist
                except Exception as ex:
                    output['error_messages'].append(_('Error parsing Playlist %s: %s') % (playlist_uuid, str(ex)))
                    continue

        return output

    def playlist_delete(self, playlist_uuid):
        msg = _build_command_message('Delete', {'Id': wrap_urn(playlist_uuid)})
        self._http_request('show/playlist/manage/delete', msg)
        return (True, _('Playlist deleted'))

    def playlist_save(self, playlist):
        is_new = 'false' if playlist['id'] in self.playlist_information.keys() else 'true'
        playlist_xml = self._construct_playlist(playlist)
        logging.info("try to save playlist with \n %s" % playlist_xml, exc_info = True )
        msg = playlist_xml.replace('encoding="utf-8"', 'encoding="UTF-8"')
        self._http_request('show/playlist/manage/update?new=%s&genId=false' % is_new, msg)
        return (True, _('Saved: %s') % playlist['title'])

    def get_playback_status(self):
        output = {'error_messages': [],
         'playback_state': None,
         'spl_uuid': None,
         'spl_position': None,
         'element_id': None,
         'element_position': None,
         'element_duration': None,
         'element_index': None,
         'cpl_uuid': None,
         'intermission': False,
         'modes': {'loop_mode': None,
                   'scheduler_enabled': None}}
        try:
            dom = self._http_request('playback/showstatus')
        except SonyError as ex:
            output['error_messages'].append(_('Error getting playback status: %s') % str(ex))
        else:
            state = xml_utils.get_element_value(dom, 'PlayState')
            output['playback_state'] = PLAYBACK_STATE.get(state, 'error')
            if xml_utils.get_element_value(dom, 'Type') == 'SPL':
                output['spl_uuid'] = strip_urn(xml_utils.get_element_value(dom, 'Id'))
                output['spl_position'] = float(xml_utils.get_element_value(dom, 'ElapsedTime')) / 1000
                output['spl_duration'] = float(xml_utils.get_element_value(dom, 'TotalDuration')) / 1000
                if xml_utils.get_element_value(dom, 'IntermissionState') == 'INTERVAL_SPL':
                    output['intermission'] = True
                    output['spl_duration'] = parse_simple_duration(xml_utils.get_element_value(dom, 'IntervalTime'))
                try:
                    spl_info = self.playlist_information[output['spl_uuid']]
                except KeyError:
                    pass
                else:
                    tmp_duration = 0
                    for index, event in enumerate(spl_info['playlist']['events']):
                        if tmp_duration + event['duration_in_seconds'] > output['spl_position']:
                            output['element_id'] = event['id']
                            output['element_index'] = index
                            output['element_position'] = output['spl_position'] - tmp_duration
                            output['element_duration'] = event['duration_in_seconds']
                            output['cpl_uuid'] = event.get('cpl_id', None)
                            break
                        else:
                            tmp_duration += event['duration_in_seconds']

            if xml_utils.get_element_value(dom, 'CurrentEventType') == 'CPL':
                output['cpl_uuid'] = strip_urn(xml_utils.get_element_value(dom, 'CurrentEventId'))

        try:
            dom = self._http_request('show/schedule/mode/get')
        except SonyError as ex:
            output['error_messages'].append(_('Error getting schedule mode status: %s') % str(ex))
        else:
            mode = xml_utils.get_element_value(dom, 'PlayBackMode')
            output['modes']['scheduler_enabled'] = mode == 'SCHEDULED'

        return output

    def playback_ready_to_play(self):
        state = self.get_playback_status()
        if state['playback_state'] == 'stop' and state['modes']['scheduler_enabled'] == False:
            return True
        else:
            return False

    def playback_eject(self):
        raise NotImplementedError(_('Sony does not support playlist ejection'))

    def playback_load(self, playlist_id):
        play_cmd = _build_command_message('Play', {'Type': 'SPL',
         'Id': wrap_urn(playlist_id),
         'StartPoint': '00:00:00.000'})
        self._http_request('playback/command', play_cmd)
        self._device_sync_playback_status()
        return (True, _('Playlist loaded: %s') % self.playlist_information[playlist_id]['title'])

    def playback_pause(self):
        pause_cmd = _build_command_message('Pause')
        self._http_request('playback/command', pause_cmd)
        self._device_sync_playback_status()
        return (True, _('Playback paused'))

    def playback_play(self):
        if self.playback_information['playback_state'] == 'pause':
            resume_cmd = _build_command_message('Resume')
            self._http_request('playback/command', resume_cmd)
            self._device_sync_playback_status()
            return (True, _('Playback started'))
        else:
            play_cmd = _build_command_message('Play', {'Type': 'SPL',
             'Id': wrap_urn(self.playback_information['spl_uuid']),
             'StartPoint': '00:00:00.000'})
            self._http_request('playback/command', play_cmd)
            self._device_sync_playback_status()
            return (True, _('Playback started'))

    def playback_stop(self):
        stop_cmd = _build_command_message('Stop', {'Type': 'SPL',
         'Id': wrap_urn(self.playback_information['spl_uuid'])})
        self._http_request('playback/command', stop_cmd)
        self._device_sync_playback_status()
        return (True, _('Playback stopped'))

    def playback_skip_forward(self):
        raise NotImplementedError(_('Sony does not support skipping to events'))

    def playback_skip_backward(self):
        raise NotImplementedError(_('Sony does not support skipping to events'))

    def playback_set_mode(self, mode):
        if mode in self.supported_modes['schedule_modes']:
            if mode == 'schedule_on':
                self._http_request('show/schedule/mode/set?playbackmode=SCHEDULED')
                return (True, _('Schedule mode enabled'))
            else:
                self._http_request('show/schedule/mode/set?playbackmode=MANUAL')
                return (True, _('Schedule mode disabled'))

    def playback_interrupt_intermission(self):
        interrupt_cmd = _build_command_message('ExitIntermission')
        self._http_request('playback/command', interrupt_cmd)
        return (True, _('Intermission interrupted'))

    def get_schedule_id_list(self):
        output = {'error_messages': [],
         'schedule_id_list': []}
        schedules = self._get_schedules()
        output['schedule_id_list'] = [ s['device_schedule_id'] for s in schedules ]
        return output

    def get_schedule_information(self, schedule_ids):
        output = {'error_messages': [],
         'schedule_info_dict': {}}
        schedules = self._get_schedules()
        for schedule in schedules:
            if not schedule_ids or schedule['device_schedule_id'] in schedule_ids:
                output['schedule_info_dict'][schedule['device_schedule_id']] = schedule

        return output

    def scheduling_delete(self, schedule_id):
        if schedule_id in self.scheduling_information:
            schedule_info = self.scheduling_information[schedule_id]
        elif schedule_id in self.cached_schedule_info:
            schedule_info = self.cached_schedule_info.pop(schedule_id)
        else:
            logging.critical('Could not delete schedule [%s] from Sony - not in main hash or cache!', schedule_id)
            return (False, trans.SCHEDULING_generic_err_s1() % schedule_id)
        start_datetime = datetime.fromtimestamp(schedule_info['start_time'])
        msg = _build_schedule_message('Delete', start_datetime, schedule_info['device_playlist_uuid'], schedule_id)
        self._http_request('show/schedule/manage', msg)
        return (True, _('Schedule deleted'))

    def scheduling_schedule_playlist(self, playlist_id, timestamp):
        spl_title = self.playlist_information[playlist_id]['title']
        start_datetime = datetime.fromtimestamp(timestamp)
        msg = _build_schedule_message('Add', start_datetime, playlist_id)
        existing_schedule_ids = self.scheduling_information.keys()
        self._http_request('show/schedule/manage', msg)
        possible_new_schedules = self._get_schedules(start=start_datetime, end=start_datetime)
        for possible_new_schedule in possible_new_schedules:
            if possible_new_schedule['device_playlist_uuid'] == playlist_id and possible_new_schedule['start_time'] == timestamp and possible_new_schedule['device_schedule_id'] not in existing_schedule_ids:
                schedule_info = possible_new_schedule
                break
        else:
            schedule_info = {'device_playlist_uuid': playlist_id,
             'start_time': timestamp,
             'device_schedule_id': None}

        return (True, _('Playlist %s has been scheduled for %s') % (spl_title, helper_methods.format_timestamp(timestamp)), schedule_info)

    def get_automation_list(self):
        output = {'error_messages': [],
         'automation_uuid_list': []}
        dom = self._http_request('config/projector/function/list')
        output['automation_uuid_list'] = xml_utils.get_element_value_list(dom, 'Value')
        dom = self._http_request('config/automation/gpio/control/list', timeout=360)
        output['automation_uuid_list'].extend(xml_utils.get_element_value_list(dom, 'Name'))
        output['automation_uuid_list'].extend(STATIC_AUTOMATION.keys())
        return output

    def get_automation_information(self, automation_uuids):
        output = {'error_messages': [],
         'automation_info_dict': {}}
        dom = self._http_request('config/projector/function/list', timeout=120)
        for func_dom in dom.getElementsByTagName('Function'):
            func_id = xml_utils.get_element_value(func_dom, 'Value')
            if func_id in automation_uuids:
                name = xml_utils.get_element_value(func_dom, 'DisplayName')
                if not name or not name.strip():
                    name = xml_utils.get_element_value(func_dom, 'Name')
                output['automation_info_dict'][func_id] = {'name': name,
                 'type': 'sony_function',
                 'duration': 1}

        dom = self._http_request('config/automation/gpio/control/list')
        for gpio_dom in dom.getElementsByTagName('GPIOControl'):
            name = xml_utils.get_element_value(gpio_dom, 'Name')
            if name in automation_uuids:
                output['automation_info_dict'][name] = {'name': name,
                 'type': 'sony_cue',
                 'duration': 1}

        for name, info in STATIC_AUTOMATION.iteritems():
            if name in automation_uuids:
                output['automation_info_dict'][name] = info

        return output

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        if cue_id in self.automation:
            if self.automation[cue_id]['type'] == 'sony_function':
                msg = _build_command_message('SEND', {'Command': cue_id})
                self._http_request('command/automation', msg)
                return (True, _('Automation cue %s fired') % cue_id)
            else:
                return (False, _('Only projector functions can be manually fired'))
        else:
            return (False, _('Cannot find automation cue %s on screen server') % cue_id)

    def get_logs(self, start_datetime):
        output = {'error_messages': []}
        date = (start_datetime + timedelta(days=1)).strftime('%Y%m%d')
        logs = StringIO()
        try:
            response = self._http_request('command/sms/auditlog/report?start=%s&end=%s' % (date, date))
        except SonyError as ex:
            if ex.code == 203 or ex.code == 210:
                output['error_messages'].append('No logs - error code %d' % ex.code)
            else:
                raise
        else:
            data = StringIO()
            data.write(response)
            data.seek(0)
            z = ZipFile(data, 'r')
            for f in z.namelist():
                logs.write(z.read(f))

        logs.seek(0)
        xml = logs.read()
        if xml.count('<?xml') > 1:
            last_xml_start = xml.rfind('<?xml')
            xml = xml[last_xml_start:]
        output['xml'] = xml
        return output

    def get_supported_patterns(self):
        return [{'description': 'Black',
          'edit_rate': [24, 1],
          'playback_mode': 'two_d',
          'type': 'pattern',
          'content_kind': None}]
# okay decompyling ./core/devices/sms/sony/sony_sms.pyc
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:01 CST
