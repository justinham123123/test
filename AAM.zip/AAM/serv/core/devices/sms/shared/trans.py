# 2017.08.13 21:49:57 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\shared\trans.py
from serv.lib.cherrypy.i18n_tool import ugettext

class LazyTrans(object):

    def __init__(self, tran):
        self.tran = tran

    def __call__(self):
        return ugettext(self.tran)


def _(tran):
    return LazyTrans(tran)


NOT_SUPPORTED = _('Not supported')
KDM_saved = _('KDM saved')
KDM_saved_s2 = _('KDM saved on %s for content (CPL) %s')
KDM_saved_err_s1 = _('Unknown error saving KDM for %s')
KDM_delete = _('KDM deleted')
CPL_delete = _('Content (CPL) deleted')
CPL_validate = _('Validation Started')
PLAYLIST_save_s1 = _('Saved: [%s]')
PLAYLIST_save_err_not_empty = _('Playlist Empty')
PLAYLIST_delete = _('Playlist deleted')
PLAYLIST_delete_err = _('Playlist could not be deleted')
PLAYLIST_corrupt = _('Content (CPL) in the Playlist is corrupt')
PLAYLIST_not_registered = _('Content (CPL) is not registered on this server')
PLAYLIST_not_playbable = _('Playlist is not playable')
PLAYLIST_no_kdm = _('No KDMs were found for this CPL')
SCHEDULING_save_s2 = _('Playlist %s has been scheduled for %s')
SCHEDULING_save_err_s2 = _('Unknown error scheduling playlist %s at %s')
SCHEDULING_delete = _('Schedule deleted')
SCHEDULING_generic_err_s1 = _('Error getting scheduling information for ID: [%s]')
SOCKET_http_s1 = _('HTTP error [%s]')
SOCKET_timeout = _('Timed out while trying to connect')
SOCKET_host = _('Unable to find the configured host/address')
SOCKET_network_s1 = _('Network error [%s]')
SOCKET_unknown_s1 = _('Unexpected error [%s]')
SOCKET_ok = _('OK')
PLAYBACK_eject = _('Playlist ejected')
PLAYBACK_load_s1 = _('Playlist loaded')
PLAYBACK_pause = _('Playback paused')
PLAYBACK_play = _('Playback started')
PLAYBACK_stop = _('Playback stopped')
PLAYBACK_stop_no_more = _('Already stopped')
PLAYBACK_skip_fwd = _('Playback skipped forward')
PLAYBACK_skip_bwd = _('Playback skipped backwards')
PLAYBACK_skip_err_must_stop = _('Error')
PLAYBACK_mode_s1 = _('Playback mode set to %s')
PLAYBACK_mode_err_s1 = _('Playback mode %s not recognised')
TRANSFER_queued = _('Transfer queued on the Screen Server')
TRANSFER_started = _('Transfer started')
TRANSFER_paused = _('Transfer is paused')
TRANSFER_in_progress = _('Transfer in progress')
TRANSFER_success = _('Transfer successful')
TRANSFER_cancelled = _('Transfer cancelled')
TRANSFER_cleared = _('Transfer history cleared')
AUTOMATION_trigger_s1 = _('Automation cue [%s] fired')
REBOOT_posix_only = _('Reboot is only available on a POSIX platform')
RAID_ok = _('OK')
# okay decompyling ./core/devices/sms/shared/trans.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:57 CST
