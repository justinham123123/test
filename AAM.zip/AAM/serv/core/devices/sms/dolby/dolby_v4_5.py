# 2017.08.13 21:49:32 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\dolby\dolby_v4_5.py
"""
Dolby SMS 4.5 Adaptor
"""
import datetime, time, posixpath, shutil, uuid, os
from StringIO import StringIO
from serv.lib.utilities.date_utils import local_datetime_to_utc
from serv.configuration import cfg
from serv.core.devices.sms.dolby.dolby_v4_3 import Dolby_v4_3
from serv.core.devices.sms.dolby.dolby_utils import check_response

class Dolby_v4_5(Dolby_v4_3):
    """
    Dolby screen server access and control
    """

    def __init__(self, id, device_info, snmp_manager):
        super(Dolby_v4_5, self).__init__(id, device_info, snmp_manager)

    def has_unencrypted_logs(self):
        return True

    def get_unencrypted_logs(self, start_datetime):
        self.log('get_unencrypted_logs')
        output = {'error_messages': [],
         'xml': None}
        log_status = self.execute(self.SYSTEM, 'getAuditLogsStatus', list_tags=['auditLogStatusInfo'], timeout=200)
        auditLogStatusInfos = log_status.get('auditLogStatusInfo', [])
        transfers_in_progress = [ ls for ls in auditLogStatusInfos if ls['transferStatus'][0] == 'IN_PROGRESS' and ls['deviceComponentType'][0] == 'PLAYER' ]
        if transfers_in_progress:
            raise Exception('Device is busy. Cannot collect at this moment')
        utc_start_datetime = local_datetime_to_utc(start_datetime)
        utc_end_datetime = utc_start_datetime + datetime.timedelta(days=1)
        log_directory = str(uuid.uuid4())
        log_dump_url = 'ftp://%s:%d/%s' % (cfg.lms_ftp_ip(), cfg.lms_ftp_port(), posixpath.join('tmp', log_directory))
        local_log_directory = os.path.join(cfg.lms_library_directory(), 'tmp', log_directory)
        os.mkdir(local_log_directory)
        response = self.execute(self.SYSTEM, 'getPlaybackLogs', params={'url': log_dump_url,
         'startDate': utc_start_datetime.strftime('%Y-%m-%dT%H:%M:%S+00:00'),
         'endDate': utc_end_datetime.strftime('%Y-%m-%dT%H:%M:%S+00:00'),
         'username': cfg.lms_ftp_username(),
         'password': cfg.lms_ftp_password()}, version='1_2')
        if check_response(response):
            tries = 0
            continue_wait = False
            success = False
            while tries < 10 or continue_wait:
                continue_wait = False
                log_retrieval_response = self.execute(self.SYSTEM, 'getPlaybackLogsStatus', params={'logRetrievalId': response['logRetrievalId']}, version='1_2')
                if check_response(log_retrieval_response):
                    if log_retrieval_response['playbackLogStatusInfo']['transferStatus'] in ('FINISHED',):
                        success = True
                        break
                    elif log_retrieval_response['playbackLogStatusInfo']['transferStatus'] in ('IN_PROGRESS',):
                        continue_wait = True
                    elif log_retrieval_response['playbackLogStatusInfo']['transferStatus'] in ('ERROR', 'CANCELLED'):
                        output['error_messages'].append('Log retrieval ended with status %s' % log_retrieval_response['playbackLogStatusInfo']['transferStatus'])
                        break
                tries += 1
                time.sleep(1)

            if success:
                log_xml = StringIO()
                log_files = os.listdir(local_log_directory)
                if log_files:
                    for log_file_name in log_files:
                        log_file = os.path.join(local_log_directory, log_file_name)
                        if os.path.isfile(log_file):
                            with open(log_file, 'r') as f:
                                log_xml.write(f.read())

                    log_xml.seek(0)
                    output['xml'] = log_xml.read()
        else:
            output['error_messages'].append(response['error_message'])
        shutil.rmtree(local_log_directory, ignore_errors=True)
        return output
# okay decompyling ./core/devices/sms/dolby/dolby_v4_5.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:33 CST
