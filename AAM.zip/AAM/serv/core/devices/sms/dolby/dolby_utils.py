# 2017.08.13 21:49:30 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\dolby\dolby_utils.py
"""
Dolby Utilities
"""
from serv.lib.network.soap_utils import SOAPClient
from serv.lib.utilities.xml_utils import iterparse_xml, node_to_dict

def check_response(response_dict):
    return 'error' not in response_dict


class DolbySOAPClient(SOAPClient):

    def __init__(self, *args, **kwargs):
        super(DolbySOAPClient, self).__init__(*args, **kwargs)

    def build_body(self, method = None, **kwargs):
        if method is not None:
            method += 'Request'
        return super(DolbySOAPClient, self).build_body(method=method, **kwargs)

    def parse_response(self, response, list_tags = None, method = None):
        response_tag = '{0}Response'.format(method)
        if not list_tags:
            list_tags = ['result']

        def loop_function(event, element, loop_vars, tree = None):
            if event == 'start':
                if element.tag.endswith(response_tag) and tree is not None:
                    attributes = element.items()
                    loop_vars['response'] = node_to_dict(tree, list_tags=list_tags, attributes=True)
                    loop_vars['response'].update(attributes)
                elif element.tag.endswith('Fault') and tree is not None:
                    self.fault(tree)
            element.clear()
            return loop_vars

        parsed_response = iterparse_xml(response, loop_function, {})
        return parsed_response['response']
# okay decompyling ./core/devices/sms/dolby/dolby_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:30 CST
