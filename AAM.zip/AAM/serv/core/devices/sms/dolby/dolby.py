# 2017.08.13 21:49:25 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\dolby\dolby.py
"""
Dolby SMS Adaptor
"""
from StringIO import StringIO
from urlparse import urlparse, ParseResult
from xml.dom import minidom
from xml.sax.saxutils import unescape
import datetime
import httplib
import time
import os
import posixpath
import uuid
import socket
import logging
import urllib
import shutil
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities.date_utils import parse_date, parse_xs_duration, seconds_to_xs_duration, local_datetime_to_utc
from serv.lib.dcinema.parsers.parsers import parse_cpl, parse_kdm, parse_content_title_text
from serv.lib.network.snmp import SNMPException
from serv.lib.network.soap_utils import SOAPError
from serv.lib.utilities.utils import strip_urn, wrap_urn
from serv.lib.utilities.xml_utils import get_element_data
from serv.configuration import cfg
from serv.configuration.constants import HFR_FPS
from serv.lib.utilities import helper_methods
from serv.core.devices.base.scheduling import Scheduling
from serv.core.devices.sms.dolby.dolby_utils import DolbySOAPClient, check_response
from serv.core.devices.sms.dolby.normalizers import DolbyNormalizer
import cherrypy

def _(input):
    return input


SCHEDULE_MODE_DICT = {'FULL_AUTOMATIC': True,
 'SELECT_AUTOMATIC': False,
 'MANUAL': False}
SCHEDULE_MODE_TRANS = {'FULL_AUTOMATIC': 'FULL_AUTOMATIC',
 'SELECT_AUTOMATIC': 'SELECT_AUTOMATIC',
 'MANUAL': 'MANUAL',
 'schedule_off': 'MANUAL',
 'schedule_on': 'FULL_AUTOMATIC'}
TRANSPORT_STATE_DICT = {'PLAYING': 'play',
 'STOPPED': 'pause',
 'PAUSED': 'pause',
 'SELECTING': 'pause',
 'PREP_SUITE': 'pause',
 'SEEKING': 'pause',
 'READY': 'stop',
 'RECOVERING': 'stop',
 'LATE': 'stop',
 'UNSELECTED': 'stop',
 'EXTENSION': 'stop',
 'PURGE_SUITE': 'stop',
 'UNAVAILABLE': 'error'}
PLAYBACK_MODE_DICT = {'TWO_D': '2D',
 'THREE_D': '3D',
 'DOLBY_3D': 'DOLBY_3D',
 '2D': 'TWO_D',
 '3D': 'THREE_D',
 'UNKNOWN': 'UNKNOWN'}
TRANSFER_STATUS_ERRORS = {'DISK_ERROR': _('There was an error with the disk'),
 'NETWORK': _('There was an error with the network'),
 'CONTENT': _('There is an error with the CPL'),
 'CONTENT_MANAGER_BUSY': _('The content manager is busy'),
 'CONTENT_EXISTS': _('The CPL already exists at the destination'),
 'DISK_FULL': _('There is no space on the disk'),
 'DISK_NOT_WRITABLE': _('The disk is not writable'),
 'COULD_NOT_VERIFY': _('The CPL was not verified'),
 'WAS_SELECTED': _('The CPL was selected for playback'),
 'HOST_NOT_FOUND': _('The host was not found'),
 'FILE_NOT_FOUND': _('A source file could not be found'),
 'CONNECTION_CLOSED': _('The remote connection was closed'),
 'DUPLICATE_TRANSFER': _('The CPL is currently transferring'),
 'DUPLICATE_PENDING_TRANSFER': _('The CPL is already queued for transfer'),
 'MAX_NUMBER_EXCEEDED': _('The maximum number of concurrent transfers has been reached'),
 'NOT_AVAILABLE': _('Information about the transfer is not yet available'),
 'PACKAGE_MISSING': _('Either the ASSETMAP or CPL could not be found on the source'),
 'PACKAGE_BROKEN': _('Either the ASSETMAP or CPL could not be parsed'),
 'UNKNOWN': _('Unknown'),
 'EXTENSION': _('Unknown')}
KDM_STATUS = {'OK': 'ok',
 'FUTURE': 'ok',
 'ABOUT_TO_EXPIRE': 'ok',
 'EXPIRED': 'ok',
 'ERROR': 'error',
 'UNKNOWN': 'unknown'}

def _create_element(root, parent, tag, text = None, namespace = False):
    """
    Creates a new element in an XML DOM and appends the node
    to a parent element
    """
    if namespace:
        element = root.createElementNS('http://www.dolby.com/dcinema/ws/smi/v1/SPL', 'ns2:' + tag)
        element.setAttribute('xmlns:ns2', 'http://www.dolby.com/dcinema/ws/smi/v1/SPL')
        element.setAttribute('xmlns', 'http://www.w3.org/2000/09/xmldsig#')
    else:
        element = root.createElementNS('http://www.dolby.com/dcinema/ws/smi/v1/SPL', 'ns2:' + tag)
    if text:
        element_text = root.createTextNode(text)
        element.appendChild(element_text)
    parent.appendChild(element)
    return element


def _round_duration_to_nearest_frame(duration, edit_rate):
    """
    Dolby gives us estimated duration, which is a rounded up version of the actual duration,
    somethign like 6.235 seconds.
    
    cues are defined in terms of frames and edit rate however, so we need to convert the seconds to some form of frames,
    we clearly cannot have partial frames, the below returns the seconds so that we get no partial frames
    #NOT ANYMORE#results are rounded down, to make up for dolby rounding up.#NOT ANYMORE#
    Now just round to the closest frame
    
    fantastic.
    """
    frames = duration * (1.0 * edit_rate[0] / edit_rate[1])
    rounded_duration = round(frames) / (1.0 * edit_rate[0] / edit_rate[1])
    return rounded_duration


class Dolby(Scheduling):
    """
    Dolby screen server access and control
    """
    CONTENT = '/dcinema/ws/smi/v1/ContentManagementService'
    SYSTEM = '/dcinema/ws/smi/v1/SystemManagementService'
    LICENSE = '/dcinema/ws/smi/v1/LicenseManagementService'
    TRANSFER = '/dcinema/ws/smi/v1/TransferManagementService'
    PLAYBACK = '/dcinema/ws/smi/v1/PlaybackControlService'
    SHOW = '/dcinema/ws/smi/v1/ShowManagementService'

    def __init__(self, id, device_info, snmp_manager):
        super(Dolby, self).__init__(id, device_info)
        self.normalizer = DolbyNormalizer()
        self.supported_modes = {'schedule_modes': ['schedule_on',
                            'schedule_off',
                            'FULL_AUTOMATIC',
                            'SELECT_AUTOMATIC',
                            'MANUAL'],
         'playback_modes': ['2D', '3D', 'DOLBY_3D']}
        self.client = DolbySOAPClient(self.device_configuration['ip'], self.device_configuration['port'])
        self.snmp_manager = snmp_manager
        self.strip_automation = False
        self.last_call_successful = True
        self.projector_connected = False
        self.last_known_transport_state = 'UNKNOWN'
        self.log_actions = False

    def execute(self, soap_endpoint, method, version = '1_0', timeout = 30, **kwargs):
        self.projector_connected = True
        soap_action = 'http://www.dolby.com/dcinema/ws/smi/v1/{0}'.format(method)
        namespaces = {'ns0': 'http://www.dolby.com/dcinema/ws/smi/v{0}'.format(version),
         'sho': 'http://www.dolby.com/dcinema/ws/smi/v1/schemas/showmanagement'}
        if not self.last_call_successful:
            timeout = 2
        try:
            response = self.client.request(soap_endpoint, method, soap_action, namespaces=namespaces, timeout=timeout, default_param_namespace='', **kwargs)
        except SOAPError as e:
            self.last_call_successful = True
            if e.type == 'NotConnected':
                self.projector_connected = False
            logging.error(u'Error on Dolby [{0}] in {1}: {2}'.format(self.device_configuration['ip'], method, str(e)))
            return {'error': True,
             'error_message': str(e)}
        except httplib.HTTPException as e:
            self.last_call_successful = False
            logging.error(u'Error connecting to Dolby [{0}]: {1}'.format(self.device_configuration['ip'], str(e)))
            return {'error': True,
             'error_message': str(e)}
        except socket.timeout as e:
            self.last_call_successful = False
            logging.error(u'Timeout error while communicating with Dolby [{0}]: {1}'.format(self.device_configuration['ip'], str(e)))
            return {'error': True,
             'error_message': str(e)}
        except socket.error as e:
            self.last_call_successful = False
            logging.error(u'Socket error while communicating with Dolby [{0}]: {1}'.format(self.device_configuration['ip'], str(e)))
            return {'error': True,
             'error_message': str(e)}

        self.last_call_successful = True
        return response

    def _dolby_xml--- This code section failed: ---

0	LOAD_GLOBAL       'minidom'
3	LOAD_ATTR         'Document'
6	CALL_FUNCTION_0   None
9	STORE_FAST        'root'

12	LOAD_CONST        'Yes'
15	LOAD_FAST         'root'
18	STORE_ATTR        'standalone'

21	LOAD_GLOBAL       '_create_element'
24	LOAD_FAST         'root'
27	LOAD_FAST         'root'
30	LOAD_CONST        'ShowPlaylist'
33	LOAD_CONST        None
36	LOAD_GLOBAL       'True'
39	CALL_FUNCTION_5   None
42	STORE_FAST        'spl_element'

45	LOAD_GLOBAL       '_create_element'
48	LOAD_FAST         'root'
51	LOAD_FAST         'spl_element'
54	LOAD_CONST        'Id'
57	LOAD_GLOBAL       'wrap_urn'
60	LOAD_FAST         'spl_dict'
63	LOAD_CONST        'id'
66	BINARY_SUBSCR     None
67	CALL_FUNCTION_1   None
70	CALL_FUNCTION_4   None
73	POP_TOP           None

74	LOAD_GLOBAL       '_create_element'
77	LOAD_FAST         'root'
80	LOAD_FAST         'spl_element'
83	LOAD_CONST        'ArrangementId'
86	LOAD_GLOBAL       'wrap_urn'
89	LOAD_FAST         'spl_dict'
92	LOAD_CONST        'id'
95	BINARY_SUBSCR     None
96	CALL_FUNCTION_1   None
99	CALL_FUNCTION_4   None
102	STORE_FAST        'el'

105	LOAD_FAST         'el'
108	LOAD_ATTR         'setAttribute'
111	LOAD_CONST        'Title'
114	LOAD_FAST         'spl_dict'
117	LOAD_CONST        'title'
120	BINARY_SUBSCR     None
121	CALL_FUNCTION_2   None
124	POP_TOP           None

125	LOAD_FAST         'el'
128	LOAD_ATTR         'setAttribute'
131	LOAD_CONST        'EstimatedDuration'
134	LOAD_GLOBAL       'seconds_to_xs_duration'
137	LOAD_FAST         'spl_dict'
140	LOAD_CONST        'duration_in_seconds'
143	BINARY_SUBSCR     None
144	CALL_FUNCTION_1   None
147	CALL_FUNCTION_2   None
150	POP_TOP           None

151	LOAD_GLOBAL       '_create_element'
154	LOAD_FAST         'root'
157	LOAD_FAST         'spl_element'
160	LOAD_CONST        'CreateDate'
163	LOAD_GLOBAL       'datetime'
166	LOAD_ATTR         'datetime'
169	LOAD_ATTR         'utcnow'
172	CALL_FUNCTION_0   None
175	LOAD_ATTR         'strftime'
178	LOAD_CONST        '%Y-%m-%dT%H:%M:%S.%f'
181	CALL_FUNCTION_1   None
184	LOAD_CONST        '+00:00'
187	BINARY_ADD        None
188	CALL_FUNCTION_4   None
191	STORE_FAST        'el'

194	LOAD_GLOBAL       '_create_element'
197	LOAD_FAST         'root'
200	LOAD_FAST         'spl_element'
203	LOAD_CONST        'ShowTitleText'
206	LOAD_FAST         'spl_dict'
209	LOAD_CONST        'title'
212	BINARY_SUBSCR     None
213	CALL_FUNCTION_4   None
216	STORE_FAST        'el'

219	LOAD_FAST         'el'
222	LOAD_ATTR         'setAttribute'
225	LOAD_CONST        'language'
228	LOAD_CONST        'en'
231	CALL_FUNCTION_2   None
234	POP_TOP           None

235	LOAD_GLOBAL       '_create_element'
238	LOAD_FAST         'root'
241	LOAD_FAST         'spl_element'
244	LOAD_CONST        'AnnotationText'
247	LOAD_FAST         'spl_dict'
250	LOAD_CONST        'title'
253	BINARY_SUBSCR     None
254	CALL_FUNCTION_4   None
257	STORE_FAST        'el'

260	LOAD_FAST         'el'
263	LOAD_ATTR         'setAttribute'
266	LOAD_CONST        'language'
269	LOAD_CONST        'en'
272	CALL_FUNCTION_2   None
275	POP_TOP           None

276	LOAD_GLOBAL       '_create_element'
279	LOAD_FAST         'root'
282	LOAD_FAST         'spl_element'
285	LOAD_CONST        'Issuer'
288	LOAD_CONST        'AAM'
291	CALL_FUNCTION_4   None
294	STORE_FAST        'el'

297	LOAD_FAST         'el'
300	LOAD_ATTR         'setAttribute'
303	LOAD_CONST        'language'
306	LOAD_CONST        'en'
309	CALL_FUNCTION_2   None
312	POP_TOP           None

313	LOAD_GLOBAL       '_create_element'
316	LOAD_FAST         'root'
319	LOAD_FAST         'spl_element'
322	LOAD_CONST        'Creator'
325	LOAD_CONST        'AAM'
328	CALL_FUNCTION_4   None
331	STORE_FAST        'el'

334	LOAD_FAST         'el'
337	LOAD_ATTR         'setAttribute'
340	LOAD_CONST        'language'
343	LOAD_CONST        'en'
346	CALL_FUNCTION_2   None
349	POP_TOP           None

350	LOAD_GLOBAL       '_create_element'
353	LOAD_FAST         'root'
356	LOAD_FAST         'spl_element'
359	LOAD_CONST        'Show'
362	CALL_FUNCTION_3   None
365	STORE_FAST        'show_element'

368	LOAD_CONST        'automation'
371	LOAD_FAST         'spl_dict'
374	COMPARE_OP        'in'
377	JUMP_IF_FALSE     '396'

380	LOAD_GLOBAL       'logging'
383	LOAD_ATTR         'warning'
386	LOAD_CONST        'Global automation is not yet implemented for Dolby'
389	CALL_FUNCTION_1   None
392	POP_TOP           None
393	JUMP_FORWARD      '396'
396_0	COME_FROM         '393'

396	SETUP_LOOP        '943'
399	LOAD_FAST         'spl_dict'
402	LOAD_CONST        'events'
405	BINARY_SUBSCR     None
406	GET_ITER          None
407	FOR_ITER          '942'
410	STORE_FAST        'event'

413	LOAD_FAST         'event'
416	LOAD_CONST        'type'
419	BINARY_SUBSCR     None
420	LOAD_CONST        ('placeholder', 'title', 'macro_pack', 'pattern')
423	COMPARE_OP        'in'
426	JUMP_IF_FALSE     '435'

429	CONTINUE          '407'
432	JUMP_FORWARD      '435'
435_0	COME_FROM         '432'

435	LOAD_CONST        'automation'
438	LOAD_FAST         'event'
441	COMPARE_OP        'in'
444	JUMP_IF_FALSE     '846'

447	SETUP_LOOP        '846'
450	LOAD_FAST         'event'
453	LOAD_CONST        'automation'
456	BINARY_SUBSCR     None
457	GET_ITER          None
458	FOR_ITER          '842'
461	STORE_FAST        'automation'

464	LOAD_FAST         'automation'
467	LOAD_CONST        'type'
470	BINARY_SUBSCR     None
471	LOAD_CONST        ('cue', 'volume')
474	COMPARE_OP        'in'
477	JUMP_IF_FALSE     '839'

480	LOAD_FAST         'automation'
483	LOAD_CONST        'type_specific'
486	BINARY_SUBSCR     None
487	LOAD_CONST        'offset_from'
490	BINARY_SUBSCR     None
491	LOAD_CONST        'end'
494	COMPARE_OP        '=='
497	JUMP_IF_FALSE     '563'

500	LOAD_CONST        'start'
503	LOAD_FAST         'automation'
506	LOAD_CONST        'type_specific'
509	BINARY_SUBSCR     None
510	LOAD_CONST        'offset_from'
513	STORE_SUBSCR      None

514	LOAD_FAST         'event'
517	LOAD_CONST        'duration_in_seconds'
520	BINARY_SUBSCR     None
521	JUMP_IF_FALSE     '546'
524	LOAD_FAST         'event'
527	LOAD_CONST        'duration_in_seconds'
530	BINARY_SUBSCR     None
531	LOAD_FAST         'automation'
534	LOAD_CONST        'type_specific'
537	BINARY_SUBSCR     None
538	LOAD_CONST        'offset_in_seconds'
541	BINARY_SUBSCR     None
542	BINARY_SUBTRACT   None
543	JUMP_FORWARD      '549'
546	LOAD_CONST        0
549_0	COME_FROM         '543'
549	LOAD_FAST         'automation'
552	LOAD_CONST        'type_specific'
555	BINARY_SUBSCR     None
556	LOAD_CONST        'offset_in_seconds'
559	STORE_SUBSCR      None
560	JUMP_FORWARD      '563'
563_0	COME_FROM         '560'

563	LOAD_FAST         'automation'
566	LOAD_CONST        'type_specific'
569	BINARY_SUBSCR     None
570	LOAD_CONST        'offset_from'
573	BINARY_SUBSCR     None
574	LOAD_CONST        'start'
577	COMPARE_OP        '=='
580	JUMP_IF_FALSE     '836'

583	LOAD_GLOBAL       '_create_element'
586	LOAD_FAST         'root'
589	LOAD_FAST         'show_element'
592	LOAD_CONST        'Marker'
595	CALL_FUNCTION_3   None
598	STORE_FAST        'marker'

601	LOAD_FAST         'marker'
604	LOAD_ATTR         'setAttribute'
607	LOAD_CONST        'Title'
610	LOAD_FAST         'automation'
613	LOAD_CONST        'type_specific'
616	BINARY_SUBSCR     None
617	LOAD_CONST        'action'
620	BINARY_SUBSCR     None
621	CALL_FUNCTION_2   None
624	POP_TOP           None

625	LOAD_GLOBAL       '_create_element'
628	LOAD_FAST         'root'
631	LOAD_FAST         'marker'
634	LOAD_CONST        'Id'
637	LOAD_GLOBAL       'wrap_urn'
640	LOAD_GLOBAL       'str'
643	LOAD_GLOBAL       'uuid'
646	LOAD_ATTR         'uuid4'
649	CALL_FUNCTION_0   None
652	CALL_FUNCTION_1   None
655	CALL_FUNCTION_1   None
658	CALL_FUNCTION_4   None
661	POP_TOP           None

662	LOAD_GLOBAL       '_create_element'
665	LOAD_FAST         'root'
668	LOAD_FAST         'marker'
671	LOAD_CONST        'AnnotationText'
674	LOAD_FAST         'automation'
677	LOAD_CONST        'type_specific'
680	BINARY_SUBSCR     None
681	LOAD_CONST        'action'
684	BINARY_SUBSCR     None
685	CALL_FUNCTION_4   None
688	STORE_FAST        'el'

691	LOAD_FAST         'el'
694	LOAD_ATTR         'setAttribute'
697	LOAD_CONST        'language'
700	LOAD_CONST        'en'
703	CALL_FUNCTION_2   None
706	POP_TOP           None

707	LOAD_GLOBAL       '_create_element'
710	LOAD_FAST         'root'
713	LOAD_FAST         'marker'
716	LOAD_CONST        'Label'
719	LOAD_FAST         'automation'
722	LOAD_CONST        'type_specific'
725	BINARY_SUBSCR     None
726	LOAD_CONST        'action'
729	BINARY_SUBSCR     None
730	CALL_FUNCTION_4   None
733	STORE_FAST        'el'

736	LOAD_FAST         'el'
739	LOAD_ATTR         'setAttribute'
742	LOAD_CONST        'scope'
745	LOAD_CONST        'http://www.dolby.com/dcinema/ws/smi/v1/SPL#markers'
748	CALL_FUNCTION_2   None
751	POP_TOP           None

752	LOAD_FAST         'automation'
755	LOAD_CONST        'type_specific'
758	BINARY_SUBSCR     None
759	LOAD_CONST        'offset_in_seconds'
762	BINARY_SUBSCR     None
763	LOAD_CONST        24
766	LOAD_CONST        1
769	BINARY_DIVIDE     None
770	BINARY_MULTIPLY   None
771	STORE_FAST        'offset_in_fake_frames'

774	LOAD_GLOBAL       '_create_element'
777	LOAD_FAST         'root'
780	LOAD_FAST         'marker'
783	LOAD_CONST        'Offset'
786	LOAD_GLOBAL       'str'
789	LOAD_FAST         'offset_in_fake_frames'
792	CALL_FUNCTION_1   None
795	CALL_FUNCTION_4   None
798	STORE_FAST        'el'

801	LOAD_FAST         'el'
804	LOAD_ATTR         'setAttribute'
807	LOAD_CONST        'EditRate'
810	LOAD_CONST        '24 1'
813	CALL_FUNCTION_2   None
816	POP_TOP           None

817	LOAD_FAST         'el'
820	LOAD_ATTR         'setAttribute'
823	LOAD_CONST        'Kind'
826	LOAD_CONST        'START'
829	CALL_FUNCTION_2   None
832	POP_TOP           None
833	JUMP_ABSOLUTE     '839'

836	CONTINUE          '458'
839	JUMP_BACK         '458'
842	POP_BLOCK         None
843_0	COME_FROM         '447'
843	JUMP_FORWARD      '846'
846_0	COME_FROM         '843'

846	LOAD_GLOBAL       '_create_element'
849	LOAD_FAST         'root'
852	LOAD_FAST         'show_element'
855	LOAD_CONST        'CompositionPlaylistId'
858	LOAD_GLOBAL       'wrap_urn'
861	LOAD_FAST         'event'
864	LOAD_CONST        'cpl_id'
867	BINARY_SUBSCR     None
868	CALL_FUNCTION_1   None
871	CALL_FUNCTION_4   None
874	STORE_FAST        'composition'

877	LOAD_FAST         'composition'
880	LOAD_ATTR         'setAttribute'
883	LOAD_CONST        'Title'
886	LOAD_FAST         'event'
889	LOAD_CONST        'text'
892	BINARY_SUBSCR     None
893	CALL_FUNCTION_2   None
896	POP_TOP           None

897	LOAD_FAST         'composition'
900	LOAD_ATTR         'setAttribute'
903	LOAD_CONST        'EstimatedDuration'
906	LOAD_GLOBAL       'seconds_to_xs_duration'
909	LOAD_FAST         'event'
912	LOAD_CONST        'duration_in_seconds'
915	BINARY_SUBSCR     None
916	JUMP_IF_FALSE     '929'
919	LOAD_FAST         'event'
922	LOAD_CONST        'duration_in_seconds'
925	BINARY_SUBSCR     None
926	JUMP_FORWARD      '932'
929	LOAD_CONST        0
932_0	COME_FROM         '926'
932	CALL_FUNCTION_1   None
935	CALL_FUNCTION_2   None
938	POP_TOP           None
939	JUMP_BACK         '407'
942	POP_BLOCK         None
943_0	COME_FROM         '396'

943	LOAD_FAST         'root'
946	LOAD_ATTR         'toxml'
949	LOAD_CONST        'encoding'
952	LOAD_CONST        'utf-8'
955	CALL_FUNCTION_256 None
958	RETURN_VALUE      None

Syntax error at or near `POP_BLOCK' token at offset 842

    def _parse_playlist_events(self, xml):
        """
        Parses playlist events within a Dolby playlist
        """
        events = []
        playlist = minidom.parseString(xml)
        ns2 = '*'
        for attr, namespace in playlist.firstChild.attributes.itemsNS():
            if attr[1] == 'ns2':
                ns2 = namespace
                break

        show = playlist.getElementsByTagNameNS(ns2, 'Show')[0]
        child = show.firstChild
        automation = []
        global_automation = []
        while child:
            if child.nodeType == minidom.Node.ELEMENT_NODE:
                if child.tagName == 'ns2:Marker':
                    label = child.getElementsByTagNameNS(ns2, 'Label')[0]
                    offset = child.getElementsByTagNameNS(ns2, 'Offset')[0]
                    id = child.getElementsByTagNameNS(ns2, 'Id')[0]
                    edit_rate = map(int, offset.attributes['EditRate'].value.split(' '))
                    fake_offset_in_frames = int(offset.firstChild.nodeValue.strip())
                    offset_in_seconds = fake_offset_in_frames / (1.0 * edit_rate[0] / edit_rate[1])
                    offset_kind = offset.attributes['Kind'].value.lower()
                    parameterized_value = child.getElementsByTagNameNS(ns2, 'parameterizedValue').item(0)
                    automation_dict = {'id': strip_urn(id.firstChild.nodeValue.strip()),
                     'name': label.firstChild.nodeValue.strip(),
                     'type': 'cue',
                     'type_specific': {'offset_from': offset_kind,
                                       'offset_in_frames': None,
                                       'offset_in_seconds': offset_in_seconds,
                                       'action': label.firstChild.nodeValue.strip()}}
                    if parameterized_value is not None:
                        automation_dict['type'] = 'volume'
                        automation_dict['type_specific']['parameter'] = parameterized_value.firstChild.nodeValue.strip()
                    if automation_dict['type_specific']['offset_from'] != 'start':
                        global_automation.append(automation_dict)
                    else:
                        automation.append(automation_dict)
                if child.tagName == 'ns2:CompositionPlaylistId':
                    cpl_uuid = strip_urn(child.firstChild.nodeValue.strip())
                    estimated_duration = parse_xs_duration(child.attributes['EstimatedDuration'].value)
                    composition_dict = {'cpl_id': cpl_uuid,
                     'edit_rate': None,
                     'text': unescape(child.attributes['Title'].value),
                     'duration_in_frames': None,
                     'duration_in_seconds': estimated_duration,
                     'type': 'composition',
                     'automation': automation,
                     'main_id': None,
                     'id': str(uuid.uuid4())}
                    events.append(composition_dict)
                    automation = []
                if child.tagName == 'ns2:SubShow':
                    subshow = child.getElementsByTagNameNS(ns2, 'SubShowId')[0]
                    marker = child.getElementsByTagNameNS(ns2, 'Marker')[0]
                    offset = marker.getElementsByTagNameNS(ns2, 'Offset')[0]
                    edit_rate = map(int, offset.attributes['EditRate'].value.split(' '))
                    fake_offset_in_frames = int(offset.firstChild.nodeValue.strip())
                    offset_in_seconds = fake_offset_in_frames / (1.0 * edit_rate[0] / edit_rate[1])
                    automation.append({'id': '0',
                     'name': 'Dolby Intermission',
                     'type': 'intermission',
                     'type_specific': {'offset_in_seconds': offset_in_seconds,
                                       'spl_uuid': strip_urn(subshow.firstChild.nodeValue.strip()),
                                       'spl_title': subshow.attributes['Title'].value.strip()}})
            child = child.nextSibling

        global_automation.extend(automation)
        if events:
            for automation in global_automation:
                if automation['type_specific']['offset_from'] == 'start':
                    remaining_offset = automation['type_specific']['offset_in_seconds'] * -1
                    for potential_event in reversed(events):
                        if not potential_event['duration_in_seconds']:
                            continue
                        elif remaining_offset > potential_event['duration_in_seconds']:
                            remaining_offset -= potential_event['duration_in_seconds']
                        else:
                            event = potential_event
                            break
                    else:
                        event = events[0]
                        remaining_offset = event['duration_in_seconds']

                    automation['type_specific']['offset_from'] = 'end'
                    automation['type_specific']['offset_in_seconds'] = remaining_offset
                    event['automation'].append(automation)
                elif automation['type_specific']['offset_from'] == 'end':
                    remaining_offset = 0
                    remaining_offset = automation['type_specific']['offset_in_seconds']
                    for potential_event in events:
                        if not potential_event['duration_in_seconds']:
                            continue
                        elif remaining_offset > potential_event['duration_in_seconds']:
                            remaining_offset -= potential_event['duration_in_seconds']
                        else:
                            event = potential_event
                            break
                    else:
                        remaining_offset = event['duration_in_seconds']
                        event = events[-1]

                    automation['type_specific']['offset_from'] = 'start'
                    automation['type_specific']['offset_in_seconds'] = remaining_offset
                    event['automation'].append(automation)
                else:
                    logging.warning('Unrecognized Dolby cue offset kind: "%s"' % str(automation['type_specific']['offset_from']))

        return events

    def _parse_playlist(self, playlist):
        """
        Parses the following information from a playlist
        """
        playlist_id = strip_urn(get_element_data(playlist, 'Id'))
        playlist_title = unescape(get_element_data(playlist, 'ShowTitleText'))
        playlist_text = unescape(get_element_data(playlist, 'AnnotationText'))
        playlist_events = self._parse_playlist_events(playlist)
        playlist_duration = reduce(lambda x, y: (x + y['duration_in_seconds'] if y['duration_in_seconds'] else x), playlist_events, 0)
        return {'id': playlist_id,
         'title': playlist_title,
         'text': playlist_text,
         'is_3d': False,
         'is_hfr': False,
         'is_4k': False,
         'duration_in_seconds': playlist_duration,
         'events': playlist_events,
         'automation': []}

    def _update_content_in_playlist(self, content_uuid, playlist_uuid):
        playlist = self.playlist_information[playlist_uuid]
        cpl = cherrypy.core.contents[content_uuid]
        playlist_is_3d = False
        playlist_is_hfr = False
        playlist_duration = 0
        for event in playlist['playlist']['events']:
            if event['type'] == 'composition' and event['cpl_id'] == content_uuid:
                if cpl['duration_in_seconds'] is not None:
                    event['duration_in_seconds'] = cpl['duration_in_seconds']
                if cpl['duration_in_frames'] is not None:
                    event['duration_in_frames'] = cpl['duration_in_frames']
                if cpl['edit_rate'][0] is not None and cpl['edit_rate'][1] is not None:
                    event['edit_rate'] = (cpl['edit_rate'][0], cpl['edit_rate'][1])
                    for automation_dict in event.get('automation', []):
                        automation_dict['type_specific']['offset_in_frames'] = int(automation_dict['type_specific']['offset_in_seconds']) * (1.0 * int(event['edit_rate'][0]) / int(event['edit_rate'][1]))

                    playlist_is_hfr |= cpl['edit_rate'][0] > HFR_FPS
                playlist_is_3d |= cpl['playback_mode'] == '3D'
                if event['duration_in_seconds']:
                    playlist_duration += event['duration_in_seconds']

        playlist['duration_in_seconds'] = playlist['playlist']['duration_in_seconds'] = playlist_duration
        playlist['is_3d'] = playlist['playlist']['is_3d'] = playlist_is_3d
        playlist['is_hfr'] = playlist['playlist']['is_hfr'] = playlist_is_hfr
        return

    def server_performance_metrics(self):
        return [self.playback_information['playback_state'], 'transfers: ' + str(len(self.transfer_information.get('transfers', [])))]

    def reboot(self):
        if os.name == 'posix':
            os.popen('ssh administrator:dolby@' + self.device_configuration['ip'] + ' reboot')
            return {'error_messages': []}
        else:
            return {'error_messages': [_('Reboot is only available for Dolby on a posix platform')]}

    def get_playback_status(self):
        """
        This recieves the current playback status
        
        @param      None
        @return     {
                        playback_state:         INTEGER     - id telling us which play state we're in e.g. play, pause
                        spl_uuid:               STRING      - loaded_spl id
                        spl_position:           INTEGER     - seconds into playlist
                        element_id:             STRING      - current loaded event
                        element_position:       INTEGER     - seconds into event
                        modes[playback_mode]:   STRING      - e.g. TWO_D, THREE_D or DOLBY_3D
                        modes[auto_playback_mode]: STRING   - MANUAL only in this version
                        modes[scheduler_enabled]: BOOLEAN   - is the scheduler enabled
                        scheduler_enabled:      BOOLEAN     - is the scheduler enabled
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'error_messages': [],
         'modes': {}}
        show_playlist_status_response = self.execute(self.PLAYBACK, 'getPlaybackState')
        if check_response(show_playlist_status_response):
            if show_playlist_status_response['transportState']['transportStateType'] == 'EXTENSION':
                output['playback_state'] = TRANSPORT_STATE_DICT.get(show_playlist_status_response['transportState']['transportStateType__extension'], 'error')
                self.last_known_transport_state = show_playlist_status_response['transportState']['transportStateType__extension']
            else:
                output['playback_state'] = TRANSPORT_STATE_DICT.get(show_playlist_status_response['transportState']['transportStateType'], 'error')
                self.last_known_transport_state = show_playlist_status_response['transportState']['transportStateType']
            if 'contentPlaybackState' in show_playlist_status_response:
                output['spl_uuid'] = strip_urn(show_playlist_status_response['contentPlaybackState']['contentId'])
                output['spl_position'] = int(parse_xs_duration(show_playlist_status_response['contentPlaybackState']['showPosition']))
                output['spl_duration'] = int(parse_xs_duration(show_playlist_status_response['contentPlaybackState']['showDuration']))
                output['cpl_uuid'] = strip_urn(show_playlist_status_response['contentPlaybackState']['currentClipId'])
                output['element_id'] = str(show_playlist_status_response['contentPlaybackState']['currentClipIndex'])
                output['element_position'] = int(parse_xs_duration(show_playlist_status_response['contentPlaybackState']['clipPosition']))
                output['element_duration'] = int(parse_xs_duration(show_playlist_status_response['contentPlaybackState']['clipDuration']))
                output['element_index'] = int(show_playlist_status_response['contentPlaybackState']['currentClipIndex'])
            else:
                output['spl_uuid'] = None
                output['spl_position'] = None
                output['spl_duration'] = None
                output['cpl_uuid'] = None
                output['element_id'] = None
                output['element_position'] = None
                output['element_duration'] = None
                output['element_index'] = None
            output['modes']['playback_mode'] = PLAYBACK_MODE_DICT[show_playlist_status_response['playbackMode']]
            output['modes']['auto_playback_mode'] = 'MANUAL'
        elif not self.projector_connected:
            output['playback_state'] = 'projector_disconnected'
        else:
            output['error_messages'].append(show_playlist_status_response['error_message'])
        if self.projector_connected:
            scheduler_enable_response = self.execute(self.PLAYBACK, 'getScheduleMode')
            if check_response(scheduler_enable_response):
                output['modes']['scheduler_enabled'] = SCHEDULE_MODE_DICT[scheduler_enable_response['scheduleMode']]
            else:
                output['error_messages'].append(scheduler_enable_response['error_message'])
        return output

    def get_transfer_ids(self):
        self.log('get_transfer_ids')
        output = {'error_messages': []}
        transfer_id_response = self.execute(self.TRANSFER, 'getTransfers', list_tags=['transferId'])
        if check_response(transfer_id_response):
            output['transfers'] = transfer_id_response.get('transferId', [])
        else:
            output['error_messages'].append(transfer_id_response['error_message'])
        return output

    def get_transfer_info(self, transfer_ids):
        self.log('get_transfer_info')
        output = {'error_messages': [],
         'transfers': []}
        for transfer_id in transfer_ids:
            response = self.execute(self.TRANSFER, 'getTransferInfos', params={'transferId': transfer_id})
            if not response:
                continue
            transfer_info = response['transferInfo']
            output_information = {'server_transfer_id': transfer_id,
             'state': None,
             'description': None,
             'content_id': None,
             'type': transfer_info['contentType'],
             'source': None,
             'progress': None,
             'message': None,
             'message_code': None}
            if transfer_info['transferProtocolType'] != 'FTP':
                output_information['source'] = transfer_info['transferProtocolType']
            elif transfer_info.get('url'):
                if transfer_info['url'].find(':') == 1:
                    parsed_url = ParseResult('', '', transfer_info['url'], '', '', '')
                else:
                    parsed_url = urlparse(transfer_info['url'])
                if not parsed_url.scheme or parsed_url.scheme == 'file':
                    output_information['source'] = 'local'
                elif parsed_url.scheme == 'ftp':
                    output_information['source'] = parsed_url.hostname
            else:
                output_information['source'] = 'FTP'
            if transfer_info.get('transferDescription') and 'urn:uuid' in transfer_info['transferDescription']:
                output_information['content_id'] = strip_urn(transfer_info['transferDescription'])
            if transfer_info['transferStatus'] in ('NOT_AVAILABLE', 'PENDING', 'UNKNOWN'):
                output_information['state'] = 'queued_on_device'
                output_information['message'] = _('Transfer queued on the screen server')
                output_information['message_code'] = 7
            elif transfer_info['transferStatus'] in ('PAUSED',):
                output_information['state'] = 'paused'
                output_information['message'] = _('Transfer is paused')
                output_information['message_code'] = 8
            elif transfer_info['transferStatus'] in ('IN_PROGRESS', 'AWAITING_VERIFICATION', 'VERIFYING', 'CANCELLATION_PENDING'):
                output_information['state'] = 'active'
                output_information['message'] = _('Transfer in progress')
                output_information['message_code'] = 9
            elif transfer_info['transferStatus'] in ('FINISHED',) or transfer_info['transferStatus'] == 'ERROR' and transfer_info['transferStatusReason'] == 'CONTENT_EXISTS':
                output_information['state'] = 'success'
                output_information['message'] = _('Transfer successful')
                output_information['message_code'] = 10
            elif transfer_info['transferStatus'] in ('CANCELLED',):
                output_information['state'] = 'cancelled'
                output_information['message'] = _('Transfer cancelled')
                output_information['message_code'] = 6
            elif transfer_info['transferStatus'] in ('ERROR',):
                output_information['state'] = 'failed'
                output_information['message'] = TRANSFER_STATUS_ERRORS.get(transfer_info['transferStatusReason'], transfer_info['transferStatusReason'])
                output_information['message_code'] = None
            output_information['progress'] = int(transfer_info['percentageComplete'])
            output['transfers'].append(output_information)

        return output

    def ready_for_kdm_transfer(self):
        """
        we need to check four things:
        - the decoder component must be present
        - the player component must be present
        - the license load state must be IDLE
        - the playback state must be STOPPED, UNSELECTED or READY
        """
        decoder_present = False
        player_present = False
        license_load_state = None
        playback_state = None
        device_component_response = self.execute(self.SYSTEM, 'getDeviceComponentInfos', list_tags=['deviceComponentInfo'])
        if check_response(device_component_response):
            for component in device_component_response.get('deviceComponentInfo', []):
                if not (decoder_present and player_present):
                    if component['deviceComponentType'] == 'DECODER':
                        decoder_present = True
                    elif component['deviceComponentType'] == 'PLAYER':
                        player_present = True
                else:
                    break

        if not decoder_present or not player_present:
            return False
        else:
            license_load_response = self.execute(self.LICENSE, 'getLicenseLoadState', version='1_1')
            if check_response(license_load_response):
                if license_load_response.get('licenseLoadState') and license_load_response['licenseLoadState'].get('loadStatus'):
                    license_load_state = license_load_response['licenseLoadState']['loadStatus']
            if license_load_state != 'IDLE':
                return False
            if cfg.dolby_playback_check_before_kdm_transfer.get():
                playback_response = self.execute(self.PLAYBACK, 'getPlaybackState')
                if check_response(playback_response):
                    if playback_response.get('transportState') and playback_response['transportState'].get('transportStateType'):
                        playback_state = playback_response['transportState']['transportStateType']
                if playback_state not in ('STOPPED', 'UNSELECTED', 'READY'):
                    return False
            return True

    def get_content_uuid_list(self):
        self.log('get_content_uuid_list')
        output = {'error_messages': []}
        cpl_id_list_response = self.execute(self.CONTENT, 'getClips', list_tags=['clipId'])
        if check_response(cpl_id_list_response):
            output['content_uuid_list'] = [ strip_urn(cpl_id) for cpl_id in cpl_id_list_response.get('clipId', []) ]
        else:
            output['error_messages'].append(cpl_id_list_response['error_message'])
        return output

    def get_content_information(self, content_uuids):
        self.log('get_content_information')
        output = {'error_messages': [],
         'content_info_dict': {}}
        for content_uuid in content_uuids:
            cpl_info = {'content_title_text': content_uuid,
             'content_kind': 'unknown',
             'edit_rate': None,
             'subtitled': None,
             'subtitle_language': None,
             'playback_mode': None,
             'aspect_ratio': None,
             'duration_in_seconds': 0,
             'duration_in_frames': 0,
             'encrypted': None,
             'xml': None,
             'parsed_info': parse_content_title_text(''),
             'video_encoding': 'UNKNOWN'}
            try:
                cpl_xml_response = self.execute(self.CONTENT, 'getCPL', params={'clipId': wrap_urn(content_uuid)})
                if check_response(cpl_xml_response):
                    temp_cpl = parse_cpl(cpl_xml_response['clip'], load_from_file=False)
                    cpl_info['content_title_text'] = unescape(temp_cpl['text'])
                    cpl_info['content_kind'] = temp_cpl['type']
                    cpl_info['edit_rate'] = temp_cpl['edit_rate']
                    cpl_info['subtitled'] = temp_cpl['subtitled']
                    cpl_info['subtitle_language'] = temp_cpl['subtitle_language']
                    cpl_info['playback_mode'] = temp_cpl['playback_mode']
                    cpl_info['aspect_ratio'] = temp_cpl['aspect_ratio']
                    cpl_info['duration_in_seconds'] = temp_cpl['duration_in_seconds']
                    cpl_info['duration_in_frames'] = temp_cpl['duration_in_frames']
                    cpl_info['encrypted'] = temp_cpl['encrypted']
                    cpl_info['xml'] = cpl_xml_response['clip']
                    cpl_info['parsed_info'] = temp_cpl['parsed_info']
                else:
                    cpl_info['error_message'] = cpl_xml_response['error_message']
                    output['error_messages'].append(cpl_xml_response['error_message'])
                if not self.projector_connected:
                    cpl_info['error_message'] = _('Cannot retrieve CPL information because the projector is disconnected or offline')
            except Exception as ex:
                logging.error('Error getting cpl information for cpl_id %s' % content_uuid, exc_info=True)
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))

            output['content_info_dict'][content_uuid] = cpl_info

        return output

    def is_ready_for_collect(self):
        """
        Overwrite this function if there are conditions which must be met
        before we can start log collection.
        @return
                bool
        
        """
        return self.last_known_transport_state != 'PLAYING'

    def get_content_validation_information(self, content_uuids):
        self.log('get_content_validation_information')
        output = {'error_messages': [],
         'content_validation_dict': {}}
        response = self.execute(self.CONTENT, 'getClipInfos', list_tags=['clipInfo'])
        if check_response(response):
            for content_uuid in content_uuids:
                wrapped_uuid = wrap_urn(content_uuid)
                for content_information in response.get('clipInfo', []):
                    if content_information['clipId'] == wrapped_uuid:
                        output['content_validation_dict'][content_uuid] = {}
                        if content_information['transferring'] == u'true':
                            output['content_validation_dict'][content_uuid]['validation_code'] = 3
                        elif content_information['corrupt'] == u'true':
                            output['content_validation_dict'][content_uuid]['validation_code'] = 2
                        elif content_information['missingData'] == u'true':
                            output['content_validation_dict'][content_uuid]['validation_code'] = 1
                        else:
                            output['content_validation_dict'][content_uuid]['validation_code'] = 0
                        if 'url' in content_information:
                            output['content_validation_dict'][content_uuid]['ingest_path'] = content_information['url'].split('/', 3)[3]
                        else:
                            output['content_validation_dict'][content_uuid]['ingest_path'] = ''
                        if 'size' in content_information:
                            output['content_validation_dict'][content_uuid]['cpl_size'] = str(int(content_information['size']) * 1048576)
                        else:
                            output['content_validation_dict'][content_uuid]['cpl_size'] = '0'
                        break

        else:
            output['error_messages'].append(response['error_message'])
        return output

    def validate_playlist(self, playlist_uuid):
        self.log('validate_playlist')
        output = {'error_messages': []}
        response = {'result': 0,
         'error_code': 0,
         'description': '',
         'cpl_uuid': ''}
        KDM_STATES = ['NOT_NEEDED',
         'NOT_RELEVANT',
         'OK',
         'ABOUT_TO_EXPIRE']
        get_show_info_response = self.execute(self.SHOW, 'getShowInfos', params={'showId': wrap_urn(playlist_uuid)}, list_tags=['showInfo'])
        if check_response(get_show_info_response):
            for info in get_show_info_response.get('showInfo', []):
                spl_name = info['name']
                if info['corrupt'] == 'true':
                    response['result'] = 1
                    response['error_code'] = 1
                    response['description'] = _('A CPL is corrupt')
                elif info['playable'] == 'false':
                    if info['missingData'] == 'true':
                        response['result'] = 1
                        response['error_code'] = 3
                        response['description'] = _('A CPL is not registered on this server')
                    else:
                        response['result'] = 1
                        response['error_code'] = 3
                        response['description'] = _('Playlist is not playable')
                elif info['licensed'] not in KDM_STATES:
                    response['result'] = 1
                    response['error_code'] = 3
                    response['description'] = _('A CPL requires a KDM which cannot be found')

        output['info'] = response
        return output

    def get_playlist_uuid_list(self):
        self.log('get_playlist_uuid_list')
        output = {'error_messages': []}
        spl_id_list_response = self.execute(self.SHOW, 'getShows', list_tags=['showId'])
        if check_response(spl_id_list_response):
            output['playlist_uuid_list'] = [ strip_urn(spl_id) for spl_id in spl_id_list_response.get('showId', []) ]
        else:
            output['error_messages'].append(spl_id_list_response['error_message'])
        return output

    def get_playlist_information(self, playlist_uuids):
        self.log('get_playlist_information')
        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for playlist_uuid in playlist_uuids:
            retrieve_playlist_response = self.execute(self.SHOW, 'getSPL', params={'showId': wrap_urn(playlist_uuid)})
            if check_response(retrieve_playlist_response):
                playlist = self._parse_playlist(retrieve_playlist_response['show'])
                output['playlist_info_dict'][playlist_uuid] = {}
                output['playlist_info_dict'][playlist_uuid]['title'] = unescape(playlist['title'] or playlist['text'])
                output['playlist_info_dict'][playlist_uuid]['duration_in_seconds'] = playlist['duration_in_seconds']
                output['playlist_info_dict'][playlist_uuid]['is_3d'] = playlist['is_3d']
                output['playlist_info_dict'][playlist_uuid]['is_hfr'] = playlist['is_hfr']
                output['playlist_info_dict'][playlist_uuid]['is_4k'] = playlist['is_4k']
                output['playlist_info_dict'][playlist_uuid]['playlist'] = playlist
            else:
                output['error_messages'].append(retrieve_playlist_response['error_message'])

        return output

    def get_key_uuid_list(self):
        self.log('get_key_uuid_list')
        output = {'error_messages': []}
        key_id_list_response = self.execute(self.LICENSE, 'getLicenses', list_tags=['licenseId'])
        if check_response(key_id_list_response):
            output['key_uuid_list'] = [ strip_urn(key_id) for key_id in key_id_list_response.get('licenseId', []) ]
        else:
            output['error_messages'].append(key_id_list_response['error_message'])
        return output

    def get_key_information(self, key_uuids):
        self.log('get_key_information')
        output = {'error_messages': [],
         'key_info_dict': {}}
        response = self.execute(self.LICENSE, 'getLicenseInfos', list_tags=['licenseInfo'])
        key_infos = dict(((strip_urn(info['licenseId']), info['licenseStatus']) for info in response.get('licenseInfo', [])))
        for key_uuid in key_uuids:
            retrieve_kdm_response = self.execute(self.LICENSE, 'getKDM', params={'licenseId': wrap_urn(key_uuid)})
            if check_response(retrieve_kdm_response):
                kdm = parse_kdm(retrieve_kdm_response['license'], load_from_file=False)
                output['key_info_dict'][key_uuid] = {}
                output['key_info_dict'][key_uuid]['cpl_title'] = unescape(kdm['cpl_text'])
                output['key_info_dict'][key_uuid]['cpl_uuid'] = kdm['cpl_id']
                output['key_info_dict'][key_uuid]['not_valid_before'] = kdm['start_date']
                output['key_info_dict'][key_uuid]['not_valid_after'] = kdm['end_date']
                output['key_info_dict'][key_uuid]['dnqualifier'] = kdm['dn_qualifier']
                output['key_info_dict'][key_uuid]['status'] = KDM_STATUS.get(key_infos.get(key_uuid), 'unknown')
            else:
                output['error_messages'].append(retrieve_kdm_response['error_message'])

        return output

    def get_key(self, key_uuid):
        """
        gets key xml
        
        @return
            dict
                xml        DICT
                    xml    STRING
                error_messages          -LIST of errors
        """
        output = {'error_messages': [],
         'xml': {}}
        retrieve_kdm_response = self.execute(self.LICENSE, 'getKDM', params={'licenseId': wrap_urn(key_uuid)})
        if check_response(retrieve_kdm_response):
            output['xml'] = retrieve_kdm_response['license']
        else:
            output['error_messages'].append(retrieve_kdm_response['error_message'])
        return output

    def toggle_log_action(self, toggle):
        self.log_actions = toggle

    def log(self, string):
        if self.log_actions:
            logging.info('Screen %s: %s' % (self.device_configuration['screen_identifier'], string))

    def get_schedule_id_list(self):
        self.log('get_schedule_id_list')
        output = {'error_messages': []}
        time_begin_timestamp = (datetime.datetime.utcnow() - datetime.timedelta(days=14)).strftime('%Y-%m-%dT%H:%M:%S+00:00')
        time_end_timestamp = (datetime.datetime.utcnow() + datetime.timedelta(days=365)).strftime('%Y-%m-%dT%H:%M:%S+00:00')
        response = self.execute(self.SHOW, 'getShowTimes', params={'startTime': time_begin_timestamp,
         'endTime': time_end_timestamp}, list_tags=['showTimeId'])
        if check_response(response):
            output['schedule_id_list'] = [ strip_urn(schedule_id) for schedule_id in response.get('showTimeId', []) ]
        else:
            output['error_messages'].append(response['error_message'])
        return output

    def get_schedule_information(self, schedule_ids):
        self.log('get_schedule_information')
        output = {'error_messages': [],
         'schedule_info_dict': {}}
        time_begin_string = (datetime.datetime.utcnow() - datetime.timedelta(days=14)).strftime('%Y-%m-%dT%H:%M:%S+00:00')
        time_end_string = (datetime.datetime.utcnow() + datetime.timedelta(days=365)).strftime('%Y-%m-%dT%H:%M:%S+00:00')
        for schedule_id in schedule_ids:
            get_schedule_info_response = self.execute(self.SHOW, 'getShowTimeInfos', params={'showTimeId': wrap_urn(schedule_id),
             'startTime': time_begin_string,
             'endTime': time_end_string}, list_tags=['showTimeInfo'])
            if check_response(get_schedule_info_response):
                if get_schedule_info_response.get('showTimeInfo'):
                    start_time_str = get_schedule_info_response['showTimeInfo'][0]['startTime']
                    showtime_infos = self.execute(self.SHOW, 'getShowTimeInfos', params={'startTime': start_time_str,
                     'endTime': start_time_str}, list_tags=['showTimeInfo'])
                    if check_response(showtime_infos):
                        for info in showtime_infos.get('showTimeInfo', []):
                            if strip_urn(info['showTimeId']) == schedule_id:
                                output['schedule_info_dict'][schedule_id] = {}
                                output['schedule_info_dict'][schedule_id]['device_playlist_uuid'] = strip_urn(info['showId'])
                                output['schedule_info_dict'][schedule_id]['start_time'] = parse_date(start_time_str)
                                output['schedule_info_dict'][schedule_id]['device_schedule_id'] = schedule_id
                                break
                        else:
                            output['error_messages'].append(_('Error getting scheduling information for ID: %s') % schedule_id)

                    else:
                        output['error_messages'].append(showtime_infos['error_message'])
                else:
                    output['error_messages'].append(_('Error getting scheduling information for ID: %s') % schedule_id)
            else:
                output['error_messages'].append(get_schedule_info_response['error_message'])

        return output

    def content_add_key(self, key):
        kdm = parse_kdm(key, load_from_file=False)
        filename = kdm['id'] + '.xml'
        tmp_file_path = os.path.join(cfg.lms_library_directory(), 'tmp', filename)
        if not os.path.exists(tmp_file_path):
            with open(tmp_file_path, 'wb') as f:
                f.write(key)
        ingest_url = 'ftp://%s:%s@%s:%d/%s' % (cfg.lms_ftp_username(),
         cfg.lms_ftp_password(),
         cfg.lms_ftp_ip(),
         cfg.lms_ftp_port(),
         posixpath.join('tmp', filename))
        message = ''
        success = False
        try:
            response = self.execute(self.TRANSFER, 'transferContent', params={'contentType': 'LICENSE',
             'url': ingest_url})
            if not check_response(response):
                return (False, response['error_message'])
            transfer_id = response['transferId']
            time.sleep(1)
            transfer_infos = self.execute(self.TRANSFER, 'getTransferInfos', list_tags=['transferInfo'])
            if not check_response(transfer_infos):
                return (False, response['error_message'])
            for transfer_info in transfer_infos.get('transferInfo', []):
                if transfer_info['transferId'] == transfer_id:
                    if transfer_info['transferStatus'] in ('FINISHED', 'ERROR', 'CANCELLED'):
                        if transfer_info['transferStatus'] == 'ERROR':
                            return (False, str(transfer_info['transferStatusReason']))

            for attempt in xrange(25):
                time.sleep(3)
                key_id_list_response = self.execute(self.LICENSE, 'getLicenses', list_tags=['licenseId'])
                if not check_response(key_id_list_response):
                    success = False
                    message = key_id_list_response['error_message']
                else:
                    key_uuid_list = [ strip_urn(key_id) for key_id in key_id_list_response.get('licenseId', []) ]
                    if kdm['id'] in key_uuid_list:
                        message = _('KDM saved on %s for CPL %s') % (self.device_configuration['screen_identifier'], kdm['cpl_text'])
                        break
                    else:
                        success = False
                        message = _('Unknown error saving KDM for %s') % kdm['cpl_text']

            return (success, message)
        finally:
            os.remove(tmp_file_path)

    def content_cancel_transfer(self, transfer_id):
        response = self.execute(self.TRANSFER, 'cancelTransfer', params={'transferId': transfer_id})
        if check_response(response):
            return (True, _('Transfer cancelled'))
        else:
            return (False, response['error_message'])

    def content_clear_transfer_history(self):
        response = self.execute(self.TRANSFER, 'clearTransferHistory')
        if check_response(response):
            return (True, _('Transfer history cleared'))
        else:
            return (False, response['error_message'])

    def content_transfer(self, connection_details, description, cpl_uuid):
        ingest_path = urllib.quote(connection_details['ingest_path'].encode('utf-8'))
        ingest_url = 'ftp://%s:%s@%s:%d/%s' % (connection_details['ftp_username'],
         connection_details['ftp_password'],
         connection_details['ftp_ip'],
         connection_details['ftp_port'],
         connection_details['ingest_path'])
        response = self.execute(self.TRANSFER, 'transferContent', params={'url': ingest_url,
         'userName': connection_details['ftp_username'],
         'password': connection_details['ftp_password']})
        if check_response(response):
            return (True, _('Transfer started'), response['transfer_id'])
        else:
            return (False, response['error_message'], None)
            return None

    def content_delete(self, content_id, sleep = False):
        if sleep:
            time.sleep(2.5)
        response = self.execute(self.CONTENT, 'deleteContent', params={'contentId': wrap_urn(content_id),
         'contentStore': 'MAINSTORE'})
        if check_response(response):
            return (True, _('CPL deleted'))
        else:
            return (False, response['error_message'])

    def content_delete_key(self, key_id):
        return (False, _('KDMs can not be deleted from a Dolby'))

    def get_ingest_path(self, content_uuid):
        self.log('get_ingest_path')
        response = self.execute(self.CONTENT, 'getClipInfos', params={'clipId': wrap_urn(content_uuid),
         'contentStore': 'MAINSTORE'}, list_tags=['clipInfo'])
        url = None
        for info in response.get('clipInfo', []):
            if info['clipId'] == wrap_urn(content_uuid):
                url = info['url']
                if url.find(':') == 1:
                    parsed_url = ParseResult('', '', url, '', '', '')
                else:
                    parsed_url = urlparse(url)
                url = parsed_url.path
                break

        return url

    def playback_eject(self):
        playback_status = self.get_playback_status()
        if playback_status['playback_state'] != 'stop':
            stop_response = self.playback_stop()
            if not stop_response[0]:
                success = False
                message = stop_response[1]
                return (success, message)
        for attempt in xrange(20):
            time.sleep(3)
            playback_status = self.get_playback_status()
            if playback_status['playback_state'] == 'stop':
                break

        response = self.execute(self.PLAYBACK, 'selectContent')
        if check_response(response):
            self._device_sync_playback_status()
            success = True
            message = _('Playlist ejected')
        else:
            success = False
            message = response['error_message']
        return (success, message)

    def playback_load(self, spl_uuid):
        response = self.execute(self.PLAYBACK, 'selectContent', params={'contentId': wrap_urn(spl_uuid)})
        if check_response(response):
            self._device_sync_playback_status()
            return (True, _('Playlist loaded: %s') % self.playlist_information[spl_uuid]['title'])
        else:
            return (False, response['error_message'])

    def playback_pause(self):
        response = self.execute(self.PLAYBACK, 'pause')
        if check_response(response):
            self._device_sync_playback_status()
            return (True, _('Playback paused'))
        else:
            return (False, response['error_message'])

    def playback_play(self):
        response = self.execute(self.PLAYBACK, 'play')
        if check_response(response):
            self._device_sync_playback_status()
            return (True, _('Playback started'))
        else:
            return (False, response['error_message'])

    def playback_stop(self):
        response1 = self.execute(self.PLAYBACK, 'stop')
        response2 = self.execute(self.PLAYBACK, 'goToPosition', params={'position': 'PT0S'})
        if check_response(response1) and check_response(response2):
            self._device_sync_playback_status()
            return (True, _('Playback stopped'))
        else:
            return (False, response1['error_message'])

    def playback_skip_forward(self):
        response = self.execute(self.PLAYBACK, 'next')
        if check_response(response):
            self._device_sync_playback_status()
            return (True, _('Playback skipped forward'))
        else:
            return (False, response['error_message'])

    def playback_skip_backward(self):
        response = self.execute(self.PLAYBACK, 'previous')
        if check_response(response):
            self._device_sync_playback_status()
            return (True, _('Playback skipped backwards'))
        else:
            return (False, response['error_message'])

    def playback_set_mode(self, mode):
        if mode in self.supported_modes['schedule_modes']:
            response = self.execute(self.PLAYBACK, 'setScheduleMode', params={'scheduleMode': SCHEDULE_MODE_TRANS[mode]})
        elif mode in self.supported_modes['playback_modes']:
            response = self.execute(self.PLAYBACK, 'setPlaybackMode', params={'playbackMode': PLAYBACK_MODE_DICT[mode]})
        else:
            return (False, _('Playback mode %s not recognised') % mode)
        if check_response(response):
            return (True, _('Playback mode set to %s') % mode)
        else:
            return (False, response['error_message'])

    def playlist_delete(self, playlist_uuid):
        response = self.execute(self.SHOW, 'deleteShow', params={'showId': wrap_urn(playlist_uuid)})
        if check_response(response):
            spl_id_list_response = self.execute(self.SHOW, 'getShows', list_tags=['showId'])
            if check_response(spl_id_list_response):
                playlist_uuid_list = [ strip_urn(spl_id) for spl_id in spl_id_list_response.get('showId', []) ]
                if playlist_uuid in playlist_uuid_list:
                    return (False, _('Playlist could not be deleted'))
                else:
                    return (True, _('Playlist deleted'))
            else:
                return (False, spl_id_list_response['error_message'])
        else:
            return (False, response['error_message'])

    def playlist_save(self, playlist):
        spl = self._dolby_xml(playlist)
        response = self.execute(self.SHOW, 'createShow', params={'show': spl})
        if check_response(response):
            return (True, _('Saved: %s') % playlist['title'])
        else:
            return (False, response['error_message'])

    def scheduling_delete(self, schedule_id):
        self.log('scheduling_delete')
        response = self.execute(self.SHOW, 'deleteShowTimes', params={'showTimeId': wrap_urn(schedule_id)})
        if check_response(response):
            return (True, _('Schedule deleted'))
        else:
            return (False, response['error_message'])

    def scheduling_schedule_playlist(self, playlist_id, timestamp):
        self.log('scheduling_schedule_playlist')
        time_begin_string = datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%dT%H:%M:%S+00:00')
        response = self.execute(self.SHOW, 'createShowTimes', params={'showTimeRequest': {'sho:showId': wrap_urn(playlist_id),
                             'sho:startTime': time_begin_string}})
        response = response['showTimeResponse']
        if response.get('fault__nil') and response['fault__nil'] == 'true':
            schedule_id = strip_urn(response['showTimeId'])
            return (True, _('Playlist %s has been scheduled for %s') % (playlist_id, helper_methods.format_timestamp(timestamp)), {'device_playlist_uuid': playlist_id,
              'start_time': timestamp,
              'device_schedule_id': schedule_id})
        else:
            if response.get('fault') and response['fault'].get('reason'):
                message = response['fault']['reason']
            else:
                message = _('Unknown error scheduling playlist %s at %s') % (playlist_id, timestamp)
            return (False, message, {})

    def get_automation_list(self):
        self.log('get_automation_list')
        output = {'error_messages': []}
        automation_list_response = self.execute(self.SHOW, 'getCueInfos', list_tags=['cueInfo'])
        if check_response(automation_list_response):
            automation_list = []
            for cue in automation_list_response.get('cueInfo', []):
                automation_list.append(strip_urn(cue['cueId']))

            output['automation_uuid_list'] = automation_list
        else:
            output['error_messages'].append(automation_list_response['error_message'])
        return output

    def get_automation_information(self, automation_ids):
        self.log('get_automation_information')
        output = {'error_messages': [],
         'automation_info_dict': {}}
        automation_list_response = self.execute(self.SHOW, 'getCueInfos', list_tags=['cueInfo'])
        if check_response(automation_list_response):
            for automation in automation_list_response.get('cueInfo', []):
                automation_id = strip_urn(automation['cueId'])
                if automation_id in automation_ids:
                    output['automation_info_dict'][automation_id] = {}
                    output['automation_info_dict'][automation_id]['name'] = automation['name']
                    output['automation_info_dict'][automation_id]['duration'] = 0
                    type = 'cue'
                    if automation['parameterized'] == 'true':
                        type = 'volume'
                    output['automation_info_dict'][automation_id]['type'] = type

        else:
            output['error_messages'].append(automation_list_response['error_message'])
        if 'intermission' in automation_ids:
            output['automation_info_dict']['intermission'] = {'name': 'Dolby Intermission',
             'duration': 0,
             'type': 'intermission'}
        return output

    def get_trigger_list(self):
        self.log('get_trigger_list')
        output = {'error_messages': []}
        output['trigger_uuid_list'] = []
        return output

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        return (False, _('Manual automation cue execution is not supported by Dolby versions below 4.3'))

    def get_device_status(self):
        self.log('get_device_status')
        output = {'error_messages': []}
        time_response = self.execute(self.SYSTEM, 'getSystemTime')
        if check_response(time_response):
            output['current_time'] = parse_date(time_response['time'])
        else:
            output['error_messages'].append(time_response['error_message'])
        return output

    def test_management_connection(self):
        try:
            self.execute(self.SYSTEM, 'getSystemTime')
        except httplib.HTTPException as ex:
            return (False, _('HTTP error %s') % str(ex))
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error %s') % str(ex))

        return (True, _('OK'))

    def get_device_version_information(self):
        self.log('get_device_version_information')
        output = {'error_messages': []}
        product_cert_response = self.execute(self.SYSTEM, 'getDeviceComponentInfos', list_tags=['deviceComponentInfo'])
        if check_response(product_cert_response):
            for component in product_cert_response.get('deviceComponentInfo', []):
                if component['deviceComponentType'] == 'DECODER':
                    if 'deviceComponentProperty' in component:
                        for sub_component in component['deviceComponentProperty']:
                            if sub_component['name'] == 'software.version' and 'software_version' not in output:
                                output['software_version'] = sub_component['value']

                elif component['deviceComponentType'] == 'PLAYER':
                    if 'deviceComponentProperty' in component:
                        for sub_component in component['deviceComponentProperty']:
                            if sub_component['name'] == 'version':
                                output['software_version'] = sub_component['value']

        else:
            output['error_messages'].append(product_cert_response['error_message'])
        return output

    def get_device_information(self):
        self.log('get_device_information')
        output = {'error_messages': [],
         'dnqualifiers': [],
         'device_dnqualifier': None,
         'product_certificates': {}}
        product_cert_response = self.execute(self.SYSTEM, 'getDeviceComponentInfos', list_tags=['deviceComponentInfo'])
        if check_response(product_cert_response):
            for component in product_cert_response.get('deviceComponentInfo', []):
                if component['deviceComponentType'] == 'DECODER':
                    if 'deviceComponentProperty' in component:
                        for sub_component in component['deviceComponentProperty']:
                            if sub_component['name'] and sub_component['name'].lower() == 'publickeyhash':
                                output['dnqualifiers'].append(sub_component['value'])
                                output['device_dnqualifier'] = sub_component['value']
                            elif sub_component['name'] == 'serialnumber':
                                output['serial'] = sub_component['value']

                    if 'deviceComponentModel' in component:
                        output['model'] = self._determine_sms_model(component['deviceComponentModel'])
                elif component['deviceComponentType'] == 'PLAYER':
                    if 'deviceComponentProperty' in component:
                        for sub_component in component['deviceComponentProperty']:
                            if sub_component['name'] == 'version':
                                output['software_version'] = sub_component['value']
                            elif sub_component['name'] == 'Ethernet - Theatre Link Address':
                                output['ftp_ip_address'] = sub_component['value']

        else:
            output['error_messages'].append(product_cert_response['error_message'])
        showStoreStorageStatusValue = '.1.3.6.1.4.1.6729.2.1.1.3.1.2.2.1.5.0'
        try:
            snmp_status = self.snmp_manager.snmpGet(showStoreStorageStatusValue, self.device_configuration['ip'], version=2)
        except SNMPException as ex:
            output['error_messages'].append(_('Error retrieving the RAID status: %s') % str(ex))
            snmp_status = None

        RAID_STATUS = {'notAvailable': {'message': 'Unavailable',
                          'status': 'error'},
         'ok': {'message': 'OK',
                'status': 'ok'},
         'unknown': {'message': 'Unknown',
                     'status': 'error'},
         'invalid': {'message': 'Invalid',
                     'status': 'error'},
         'fault': {'message': 'Faulty',
                   'status': 'error'},
         'rebuilding': {'message': 'Rebuilding',
                        'status': 'error'},
         'initializing': {'message': 'Initializing',
                          'status': 'error'},
         'degraded': {'message': 'Degraded',
                      'status': 'warning'}}
        raid_status = RAID_STATUS.get(snmp_status, {'message': 'Unknown',
         'status': 'error'})
        raid_status['name'] = 'MainStore'
        output['raid_status'] = [raid_status]
        content_stores_response = self.execute(self.SYSTEM, 'getContentStores', list_tags=['contentStoreInfo'])
        if check_response(content_stores_response):
            free_space = 0
            total_space = 0
            for store in content_stores_response.get('contentStoreInfo', []):
                free_space += int(store['freeSpace'])
                total_space += int(store['totalSpace'])

            output['storage_total'] = total_space * 1024 * 1024
            output['storage_used'] = (total_space - free_space) * 1024 * 1024
            output['storage_available'] = free_space * 1024 * 1024
        else:
            output['error_messages'].append(content_stores_response['error_message'])
            output['storage_total'] = None
            output['storage_used'] = None
            output['storage_available'] = None
        return output

    def _determine_sms_model(self, decoder_model):
        """
        Determine the Dolby model based on the installed media block/decoder model.
        """
        if decoder_model == 'cat862':
            return 'dss200'
        elif decoder_model == 'cat745':
            return 'dby-imb'
        else:
            return 'dss100'

    def get_logs(self, start_datetime):
        self.log('get_logs')
        output = {'error_messages': [],
         'xml': None}
        log_status = self.execute(self.SYSTEM, 'getAuditLogsStatus', list_tags=['auditLogStatusInfo'])
        auditLogStatusInfos = log_status.get('auditLogStatusInfo', [])
        transfers_in_progress = [ ls for ls in auditLogStatusInfos if ls['transferStatus'] == 'IN_PROGRESS' and ls['deviceComponentType'] == 'PLAYER' ]
        if transfers_in_progress:
            raise Exception('Device is busy. Cannot collect at this moment')
        utc_start_datetime = local_datetime_to_utc(start_datetime)
        utc_end_datetime = utc_start_datetime + datetime.timedelta(days=1)
        log_directory = str(uuid.uuid4())
        log_dump_url = 'ftp://%s:%d/%s' % (cfg.lms_ftp_ip(), cfg.lms_ftp_port(), posixpath.join('tmp', log_directory))
        local_log_directory = os.path.join(cfg.lms_library_directory(), 'tmp', log_directory)
        os.mkdir(local_log_directory)
        response = self.execute(self.SYSTEM, 'getAuditLogs', params={'url': log_dump_url,
         'startDate': utc_start_datetime.strftime('%Y-%m-%dT%H:%M:%S+00:00'),
         'endDate': utc_end_datetime.strftime('%Y-%m-%dT%H:%M:%S+00:00'),
         'username': cfg.lms_ftp_username(),
         'password': cfg.lms_ftp_password()}, timeout=200)
        if check_response(response):
            tries = 0
            continue_wait = False
            success = False
            while tries < 10 or continue_wait:
                continue_wait = False
                log_retrieval_response = self.execute(self.SYSTEM, 'getAuditLogsStatus', params={'logRetrievalId': response['logRetrievalId']})
                if check_response(log_retrieval_response) and log_retrieval_response.get('auditLogStatusInfo'):
                    if log_retrieval_response['auditLogStatusInfo']['transferStatus'] in ('FINISHED',):
                        success = True
                        break
                    elif log_retrieval_response['auditLogStatusInfo']['transferStatus'] in ('IN_PROGRESS',):
                        continue_wait = True
                    elif log_retrieval_response['auditLogStatusInfo']['transferStatus'] in ('ERROR', 'CANCELLED'):
                        output['error_messages'].append('Log retrieval ended with status %s' % log_retrieval_response['auditLogStatusInfo']['transferStatus'])
                        break
                tries += 1
                time.sleep(1)

            if success:
                log_xml = StringIO()
                log_files = os.listdir(local_log_directory)
                if log_files:
                    for log_file_name in log_files:
                        log_file = os.path.join(local_log_directory, log_file_name)
                        if os.path.isfile(log_file):
                            with open(log_file, 'r') as f:
                                log_xml.write(f.read())

                    log_xml.seek(0)
                    output['xml'] = log_xml.read()
        else:
            output['error_messages'].append(response['error_message'])
        shutil.rmtree(local_log_directory, ignore_errors=True)
        return output# decompiled 0 files: 0 okay, 1 failed, 0 verify failed
# 2017.08.13 21:49:29 CST
