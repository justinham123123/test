# 2017.08.13 21:49:33 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\dolby\dolby_v4_8.py
"""
Dolby SMS 4.8 Adaptor
"""
from xml.sax.saxutils import unescape
from serv.core.devices.sms.dolby.dolby_utils import check_response
from serv.core.devices.sms.dolby.dolby_v4_5 import Dolby_v4_5
from serv.lib.utilities.utils import wrap_urn, strip_urn

class Dolby_v4_8(Dolby_v4_5):
    """
    Dolby screen server access and control
    """

    def __init__(self, id, device_info, snmp_manager):
        super(Dolby_v4_8, self).__init__(id, device_info, snmp_manager)

    def get_playlist_information(self, playlist_uuids):
        self.log('get_playlist_information')
        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for playlist_uuid in playlist_uuids:
            retrieve_playlist_response = self.execute(self.SHOW, 'getSPL3', params={'showId': wrap_urn(playlist_uuid)}, version='1_2')
            if check_response(retrieve_playlist_response):
                playlist = self._parse_playlist(retrieve_playlist_response['show'].encode('utf-8'))
                output['playlist_info_dict'][playlist_uuid] = {}
                output['playlist_info_dict'][playlist_uuid]['title'] = unescape(playlist['title'] or playlist['text'])
                output['playlist_info_dict'][playlist_uuid]['duration_in_seconds'] = playlist['duration_in_seconds']
                output['playlist_info_dict'][playlist_uuid]['is_3d'] = playlist['is_3d']
                output['playlist_info_dict'][playlist_uuid]['is_hfr'] = playlist['is_hfr']
                output['playlist_info_dict'][playlist_uuid]['is_4k'] = playlist['is_4k']
                output['playlist_info_dict'][playlist_uuid]['is_pack'] = False
                output['playlist_info_dict'][playlist_uuid]['playlist'] = playlist
            else:
                output['error_messages'].append(retrieve_playlist_response['error_message'])

        return output

    def get_automation_list(self):
        self.log('get_automation_list')
        output = {'error_messages': []}
        automation_list_response = self.execute(self.SHOW, 'getCueInfos', list_tags=['cueInfo'])
        if check_response(automation_list_response):
            automation_list = []
            for cue in automation_list_response.get('cueInfo', []):
                automation_list.append(strip_urn(cue['cueId']))

            output['automation_uuid_list'] = automation_list
            output['automation_uuid_list'].append('intermission')
        else:
            output['error_messages'].append(automation_list_response['error_message'])
        return output

    def get_playback_status(self):
        output = super(Dolby_v4_8, self).get_playback_status()
        if output['element_index'] is not None:
            pass
        return output
# okay decompyling ./core/devices/sms/dolby/dolby_v4_8.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:33 CST
