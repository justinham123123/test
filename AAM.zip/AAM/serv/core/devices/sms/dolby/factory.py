# 2017.08.13 21:49:33 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\dolby\factory.py
"""
This file is meant to cover all the tricks and tweaks of autodetecting a Dolby type and instantiating a Device handler class.
"""
import re
from serv.core.devices.sms.dolby import dolby_v4_3, dolby_v4_5, dolby_v4_8

def assess_device(device_id, device, snmp_manager):
    software_information = device.get_device_version_information()
    if 'software_version' in software_information:
        version_match = re.match('0?(\\d)\\.0?(\\d)\\.', software_information['software_version'])
        if version_match and version_match.group(1) == '4' and version_match.group(2) == '2':
            return device
        if version_match and version_match.group(1) == '4' and version_match.group(2) >= '8':
            return dolby_v4_8.Dolby_v4_8(device_id, device.device_configuration, snmp_manager)
        if version_match and version_match.group(1) == '4' and version_match.group(2) > '4':
            return dolby_v4_5.Dolby_v4_5(device_id, device.device_configuration, snmp_manager)
        if version_match:
            return dolby_v4_3.Dolby_v4_3(device_id, device.device_configuration, snmp_manager)
        raise ValueError('Unknown Dolby device version %s' % software_information['software_version'])
    else:
        raise ValueError('Unknown Dolby device version')
# okay decompyling ./core/devices/sms/dolby/factory.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:33 CST
