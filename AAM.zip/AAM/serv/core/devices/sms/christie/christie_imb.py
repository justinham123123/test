# 2017.08.13 21:49:20 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\christie\christie_imb.py
"""
Christie IMB SMS Adaptor
"""
import datetime, logging, socket, struct, time, types, urllib2, urlparse, zipfile
from itertools import chain
from StringIO import StringIO
from threading import Lock
from uuid import uuid4
from xml.dom import minidom
import cherrypy
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.parsers.parsers import parse_kdm, parse_cpl, parse_content_title_text
from serv.lib.dcinema.parsers.certificate_parsers import parse_device_certificates
from serv.lib.network.socket_utils import encode_ber_length, decode_ber_length
from serv.lib.utilities.utils import strip_urn, wrap_urn, certificate_regex
from serv.lib.utilities.xml_utils import create_node, get_element_value, get_child_by_tag
from serv.core.devices.base.scheduling import Scheduling
from serv.core.devices.base.socket_pool import SocketPool
from christie_utils import Timeout, ChristieIMBError, UnknownError
from serv.lib.utilities import helper_methods
from serv.configuration.constants import HFR_FPS

class InvalidKLMHeader(IOError):
    pass


class InvalidIDError(ChristieIMBError):
    pass


class FormatError(ChristieIMBError):
    pass


class InvalidTimeError(ChristieIMBError):
    pass


class DuplicateIDError(ChristieIMBError):
    pass


class InvalidContentTypeError(ChristieIMBError):
    pass


class LoginFailed(ChristieIMBError):
    pass


class InvalidSecurityLevel(ChristieIMBError):
    pass


class APINotFound(ChristieIMBError):
    pass


class StatusNotFound(ChristieIMBError):
    pass


class InvalidCategoryError(ChristieIMBError):
    pass


class InvalidCertificateTypeError(ChristieIMBError):
    pass


class UnableToLocateIngestible(ChristieIMBError):
    pass


class ProblemWithIngestVolume(ChristieIMBError):
    pass


class PrimaryContentDriveUnavailable(ChristieIMBError):
    pass


class OperationNotPermitted(ChristieIMBError):
    pass


class KDMInUse(ChristieIMBError):
    pass


class ContentInUse(ChristieIMBError):
    pass


class KeyNotFound(ChristieIMBError):
    pass


class ScanningInProgress(ChristieIMBError):
    pass


class ConnectionError(ChristieIMBError):
    pass


class CPLNotFoundError(ChristieIMBError):
    pass


class MalformedPlaylist(ChristieIMBError):
    pass


class SavingPlaylistError(ChristieIMBError):
    pass


class NoPrimaryDriveError(ChristieIMBError):
    pass


class PlaylistLoadedError(ChristieIMBError):
    pass


class MalformedXMLError(ChristieIMBError):
    pass


class UnableToStartScheduler(ChristieIMBError):
    pass


class AlreadyPlayingError(ChristieIMBError):
    pass


class PerformanceTestInProgressError(ChristieIMBError):
    pass


class SMConnectionError(ChristieIMBError):
    pass


class InvalidOffsetError(ChristieIMBError):
    pass


class PlaybackError(ChristieIMBError):
    pass


class ContentNotLoadedError(ChristieIMBError):
    pass


class NotMarriedError(ChristieIMBError):
    pass


class ValidationInProgress(ChristieIMBError):
    pass


class NoValidationRunning(ChristieIMBError):
    pass


class ConfigFileError(ChristieIMBError):
    pass


class InvalidLogTypeError(ChristieIMBError):
    pass


class IngestIDNotCancelled(ChristieIMBError):
    pass


GLOBAL_ERRORS = {124: InvalidSecurityLevel,
 125: APINotFound}
INT, STRING, BOOL = range(3)
MAX_SOCKETS = 3
LOG_TYPE_SMS = 1
LOG_TYPE_SM = 2
LOG_TYPE_SM_REPORT = 3
PLAYBACK_STATE = {0: 'stop',
 1: 'play',
 2: 'pause',
 'stop': 0,
 'play': 1,
 'pause': 2}
LOAD_STATE = {0: 'OK',
 1: 'Playlist Not Found',
 2: 'Key not found',
 3: 'SM Returned Play OK Error',
 4: 'Issue with CPL',
 5: 'CPL Validation issue',
 6: 'KDM Validation issue',
 7: 'Issue with Content',
 8: 'SM Fatal Issue',
 9: 'SM Issue',
 10: 'General Validation Issue',
 11: 'Issue with Prepsuite',
 12: 'Missing Assets',
 13: 'SM Connection Failure',
 14: 'KDM Missing',
 15: 'AssetHASH Failure',
 16: 'Content Prep Failure',
 17: 'High Frame Rate License Required',
 18: 'Not Married',
 19: 'TDL Error',
 20: 'KDM Expired',
 21: 'KDM Not Yet Valid',
 22: 'KDM Extends Beyond 6 Hours',
 23: 'Not Loaded',
 100: 'Not Loaded'}
INGEST_STATE = {0: 'active',
 1: 'success',
 2: 'cancelled',
 3: 'queued_on_device',
 4: 'failed',
 5: 'failed'}
INGEST_TYPE = {'CPL': 'CPL',
 'PKL': 'CPL',
 'Remote': 'CPL',
 'KEY': 'KDM'}
OFFSET_KIND = {'OnClipStart': 'start',
 'OnClipEnd': 'end'}

def create_klv_message(oid, elements = {}, method = 'GET'):
    """
    Creates a Christie KLV message with the specified object id
    and dictionary of elements
    """
    if method == 'SET':
        cmd_code = '\x01'
    else:
        cmd_code = '\x02'
    header = '{\x024+\x01\x00' + cmd_code + struct.pack('B', oid) + '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    element_bytes = ''
    for key, value in elements.iteritems():
        key_bytes = struct.pack('<L', key)
        if type(value) in types.StringTypes:
            value_bytes = value.encode('UTF-16LE')
        elif type(value) in (types.IntType, types.LongType):
            value_bytes = struct.pack('<q', value)
        elif type(value) == types.BooleanType:
            value_bytes = struct.pack('<?', value)
        else:
            raise TypeError('Unsupported type: ', value)
        element_bytes += key_bytes + encode_ber_length(len(value_bytes)) + value_bytes

    return header + encode_ber_length(len(element_bytes)) + element_bytes


def decode_klv_elements(element_data, types_dict = {}):
    """
    Decodes Christie KLV elements into a dictionary
    
    Takes an optional type dictionary, which specifies
    a type for keys. These keys will be transformed into
    their closest Python equivalent
    """
    stream = StringIO(element_data)
    result_dict = {}
    pos = 0
    while pos < len(element_data):
        key = struct.unpack('<L', stream.read(4))[0]
        length, len_bytes = decode_ber_length(stream.read)
        result_dict[key] = stream.read(length)
        if key in types_dict:
            if types_dict[key] == STRING:
                result_dict[key] = result_dict[key].decode('UTF-16LE').encode('utf-8')
            elif types_dict[key] == INT:
                if length == 4:
                    result_dict[key] = struct.unpack('<L', result_dict[key])[0]
                elif length == 8:
                    result_dict[key] = struct.unpack('<Q', result_dict[key])[0]
                else:
                    raise ValueError('Unable to unpack integer from %d chars' % length)
            elif types_dict[key] == BOOL:
                result_dict[key] = struct.unpack('<?', result_dict[key])[0]
        pos += 4 + len_bytes + length

    return result_dict


def _send_recv(soc, message, sequence, timeout):
    soc.settimeout(timeout)
    soc.sendall(message)
    response_sequence = None
    start_time = time.time()
    while response_sequence != sequence:
        if time.time() - start_time > timeout:
            raise Timeout()
        header = ''
        header_length = 18
        while header_length > 0:
            recv_data = soc.recv(header_length)
            if not recv_data:
                raise IOError('Received only %d of expected 18 byte header' % len(header))
            header += recv_data
            header_length -= len(recv_data)

        error_code = struct.unpack('<H', header[8:10])[0]
        length = decode_ber_length(soc.recv)[0]
        data = ''
        while length:
            recv_data = soc.recv(length)
            data += recv_data
            length -= len(recv_data)

        if len(header) >= 14:
            response_sequence = int(header[14].encode('hex'), 16)
        else:
            raise InvalidKLMHeader('Unexpected length [%d]' % len(header))

    soc.settimeout(0)
    return (data, error_code)


def ensure_assets_tags_well_formed(xml_string):
    return _ensure_pair_of_tags_well_formed(xml_string, 'Assets')


def ensure_cpldetail_tags_well_formed(xml_string):
    return _ensure_pair_of_tags_well_formed(xml_string, 'CPLDetail')


def _ensure_pair_of_tags_well_formed(xml_string, tag_name):
    """This only works if we are expecting a single occurrence of this XML node.
    (i.e. one open and one close tag)
    
    There is probably a nicer way, but this works for now..."""
    open_tag = '<%s>' % tag_name
    close_tag = '</%s>' % tag_name
    if xml_string.count(open_tag) == 2:
        index = xml_string.rfind(open_tag)
        return ''.join([xml_string[:index], xml_string[index:].replace(open_tag, close_tag)])
    return xml_string


class ChristieIMB(SocketPool, Scheduling):

    def __init__(self, *args, **kwargs):
        super(ChristieIMB, self).__init__(*args, **kwargs)
        self.supported_modes = {'schedule_modes': ['schedule_on', 'schedule_off'],
         'loop_modes': ['do_not_loop', 'loop']}
        self.SEQUENCE_LOCK = Lock()
        self.SEQUENCE = 1
        self.missing_transfer_data = {}
        self.intermissions_supported = None
        return

    def _get_sequence(self):
        with self.SEQUENCE_LOCK:
            self.SEQUENCE += 1
            if self.SEQUENCE == 256:
                self.SEQUENCE = 1
            ret = self.SEQUENCE
        return ret

    def socket_address(self):
        return (self.device_configuration['ip'], self.device_configuration['port'])

    def prep_socket(self, soc):
        login_message = create_klv_message(1, {1: self.device_configuration['api_username'],
         2: self.device_configuration['api_password']}, method='SET')
        data, error_code = _send_recv(soc, login_message, 0, timeout=30)
        if error_code:
            if error_code == 1:
                raise LoginFailed()
            else:
                raise UnknownError(error_code)

    def _execute_command(self, message, return_types = {}, error_types = {}, timeout = 30):
        """
        Send a message to a Christie IMB and parse out the response
        """
        sequence = self._get_sequence()
        message = message[:14] + struct.pack('B', sequence) + message[15:]
        with self.get_socket(timeout) as soc:
            data, error_code = _send_recv(soc, message, sequence, timeout)
        if error_code:
            error_types.update(GLOBAL_ERRORS)
            try:
                error_type = error_types[error_code]
            except KeyError:
                logging.info('UNKNOWN ERROR FOR CHRISTIE:' + str(data) + ' code: ' + str(error_code) + ' message:' + str(message))
                raise UnknownError(error_code)
            else:
                raise error_type()

        return decode_klv_elements(data, return_types)

    def _get_certificates(self):
        """
        Get the IMB certificates
        """
        oid = 131
        elements = {1: 0}
        return_types = {5: STRING}
        error_types = {1: InvalidCertificateTypeError}
        klv_message = create_klv_message(oid, elements)
        response = self._execute_command(klv_message, return_types, error_types)
        certificate_text = response[5]
        match = certificate_regex.search(certificate_text)
        certificates = []
        while match:
            certificates.append(match.group(0))
            match = certificate_regex.search(certificate_text, match.end())

        return certificates

    def _list_licenses(self):
        """
        Gets the list of licenses from the IMB in XML form
        """
        oid = 132
        return_types = {5: STRING}
        return self._execute_command(create_klv_message(oid), return_types)

    def __get_status_all(self):
        elements = {10000: 'ALL'}
        error_types = {1: InvalidIDError,
         2: InvalidCategoryError}
        response = self._execute_command(create_klv_message(21, elements), error_types=error_types)
        output = {}
        for status_id in response.keys():
            status_xml = response[status_id]
            dom = minidom.parseString(status_xml)
            value = get_element_value(dom, 'value')
            _type = get_element_value(dom, 'type')
            if _type in ('LONG', 'INT'):
                output[status_id] = int(value)
            elif _type == 'BOOL':
                output[status_id] = {'true': True,
                 'false': False}.get(value, None)
            else:
                output[status_id] = value

        return output

    def _get_status(self, status_id):
        """
        Gets a status value
        """
        elements = {status_id: 1}
        return_types = {status_id: STRING}
        error_types = {1: InvalidIDError,
         2: InvalidCategoryError}
        response = self._execute_command(create_klv_message(21, elements), return_types, error_types)
        try:
            status_xml = response[status_id]
        except KeyError:
            raise StatusNotFound()

        dom = minidom.parseString(status_xml)
        value = get_element_value(dom, 'value')
        _type = get_element_value(dom, 'type')
        if _type in ('LONG', 'INT'):
            return int(value)
        elif _type == 'BOOL':
            return {'true': True,
             'false': False}.get(value, None)
        else:
            return value
            return None

    def _get_status_list(self, status_ids):
        """
        Gets a dict of statuses from the IMB
        """
        oid = 21
        elements = {}
        return_types = {}
        for status_id in status_ids:
            elements[status_id] = 1
            return_types[status_id] = STRING

        error_types = {1: InvalidIDError,
         2: InvalidCategoryError}
        klv_message = create_klv_message(oid, elements)
        response = self._execute_command(klv_message, return_types, error_types)
        output = {}
        for status_id in status_ids:
            try:
                status_xml = response[status_id]
            except KeyError:
                raise StatusNotFound()

            dom = minidom.parseString(status_xml)
            value = get_element_value(dom, 'value')
            _type = get_element_value(dom, 'type')
            if _type in ('LONG', 'INT'):
                output[status_id] = int(value)
            elif _type == 'BOOL':
                output[status_id] = {'true': True,
                 'false': False}.get(value, None)
            else:
                output[status_id] = value

        return output

    def get_time(self):
        """
        Gets the epoch time localised to the current locale
        """
        response = self._execute_command(create_klv_message(109), {5: STRING})
        return response[5]

    def _list_content(self, content_type):
        """
        Returns the content of type 'content_type'
        """
        CONTENT_TYPE = {'CPL': 1,
         'KDM': 2,
         'Playlist': 3,
         'ALT': 4,
         'ALL': 5}
        oid = 41
        elements = {1: CONTENT_TYPE[content_type]}
        return_types = {5: STRING}
        error_types = {1: InvalidContentTypeError}
        response = self._execute_command(create_klv_message(oid, elements), return_types, error_types)
        return minidom.parseString(response[5])

    def _list_cpls(self):
        dom = self._list_content('CPL')
        cpls = {}
        for cpl_el in dom.getElementsByTagName('CPL'):
            cpl_uuid = strip_urn(get_element_value(cpl_el, 'Id'))
            cpls[cpl_uuid] = {}
            cpls[cpl_uuid]['name'] = get_element_value(cpl_el, 'Name')
            cpls[cpl_uuid]['is_3d'] = get_element_value(cpl_el, 'is3D')
            cpls[cpl_uuid]['is_complete'] = get_element_value(cpl_el, 'isComplete')
            cpls[cpl_uuid]['is_encrypted'] = get_element_value(cpl_el, 'isEncrypted')
            cpls[cpl_uuid]['is_key_available'] = get_element_value(cpl_el, 'isKeyAvailable')
            cpls[cpl_uuid]['duration_in_seconds'] = get_element_value(cpl_el, 'duration_in_seconds')
            cpls[cpl_uuid]['duration_in_frames'] = get_element_value(cpl_el, 'duration_in_frames')
            cpls[cpl_uuid]['rating'] = get_element_value(cpl_el, 'rating')
            cpls[cpl_uuid]['sound_language'] = get_element_value(cpl_el, 'SoundLanguage')
            cpls[cpl_uuid]['subtitle_language'] = get_element_value(cpl_el, 'SubtitleLanguage')
            cpls[cpl_uuid]['cc_language'] = get_element_value(cpl_el, 'CCLanguage')
            cpls[cpl_uuid]['content_kind'] = get_element_value(cpl_el, 'ContentType')
            cpls[cpl_uuid]['creation_date'] = get_element_value(cpl_el, 'ContentCreationDate')
            cpls[cpl_uuid]['kdm_valid_from'] = get_element_value(cpl_el, 'KDMValidFrom')
            cpls[cpl_uuid]['kdm_valid_to'] = get_element_value(cpl_el, 'KDMValidTo')
            cpls[cpl_uuid]['cpl_type'] = get_element_value(cpl_el, 'CPLType')
            cpls[cpl_uuid]['valid_from'] = get_element_value(cpl_el, 'ValidFrom')
            cpls[cpl_uuid]['valid_to'] = get_element_value(cpl_el, 'ValidTo')
            cpls[cpl_uuid]['is_key_almost_expired'] = get_element_value(cpl_el, 'isKeyAlmostExpired')

        return cpls

    def _list_kdms(self):
        dom = self._list_content('KDM')
        kdms = {}
        for kdm_el in dom.getElementsByTagName('KDM'):
            kdm_uuid = strip_urn(get_element_value(kdm_el, 'Id'))
            kdms[kdm_uuid] = {}
            kdms[kdm_uuid]['name'] = get_element_value(kdm_el, 'Name')
            kdms[kdm_uuid]['cpl_uuid'] = get_element_value(kdm_el, 'CPLID')
            kdms[kdm_uuid]['valid_from'] = get_element_value(kdm_el, 'ValidFrom')
            kdms[kdm_uuid]['valid_to'] = get_element_value(kdm_el, 'ValidTo')

        return kdms

    def _list_playlists(self):
        oid = 148
        return_types = {5: STRING}
        klv_message = create_klv_message(oid)
        return_types = {5: STRING}
        response = self._execute_command(klv_message, return_types)
        dom = minidom.parseString(response[5])
        playlists = {}
        for playlist_el in dom.getElementsByTagName('CDSPlaylist'):
            playlist_uuid = get_element_value(playlist_el, 'Id').replace('playlist_', '')
            playlists[playlist_uuid] = {}
            playlists[playlist_uuid]['annotation_text'] = get_element_value(playlist_el, 'AnnotationText')
            playlists[playlist_uuid]['creator'] = get_element_value(playlist_el, 'Creator')
            playlists[playlist_uuid]['creation_date'] = get_element_value(playlist_el, 'CreationDate')
            playlists[playlist_uuid]['total_running_length'] = get_element_value(playlist_el, 'TotalRunLength')

        return playlists

    def _delete_content(self, content_id):
        oid = 42
        elements = {1: content_id}
        error_types = {1: InvalidIDError,
         2: ContentInUse,
         3: KDMInUse}
        return self._execute_command(create_klv_message(oid, elements, method='SET'), error_types=error_types)

    def _get_playlist(self, playlist_id):
        oid = 43
        elements = {1: 'playlist_' + playlist_id}
        return_types = {5: STRING}
        error_types = {1: InvalidIDError}
        klv_message = create_klv_message(oid, elements)
        response = self._execute_command(klv_message, return_types, error_types)
        return response[5]

    def _parse_playlist(self, playlist_xml):
        """
        Gets the playlist XML and returns a playlist dictionary
        """
        dom = minidom.parseString(playlist_xml)
        playlist_el = get_child_by_tag(dom, 'CDSPlaylist')
        playlist_id = str(get_child_by_tag(playlist_el, 'Id').firstChild.data)
        playlist_id = playlist_id.replace('playlist_', '')
        playlist_title = get_child_by_tag(playlist_el, 'AnnotationText').firstChild.data if get_child_by_tag(playlist_el, 'AnnotationText').firstChild != None else playlist_id
        playlist_duration = 0
        playlist_is_3d = False
        playlist_is_hfr = False
        events = []
        for entry_el in playlist_el.getElementsByTagName('Entry'):
            event = {}
            event['id'] = get_element_value(entry_el, 'Id')
            event['main_id'] = None
            event['cpl_id'] = strip_urn(get_element_value(entry_el, 'CompositionId'))
            event['text'] = get_element_value(entry_el, 'AnnotationText')
            event['type'] = 'composition'
            try:
                cpl = cherrypy.core.contents[event['cpl_id']]
            except KeyError:
                edit_rate = [None, None]
                duration_in_seconds = None
                duration_in_frames = None
            else:
                if cpl['edit_rate'][0] is not None and cpl['edit_rate'][1] is not None:
                    edit_rate = (cpl['edit_rate'][0], cpl['edit_rate'][1])
                    playlist_is_hfr |= cpl['edit_rate'][0] > HFR_FPS
                else:
                    edit_rate = [None, None]
                duration_in_seconds = cpl['duration_in_seconds']
                duration_in_frames = cpl['duration_in_frames']
                if duration_in_seconds:
                    playlist_duration += int(duration_in_seconds)
                playlist_is_3d |= cpl['playback_mode'] == '3D'

            event['duration_in_seconds'] = duration_in_seconds
            event['duration_in_frames'] = duration_in_frames
            event['edit_rate'] = edit_rate
            event['automation'] = []
            for automation_el in entry_el.getElementsByTagName('AutomationCue'):
                action = get_element_value(automation_el, 'Action')
                trigger = get_element_value(automation_el, 'Trigger')
                if action == 'Intermission':
                    automation = {'id': action,
                     'name': 'Christie Intermission',
                     'type': 'intermission',
                     'type_specific': {'offset_in_seconds': int(get_element_value(automation_el, 'ActionTimeCode')) / 1000,
                                       'restart_in_seconds': get_element_value(automation_el, 'ClipRewindOffset'),
                                       'spl_title': get_element_value(automation_el, 'PlaylistName'),
                                       'start_automation': get_element_value(automation_el, 'StartMacroName'),
                                       'end_automation': get_element_value(automation_el, 'EndMacroName')}}
                elif trigger == 'OnClipCue':
                    automation = {'id': action,
                     'name': action,
                     'type': 'wait_for_input',
                     'type_specific': {'offset_from': 'start',
                                       'offset_in_seconds': 0,
                                       'offset_in_frames': 0,
                                       'action': action}}
                else:
                    offset_kind = OFFSET_KIND[trigger]
                    offset_in_seconds = float(get_element_value(automation_el, 'ActionTimeCode')) / 1000
                    if event['edit_rate'] is not None and len(event['edit_rate']) == 2 and event['edit_rate'][0] is not None and event['edit_rate'][1] is not None:
                        offset_in_frames = offset_in_seconds * (1.0 * event['edit_rate'][0] / event['edit_rate'][1])
                    else:
                        offset_in_frames = None
                    automation = {'id': action,
                     'name': action,
                     'type': 'cue',
                     'type_specific': {'offset_from': offset_kind,
                                       'offset_in_seconds': offset_in_seconds,
                                       'offset_in_frames': offset_in_frames,
                                       'action': action}}
                event['automation'].append(automation)

            events.append(event)

        return {'id': playlist_id,
         'title': playlist_title,
         'text': playlist_title,
         'is_3d': playlist_is_3d,
         'is_hfr': playlist_is_hfr,
         'duration_in_seconds': playlist_duration,
         'events': events,
         'automation': []}

    def _update_content_in_playlist(self, content_uuid, playlist_uuid):
        playlist = self.playlist_information[playlist_uuid]
        cpl = cherrypy.core.contents[content_uuid]
        playlist_is_3d = False
        playlist_is_hfr = False
        playlist_duration = 0
        for event in playlist['playlist']['events']:
            if event['type'] == 'composition' and event['cpl_id'] == content_uuid:
                if cpl['duration_in_seconds'] is not None:
                    event['duration_in_seconds'] = cpl['duration_in_seconds']
                if cpl['duration_in_frames'] is not None:
                    event['duration_in_frames'] = cpl['duration_in_frames']
                if cpl['edit_rate'][0] is not None and cpl['edit_rate'][1] is not None:
                    event['edit_rate'] = (cpl['edit_rate'][0], cpl['edit_rate'][1])
                    for automation_dict in event['automation']:
                        automation_dict['type_specific']['offset_in_frames'] = int(automation_dict['type_specific']['offset_in_seconds'] * (1.0 * event['edit_rate'][0] / event['edit_rate'][1]))

                    playlist_is_hfr |= cpl['edit_rate'][0] > HFR_FPS
                playlist_is_3d |= cpl['playback_mode'] == '3D'
            playlist_duration += event['duration_in_seconds'] if event['duration_in_seconds'] else 0

        playlist['is_3d'] = playlist['playlist']['is_3d'] = playlist_is_3d
        playlist['is_hfr'] = playlist['playlist']['is_hfr'] = playlist_is_hfr
        playlist['duration_in_seconds'] = playlist['playlist']['duration_in_seconds'] = playlist_duration
        return

    def _construct_playlist(self, spl_dict):
        """
        Creates an SPL XML suitable for ingestion to Christie IMB
        
        <CDSPlaylist>
            <Id>playlist_ed497bf7-38f3-4140-a33f-ad06236bb1f6</Id>
            <AnnotationText>This is an Example Show Play List</AnnotationText>
            <Creator>Mike Loder</Creator>
            <CreationDate>2011-02-24T19:17:48+00:00</CreationDate>
            <TotalRunLength>1212121</TotalRunLength>
            <EntryList>
                <Entry>
                    <Id>a6a84dbe-4a41-4d4a-9941-ce160519d6a8</Id>
                    <AnnotationText>G-Force Trailer</AnnotationText>
                    <Tag>FEATURE_START</Tag>
                    <CompositionId>urn:uuid:aae10501-9a0c-41d4-abdc-fdc57c933e87</CompositionId>
                    <Duration>12121</Duration>
                    <AutomationCueList>
                        <AutomationCue>
                            <Trigger>OnClipStart</Trigger>
                            <Action>CREDITS_CYCLE</Action>
                            <ActionTimeCode>0</ActionTimeCode>
                        </AutomationCue>
                    </AutomationCueList>
                </Entry>
            </EntryList>
        </CDSPlaylist>
        """
        root = minidom.Document()
        spl_element = create_node(root, root, 'CDSPlaylist')
        create_node(root, spl_element, 'Id', 'playlist_' + spl_dict['id'])
        create_node(root, spl_element, 'AnnotationText', spl_dict['title'])
        create_node(root, spl_element, 'Creator', 'AAM - TMS')
        create_node(root, spl_element, 'CreationDate', datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + '+00:00')
        create_node(root, spl_element, 'TotalRunLength', str(int(round(spl_dict['duration_in_seconds'] * 1000))))
        event_list_el = create_node(root, spl_element, 'EntryList')
        for event in spl_dict['events']:
            if event['type'] == 'composition':
                entry_list_element = create_node(root, event_list_el, 'Entry')
                create_node(root, entry_list_element, 'Id', event['id'])
                create_node(root, entry_list_element, 'AnnotationText', event['text'])
                create_node(root, entry_list_element, 'Duration', str(int(round(event['duration_in_seconds'] * 1000))) if event['duration_in_seconds'] else '0')
                create_node(root, entry_list_element, 'CompositionId', wrap_urn(event['cpl_id']))
                automation_list_el = create_node(root, entry_list_element, 'AutomationCueList')
                for automation in event['automation']:
                    if automation['type'] == 'cue':
                        automation_el = create_node(root, automation_list_el, 'AutomationCue')
                        if automation['type_specific']['offset_from'] == 'end':
                            trigger = 'OnClipEnd'
                        else:
                            trigger = 'OnClipStart'
                        create_node(root, automation_el, 'Trigger', trigger)
                        create_node(root, automation_el, 'Action', automation['type_specific']['action'])
                        create_node(root, automation_el, 'ActionTimeCode', str(int(round(automation['type_specific']['offset_in_seconds'] * 1000))))
                    elif automation['type'] == 'wait_for_input':
                        automation_el = create_node(root, automation_list_el, 'AutomationCue')
                        create_node(root, automation_el, 'Trigger', 'OnClipCue')
                        create_node(root, automation_el, 'Action', automation['type_specific']['action'])
                        create_node(root, automation_el, 'ActionTimeCode', 0)
                    elif automation['type'] == 'intermission':
                        automation_el = create_node(root, automation_list_el, 'AutomationCue')
                        create_node(root, automation_el, 'Trigger', 'OnClipStart')
                        create_node(root, automation_el, 'Action', 'Intermission')
                        create_node(root, automation_el, 'ActionTimeCode', str(int(round(automation['type_specific']['offset_in_seconds'] * 1000))))
                        create_node(root, automation_el, 'PlaylistName', automation['type_specific']['spl_title'])
                        create_node(root, automation_el, 'ClipRewindOffset', automation['type_specific']['restart_in_seconds'])
                        create_node(root, automation_el, 'StartMacroName', automation['type_specific']['start_automation'])
                        create_node(root, automation_el, 'EndMacroName', automation['type_specific']['end_automation'])

        return root.toxml()

    def _set_playlist(self, playlist_xml):
        oid = 44
        elements = {1: playlist_xml}
        error_types = {1: MalformedPlaylist,
         2: SavingPlaylistError,
         3: NoPrimaryDriveError,
         4: PlaylistLoadedError}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, error_types=error_types)

    def _get_all_playlists(self):
        oid = 148
        return_types = {5: STRING}
        return self._execute_command(create_klv_message(oid), return_types)

    def _get_cpl(self, cpl_id):
        oid = 58
        elements = {1: wrap_urn(cpl_id)}
        return_types = {5: STRING}
        error_types = {1: InvalidIDError}
        response = self._execute_command(create_klv_message(oid, elements), return_types, error_types)
        return response[5]

    def _get_cpl_details(self, cpl_uuid):
        oid = 60
        elements = {1: cpl_uuid}
        return_types = {5: STRING}
        error_types = {1: InvalidIDError}
        response = self._execute_command(create_klv_message(oid, elements), return_types, error_types)
        response[5] = ensure_cpldetail_tags_well_formed(ensure_assets_tags_well_formed(response[5]))
        return minidom.parseString(response[5])

    def _get_kdm(self, kdm_id):
        oid = 59
        elements = {1: kdm_id}
        return_types = {5: STRING}
        error_types = {1: InvalidIDError}
        response = self._execute_command(create_klv_message(oid, elements), return_types, error_types)
        return response[5]

    def _get_storage_information(self):
        oid = 47
        return_types = {5: STRING}
        klv_message = create_klv_message(oid)
        response = self._execute_command(klv_message, return_types)
        dom = minidom.parseString(response[5])
        output = {}
        for device_el in chain(dom.getElementsByTagName('nas'), dom.getElementsByTagName('das')):
            uuid = get_element_value(device_el, 'uuid')
            device_info = {'primary': get_element_value(device_el, 'primary') == 'true',
             'content_drive': get_element_value(device_el, 'content_drive') == 'true'}
            output[uuid] = device_info

        return output

    def _get_storage_status(self):
        oid = 51
        return_types = {5: STRING}
        klv_message = create_klv_message(oid)
        response = self._execute_command(klv_message, return_types)
        dom = minidom.parseString(response[5])
        output = {}
        for status_el in dom.getElementsByTagName('volume'):
            uuid = get_element_value(status_el, 'uuid')
            status = get_element_value(status_el, 'online') == 'true'
            output[uuid] = status

        return output

    def _search_share_dirs(self, ip, username, password, type):
        oid = 45
        elements = {1: ip,
         2: username,
         3: password,
         4: type}
        return_types = {10: STRING}
        klv_message = create_klv_message(oid, elements)
        res = self._execute_command(klv_message, return_types)
        return res

    def _get_disk_volume_list(self):
        oid = 49
        return_types = {5: STRING}
        klv_message = create_klv_message(oid)
        response = self._execute_command(klv_message, return_types)
        dom = minidom.parseString(response[5])
        output = {}
        for disk_el in dom.getElementsByTagName('volume'):
            uuid = get_element_value(disk_el, 'uuid')
            disk_info = {}
            disk_info['device'] = get_element_value(disk_el, 'device')
            disk_info['label'] = get_element_value(disk_el, 'label')
            disk_info['model'] = get_element_value(disk_el, 'model')
            disk_info['product'] = get_element_value(disk_el, 'product')
            disk_info['vendor'] = get_element_value(disk_el, 'vendor')
            disk_info['serial'] = get_element_value(disk_el, 'serial')
            disk_info['size'] = get_element_value(disk_el, 'size')
            output[uuid] = disk_info

        return output

    def _validate_playlist(self, playlist_id):
        oid = 145
        elements = {1: playlist_id}
        return_types = {1: STRING}
        error_types = {1: ValidationInProgress,
         2: InvalidIDError}
        klv_message = create_klv_message(oid, elements, method='SET')
        return self._execute_command(klv_message, return_types, error_types=error_types)

    def _validate_playlist_result(self):
        oid = 151
        return_types = {5: STRING,
         6: STRING}
        error_types = {1: ValidationInProgress,
         2: NoValidationRunning}
        klv_message = create_klv_message(oid)
        return self._execute_command(klv_message, return_types)

    def _ingest_kdm(self, kdm_xml):
        oid = 57
        elements = {1: kdm_xml}
        return_types = {5: STRING}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, return_types)

    def _get_ingest_status(self):
        oid = 54
        return_types = {5: STRING}
        klv_message = create_klv_message(oid)
        response = self._execute_command(klv_message, return_types)
        dom = minidom.parseString(response[5])
        ingests = {}
        for ingest_el in dom.getElementsByTagName('IngestStatusItem'):
            ingest_id = get_element_value(ingest_el, 'id')
            ingests[ingest_id] = {}
            ingests[ingest_id]['title'] = get_element_value(ingest_el, 'ingestTitle')
            sub_title = get_element_value(ingest_el, 'ingestSubTitle')
            ingests[ingest_id]['sub_title'] = sub_title if sub_title != 'null' else None
            ingests[ingest_id]['state'] = int(get_element_value(ingest_el, 'ingestState'))
            ingests[ingest_id]['type'] = get_element_value(ingest_el, 'ingestType')
            ingests[ingest_id]['total_bytes'] = int(get_element_value(ingest_el, 'totalbytes'))
            ingests[ingest_id]['ingested_bytes'] = int(get_element_value(ingest_el, 'ingestedbytes'))

        return ingests

    def _cancel_ingest(self, ingest_id):
        oid = 55
        elements = {1: ingest_id}
        error_types = {1: InvalidIDError,
         2: IngestIDNotCancelled}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, error_types=error_types)

    def _check_ingestible_listed(self, cpl_uuid):
        list_msg = create_klv_message(52)
        list_return_types = {0: BOOL,
         1: BOOL,
         5: STRING}
        list_error_types = {1: ScanningInProgress,
         2: ScanningInProgress}
        cpl_listed = False
        try:
            ingestibles = self._execute_command(list_msg, list_return_types, list_error_types)
        except ScanningInProgress:
            pass
        else:
            dom = minidom.parseString(ingestibles[5])
            for cpl_el in dom.getElementsByTagName('CPL'):
                uuid = strip_urn(get_element_value(cpl_el, 'Id'))
                if uuid == cpl_uuid:
                    cpl_listed = True

            if cpl_listed:
                return True
            scan_msg = create_klv_message(147)
            self._execute_command(scan_msg)

        start_time = time.time()
        while time.time() < start_time + 30:
            try:
                ingestibles = self._execute_command(list_msg, list_return_types, list_error_types)
            except ScanningInProgress:
                time.sleep(2)
                continue
            else:
                dom = minidom.parseString(ingestibles[5])
                for cpl_el in dom.getElementsByTagName('CPL'):
                    uuid = strip_urn(get_element_value(cpl_el, 'Id'))
                    if uuid == cpl_uuid:
                        cpl_listed = True

                break

        return cpl_listed

    def _load_content(self, content_id):
        oid = 61
        elements = {1: content_id}
        error_types = {1: InvalidIDError,
         2: AlreadyPlayingError,
         3: PerformanceTestInProgressError,
         4: SMConnectionError,
         18: SMConnectionError}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, error_types=error_types)

    def _play(self, offset):
        oid = 63
        elements = {1: offset}
        error_types = {1: InvalidOffsetError,
         2: PlaybackError,
         3: ContentNotLoadedError,
         4: AlreadyPlayingError,
         5: NotMarriedError}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, error_types=error_types)

    def _jog_playback(self, offset):
        oid = 66
        elements = {1: offset}
        klv_message = create_klv_message(oid, elements, method='SET')
        return self._execute_command(klv_message)

    def _pause_resume(self):
        oid = 64
        klv_message = create_klv_message(oid, method='SET')
        error_types = {1: ContentNotLoadedError}
        self._execute_command(klv_message, error_types=error_types)

    def _stop(self):
        oid = 65
        klv_message = create_klv_message(oid, method='SET')
        error_types = {1: ContentNotLoadedError}
        self._execute_command(klv_message, error_types=error_types)

    def _set_loop_mode(self, enabled):
        oid = 110
        elements = {1: enabled}
        klv_message = create_klv_message(oid, elements, method='SET')
        return self._execute_command(klv_message)

    def _unload(self):
        oid = 69
        klv_message = create_klv_message(oid, method='SET')
        self._execute_command(klv_message)

    def _execute_macro(self, macro_name):
        oid = 74
        elements = {1: macro_name}
        error_types = {1000: InvalidIDError}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, error_types=error_types)

    def _execute_input_cue(self, input_cue_name):
        oid = 76
        elements = {1: input_cue_name}
        klv_message = create_klv_message(oid, elements, method='SET')
        return self._execute_command(klv_message)

    def _add_schedule_item(self, content_uuid, timestamp):
        oid = 141
        schedule_id = str(uuid4())
        schedule_item = '<?xml version="1.0" encoding="utf-8"?><ScheduleItem><ID>{id}</ID><ContentID>{content_id}</ContentID><DateTime>{timestamp}</DateTime></ScheduleItem>'.format(id=schedule_id, content_id='playlist_' + content_uuid, timestamp=int(round(timestamp * 1000)))
        elements = {1: schedule_item}
        return_types = {1: STRING}
        error_types = {1: MalformedXMLError,
         2: InvalidTimeError,
         3: DuplicateIDError}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, return_types, error_types)
        return schedule_id

    def _delete_schedule_item(self, schedule_id):
        oid = 142
        elements = {1: schedule_id}
        error_types = {1: InvalidIDError}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, error_types=error_types)

    def _get_schedule(self):
        oid = 140
        return_types = {5: STRING}
        klv_message = create_klv_message(oid)
        response = self._execute_command(klv_message, return_types)
        dom = minidom.parseString(response[5])
        schedule_items = {}
        for schedule_el in dom.getElementsByTagName('ScheduleItem'):
            schedule_id = get_element_value(schedule_el, 'ID')
            schedule_items[schedule_id] = {'device_schedule_id': schedule_id,
             'device_playlist_uuid': get_element_value(schedule_el, 'ContentID').replace('playlist_', ''),
             'start_time': float(get_element_value(schedule_el, 'DateTime')) / 1000}

        return schedule_items

    def _get_schedule_by_id(self, schedule_id):
        oid = 149
        elements = {1: schedule_id}
        return_types = {1: STRING,
         5: STRING}
        error_types = {1: InvalidIDError}
        klv_message = create_klv_message(oid, elements)
        response = self._execute_command(klv_message, return_types, error_types)
        dom = minidom.parseString(response[5])
        schedule_el = dom.getElementsByTagName('ScheduleItem')[0]
        return {'schedule_id': get_element_value(schedule_el, 'ID'),
         'playlist_uuid': get_element_value(schedule_el, 'ContentID').replace('playlist_', ''),
         'start_time': float(get_element_value(schedule_el, 'DateTime')) / 1000}

    def _get_schedule_by_date_range(self, start_date, end_date):
        oid = 150
        elements = {1: str(start_date),
         2: str(end_date)}
        return_types = {1: STRING,
         2: STRING,
         5: STRING}
        error_types = {1: FormatError}
        klv_message = create_klv_message(oid, elements)
        return self._execute_command(klv_message, return_types)

    def _enable_schedule(self, enable):
        """
        Enable the schedule system on the Christie IMB
        """
        oid = 143
        elements = {1: bool(enable)}
        klv_message = create_klv_message(oid, elements, method='SET')
        self._execute_command(klv_message, error_types={1: UnableToStartScheduler})

    def _update_schedule_item(self, schedule_xml):
        oid = 146
        elements = {1: schedule_xml}
        return_types = {5: STRING}
        klv_message = create_klv_message(oid, elements, method='SET')
        return self._execute_command(klv_message, return_types)

    def _check_item_in_schedule(self, item_id):
        oid = 135
        elements = {1: item_id}
        return_types = {1: STRING,
         5: BOOL}
        klv_message = create_klv_message(oid, elements)
        return self._execute_command(klv_message, return_types)

    def _get_automation_config(self):
        oid = 71
        return_types = {5: STRING}
        error_types = {1000: ConfigFileError}
        klv_message = create_klv_message(oid)
        response = self._execute_command(klv_message, return_types, error_types)
        dom = minidom.parseString(response[5])
        inputcues = []
        for alias_el in dom.getElementsByTagName('alias'):
            inputcues.append(alias_el.attributes['aliasname'].value)

        macros = []
        for macro_el in dom.getElementsByTagName('macro'):
            macros.append(macro_el.attributes['name'].value)

        return {'inputcues': inputcues,
         'macros': macros}

    def supports_intermission(self):
        if self.intermissions_supported == None:
            try:
                self._execute_command(create_klv_message(181))
                self.intermissions_supported = True
            except Exception:
                self.intermissions_supported = False

        return self.intermissions_supported

    def add_log_entry(self, log):
        oid = 101
        elements = {1: log}
        return_types = {1: STRING}
        klv_message = create_klv_message(oid, elements, method='SET')
        return self._execute_command(klv_message, return_types)

    def get_device_status(self):
        output = {'error_messages': [],
         'current_time': None}
        time_val = self._get_status(5)
        if time_val is None:
            output['error_messages'].append(_('Screen server is reporting an invalid time'))
        else:
            output['current_time'] = float(time_val) / 1000
        return output

    def test_management_connection(self):
        try:
            self._get_status(5)
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error %s') % str(ex))

        return (True, _('OK'))

    def get_device_version_information(self):
        output = {'error_messages': [],
         'software_version': None}
        output['software_version'] = self._get_status(201)
        return output

    def get_device_information(self):
        output = {'error_messages': [],
         'product_certificates': {},
         'dnqualifiers': [],
         'model_id': None,
         'model_name': None,
         'serial': None,
         'software_version': None,
         'raid_status': [],
         'storage_total': None,
         'storage_used': None,
         'storage_available': None}
        try:
            certificates = self._get_certificates()
        except (ChristieIMBError, KeyError) as ex:
            output['error_messages'].append(_('Error retrieving the product certificate: %s') % str(ex))
        else:
            output.update(parse_device_certificates(certificates))

        try:
            output['model_id'] = self._get_status(2)
        except ChristieIMBError as ex:
            output['error_messages'].append(_('Error retrieving the model ID: %s') % str(ex))

        try:
            output['model'] = self._get_status(1)
        except ChristieIMBError as ex:
            output['error_messages'].append(_('Error retrieving the model name: %s') % str(ex))

        try:
            output['serial'] = self._get_status(3)
        except ChristieIMBError as ex:
            output['error_messages'].append(_('Error retrieving the serial number: %s') % str(ex))

        try:
            output['software_version'] = self._get_status(201)
        except ChristieIMBError as ex:
            output['error_messages'].append(_('Error retrieving the software version: %s') % str(ex))

        try:
            raid_status = self._get_status(600)
        except ChristieIMBError as ex:
            output['error_messages'].append(_('Error retrieving the RAID status: %s') % str(ex))
        else:
            output['raid_status'].append({'name': 'RAID',
             'active': raid_status == 'yes',
             'degraded': False,
             'message': _('OK') if raid_status == 'yes' else _('Inactive'),
             'status': 'ok' if raid_status == 'yes' else 'error'})

        try:
            disk_status = self._get_status_list([400, 401])
        except ChristieIMBError as ex:
            output['error_messages'].append(_('Error retrieving disk usage information: %s') % str(ex))
        else:
            total = float(disk_status[400])
            free = float(disk_status[401])
            output['storage_total'] = total
            output['storage_used'] = total - free
            output['storage_available'] = free

        return output

    def reboot(self):
        reboot_cmd = create_klv_message(3)
        self._execute_command(reboot_cmd)
        return {'error_messages': []}

    def get_key_uuid_list(self):
        """
        This recieves the uuids of all the kdms in the system
        
        @param      None
        @return     [key_uuid]      - list of key uuids
        """
        output = {'error_messages': []}
        output['key_uuid_list'] = self._list_kdms().keys()
        return output

    def get_key_information(self, key_uuids):
        """
        This key information for key uuids provided
        
        @param      key_uuids          LIST of key ids
        @return     key dictionary
        """
        output = {'error_messages': [],
         'key_info_dict': {}}
        for kdm_uuid in key_uuids:
            try:
                kdm_xml = self._get_kdm(kdm_uuid)
                kdm_dict = parse_kdm(kdm_xml, load_from_file=False)
                output['key_info_dict'][kdm_uuid] = {}
                output['key_info_dict'][kdm_uuid]['cpl_title'] = kdm_dict['cpl_text']
                output['key_info_dict'][kdm_uuid]['cpl_uuid'] = kdm_dict['cpl_id']
                output['key_info_dict'][kdm_uuid]['not_valid_before'] = kdm_dict['start_date']
                output['key_info_dict'][kdm_uuid]['not_valid_after'] = kdm_dict['end_date']
                output['key_info_dict'][kdm_uuid]['dnqualifier'] = kdm_dict['dn_qualifier']
                output['key_info_dict'][kdm_uuid]['status'] = 'ok'
            except Exception as ex:
                output['error_messages'].append(_('Error getting KDM information for ID %s: %s') % (kdm_uuid, str(ex)))

        return output

    def get_key(self, key_uuid):
        """
        This key xml
        
        @param      key_uuid 
        @return     key dictionary
        """
        output = {'error_messages': [],
         'xml': {}}
        kdm_xml = self._get_kdm(key_uuid)
        output['xml'] = kdm_xml
        return output

    def get_transfer_ids(self):
        output = {'error_messages': [],
         'transfers': []}
        ingests = self._get_ingest_status()
        output['transfers'] = ingests.keys()
        return output

    def get_transfer_info(self, transfer_ids):
        output = {'error_messages': [],
         'transfers': []}
        ingests = self._get_ingest_status()
        for ingest_id, ingest_dict in ingests.iteritems():
            transfer_info = ingest_id in transfer_ids and {'server_transfer_id': ingest_id,
             'state': None,
             'description': None,
             'content_id': None,
             'type': None,
             'source': None,
             'progress': None,
             'message': None}
            transfer_info['state'] = INGEST_STATE[ingest_dict['state']]
            transfer_info['description'] = ingest_dict['title']
            if not ingest_dict['sub_title']:
                transfer_info['message'] = ingest_dict['title']
                try:
                    transfer_info['type'] = INGEST_TYPE[ingest_dict['type']]
                except KeyError:
                    transfer_info['type'] = 'UNKNOWN'
                    logging.warning('Unknown ingest type on ChristieIMB %s' % ingest_dict['type'])

                if int(ingest_dict['total_bytes']) == 0 and transfer_info['type'] == 'CPL':
                    ctt = ingest_dict['title']
                    if ctt in self.missing_transfer_data:
                        transfer_info['total_bytes'] = self.missing_transfer_data[ctt]['total_bytes']
                        transfer_info['content_id'] = self.missing_transfer_data[ctt]['cpl_uuid']
                    else:
                        approx_bytes = 0
                        found_count = 0
                        for content_uuid, content in cherrypy.core.contents.iteritems():
                            if content['content_title_text'] == ctt:
                                cpl_uuid = content_uuid
                                for device_uuid, status in content['devices'].iteritems():
                                    if status.get('cpl_size', None):
                                        found_count += 1
                                        approx_bytes += int(status['cpl_size'])

                        if found_count > 0:
                            approx_bytes = approx_bytes / found_count
                            transfer_info['total_bytes'] = approx_bytes
                            transfer_info['content_id'] = cpl_uuid
                            self.missing_transfer_data[ctt] = {'total_bytes': approx_bytes,
                             'cpl_uuid': cpl_uuid}
                if int(ingest_dict['total_bytes']) != 0:
                    transfer_info['progress'] = int(round(100.0 * int(ingest_dict['ingested_bytes']) / int(ingest_dict['total_bytes'])))
                    if transfer_info['progress'] > 100:
                        transfer_info['progress'] = 100
                else:
                    transfer_info['progress'] = 0
                output['transfers'].append(transfer_info)

        return output

    def get_content_uuid_list(self):
        """
        This recieves the uuids of all the cpls in the system
        
        @param      None
        @return     [cpl_uuid]      - list of cpl uuids
        """
        output = {'error_messages': []}
        output['content_uuid_list'] = self._list_cpls().keys()
        return output

    def get_content_information(self, content_uuids):
        """
        gets content information of a device
        
        @param      content_uuids   - list of cpl uuids we want information for
        @return {
                    content_info_dict:        DICT
                        {
                            content_uuid: {
                                content_title_text  STRING
                                content_kind        INT
                                edit_rate           [INT, INT]
                                encrypted           BOOL
                                subtitled           BOOL
                                is_3d               BOOL
                                duration            INT in seconds
                                xml                 STRING xml file
                                parsed_info         DICT
                            }
                    error_messages          -LIST of errors
                }
        """
        output = {'error_messages': [],
         'content_info_dict': {}}
        for content_uuid in content_uuids:
            cpl_info = {'content_title_text': content_uuid,
             'content_kind': 'unknown',
             'edit_rate': None,
             'subtitled': None,
             'subtitle_language': None,
             'playback_mode': None,
             'aspect_ratio': None,
             'duration_in_seconds': 0,
             'duration_in_frames': 0,
             'encrypted': None,
             'xml': None,
             'parsed_info': parse_content_title_text(''),
             'video_encoding': 'UNKNOWN'}
            try:
                cpl_xml = self._get_cpl(content_uuid)
                temp_cpl = parse_cpl(cpl_xml, load_from_file=False)
                cpl_info['content_title_text'] = temp_cpl['text']
                cpl_info['content_kind'] = temp_cpl['type']
                cpl_info['edit_rate'] = temp_cpl['edit_rate']
                cpl_info['subtitled'] = temp_cpl['subtitled']
                cpl_info['subtitle_language'] = temp_cpl['subtitle_language']
                cpl_info['playback_mode'] = temp_cpl['playback_mode']
                cpl_info['aspect_ratio'] = temp_cpl['aspect_ratio']
                cpl_info['duration_in_seconds'] = temp_cpl['duration_in_seconds']
                cpl_info['duration_in_frames'] = temp_cpl['duration_in_frames']
                cpl_info['encrypted'] = temp_cpl['encrypted']
                cpl_info['xml'] = cpl_xml
                cpl_info['parsed_info'] = temp_cpl['parsed_info']
            except Exception as ex:
                logging.error('Error getting cpl information for cpl_id %s' % content_uuid, exc_info=True)
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))

            output['content_info_dict'][content_uuid] = cpl_info

        return output

    def get_content_validation_information(self, content_uuids):
        """
        This recieves information for given cpls in the system
        
        @param      content_uuids   - list of cpl uuids we want information for
        @return     {
                        cpl_uuid:
                            {
                                validation_code - Integer
                                                                0 No error nor warning
                                                                1 CPL is partially registered on this server
                                                                2 CPL is registered on this server but cannot be loaded
                                                                3 CPL is ingesting
                                                                4 CPL is queued for ingest
                                ingest_path         STRING relative path to cpl.xml from ftp logon
                                cpl_size            STRING size of cpl in bytes
                            }
                    }
        """
        output = {'error_messages': [],
         'content_validation_dict': {}}
        for cpl_uuid in content_uuids:
            try:
                cpl_details = self._get_cpl_details(cpl_uuid)
                validation_info = {}
                ftp_url = get_element_value(cpl_details, 'FTPURL')
                validation_info['ingest_path'] = ftp_url
                validation_info['validation_code'] = 0
                for asset in cpl_details.getElementsByTagName('Asset'):
                    if get_element_value(asset, 'Exists') != 'true':
                        validation_info['validation_code'] = 1
                        break
                    elif get_element_value(asset, 'HashStatus') == 'Differs from CPL':
                        validation_info['validation_code'] = 2

                validation_info['cpl_size'] = get_element_value(cpl_details, 'TotalSize')
                output['content_validation_dict'][cpl_uuid] = validation_info
            except Exception as ex:
                logging.error('Error getting CPL details for ID %s' % cpl_uuid, exc_info=True)
                output['error_messages'].append(str(ex))

        return output

    def get_ingest_path(self, content_uuid):
        cpl_details = self._get_cpl_details(content_uuid)
        ingest_path = get_element_value(cpl_details, 'FTPURL')
        return ingest_path

    def content_add_key(self, key):
        kdm = parse_kdm(key, load_from_file=False)
        kdm_uuid = kdm['id']
        self._ingest_kdm(key)
        self._add_key(kdm_uuid, {'cpl_title': kdm['cpl_text'],
         'cpl_uuid': kdm['cpl_id'],
         'not_valid_before': kdm['start_date'],
         'not_valid_after': kdm['end_date'],
         'dnqualifier': kdm['dn_qualifier'],
         'status': 'ok'})
        message = _('KDM saved on %s for CPL %s') % (self.device_configuration['screen_identifier'], kdm['cpl_text'])
        return (True, message)

    def content_cancel_transfer(self, transfer_id):
        try:
            self._cancel_ingest(int(transfer_id))
        except InvalidIDError:
            pass

        return (True, _('Transfer cancelled'))

    def content_clear_transfer_history(self):
        return (True, _('Transfer history cleared'))

    def content_delete(self, content_id):
        try:
            ret = self._delete_content(wrap_urn(content_id))
        except InvalidIDError:
            return (True, _('CPL does not exist on screen server'))

        return (True, _('CPL deleted'))

    def content_delete_key(self, key_id):
        self._delete_content(wrap_urn(key_id))
        return (True, _('KDM deleted'))

    def content_transfer(self, connection_details, description, cpl_uuid):
        oid = 167
        elements = {1: connection_details['ftp_ip'],
         2: connection_details['ftp_username'],
         3: connection_details['ftp_password'],
         4: 2,
         6: connection_details['ingest_path'],
         7: description or '',
         8: connection_details['ftp_port']}
        return_types = {5: INT}
        error_types = {1: ConnectionError,
         2: CPLNotFoundError}
        logging.info('doing a content transfer:' + str(elements))
        klv_message = create_klv_message(oid, elements, method='SET')
        response = self._execute_command(klv_message, return_types, error_types)
        transfer_id = response[5]
        return (True, _('Transfer started'), transfer_id)

    def validate_playlist(self, playlist_uuid):
        output = {'error_messages': [],
         'info': {}}
        response = {'result': 0,
         'error_code': 0,
         'description': '',
         'cpl_uuid': ''}
        try:
            validate_playlist_response = self._validate_playlist(playlist_uuid)
            start_time = time.time()
            while time.time() < start_time + 30:
                try:
                    validation_response = self._validate_playlist_result()
                    if validation_response[6] == playlist_uuid:
                        validation_info = validation_response[5]
                        status = get_element_value(cpl_details, 'Status')
                        if status == 'INVALID':
                            response['result'] = 1
                            for cpl in cpl_details.getElementsByTagName('CPL'):
                                if get_element_value(cpl, 'Id') != 'true':
                                    validation_info['validation_code'] = 1
                                    break
                                elif get_element_value(asset, 'HashStatus') == 'Differs from CPL':
                                    validation_info['validation_code'] = 2

                        response = validation_response[5]
                        break
                except ValidationInProgress as ex:
                    pass
                except NoValidationRunning as ex:
                    break

        except ValidationInProgress as ex:
            output['error_messages'].append(_('Currently validating another Playlist'))
        except InvalidIDError as ex:
            output['error_messages'].append(_('Cannot find requested Playlist'))

        output['info'] = response
        return output

    def get_playlist_uuid_list(self):
        """
        This recieves the uuids of all the playlists in the system
        
        @param      None
        @return     [playlist_uuid_list]      - list of playlist uuids
        """
        output = {'error_messages': [],
         'playlist_uuid_list': []}
        spl_id_list_response = self._list_playlists().keys()
        output['playlist_uuid_list'] = spl_id_list_response
        return output

    def get_playlist_information(self, playlist_uuids):
        """
        This playlist information for playlist uuids provided
        
        @param      playlist_uuids          LIST of playlist ids
        @return     playlist dictionary
        """
        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for playlist_uuid in playlist_uuids:
            try:
                playlist_xml = self._get_playlist(playlist_uuid)
                playlist = self._parse_playlist(playlist_xml)
            except ChristieIMBError as ex:
                output['error_messages'].append(_('Error getting Playlist information for ID %s: %s') % (playlist_uuid, str(ex)))
            else:
                playlist_info = {}
                playlist_info['title'] = playlist['title']
                playlist_info['duration_in_seconds'] = playlist['duration_in_seconds']
                playlist_info['is_3d'] = playlist['is_3d']
                playlist_info['is_hfr'] = playlist['is_hfr']
                playlist_info['is_pack'] = False
                playlist_info['playlist'] = playlist
                output['playlist_info_dict'][playlist_uuid] = playlist_info

        return output

    def playlist_delete(self, playlist_uuid):
        self._delete_content('playlist_' + playlist_uuid)
        return (True, 'Playlist deleted')

    def playlist_save(self, playlist):
        playlist_xml = self._construct_playlist(playlist)
        self._set_playlist(playlist_xml)
        return (True, _('Saved: %s') % playlist['title'])

    def get_intermission_state(self):
        try:
            state = self._execute_command(create_klv_message(182), {10: INT})
            if state[10] == 1:
                return True
            return False
        except Exception:
            return False

    def playback_interrupt_intermission(self):
        try:
            self._execute_command(create_klv_message(183))
            return (True, _('Intermission interrupted'))
        except:
            return (False, _('Failed to interrupt intermission'))

    def get_playback_status(self):
        output = {'error_messages': [],
         'playback_state': None,
         'spl_uuid': None,
         'spl_position': None,
         'spl_duration': None,
         'cpl_uuid': None,
         'element_id': None,
         'element_position': None,
         'element_duration': None,
         'element_index': None,
         'intermission': False,
         'modes': {'loop_mode': None,
                   'scheduler_enabled': None}}
        try:
            status_list = self._get_status_list([300,
             301,
             302,
             303,
             306,
             308,
             317])
        except ChristieIMBError as ex:
            output['error_messages'].append(_('Error getting playback status: %s') % str(ex))
        else:
            if status_list[306] not in (0, 100):
                output['error_messages'].append(LOAD_STATE[status_list[306]])
            output['playback_state'] = PLAYBACK_STATE[status_list[300]]
            if self.supports_intermission():
                output['intermission'] = self.get_intermission_state()
            content_id = status_list[301]
            if content_id is not None:
                if content_id.startswith('playlist'):
                    output['spl_uuid'] = content_id.replace('playlist_', '')
                    output['spl_position'] = float(status_list[302]) / 1000
                    output['spl_duration'] = float(status_list[303]) / 1000
                    try:
                        spl_info = self.playlist_information[output['spl_uuid']]
                    except KeyError:
                        pass
                    else:
                        tmp_duration = 0
                        for index, event in enumerate(spl_info['playlist']['events']):
                            if tmp_duration + event['duration_in_seconds'] > output['spl_position']:
                                output['element_id'] = event['id']
                                output['element_index'] = index
                                output['element_position'] = output['spl_position'] - tmp_duration
                                output['element_duration'] = event['duration_in_seconds']
                                output['cpl_uuid'] = event['cpl_id']
                                break
                            else:
                                tmp_duration += event['duration_in_seconds']

                else:
                    output['cpl_uuid'] = strip_urn(content_id)
                    output['element_id'] = output['cpl_uuid']
                    output['element_position'] = float(status_list[302]) / 1000
                    output['element_duration'] = float(status_list[303]) / 1000
            output['modes']['loop_mode'] = 'loop' if status_list[308] else 'do_not_loop'
            try:
                output['modes']['scheduler_enabled'] = self._get_status(450)
            except ChristieIMBError as ex:
                output['error_messages'].append(_('Error getting schedule mode status: %s') % str(ex))

        return output

    def playback_eject(self):
        """
            Ejects the current playback item
        """
        self._unload()
        self._device_sync_playback_status()
        playback_state = self._get_status(300)
        if playback_state == 0:
            return (True, _('Playlist ejected'))
        else:
            return (False, _('Error ejecting playlist'))

    def playback_load(self, playlist_id):
        """
        Load Content
        """
        playback_state = self._get_status_list([300, 301])
        if playback_state[300] == 0 and playback_state[301] != '':
            self._unload()
        self._load_content('playlist_' + playlist_id)
        for i in range(80):
            status = self._get_status_list([301, 306])
            if status[306] != 100:
                if status[301] == 'playlist_' + playlist_id:
                    if status[306] == 0:
                        return (True, _('Playlist loaded: %s') % self.playlist_information[playlist_id]['title'])
                    else:
                        error = LOAD_STATE.get(status[306], 'Unknown')
                        return (False, _('Error loading playlist: %s') % error)
                else:
                    error = LOAD_STATE.get(status[306], 'Unknown')
                    return (False, _('Error loading playlist: %s') % error)
            else:
                time.sleep(0.2)

        return (False, _('Error confirming playlist load'))

    def playback_pause(self):
        """
        Pauses the content
        """
        playback_status = self._get_status(300)
        if playback_status in (PLAYBACK_STATE['play'], PLAYBACK_STATE['pause']):
            self._pause_resume()
        return (True, _('Playback paused'))

    def playback_play(self):
        """
        Plays the content
        """
        playback_status = self._get_status(300)
        if playback_status == PLAYBACK_STATE['pause']:
            self._pause_resume()
        else:
            self._play(0)
        return (True, _('Playback started'))

    def playback_stop(self):
        """
        Stops the content
        """
        try:
            self._stop()
        except ContentNotLoadedError:
            return (False, _('No Playlist loaded'))

        return (True, _('Playback stopped'))

    def playback_skip_forward(self):
        current_element_id = self.playback_information['element_id']
        if current_element_id is None:
            logging.error('Error in finding the key in playback information element_id in %s' % str(self.playback_information))
            return (False, _('Error finding the current position in the Playlist'))
        else:
            playlist = self.playlist_information[self.playback_information['spl_uuid']]
            tmp_duration = 0
            for event in playlist['playlist']['events']:
                if event['duration_in_seconds']:
                    tmp_duration += event['duration_in_seconds']
                if event['id'] == current_element_id:
                    skip_position = tmp_duration
                    break

            skip_position = int(round(skip_position * 1000))
            if self.playback_information['playback_state'] == 'play':
                self._pause_resume()
                self._jog_playback(skip_position)
                self._pause_resume()
            else:
                self._jog_playback(skip_position)
            self._device_sync_playback_status()
            return (True, _('Playback skipped forward'))

    def playback_skip_backward(self):
        current_element_id = self.playback_information['element_id']
        if current_element_id is None:
            logging.error('Error in finding the key in playback information element_id in %s' % str(self.playback_information))
            return (False, _('Error finding the current position in the Playlist'))
        else:
            playlist = self.playlist_information[self.playback_information['spl_uuid']]
            tmp_duration = previous_item_position = 0
            for event in playlist['playlist']['events']:
                if event['id'] == current_element_id:
                    if self.playback_information['element_position'] < 5:
                        skip_position = previous_item_position
                    else:
                        skip_position = tmp_duration
                    break
                else:
                    previous_item_position = tmp_duration
                    if event['duration_in_seconds']:
                        tmp_duration += event['duration_in_seconds']

            skip_position = int(round(skip_position * 1000))
            if self.playback_information['playback_state'] == 'play':
                self._pause_resume()
                self._jog_playback(skip_position)
                self._pause_resume()
            else:
                self._jog_playback(skip_position)
            self._device_sync_playback_status()
            return (True, _('Playback skipped backwards'))

    def playback_set_mode(self, mode):
        """
        Sets the playback mode
        """
        if mode in self.supported_modes['schedule_modes']:
            if mode == 'schedule_on':
                enable = True
            else:
                enable = False
            self._enable_schedule(enable)
            if self._get_status(450) == enable:
                if enable:
                    return (True, _('Schedule mode enabled'))
                else:
                    return (True, _('Schedule mode disabled'))
            else:
                logging.error('error enabling /disabling the schedule mode:%s' % str(self._get_status(450)))
                return (False, _('Unknown error enabling or disabling schedule mode'))
        elif mode in self.supported_modes['loop_modes']:
            enabled = mode == 'loop'
            self._set_loop_mode(enabled)
            if self._get_status(308) == enabled:
                if enabled:
                    return (True, _('Loop mode enabled'))
                else:
                    return (True, _('Loop mode disabled'))
            else:
                logging.error('error enabling /disabling the loop mode:%s' % str(self._get_status(308)))
                return (False, _('Unknown error enabling or disabling loop mode'))

    def get_schedule_id_list(self):
        output = {'error_messages': []}
        output['schedule_id_list'] = self._get_schedule().keys()
        return output

    def get_schedule_information(self, schedule_ids):
        output = {'error_messages': [],
         'schedule_info_dict': {}}
        schedule_dicts = self._get_schedule()
        for schedule_id, schedule_dict in schedule_dicts.iteritems():
            if schedule_id in schedule_ids:
                output['schedule_info_dict'][schedule_id] = schedule_dict

        return output

    def scheduling_delete(self, schedule_id):
        self._delete_schedule_item(schedule_id)
        return (True, _('Schedule deleted'))

    def scheduling_schedule_playlist(self, playlist_id, timestamp):
        spl_title = self.playlist_information[playlist_id]['title']
        schedule_id = self._add_schedule_item(playlist_id, timestamp)
        success = True
        message = _('Playlist %s has been scheduled for %s') % (spl_title, helper_methods.format_timestamp(timestamp))
        schedule_info = {'device_playlist_uuid': playlist_id,
         'start_time': timestamp,
         'device_schedule_id': schedule_id}
        return (success, message, schedule_info)

    def get_automation_list(self):
        output = {'error_messages': [],
         'automation_uuid_list': []}
        automation_dict = self._get_automation_config()
        output['automation_uuid_list'] = automation_dict['inputcues'] + automation_dict['macros']
        if self.supports_intermission():
            output['automation_uuid_list'].append('Intermission')
        return output

    def get_automation_information(self, automation_uuids):
        output = {'error_messages': [],
         'automation_info_dict': {}}
        automation_dict = self._get_automation_config()
        for inputcue in automation_dict['inputcues']:
            if inputcue in automation_uuids:
                output['automation_info_dict'][inputcue] = {}
                output['automation_info_dict'][inputcue]['name'] = inputcue
                output['automation_info_dict'][inputcue]['duration'] = 0
                output['automation_info_dict'][inputcue]['type'] = 'wait_for_input'

        for macro in automation_dict['macros']:
            if macro in automation_uuids:
                output['automation_info_dict'][macro] = {}
                output['automation_info_dict'][macro]['name'] = macro
                output['automation_info_dict'][macro]['duration'] = 0
                output['automation_info_dict'][macro]['type'] = 'cue'

        if self.supports_intermission():
            output['automation_info_dict']['Intermission'] = {}
            output['automation_info_dict']['Intermission']['name'] = 'Christie Intermission'
            output['automation_info_dict']['Intermission']['duration'] = 0
            output['automation_info_dict']['Intermission']['type'] = 'intermission'
        return output

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        if self.automation.has_key(cue_id):
            self._execute_macro(cue_id)
            return (True, _('Automation cue %s fired') % cue_id)
        else:
            return (False, _('Cannot find automation cue %s on screen server') % cue_id)

    def get_logs(self, start_datetime):
        """
        NB: Christie only returns playouts of encrypted content so the number returned will be far less than for other devices
        """
        output = {'error_messages': [],
         'xml': None}
        TIMEOUT = 720
        RETRIES = 60
        RETRY_WAIT = 10
        formatted_date = start_datetime.strftime('%Y%m%d')
        oid = 102
        elements = {1: formatted_date,
         2: formatted_date,
         3: LOG_TYPE_SM_REPORT}
        return_types = {1: STRING,
         2: STRING,
         3: INT,
         5: STRING}
        klv_message = create_klv_message(oid, elements)
        response = self._execute_command(klv_message, return_types, timeout=TIMEOUT)
        if response.has_key(5):
            url_parts = ('http',
             self.device_configuration['ip'],
             response[5],
             '',
             '',
             '')
            url = None
            for attempt in xrange(0, RETRIES):
                try:
                    url = urllib2.urlopen(urlparse.urlunparse(url_parts))
                    error = None
                except Exception as ex:
                    error = str(ex)
                    time.sleep(RETRY_WAIT)

                if not error:
                    break

            if RETRIES - attempt < 5:
                logging.warn('Took %d out of %d polls to pull Christie logs from %s' % (attempt, RETRIES, self.device_configuration['ip']))
            if url:
                zip = zipfile.ZipFile(StringIO(url.read()))
                for archive in zip.namelist():
                    if 'log' in archive:
                        all_log_xml = zip.read(archive)
                        all_log_xml = all_log_xml.replace('lr:', '')
                        all_log_xml = all_log_xml.replace('dcml:', '')
                        output['xml'] = all_log_xml
                        break

            else:
                output['error_messages'].append('Timeout waiting for logs to be published')
        else:
            output['error_messages'].append('Invalid log response')
        return output

    def is_ready_for_collect(self):
        """
        Overwrite this function if there are conditions which must be met
        before we can start log collection.
        @return 
                bool
                
        """
        return self.playback_information['playback_state'] not in ('error', 'playback_unknown') and self.playback_information['spl_uuid'] == None
# okay decompyling ./core/devices/sms/christie/christie_imb.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:25 CST
