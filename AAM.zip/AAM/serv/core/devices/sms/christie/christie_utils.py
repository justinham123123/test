# 2017.08.13 21:49:25 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\christie\christie_utils.py
"""
Christie Utilities
"""

class ChristieBadResponse(Exception):
    pass


class ChristieIMBError(Exception):

    def __repr__(self):
        return '%s()' % self.__class__.__name__

    def __str__(self):
        return repr(self)


class UnknownError(ChristieIMBError):

    def __init__(self, error_code):
        super(ChristieIMBError, self).__init__(self)
        self.error_code = error_code

    def __repr__(self):
        return '%s(error_code=%d)' % (self.__class__.__name__, self.error_code)


class Timeout(ChristieIMBError):
    pass
# okay decompyling ./core/devices/sms/christie/christie_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:25 CST
