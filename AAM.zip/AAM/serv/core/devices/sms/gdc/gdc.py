# 2017.08.13 21:49:45 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\gdc\gdc.py
"""
GDC SMS Adaptor
"""
import array, datetime, logging, os.path, posixpath, socket, urlparse, uuid, time
from contextlib import contextmanager
from xml.dom import DOMException
from xml.sax.saxutils import escape as xml_escape
from serv.lib.cherrypy.i18n_tool import ugettext as _
import cherrypy
from serv.configuration import cfg
from serv.configuration.constants import HFR_FPS
from serv.lib.utilities import helper_methods
from serv.lib.utilities.date_utils import parse_date
from serv.lib.dcinema.parsers.certificate_parsers import parse_device_certificates
from serv.lib.dcinema.parsers.parsers import parse_kdm, parse_cpl, parse_content_title_text, construct_smpte_playlist, parse_smpte_playlist
from serv.lib.network.snmp import SNMPException
from serv.lib.network.socket_utils import decode_ber_length
from serv.lib.network.socket_utils import int_to_ber_length
from serv.lib.network.socket_utils import str_to_byte_array
from serv.lib.network.socket_utils import receive_bytes
from serv.lib.utilities.utils import strip_urn, wrap_urn
from serv.core.devices.base.scheduling import Scheduling
from serv.core.devices.base.socket_pool import SocketPool
from serv.core.devices.sms.gdc import gdc_utils
from serv.lib.utilities.xml_utils import node_to_dict
PLAYBACK_STATE = {'PLAYING': 'play',
 'PAUSED': 'pause',
 'STOPPED': 'stop',
 'ERROR': 'error'}
ASSET_ERROR_MISSING = '0x001'
ASSET_ERROR_PARSE = '0x002'
ASSET_ERROR_NO_KDM = '0x003'
ASSET_ERROR_UNKNOWN = '0xfff'
RAID_STATUS_OID = '.1.3.6.1.4.1.28713.1.6.1.1.6.1'
RAID_STATUS_OK = '2'

def _convert_to_seconds(time_str):
    """
    Converts a time in the format: 'HH:MM:SS' to seconds
    """
    bits = time_str.split(':')
    return int(bits[0]) * 60 * 60 + int(bits[1]) * 60 + int(bits[2])


def _encode_command(xml_command):
    """
    Encodes a GDC XML command for transport over a TCP/IP socket
    """
    command = array.array('B', (6, 14, 43, 52, 2, 5, 1, 1, 15, 21, 1, 16, 0, 0, 0, 0))
    command.extend(int_to_ber_length(len(xml_command)))
    command.extend(str_to_byte_array(xml_command))
    return command


def _build_command(name, version = '2.1', attributes = [], children = []):
    """
    Constructs a (simple) GDC XML command.
    The attributes list takes is of the form [(key, value)] and
    places them in the tag element.
    The children list creates child tags within the command structure.
    """
    command = '<?xml version="1.0" encoding="UTF-8" ?>'
    command += '<command version="%s" cmd=' % version
    command += '"%s"' % name
    for attribute_name, attribute_value in attributes:
        command += ' %s="%s" ' % (attribute_name, attribute_value)

    command += '>'
    for child in children:
        command += '<%s>%s</%s>' % (child[0], child[1], child[0])

    command += '</command>'
    return _encode_command(command)


HEARTBEAT_CMD = _build_command('HEARTBEAT')
GET_CPL_LIST_CMD = _build_command('GET_CPL_LIST', attributes=[('list_all', 'false')])
GET_CPL_STATUS_LIST = _build_command('GET_LIST_OF_ASSET_STATUS', children=[('asset_type', 'CPL')])
GET_KDM_LIST_CMD = _build_command('GET_KDM_LIST')
GET_INGEST_LIST_CMD = _build_command('GET_INGEST_LIST')
GET_PLAYBACK_STATUS_CMD = _build_command('GET_PLAYBACK_STATUS')
GET_SHOW_LIST_CMD = _build_command('GET_SHOW_LIST')
CLEAR_SHOW_CMD = _build_command('CLEAR_SHOW')
PLAY_CMD = _build_command('PLAY_SHOW')
PAUSE_CMD = _build_command('PAUSE_PLAYBACK')
STOP_CMD = _build_command('STOP_PLAYBACK')
FORWARD_CMD = _build_command('SKIP_FORWARD')
BACKWARD_CMD = _build_command('SKIP_BACKWARD')
UNPAUSE_CMD = _build_command('UNPAUSE_PLAYBACK')
GET_SERVER_INFO_CMD = _build_command('GET_SERVER_INFO')
GET_DATE_TIME_CMD = _build_command('GET_DATE_TIME')
GET_CERTIFICATES_CMD = _build_command('GET_CERTIFICATES')
GET_STORAGE_INFO_CMD = _build_command('GET_STORAGE_INFO')
GET_SCHEDULER_STATUS_CMD = _build_command('GET_SCHEDULER_STATUS')
ENABLE_SCHEDULER_CMD = _build_command('ENABLE_SCHEDULER')
DISABLE_SCHEDULER_CMD = _build_command('DISABLE_SCHEDULER')
SCHEDULES_CMD = _build_command('GET_SCHEDULES')
GET_CURRENT_SCHEDULE = _build_command('GET_CURRENT_SCHEDULE')
GET_NEXT_SCHEDULE = _build_command('GET_NEXT_SCHEDULE')
GET_AUTOMATION_LABELS = _build_command('GET_AUTOMATION_LABELS')
GDC_TRANSFER_STATUS_MAP = {'Queued': 'queued_on_device',
 'Running': 'active',
 'Complete': 'success',
 'Cancelled': 'cancelled',
 'Exception': 'failed',
 'Incomplete DCP': 'failed'}

class GDC(SocketPool, Scheduling):
    """
    Implementation of the Core 2.0 representation of a GDC server
    """

    def __init__(self, id, device_info, snmp_manager):
        super(GDC, self).__init__(id, device_info)
        self.MAX_SOCKETS = 4
        self.snmp_manager = snmp_manager
        self.supported_modes = {'loop_modes': [],
         'schedule_modes': ['schedule_on', 'schedule_off']}
        self.ignored_transfers = set()

    def socket_address(self):
        return (self.device_configuration['ip'], self.device_configuration['port'])

    def _send_receive(self, command, timeout = 30):
        """
        Sends a command to a GDC server and returns the XML response
        """
        with self.get_socket(timeout) as soc:
            soc.settimeout(timeout)
            soc.sendall(command)
            response_header = receive_bytes(soc, 16)
            response_length, len_bytes_read = decode_ber_length(soc.recv)
            response_xml = receive_bytes(soc, response_length)
            soc.settimeout(0)
            return response_xml.decode('latin1')

    def _get_iso_datetime(self):
        """
        Returns the server's date and time in ISO format:
        YYYY-MM-DDTHH:MM:SS+ZZ:ZZ
        """
        xml = self._send_receive(GET_DATE_TIME_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('iso_date_time'))
        return (res['success'], res['message'], res['response'])

    def _get_server_info(self):
        """
        Retrieves the server info
        """
        xml = self._send_receive(GET_SERVER_INFO_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._extract_server_info)
        return (res['success'], res['message'], res['response'])

    def _get_certificates(self):
        """
        Returns a list of certificates in PEM format
        """
        xml = self._send_receive(GET_CERTIFICATES_CMD)
        res = gdc_utils._process_response(xml, node_to_dict)
        return (res['success'], res['message'], res['response']['certificate'])

    def _get_kdm_uuids(self):
        """
        Returns a list of KDM UUIDs
        """
        xml = self._send_receive(GET_KDM_LIST_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._extract_uuid_list_by_tag('asset_uuid'))
        return (res['success'], res['message'], res['response'])

    def _get_kdm(self, kdm_uuid):
        """
        Gets the raw XML for a specified KDM
        """
        request = _build_command('GET_KDM', children=[('asset_uuid', wrap_urn(kdm_uuid))])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('response_text'))
        return (res['success'], res['message'], res['response'])

    def _get_cpl_uuids(self):
        """
        Returns a list of CPL UUIDs
        """
        xml = self._send_receive(GET_CPL_STATUS_LIST)
        res = gdc_utils._process_response(xml, gdc_utils._extract_cpl_uuid_list)
        return (res['success'], res['message'], res['response'])

    def _get_cpl(self, cpl_uuid):
        """
        Returns the raw XML for a specified CPL
        """
        request = _build_command('GET_CPL', children=[('cpl_uuid', cpl_uuid)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('response_text'))
        return (res['success'], res['message'], res['response'])

    def _get_cpl_statuses(self):
        xml = self._send_receive(GET_CPL_STATUS_LIST)
        res = gdc_utils._process_response(xml, gdc_utils._extract_cpl_statuses)
        return (res['success'], res['message'], res['response'])

    def _get_asset_uri(self, asset_id):
        """
        Retrieves the ftp uri of a CPL
        """
        request = _build_command('GET_ASSET_URI', children=[('asset_uuid', asset_id), ('asset_type', 'CPL')])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('asset_uri'))
        return (res['success'], res['message'], res['response'])

    def _get_asset_size(self, asset_id):
        """
        Retrieves the size, in bytes, of an asset (currently only CPL supported)
        """
        request = _build_command('GET_ASSET_SIZE', children=[('asset_uuid', asset_id), ('asset_type', 'CPL')])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('asset_size'))
        return (res['success'], res['message'], res['response'])

    def _get_playlist_uuids(self):
        xml = self._send_receive(GET_SHOW_LIST_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._extract_uuid_list_by_tag('show_uuid'))
        return (res['success'], res['message'], res['response'])

    def _get_playlist(self, playlist_uuid):
        request = _build_command('GET_SHOW', children=[('show_uuid', playlist_uuid)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('response_text'))
        return (res['success'], res['message'], res['response'])

    def _update_content_in_playlist(self, content_uuid, playlist_uuid):
        playlist = self.playlist_information[playlist_uuid]
        cpl = cherrypy.core.contents[content_uuid]
        playlist_is_3d = False
        playlist_is_hfr = False
        playlist_is_4k = False
        playlist_duration = 0
        for event in playlist['playlist']['events']:
            if event['type'] == 'composition' and event['cpl_id'] == content_uuid:
                event['text'] = cpl['content_title_text']
                if cpl['duration_in_seconds'] is not None:
                    event['duration_in_seconds'] = cpl['duration_in_seconds']
                if cpl['duration_in_frames'] is not None:
                    event['duration_in_frames'] = cpl['duration_in_frames']
                if cpl['edit_rate'][0] is not None and cpl['edit_rate'][1] is not None:
                    event['edit_rate'] = (cpl['edit_rate'][0], cpl['edit_rate'][1])
                    for automation_dict in event['automation']:
                        if automation_dict['type'] == 'cue':
                            automation_dict['type_specific']['offset_in_seconds'] = automation_dict['type_specific']['offset_in_frames'] / (1.0 * int(event['edit_rate'][0]) / int(event['edit_rate'][1]))

                    playlist_is_hfr |= cpl['edit_rate'][0] > HFR_FPS
                playlist_is_3d |= cpl['playback_mode'] == '3D'
            playlist_duration += int(event['duration_in_seconds']) if event['duration_in_seconds'] else 0

        playlist['is_3d'] = playlist['playlist']['is_3d'] = playlist_is_3d
        playlist['is_hfr'] = playlist['playlist']['is_hfr'] = playlist_is_hfr
        playlist['is_4k'] = playlist['playlist']['is_4k'] = playlist_is_4k
        playlist['duration_in_seconds'] = playlist['playlist']['duration_in_seconds'] = playlist_duration
        return

    def _get_schedules(self):
        xml = self._send_receive(SCHEDULES_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._parse_schedules)
        schedules = []
        if res['success']:
            if res['response']['success']:
                schedules = res['response']['schedules']
            else:
                res['success'] = False
                res['message'] = res['response']['message']
                schedules = None
        return (res['success'], res['message'], schedules)

    def get_device_status(self):
        output = {'error_messages': []}
        success, error_message, iso_datetime = self._get_iso_datetime()
        if success:
            output['current_time'] = parse_date(iso_datetime)
        else:
            output['error_messages'].append(error_message)
        return output

    def test_management_connection(self):
        try:
            self._send_receive(GET_DATE_TIME_CMD)
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error %s') % str(ex))

        return (True, _('OK'))

    def get_device_version_information(self):
        output = {'error_messages': []}
        success, error_message, info = self._get_server_info()
        if success:
            output['model'] = info['model']
            output['serial'] = info['serial']
        else:
            output['model'] = None
            output['serial'] = None
            output['error_messages'].append(error_message)
        return output

    def get_device_information(self):
        output = self.get_device_version_information()
        success, error_message, certificates = self._get_certificates()
        output.update(parse_device_certificates(*certificates))
        if not success:
            output['error_messages'].append(error_message)
        try:
            raid_status = self.snmp_manager.snmpGet(RAID_STATUS_OID, self.device_configuration['ip'], version=2)
        except SNMPException as ex:
            output['raid_status'] = [{'name': 'RAID',
              'status': 'error',
              'message': 'Not Available'}]
            if not cfg.core_log_collection_only():
                logging.error('Error getting RAID status: address = %s' % str(self.device_configuration['ip']), exc_info=True)
        else:
            if raid_status == RAID_STATUS_OK:
                output['raid_status'] = [{'name': 'RAID',
                  'status': 'ok',
                  'message': 'OK'}]
            else:
                output['raid_status'] = [{'name': 'RAID',
                  'status': 'warning',
                  'message': 'Degraded'}]

        xml = self._send_receive(GET_STORAGE_INFO_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._extract_storage_info)
        output['storage_total'] = res['response']['total']
        output['storage_available'] = res['response']['free']
        output['storage_used'] = res['response']['total'] - res['response']['free']
        return output

    def server_performance_metrics(self):
        return [self.playback_information['playback_state'], 'transfers: ' + str(len(self.transfer_information.get('transfers', [])))]

    def get_key_uuid_list(self):
        output = {'error_messages': [],
         'key_uuid_list': []}
        success, error_message, kdm_uuids = self._get_kdm_uuids()
        if success:
            output['key_uuid_list'] = kdm_uuids
        else:
            output['error_messages'].append(error_message)
        return output

    def get_key_information(self, kdm_uuids):
        """
        gets key information of a device
        """
        output = {'error_messages': [],
         'key_info_dict': {}}
        if kdm_uuids == None:
            success, error_message, kdm_uuids = self._get_kdm_uuids()
            if not success:
                output['error_messages'].append(error_message)
                return output
        for kdm_uuid in kdm_uuids:
            success, error_message, kdm_xml = self._get_kdm(kdm_uuid)
            if success:
                kdm = parse_kdm(kdm_xml, load_from_file=False)
                key_uuid = kdm['id']
                output['key_info_dict'][key_uuid] = {}
                output['key_info_dict'][key_uuid]['cpl_title'] = kdm['cpl_text']
                output['key_info_dict'][key_uuid]['cpl_uuid'] = kdm['cpl_id']
                output['key_info_dict'][key_uuid]['not_valid_before'] = kdm['start_date']
                output['key_info_dict'][key_uuid]['not_valid_after'] = kdm['end_date']
                output['key_info_dict'][key_uuid]['dnqualifier'] = kdm['dn_qualifier']
                output['key_info_dict'][key_uuid]['status'] = 'ok'
            output['error_messages'].append(error_message)

        return output

    def get_key(self, key_uuid):
        """
        gets key xml
        
        @return
            dict
                xml        DICT
                    xml    STRING
                error_messages          -LIST of errors
        """
        output = {'error_messages': [],
         'xml': {}}
        success, error_message, kdm_xml = self._get_kdm(key_uuid)
        if success:
            output['xml'] = kdm_xml
        else:
            output['error_messages'].append(error_message)
        return output

    def get_transfer_ids(self):
        output = {'error_messages': [],
         'transfers': []}
        xml = self._send_receive(GET_INGEST_LIST_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._extract_uuid_list_by_tag('ingest_uuid'))
        output['transfers'] = res['response']
        self.ignored_transfers.intersection_update(res['response'])
        return output

    def get_transfer_info(self, transfer_ids):
        output = {'error_messages': [],
         'transfers': []}
        for ingest_uuid in transfer_ids:
            if ingest_uuid not in self.ignored_transfers:
                request = _build_command('GET_INGEST_STATUS', children=[('ingest_uuid', wrap_urn(ingest_uuid))])
                xml = self._send_receive(request)
                res = gdc_utils._process_response(xml, gdc_utils._extract_transfert_info)
                output_info = {'server_transfer_id': ingest_uuid,
                 'state': None,
                 'description': None,
                 'content_id': None,
                 'type': None,
                 'source': None,
                 'progress': None,
                 'message': None}
                if res['success']:
                    output_info['type'] = res['response'].get('asset_type')
                    asset_uri = res['response'].get('asset_uri')
                    if asset_uri is not None:
                        parsed_url = urlparse.urlparse(asset_uri)
                        if not parsed_url.scheme or parsed_url.scheme == 'file':
                            output_info['source'] = 'local'
                        else:
                            output_info['source'] = parsed_url.hostname
                    asset_uuid = res['response'].get('asset_uuid')
                    if asset_uuid is not None:
                        output_info['content_id'] = asset_uuid
                        output_info['description'] = asset_uuid
                    status = res['response'].get('status')
                    output_info['state'] = GDC_TRANSFER_STATUS_MAP[status]
                    output_info['message'] = res['response'].get('description')
                    total = res['response'].get('total_size')
                    transferred_size = res['response'].get('transferred_size')
                    if total and transferred_size:
                        output_info['progress'] = 100 * transferred_size / total
                output['transfers'].append(output_info)

        return output

    def get_content_uuid_list(self):
        output = {'error_messages': [],
         'content_uuid_list': []}
        success, error_message, cpl_uuids = self._get_cpl_uuids()
        if success:
            output['content_uuid_list'] = cpl_uuids
        else:
            output['error_messages'].append(error_message)
        return output

    def get_content_information(self, content_uuids):
        output = {'error_messages': [],
         'content_info_dict': {}}
        for cpl_uuid in content_uuids:
            cpl_info = {'content_title_text': cpl_uuid,
             'content_kind': 'unknown',
             'edit_rate': None,
             'subtitled': None,
             'subtitle_language': None,
             'playback_mode': None,
             'aspect_ratio': None,
             'duration_in_seconds': 0,
             'duration_in_frames': 0,
             'encrypted': None,
             'xml': None,
             'parsed_info': parse_content_title_text(''),
             'video_encoding': 'UNKNOWN'}
            try:
                success, error_message, cpl_xml = self._get_cpl(cpl_uuid)
                if success:
                    cpl = parse_cpl(cpl_xml, load_from_file=False)
                    cpl_info['content_title_text'] = cpl['text']
                    cpl_info['content_kind'] = cpl['type']
                    cpl_info['edit_rate'] = cpl['edit_rate']
                    cpl_info['subtitled'] = cpl['subtitled']
                    cpl_info['subtitle_language'] = cpl['subtitle_language']
                    cpl_info['playback_mode'] = cpl['playback_mode']
                    cpl_info['aspect_ratio'] = cpl['aspect_ratio']
                    cpl_info['duration_in_seconds'] = cpl['duration_in_seconds']
                    cpl_info['duration_in_frames'] = cpl['duration_in_frames']
                    cpl_info['encrypted'] = cpl['encrypted']
                    cpl_info['xml'] = cpl_xml
                    cpl_info['parsed_info'] = cpl['parsed_info']
                else:
                    cpl_info['error_message'] = error_message
                    output['error_messages'].append(error_message)
            except Exception as ex:
                logging.error('Error getting cpl information for cpl_id %s' % cpl_uuid, exc_info=True)
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))

            output['content_info_dict'][cpl_uuid] = cpl_info

        return output

    def get_ingest_path(self, content_uuid):
        success, error_message, asset_uri = self._get_asset_uri(content_uuid)
        if asset_uri:
            asset_uri = asset_uri.split('/', 3)[3]
        return asset_uri

    def get_content_validation_information(self, content_uuids):
        output = {'error_messages': [],
         'content_validation_dict': {}}
        success, error_message, cpl_status_dict = self._get_cpl_statuses()
        if success:
            for cpl_uuid in content_uuids:
                try:
                    status_info = cpl_status_dict[cpl_uuid]
                except KeyError:
                    continue

                cpl_info = {}
                cpl_info['validation_code'] = 0
                if not status_info['ok']:
                    for error in status_info['errors']:
                        if error == ASSET_ERROR_MISSING:
                            cpl_info['validation_code'] = 1
                        elif error == ASSET_ERROR_PARSE and cpl_info['validation_code'] != 1:
                            cpl_info['validation_code'] = 2
                        elif error == ASSET_ERROR_UNKNOWN and cpl_info['validation_code'] != 1:
                            cpl_info['validation_code'] = 2

                success, error_message, asset_uri = self._get_asset_uri(cpl_uuid)
                if success:
                    cpl_info['ingest_path'] = asset_uri.split('/', 3)[3]
                else:
                    cpl_info['ingest_path'] = None
                    output['error_messages'].append(error_message)
                success, error_message, asset_size = self._get_asset_size(cpl_uuid)
                if success:
                    cpl_info['cpl_size'] = asset_size
                else:
                    cpl_info['cpl_size'] = None
                    output['error_messages'].append(error_message)
                output['content_validation_dict'][cpl_uuid] = cpl_info

        else:
            output['error_messages'].append(error_message)
        return output

    def content_add_key(self, key):
        success = True
        kdm = parse_kdm(key, load_from_file=False)
        filename = kdm['id'] + '.xml'
        tmp_file_path = os.path.join(cfg.lms_library_directory(), 'tmp', filename)
        if not os.path.exists(tmp_file_path):
            with open(tmp_file_path, 'wb') as f:
                f.write(key)
        ftp_url = 'ftp://%s:%s@%s:%d/' % (cfg.lms_ftp_username(),
         cfg.lms_ftp_password(),
         cfg.lms_ftp_ip(),
         cfg.lms_ftp_port())
        ftp_path = posixpath.join('tmp', filename)
        request = _build_command('INGEST_FILE', children=[('source', ftp_url),
         ('path', ftp_path),
         ('asset_type', 'KDM'),
         ('asset_uuid', kdm['id'])])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('ingest_uuid'))
        ingest_id = None
        if res['success']:
            ingest_id = strip_urn(res['response'])
            message = _('Transfer started')
        else:
            success = False
            message = res['message']
        return (success, message, ingest_id)

    def content_cancel_transfer(self, transfer_id):
        request = _build_command('CANCEL_INGEST', children=[('ingest_uuid', transfer_id)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            return (True, _('Transfer cancelled'))
        else:
            return (False, res['message'])

    def content_clear_transfer_history(self):
        completed_transfers = self.get_completed_transfers()
        for transfer_id in completed_transfers:
            if completed_transfers[transfer_id].has_key('server_transfer_id'):
                self.ignored_transfers.add(completed_transfers[transfer_id]['server_transfer_id'])

        return (True, _('Transfer history cleared'))

    def content_delete(self, content_id, sleep = False):
        if sleep == True:
            time.sleep(2.5)
        output = {}
        request = _build_command('DELETE_CONTENT', children=[('asset_uuid', content_id)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            return (True, _('CPL deleted'))
        else:
            return (False, res['message'])

    def content_delete_key(self, key_id):
        request = _build_command('DELETE_FILE', children=[('asset_uuid', key_id)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            return (True, _('KDM deleted'))
        else:
            return (False, res['message'])

    def content_transfer(self, connection_details, description, cpl_uuid):
        connection_string = 'ftp://%s:%s@%s:%d/' % (connection_details['ftp_username'],
         connection_details['ftp_password'],
         connection_details['ftp_ip'],
         connection_details['ftp_port'])
        request = _build_command('INGEST_CONTENT', children=[('source', connection_string),
         ('path', connection_details['ingest_path']),
         ('asset_uuid', cpl_uuid),
         ('asset_type', 'CPL')])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('ingest_uuid'))
        if res['success']:
            ingest_id = strip_urn(res['response'])
            return (True, _('Transfer started'), ingest_id)
        else:
            return (False, res['message'], None)
            return None

    def get_playlist_missing_or_invalid_cpl_uuids(self, playlist_uuid):
        """
        Returns a list of cpl uuids that are present in the given playlist but
        are corrupt, missing assets or not present on the device.
        This is only used for marker clip templating.
        """
        request = _build_command('VALIDATE_SHOW', children=[('show_uuid', playlist_uuid)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._extract_errors)
        missing_or_corrupt_cpls = set()
        if not res['success']:
            for error in res['response']:
                error_code = int(error['code'], 16)
                if error_code != 3 and error['asset_type'] == 'CPL':
                    missing_or_corrupt_cpls.add(strip_urn(str(error['asset_uuid'])))

        return missing_or_corrupt_cpls

    def validate_cpl(self, cpl_uuid):
        """
        Returns the validation info for the given cpl returned by the
        VALIDATE_CPL call.
        This is only used for marker clip templating.
        """
        request = _build_command('VALIDATE_CPL', children=[('cpl_uuid', cpl_uuid)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._extract_errors)
        for error in res['response']:
            error['code'] = int(error['code'], 16)

        return res

    def validate_playlist(self, playlist_uuid):
        output = {'error_messages': [],
         'info': {}}
        request = _build_command('VALIDATE_SHOW', children=[('show_uuid', playlist_uuid)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, gdc_utils._extract_errors)
        logging.info('%s %s' % (str(res['success']), str(res['message'])))
        validation = {'result': 0,
         'error_code': 0,
         'description': '',
         'cpl_uuid': ''}
        if not res['success']:
            output['error_messages'].append(res['message'])
            validation['result'] = 1
            description = ''
            for error in res['response']:
                error_code = int(error['code'], 16)
                if error_code == 1:
                    validation['error_code'] = 2
                elif error_code in (2, 3, 4, 4095):
                    validation['error_code'] = 3
                description = str(error['description'])
                if error['asset_type'] == 'CPL':
                    validation['cpl_uuid'] = strip_urn(str(error['asset_uuid']))
                else:
                    description = description + ':%s' % error['asset_type']
                validation['description'] = description
                break

        output['info'] = validation
        return output

    def get_playlist_uuid_list(self):
        output = {'error_messages': [],
         'playlist_uuid_list': []}
        success, error_message, playlist_uuids = self._get_playlist_uuids()
        if success:
            output['playlist_uuid_list'] = playlist_uuids
        else:
            output['playlist_uuid_list'] = []
            output['error_messages'].append(error_message)
        return output

    def get_playlist_information(self, playlist_uuids):
        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for playlist_uuid in playlist_uuids:
            try:
                success, error_message, playlist_xml = self._get_playlist(playlist_uuid)
                if success:
                    playlist = parse_smpte_playlist(cherrypy.core.contents, playlist_xml)
                    for event in playlist['events']:
                        for automation in event.get('automation', []):
                            if automation['name'] == 'GDC-START-CUE-c71a62ac-9890-48c0-8e7a-56d58f153e04':
                                automation['name'] = 'GDC-START-CUE'
                                automation['type'] = 'gdc_start_cue'
                                automation['type_specific']['delay_in_seconds'] = automation['type_specific']['offset_in_frames']

                    output['playlist_info_dict'][playlist_uuid] = {}
                    output['playlist_info_dict'][playlist_uuid]['title'] = playlist['title'] or playlist['text']
                    output['playlist_info_dict'][playlist_uuid]['duration_in_seconds'] = playlist['duration_in_seconds']
                    output['playlist_info_dict'][playlist_uuid]['is_3d'] = playlist['is_3d']
                    output['playlist_info_dict'][playlist_uuid]['is_hfr'] = playlist['is_hfr']
                    output['playlist_info_dict'][playlist_uuid]['is_4k'] = playlist['is_4k']
                    output['playlist_info_dict'][playlist_uuid]['playlist'] = playlist
                    output['playlist_info_dict'][playlist_uuid]['content_version_id'] = playlist['content_version_id']
                else:
                    output['error_messages'].append(error_message)
            except DOMException as ex:
                logging.error('Error parsing playlist %s' % playlist_uuid, exc_info=True)
                error_message = _('Error parsing Playlist %s: %s') % (playlist_uuid, str(ex))
                output['error_messages'].append(error_message)

        return output

    def playlist_delete(self, playlist_uuid):
        request = _build_command('DELETE_SHOW', children=[('show_uuid', playlist_uuid)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            return (True, _('Playlist deleted'))
        else:
            return (False, res['message'])

    def playlist_save(self, playlist):
        for event in playlist['events']:
            for automation in event.get('automation', []):
                if automation['type'] == 'gdc_start_cue':
                    automation['name'] = automation['type_specific']['action']
                    automation['type_specific']['offset_in_frames'] = automation['type_specific']['delay_in_seconds']
                    automation['type_specific']['action'] = 'GDC-START-CUE-c71a62ac-9890-48c0-8e7a-56d58f153e04'

        playlist_xml = construct_smpte_playlist(cherrypy.core.contents, playlist)
        escaped_xml = xml_escape(playlist_xml)
        request = _build_command('PUT_SHOW', children=[('command_text', escaped_xml)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            return (True, _('Saved: %s') % playlist['title'])
        else:
            return (False, res['message'])

    def get_playback_status(self):
        output = {'error_messages': []}
        output['modes'] = {}
        xml = self._send_receive(GET_PLAYBACK_STATUS_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._extract_status)
        if res['success']:
            response = res['response']
            output['playback_state'] = PLAYBACK_STATE.get(response['state'], 'error')
            output['spl_uuid'] = response['show_uuid']
            if output['spl_uuid'] == '00000000-0000-0000-0000-000000000000':
                output['spl_uuid'] = None
            output['spl_position'] = response['show_played']
            output['spl_duration'] = response['show_total']
            output['element_id'] = str(response['cpl_index'])
            output['cpl_uuid'] = response['cpl_uuid']
            if output['cpl_uuid'] == '00000000-0000-0000-0000-000000000000':
                output['cpl_uuid'] = None
            output['element_position'] = response['cpl_played']
            output['element_duration'] = response['cpl_total']
            output['element_index'] = int(response['cpl_index'])
            if output['playback_state'] == 'error':
                playback_error_message = response['error'] if response['error'] else _('Unknown error getting playback information')
                playback_error_message = playback_error_message.strip(' []')
                msg_split = playback_error_message.split(':')
                if len(msg_split) == 2:
                    output['error_messages'].append(_('Error with %s: %s') % (msg_split[0], msg_split[1]))
                else:
                    output['error_messages'].append(playback_error_message)
        else:
            output['playback_state'] = None
            output['spl_uuid'] = None
            output['spl_position'] = None
            output['spl_duration'] = None
            output['cpl_uuid'] = None
            output['element_id'] = None
            output['element_position'] = None
            output['element_duration'] = None
            output['element_index'] = None
            output['error_messages'].append(res['message'])
        xml = self._send_receive(GET_SCHEDULER_STATUS_CMD)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_attribute('status', 'enabled'))
        if res['success']:
            output['modes']['scheduler_enabled'] = res['response'] == 'true'
        else:
            output['modes']['scheduler_enabled'] = None
            output['error_messages'].append(res['message'])
        return output

    def playback_eject(self):
        xml = self._send_receive(CLEAR_SHOW_CMD)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            self._device_sync_playback_status()
            return (True, _('Playlist ejected'))
        else:
            return (False, res['message'])

    def playback_load(self, playlist_id):
        request = _build_command('LOAD_SHOW', children=[('show_uuid', wrap_urn(playlist_id))])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            self._device_sync_playback_status()
            return (True, _('Playlist loaded: %s') % self.playlist_information[playlist_id]['title'])
        else:
            return (False, res['message'])

    def playback_pause(self):
        xml = self._send_receive(PAUSE_CMD)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            self._device_sync_playback_status()
            return (True, _('Playback paused'))
        else:
            return (False, res['message'])

    def playback_play(self):
        xml = self._send_receive(PLAY_CMD)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            self._device_sync_playback_status()
            return (True, _('Playback started'))
        else:
            return (False, res['message'])

    def playback_stop(self):
        xml = self._send_receive(STOP_CMD)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            self._device_sync_playback_status()
            return (True, _('Playback stopped'))
        else:
            return (False, res['message'])

    @contextmanager
    def _not_playing(self):
        """Helper that pauses if playback is in progress to allow skipping"""
        if self.playback_information.get('playback_state') == 'play':
            self._send_receive(PAUSE_CMD)
            try:
                yield
            finally:
                self._send_receive(PLAY_CMD)

        else:
            yield

    def playback_skip_forward(self):
        xml = None
        with self._not_playing():
            xml = self._send_receive(FORWARD_CMD)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            self._device_sync_playback_status()
            return (True, _('Playback skipped forward'))
        else:
            return (False, res['message'])
            return

    def playback_skip_backward(self):
        xml = None
        with self._not_playing():
            xml = self._send_receive(BACKWARD_CMD)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            self._device_sync_playback_status()
            return (True, _('Playback skipped backwards'))
        else:
            return (False, res['message'])
            return

    def playback_set_mode(self, mode):
        if mode in self.supported_modes['schedule_modes']:
            xml = self._send_receive(ENABLE_SCHEDULER_CMD if mode == 'schedule_on' else DISABLE_SCHEDULER_CMD)
            res = gdc_utils._process_response(xml, lambda t: None)
            if res['success']:
                if mode == 'schedule_on':
                    return (True, _('Schedule mode enabled'))
                else:
                    return (True, _('Schedule mode disabled'))
            else:
                return (False, res['message'])
        else:
            return (False, _('Unknown playback mode requested: %s') % mode)

    def get_schedule_id_list(self):
        output = {'error_messages': [],
         'schedule_id_list': []}
        success, error_message, schedules = self._get_schedules()
        if success:
            output['schedule_id_list'] = [ s['schedule_id'] for s in schedules ]
        else:
            output['error_messages'].append(error_message)
        return output

    def get_schedule_information(self, schedule_ids):
        output = {'error_messages': [],
         'schedule_info_dict': {}}
        success, error_message, schedules = self._get_schedules()
        if success:
            for schedule in schedules:
                if schedule['schedule_id'] in schedule_ids:
                    matched_playlist_uuid = None
                    if schedule['show_content_ver_id']:
                        for playlist in self.playlist_information:
                            if type(self.playlist_information[playlist]) is dict and self.playlist_information[playlist]['playlist']['content_version_id'] == schedule['show_content_ver_id']:
                                matched_playlist_uuid = playlist
                                break

                        if not matched_playlist_uuid:
                            continue
                    schedule_info = {'device_playlist_uuid': matched_playlist_uuid if matched_playlist_uuid else schedule['show_uuid'],
                     'start_time': parse_date(schedule['iso_date_time']),
                     'device_schedule_id': schedule['schedule_id']}
                    output['schedule_info_dict'][schedule['schedule_id']] = schedule_info

        else:
            output['error_messages'].append(error_message)
        return output

    def scheduling_delete(self, schedule_id):
        request = _build_command('CANCEL_SCHEDULE', children=[('schedule_uuid', schedule_id)])
        xml = self._send_receive(request)
        res = gdc_utils._process_response(xml, lambda t: None)
        if res['success']:
            return (True, _('Schedule deleted'))
        else:
            return (False, res['message'])

    def scheduling_schedule_playlist(self, playlist_id, timestamp):
        spl_title = self.playlist_information[playlist_id]['title']
        start_time = datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%dT%H:%M:%S')
        schedule_id = str(uuid.uuid4())
        matched_content_version_id = None
        for playlist in self.playlist_information:
            if type(self.playlist_information[playlist]) is dict and playlist == playlist_id:
                matched_content_version_id = self.playlist_information[playlist]['playlist']['content_version_id']
                break

        command = '<?xml version="1.0" encoding="UTF-8" ?><command version="2.1" cmd="PUT_SCHEDULE">'
        if not cfg.gdc_schedule_with_content_version_id():
            use_cvid = cfg.marker_clip_templating()
            if matched_content_version_id and use_cvid:
                command += '<schedule iso_date_time="{start_time}" show_content_version_id="{content_version_id}" show_playtype="test">{id}</schedule>'.format(start_time=start_time, content_version_id=matched_content_version_id, id=schedule_id)
            else:
                command += '<schedule iso_date_time="{start_time}" show_uuid="{playlist_uuid}" show_playtype="test">{id}</schedule>'.format(start_time=start_time, playlist_uuid=playlist_id, id=schedule_id)
            command += '</command>'
            request = _encode_command(command)
            xml = self._send_receive(request)
            res = gdc_utils._process_response(xml, lambda t: None)
            schedule_info = res['success'] and {'device_playlist_uuid': playlist_id,
             'start_time': timestamp,
             'device_schedule_id': schedule_id}
            return (True, _('Playlist %s has been scheduled for %s') % (spl_title, helper_methods.format_timestamp(timestamp)), schedule_info)
        else:
            return (False, res['message'], None)
            return

    def get_automation_list(self):
        output = {'error_messages': [],
         'automation_uuid_list': []}
        xml = self._send_receive(GET_AUTOMATION_LABELS)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value_list('automation_label'))
        if res['success']:
            output['automation_uuid_list'] = res['response']
        else:
            output['error_messages'].append(res['message'])
        return output

    def get_automation_information(self, automation_uuids):
        output = {'error_messages': [],
         'automation_info_dict': {}}
        xml = self._send_receive(GET_AUTOMATION_LABELS)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value_list('automation_label'))
        if res['success']:
            for automation_label in res['response']:
                output['automation_info_dict'][automation_label] = {}
                output['automation_info_dict'][automation_label]['name'] = automation_label
                output['automation_info_dict'][automation_label]['duration'] = 0
                output['automation_info_dict'][automation_label]['type'] = 'cue'

        else:
            output['error_messages'].append(res['message'])
        return output

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        if self.automation.has_key(cue_id):
            request = _build_command('TRIGGER_AUTOMATION', children=[('event_label', cue_id)])
            xml = self._send_receive(request)
            res = gdc_utils._process_response(xml, lambda t: None)
            if res['success']:
                return (True, _('Automation cue %s fired') % cue_id)
            else:
                return (False, res['message'])
        else:
            return (False, _('Cannot find automation cue %s on screen server') % cue_id)

    def is_ready_for_collect(self):
        """
        Overwrite this function if there are conditions which must be met
        before we can start log collection.
        @return
                bool
        """
        return self.playback_information['playback_state'] not in ('error', 'playback_unknown') and self.playback_information['playback_state'] != 'play'

    def get_logs(self, start_datetime):
        output = {'error_messages': [],
         'xml': None}
        start_date = start_datetime.strftime('%Y-%m-%d')
        start_time = start_datetime.strftime('%H:%M:%S')
        end_datetime = start_datetime + datetime.timedelta(days=1)
        end_date = end_datetime.strftime('%Y-%m-%d')
        end_time = end_datetime.strftime('%H:%M:%S')
        command = '<?xml version="1.0" encoding="UTF-8" ?><command version="2.1" cmd="GET_EVENT_LOGS_SMPTE">'
        command += '<log date="{start_date}" time="{start_time}" end_date="{end_date}" end_time="{end_time}"/>'.format(start_date=start_date, start_time=start_time, end_date=end_date, end_time=end_time)
        command += '</command>'
        request = _encode_command(command)
        xml = self._send_receive(request, timeout=120)
        res = gdc_utils._process_response(xml, gdc_utils._get_response_tag_value('response_text'))
        if res['success']:
            output['xml'] = res['response']
        else:
            output['error_messages'].append(res['message'])
        return output
# okay decompyling ./core/devices/sms/gdc/gdc.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:47 CST
