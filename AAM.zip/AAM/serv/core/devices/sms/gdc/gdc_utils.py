# 2017.08.13 21:49:48 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\gdc\gdc_utils.py
import logging
from serv.lib.utilities.utils import strip_urn
from serv.lib.utilities.xml_utils import iterparse_xml
from serv.lib.utilities.xml_utils import node_to_dict

def _process_response(response_xml, success_parser):
    """
    Check to see if the response has an OK or an error status.
    Parses the content with the success_parser function.
    On success returns: {
        'success': True,
        'message': 'ok',
        'response': <parsed response>
    }
    On error  returns: {
        'success': False,
        'message': <response error message>,
        'response': <parsed response>
    }
    """

    def loop_function(event, node, state, tree = None):
        if event == 'start' and node.tag == 'response':
            if node.get('status') == 'OK' and tree:
                state['response'] = success_parser(tree)
                state['message'] = 'ok'
                state['success'] = True
                node.clear()
        elif event == 'end' and node.tag == 'error':
            state['message'] = node.text
            state['success'] = False
            state['response'] = success_parser(tree)
            node.clear()
        return state

    try:
        return iterparse_xml(response_xml, loop_function, {})
    except Exception:
        logging.error('Invalid XML in GDC response:\n' + str(response_xml))
        raise

    return


def _get_response_tag_value(tag_name):
    """Extracts the value of a tag from an XML response.
    
    :param tag_name: The tag whose data is to be extracted.
    
    :returns: A function to pass to _process_response.
              More info available in that function docs.
    """

    def extractor(tree):
        """Iterates over an XML tree and extract the value of a tag.
        
        Please note that this function cannot guarantee what the state of the
        iterator will be afterword and you should not rely on it.
        """
        for event, node in tree:
            if event == 'end' and node.tag.endswith(tag_name):
                return node.text

        return None

    return extractor


def _get_response_tag_value_list(tag_name):
    """Extracts the value of all occurrences of a tag from an XML response.
    
    :param tag_name: The tag whose data is to be extracted.
    
    :returns: A function to pass to _process_response.
              More info available in that function docs.
    """

    def extractor(tree):
        """Iterates over an XML tree and extract the value of a tag.
        
        Please note that this function cannot guarantee what the state of the
        iterator will be afterword and you should not rely on it.
        """
        values = []
        for event, node in tree:
            if event == 'end':
                if node.tag.endswith(tag_name):
                    values.append(node.text)
                node.clear()

        return values

    return extractor


def _get_response_tag_attribute(tag_name, attribute_name, default = None):
    """Extracts the attribute of a tag from an XML response.
    
    :param tag_name: The tag from which the attribute is to be extracted.
    :param attribute_name: The attribute whose value is to be extracted.
    :param default: The default value to use for the attribute.
                    The default is only used if the tag is found.
    
    :returns: A function to pass to _process_response.
              More info available in that function docs.
    """

    def extractor(tree):
        """Iterates over an XML tree and extract the value of a tag.
        
        Please note that this function cannot guarantee what the state of the
        iterator will be afterword and you should not rely on it.
        """
        for event, node in tree:
            if event == 'start' and node.tag.endswith(tag_name):
                return node.get(attribute_name, default)

        return None

    return extractor


def _extract_server_info(tree):
    """Scans a GET_SERVER_INFO_CMD response.
    
    Extract the content of the following tags:
      * model
      * serial
      * server_time
    And the attributes of the 'version' tag.
    """
    result = {}
    for event, node in tree:
        if event == 'end':
            if node.tag == 'model':
                result['model'] = node.text
            elif node.tag == 'serial':
                result['serial'] = node.text
            elif node.tag == 'server_time':
                result['time'] = node.text
            elif node.tag == 'version':
                result['version'] = {'firmware': node.get('firmware'),
                 'os': node.get('os'),
                 'software': node.get('software')}
            node.clear()

    return result


def _extract_uuid_list_by_tag(tag_name):
    """Scans a GET_KDM_LIST_CMD response.
    
    Extract the content of the tags asset_uuid.
    """

    def extractor(tree):
        result = []
        for event, node in tree:
            if event == 'end':
                if node.tag.endswith(tag_name):
                    result.append(strip_urn(node.text))
                node.clear()

        return result

    return extractor


def _extract_cpl_uuid_list(tree):
    """Scans a GET_CPL_STATUS_LIST response.
    
    Extract the uuid attribute of the asset tags.
    """
    result = []
    for event, node in tree:
        if event == 'end':
            if node.tag.endswith('asset'):
                result.append(strip_urn(node.get('uuid')))
            node.clear()

    return result


def _extract_cpl_statuses(tree):
    result = {}
    current_uuid = None
    for event, node in tree:
        if event == 'start':
            if node.tag.endswith('asset'):
                current_uuid = strip_urn(node.get('uuid'))
                result[current_uuid] = {'ok': node.get('status') == 'OK',
                 'errors': []}
            elif node.tag.endswith('error'):
                result[current_uuid]['errors'].append(node.get('code'))
        elif event == 'end':
            node.clear()

    return result


def _parse_schedules(tree):
    result = {'success': True,
     'schedules': []}
    for event, node in tree:
        if event == 'end':
            if node.tag.endswith('schedule'):
                if node.text:
                    result['schedules'].append({'playlist_duration': node.get('playlist_duration', ''),
                     'iso_date_time': node.get('iso_date_time', ''),
                     'show_content_ver_id': strip_urn(node.get('show_content_ver_id', '')),
                     'show_playtype': node.get('show_playtype', ''),
                     'show_uuid': strip_urn(node.get('show_uuid', '')),
                     'schedule_id': strip_urn(node.text)})
                else:
                    logging.error('Error parsing the schedule. The schedule uuid was None')
                    result['message'] = _('Unknown error getting schedule information')
                    result['success'] = False
            node.clear()

    return result


def _extract_storage_info(tree):
    result = {}
    for event, node in tree:
        if event == 'start' and node.tag.endswith('storage'):
            result['total'] = int(node.get('total_space', 0))
            result['free'] = int(node.get('free_space', 0))
        elif event == 'end':
            node.clear()

    return result


def _extract_transfert_info(tree):
    result = {}
    for event, node in tree:
        if event == 'end':
            if node.tag == 'asset_uuid':
                asset_uuid = node.text if node.text else ''
                result['asset_uuid'] = strip_urn(asset_uuid)
            elif node.tag == 'asset_type':
                result['asset_type'] = node.text
            elif node.tag == 'asset_uri':
                result['asset_uri'] = node.text
            elif node.tag == 'status':
                result['status'] = node.text
            elif node.tag == 'description':
                result['description'] = node.text
            elif node.tag == 'size':
                result['total_size'] = int(node.get('total', 0))
                result['transferred_size'] = int(node.get('transferred', 0))
            node.clear()

    return result


def _extract_errors(tree):
    errors = []
    in_error_list = False
    for event, node in tree:
        if event == 'start':
            if node.tag.endswith('error_list'):
                in_error_list = True
            elif in_error_list and node.tag.endswith('error'):
                errors.append(node.attrib)
        if event == 'end' and node.tag.endswith('error_list'):
            return errors

    return errors


def _extract_status(tree):
    result = {}
    for event, node in tree:
        if event == 'start':
            if node.tag.endswith('status'):
                result['state'] = node.get('state')
                result['error'] = node.get('error_description')
            elif node.tag.endswith('show_position'):
                result['show_played'] = int(node.get('played_duration'))
                result['show_total'] = int(node.get('total_duration'))
            elif node.tag.endswith('cpl_position'):
                result['cpl_played'] = int(node.get('played_duration'))
                result['cpl_total'] = int(node.get('total_duration'))
                result['cpl_index'] = node.get('cpl_index')
        if event == 'end':
            if node.tag.endswith('show_uuid'):
                result['show_uuid'] = strip_urn(node.text)
            elif node.tag.endswith('cpl_uuid'):
                result['cpl_uuid'] = strip_urn(node.text)
            node.clear()

    return result
# okay decompyling ./core/devices/sms/gdc/gdc_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:48 CST
