# 2017.08.13 21:49:52 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\imax\imax_handlers.py
from array import array
from struct import unpack
from serv.lib.utilities.utils import uuid_bytes_2_canonical, byte_array_2_short, uuid_canonical_2_bytes, byte_array_2_word, word_2_byte_array, byte_array_2_long, long_2_byte_array, byte_array_2_little_endian_long, ip_to_little_endian_word, short_2_byte_array, byte_array_2_little_endian_word

def request_handler(data):
    raise Exception('Not implemented request handler')


def response_handler(data):
    """ Handles parsing only response data from a response """
    return {'response': ord(data[-1:])}


def uuid_request_handler(uuid):
    """
    Handles the creation of a header info for an UUID info request:
        e.g spl_id -- the spl uuid in canonical form
    """
    return uuid_canonical_2_bytes(uuid)


def get_uuid_list_response_handler(data):
    """ Handles the response data for an SPL or CPL List request """
    item_count = byte_array_2_word(data[0:4])
    item_size = byte_array_2_word(data[4:8])
    position = 8
    uuid_list = []
    for item in xrange(0, item_count):
        spl_id = uuid_bytes_2_canonical(data[position:position + item_size])
        position = position + item_size
        uuid_list.append(spl_id)

    return {'response': ord(data[-1:]),
     'list': uuid_list}


def spl_get_xml_response_handler(data):
    """ Handles the response data for the XML of an SPL on the server """
    return {'xml': data[:-1],
     'response': ord(data[-1:])}


def spl_get_jump_request_handler(duration):
    """ Handles the jump forward and jump backwards request """
    return word_2_byte_array(duration)


def spl_get_status_request_handler(params):
    """
    flags - nothing but they need it anyways?
    """
    return array('B', word_2_byte_array(int(params)))


def spl_get_status_response_handler(data):
    """ Handles the current playback status of the Doremi server """
    return {'playback_state': {1: 'stop',
                        2: 'play',
                        3: 'pause'}.get(ord(data[:1]), 'error'),
     'spl_id': uuid_bytes_2_canonical(data[1:17]),
     'spl_position': byte_array_2_word(data[17:21]),
     'spl_duration': byte_array_2_word(data[21:25]),
     'cpl_id': uuid_bytes_2_canonical(data[25:41]),
     'event_id': uuid_bytes_2_canonical(data[41:57]),
     'element_id': uuid_bytes_2_canonical(data[57:73]),
     'element_position': byte_array_2_word(data[73:77]),
     'element_duration': byte_array_2_word(data[77:81]),
     'response': ord(data[-1])}


def get_schedule_list_request_handler(params):
    """
    time_begin_timestamp - unix timestamp
    time_end_timestamp   - unix timestamp
    """
    time_begin_timestamp, time_end_timestamp = params
    start_time_bytes = long_2_byte_array(int(time_begin_timestamp))
    end_time_bytes = long_2_byte_array(int(time_end_timestamp))
    byte_array = []
    byte_array.extend(start_time_bytes)
    byte_array.extend(end_time_bytes)
    return array('B', byte_array)


def get_schedule_list_response_handler(data):
    """ Handles the response data for a schedule list request """
    schedule_list = []
    for pos in xrange(0, len(data[:-1]), 8):
        schedule_list.append(byte_array_2_little_endian_long(data[pos:pos + 8]))

    return {'schedule_list': schedule_list,
     'response': ord(data[-1:])}


def get_time_utc_request_handler(data):
    """
    1 = clockid_system - DCP2000 OS Time
    """
    return [1]


def get_time_utc_response_handler(data):
    """
        returns a dictionary containing
                    utc_time : time in seconds since jan1 1970
                    response : the response code from the server
    """
    error = False
    utc_bytes = data[0:8]
    if len(utc_bytes) == 8:
        utc_time = byte_array_2_long(utc_bytes)
    else:
        utc_time = -1
    if utc_time == 0:
        error = "The server's clock is not configured"
    elif utc_time == -1:
        error = 'Could not retrieve the clock value (critical)'
    response = {'utc_time': utc_time,
     'response': ord(data[-1:])}
    if error:
        response['error'] = error
    return response


def get_device_status_response_handler(data):
    """
    Parse Device status batch
    """
    item_count = byte_array_2_word(data[0:4])
    position = 8
    device_status_properties = []
    for item in xrange(0, item_count):
        device_status_name = data[position:position + 64]
        position += 64
        device_status_value = data[position:position + 128]
        position += 128
        device_status_properties.append({device_status_name: device_status_value})

    return {'status': device_status_properties,
     'response': ord(data[-1])}


def get_cpl_info_response_handler(data):
    """ Handles the response data for an CPL on the server """
    info = {'id': uuid_bytes_2_canonical(data[:16]),
     'storage': ord(data[16]),
     'content_title_text': data[17:145].split('\x00')[0],
     'content_kind': ord(data[145]),
     'duration': byte_array_2_word(data[146:150]),
     'edit_rate_a': byte_array_2_word(data[150:154]),
     'edit_rate_b': byte_array_2_word(data[154:158]),
     'picture_encoding': ord(data[158]),
     'picture_width': byte_array_2_short(data[159:161]),
     'picture_height': byte_array_2_short(data[161:163]),
     'picture_encryption': ord(data[163]),
     'sound_encoding': ord(data[164]),
     'sound_channel_count': ord(data[165]),
     'sound_quantization_bits': ord(data[166]),
     'sound_encryption': ord(data[167]),
     'response': ord(data[-1])}
    num_items = byte_array_2_word(data[168:172])
    item_length = byte_array_2_word(data[172:176])
    position = 176
    crypto_key_id_list = []
    for item in xrange(0, num_items):
        cpl_id = uuid_bytes_2_canonical(data[position:position + item_length])
        position = position + item_length
        crypto_key_id_list.append(cpl_id)

    info['crypto_key_id_batch'] = {'number_of_items': num_items,
     'item_length': item_length,
     'list': crypto_key_id_list}
    return info


def get_kdm_info_response_handler(data):
    """ Handles the response data from a GET KDM INFO request"""
    response_data = {'kdm_id': uuid_bytes_2_canonical(data[0:16]),
     'cpl_id': uuid_bytes_2_canonical(data[16:32]),
     'not_valid_before': str(byte_array_2_long(data[32:40])),
     'not_valid_after': str(byte_array_2_long(data[40:48])),
     'response': ord(data[-1:])}
    num_items = byte_array_2_word(data[48:52])
    item_length = byte_array_2_word(data[52:56])
    position = 56
    key_id_list = []
    for item in xrange(0, num_items):
        key_id = uuid_bytes_2_canonical(data[position:position + item_length])
        position = position + item_length
        key_id_list.append(key_id)

    response_data['key_id_batch'] = {'number_of_items': num_items,
     'item_length': item_length,
     'list': key_id_list}
    return response_data


def get_schedule_info_response_handler(data):
    """ Handles the response data for a get_schedule_info
        returns
                {
                    id                  - int64
                    spl_id              - UUID string
                    time_begin          - string, YYYY-MM-DD HH:MM
                    time_end            - string, YYYY-MM-DD HH:MM
                    status              - string, 'InDatabase' | 'SuccessfullyScheduled' | 'ScheduleFailed'
                    annotation_text     - string
                    response            - int
    """
    info = {'id': byte_array_2_long(data[:8]),
     'spl_id': uuid_bytes_2_canonical(data[8:24]),
     'status': {'\x00': 'InDatabase',
                '\x01': 'SuccessfullyScheduled',
                '\x02': 'ScheduleFailed'}.get(data[40], 'Error'),
     'annotation_text': data[41:169].split('\x00')[0],
     'response': ord(data[-1]),
     'time_begin': byte_array_2_long(data[24:32]),
     'time_end': byte_array_2_long(data[32:40])}
    return info


def get_schedule_info_request_handler(schedule_id):
    byte_array = long_2_byte_array(int(schedule_id))
    return array('B', byte_array)


def get_scheduler_response_handler(data):
    return {'enabled': {0: False,
                 1: True}.get(ord(data[0]), 'Error'),
     'response': ord(data[-1])}


def get_loop_mode_spl_response_handler(data):
    """ Handles the response data for the current SPL loop mode """
    return {'loop_mode': ord(data[0]),
     'response': ord(data[-1:])}


def retrieve_cpl_response_handler(data):
    """ Handles the response data for an CPL on the server """
    info = {'data': data[:len(data) - 1],
     'response': ord(data[-1])}
    return info


def retrieve_kdm_response_handler(data):
    """Retrieves the KDM XML from the response data"""
    return {'xml': data[0:-1].split('\x00')[0],
     'response': ord(data[-1:])}


def validate_item_request_handler(params):
    """ Handles the request parameters for a CPL or SPL validation check
    
        Arguments:  params - a tuple consisting of:
                    item_uuid:  the SPL or CPL UUID of the item being validated
                    time:        UTC Time in ISO8601 format
                                E.g. 2008-12-17T15:25:49+00:00
                    level:        0..N
    
    """
    item_uuid, time, level = params
    uuid_bytes = uuid_canonical_2_bytes(item_uuid)
    time_bytes = [ ord(d) for d in time.ljust(32, '\x00') ]
    validation_level_bytes = word_2_byte_array(int(level))
    byte_array = []
    byte_array.extend(uuid_bytes)
    byte_array.extend(time_bytes)
    byte_array.extend(validation_level_bytes)
    return array('B', byte_array)


def validate_cpl_response_handler(data):
    """ Handles the response data for a CPL validation """
    response_data = {'result': ord(data[0:1]),
     'error_code': ord(data[1:2]),
     'response': ord(data[-1:])}
    len_error_msgs = len(data) - 3
    if len_error_msgs > 0:
        response_data['error_msgs'] = data[2:2 + len_error_msgs].split('\x00')[0]
    else:
        response_data['error_msgs'] = ''
    return response_data


def get_macro_cue_info_response_handler(data):
    """
        MacroCueId    - 16 bytes
        Macro Name - Null terminated UTF-8 string - 64 bytes
        Macro duration - 4 bytes (UInt32)
        Response:
    """
    return {'id': uuid_bytes_2_canonical(data[:16]),
     'name': data[16:80].split('\x00')[0],
     'duration': byte_array_2_word(data[80:84]),
     'response': ord(data[-1:])}


def get_data_disk_space_usage_response_handler(data):
    """ Handles the response data returned by the get disk space usage command. """
    return {'total_size': str(byte_array_2_long(data[:8])),
     'used': str(byte_array_2_long(data[8:16])),
     'available': str(byte_array_2_long(data[16:24])),
     'response': ord(data[-1:])}


def get_product_certificate_request_handler(cert_type):
    """
    'cert_type' identifys the certificate type
        0 - SMPTE
        1 - MPEG Interop Group
    """
    if cert_type in (0, 1):
        return [cert_type]
    raise ValueError('Invalid cert type [%s]' % str(cert_type))


def get_product_certificate_response_handler(data):
    return {'certificate': data[:-1].replace('\x00', ''),
     'response': ord(data[-1:])}


def get_product_information_response_handler(data):
    """ Returns Doremi server information """
    return {'serial': data[:16].split('\x00')[0],
     'response': ord(data[-1:])}


def validate_spl_response_handler(data):
    """ Handles the response data for a SPL validation """
    return {'result': ord(data[0:1]),
     'error_code': ord(data[1:2]),
     'cpl_id': uuid_bytes_2_canonical(data[2:18]),
     'error_msgs': data[18:-1].split('\x00')[0],
     'response': ord(data[-1:])}


def add_schedule_request_handler(data):
    """
    Handles the response data for an add schedule request
    """
    spl_id, time_begin, display_name = data
    time_begin_bytes = long_2_byte_array(int(time_begin))
    spl_id_bytes = uuid_canonical_2_bytes(spl_id)
    display_name = display_name.ljust(128, '\x00')
    display_name_bytes = unicode(display_name, 'UTF-8').encode('UTF-8')[0:128]
    byte_array = []
    byte_array.extend(spl_id_bytes)
    byte_array.extend(time_begin_bytes)
    byte_array.extend([ ord(d) for d in display_name_bytes ])
    return array('B', byte_array)


def add_schedule_response_handler(data):
    """ Handles the response data for schedule add request """
    schedule_id = byte_array_2_long(data[:8])
    error_code = data[9]
    error = ''
    if error_code == '\x01':
        error = 'Schedule overlapped'
    elif error_code == '\x02':
        error = 'Scheduled Time passed'
    return {'schedule_id': schedule_id,
     'error': error,
     'response': ord(data[-1:])}


def delete_schedule_list_request_handler(schedule_id):
    """ Handles the response data for a delete schedule list request """
    byte_array = []
    schedule_id = int(schedule_id)
    byte_array.extend(long_2_byte_array(schedule_id))
    return array('B', byte_array)


def store_spl_request_handler(data):
    """
        Returns a byte array containing the XML SPL data
    """
    byte_array = []
    byte_array.extend([ ord(d) for d in data ])
    return array('B', byte_array)


def set_scheduler_request_handler(enabled):
    if enabled == True or enabled == 'true':
        return [1]
    if enabled == False or enabled == 'false':
        return [0]
    raise Exception('"Enabled" parameter to SetSchedulerEnable  should be boolean')


def loop_mode_spl_request_handler(loop_mode):
    """ Handles the loop mode Request parameter """
    return array('B', [loop_mode])


def store_kdm_request_handler(data):
    """
        Returns a byte array containing the XML KDM data
    """
    byte_array = []
    byte_array.extend([ ord(d) for d in data ])
    return array('B', byte_array)


def get_sm_log_request_handler(params):
    """
    Handles a sm log request - hardcoded to only return
    SMPTE430-4/SMPTE 430-5 logs (strict mode=2)
    
    'Params' is a tuple that must contain the following parameters:
                event_id_min  - positive  integer
                event_id_max  - positive integer
                start_timestamp - posix timestamp integer
                end_datetime  - posix timestamp integer
                cpl_id - 36 chars, e.g. 550e8400-e29b-41d4-a716-446655440000
                kdm_id - 36 chars, e.g. 550e8400-e29b-41d4-a716-446655440000
                strict_mode = 0  - all logs
                              1  - strict log
                              2  - smpte logs
    
    These values should be set to None if they they are not specified
    
    """
    event_id_min, event_id_max, start_timestamp, end_timestamp, cpl_id, kdm_id, strict_mode = params
    if strict_mode == 2:
        smb = '\x02'
    elif strict_mode == 1:
        smb = '\x01'
    else:
        smb = '\x00'
    strict_mode_byte_array = unpack('>B', smb)
    filter_mask = 0
    if event_id_min != None and event_id_min != '' and str(event_id_min).isdigit():
        event_id_min = int(event_id_min)
        filter_mask = filter_mask | 1
    else:
        event_id_min = 0
    if event_id_max != None and event_id_max != '' and str(event_id_max).isdigit():
        event_id_max = int(event_id_max)
        filter_mask = filter_mask | 2
    else:
        event_id_max = 0
    if start_timestamp != None:
        filter_mask = filter_mask | 4
    else:
        start_timestamp = 0
    if end_timestamp != None:
        filter_mask = filter_mask | 8
    else:
        end_timestamp = 0
    if cpl_id != None and len(cpl_id) == 36:
        filter_mask = filter_mask | 16
    else:
        cpl_id = '00000000000000000000000000000000'
    if kdm_id != None and len(kdm_id) == 36:
        filter_mask = filter_mask | 32
    else:
        kdm_id = '00000000000000000000000000000000'
    filter_mask_byte = [filter_mask]
    event_id_min_bytes = word_2_byte_array(int(event_id_min))
    event_id_max_bytes = word_2_byte_array(int(event_id_max))
    min_time_bytes = long_2_byte_array(int(start_timestamp))
    max_time_bytes = long_2_byte_array(int(end_timestamp))
    cpl_id_bytes = uuid_canonical_2_bytes(cpl_id)
    kdm_id_bytes = uuid_canonical_2_bytes(kdm_id)
    byte_array = []
    byte_array.extend(strict_mode_byte_array)
    byte_array.extend(filter_mask_byte)
    byte_array.extend(event_id_min_bytes)
    byte_array.extend(event_id_max_bytes)
    byte_array.extend(min_time_bytes)
    byte_array.extend(max_time_bytes)
    byte_array.extend(cpl_id_bytes)
    byte_array.extend(kdm_id_bytes)
    return array('B', byte_array)


def get_sm_log_response_handler(data):
    """
    Retrieves the SMPTE Compliant (signed XML) security logh
    of the server.
    
    Returns
            error_code    -  1 btye (0 success, 1 Failure)
            xml            -  the SM Log
            Response    -  response code 0 or 1
    """
    return {'error_code': ord(data[0]),
     'xml': data[1:-1],
     'response': 0}


def ingest_get_status_response_handler(data):
    """
    Parses the supplied data and returns a dictionary containing:
    
        Response               -- the server response code
        IsRunning              -- bool (1 == ingest in progress else 0)
        ErrorCount               -- Number of error in all process
        WarningCount           -- number of warnings in all processes
        LastEventID              -- Last eventID generated by the ingest
        CurrentProcessPercent -- Current process percent ??
        AllProcessesPerecent  -- Global ingest percent including all
                                  ingest steps
        CurrentProcessDescription -- Current process step name
    """
    return {'IsRunning': ord(data[0:1]),
     'ErrorCount': byte_array_2_short(data[1:3]),
     'WarningCount': byte_array_2_short(data[3:5]),
     'LastEventID': byte_array_2_word(data[5:9]),
     'CurrentProcessPercent': ord(data[9:10]),
     'AllProcessesPerecent': ord(data[10:11]),
     'CurrentProcessDescription': data[11:-1].split('\x00')[0],
     'response': ord(data[-1:])}


def ingest_get_event_info_response_handler(data):
    """
    Returns a dictionary of:
        Response    --  the server response code
        event_id    --  32bit int id of the event
        event_text    --  Text description of the event
    """
    return {'event_id': byte_array_2_word(data[:4]),
     'event_text': data[4:-1].split('\x00')[0],
     'response': ord(data[-1])}


def ingest_get_event_info_request_handler(event_id):
    """
    Returns a byte array wrapping the specified event id
    """
    return word_2_byte_array(int(event_id))


def ingest_remote_packing_list_request_handler(params):
    """
    ftp_ip     - string representation of the ftp server in
                 dotted quad notation
    ftp_port - string representation of the ftp server port
    ftp_username - 16 byte utf8 string
    ftp_password - 16 byte utf8 string
    path         - variable
    """
    ftp_ip, ftp_port, username, password, ftp_path = params
    ip = word_2_byte_array(ip_to_little_endian_word(ftp_ip))
    port = short_2_byte_array(int(ftp_port))
    login = [ ord(d) for d in username.ljust(16, '\x00') ]
    pwd = [ ord(d) for d in password.ljust(16, '\x00') ]
    path = [ ord(d) for d in ftp_path + '\x00' ]
    byte_array = []
    byte_array.extend(ip)
    byte_array.extend(port)
    byte_array.extend(login)
    byte_array.extend(pwd)
    byte_array.extend(path)
    return array('B', byte_array)


def ingest_get_event_list_response_handler(data):
    """
    Returns a dictionary of:
        response    --  the response code of 0
        event_list    -- a array of event id's (int32)
    """
    item_count = len(data[:-1]) / 4
    position = 0
    event_list = []
    for item in xrange(0, item_count):
        event_id = byte_array_2_word(data[position:position + 4])
        position += 4
        event_list.append(event_id)

    return {'response': ord(data[-1:]),
     'event_list': event_list}


def power_request_handler(command):
    if command not in (0, 1):
        raise Exception('Possible values for the power command are 0 or 1')
    return [command]


def power_status_request_handler(command):
    """
    Gets the status of a previous power command.
    @param command:
    @return: An array containing the command
    """
    if command not in (0, 1):
        raise Exception('Possible values for the power command are 0 or 1')
    return [command]


def power_status_response_handler(data):
    """
    Handles the response for checking the status of a previous
    power command
    @param data:
    @return: Dict containing IsRunning 0 | 1
    which determines if previous power UP/DOWN command is still running
    """
    return {'is_running': ord(data[:1]),
     'cur_proc_percent': ord(data[1:2]),
     'error': ord(data[2:3]),
     'error_description': data[3:128].split('\x00')[0],
     'response': ord(data[-1:])}


def get_lamp_status_request_handler(command):
    """
    Gets the lamp status of a projector.
    @param command:
    @return: An array containing the command
    """
    if command not in (0, 1):
        raise Exception('Possible values for projector are 0 or 1')
    return [command]


def get_lamp_status_response_handler(data):
    """
    Handles the response for checking the lamp status of a projector.
    @param command:
    @return: An array containing the command
    """
    return {'lamp_status': ord(data[:1]),
     'response': ord(data[-1:])}
# okay decompyling ./core/devices/sms/imax/imax_handlers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:53 CST
