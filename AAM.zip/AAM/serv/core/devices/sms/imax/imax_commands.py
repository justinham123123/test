# 2017.08.13 21:49:51 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\imax\imax_commands.py
"""
Implementations of the IMAX remote API commands
"""
from serv.core.devices.sms.imax import imax_handlers
ADD_UPDATE_MACRO_CUE_TO_FILE = (imax_handlers.request_handler, imax_handlers.response_handler)
CPL_DELETE = ((1, 5, 0),
 (1, 6, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.response_handler)
CPL_GET_INFO = ((1, 3, 0),
 (1, 4, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.get_cpl_info_response_handler)
CPL_GET_LIST = ((1, 1, 0),
 (1, 2, 0),
 None,
 imax_handlers.get_uuid_list_response_handler)
CPL_RETRIEVE = ((1, 7, 0),
 (1, 8, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.retrieve_cpl_response_handler)
CPL_VALIDATE = ((1, 11, 0),
 (1, 12, 0),
 imax_handlers.validate_item_request_handler,
 imax_handlers.validate_cpl_response_handler)
CONFIGURATION_FILE_GET = ((5, 19, 0),
 (5, 20, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
CONFIGURATION_FILE_SET = ((5, 21, 0),
 (5, 22, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
DELETE_MACRO_CUE_FROM_FILE = (imax_handlers.request_handler, imax_handlers.response_handler)
DISK_SPACE_GET = ((8, 1, 0),
 (8, 2, 0),
 None,
 imax_handlers.get_data_disk_space_usage_response_handler)
GET_CURRENT_IE_BYPASS_MODE = ((18, 11, 0),
 (18, 12, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_DAILY_CAL_STATUS = ((16, 1, 0),
 (16, 2, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_LAMP_STATUS = ((17, 3, 0),
 (17, 4, 0),
 imax_handlers.get_lamp_status_request_handler,
 imax_handlers.get_lamp_status_response_handler)
GET_MACRO_CUE_INFO = ((10, 3, 0),
 (10, 4, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.get_macro_cue_info_response_handler)
GET_MACRO_CUE_INFO_FROM_FILE = ((10, 13, 0),
 (10, 14, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_MACRO_CUE_LIST = ((10, 1, 0),
 (10, 2, 0),
 None,
 imax_handlers.get_uuid_list_response_handler)
GET_POWER_CONTROL_PROCESS_STATUS = ((15, 3, 0),
 (15, 4, 0),
 imax_handlers.power_status_request_handler,
 imax_handlers.power_status_response_handler)
GET_SMS_CERTIFICATE = ((5, 31, 0),
 (5, 32, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_SMS_DEVICES_COMM_STATUS = ((18, 3, 0),
 (18, 4, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_SMS_DEVICES_STATUS = ((18, 5, 0),
 (18, 6, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_SMS_DEVICES_VERSION = ((18, 7, 0),
 (18, 8, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_SMS_SERVER_CERTIFICATE = ((5, 3, 0),
 (5, 4, 0),
 imax_handlers.get_product_certificate_request_handler,
 imax_handlers.get_product_certificate_response_handler)
CERT_TYPE_JP2K_CURRENT = 0
CERT_TYPE_MPEG2 = 1
GET_SMS_SERVER_SERIAL_NUMBER = ((5, 1, 0),
 (5, 2, 0),
 None,
 imax_handlers.get_product_information_response_handler)
GET_SMS_SYSTEM_STATE = ((18, 1, 0),
 (18, 2, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_SPL_INFO = ((3, 3, 0),
 (3, 4, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
GET_SPL_LIST = ((3, 1, 0),
 (3, 2, 0),
 None,
 imax_handlers.get_uuid_list_response_handler)
GET_SYSTEM_ERROR_WARNING_MSG = ((18, 9, 0),
 (18, 10, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
INGEST_CANCEL = ((7, 7, 0),
 (7, 8, 0),
 None,
 imax_handlers.response_handler)
INGEST_GET_EVENT_INFO = ((7, 3, 0),
 (7, 4, 0),
 imax_handlers.ingest_get_event_info_request_handler,
 imax_handlers.ingest_get_event_info_response_handler)
INGEST_GET_EVENT_LIST = ((7, 1, 0),
 (7, 2, 0),
 None,
 imax_handlers.ingest_get_event_list_response_handler)
INGEST_GET_STATUS = ((7, 9, 0),
 (7, 10, 0),
 None,
 imax_handlers.ingest_get_status_response_handler)
INGEST_REMOTE_PACKAGING_LIST = ((7, 5, 0),
 (7, 6, 0),
 imax_handlers.ingest_remote_packing_list_request_handler,
 imax_handlers.response_handler)
KDM_DELETE = ((2, 5, 0),
 (2, 6, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.response_handler)
KDM_GET_INFO = ((2, 3, 0),
 (2, 4, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.get_kdm_info_response_handler)
KDM_GET_LIST = ((2, 1, 0),
 (2, 2, 0),
 None,
 imax_handlers.get_uuid_list_response_handler)
KDM_RETRIEVE = ((2, 7, 0),
 (2, 8, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.retrieve_kdm_response_handler)
KDM_STORE = ((2, 9, 0),
 (2, 10, 0),
 imax_handlers.store_kdm_request_handler,
 imax_handlers.response_handler,
 90)
LAMP_CONTROL = ((17, 1, 0),
 (17, 2, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
POWER_CONTROL_COMMAND = ((15, 1, 0),
 (15, 2, 0),
 imax_handlers.power_request_handler,
 imax_handlers.response_handler)
SM_GET_LOG = ((12, 1, 0),
 (12, 2, 0),
 imax_handlers.get_sm_log_request_handler,
 imax_handlers.get_sm_log_response_handler,
 300)
SMS_CONFIGURATION_GET = ((5, 27, 0),
 (5, 28, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SMS_CONFIGURATION_SET = ((5, 29, 0),
 (5, 30, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SMS_GET_LOG = ((12, 3, 0),
 (12, 4, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SPL_COPY = ((3, 45, 0),
 (3, 46, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SPL_DELETE = ((3, 5, 0),
 (3, 6, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.response_handler)
SPL_GET_ELEMENTS_STATUS = ((3, 43, 0),
 (3, 44, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SPL_GET_LOOP_MODE = ((3, 35, 0),
 (3, 36, 0),
 None,
 imax_handlers.get_loop_mode_spl_response_handler)
SPL_GET_STATUS = ((3, 27, 0),
 (3, 28, 0),
 imax_handlers.spl_get_status_request_handler,
 imax_handlers.spl_get_status_response_handler)
SPL_LOAD = (imax_handlers.request_handler, imax_handlers.response_handler)
SPL_LOAD_BY_UUID = ((3, 9, 0),
 (3, 10, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.response_handler)
SPL_RECALL = ((3, 29, 0),
 (3, 30, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.spl_get_xml_response_handler)
SPL_SAVE = ((3, 31, 0),
 (3, 32, 0),
 imax_handlers.store_spl_request_handler,
 imax_handlers.response_handler)
SPL_SET_LOOP_MODE = ((3, 25, 0),
 (3, 26, 0),
 imax_handlers.loop_mode_spl_request_handler,
 imax_handlers.response_handler)
SPL_STOP_AND_REWIND = (imax_handlers.request_handler, imax_handlers.response_handler)
SPL_VALIDATE = ((3, 37, 0),
 (3, 38, 0),
 imax_handlers.validate_item_request_handler,
 imax_handlers.validate_spl_response_handler)
SCHEDULE_ADD = ((4, 1, 0),
 (4, 2, 0),
 imax_handlers.add_schedule_request_handler,
 imax_handlers.add_schedule_response_handler)
SCHEDULE_DELETE = ((4, 3, 0),
 (4, 4, 0),
 imax_handlers.delete_schedule_list_request_handler,
 imax_handlers.response_handler)
SCHEDULE_GET_CURRENT = ((4, 9, 0),
 (4, 10, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SCHEDULE_GET_INFO = ((4, 7, 0),
 (4, 8, 0),
 imax_handlers.get_schedule_info_request_handler,
 imax_handlers.get_schedule_info_response_handler)
SCHEDULE_GET_LIST = ((4, 5, 0),
 (4, 6, 0),
 imax_handlers.get_schedule_list_request_handler,
 imax_handlers.get_schedule_list_response_handler)
SCHEDULE_GET_NEXT = ((4, 11, 0),
 (4, 12, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SCHEDULER_GET_STATUS = ((4, 15, 0),
 (4, 16, 0),
 None,
 imax_handlers.get_scheduler_response_handler)
SCHEDULER_SET_ENABLE = ((4, 13, 0),
 (4, 14, 0),
 imax_handlers.set_scheduler_request_handler,
 imax_handlers.response_handler)
SECURE_CONTENT_GET_LOCK = ((5, 15, 0),
 (5, 16, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SHOW_EJECT = ((3, 15, 0),
 (3, 16, 0),
 None,
 imax_handlers.response_handler)
SHOW_JUMP_BACKWARD = ((3, 23, 0),
 (3, 24, 0),
 imax_handlers.spl_get_jump_request_handler,
 imax_handlers.response_handler)
SHOW_JUMP_FORWARD = ((3, 21, 0),
 (3, 22, 0),
 imax_handlers.spl_get_jump_request_handler,
 imax_handlers.response_handler)
SHOW_OUTPUT_GET = ((20, 3, 0),
 (20, 4, 0),
 imax_handlers.request_handler,
 imax_handlers.response_handler)
SHOW_OUTPUT_SET = (imax_handlers.request_handler, imax_handlers.response_handler)
SHOW_PAUSE = ((3, 13, 0),
 (3, 14, 0),
 None,
 imax_handlers.response_handler)
SHOW_PLAY = ((3, 11, 0),
 (3, 12, 0),
 None,
 imax_handlers.response_handler)
SHOW_SKIP_BACKWARD = ((3, 19, 0),
 (3, 20, 0),
 None,
 imax_handlers.response_handler)
SHOW_SKIP_FORWARD = ((3, 17, 0),
 (3, 18, 0),
 None,
 imax_handlers.response_handler)
SHOW_SKIP_TO_EVENT = ((3, 33, 0),
 (3, 34, 0),
 imax_handlers.uuid_request_handler,
 imax_handlers.response_handler)
SWITCH_AUDIO_SOURCE = (imax_handlers.request_handler, imax_handlers.response_handler)
UTC_GET_TIME = ((5, 7, 0),
 (5, 8, 0),
 imax_handlers.get_time_utc_request_handler,
 imax_handlers.get_time_utc_response_handler)
UTC_SET_TIME = (imax_handlers.request_handler, imax_handlers.response_handler)
# okay decompyling ./core/devices/sms/imax/imax_commands.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:52 CST
