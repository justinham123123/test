# 2017.08.13 21:48:26 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\camera.py
import abc
from serv.core.devices.base.monitoring import Monitor

class Camera(Monitor):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def get_live_image(self):
        raise NotImplementedError

    def __init__(self, id, device_info):
        super(Camera, self).__init__(id, device_info)
        self._current_image = None
        return

    def get_stored_image(self):
        return self._current_image

    def _store_image(self, image):
        self._current_image = image

    def store_internal_image(self):
        """
        Calls the camera to pull an image and then store it in the db
        """
        self._current_image = self.get_live_image()

    def store_external_image(self, image):
        """
        Stores an image that has been pushed to Core for this camera
        """
        self._current_image = image
# okay decompyling ./core/devices/base/camera.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:26 CST
