# 2017.08.13 21:48:33 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\mount_point.py
import abc
import datetime
import logging
import os
import re
import shutil
import sys
import tarfile
import threading
import time
import traceback
import uuid
import zipfile
from serv.core.devices.base.content import Content
from serv.configuration import cfg
from serv.configuration.constants import MOUNT_POINT_SCAN_DEPTH
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.dcp.dcp import DCP
from serv.lib.dcinema.dcp.helpers import _folder_is_package
from serv.lib.dcinema.parsers.parsers import parse_kdm, parse_cpl, parse_content_title_text, parse_pack_xml
from serv.lib.dcinema.parsers.parsers import parse_pos
from serv.lib.utilities import helper_methods
from serv.lib.utilities.action import SyncAction

def _(text):
    return text


def ignore_hidden_walk(handler, path):
    for dirpath, dirnames, filenames in handler.walk(u'' + path):
        dirnames[:] = [ dir for dir in dirnames if not dir.startswith('.') if not dir.startswith('$') ]
        yield (dirpath, dirnames, filenames)


class MountPoint(Content):
    __metaclass__ = abc.ABCMeta

    def __init__(self, id, device_info):
        super(MountPoint, self).__init__(id, device_info)
        self.sync_lock = threading.Lock()
        self.show_expired_kdms = False
        self.processed_files = {'stamp': time.time(),
         'files': {}}
        self.drive_storage = {'cpls': {},
         'kdms': {},
         'last_updated': None}
        self._reset_content_report_storage()
        return

    def _reset_content_report_storage(self):
        self.content_report_storage = {'stats': {'kdms': {'success': 0,
                            'expired': 0,
                            'faulty': 0},
                   'dcps': {'all': 0,
                            'success': 0,
                            'faulty': 0,
                            'with_faulty_cpls': 0},
                   'packs': {'success': 0,
                             'expired': 0,
                             'faulty': 0}}}

    @abc.abstractmethod
    def retrieve_all_contents(self):
        """
        Scans the mount for cpls, kdms, pos files and adpacks and returns these with all details in the below format.
        we are not scanning on the fly, as this can be quite inefficient when large mount points are provided.
        by default the sync mount point command is invoked when a mount point is first connected only. and subsequent scans require user action
        some mount points with autosync enabled will attempt to keep themselves up to date.
        
        @return
        dict
            content - {
                content_uuid: {
                                content_title_text  STRING
                                content_kind        INT
                                edit_rate           [INT, INT]
                                encrypted           BOOL
                                subtitled           BOOL
                                is_3d               BOOL
                                duration            INT in seconds
                                storage             INT
                                create_date         DATETIME
                                is_topup            BOOLEAN
                                source              STRING
                                xml                 STRING
                                parsed_info         DICT
                                validation_info     : {
                                    validation_code - Integer
                                                        0 No error nor warning
                                                        1 CPL is partially registered on this server
                                                        2 CPL is registered on this server but cannot be loaded
                                                        3 CPL is ingesting
                                                        4 CPL is queued for ingest
                                    ingest_path         STRING relative path to cpl.xml from ftp logon
                                    cpl_size            STRING size of cpl in bytes
                                }
                }
            }
            keys - {
                key_uuid: {
        
                }
            }
            additional_files {
                #this would be stuff like pos files, adpack files etc.
                path : {
                    type: STRING
                    path: STRING
                }
            }
            error_messages - LIST of errors
        """
        raise NotImplementedError, 'Abstract API class; use concrete implementation'

    @abc.abstractmethod
    def get_thumbprint(self):
        """
        this aquires a thumbprint of the mountpoint. the thumbprint is uesd to determine if the scanned information we retrieved on previous scans
        can now be considered to be out of date.
        """
        raise NotImplementedError, 'Abstract API class; use concrete implementation'

    def get_device_version_information(self, *args, **kwargs):
        raise NotImplementedError

    def _get_all_digital_cinema_content(self, handler, folder_path, include_kdms = True, search_depth = MOUNT_POINT_SCAN_DEPTH, include_error_report = False):
        found_packages = []
        found_kdms = []
        found_packs = []
        found_pos = {}
        encoding = 'utf-8' if sys.getfilesystemencoding() == None else sys.getfilesystemencoding()
        self._reset_content_report_storage()
        for root, dirs, files in ignore_hidden_walk(handler, folder_path.decode(encoding)):
            starting_level = folder_path.count(os.path.sep)
            level = root.count(os.path.sep)
            if level - starting_level <= search_depth:
                if _folder_is_package(root, handler):
                    found_packages.append(root)
            for each_file in files:
                if self.__was_processed(root, each_file, handler):
                    continue
                kdms_return = self.__get_kdms_from_file(each_file, root, handler)
                found_kdms.extend(kdms_return['found_kdms'])
                self.content_report_storage['stats']['kdms']['success'] += len(kdms_return['found_kdms'])
                for message in kdms_return['messages']:
                    if message['type'] == 'ERROR':
                        if message['reason'] == 'expired':
                            self.content_report_storage['stats']['kdms']['expired'] += 1

                if self.device_configuration['type'] != 'ftp':
                    packs_return = self.__get_packs_from_file(each_file, root, handler)
                    found_packs.extend(packs_return['found_packs'])
                    self.content_report_storage['stats']['packs']['success'] += len(packs_return['found_packs'])
                    for message in packs_return['messages']:
                        if message['type'] == 'ERROR':
                            if message['reason'] == 'expired':
                                self.content_report_storage['stats']['packs']['expired'] += 1

                    parsed_pos = self.__get_pos_from_file(each_file, root, handler)
                    if parsed_pos['success']:
                        found_pos[str(each_file)] = parsed_pos['messages']

        processed_dcps = {}
        self.content_report_storage['stats']['dcps']['all'] = len(found_packages)
        for package in found_packages:
            dcps_return = self.__get_dcp_info_from_package(handler, package)
            if dcps_return['cpls']:
                is_faulty = False
                if dcps_return['errors']:
                    self.content_report_storage['stats']['dcps']['faulty'] += 1
                    is_faulty = True
                for cpl in dcps_return['cpls']:
                    if cpl['errors']:
                        if not is_faulty:
                            self.content_report_storage['stats']['dcps']['with_faulty_cpls'] += 1
                            is_faulty = True
                            break

                if not is_faulty:
                    self.content_report_storage['stats']['dcps']['success'] += 1
                processed_dcps[package] = dcps_return

        self.__clean_processed(handler)
        return {'processed_dcps': processed_dcps,
         'processed_kdms': found_kdms,
         'processed_packs': found_packs,
         'processed_pos': found_pos}

    def __get_dcp_info_from_package(self, handler, package):
        response = {'errors': [],
         'cpls': []}
        try:
            dcp = DCP(package, handler)
        except Exception as ex:
            logging.error('There was a problem validating the dcp at this location %s' % package, exc_info=True)
            response['errors'].append(_('Error analysing the DCP at location %s: %s') % (package, ex))
        else:
            response['errors'].extend(dcp.errors)
            assets_in_cpls = {}
            for cpl in dcp.cpls:
                assets_in_cpls[cpl.uuid] = True
                for asset in cpl.assets:
                    assets_in_cpls[asset['uuid']] = True

            for asset in dcp.assets.values():
                if not assets_in_cpls.has_key(asset.uuid):
                    for error in asset.errors:
                        response['errors'].append(_('Error with the asset file %s : %s') % (asset.relative_path, error))

            if not dcp.cpls:
                if self.device_configuration['type'] == 'watchfolder':
                    return response
                fake_uuid = uuid.uuid5(uuid.UUID(self.device_configuration['id']), package.encode('ascii', 'xmlcharrefreplace'))
                total_size = 0
                for dirpath, dirnames, filenames in handler.walk(package):
                    for f in filenames:
                        fp = os.path.join(dirpath, f)
                        if self.device_configuration['type'] != 'ftp':
                            total_size += os.path.getsize(fp)
                        else:
                            total_size += handler.get_size(fp)

                dcp_info = {'uuid': str(fake_uuid),
                 'ingestible': False,
                 'complete': False,
                 'is_empty_dcp': True,
                 'ingest_path': package,
                 'total_size': total_size,
                 'errors': dcp.errors,
                 'xml': None}
                response['cpls'].append(dcp_info)
            else:
                for cpl in dcp.cpls:
                    cpl_info = {'uuid': cpl.uuid,
                     'ingestible': cpl.is_ingestible,
                     'complete': cpl.complete,
                     'is_empty_dcp': False,
                     'ingest_path': cpl.full_path,
                     'total_size': cpl.total_asset_size,
                     'xml': cpl._xml}
                    error_list = []
                    missing_assets = []
                    if dcp.assets.has_key(cpl.uuid):
                        if dcp.assets[cpl.uuid].errors:
                            message = _('CPL %s has the following errors %s') % (dcp.assets[cpl.uuid].full_path, str(dcp.assets[cpl.uuid].errors))
                            if message not in error_list:
                                error_list.append(message)
                    for asset in cpl.assets:
                        if dcp.assets.has_key(asset['uuid']) and not dcp.assets[asset['uuid']].missing:
                            if dcp.assets[asset['uuid']].errors:
                                message = _('Asset %s has the following errors %s') % (dcp.assets[asset['uuid']].full_path, str(dcp.assets[asset['uuid']].errors))
                                if message not in error_list:
                                    error_list.append(message)
                        else:
                            missing_assets.append(asset['uuid'])
                            if re.match('.*_VF(?:-\\d+)?$', cpl.content_title_text, re.U):
                                message = _('Asset %s is missing but this appears to be a supplemental package') % asset['uuid']
                            else:
                                message = _('Asset %s is missing') % asset['uuid']
                            if message not in error_list:
                                error_list.append(message)

                    cpl_info['errors'] = error_list
                    cpl_info['missing_assets'] = missing_assets
                    response['cpls'].append(cpl_info)

        return response

    def __get_packs_from_file(self, filename, root, handler):
        """
        Checks if a file is an Ad Pack returns details of the pack found
        Only used in __update_mounted_drive_content
        """
        found_packs = []
        messages = []
        return_values = {'found_packs': [],
         'messages': []}
        if filename.startswith('.'):
            return return_values
        try:
            if filename.lower().endswith('.xml') and handler.exists(handler.join(root, filename)) and handler.get_size(handler.join(root, filename)) < 300000:
                try:
                    filepath = handler.join(root, filename)
                    with handler.open(filepath) as tmp_file:
                        first_200_chars = tmp_file.read(200)
                        if first_200_chars.find('AAMPack') != -1 or first_200_chars.find('Val Morgan') != -1:
                            entire_file = first_200_chars + tmp_file.read()
                            packs = parse_pack_xml(entire_file)
                            if not len(packs):
                                messages.append({'type': 'INFO',
                                 'message': 'No packs found in file %s' % str(filename),
                                 'reason': 'bad_format'})
                            else:
                                self.__is_processed(root, filename, handler)
                            for pack in packs:
                                if pack.get('date_to'):
                                    if pack.get('time_to'):
                                        valid_to = datetime.datetime.strptime(pack['date_to'] + ' ' + pack['time_to'], '%Y-%m-%d %H:%M:%S')
                                    else:
                                        valid_to = datetime.datetime.strptime(pack['date_to'] + ' 00:00:00', '%Y-%m-%d %H:%M:%S')
                                    if valid_to >= datetime.datetime.now():
                                        found_packs.append({'pack': pack,
                                         'pack_path': filepath})
                                    else:
                                        messages.append({'type': 'ERROR',
                                         'message': 'Pack expired at {valid_to}'.format(valid_to=valid_to),
                                         'reason': 'expired'})
                                else:
                                    found_packs.append({'pack': pack,
                                     'pack_path': filepath})

                        else:
                            messages.append({'type': 'INFO',
                             'message': 'This is not a pack',
                             'reason': 'unknown_type'})
                except Exception:
                    logging.error('Unable to parse potential Pack %s' % str(filename), exc_info=True)
                    messages.append({'type': 'INFO',
                     'message': 'Unable to parse potential Pack %s' % str(filename),
                     'reason': 'unknown_type'})

        except Exception as e:
            logging.error('There was an error extracting packs from path: %s, %s\n%s' % (str(filename), str(e), traceback.format_exc()))
            messages.append({'type': 'ERROR',
             'message': 'There was an error extracting packs from path: %s' % str(filename),
             'reason': 'ioerror'})

        return_values['messages'] = messages
        return_values['found_packs'] = found_packs
        return return_values

    def __get_pos_from_file(self, filename, root, handler):
        """
        Checks if a file is an POS File and ingests if it is
        Only used in __update_mounted_drive_content
        """
        output = {'success': False,
         'messages': []}
        lowercase = filename.lower()
        if lowercase.startswith('.') or not handler.exists(handler.join(root, filename)) or not lowercase.endswith(('.xml', '.txt', '.iff')):
            return output
        try:
            if handler.get_size(handler.join(root, filename)) < 1000000:
                filepath = handler.join(root, filename)
                lms_pos_path = os.path.join(cfg.lms_library_directory.get(), 'POS')
                try:
                    shutil.copy(filepath, lms_pos_path)
                    output['success'] = True
                except Exception as e:
                    message = 'Unable to move pos file to lms for ingest: %s' % e
                    logging.error(message)
                    output['messages'].append({'type': 'error',
                     'message': _('Error ingesting POS file')})
                    output['success'] = False

        except Exception as e:
            logging.error('There was an error extracting POS files from path: %s, %s\n%s' % (str(filename), str(e), traceback.format_exc()))
            output['messages'].append({'type': 'error',
             'message': _('Error reading POS file')})
            output['success'] = False

        if output['success']:
            output['messages'].append({'type': 'success',
             'message': _('POS file ingested successfully')})
        return output

    def __get_kdms_from_file(self, filename, root, handler):
        """
        Checks if a file is a KDM or if a zip contains KDMs and returns details of the KDMs found
        Only used in __update_mounted_drive_content
        """

        def inside_kdm_parser(file_handle, filepath):
            first_100_chars = file_handle.read(100)
            if first_100_chars.find('DCinemaSecurityMessage') != -1:
                entire_file = first_100_chars + file_handle.read()
                kdm = parse_kdm(entire_file, False)
                if kdm.has_key('start_date'):
                    if kdm['dn_qualifier'] == '?':
                        messages.append({'type': 'ERROR',
                         'message': "KDM dnQualifier couldn't be read",
                         'reason': 'bad_format'})
                    elif kdm.has_key('end_date') and kdm['end_date'] < time.time():
                        if self.show_expired_kdms:
                            found_kdms.append({'xml': entire_file,
                             'uuid': kdm['id'],
                             'path': filepath,
                             'expired': True})
                        messages.append({'type': 'ERROR',
                         'message': 'KDM expired at: {date}'.format(date=kdm['end_date']),
                         'reason': 'expired'})
                    else:
                        found_kdms.append({'xml': entire_file,
                         'uuid': kdm['id'],
                         'path': filepath,
                         'expired': False})
                        self.__is_processed(root, filename, handler)
                else:
                    messages.append({'type': 'ERROR',
                     'message': 'KDM has no start_date. Bad Parsing',
                     'reason': 'bad_format'})
            else:
                messages.append({'type': 'INFO',
                 'message': 'This is not a KDM',
                 'reason': 'unknown_type'})

        return_values = {'found_kdms': [],
         'messages': []}
        found_kdms = []
        messages = []
        if filename.startswith('.'):
            return return_values
        else:
            try:
                if filename.lower().endswith('.xml') and handler.get_size(handler.join(root, filename)) < 300000:
                    try:
                        filepath = handler.join(root, filename)
                        with handler.open(filepath) as tmp_file:
                            inside_kdm_parser(tmp_file, filepath)
                    except Exception:
                        messages.append({'type': 'ERROR',
                         'message': u'Unable to parse potential KDM %s' % unicode(filename),
                         'reason': 'ioerror'})
                        logging.error(u'Unable to parse potential KDM %s' % unicode(filename), exc_info=True)

                elif filename.lower()[-4:] == '.zip':
                    zp_filepath = handler.join(root, filename)
                    with handler.open(zp_filepath, 'rb') as zp_fileobj:
                        zp = None
                        try:
                            zp = zipfile.ZipFile(zp_fileobj)
                            for zip_asset_info in zp.infolist():
                                if zip_asset_info.filename[-4:] == '.xml' and zip_asset_info.file_size < 300000:
                                    try:
                                        xml_asset = zp.open(zip_asset_info.filename)
                                        inside_kdm_parser(xml_asset, zp_filepath)
                                    except Exception as e:
                                        logging.error('Unable to parse potential KDM %s in %s' % (str(zip_asset_info.filename), str(filename)), exc_info=True)

                        except Exception as e:
                            messages.append({'type': 'ERROR',
                             'message': u'Unable to unpack ZIP file %s' % unicode(filename),
                             'reason': 'ioerror'})
                            logging.error('ZIP unpack error file %s' % zp_filepath, exc_info=True)
                        finally:
                            if zp != None:
                                zp.close()

                elif filename.lower()[-7:] == '.tar.gz' or filename.lower()[-8:] == '.tar.bz2':
                    tar_filepath = handler.join(root, filename)
                    with handler.open(tar_filepath, 'rb') as tar_fileobj:
                        tar = None
                        try:
                            tar = tarfile.open(fileobj=tar_fileobj)
                            for tar_member_info in tar.getmembers():
                                if tar_member_info.name[-4:] == '.xml' and tar_member_info.size < 300000:
                                    try:
                                        xml_asset = tar.extractfile(tar_member_info)
                                        inside_kdm_parser(xml_asset, tar_filepath)
                                    except Exception as e:
                                        logging.error('trying to read potential kdm, but it appears it was not kdm: %s\n%s' % (str(e), traceback.format_exc()))

                        except Exception as ex:
                            messages.append({'type': 'ERROR',
                             'message': u'Unable to unpack TAR file %s' % unicode(filename),
                             'reason': 'ioerror'})
                            logging.error('TAR unpack error file %s: %s\n%s' % (tar_filepath, str(ex), traceback.format_exc()))
                        finally:
                            if tar != None:
                                tar.close()

            except Exception as e:
                messages.append({'type': 'ERROR',
                 'message': u'There was an error extracting kdms from path: %s, %s\n%s' % (unicode(filename), unicode(e), traceback.format_exc()),
                 'reason': 'ioerror'})
                logging.error(u'There was an error extracting kdms from path: %s, %s\n%s' % (unicode(filename), unicode(e), traceback.format_exc()))

            return_values['found_kdms'] = found_kdms
            return_values['messages'] = messages
            return return_values

    def __was_processed(self, root, filename, handler):
        file = handler.join(root, filename)
        return self.processed_files['files'].get(file) == handler.last_modified(file)

    def __is_processed(self, root, filename, handler):
        file = handler.join(root, filename)
        self.processed_files['files'][file] = handler.last_modified(file)

    def __clean_processed(self, handler):
        if time.time() - self.processed_files['stamp'] > 7200:
            self.processed_files = {'stamp': time.time(),
             'files': {}}
        else:
            processed_files = {}
            for filename in self.processed_files['files']:
                if handler.exists(filename):
                    processed_files[filename] = self.processed_files['files'][filename]

            self.processed_files['files'] = processed_files

    def test_management_connection(self):
        return (True, _('OK'))

    def get_content_uuid_list(self):
        """
        gets content uuid list of a device
        
        @return
            {
                content_uuid_list       -LIST of UUIDs
                error_messages          -LIST of errors
            }
        
        """
        return {'content_uuid_list': self.drive_storage['cpls'].keys(),
         'error_messages': []}

    def transfer_methods(self):
        return ['local']

    def get_content_information(self, content_uuids):
        """
        gets content information of a device
        
        @param      content_uuids   - list of cpl uuids we want information for
        @return {
                    content_info_dict:        DICT
                        {
                            content_uuid: {
                                content_title_text  STRING
                                content_kind        INT
                                edit_rate         [INT, INT]
                                encrypted           BOOL
                                subtitled           BOOL
                                is_3d               BOOL
                                duration            INT in seconds
                                xml                 STRING xml file
                                parsed_info         DICT
                            }
                    error_messages          -LIST of errors
                }
        """
        output = {'error_messages': [],
         'content_info_dict': {}}
        for content_uuid in content_uuids:
            cpl_info = {'content_title_text': content_uuid,
             'content_kind': 'unknown',
             'edit_rate': [None, None],
             'subtitled': None,
             'subtitle_language': None,
             'playback_mode': None,
             'aspect_ratio': None,
             'duration_in_seconds': 0,
             'duration_in_frames': 0,
             'encrypted': None,
             'xml': None,
             'parsed_info': parse_content_title_text(''),
             'video_encoding': 'UNKNOWN'}
            if self.drive_storage['cpls'][content_uuid]['is_empty_dcp']:
                cpl_info['content_title_text'] = self.drive_storage['cpls'][content_uuid]['ingest_path']
                cpl_info['error_message'] = ', '.join(self.drive_storage['cpls'][content_uuid]['errors'])
            else:
                try:
                    temp_cpl = parse_cpl(self.drive_storage['cpls'][content_uuid]['xml'], load_from_file=False)
                    cpl_info['content_title_text'] = temp_cpl['text']
                    cpl_info['content_kind'] = temp_cpl['type']
                    cpl_info['edit_rate'] = temp_cpl['edit_rate']
                    cpl_info['subtitled'] = temp_cpl['subtitled']
                    cpl_info['subtitle_language'] = temp_cpl['subtitle_language']
                    cpl_info['playback_mode'] = temp_cpl['playback_mode']
                    cpl_info['aspect_ratio'] = temp_cpl['aspect_ratio']
                    cpl_info['duration_in_seconds'] = temp_cpl['duration_in_seconds']
                    cpl_info['duration_in_frames'] = temp_cpl['duration_in_frames']
                    cpl_info['encrypted'] = temp_cpl['encrypted']
                    cpl_info['xml'] = self.drive_storage['cpls'][content_uuid]['xml']
                    cpl_info['parsed_info'] = temp_cpl['parsed_info']
                    if cfg.core_detect_content_video_encoding():
                        cpl_info['video_encoding'] = self.get_content_video_encoding(content_uuid)['video_encoding']
                except Exception as ex:
                    logging.error('Error getting cpl information for cpl_id %s' % content_uuid, exc_info=True)
                    cpl_info['error_message'] = str(ex)
                    output['error_messages'].append(str(ex))

            output['content_info_dict'][content_uuid] = cpl_info

        return output

    def get_content_validation_information(self, content_uuids):
        """
        This recieves information for given cpls in the system
        
        @param      content_uuids   - list of cpl uuids we want information for
        @return     {
                        content_validation_dict:
                            {
                                cpl_uuid:
                                {
                                    validation_code - Integer
                                        0 No error nor warning
                                        1 CPL is partially registered on this server
                                        2 CPL is registered on this server but cannot be loaded
                                        3 CPL is ingesting
                                        4 CPL is queued for ingest
                                    cpl_size - STRING cpl size in bytes
                                }
                            }
                        error_messages - LIST of errors
                    }
        """
        output = {'error_messages': [],
         'content_validation_dict': {}}
        for content_uuid in content_uuids:
            if self.drive_storage['cpls'].has_key(content_uuid):
                cpl_validation_info = {}
                if self.drive_storage['cpls'][content_uuid]['ingestible']:
                    if self.drive_storage['cpls'][content_uuid]['complete']:
                        cpl_validation_info['validation_code'] = 0
                    else:
                        mismatch = False
                        for error in self.drive_storage['cpls'][content_uuid]['errors']:
                            if 'SIZE_MISMATCH' in error:
                                mismatch = True
                                break

                        if mismatch == True:
                            cpl_validation_info['validation_code'] = 2
                        else:
                            cpl_validation_info['validation_code'] = 1
                else:
                    cpl_validation_info['validation_code'] = 2
                if self.device_configuration['type'] not in ('cd', 'ftp', 'watchfolder'):
                    if self.is_ingesting(content_uuid):
                        cpl_validation_info['validation_code'] = 3
                cpl_validation_info['ingest_path'] = self.drive_storage['cpls'][content_uuid]['ingest_path']
                cpl_validation_info['cpl_size'] = self.drive_storage['cpls'][content_uuid]['size']
                if self.drive_storage['cpls'][content_uuid].get('is_empty_dcp') and not cpl_validation_info['validation_code'] == 3:
                    cpl_validation_info['invalid_cpl'] = True
                output['content_validation_dict'][content_uuid] = cpl_validation_info
            else:
                output['error_messages'].append(_('Error getting CPL information for ID: %s') % str(content_uuid))

        return output

    def get_ingest_path(self, content_uuid):
        return self.drive_storage['cpls'][content_uuid]['ingest_path']

    def get_key_uuid_list(self):
        """
        gets key uuid list of a device
        
        @return
            dict
                key_uuid_list      -LIST of UUIDs
                error_messages          -LIST of errors
        
        """
        return {'key_uuid_list': self.drive_storage['kdms'].keys(),
         'error_messages': []}

    def get_sync_report(self):
        with self.sync_lock:
            return self.content_report_storage

    def get_key_information(self, key_uuids):
        """
        This key information for key uuids provided
        
        @param      key_uuids          LIST of key ids
        @return     key dictionary
        """
        output = {'error_messages': [],
         'key_info_dict': {}}
        for key_uuid in key_uuids:
            if self.drive_storage['kdms'].has_key(key_uuid):
                kdm = parse_kdm(self.drive_storage['kdms'][key_uuid]['xml'], load_from_file=False)
                output['key_info_dict'][key_uuid] = {}
                output['key_info_dict'][key_uuid]['cpl_title'] = kdm['cpl_text']
                output['key_info_dict'][key_uuid]['cpl_uuid'] = kdm['cpl_id']
                output['key_info_dict'][key_uuid]['not_valid_before'] = kdm['start_date']
                output['key_info_dict'][key_uuid]['not_valid_after'] = kdm['end_date']
                output['key_info_dict'][key_uuid]['dnqualifier'] = kdm['dn_qualifier']
                output['key_info_dict'][key_uuid]['status'] = 'unknown' if kdm['dn_qualifier'] != '?' else 'error'
            else:
                output['error_messages'].append(_('Error getting KDM information for ID %s') % key_uuid)

        return output

    def content_add_key(self, key):
        """
        Adds a list of keys to a device.
        
        @param key          xml_file      - kdm_xml
        """
        raise NotImplementedError

    def content_delete_key(self, key_id):
        """
        Deletes a key from a device.
        @param key_id                  UUID   - key identifiers
        """
        raise NotImplementedError

    def get_key(self, key_uuid):
        """
        gets key xml
        
        @return
            dict
                xml        DICT
                    xml    STRING
                error_messages          -LIST of errors
        """
        raise NotImplementedError

    def sync_required(self):
        if self.device_configuration['type'] not in ('ftp', 'cd', 'watch') and self.is_ingesting():
            return False
        else:
            previous = self.sync_status['thumbprint']
            current = self.get_thumbprint()
            self.sync_status['thumbprint'] = current
            return previous == None or previous != current

    def reset_sync(self):
        self.drive_storage['last_updated'] = None
        self.sync_status['last_updated'] = None
        success = True
        message = 'Sync marked for restart'
        return (success, message)

    def sync(self):
        self.drive_storage['last_updated'] = time.time()
        test = self.test_content_connection()
        if test[0] == False:
            return test
        if self.sync_status['sync_active']:
            return (False, _('Sync is in progress'))
        if not self.sync_required():
            return (True, _('Sync is not required'))
        with self.sync_lock:
            self.sync_status['sync_active'] = True
            try:
                output = self.retrieve_all_contents()
            except Exception as ex:
                logging.error('Sync failed', exc_info=True)
                return (False, _('Sync failed %s') % str(ex))

            self.drive_storage['cpls'] = {}
            for dcps in output['processed_dcps'].itervalues():
                for cpl in dcps['cpls']:
                    self.drive_storage['cpls'][cpl['uuid']] = {}
                    self.drive_storage['cpls'][cpl['uuid']]['errors'] = cpl['errors']
                    self.drive_storage['cpls'][cpl['uuid']]['ingestible'] = cpl['ingestible']
                    self.drive_storage['cpls'][cpl['uuid']]['complete'] = cpl['complete']
                    self.drive_storage['cpls'][cpl['uuid']]['is_empty_dcp'] = cpl['is_empty_dcp']
                    self.drive_storage['cpls'][cpl['uuid']]['size'] = cpl['total_size']
                    self.drive_storage['cpls'][cpl['uuid']]['ingest_path'] = cpl['ingest_path']
                    self.drive_storage['cpls'][cpl['uuid']]['xml'] = cpl['xml']

            self.drive_storage['kdms'] = {}
            for kdm in output['processed_kdms']:
                self.drive_storage['kdms'][kdm['uuid']] = {}
                self.drive_storage['kdms'][kdm['uuid']]['xml'] = kdm['xml']
                self.drive_storage['kdms'][kdm['uuid']]['uuid'] = kdm['uuid']
                self.drive_storage['kdms'][kdm['uuid']]['ingest_path'] = kdm['path']

            with self.content_information_lock:
                self.content_information['last_updated'] = 0
            self.sync_status['sync_active'] = False
            return (True, _('Sync complete: %s DCPs %s KDMs %s Packs') % (len(output['processed_dcps'].keys()), len(output['processed_kdms']), len(output['processed_packs'])))

    def monitor_device_state(self, *args, **kwargs):
        super(MountPoint, self).monitor_device_state(*args, **kwargs)
        if helper_methods.info_needs_updating(self.drive_storage, cfg.sync_device_state_validity.get()):
            self._execute_action(SyncAction(self.sync))
# okay decompyling ./core/devices/base/mount_point.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:35 CST
