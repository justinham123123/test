# 2017.08.13 21:48:30 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\custom.py
import abc
from serv.core.devices.base.monitoring import Monitor
from serv.lib.cherrypy.i18n_tool import ugettext as _

class Custom(Monitor):
    __metaclass__ = abc.ABCMeta

    def __init__(self, id, device_info):
        device_info['custom'] = True
        super(Custom, self).__init__(id, device_info)

    def test_management_connection(self):
        return (True, _('OK'))

    def get_device_status(self):
        return {'error_messages': []}

    def get_device_information(self):
        return {'error_messages': []}

    def get_device_version_information(self):
        return {'error_messages': []}
# okay decompyling ./core/devices/base/custom.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:30 CST
