# 2017.08.13 21:48:39 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\projection.py
import abc
from time import time
import logging
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.core.devices.base.monitoring import Monitor
from serv.lib.utilities.action import SyncAction

class Projection(Monitor):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def get_projector_status(self):
        """
        Gets the available status values for the projector
        @return
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        raise NotImplementedError

    @abc.abstractmethod
    def lamp_on(self):
        """
        Strike the lamp
        """
        raise NotImplementedError

    @abc.abstractmethod
    def lamp_off(self):
        """
        Turn the lamp off
        """
        raise NotImplementedError

    @abc.abstractmethod
    def open_dowser(self):
        """
        Open the dowser
        """
        raise NotImplementedError

    @abc.abstractmethod
    def close_dowser(self):
        """
        Close the dowser
        """
        raise NotImplementedError

    @abc.abstractmethod
    def power_on(self):
        """
        Turn the projector on
        """
        raise NotImplementedError

    @abc.abstractmethod
    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        raise NotImplementedError

    def get_device_version_information(self, *args, **kwargs):
        return NotImplementedError

    def _device_sync_projection_status(self):
        logging.debug('Syncing projection status for device [%s]' % self.device_configuration['id'])
        success = True
        messages = []
        projection_status = self.get_projector_status()
        self.handle_api_update(projection_status)
        if len(projection_status['error_messages']) > 0:
            success = False
            messages.extend(projection_status['error_messages'])
        self.device_information['last_updated'] = time()
        return (success, messages)

    def device_get_projection_status(self):
        return dict(self.device_information)

    def has_multiple_lamps(self):
        return False

    def monitor_device_state(self, *args, **kwargs):
        super(Projection, self).monitor_device_state(*args, **kwargs)
        if helper_methods.info_needs_updating(self.device_information, cfg.sync_projection_status_validity.get()):
            self._execute_action(SyncAction(self._device_sync_projection_status))
# okay decompyling ./core/devices/base/projection.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:39 CST
