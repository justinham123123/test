# 2017.08.13 21:48:26 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\content.py
from copy import deepcopy
import datetime
import ftplib
import logging
import os
import time
import socket
import threading
import uuid
import abc
from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound
from sqlalchemy.sql.expression import and_, not_, or_
from serv import core
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.dcp import helpers
from serv.lib.dcinema.dcp.file_handlers import FTPHandler
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.configuration.constants import TRANSFER_STATES
from serv.core.devices.sms import gdc
from serv.core.devices.base.monitoring import Monitor
from serv.lib.utilities.action import SyncAction
from serv.storage.database.primary import database as db
import cherrypy
from serv.configuration.constants import ContentStates as CS
from serv.lib.dcinema.parsers.parsers import parse_kdm

class Content(Monitor):
    __metaclass__ = abc.ABCMeta

    def __init__(self, id, device_info):
        super(Content, self).__init__(id, device_info)
        self.device_configuration['ftp_ip'] = device_info['ftp_ip'] if 'ftp_ip' in device_info else None
        self.device_configuration['ftp_port'] = device_info['ftp_port'] if 'ftp_port' in device_info else None
        self.device_configuration['ftp_username'] = device_info['ftp_username'] if 'ftp_username' in device_info else None
        self.device_configuration['ftp_password'] = device_info['ftp_password'] if 'ftp_password' in device_info else None
        self.transfer_information = {'queue': [],
         'active': {},
         'last_updated': None}
        self.transfer_ignore_list = {}
        self.transfer_initial_sync = False
        self.transfer_information_lock = threading.Lock()
        self.content_information_lock = threading.Lock()
        self.content_information = {'last_updated': None}
        self.key_information_lock = threading.Lock()
        self.key_information = {'last_updated': None}
        self.sync_status = {'sync_active': False,
         'auto_sync': False,
         'auto_ingest': False,
         'last_updated': None,
         'thumbprint': None}
        self.eta_information = {}
        self._device_get_persisted_transfers()
        self._transfers_syncing = False
        self._content_syncing = False
        self._keys_syncing = False
        self._schedules_syncing = False
        self._playlists_syncing = False
        self.initial_sync_complete = False
        return

    @abc.abstractmethod
    def get_key_uuid_list(self):
        """
        Returns key uuid list of a device
        
        @return
        dict
            key_uuid_list - LIST of UUIDs
            error_messages - LIST of errors
        """
        raise NotImplementedError, 'Abstract API class; use concrete implementation'

    @abc.abstractmethod
    def get_key_information(self, key_uuids):
        """
        gets key information of a device
        
        @return
            dict
                key_info_dict        DICT
                    <key_uuid>
                        cpl_title
                        cpl_uuid            STRING (UUID)
                        not_valid_before    FLOAT datetime in posix timestamp format
                        not_valid_after     FLOAT datetime in posix timestamp format
                        dnqualifier         STRING
                error_messages          -LIST of errors
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_key(self, key_uuid):
        """
        gets key xml
        
        @return
            dict
                xml        DICT
                    xml    STRING
                error_messages          -LIST of errors
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_transfer_ids(self):
        """
        This returns all the transfer ids in the syste,
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                            ]
        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_transfer_info(self, transfer_ids):
        """
        This returns all information for specified transfers
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                                state          STRING      - 'initializing', 'queued on server', 'active', 'paused', 'cancelled', 'success', 'failure'
                                description    STRING      - description of the transfer, ie content title
                                type           STRING      - cpl, kdm...
                                cpl_uuid       STRING      - transferring cpl
                                source         STRING      - source this can be an ipaddress or a description (ie local disk)
                                progress       INTEGER     - % transfer complete
                                message        STRING      - a message elaborating on the transfer_state ('ingest was paused at 15:00')
                            ]
        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_content_uuid_list(self):
        """
        gets content uuid list of a device
        
        @return
            {
                content_uuid_list       -LIST of UUIDs
                error_messages          -LIST of errors
            }
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_content_information(self, content_uuids):
        """
        gets content information of a device
        
        @type content_uuids:LIST
        @param   content_uuids:list of cpl uuids we want information for
        @rtype DICT
        @return {
                    content_info_dict:        DICT
                        {
                            content_uuid: {
                                content_title_text  STRING
                                content_kind        INT
                                edit_rate           [INT, INT]
                                subtitled           BOOL
                                subtitle_language   STRING
                                aspect_ratio        STRING
                                duration_in_seconds INT
                                duration_in_frames  INT
                                encrypted           BOOL
                                playback_mode       String
                                xml                 STRING xml file
                                parsed_info         DICT
                            }
                    error_messages          -LIST of errors
                }
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_content_validation_information(self, content_uuids):
        """
        Returns device specific content information e.g. validation state, ingest path etc.
        
        :param content_uuids: a list of content identifiers
        :returns: a dict containing the content information
        
        Example usage::
        
            device.get_content_validation_information(["870c714f-678c-4069-ba92-7913e286912b"])
        
        Example response::
        
            {
              "content_validation_dict": {
                "870c714f-678c-4069-ba92-7913e286912b": {
                  "validation_code": 0,
                  "ingest_path": "/870c714f-678c-4069-ba92-7913e286912b/870c714f-678c-4069-ba92-7913e286912b.xml",
                  "cpl_size": 77876519
                }
              },
              "error_messages": [ ]
            }
        
        Validation Codes:
        ====  ===================================
        Code  Meaning
        ====  ===================================
        -1    Content doesn't exist on the device
        0     OK
        1     Content is missing assets
        2     Content is corrupt
        3     Content is ingesting
        4     Content is queued for ingest
        ==== ====================================
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_ingest_path(self, content_uuid):
        """
        Find the FTP path to the CPL XML file (just the path part, not the URL)
        @param      content_uuid   - the CPL uuid
        @return     STRING   ingest path
        """
        raise NotImplementedError

    @abc.abstractmethod
    def content_add_key(self, key):
        """
        Adds a list of keys to a device.
        
        @param key          xml_file      - kdm_xml
        """
        raise NotImplementedError

    @abc.abstractmethod
    def content_cancel_transfer(self, transfer_id):
        """
        Cancels a transfer on a device.
        
        @param transfer_id  STRING  - transfer identifier
        """
        raise NotImplementedError

    @abc.abstractmethod
    def content_clear_transfer_history(self):
        """
        Clears transfer history from a device.
        
        @param transfer_id  STRING  - transfer identifier
        """
        raise NotImplementedError

    @abc.abstractmethod
    def content_delete(self, content_id):
        """
        Deletes the specified content from the device
        @param content_id              UUID - content identifiers
        """
        raise NotImplementedError

    @abc.abstractmethod
    def content_delete_key(self, key_id):
        """
        Deletes a key from a device.
        @param key_id                  UUID   - key identifiers
        """
        raise NotImplementedError

    @abc.abstractmethod
    def content_transfer(self, connection_details, description, cpl_uuid):
        """
        Ingests content onto the device.
        
        @param connection_details      DICT - Must include 'type' key along with type-specific details
                                              e.g. ftp ip, path, user, pass or local path
        @param description             STRING - Human readable desc for the transfer i.e. content_title_text
        @param cpl_uuid                STRING - UUID of CPL to be transferred
        """
        raise NotImplementedError

    def get_content_video_encoding(self, content_uuid):
        """
        Return info identifying the content assets' encoding e.g. MPEG2 or JPEG2000
        @param      content_uuid    - CPL UUID
        @return     content_encoding {
                        cpl_uuid: "MPEG2" | "JPEG2000" | "UNKNOWN"
                    }
        """
        raise NotImplementedError

    def content_validate(self, cpl_uuid):
        """
        Starts content validation on the device.
        -only shoud be for sony
        
        @param cpl_uuid                STRING - UUID of CPL to be transferred
        """
        raise NotImplementedError

    def scan_content(self, content_uuid):
        """
        This scans the actual folder content and returns detailed information for given cpl in the system
        
        @param      content_uuid   - the content uuid to be scanned
        
        @return     {
                file_name:
                    {
                    status : Error or Valid
                    message: Relative informative message that will make sense to everyone
                    }
                }
            }
        """
        handler = self._default_handler()
        path = self.get_ingest_path(content_uuid)
        return helpers._analyze_cpl(handler, path)

    def _update_content_in_playlist(self, content_uuid, playlist_uuid):
        """
        If needed this will update the playlist info with actual content info
        """
        pass

    def transfer_methods(self):
        """
        returns the transfer methods available: ftp and/or local. Default is just ftp
        """
        return ['ftp']

    def _default_handler(self):
        """
        Default handler for file transfer/inspection operations
        i.e. can be overridden for local devices
        """
        return FTPHandler(self.device_configuration['ftp_ip'], self.device_configuration['ftp_username'], self.device_configuration['ftp_password'], self.device_configuration['ftp_port'])

    def ready_for_transfer(self, source):
        """
        Check to see if device is currently capable of accepting a CPL transfer
        Default no if currently ingesting anything
        """
        return len(self.transfer_information['active']) == 0

    def ready_for_kdm_transfer(self):
        """
        Check to see if device is currently capable of accepting a KDM transfer (Dolby says no when playing back)
        """
        if not self.sync_status['sync_active']:
            return True

    def test_content_connection(self):
        """
        Checks that the FTP connection for this device is working
        :returns: tuple containing a bool which is shows the success of the test and a str containing any error message
        """
        try:
            self._default_handler()
        except (ftplib.error_temp, ftplib.error_perm) as ex:
            if ex.args and ex.args[0].startswith('530'):
                return (False, _('Incorrect login details'))
            return (False, _('Unexpected FTP error %s' % str(ex)))
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error %s') % str(ex))

        return (True, _('OK'))

    @db.close_session
    def _device_get_persisted_transfers(self):
        transfers = db.Session.query(db.Transfer).filter(and_(db.Transfer.destination_device_uuid == self.device_configuration['id'], db.Transfer.state.in_(['queued',
         'request_sent',
         'queued_on_device',
         'success',
         'cancelled',
         'failed'])))
        for transfer in transfers:
            transfer_object = {'state': transfer.state,
             'description': transfer.description,
             'source': transfer.source,
             'content_id': transfer.content_uuid,
             'not_before': transfer.not_before,
             'not_before_string': helper_methods.format_timestamp(transfer.not_before),
             'id': transfer.uuid,
             'message': transfer.message,
             'message_code': transfer.message_code,
             'type': transfer.type,
             'playlist_uuid': transfer.playlist_uuid,
             'playlist_json': transfer.playlist_json,
             'server_transfer_id': transfer.device_transfer_uuid,
             'kdm_uuid': transfer.kdm_uuid}
            if transfer.state == 'queued':
                self.transfer_information['queue'].append(transfer_object)

    def _device_sync_key_information(self):
        logging.debug('Syncing key info for device %s' % self.device_configuration['id'])
        success = True
        messages = []
        self.sync_status['sync_active'] = True
        self._keys_syncing = True
        key_uuid_response = self.get_key_uuid_list()
        if not key_uuid_response['error_messages']:
            key_info_to_get = []
            for key_uuid in key_uuid_response['key_uuid_list']:
                if key_uuid not in self.key_information or helper_methods.info_needs_updating(self.key_information[key_uuid], cfg.sync_individual_key_info_validity(), True):
                    key_info_to_get.append(key_uuid)

            key_information_response = self.get_key_information(key_info_to_get)
            for key_uuid in key_information_response['key_info_dict']:
                self._add_key(key_uuid, key_information_response['key_info_dict'][key_uuid])

            for key_uuid in set(self.key_information.keys()) - set(key_uuid_response['key_uuid_list']):
                if key_uuid != 'last_updated':
                    with self.key_information_lock:
                        cherrypy.core.contents[self.key_information[key_uuid]['cpl_uuid']].remove_key(self.device_id, key_uuid)
                        del self.key_information[key_uuid]

            with self.key_information_lock:
                self.key_information['last_updated'] = time.time()
        else:
            success = False
            messages.extend(key_uuid_response['error_messages'])
        self._keys_syncing = False
        if self._sync_complete():
            self.sync_status['sync_active'] = False
        return (success, messages)

    def _add_key(self, key_uuid, key_dict):
        with self.key_information_lock:
            if not self.key_information.get(key_uuid, False):
                self.key_information[key_uuid] = {}
            self.key_information[key_uuid]['cpl_title'] = key_dict['cpl_title']
            self.key_information[key_uuid]['cpl_uuid'] = key_dict['cpl_uuid']
            self.key_information[key_uuid]['not_valid_before'] = key_dict['not_valid_before']
            self.key_information[key_uuid]['not_valid_after'] = key_dict['not_valid_after']
            self.key_information[key_uuid]['dnqualifier'] = key_dict['dnqualifier']
            if 'device_serial_number' in key_dict:
                self.key_information[key_uuid]['device_serial_number'] = key_dict['device_serial_number']
            else:
                self.key_information[key_uuid]['device_serial_number'] = None
            self.key_information[key_uuid]['status'] = key_dict['status']
            self.key_information[key_uuid]['clean'] = True
            self.key_information[key_uuid]['last_updated'] = time.time()
            self.key_information[key_uuid]['orphaned'] = True
        cc_kdm_info = {'uuid': key_uuid}
        cc_kdm_info.update(self.key_information[key_uuid])
        cherrypy.engine.publish('ccpush', 'kdm_update', {'kdm': cc_kdm_info,
         'device_uuid': self.device_id})
        cherrypy.core.contents.add_key(self.device_id, key_uuid, key_dict)
        return

    def _delete_key_helper(self, key_uuid):
        _success, _message = self.content_delete_key(key_uuid)
        if _success:
            with self.key_information_lock:
                del self.key_information[key_uuid]
            cherrypy.engine.publish('ccpush', 'kdm_deleted', {'kdm_uuid': key_uuid,
             'device_uuid': self.device_id})
        return (_success, _message)

    @db.close_session
    def content_add_key_helper(self, device_transfer):
        transfer_uuid = device_transfer['id']
        db_transfer = db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_uuid).one()
        db_transfer.state = 'active'
        db_transfer.start = time.time()
        kdm_xml = db_transfer.kdm_xml
        try:
            self.transfer_information['queue'].remove(device_transfer)
        except ValueError:
            pass

        device_transfer['state'] = 'active'
        device_transfer['start_time'] = str(db_transfer.start)
        device_transfer['start_time_string'] = helper_methods.format_timestamp(db_transfer.start)
        self.transfer_information['active'][transfer_uuid] = device_transfer
        try:
            ingest_id = None
            if isinstance(self, gdc.gdc.GDC):
                success, message, ingest_id = self.content_add_key(kdm_xml)
            else:
                success, message = self.content_add_key(kdm_xml)
        except Exception as ex:
            logging.error('Problem in content_add_key_helper on device %s' % self.device_configuration['id'], exc_info=True)
            success = False
            message = _('Unknown error sending KDM: %s') % str(repr(ex))

        try:
            del self.transfer_information['active'][transfer_uuid]
        except KeyError:
            logging.warning('KDM transfer could not be found in active list: %s on device %s' % (transfer_uuid, self.device_configuration['id']), exc_info=True)

        if ingest_id != None:
            db_transfer.device_transfer_uuid = ingest_id
            device_transfer['server_transfer_id'] = ingest_id
        if not isinstance(self, gdc.gdc.GDC):
            if success:
                db_transfer.state = 'success'
                device_transfer['state'] = 'success'
                db_transfer.kdm_xml = None
                kdm = parse_kdm(kdm_xml, load_from_file=False)
                self._add_key(kdm['id'], {'cpl_title': kdm['cpl_text'],
                 'cpl_uuid': kdm['cpl_id'],
                 'not_valid_before': kdm['start_date'],
                 'not_valid_after': kdm['end_date'],
                 'dnqualifier': kdm['dn_qualifier'],
                 'device_serial_number': kdm['device_serial_number'],
                 'status': 'ok'})
            else:
                db_transfer.state = 'failed'
                device_transfer['state'] = 'failed'
        db_transfer.message = message
        device_transfer['message'] = message
        db_transfer.end = time.time()
        device_transfer['end_time'] = str(db_transfer.end)
        device_transfer['end_time_string'] = helper_methods.format_timestamp(db_transfer.end)
        db.Session.commit()
        with self.key_information_lock:
            self.key_information['last_updated'] = None
        return (success, message)

    @db.close_session
    def _device_sync_transfer_information(self):
        logging.debug('Syncing transfer info for device %s' % self.device_configuration['id'])
        success = True
        messages = []
        self.sync_status['sync_active'] = True
        self._transfers_syncing = True
        transfer_ids = self.get_transfer_ids()
        if transfer_ids['error_messages']:
            self._transfers_syncing = False
            if self._sync_complete():
                self.sync_status['sync_active'] = False
            return (False, str(transfer_ids['error_messages']))
        else:
            completed_transfers = self.get_completed_transfers()
            known_dead_transfers = [ transfer['server_transfer_id'] for transfer in completed_transfers.values() if 'server_transfer_id' in transfer ] + self.transfer_ignore_list.keys()
            known_active_transfers = [ transfer['server_transfer_id'] for transfer in self.transfer_information['active'].values() if 'server_transfer_id' in transfer ]
            known_dead_transfers = set(known_dead_transfers)
            known_active_transfers = set(known_active_transfers)
            duplicates = known_active_transfers.intersection(known_dead_transfers)
            if len(duplicates) > 0:
                known_dead_transfers = known_dead_transfers - duplicates
                db.Session.query(db.Transfer).filter(and_(db.Transfer.device_transfer_uuid.in_(duplicates), db.Transfer.destination_device_uuid == self.device_configuration['id'], db.Transfer.state.in_(['success', 'cancelled', 'failed']))).delete(False)
            active_or_unknown_transfers = list(set(transfer_ids['transfers']) - known_dead_transfers)
            if len(active_or_unknown_transfers) > 0:
                transfer_updates = self.get_transfer_info(active_or_unknown_transfers)
                if transfer_updates['error_messages']:
                    self._transfers_syncing = False
                    if self._sync_complete():
                        self.sync_status['sync_active'] = False
                    return (False, str(transfer_updates['error_messages']))
                for transfer in transfer_updates['transfers']:
                    if transfer['server_transfer_id'] in active_or_unknown_transfers:
                        if str(transfer['type']).upper() in ('CPL', 'CLIP', 'DCP', 'KDM', 'SPL'):
                            self.__update_transfer_information(transfer)
                        else:
                            self.transfer_ignore_list[transfer['server_transfer_id']] = True

            requested_time_limit = time.time() - 30
            with self.transfer_information_lock:
                for transfer_id, transfer in self.transfer_information['active'].items():
                    if (transfer['state'] != 'request_sent' or transfer['start_time'] < requested_time_limit) and transfer['server_transfer_id'] not in transfer_ids['transfers'] and (transfer['type'] != 'KDM' or transfer['source'] == None):
                        try:
                            del self.transfer_information['active'][transfer_id]
                        except KeyError:
                            logging.warning('Transfer could not be found in active list: %s on device %s' % (transfer_id, self.device_configuration['id']))

            db_transfers_to_remove = db.Session.query(db.Transfer).filter(and_(db.Transfer.destination_device_uuid == self.device_configuration['id'], not_(or_(db.Transfer.type.in_(['KDM']), db.Transfer.source == None)), not_(db.Transfer.state.in_(['queued',
             'success',
             'cancelled',
             'failed'])), not_(and_(db.Transfer.state == 'request_sent', db.Transfer.start > requested_time_limit)))).all()
            for db_transfer in db_transfers_to_remove:
                if db_transfer.device_transfer_uuid is None or db_transfer.device_transfer_uuid not in transfer_ids['transfers']:
                    db.Session.delete(db_transfer)

            db.Session.commit()
            if not self.transfer_initial_sync:
                self.transfer_initial_sync = True
            self._transfers_syncing = False
            if self._sync_complete():
                self.sync_status['sync_active'] = False
            self.transfer_information['last_updated'] = time.time()
            return (success, messages)

    def __update_transfer_information(self, transfer):
        server_transfer_uuid = transfer['server_transfer_id']
        matching_transfers = [ tmp_transfer for tmp_transfer in self.transfer_information['active'].values() if tmp_transfer['server_transfer_id'] == server_transfer_uuid ]
        progress_timestamp = None
        progress_at_timestamp = transfer['progress']
        if len(matching_transfers) > 1:
            with self.transfer_information_lock:
                for tmp_transfer in matching_transfers:
                    try:
                        del self.transfer_information['active'][tmp_transfer['id']]
                    except KeyError:
                        logging.warning('Transfer could not be found in active list: %s on device %s' % (tmp_transfer['id'], self.device_configuration['id']))

        elif len(matching_transfers) == 1:
            progress_timestamp = matching_transfers[0].get('progress_timestamp', None)
            progress_at_timestamp = matching_transfers[0].get('progress_at_timestamp', transfer['progress'])
        found = False
        try:
            db_transfer = db.Session.query(db.Transfer).filter(and_(db.Transfer.destination_device_uuid == self.device_configuration['id'], db.Transfer.device_transfer_uuid == server_transfer_uuid)).one()
        except NoResultFound:
            pass
        except MultipleResultsFound:
            multi_db_transfers = db.Session.query(db.Transfer).filter(and_(db.Transfer.destination_device_uuid == self.device_configuration['id'], db.Transfer.device_transfer_uuid == server_transfer_uuid))
            try:
                db_transfer = multi_db_transfers.filter(db.Transfer.core == True).one()
            except (NoResultFound, MultipleResultsFound):
                multi_db_transfers.delete(False)
            else:
                found = True

        else:
            found = True

        if not found:
            db_transfer = db.Transfer(uuid=str(uuid.uuid4()), device_transfer_uuid=server_transfer_uuid, destination_device_uuid=self.device_configuration['id'], content_uuid=transfer['content_id'], type=transfer['type'], source=transfer['source'], start=transfer.get('start_time', time.time()), description=transfer['description'])
            db.Session.add(db_transfer)
        dict_transfer = {'id': db_transfer.uuid,
         'start_time_string': helper_methods.format_timestamp(db_transfer.start),
         'start_time': db_transfer.start,
         'type': db_transfer.type,
         'content_id': db_transfer.content_uuid,
         'description': db_transfer.description,
         'source': db_transfer.source,
         'server_transfer_id': db_transfer.device_transfer_uuid,
         'progress_timestamp': progress_timestamp,
         'progress_at_timestamp': progress_at_timestamp}
        db_transfer.state = transfer['state']
        dict_transfer['state'] = transfer['state']
        if 'progress' not in transfer:
            dict_transfer['progress'] = 0
        else:
            dict_transfer['progress'] = transfer['progress']
        if 'message_code' in transfer:
            db_transfer.message_code = transfer['message_code']
        else:
            db_transfer.message_code = None
        dict_transfer['message_code'] = db_transfer.message_code
        if transfer['message'] != None:
            db_transfer.message = transfer['message']
        dict_transfer['message'] = db_transfer.message
        db_transfer.last_modified = time.time()
        dict_transfer['last_modified'] = time.time()
        dict_transfer['server_transfer_id'] = server_transfer_uuid
        if transfer['type'].upper() in ('CPL', 'CLIP', 'DCP') and db_transfer.content_uuid in cherrypy.core.contents and transfer['state'] in ('queued', 'request_sent', 'queued_on_device'):
            cherrypy.core.contents[db_transfer.content_uuid].update_transfer_state(self.device_id, transfer['state'])
        if transfer['state'] in ('active',):
            if dict_transfer['progress'] is not None and dict_transfer['progress_at_timestamp'] is not None and dict_transfer['progress'] - dict_transfer['progress_at_timestamp'] > 0 and dict_transfer['progress_timestamp'] is not None:
                elapsed_time = time.time() - dict_transfer['progress_timestamp']
                time_per_cent = elapsed_time / float(dict_transfer['progress'] - dict_transfer['progress_at_timestamp'])
                remaining = 100 - dict_transfer['progress']
                dict_transfer['eta'] = helper_methods.format_time(int(time_per_cent * float(remaining)))
            else:
                dict_transfer['eta'] = None
                dict_transfer['progress_timestamp'] = time.time()
            with self.transfer_information_lock:
                self.transfer_information['active'].setdefault(dict_transfer['id'], {}).update(dict_transfer)
        elif transfer['state'] in ('queued', 'request_sent', 'queued_on_device', 'paused', 'verifying'):
            dict_transfer['eta'] = TRANSFER_STATES[transfer['state']]
            with self.transfer_information_lock:
                self.transfer_information['active'].setdefault(dict_transfer['id'], {}).update(dict_transfer)
        elif transfer['state'] in ('cancelled', 'failed', 'success'):
            if transfer.get('end_time'):
                db_transfer.end = transfer['end_time']
                if transfer.get('start_time'):
                    db_transfer.start = transfer['start_time']
                    dict_transfer['start_time_string'] = helper_methods.format_timestamp(transfer['start_time'])
                    dict_transfer['start_time'] = transfer['start_time']
            else:
                db_transfer.end = time.time()
            dict_transfer['end_time_string'] = helper_methods.format_timestamp(db_transfer.end)
            dict_transfer['end_time'] = db_transfer.end
            if dict_transfer['end_time'] and dict_transfer['start_time']:
                total_time = int(dict_transfer['end_time'] - dict_transfer['start_time'])
                if total_time > 0:
                    dict_transfer['total_time'] = helper_methods.format_time(total_time)
                else:
                    dict_transfer['total_time'] = _('0 Seconds')
            with self.transfer_information_lock:
                try:
                    del self.transfer_information['active'][dict_transfer['id']]
                except KeyError:
                    pass

            self.content_information['last_updated'] = None
            if db_transfer.content_uuid in cherrypy.core.contents:
                cherrypy.core.contents[db_transfer.content_uuid].force_update(device_uuid=self.device_id)
            self.device_information.last_updated = None
            if transfer['state'] == 'success' and transfer['type'] == 'KDM':
                db_transfer.kdm_xml = None
            if transfer['type'] == 'KDM':
                if transfer['content_id']:
                    filename = transfer['content_id'] + '.xml'
                    tmp_file_path = os.path.join(cfg.lms_library_directory(), 'tmp', filename)
                    if os.path.exists(tmp_file_path):
                        os.remove(tmp_file_path)
        else:
            logging.error('Unknown transfer state %s on device %s' % (str(transfer['state']), self.device_configuration['id']))
        db.Session.commit()
        return

    def _device_sync_content_information(self):
        logging.debug('Syncing content info for device %s' % self.device_configuration['id'])
        success = True
        messages = []
        global_contents = cherrypy.core.contents
        self.sync_status['sync_active'] = True
        self._content_syncing = True
        content_uuid_response = self.get_content_uuid_list()
        if content_uuid_response['error_messages'] == []:
            content_general_info_to_get = []
            content_validation_info_to_get = []
            for content_uuid in content_uuid_response['content_uuid_list']:
                if len(content_uuid) != 36:
                    logging.error('Invalid CPL ID %s returned from device: %s' % (content_uuid, self.device_configuration['id']))
                    continue
                if global_contents.needs_updating(content_uuid):
                    content_general_info_to_get.append(content_uuid)
                if not global_contents.valid_on_device(content_uuid, self.device_id):
                    content_validation_info_to_get.append(content_uuid)

            content_information_response = self.get_content_information(content_general_info_to_get)
            new_content_uuids = set(cherrypy.core.contents.keys()) - set(content_information_response['content_info_dict'].keys())
            titles_last_modified = cherrypy.core.title_service.producer_last_modified()
            if new_content_uuids or titles_last_modified:
                cherrypy.engine.publish('ccpush', 'cpl_titles', {'cpl_uuids': list(new_content_uuids),
                 'titles_last_modified': titles_last_modified})
            for content_uuid in content_information_response['content_info_dict']:
                self._add_content(content_uuid, content_information_response['content_info_dict'][content_uuid])

            content_validation_response = self.get_content_validation_information(content_validation_info_to_get)
            if content_validation_response.get('error_messages', []) != []:
                logging.info('There were non critical errors in getting the content validation information: %s' % ','.join(content_validation_response['error_messages']))
            for content_uuid in content_validation_response['content_validation_dict']:
                self._add_content_validation(content_uuid, content_validation_response['content_validation_dict'][content_uuid])

            for content_uuid in cherrypy.core.contents.get_contents_dict(device_uuid=self.device_id).keys():
                content = cherrypy.core.contents[content_uuid]
                if content.valid_on_device(device_uuid=self.device_id) and content_uuid not in content_uuid_response['content_uuid_list']:
                    content.remove_from_device(device_uuid=self.device_id)

            self.content_information['last_updated'] = time.time()
        else:
            success = False
            messages.extend(content_uuid_response['error_messages'])
        self._content_syncing = False
        if self._sync_complete():
            self.sync_status['sync_active'] = False
        return (success, messages)

    def _add_content(self, content_uuid, content_dict):
        cherrypy.core.contents.update(content_uuid, content_dict)

    def _add_content_validation(self, content_uuid, content_validation_dict):
        global_contents = cherrypy.core.contents
        if content_uuid in global_contents:
            global_contents[content_uuid].update_validation(self.device_id, content_validation_dict)

    def _get_content_keys(self, content_uuid):
        output = []
        for key_uuid, key_information in self.key_information.items():
            if key_uuid == 'last_updated':
                continue
            if key_information['cpl_uuid'] == content_uuid:
                output.append(key_uuid)

        return output

    def _get_content_playlists(self, content_uuid):
        output = []
        if hasattr(self, 'playlist_information'):
            for playlist_uuid, playlist_information in self.playlist_information.items():
                if playlist_uuid == 'last_updated':
                    continue
                if content_uuid in playlist_information['content_ids']:
                    output.append(playlist_uuid)

        return output

    def _device_get_key_information(self, key_ids, content_ids, hide_expired):
        """
        gets device specific key information
        
        format to go with other formats
        
        {
            key_id: {
                    key info
                }
        }
        """
        output = {}
        for key_id, key_information in self.key_information.items():
            if key_id == 'last_updated':
                continue
            if hide_expired:
                if key_information['not_valid_after'] < time.time():
                    continue
            if key_ids != [] and key_id not in key_ids:
                continue
            if content_ids != [] and key_information['cpl_uuid'] not in content_ids:
                continue
            output[key_id] = key_information

        return output

    def _device_get_transfer_information(self, active_only):
        if active_only:
            return {'active': self.transfer_information['active']}
        else:
            return {'queue': self.transfer_information['queue'],
             'active': self.transfer_information['active'],
             'completed': self.get_completed_transfers()}

    def content_clear_transfer_history_helper(self):
        """
        Clears the transfer history from the device.
        """
        deleted_transfers = []
        completed_transfers = self.get_completed_transfers()
        if len(completed_transfers) != 0:
            if not self.device_status['alive']:
                return (False, _('Error communicating with device: %s') % self.device_configuration['screen_identifier'], deleted_transfers)
            try:
                success, message = self.content_clear_transfer_history()
            except NotImplementedError:
                transfer_ids = self.get_transfer_ids()
                if transfer_ids['error_messages'] != []:
                    return (False, str(transfer_ids['error_messages']))
                for transfer_id, transfer in completed_transfers.items():
                    if transfer['server_transfer_id'] not in transfer_ids['transfers']:
                        deleted_transfers.append(transfer_id)
                        try:
                            del completed_transfers[transfer_id]
                        except KeyError:
                            logging.warning('Transfer could not be found in completed list: %s on device %s' % (transfer_id, self.device_configuration['id']))

                db_transfers_to_remove = db.Session.query(db.Transfer).filter(and_(db.Transfer.destination_device_uuid == self.device_configuration['id'], not_(db.Transfer.type.in_(('KDM', 'SPL'))), db.Transfer.state.in_(['success', 'failed', 'cancelled'])))
                for db_transfer in db_transfers_to_remove:
                    if db_transfer.device_transfer_uuid is None or db_transfer.device_transfer_uuid not in transfer_ids['transfers']:
                        db.Session.delete(db_transfer)

                if completed_transfers:
                    success = False
                    message = _('Transfer history could not be completely cleared')
                else:
                    success = True
                    message = _('Transfer history cleared')
            else:
                for transfer_id in completed_transfers.keys():
                    deleted_transfers.append(transfer_id)
                    db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_id).delete(False)

            db.Session.commit()
        else:
            success = True
            message = _('Transfer history cleared')
        return (success, message, deleted_transfers)

    def content_delete_helper(self, content_id, sleep_between_requests = False):
        """
        Deletes the specified content from the device
        @param content_id              UUID - content identifiers
        """
        if sleep_between_requests == True:
            success, message = self.content_delete(content_id, True)
        else:
            success, message = self.content_delete(content_id)
        if success:
            self.device_information.last_updated = 0
            if content_id in cherrypy.core.contents:
                cherrypy.core.contents[content_id].remove_from_device(self.device_id)
        return (success, message)

    @db.close_session
    def transfer_cancel_helper(self, transfer_id):
        """
        Cancels the specified transfer from the device
        @param transfer_id              UUID - transfer identifiers
        """
        success = False
        try:
            db_transfer = db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_id).one()
            success, message = self.content_cancel_transfer(db_transfer.device_transfer_uuid)
        except NoResultFound:
            message = 'could not find transfer of id %s to cancel' % transfer_id
            logging.error(message)

        if success:
            with self.transfer_information_lock:
                if transfer_id in self.transfer_information['active']:
                    transfer = deepcopy(self.transfer_information['active'][transfer_id])
                    transfer['state'] = 'cancelled'
                    transfer['message'] = _('Transfer cancelled')
                    transfer['message_code'] = 6
                    transfer['end_time'] = int(time.time())
                    transfer['end_time_string'] = helper_methods.format_timestamp(int(time.time()))
                    del self.transfer_information['active'][transfer_id]
            db_transfer.state = 'cancelled'
            db_transfer.end = int(time.time())
            db_transfer.message_code = 6
            db_transfer.message = 'Transfer cancelled'
            db.Session.commit()
            self.content_information['last_updated'] = None
            if db_transfer.content_uuid in cherrypy.core.contents:
                cherrypy.core.contents[db_transfer.content_uuid].force_update(device_uuid=self.device_id)
            self.device_information.last_updated = None
        return (success, message)

    @db.close_session
    def transfer_helper(self, transfer_queue_item, connection_details, content_validation_info):
        """
        Ingests content onto the device.
        @param transfer_queue_item           DICT     - queue item to be updated for tracking.
        @param source_url                    STRING   - URL the destination server can find the content at (ftp:// or local mount)
        @param content_validation_info       DICT     - validation info of the cpl from source server...
        """
        success = True
        already_exists = False
        transfer_id = None
        message = None
        if cherrypy.core.contents.valid_on_device(transfer_queue_item['content_id'], self.device_id, CS.VALID):
            already_exists = True
            message = _('CPL already exists and is valid')
            message_code = 0
        if content_validation_info == None or content_validation_info['validation_code'] not in [CS.VALID, CS.MISSING_ASSETS, CS.CORRUPT] or connection_details['ingest_path'] == None:
            success = False
            if connection_details['ingest_path'] == None:
                message = _('Cannot determine ingest location of content. CPL is either not on the specified source or is in an invalid state')
                message_code = 1
            elif content_validation_info != None:
                message = _('CPL is either not on the specified source or is in an invalid state. CPL state: %s') % content_validation_info.get('validation_code', 'not available')
                message_code = None
            elif not transfer_queue_item['source']:
                message = _('Could not find a valid source to transfer the CPL from')
                message_code = 2
            else:
                message = _('CPL is either not on the specified source or is in an invalid state. CPL state: %s') % 'not available'
                message_code = None
        else:
            not_enough_space = False
            if self.device_information.has('storage_available'):
                try:
                    not_enough_space = int(content_validation_info['cpl_size']) > int(self.device_information.get('storage_available'))
                except ValueError:
                    logging.warn('Could not establish if server has enough free space for transfer, attempting anyway')

            if not_enough_space:
                success = False
                message = _('There is not enough free space to transfer the CPL')
                message_code = 3
            else:
                try:
                    success, message, transfer_id = self.content_transfer(connection_details, transfer_queue_item['description'], transfer_queue_item['content_id'])
                    if message == _('Transfer started'):
                        message_code = 4
                    else:
                        message_code = None
                except Exception as ex:
                    success = False
                    message = _('Error starting CPL transfer: %s') % str(repr(ex))
                    message_code = None
                    logging.error('Error initiating content transfer on device %s' % self.device_configuration['id'], exc_info=True)

        transfer = db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_queue_item['id']).one()
        with self.transfer_information_lock:
            try:
                self.transfer_information['queue'].remove(transfer_queue_item)
            except ValueError:
                logging.error('Transfer no longer exists %s on device %s' % (str(transfer_queue_item), self.device_configuration['id']))
                message = _('Unable to find transfer request')
                message_code = 5

            transfer.message = message
            transfer.message_code = message_code
            transfer_queue_item['message'] = message
            transfer.start = self.device_status['current_time']
            transfer_queue_item['start_time'] = transfer.start
            transfer_queue_item['start_time_string'] = helper_methods.format_timestamp(transfer.start)
            if already_exists:
                transfer.end = time.time()
                transfer.state = 'success'
            elif success:
                transfer.device_transfer_uuid = str(transfer_id) if transfer_id is not None else None
                transfer_queue_item['server_transfer_id'] = str(transfer_id) if transfer_id is not None else None
                transfer.state = 'request_sent'
                transfer_queue_item['state'] = 'request_sent'
                transfer_queue_item['progress'] = 0
                self.transfer_information['active'].setdefault(transfer_queue_item['id'], {}).update(transfer_queue_item)
            else:
                transfer.end = time.time()
                transfer.state = 'failed'
                transfer_queue_item['end_time_string'] = helper_methods.format_timestamp(transfer.end)
        db.Session.commit()
        return (success, message)

    def _sync_complete(self):
        if not self._playlists_syncing and not self._schedules_syncing and not self._transfers_syncing and not self._content_syncing:
            sync_complete = not self._keys_syncing
            self.sync_status['last_updated'] = sync_complete and time.time()
        return sync_complete

    def get_completed_transfers(self):
        completed_transfers = db.Session.query(db.Transfer).filter(and_(db.Transfer.destination_device_uuid == self.device_configuration['id'], db.Transfer.state.in_(['success', 'cancelled', 'failed']))).all()
        completed_transfers_dict = {}
        for transfer in completed_transfers:
            transfer_dict = transfer.to_dict()
            completed_transfers_dict[transfer.uuid] = transfer_dict

        return completed_transfers_dict

    def get_supported_patterns(self):
        return []

    def monitor_device_state(self, sync_content = True):
        if sync_content:
            cherrypy.engine.publish('content_device_syncing_started')
        super(Content, self).monitor_device_state(sync_content)
        if sync_content:
            if isinstance(self, core.devices.base.mount_point.MountPoint) and (self.sync_status['sync_active'] or self.drive_storage['last_updated'] == None):
                pass
            elif isinstance(self, core.devices.content.aamLMS.aamLMS.AAMLMS) and self.sync_status['content_scan_active']:
                pass
            else:
                if not isinstance(self, core.devices.content.ftp_drive.ftp_drive.FTPDrive) and not isinstance(self, core.devices.content.watchfolder.watchfolder.Watchfolder):
                    if helper_methods.info_needs_updating(self.transfer_information, cfg.sync_transfer_info_validity.get()):
                        self._execute_action(SyncAction(self._device_sync_transfer_information))
                if helper_methods.info_needs_updating(self.content_information, cfg.sync_content_info_validity.get()):
                    self._execute_action(SyncAction(self._device_sync_content_information))
                if helper_methods.info_needs_updating(self.key_information, cfg.sync_key_info_validity()):
                    self._execute_action(SyncAction(self._device_sync_key_information))
            cherrypy.engine.publish('content_device_syncing_complete')
        return
# okay decompyling ./core/devices/base/content.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:30 CST
