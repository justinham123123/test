# 2017.08.13 21:48:38 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\probe.py
from datetime import datetime, timedelta
from serv.core.devices.base.monitoring import Monitor
import cherrypy
import calendar
import abc

class Probe(Monitor):
    __metaclass__ = abc.ABCMeta
    PROBE_RETRY_TIMEOUT = timedelta(hours=6)

    def __init__(self, *args, **kwargs):
        super(Probe, self).__init__(*args, **kwargs)
        self.last_collection = 0
        self.data = {}

    def update(self):
        utc_now = datetime.utcnow()
        utc_next = datetime.fromtimestamp(self.last_collection) + self.PROBE_RETRY_TIMEOUT
        update = False
        data = None
        if utc_now >= utc_next:
            self.last_collection = int(calendar.timegm(utc_now.utctimetuple()))
            success, data = self.get_logs(utc_now.date())
            if success and data != self.data:
                self.data = data
                update = True
        return (update, data)

    def get_logs(self, today):
        pass

    def monitor_device_state(self, *args, **kwargs):
        super(Probe, self).monitor_device_state(*args, **kwargs)
        update, data = self.update()
        if update:
            cherrypy.engine.publish('ccpush', 'device_monitoring_update', {'device_uuid': self.device_id,
             'monitoring_data': data})
# okay decompyling ./core/devices/base/probe.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:39 CST
