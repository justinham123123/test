# 2017.08.13 21:48:38 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\pos.py
import abc
import datetime
import logging
import time
import cherrypy
from serv.core.devices.base.monitoring import Monitor
from serv.configuration import cfg
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities import helper_methods
from serv.lib.utilities.action import SyncAction
from serv.storage.database.primary import database as db

class POS(Monitor):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def get_schedule(self, start_date, end_date, complex_ids):
        """
        Gets a schedule of films for a cinema theatre
        """
        raise NotImplementedError, 'Abstract API class; use concrete implementation'

    def __init__(self, id, device_info, core = None):
        super(POS, self).__init__(id, device_info)
        self.auto_sync = True
        self.force_sync = False
        self.pos_timestamp = {'last_updated': None}
        if core:
            self.pos = core.pos.service
        else:
            self.pos = cherrypy.core.pos.service
        return

    @db.close_session
    def _device_sync_pos_information(self):
        logging.debug('Syncing POS info for device %s' % self.device_configuration['id'])
        self.pos.pos_devices_syncing[self.device_id] = True
        messages = []
        success = False
        start = datetime.date.today()
        end = start + datetime.timedelta(days=21)
        if not cfg.pos_enabled():
            self.pos_timestamp['last_updated'] = time.time()
            self.pos.pos_devices_syncing[self.device_id] = False
            return (True, messages)
        try:
            logging.info(_('Updating POS feed: %s') % self.device_configuration['ip'])
            pos_info = self.get_schedule(start, end, self.pos.get_complex_identifiers())
            pos_info['device'] = self.device_id
            pos_info['source'] = self.pos.core.get_pretty_name(self.device_id)
            pos_info['start'] = start
            pos_info['end'] = end
            allow_empty = pos_info.get('allow_empty', False)
            update_success, update_message, update_status = self.pos.update_pos_items(pos_info, allow_empty=allow_empty)
            if 'raw_input' in pos_info:
                self.pos.persist_raw_feed(pos_info['raw_input'], self.device_configuration['ip'])
            messages = pos_info['messages']
            if update_message:
                if update_success:
                    messages.append({'type': 'success',
                     'message': update_message})
                else:
                    messages.append({'type': 'error',
                     'message': update_message})
            success = update_success and pos_info['success']
        except Exception:
            success = False
            logging.error('Error syncing POS feed for device %s' % self.device_id, exc_info=True)
            messages.append({'type': 'error',
             'message': _('Unknown error getting schedules from the POS feed %s') % self.device_configuration['type']})
        finally:
            self.pos_timestamp['last_updated'] = time.time()
            self.pos.pos_devices_syncing[self.device_id] = False

        return (success, messages)

    def monitor_device_state(self, *args, **kwargs):
        super(POS, self).monitor_device_state(*args, **kwargs)
        if (self.auto_sync or self.force_sync) and helper_methods.info_needs_updating(self.pos_timestamp, cfg.sync_pos_info_validity.get()):
            self.force_sync = False
            self._execute_action(SyncAction(self._device_sync_pos_information))

    def get_device_status(self):
        return {'error_messages': []}

    def get_device_information(self):
        return {'error_messages': []}

    def get_device_version_information(self):
        return {'error_messages': []}
# okay decompyling ./core/devices/base/pos.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:38 CST
