# 2017.08.13 21:48:32 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\monitoring.py
"""
The base functionality that every device must support.
Provides status and monitoring functionality.
"""
import datetime
import Queue
import time
import logging
import errno
import socket
import difflib
import abc
from urllib2 import URLError
import cherrypy
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.lib.network.snmp import SNMPTimeout
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities.action import SyncAction
from serv.core.devices.sms.christie.christie_utils import Timeout
from serv.core.devices.base.cache import DeviceCache
from serv.core.devices.base.normalizer import DefaultNormalizer
from serv.storage.database.primary import database as db
MESSAGE_HISTORY = 100

class Monitor(DeviceCache):
    __metaclass__ = abc.ABCMeta

    def __init__(self, id, device_info):
        super(Monitor, self).__init__()
        self.device_id = id
        self.device_configuration = device_info
        self.normalizer = DefaultNormalizer()
        self.device_status.update({'status': 'unknown',
         'error_messages': {},
         'alive': False,
         'confirmed': False,
         'last_assess_time': 0})
        self.device_status_last_update = 0
        self.action_queue = Queue.Queue()
        self.deleting_device = False
        self.cycle_action_handler = False
        self.messages = {}
        self.message_list = []
        self.first_sync = False

    @abc.abstractmethod
    def get_device_status(self):
        """
        Returns the status of the device
        """
        raise NotImplementedError, 'Abstract API class; use concrete implementation'

    @abc.abstractmethod
    def get_device_information(self):
        """
        Returns information regarding the device
        """
        raise NotImplementedError, 'Abstract API class; use concrete implementation'

    @abc.abstractmethod
    def test_management_connection(self):
        """
        Checks that the communication method used to interact with the device is functioning correctly
        :returns: tuple containing a bool which is shows the success of the test and a str containing any error message
        """
        raise NotImplementedError

    def reboot(self):
        """
        Reboots the device
        @rtype: DICT
        @return: {
            error_messages    -    LIST errors executing the reboot
        }
        """
        pass

    def server_performance_metrics(self):
        """
        Returns a list of strings representing the current server states:
        (i.e., playback, scheduled mode on, loop mode, ingesting, 3d mode, etc.)
        """
        return {}

    def _execute_action(self, action):
        """
        Records the amount of time it takes to perform a function
        """
        start = time.time()
        message = ''
        success = False
        try:
            success, message = action()
            if action.report_messages and (not isinstance(success, bool) or not isinstance(message, str) and not isinstance(message, unicode)):
                raise Exception('Action Function returned wrong type, success is [{success_type}] should be Boolean, message is [{message_type}] should be String'.format(success_type=type(success), message_type=type(message)))
            if action.name in self.device_status['error_messages']:
                del self.device_status['error_messages'][action.name]
            if not success:
                logging.error('Error in running the function %s: %s' % (action.name, message))
            if self.device_status['confirmed']:
                self.device_status['alive'] = True
        except (IOError, URLError, Timeout) as ex:
            success = False
            self.device_status['alive'] = False
            self.device_status['current_time'] = None
            message = _('Error communicating with device')
            logging.error('Error communicating with device : %s ' % str(self.device_configuration['id']), exc_info=True)
        except socket.error as v:
            success = False
            errorcode = v[0]
            if errorcode in (errno.ECONNREFUSED,
             errno.ETIMEDOUT,
             errno.ECONNRESET,
             errno.ENETDOWN,
             errno.ENETUNREACH) or v == socket.timeout:
                self.device_status['alive'] = False
                self.device_status['current_time'] = None
                message = _('Error communicating with device')
            else:
                logging.error('Connection exception while trying to execute: [%s]  [%s]' % (str(action.name), str(self.device_configuration['id'])), exc_info=True)
                message = str(repr(v))
                self.device_status['error_messages'][action.name] = message
        except SNMPTimeout:
            success = False
            message = _('Error communicating with device')
            self.device_status['confirmed'] = False
            logging.error('Timeout in connecting to the Projector..', exc_info=True)
        except Exception as ex:
            success = False
            message = str(repr(ex))
            logging.error('Exception while trying to execute: [{name}] [Device: {id}]'.format(name=action.name, id=self.device_configuration['id']), exc_info=True)
            self.device_status['error_messages'][action.name] = message
        finally:
            if action.report_messages:
                self.__append_message(action.action_id, success, message)
            if self.device_status['alive'] and not self.device_status['error_messages']:
                self.device_status['status'] = 'ok'
            else:
                self.device_status['status'] = 'error'

        return

    def monitor_device_state(self, *args, **kwargs):
        """
        Synchronises device states depending on what interfaces a device implements
        """
        if helper_methods.info_needs_updating(self.device_information, cfg.sync_device_info_validity.get()):
            self._execute_action(SyncAction(self._device_sync_device_information))
        if self.status_needs_updating():
            self._execute_action(SyncAction(self._device_sync_device_status))
        if self.first_sync:
            cherrypy.engine.publish('device_first_synced', self.device_id)
            self.first_sync = False

    def status_needs_updating(self):
        return self.device_status_last_update + cfg.sync_device_state_validity.get() < time.time()

    def _device_sync_device_information(self):
        logging.debug('Syncing device info [%s]' % self.device_configuration['id'])
        success = True
        messages = []
        device_information = self.get_device_information()
        self.handle_api_update(device_information)
        detected_model = device_information.get('model')
        if detected_model:
            self._update_device_model(detected_model)
        self.device_information['last_updated'] = time.time()
        return (success, messages)

    @db.close_session
    def _update_device_model(self, detected_model):
        """
        Update the device's model information if necessary
        """
        category = self.device_configuration['category']
        make = self.device_configuration['type']
        try:
            matched_model = self._match_device_model(detected_model, category, make)
            if matched_model not in ('default', self.device_configuration.get('model', 'default')):
                cherrypy.core.configuration_service.set_model(self.device_id, matched_model)
                self.device_configuration['model'] = matched_model
                cherrypy.engine.publish('ccpush', 'device_information_update', {'device_uuid': self.device_id,
                 'device_information': {'device_specification': {'category': category,
                                                                 'make': make,
                                                                 'model': matched_model}}})
        except (ValueError, KeyError):
            logging.debug('Could not match device model, falling back to default (detected "%s" for make "%s")', detected_model, make)

    def _match_device_model(self, detected_model, category, make):
        """
        Match the model string reported by the API against our list
        of know models and take the one with the minimum Levenshtein distance.
        :param detected_model: The model string detected by API or SNMP
        :param category: Device category string
        :param make: Device type string
        :raises: ValueError if no matching model could be found.
                 KeyError if category or make is unknown to core.
        """
        try:
            screen_device_metadata = cherrypy.core.screen_device_metadata
            known_models = [ m['model'].lower() for m in screen_device_metadata[category][make] ]
            matching_models = difflib.get_close_matches(detected_model.lower(), known_models, 1)
            if len(matching_models) != 1:
                raise ValueError('Could not find matching model for "%s"' % detected_model)
            return matching_models[0]
        except KeyError:
            raise KeyError('Device of category "%s" and type "%s" not supported' % (category, make))

    def _device_sync_device_status(self):
        logging.debug('Syncing device status [%s]' % self.device_configuration['id'])
        success = True
        messages = []
        status = self.get_device_status()
        if status['error_messages'] == []:
            for k, v in status.iteritems():
                if k != 'error_messages':
                    self.device_status[k] = v

            self.device_status_last_update = time.time()
        else:
            success = False
            messages.extend(status['error_messages'])
        self.device_status['last_updated'] = time.time()
        return (success, messages)

    def __append_message(self, action_id, success, message):
        if action_id not in self.message_list:
            self.message_list.append(action_id)
        self.messages[action_id] = {'success': success,
         'action_id': action_id,
         'time': time.time(),
         'message': message}
        if len(self.message_list) > MESSAGE_HISTORY:
            remove_us = []
            for id in reversed(self.message_list):
                if self.messages.has_key(id) and datetime.datetime.fromtimestamp(self.messages[id]['time']) < datetime.datetime.now() - datetime.timedelta(days=1):
                    remove_us.append(id)

            for id in remove_us:
                self.message_list.remove(id)
                del self.messages[id]

    def push_action_stack(self, action):
        """Pushes an action onto the action queue for execution"""
        self.action_queue.put(action)

    def clear_action_queue(self):
        with self.action_queue.mutex:
            self.action_queue.queue.clear()

    def handle_action_queue(self):
        """Runs through the action queue, executing the next action"""
        self.cycle_action_handler = False
        while not self.deleting_device and not cherrypy.engine.shutdown_servers and not self.cycle_action_handler:
            action = self.action_queue.get(True)
            if self.device_configuration['enabled']:
                self._execute_action(action)
            else:
                self.__append_message(action.action_id, False, _('Device must be enabled'))
            self.action_queue.task_done()

    def ready_to_check(self):
        if self.device_status['last_assess_time'] + 600 > time.time():
            return False
        else:
            self.device_status['last_assess_time'] = time.time()
            return True

    def shutdown(self):
        """
        When a shutdown signal is received, this function is pushed onto the
        action queue to cause it to cycle and thus shut down gracefully.
        """
        return (True, '')
# okay decompyling ./core/devices/base/monitoring.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:33 CST
