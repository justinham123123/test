# 2017.08.13 21:48:03 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\content_api.py
import cherrypy
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.content_service import ContentService
import ujson
import serv.lib.cherrypy.custom_tools.all

class ContentAPI(API):
    """
    HTTP API for managing content on digital cinema devices
    """

    def __init__(self, core):
        super(ContentAPI, self).__init__(core)
        self.service = ContentService(core)
        cherrypy.engine.publish('cclisten', 'request_content_uuids', self.request_content_uuids)
        cherrypy.engine.publish('cclisten', 'content_information', self.request_content_information)

    def request_content_uuids(self, payload):
        """
        Handles `config_synced` event from Circuit Core.
        
        Sent as part of the start up sync. Core sends Circuit Core all content
        UUIDs, and device information.
        
        :note:  On a Core start up this might not return much info, as devices
                are stil being sync. This is ok as we'll get all that content
                when it's added to the global content store. We still need to
                perform this sync in the case of a Circuit Core restart.
        """
        device_ids = payload['data']['device_ids']
        content_data, device_errors = self.service.content(device_ids)
        cherrypy.engine.publish('ccpush', 'content_uuids', {'content_information': content_data}, target=payload['url'])
        kdm_info, errors = self.service.keys()
        cherrypy.engine.publish('ccpush', 'kdm_information', {'kdm_information': kdm_info}, target=payload['url'])

    def request_content_information(self, payload):
        """
        Handles `content_information` event from Core.
        """
        content_uuids = payload['data']
        content_info, errors = self.service.content(content_ids=content_uuids)
        cherrypy.engine.publish('ccpush', 'content_information', {'content_information': content_info}, target=payload['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def reload_key_from_lms(self, key_uuid, device_uuid):
        """
        Retrieve the KDM XML for the given key_uuid from the LMS and add it to the specified device.
        
        .. http_method_uri:: content/reload_key_from_lms
            :category: Content
        
        :param key_uuid: KDM identifier
        :param device_uuid: Device identifier
        :type key_uuid: String
        :type device_uuid: String
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/reload_key_from_lms?key_uuid="48f908b4-a2c3-4c52-b921-3a08e6b0d014"&device_uuid="12afa89f-0c69-47d0-a9ba-2b4762d42a2d"
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "message" : "KDM 48f908b4-a2c3-4c52-b921-3a08e6b0d014 already exists on 1",
                            "type" : "success"
                        }
                    ],
                "data":{}
            }
        
        """
        messages = self.service.reload_key_from_lms(key_uuid, device_uuid)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['keys'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def add_key(self, key, device_id = None, add_to_lms = True, source = 'lms'):
        """
        Add a KDM to a device.
        
        .. http_method_uri:: content/add_key
            :category: Content
        
        :param key: KDM xml
        :param device_id: Device identifier *(optional)*
        :param add_to_lms: Flag specifying whether KDM should also be added to the LMS *(optional) (default=True)*
        :param source: KDM source identifier *(optional) (default='LMS')*
        :type key: String
        :type device_id: String
        :type add_to_lms: Boolean
        :type source: String
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/add_key?key="[XML]"&device_id="12afa89f-0c69-47d0-a9ba-2b4762d42a2d"
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "message" : "KDM 48f908b4-a2c3-4c52-b921-3a08e6b0d014 queued for uploading to 2",
                            "type" : "success"
                        }
                    ],
                "data":{}
            }
        
        """
        kdm_id, messages = self.service.add_key(key, device_id, add_to_lms, source)
        return {'data': {'kdm_id': kdm_id},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['transfer_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def retry_key_transfer(self, transfer_uuid):
        """
        Re-try specified KDM transfer.
        
        .. http_method_uri:: content/retry_key_transfer
            :category: Content
        
        :param transfer_uuid: Transfer identifier
        :type transfer_uuid: String
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/retry_key_transfer?transfer_uuid="12afa89f-0c69-47d0-a9ba-2b4762d42a2d"
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "message" : "KDM 48f908b4-a2c3-4c52-b921-3a08e6b0d014 queued for uploading to 2",
                            "type" : "success"
                        }
                    ],
                "data":{}
            }
        
        """
        messages = self.service.retry_key_transfer(transfer_uuid)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def cancel_transfers(self, device_id, transfer_ids = []):
        """
        Cancel transfers to a device.
        
        .. http_method_uri:: content/cancel_transfers
            :category: Content
        
        :param device_id: Device identifier
        :param transfer_ids: List of Transfer identifiers
        :type device_id: String
        :type transfer_ids: JSON
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/cancel_transfers?device_id="12afa89f-0c69-47d0-a9ba-2b4762d42a2d"&transfer_ids=["48f908b4-a2c3-4c52-b921-3a08e6b0d014"]
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "message" : "Transfer cancel request sent to 6. Transfer Id: [5126aabe-3366-4d1e-8ee4-aeb1ed7f350e]",
                            "type":"success"
                        }
                    ],
                "data":
                    {
                        "action_id":"7e372ff3-ca01-4df6-ac52-cdca57632ce8"
                    }
            }
        
        """
        action_id, messages = self.service.cancel_transfers(device_id, transfer_ids)
        return {'data': {'action_id': action_id} if action_id is not None else {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def clear_transfer_history(self, device_ids = []):
        """
        Clear the transfer history on a device.
        
        .. http_method_uri:: content/clear_transfer_history
            :category: Content
        
        :param device_ids: List of device identifiers *(optional)*
        :type device_ids: JSON
        
        :returns: Status Message and list of cleared transfer identifiers (JSON)
        
        Example Request::
        
           /content/clear_transfer_history?device_ids=["12afa89f-0c69-47d0-a9ba-2b4762d42a2d"]
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "message":"Transfer history cleared for: 2",
                            "type":"success"
                        }
                    ],
                "data":
                    {
                        "a6b2126a-a17b-449d-af5e-78ceda0b0976":
                            [
                                "d0b8c0d3-b132-4d18-bd03-368acf2e5953",
                                "5cc42125-79c6-4b44-b6e3-6cae5a5a7410",
                                "78b67744-4eae-4b8c-b09f-0c83439d52c9",
                                "9ce69f22-c2f1-4439-a60b-c0a8c3124b1a",
                            ]
                        }
                    }
        
        """
        cleared_transfers, messages = self.service.clear_transfer_history(device_ids)
        return {'data': cleared_transfers,
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def scan_content(self, content_id, device_id):
        """
        Scan the content's directory and return detailed information for the CPL on the device.
        
        .. http_method_uri:: content/scan_content
            :category: Content
        
        :param content_id: CPL identifier
        :param device_id: Device identifier
        :type content_id: String
        :type device_id: String
        
        :returns: State of the selected CPl on the selected device (JSON)
        
        Example Request::
        
           /content/scan_content?content_id="12afa89f-0c69-47d0-a9ba-2b4762d42a2d"&device_id="9ce69f22-c2f1-4439-a60b-c0a8c3124b1a"
        
        Example Response::
        
            {
                "messages":[],
                "data":{
                    "e2cedea0-c9b9-4f6b-90d2-ab168bef1ce6.mxf":{
                        "status":"valid",
                        "reel":1,
                        "message":"The asset file is valid: [e2cedea0-c9b9-4f6b-90d2-ab168bef1ce6.mxf]",
                        "type":"Picture",
                        "name":"CPL XML"
                    },
                    "2264a761-bf2b-4266-a6b3-5982a8d061be.mxf":{
                        "status":"valid",
                        "reel":1,
                        "message":"The asset file is valid: [2264a761-bf2b-4266-a6b3-5982a8d061be.mxf]",
                        "type":"Sound",
                        "name":"CPL XML"
                    }
                }
            }
        
        """
        output = {'data': {},
         'messages': []}
        content, message = self.service.scan_content(content_id, device_id)
        if content is not None:
            output['data'] = content
            output['data']['error'] = False
        else:
            output['data']['error'] = True
        if message is not None:
            output['messages'] = [message]
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['content_ids', 'device_ids', 'requested_data_items'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def content(self, device_ids = [], content_ids = []):
        """
        Return content information for some content(s) on some device(s).
        
        .. http_method_uri:: content/content
            :category: Content
        
        :param content_ids: List of content identifiers *(optional)*
        :param device_ids: List of device identifiers *(optional)*
        :type content_ids: JSON
        :type device_ids: JSON
        
        :returns: Content information (JSON)
        
        Example Request::
        
           /content/content?device_ids=["94699394-4ffd-45be-bbcf-16970890945b"]&
               content_ids=["870c714f-678c-4069-ba92-7913e286912b"]
        
        Example Response::
        
            {
                "data": {
                    "870c714f-678c-4069-ba92-7913e286912b": {
                        "aspect_ratio": "1.90",
                        "duration_in_frames": 240,
                        "devices": {
                            "94699394-4ffd-45be-bbcf-16970890945b": { }
                        }
                    }
                },
                "messages": [ ]
            }
        
        """
        content_data, device_errors = self.service.content(device_ids, content_ids)
        return {'data': content_data,
         'messages': device_errors}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def pattern(self, device_ids = []):
        """
        Get the patterns supported by the system.
        
        .. http_method_uri:: content/pattern
            :category: Content
        
        :param device_ids: List of device identifiers *(optional)*
        :type device_ids: JSON
        
        :returns: Pattern information (JSON)
        
        Example Request::
        
           /content/pattern?device_ids=["94699394-4ffd-45be-bbcf-16970890945b"]
        
        Example Response::
        
            {
                "data": [{
                    "description": "Black",
                    "content_kind": "pattern",
                    "playback_mode": "two_d",
                    "edit_rate": [24,1],
                    "duration_in_seconds": 2,
                    "duration_in_frames": 48
                }],
                "messages": []
            }
        
        """
        patterns = self.service.pattern(device_ids=device_ids)
        return {'data': patterns['data'],
         'messages': patterns['messages']}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['cpl_metadata'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save(self, cpl_metadata):
        """
        Save/update meta data for a CPL.
        
        .. http_method_uri:: content/save
            :category: Content
        
        :param cpl_metadata: CPL meta data dictionary
        :type cpl_metadata: JSON
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/save?cpl_metadata={
                "credits_offset": null,
                "last_modified": 1361275011.927,
                "uuid": "198798f1-f059-4ecb-9695-055432744c53",
            }
        
        
        Example Response::
        
            {
                "data": {},
                "messages": [{
                    'type': 'success',
                    'content_id': "198798f1-f059-4ecb-9695-055432744c53",
                    'message': 'Metadata updated for CPL 198798f1-f059-4ecb-9695-055432744c53'
                }]
            }
        
        """
        uuid, message = self.service.save(cpl_metadata)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['content_ids', 'device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, content_ids, device_ids = []):
        """
        Delete specified content(s) from device(s).
        
        .. http_method_uri:: content/delete
            :category: Content
        
        :param content_ids: List of content identifiers
        :param device_ids: List of device identifiers *(optional)*
        :type content_ids: JSON
        :type device_ids: JSON
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/delete/?contentIds=["ebd70a22-32c6-4e3b-bfba-efb8f2c38a71"]&
               device_ids=["94699394-4ffd-45be-bbcf-16970890945b"]
        
        Example Response::
        
           {
             "data": { },
             "messages": [
               {
                 "content_id": "cf36fa54-be7b-44fd-9fa8-a18ae9a0498b",
                 "device_id": "cbdcadbe-d7b8-4709-878a-c75d0de80917",
                 "type": "action",
                 "message": "Content [LQ731-PD101678_ADV_F_EN-XX_UK_51_2K_CSA_20110505_DGN_i3D-ngb_OV] has been marked for deletion on device [cbdcadbe-d7b8-4709-878a-c75d0de80917]",
                 "action_id": "781e7911-2c48-4199-a075-551816e23fbc"
               }
             ]
           }
        
        """
        messages = self.service.delete(content_ids, device_ids)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['key_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_key_check(self, device_id, key_ids):
        """
        Verify that deleting the given KDMs will not affect current schedule.
        
        .. http_method_uri:: content/delete_key_check
            :category: Content
        
        :param device_id: Device identifier
        :param key_ids: List of KDM identifiers
        :type device_id: String
        :type key_ids: JSON
        
        :returns: Status of CPL(s) associated to given KDMs (JSON)
        
        Example Request::
        
           /core/content/delete_key_check?device_id=62bd33b5-9c08-4b70-9541-2fa28e9a66a3&
                key_ids=["7d7b4d1de-9177-4419-abb3-1920fe562571"]
        
        Example Response::
        
           {
             "data": {
                 "cf36fa54-be7b-44fd-9fa8-a18ae9a0498b":{
                     "cpl_title": "Test CPL Encrypted",
                     "keys": [
                         "fefc1d4b-83d2-453b-8d51-780102ecba5c"
                     ]
                 }
             },
             "messages": [...]
           }
        """
        return self.service.delete_key_check(device_id, key_ids)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['key_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_key(self, device_id, key_ids):
        """
        Delete KDM(s) from a device.
        
        .. http_method_uri:: content/delete_key
            :category: Content
        
        :param key_ids: List of KDM identifiers
        :param device_id: Device identifier
        :type key_ids: JSON
        :type device_id: String
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           GET /content/delete_key?device_id=cbdcadbe-d7b8-4709-878a-c75d0de80917&
               key_ids=["fefc1d4b-83d2-453b-8d51-780102ecba5c"]
        
        Example Response::
        
           {
             "data": {},
             "messages": [{
               "key_id": "fefc1d4b-83d2-453b-8d51-780102ecba5c",
               "message": "Key [fefc1d4b-83d2-453b-8d51-780102ecba5c] has been marked for deletion on device [b059f777-87e8-4f83-bc68-d5ac324cd2ce]",
               "device_id": "b059f777-87e8-4f83-bc68-d5ac324cd2ce",
               "type": "action",
                 "action_id": "a541ae62-73d2-4649-8fa0-14aee5c8f245"
             }]
           }
        
        """
        messages = self.service.delete_key(device_id, key_ids)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy_peformance_log
    def key_xml(self, key_id):
        """
        Download KDM xml.
        
        .. http_method_uri:: content/key_xml
            :category: Content
        
        :param key_id: KDM identifier
        :type key_id: String
        
        :returns: KDM (XML)
        
        Example Request::
        
           /content/key_xml?key_id="cbdcadbe-d7b8-4709-878a-c75d0de80917"
        
        Example Response::
        
            [ KDM XML ]
        
        """
        xml, messages = self.service.key_xml(key_id)
        if xml is not None:
            return xml
        else:
            return ujson.dumps({'data': {},
             'messages': messages})
            return

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy_peformance_log
    def cpl_xml(self, cpl_uuid):
        """
        Download CPL xml.
        
        .. http_method_uri:: content/cpl_xml
            :category: Content
        
        :param key_id: CPL identifier
        :type key_id: String
        
        :returns: CPL (XML)
        
        Example Request::
        
           /content/cpl_xml?key_id="cbdcadbe-d7b8-4709-878a-c75d0de80917"
        
        Example Response::
        
            [ CPL XML ]
        
        """
        xml, messages = self.service.cpl_xml(cpl_uuid)
        if xml is not None:
            return xml
        else:
            return ujson.dumps({'data': {},
             'messages': messages})
            return

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids', 'hide_expired'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def keys(self, device_ids = [], key_ids = [], content_ids = [], hide_expired = True):
        """
        Returns KDM information for one or more devices.
        
        .. http_method_uri:: content/keys
            :category: Content
        
        :param device_ids: List of device identifiers *(optional)*
        :param key_ids: List of KDM identifiers *(optional)*
        :param content_ids: List of CPL identifiers *(optional)*
        :param hide_expired: Flag to hide keys that have already expired *(optional)* *(default=True)*
        :type device_ids: JSON
        :type key_ids: JSON
        :type content_ids: JSON
        :type hide_expired: Boolean
        
        :returns: KDM information (JSON)
        
        Example Request::
        
           /content/keys?device_ids=["94699394-4ffd-45be-bbcf-16970890945b"]&
               content_ids=["ff18aa07-c101-4854-9591-10676fb4f843"]
        
        Example Response::
        
           {
             "data": {
               "b059f777-87e8-4f83-bc68-d5ac324cd2ce": {
                 "fefc1d4b-83d2-453b-8d51-780102ecba5c": {
                    status: "ok",
                    device_serial_number: null,
                    last_updated: 1377613608.294,
                    not_valid_before: 1360195200,
                    cpl_title: "JASON-ARGONAUTS_FTR_F_EN-FR_FR_51_2K_CLTA_20111015_AAM_OV",
                    dnqualifier: "Gio9Szty8daEiFpFUVMv2uiackk=",
                    matched_device_uuid: "d3dd263f-c512-4af9-9486-0359087f571e",
                    beacon_reported: true,
                    not_valid_after: 1383350340,
                    cpl_uuid: "2c8d7bf3-462c-49bc-b044-af0e634eca92",
                    clean: true,
                    orphaned: true
                 }
               }
             },
             messages: [ ]
           }
        """
        device_keys, messages = self.service.keys(device_ids, key_ids, content_ids, hide_expired)
        return {'data': device_keys,
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_availability(self, content_uuid):
        """
        Returns KDM availability on devices for encrypted content corresponding to given CPL identifier
        
        .. http_method_uri:: content/get_availability
            :category: Content
        
        :param content_uuid: CPL identifier
        :type content_uuid: String
        
        :returns: CPL availability information (JSON)
        
        Example Request::
        
           /content/get_availability?content_uuid="6b3f9ef8-f9c4-42b9-aff0-645cb0b11e06"
        
        Example Response::
        
            {
                "b3cee4ae-9ac8-417e-9617-b62f6ae5d61d":{
                    "f5ffd826-d275-418a-95f3-eb926aa064fd":{
                        "status":"unknown",
                        "on":[
                            "df45c5f-ed98-404d-875c-097fd77cdd94",
                            "a6b2126a-a17b-449d-af5e-78ceda0b0976"
                        ],
                        "on_target":false,
                        "valid_in_24":false,
                        "valid_now":false,
                        "valid":false
                    }
                }
            }
        
        """
        return self.service.get_availability(content_uuid)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def lms_assets(self):
        """
        Return information about all assets/CPLs on the LMS
        
        .. http_method_uri:: content/lms_assets
            :category: Content
        
        :returns: Asset information (JSON)
        
        Example Request::
        
           /content/lms_assets
        
        Example Response::
        
            {
                "cpls":{
                    "885ee617-156d-44c4-8c32-2481b3fc0810": {
                        "status": -1,
                        "create_date": 1375108724.552,
                        "file_name": "885ee617-156d-44c4-8c32-2481b3fc0810.xml",
                        "actual_size": 7821,
                        "total_actual_size": 93056632,
                        "hash": "8+sFueWBlbtexMoXS6adV1y2wjg=",
                        "assets": [
                            "05f1df43-6d77-47c6-950b-db741feb491a",
                            "4267ea07-1068-4dae-85dc-a0d2c04eea38"
                        ],
                        "ingest_source_type": "doremi",
                        "size": 7821,
                        "uuid": "885ee617-156d-44c4-8c32-2481b3fc0810",
                        "total_size": 93056632,
                        "total_actual_size": 93056632,
                        "content_title_text": "ADIDAS-ACROSS-SPORT_ADV_F_EN-XX_UK-XX_51_2K_20110315_PD",
                        "type": "text/xml;asdcpKind=CPL"
                    }
                },
                "assets":{
                    "e04e5453-b6c2-4c8d-b910-f2afc2c4c8cd": {
                        "status": 100,
                        "cpls": [
                            "d7a1c3c1-cbbb-4190-8e9b-b493e8a80de5"
                        ],
                        "hash": "8/PEhVTbPx85rFjorP/4Mh6DWpg=",
                        "file_name": "e04e5453-b6c2-4c8d-b910-f2afc2c4c8cd.mxf",
                        "actual_size": 103524232,
                        "parent_folder": null,
                        "actual_size": 103524232,
                        "uuid": "e04e5453-b6c2-4c8d-b910-f2afc2c4c8cd",
                        "hash_validated": true,
                        "size": 103524232,
                        "type": "application/x-smpte-mxf;asdcpKind=Picture"
                    }
                }
            }
        
        """
        return self.service.lms_assets()

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['receiving_device_ids', 'content_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def transfer(self, sending_device_id, receiving_device_ids, content_ids, not_before = None):
        """
        Transfer specified content from one device to another
        
        .. http_method_uri:: content/transfer
            :category: Content
        
        :param sending_device_id: Source device identifier
        :param receiving_device_ids: List of destination device identifiers
        :param content_ids: List of CPL identifiers to transfer
        :param not_before: POSIX timestamp for scheduling the transfer(s) *(optional)*
        :type sending_device_id: String
        :type receiving_device_ids: JSON
        :type content_ids: JSON
        :type not_before: Integer
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/transfer?sending_device_id=b059f777-87e8-4f83-bc68-d5ac324cd2ce&
               receiving_device_ids=[%224e1a0d59-507d-4194-9034-2d4acf1b7d23%22]&
               content_ids=[%22ebd70a22-32c6-4e3b-bfba-efb8f2c38a71%22]
        
        Example Response::
        
           {
             "messages": [{
               "state": "queued",
               "content_id": "885ee617-156d-44c4-8c32-2481b3fc0810",
               "type": "success",
               "message": "Transfer for content [885ee617-156d-44c4-8c32-2481b3fc0810] has been queued on device [4e1a0d59-507d-4194-9034-2d4acf1b7d23]",
               "device_id": "4e1a0d59-507d-4194-9034-2d4acf1b7d23"
             }],
             "data": { }
           }
        
        """
        messages = self.service.transfer(sending_device_id, receiving_device_ids, content_ids, not_before)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def validate(self, content_id, device_id):
        """
        Starts the validation process for a piece content on specified device (Sony only)
        
        .. http_method_uri:: content/validate
            :category: Content
        
        :param content_id: Content identifier
        :param device_id:  Device identifier
        :type content_id: String
        :type device_id: String
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/validate/?content_id=ebd70a22-32c6-4e3b-bfba-efb8f2c38a71&
            device_id=94699394-4ffd-45be-bbcf-16970890945b
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "message" : "Validating Content",
                            "type" : "success"
                        }
                    ],
                "data":{}
            }
        
        """
        return {'data': {},
         'messages': [self.service.validate(content_id, device_id)]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def force_transfers(self, device_id, transfer_ids = []):
        """
        Force a queued transfer to start now.
        
        .. http_method_uri:: content/force_transfers
            :category: Content
        
        :param transfer_ids: List of transfer identifiers
        :param device_id: Device identifier for destination device
        :type device_id: String
        :type transfer_ids: JSON
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/force_transfers?device_id="b059f777-87e8-4f83-bc68-d5ac324cd2ce"&transfer_ids=["4e1a0d59-507d-4194-9034-2d4acf1b7d23"]
        
        Example Response::
        
            {
                "messages":[
                    {
                        "message":"Transfer cancel request sent to 1. Transfer Id: [758c2c01-e09a-4c7c-9f4e-d6fb1215a49e]",
                        "type":"success"
                    }
                ],
                "data":{}
            }
        
        """
        messages = self.service.force_transfers(device_id, transfer_ids)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def prioritize_transfer(self, transfer_id, device_id):
        """
        Move a transfer to the head of the queue.
        
        .. http_method_uri:: content/prioritize_transfer
            :category: Content
        
        :param transfer_id: Transfer identifier
        :param device_id: Destination device identifier
        :type device_id: String
        :type transfer_id: String
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /content/prioritize_transfer?device_id="b059f777-87e8-4f83-bc68-d5ac324cd2ce"&transfer_id="224e1a0d59-507d-4194-9034-2d4acf1b7d23"
        
        Example Response::
        
            {
                "messages":[
                    {
                        "message":"Transfer [32653a01-73cb-458f-9388-74638e519c5c] has been re-scheduled on 6",
                        "type":"success"
                    }
                ],
                "data":{}
            }
        
        """
        messages = self.service.prioritize_transfer(transfer_id, device_id)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids', 'active_only'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def transfer_status(self, device_ids = [], active_only = True):
        """
        Returns the status of all the transfers for one or more specified devices
        
        .. http_method_uri:: content/transfer_status
            :category: Content
        
        :param device_ids: List of device identifiers *(optional)*
        :param active_only: Flag to show only active transfers *(optional)* *(default=True)*
        :type device_ids: JSON
        :type active_only: Boolean
        
        :returns: Transfer information (JSON)
        
        Example Request::
        
           /content/transfer_status?device_ids=["b059f777-87e8-4f83-bc68-d5ac324cd2ce", "b0c742b3-4d58-4378-8f82-f410d3be0b35"]&
               active_only=false
        
        Example Response::
        
           {
             "data": {
               "b059f777-87e8-4f83-bc68-d5ac324cd2ce": {
                 "queue": [ ],
                 "active": { },
                 "completed": {
                   "ece223a3-1821-4239-90fa-368c9271a3ff": {
                     "description": null,
                     "playlist_json": null,
                     "playlist_uuid": null,
                     "server_transfer_id": "df709415-d533-413f-91ef-fb2c70fe9b45",
                     "source": "aaec87d7-bc77-411d-8987-87023d93c49f",
                     "state": "success",
                     "not_before": null,
                     "message": "The CPL and related assets have been ingested successfully",
                     "content_id": "8723dd6b-d46b-48ad-8c45-a5757e493f66",
                     "type": "DCP",
                     "id": "ece223a3-1821-4239-90fa-368c9271a3ff"
                   }
                 }
               }
             },
             "messages": []
           }
        """
        device_transfer_status, device_errors = self.service.transfer_status(device_ids, active_only)
        return {'data': device_transfer_status,
         'messages': device_errors}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def transfer_detail(self, device_uuid, transfer_id):
        """
        Returns the status of the given transfer on the given device.
        
        .. http_method_uri:: content/transfer_detail
            :category: Content
        
        :param device_uuid: Destination device identifier
        :param transfer_id: Transfer identifier
        :type device_uuid: String
        :type transfer_id: String
        
        :returns: Transfer information (JSON)
        
        Example Request::
        
            /content/transfer_detail?device_uuid=b059f777-87e8-4f83-bc68-d5ac324cd2ce&transfer_id=b0c742b3-4d58-4378-8f82-f410d3be0b35
        
        Example Response::
        
           {
             "data": {
                 "description": null,
                 "playlist_json": null,
                 "playlist_uuid": null,
                 "server_transfer_id": "df709415-d533-413f-91ef-fb2c70fe9b45",
                 "source": "aaec87d7-bc77-411d-8987-87023d93c49f",
                 "state": "success",
                 "not_before": null,
                 "message": "The CPL and related assets have been ingested successfully",
                 "content_id": "8723dd6b-d46b-48ad-8c45-a5757e493f66",
                 "type": "DCP",
                 "id": "ece223a3-1821-4239-90fa-368c9271a3ff"
               },
             "messages": []
           }
        """
        detail, messages = self.service.transfer_detail(device_uuid, transfer_id)
        return {'data': detail,
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_id'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_sync_report(self, device_id):
        """
        Get content sync report for mounted drives and/or local folders.
        
        .. http_method_uri:: content/get_sync_report
            :category: Content
        
        :param device_id: Device identifier
        :type device_id: String
        
        :return: Sync report information (JSON)
        
        Example Request::
        
            /core/content/get_sync_report?device_id="6ae8bf04-3127-4c65-b3e5-cdd2d13a0125"
        
        Example Response::
        
            {
                messages: [ ],
                data: {
                    stats: {
                        dcps: {
                            all: 1,
                            faulty: 0,
                            with_faulty_cpls: 0,
                            success: 1
                        },
                        kdms: {
                            faulty: 0,
                            expired: 0,
                            success: 0
                        },
                        packs: {
                            faulty: 0,
                            expired: 1153,
                            success: 0
                        }
                    }
                }
            }
        """
        report, messages = self.service.get_sync_report(device_id)
        return {'data': report,
         'messages': messages}
# okay decompyling ./core/api/content_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:03 CST
