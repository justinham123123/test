# 2017.08.13 21:48:06 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\paginated.py
from collections import namedtuple
from datetime import datetime, date, time as dt_time
import json
import logging
from operator import itemgetter
import os
import re
import time
import types
import cherrypy
from sqlalchemy import distinct
from sqlalchemy.exc import OperationalError, ProgrammingError
from sqlalchemy.orm import subqueryload
from sqlalchemy.sql.expression import or_, not_, func, and_
from serv.configuration import cfg
from serv.core.devices.base import content as base_content, playback as base_playback
from serv.core.devices.base import log_collection as base_Logging
from serv.core.tasks.reconcile_logs import CODE_START_AND_END_OFF
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler_raw
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities import date_utils
from serv.lib.utilities import helper_methods
from serv.lib.utilities.helper_methods import API, multipassify_string
from serv.storage.database.audit import database as audit
from serv.storage.database.playback import database as playback
from serv.storage.database.primary import database as db
from serv.tms.tms_core import TMS

def _order_values(record, order_columns):
    """
    Helper functions for generating tuples to use as sorting keys (allows mixed direction sorting on multiple fields)
    """
    for column, desc_flag in order_columns:
        value = record.get(column, None)
        if value is None:
            yield (999, 999, 999)
        elif type(value) in types.StringTypes:
            yield tuple((ord(c) * desc_flag for c in value.lower()))
        else:
            yield float(value) * desc_flag

    return


def order_tuple(orders):
    return lambda record: tuple(_order_values(record, orders))


def format_db_value(val):
    if type(val) is datetime:
        return helper_methods.tstamp(val)
    if type(val) is dt_time:
        return val.strftime('%H:%M')
    if type(val) is date:
        return val.strftime('%Y-%m-%d')
    return val


def fix_end_stamp(stamp):
    """End timestamps should be the start of the following day"""
    return float(stamp) + 86400


class Paginated(API):
    """
    HTTP API for managing paginated calls from core2. paginated calls benefit from being much faster
    
    #TODO: Create PaginatedService and decouple api from backend code
    """

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    def get_datatables_audit(self, device_uuid = None, start = None, end = None, tags = None, filter_system = False, sEcho = 0, iDisplayStart = 0, iDisplayLength = 0, iSortingCols = 0, sSearch = None, **kwargs):
        is_sqlite = cfg.db_engine == 'sqlite3'
        logs = audit.Session.query(audit.Log).outerjoin(audit.Log._tags).options(subqueryload('_tags')).group_by(audit.Log.uuid)
        if device_uuid:
            logs = logs.filter(audit.Log.meta.like('%%%s%%' % device_uuid))
        iTotalRecords = logs.count()
        if start:
            logs = logs.filter(audit.Log.created >= str(start))
        if end:
            logs = logs.filter(audit.Log.created <= str(fix_end_stamp(end)))
        if filter_system:
            logs = logs.filter(not_(or_(audit.Log.ip == '127.0.0.1', audit.Log.user == 'system')))
        if sSearch:
            sSearch = sSearch.lower()
            for search in sSearch.split(' '):
                logs = logs.filter(or_(audit.Log.message.like('%' + search + '%'), audit.Log.user.like('%' + search + '%'), audit.Log.meta.like('%' + search + '%'), audit.Tag.name == search))

        for i in range(iSortingCols):
            col = int(kwargs['iSortCol_%d' % i])
            direction = kwargs['sSortDir_%d' % i]
            rest = ' ' + direction + (is_sqlite and 'COLLATE NOCASE ' or '')
            if col == 2:
                pass
            elif col == 4:
                logs = logs.order_by('created' + rest)

        iTotalDisplayRecords = logs.count()
        if iDisplayLength:
            logs = logs.limit(iDisplayLength)
        if iDisplayStart:
            logs = logs.offset(iDisplayStart)
        aaData = []
        for log in logs:
            meta = {}
            if log.meta:
                meta = json.loads(log.meta)
            aaData.append({'user': log.user,
             'ip': log.ip,
             'message': log.message,
             'when': datetime.fromtimestamp(log.created).strftime('%H:%M:%S %Y-%m-%d'),
             'timestamp': log.created,
             'tags': list(log.tags),
             'meta': meta})

        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    def _get_playback_meta(self, playback):
        if playback.meta and playback.content_kind:
            meta = json.loads(playback.meta)
            meta['content_kind'] = playback.content_kind
            return meta
        return self.core.contents.get(playback.cpl_uuid, {})

    def get_playbacks_filter(self, device_uuid = None, start = None, end = None, content_kind = None, search = None):
        db_logs = playback.Session.query(playback.Playback).filter_by(deleted=False)
        if device_uuid and device_uuid in self.core.devices:
            ip = self.core.devices[device_uuid].device_configuration['ip']
            db_logs = db_logs.filter(playback.Playback.device_ip_address == ip)
        total_records = db_logs.count()
        if start:
            db_logs = db_logs.filter(or_(playback.Playback.start >= start, playback.Playback.end >= start))
        if end:
            end = fix_end_stamp(end)
            db_logs = db_logs.filter(or_(playback.Playback.start <= end, playback.Playback.end <= end))
        if content_kind:
            db_logs = db_logs.filter(playback.Playback.content_kind == content_kind)
        if search:
            db_logs = db_logs.filter(playback.Playback.meta.ilike('%' + search.lower() + '%'))
        return (db_logs, total_records)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    def get_datatables_playback(self, device_uuid = None, start = None, end = None, content_kind = None, sEcho = 0, iDisplayStart = 0, iDisplayLength = 0, iSortingCols = 0, sSearch = None, **kwargs):
        aaData = []
        db_logs, iTotalRecords = self.get_playbacks_filter(device_uuid, start, end, content_kind, sSearch)
        iTotalDisplayRecords = db_logs.count()
        for i in range(iSortingCols):
            col = int(kwargs['iSortCol_%d' % i])
            direction = kwargs['sSortDir_%d' % i]
            rest = ' ' + direction
            if col == 3:
                db_logs = db_logs.order_by('playback.start' + rest)
            elif col == 4:
                db_logs = db_logs.order_by('playback.end' + rest)
            elif col == 5:
                db_logs = db_logs.order_by('playback.duration' + rest)

        if iDisplayLength:
            db_logs = db_logs.limit(iDisplayLength)
        if iDisplayStart:
            db_logs = db_logs.offset(iDisplayStart)
        screens_by_ip = {}
        if not device_uuid:
            for uuid in self.core.get_devices(required_api=base_Logging.Logging)[0]:
                device = self.core.devices[uuid]
                screens_by_ip[device.device_configuration['ip']] = device.device_configuration['screen_identifier']

        else:
            device = self.core.devices[device_uuid]
            screens_by_ip[device.device_configuration['ip']] = device.device_configuration['screen_identifier']
        for db_log in db_logs:
            log = {}
            meta = self._get_playback_meta(db_log)
            log['playback_uuid'] = db_log.uuid
            log['cpl_uuid'] = db_log.cpl_uuid
            log['content_title'] = meta.get('content_title_text', db_log.cpl_uuid)
            log['content_kind'] = meta.get('content_kind', 'unknown')
            log['titles'] = [meta.get('spl_name', _('Unknown'))]
            log['feature'] = meta.get('feature_title')
            log['start_ts'] = db_log.start
            log['end_ts'] = db_log.end
            log['duration'] = db_log.duration
            log['live_log'] = bool(db_log.live_log_uuid)
            log['smpte_logs'] = bool(db_log.merge_error_code not in (CODE_START_AND_END_OFF, None))
            log['screen'] = screens_by_ip.get(db_log.device_ip_address)
            aaData.append(log)

        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    def get_parsed_playouts(self, playback_uuid, **kwargs):
        output = []
        db_playback = playback.Session.query(playback.Playback).get(playback_uuid)
        if not db_playback:
            return output
        playout_ids = [ x[0] for x in playback.Session.query(playback.LogFilePlayout.id).filter_by(playback_uuid=playback_uuid) ]
        for playout in db_playback.playout_logs:
            info = {'path': playout.log_file.absolute_file_path,
             'ip': playout.log_file.device_ip_address,
             'screen_identifier': playout.log_file.screen_identifier,
             'playouts': []}
            playouts = playback.Session.query(playback.LogFilePlayout, playback.Playback.meta, playback.Playback.content_kind).filter(playback.LogFilePlayout.log_file_uuid == playout.log_file_uuid, playback.LogFilePlayout.deleted == False).outerjoin(playback.Playback, playback.Playback.uuid == playback.LogFilePlayout.playback_uuid).order_by(playback.LogFilePlayout.start_time)

            def time(stamp):
                try:
                    return datetime.fromtimestamp(stamp).strftime('%H:%M:%S')
                except Exception:
                    return _('Unknown')

            pl = namedtuple('playback', 'meta content_kind cpl_uuid')
            for playout in playouts:
                meta = self._get_playback_meta(pl(playout[1], playout[2], playout[0].cpl_uuid))
                playout = playout[0]
                info['playouts'].append({'playout_id': playout.id,
                 'selected': playout.id in playout_ids,
                 'cpl_uuid': playout.cpl_uuid,
                 'content_kind': meta.get('content_kind'),
                 'content_title_text': meta.get('content_title_text'),
                 'start': time(playout.start_time),
                 'end': time(playout.end_time)})

            output.append(info)

        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    def get_datatables_titles(self, sEcho = 0, iDisplayStart = 0, iDisplayLength = 0, iSortingCols = 0, sSearch = None, hide_unavailable = False, exclude = None, **kwargs):
        is_sqlite = cfg.db_engine == 'sqlite3'
        aaData = []
        iTotalRecords = db.Session.query(db.Title).count()
        if hide_unavailable:
            device_content_list = cherrypy.core.contents.get_complex_content().keys()
            device_content_chunks = [ device_content_list[x:x + 999] for x in xrange(0, len(device_content_list), 999) ]
            titles_ids = []
            for chunk in device_content_chunks:
                db_titles_chunk_ids = db.Session.query(db.Title.uuid).join('title_cpl_maps').filter(db.TitleCplMap.cpl_uuid.in_(chunk)).all()
                db_titles_chunk_ids_list = [ title_id[0] for title_id in db_titles_chunk_ids ]
                titles_ids = titles_ids + db_titles_chunk_ids_list

            db_titles = db.Session.query(db.Title).filter(db.Title.uuid.in_(set(titles_ids)))
        else:
            db_titles = db.Session.query(db.Title)
        if exclude:
            db_titles = db_titles.filter(not_(db.Title.uuid.in_(exclude)))
        if sSearch:
            sSearch = sSearch.lower()
            for search in sSearch.split(' '):
                if helper_methods.is_uuid(search):
                    db_titles = db_titles.filter(db.Title.uuid == search)
                else:
                    db_titles = db_titles.filter(db.Title.name.like('%' + search + '%'))

        iTotalDisplayRecords = db_titles.count()
        for i in range(iSortingCols):
            col = int(kwargs['iSortCol_%d' % i])
            direction = kwargs['sSortDir_%d' % i]
            if col == 1:
                db_titles = db_titles.order_by('name COLLATE NOCASE ' + direction)
            elif col == 2:
                db_titles = db_titles.order_by('last_modified COLLATE NOCASE ' + direction)

        if iDisplayLength:
            db_titles = db_titles.limit(iDisplayLength)
        if iDisplayStart:
            db_titles = db_titles.offset(iDisplayStart)
        for title in db_titles:
            a_title = {}
            a_title['name'] = title.name
            a_title['uuid'] = title.uuid
            a_title['year'] = title.year
            a_title['credits_offset'] = title.credits_offset
            a_title['last_modified'] = datetime.fromtimestamp(title.last_modified).strftime('%H:%M:%S %Y-%m-%d')
            aaData.append(a_title)

        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_datatables_kdm(self, sEcho = 0, iDisplayStart = 0, iDisplayLength = 0, iSortingCols = 0, sSearch = None, device_uuids = [], hide_orphan_kdms = False, hide_expired = False, **kwargs):
        aaData = []
        lms_id = self.core.get_lms_id()
        device_ids = []
        for device in device_uuids:
            if device == 'LMS':
                device_ids.append(lms_id)
            else:
                device_ids.append(device)

        device_screen_map = {}
        for scrid in self.core.screens:
            for dev_id in self.core.screens[scrid]['devices']:
                device_screen_map[dev_id] = self.core.screens[scrid]['identifier']

        kdms = self.core.content_service.keys(device_ids=device_ids, hide_expired=hide_expired or hide_orphan_kdms)
        kdm_list = []
        time_now = time.time()
        time_24 = time_now + 86400
        search_keywords = sSearch.lower().split(' ')
        iTotalRecords = 0
        iTotalDisplayRecords = 0
        for device in device_ids:
            if device in kdms[0]:
                for kdm in kdms[0][device]:
                    iTotalRecords += 1
                    kdm_obj = kdms[0][device][kdm]
                    kdm_obj['orphaned'] = not self.core.contents.content_on_device(kdm_obj['cpl_uuid'], device)
                    if kdm_obj['orphaned'] and hide_orphan_kdms and device != lms_id:
                        continue
                    to_append = True
                    if search_keywords:
                        search_data = kdm_obj.get('cpl_title', '').lower()
                        for keyword in search_keywords:
                            if keyword not in search_data and not helper_methods.match_uuid(keyword, kdm):
                                to_append = False

                    if to_append:
                        kdm_obj['uuid'] = kdm
                        if not kdm_obj['cpl_title'].strip():
                            if kdm_obj['cpl_uuid'] in self.core.contents:
                                ctt = self.core.contents[kdm_obj['cpl_uuid']].get('content_title_text', '')
                                if ctt and not re.findall('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', ctt.lower()):
                                    kdm_obj['cpl_title'] = ctt
                                else:
                                    kdm_obj['cpl_title'] = kdm_obj['uuid']
                            else:
                                kdm_obj['cpl_title'] = kdm_obj['uuid']
                            kdm_obj['version'] = '?'
                        else:
                            kdm_obj['version'] = 'VF' if re.findall('(?:.*)_VF$', kdm_obj['cpl_title']) else 'OV'
                        kdm_obj['screen'] = device_screen_map[kdm_obj['matched_device_uuid']] if kdm_obj['matched_device_uuid'] else '?'
                        kdm_obj['expired'] = True if time_now > kdm_obj['not_valid_after'] else False
                        kdm_obj['expires_in_24'] = True if time_now < kdm_obj['not_valid_after'] and time_24 > kdm_obj['not_valid_after'] else False
                        kdm_obj['valid_in_future'] = True if time_now < kdm_obj['not_valid_before'] else False
                        kdm_obj['status_order'] = 0 + (kdm_obj['valid_in_future'] and 1 + kdm_obj['expires_in_24'] and 2) + (kdm_obj['expired'] and 4) + (kdm_obj['valid_in_future'] and 8) + (device != lms_id and kdm_obj['orphaned'] and 16 or 0) + (kdm_obj['status'] == 'error' and 1)
                        kdm_list.append(kdm_obj)
                        iTotalDisplayRecords += 1

        aaData = kdm_list
        orders = []
        sort_no = int(iSortingCols)
        for i in range(sort_no):
            col = int(kwargs['iSortCol_%d' % i])
            desc = -1 if kwargs['sSortDir_%d' % i] == 'desc' else 1
            if col == 2:
                orders.append(('status_order', desc))
            elif col == 4:
                orders.append(('cpl_title', desc))
            elif col == 5:
                orders.append(('version', desc))
            elif col == 6:
                orders.append(('screen', desc))
            elif col == 7:
                orders.append(('device_serial_number', desc))
            elif col == 8:
                orders.append(('not_valid_before', desc))
            elif col == 9:
                orders.append(('not_valid_after', desc))

        if orders:
            aaData = sorted(aaData, key=order_tuple(orders))
        aaData = aaData[int(iDisplayStart):int(iDisplayStart) + int(iDisplayLength)]
        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_draglist_content(self, iDisplayLength = 0, sSearch = None, show_kdms = False, type_filter = None, device_uuid = None, orphaned = False, **kwargs):
        kwargs = {}
        kwargs['iSortCol_0'] = 7
        kwargs['iSortCol_1'] = 8
        kwargs['sSortDir_0'] = 'asc'
        kwargs['sSortDir_1'] = 'asc'
        content = self.get_datatables_content(iDisplayLength=iDisplayLength, iSortingCols=2, sSearch=sSearch, show_kdms=show_kdms, type_filter=type_filter, device_uuid=device_uuid, servers_only=True, **kwargs)
        if orphaned:
            used = [ x[0] for x in db.Session.query(distinct(db.TitleCplMap.cpl_uuid)).all() ]
            to_remove = []
            for i, v in enumerate(content['aaData']):
                if content['aaData'][i]['uuid'] in used:
                    to_remove.append(content['aaData'][i])

            for i in to_remove:
                content['aaData'].remove(i)

            content['iTotalRecords'] = len(content['aaData'])
            content['iTotalDisplayRecords'] = content['iTotalDisplayRecords'] - len(to_remove)
            db.Session.close()
        return content

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_datatables_content(self, sEcho = 0, iDisplayStart = 0, iDisplayLength = 0, iSortingCols = 0, sSearch = None, show_kdms = True, type_filter = None, cleanup_filter = None, device_uuid = None, servers_only = False, last_playback = False, **kwargs):
        device_uuids = [device_uuid] if device_uuid else []
        aaData = []
        lms_id = self.core.get_lms_id()
        lms_view = False
        lms_content = {}
        non_screen_server_view = False
        if device_uuid is not None:
            lms_view = True if lms_id == device_uuid else False
            device_category = cherrypy.core.devices[device_uuid].device_configuration.get('category')
            non_screen_server_view = device_category not in ('lms', 'sms')
        if not servers_only or servers_only and device_uuid:
            device_uuids, device_errors = self._get_devices(device_uuids, base_content.Content)
        else:
            device_uuids, device_errors = self._get_devices([], base_playback.Playback)
            device_uuids.append(lms_id)
        contents = cherrypy.core.contents.get_contents_dict(device_uuid)
        iTotalRecords = len(contents)
        if non_screen_server_view:
            lms_content = self.core.contents.get_contents_dict(device_uuid=lms_id)
        if cleanup_filter and cleanup_filter != 'none':
            if cleanup_filter == 'unused':
                packs_clips = db.Session.query(db.Pack.clips).all()
                packs_clips_strings = [ pack_clip[0] for pack_clip in packs_clips ]
                pack_clips_string = ''.join(packs_clips_strings)
                titles_cpl_uuids = db.Session.query(db.TitleCplMap.cpl_uuid).all()
                cpls_in_titles = [ title_cpl[0] for title_cpl in titles_cpl_uuids ]
            elif cleanup_filter == 'not_on_lms':
                lms_cpl_ids = lms_content.keys() if len(lms_content) else self.core.contents.get_contents_dict(device_uuid=lms_id).keys()
        for content_id, content in contents.iteritems():
            core_content = self.core.contents[content_id]
            data = {'uuid': content_id,
             'encrypted': content['encrypted'] if 'encrypted' in content else None,
             'video_encoding': content['video_encoding'],
             'playback_mode': content['playback_mode'],
             'subtitled': content['subtitled'],
             'subtitle_language': content['subtitle_language'],
             'devices': {},
             'validation_code': -1,
             'content_kind': content['content_kind'],
             'content_title': content['content_title'],
             'content_title_text': content['content_title_text'],
             'duration_in_seconds': content['duration_in_seconds'],
             'duration_in_frames': content['duration_in_frames'],
             'edit_rate': content['edit_rate'],
             'credits_offset': content['credits_offset'],
             'rating_hardlocked': content['rating_hardlocked'],
             'resolution': content.get('resolution'),
             'ingest_source_type': None,
             'rating': content['rating'],
             'territory': content['territory'],
             'ingest_date': None,
             'devices': content['devices']}
            if device_uuid is None:
                for device in content['devices']:
                    if content['devices'][device] and content['devices'][device]['validation_code'] != -1:
                        data['validation_code'] = None
                        break

            else:
                data['validation_code'] = content['devices'][device_uuid].get('validation_code', -1)
                if lms_view:
                    data['ingest_source_type'] = content['devices'][device_uuid].get('ingest_source_type', None)
                    data['ingest_date'] = content['devices'][device_uuid].get('ingest_date', None)
                if non_screen_server_view:
                    data['on_lms'] = core_content.valid_on_device(lms_id)
                if self.core.contents[content_id]['encrypted']:
                    valid_now, valid_in_future, expires_in_24, details = core_content.get_encryption_state(device_uuid, '')
                    data['devices'][device_uuid]['valid_now'] = valid_now
                    data['devices'][device_uuid]['valid_in_future'] = valid_in_future
                    data['devices'][device_uuid]['expires_in_24'] = expires_in_24
                    data['devices'][device_uuid]['keys_detailed'] = details
            if not show_kdms and data['validation_code'] == -1:
                iTotalRecords -= 1
                continue
            if show_kdms and not data['encrypted']:
                iTotalRecords -= 1
                continue
            if type_filter and type_filter != 'none':
                if content['content_kind'].lower() != type_filter.lower():
                    continue
            if cleanup_filter and cleanup_filter != 'none':
                if cleanup_filter == 'unused':
                    if content_id in pack_clips_string:
                        continue
                    if content_id in cpls_in_titles:
                        continue
                    if device_uuid:
                        if len(self.core.contents.get_playlists(content_id, device_uuid)) > 0:
                            continue
                    elif len(self.core.contents.get_playlists(content_id)) > 0:
                        continue
                elif cleanup_filter == 'not_on_lms':
                    if content_id in lms_cpl_ids:
                        continue
            if sSearch:
                con = False
                keywords = content.get('content_title_text', '').lower()
                for term in sSearch.split(' '):
                    if not helper_methods.match_uuid(term, content_id) and term.lower() not in keywords:
                        con = True
                        break

                if con:
                    continue
            aaData.append(data)

        def get_last_playbacks():
            last_playbacks = {}
            if last_playback:
                db_playback_dates = playback.Session.query(playback.Playback).filter(playback.Playback.cpl_uuid.in_([ cpl['uuid'] for cpl in aaData ]), playback.Playback.start != None).group_by(playback.Playback.cpl_uuid).values(playback.Playback.cpl_uuid, func.max(playback.Playback.start))
                for cpl_uuid, start in db_playback_dates:
                    last_playbacks[cpl_uuid] = datetime.fromtimestamp(start).strftime('%Y-%m-%d')

                for cpl in aaData:
                    cpl['last_playback'] = last_playbacks.get(cpl['uuid'])

            return

        orders = []
        playbacks_got = False
        sort_no = int(iSortingCols)
        for i in range(sort_no):
            col = int(kwargs['iSortCol_%d' % i])
            desc = -1 if kwargs['sSortDir_%d' % i] == 'desc' else 1
            if col == 2:
                orders.append(('validation_code', desc))
            elif col == 3:
                orders.append(('encrypted', desc))
            elif col == 6:
                orders.append(('subtitled', desc))
            elif col == 7:
                orders.append(('content_kind', desc))
            elif col == 8:
                orders.append(('content_title_text', desc))
            elif col == 9:
                orders.append(('ingest_date', desc))
            elif col == 10:
                orders.append(('ingest_source_type', desc))
            elif col == 11:
                orders.append(('on_lms', desc))
            elif col == 12:
                get_last_playbacks()
                playbacks_got = True
                orders.append(('last_playback', desc))
            elif col == 13:
                orders.append(('duration_in_seconds', desc))

        if orders:
            aaData = sorted(aaData, key=order_tuple(orders))
        iTotalDisplayRecords = len(aaData)
        if iDisplayLength != 0:
            aaData = aaData[int(iDisplayStart):int(iDisplayStart) + int(iDisplayLength)]
        if not playbacks_got:
            get_last_playbacks()
        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_datatables_packs(self, sEcho = 0, iDisplayStart = 0, iDisplayLength = None, sSearch = None, placeholder_filter = None, screen_number_filter = None, rating_filter = None, iSortingCols = 0, **kwargs):
        is_sqlite = cfg.db_engine() == 'sqlite3'
        iTotalDisplayRecords = db.Session.query(db.Pack).count()
        packs_db = db.Session.query(db.Pack, db.PackRatingMap.rating.label('rating')).outerjoin('placeholder').outerjoin(db.ExternalTitleMap).outerjoin(db.PackRatingMap, and_(db.Pack.uuid == db.PackRatingMap.pack_uuid, db.PackRatingMap.region == cfg.country()))
        if screen_number_filter:
            packs_db = packs_db.join('screen_maps').filter(db.PackScreenMap.screen_uuid == screen_number_filter)
        if placeholder_filter:
            packs_db = packs_db.filter(db.Pack.placeholder_uuid == placeholder_filter)
        if rating_filter:
            packs_db = packs_db.filter(db.PackRatingMap.rating == rating_filter)
        if sSearch:
            sSearch = sSearch.lower()
            for search in sSearch.split(' '):
                if helper_methods.is_uuid(search):
                    packs_db = packs_db.filter(db.Pack.uuid == search)
                else:
                    packs_db = packs_db.filter(db.Pack.name.like('%' + search + '%'))

        sort_no = int(iSortingCols)
        for i in range(sort_no):
            col = int(kwargs['iSortCol_%d' % i])
            direction = kwargs['sSortDir_%d' % i]
            if col == 2:
                name = 'pack.name'
            elif col == 3:
                name = 'placeholder.name'
            elif col == 4:
                name = 'external_title_map.name'
            elif col == 5:
                name = 'screens'
            elif col == 6:
                name = 'pack.playback_date_range_start'
            elif col == 7:
                name = 'pack.playback_time_range_start'
            elif col == 9:
                name = 'rating'
            elif col == 10:
                name = 'pack.last_modified'
            packs_db = packs_db.order_by(name + (is_sqlite and ' COLLATE NOCASE ' or ' ') + direction)

        iTotalRecords = packs_db.count()
        if iDisplayLength:
            packs_db = packs_db.limit(iDisplayLength)
            packs_db = packs_db.offset(iDisplayStart)
        aaData = []
        for pack in packs_db:
            pack_obj = pack[0].to_datatables_dict()
            pack_obj.update({'rating': pack.rating})
            aaData.append(pack_obj)

        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_datatables_playlists(self, device_uuid, sEcho = 0, iDisplayStart = 0, iDisplayLength = None, sSearch = None, cleanup_filter = None, iSortingCols = 0, **kwargs):
        aaData = []
        validate_timestamp = time.time()
        if cleanup_filter and cleanup_filter != 'none':
            schedules_playlist_uuids = db.Session.query(db.Schedule.device_playlist_uuid).filter(db.Schedule.start_timestamp > validate_timestamp).all()
            playlists_scheduled = set([ playlist_uuid[0] for playlist_uuid in schedules_playlist_uuids ])
        playlists = cherrypy.core.playlist_service.playlist([device_uuid], validate=False)[0]
        automations = cherrypy.core.automation_service.get_automation_configuration()
        for playlist_uuid in playlists[device_uuid]:
            playlist = playlists[device_uuid][playlist_uuid]
            playlist['uuid'] = playlist_uuid
            playlist['features'] = []
            if cleanup_filter and cleanup_filter != 'none':
                if playlist_uuid in playlists_scheduled:
                    continue
            con = False
            if sSearch:
                for search_term in sSearch.lower().split():
                    if search_term not in playlist['title'].lower() and not helper_methods.match_uuid(search_term, playlist_uuid):
                        con = True
                        break

            if con:
                continue
            aaData.append(playlist)

        sort_no = int(iSortingCols)
        for i in range(sort_no):
            col = int(kwargs['iSortCol_%d' % i])
            desc = True if kwargs['sSortDir_%d' % i] == 'desc' else False
            if col == 2:
                aaData = sorted(aaData, key=lambda k: k['title'].lower(), reverse=desc)
            elif col == 4:
                aaData = sorted(aaData, key=lambda k: k['duration_in_seconds'], reverse=desc)

        iTotalDisplayRecords = len(aaData)
        iTotalRecords = len(playlists[device_uuid])
        if iDisplayLength:
            aaData = aaData[int(iDisplayStart):int(iDisplayStart) + int(iDisplayLength)]
        for playlist in aaData:
            try:
                if playlist.has_key('playlist'):
                    playlist['validation'] = cherrypy.core.playlist_validation.get_validation(playlist['uuid'], device_uuid, validate_timestamp)
                    playlist.update(helper_methods.get_event_info(playlist['playlist'], automations))
                else:
                    print 'no inner playlist :/'
                    playlist['validation'] = {}
                    playlist['has_show_start'] = False
                    playlist['has_intermission'] = False
                    playlist['show_start_offset'] = 0
                for content_id in playlist['content_ids']:
                    content = cherrypy.core.contents.get(content_id)
                    if content and content.store.get('content_kind', '') == 'feature':
                        playlist['features'].append(content['content_title'])

            except Exception as ex:
                print str(ex)
                logging.error('Error getting playlist %s information: %s' % (playlist['uuid'], ex))

        for playlist in aaData:
            del playlist['content_ids']
            del playlist['playlist']
            if 'clean' in playlist:
                del playlist['clean']

        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_datatables_templates(self, sEcho = 0, iDisplayStart = 0, iDisplayLength = None, sSearch = None, iSortingCols = 0, **kwargs):
        aaData = []
        templates = cherrypy.core.template_service.template()[0]
        active_uuid = cfg.core_active_template.get()
        for template_uuid in templates:
            template = templates[template_uuid]
            template['active'] = True if active_uuid == template_uuid else False
            con = False
            if sSearch:
                for search_term in sSearch.lower().split():
                    if search_term not in template['name'].lower() and not helper_methods.match_uuid(search_term, template['uuid']):
                        con = True
                        break

            if con:
                continue
            aaData.append(template)

        iTotalDisplayRecords = len(aaData)
        iTotalRecords = len(templates)
        if iDisplayLength:
            aaData = aaData[int(iDisplayStart):int(iDisplayStart) + int(iDisplayLength)]
        return {'sEcho': int(sEcho),
         'iTotalRecords': iTotalRecords,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': iTotalDisplayRecords,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler_raw)
    def get_datatables_tms_logs(self, log_name = None, log_rotation_num = None, log_level = None, iSortCol_0 = 0, sSortDir_0 = '', sSearch = '', sEcho = 0, iDisplayStart = 0, iDisplayLength = 10, **kwargs):
        logs = []
        cols = ['datetime', 'source', 'msg']

        def get_line(line_str):
            if '::' in line_str:
                fields = line.split('::')
                if len(fields) > 5:
                    logs.append({'datetime': fields[1],
                     'level': fields[2],
                     'source': fields[3][1:-1],
                     'msg': fields[5]})
            elif len(logs):
                logs[-1]['msg'] += line

        def search_filter(log):
            keywords = (log['source'] + log['msg']).lower()
            for term in sSearch.split(' '):
                if term.lower() in keywords:
                    return True

            return False

        def skip_filter(log):
            return 'X-REQUESTED-WITH' not in log['msg']

        log_name_core = '' if log_name == 'main' else '.%s' % log_name
        log_nums = [None,
         1,
         2,
         3,
         4,
         5] if log_rotation_num == 'All' else [log_rotation_num]
        err = None
        for log_num in log_nums:
            log_rotation_str = '.%s' % log_num if log_num else ''
            log_name_full = '%s%s.log%s' % (multipassify_string('cinema_services'), log_name_core, log_rotation_str)
            log_path = os.path.join(cfg.log_dir(), log_name_full)
            if os.path.exists(log_path):
                err = False
                with open(log_path) as log_file:
                    for line in log_file:
                        get_line(line)

            elif err is None:
                err = 'Log path %s not found' % log_path

        logs = filter(skip_filter, logs)
        ttl = len(logs)
        if sSearch:
            logs = filter(search_filter, logs)
        if log_level:
            logs = filter(lambda l: l['level'] == log_level, logs)
        descending = sSortDir_0 == 'desc'
        if iSortCol_0 > 0:
            logs = sorted(logs, key=itemgetter(cols[iSortCol_0]), reverse=descending)
        elif descending:
            logs.reverse()
        return {'sEcho': int(sEcho),
         'iTotalRecords': ttl,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': len(logs),
         'aaData': logs[int(iDisplayStart):int(iDisplayStart) + int(iDisplayLength)],
         'error': err}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    def get_datatables_db(self, db_name = None, db_model_name = None, iSortCol_0 = None, sSortDir_0 = 'asc', sSearch = '', sEcho = 0, iDisplayStart = 0, iDisplayLength = 10, **kwargs):
        aaData = []
        database = db
        if 'audit' in db_name:
            database = audit
        if 'playback' in db_name:
            database = playback
        db_model = getattr(database, db_model_name)
        data = database.Session.query(db_model)
        ttl = data.count()
        if sSearch:
            data = data.filter(sSearch)
        try:
            filtered_ttl = data.count()
            err = None
        except (OperationalError, ProgrammingError) as e:
            filtered_ttl = 0
            err = str(e).split('SELECT')[0]

        if not err:
            column_names = [ c.name for c in db_model.__table__.columns ]
            if iSortCol_0 is not None:
                order = getattr(db_model, column_names[iSortCol_0])
                if sSortDir_0 == 'desc':
                    order = order.desc()
                data = data.order_by(order)
            for row in data.offset(iDisplayStart).limit(iDisplayLength):
                d = {}
                for column in column_names:
                    val = getattr(row, column)
                    d[column] = format_db_value(val)

                aaData.append(d)

        return {'sEcho': int(sEcho),
         'iTotalRecords': ttl,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': filtered_ttl,
         'aaData': aaData,
         'error': err}
# okay decompyling ./core/api/paginated.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:10 CST
