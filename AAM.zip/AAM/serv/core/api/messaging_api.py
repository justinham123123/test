# 2017.08.13 21:48:05 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\messaging_api.py
import cherrypy
from serv.lib.cherrypy.cherrypy_utils import json_out_handler, cherrypy_peformance_log
from serv.lib.utilities.helper_methods import API
from serv.core.services.messaging_service import MessagingService

class MessagingAPI(API):
    """
    Messaging API
    """

    def __init__(self, core):
        super(MessagingAPI, self).__init__(core)
        self.service = MessagingService(core)

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def start(self):
        return self.service.start()

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def get_roster(self):
        return self.service.get_roster()

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def get_conversation(self, username):
        return self.service.get_conversation(username)

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def send_message(self, username, body):
        return self.service.send_message(username, body)

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def get_settings(self):
        return self.service.get_settings()

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def set_settings(self, email_server = None, email_port = None, chat_server_name = None, chat_server_ip = None, chat_server_port = None, chat_enabled = None):
        return self.service.set_settings(email_server, email_port, chat_server_name, chat_server_ip, chat_server_port, chat_enabled)

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['complexes'])
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def update_complexes(self, complexes):
        """
        Fully updates the TMS's list of Producer complexes.
        Primarily used for Producer updates.
        
        .. http_method_uri:: messaging/update_complexes
            :category: Producer_complex
        
        :param complexes: List of complexes
        :type complexes: JSON
        
        :returns: Status message (JSON)
        
        Example Request::
        
            /messaging/update_complexes?complexes=[{
                "name":"cinema awesome",
                "external_id":1,
                "current": true
            },{
                "name":"cinema more awesome",
                "external_id":2,
                "current": false
            }]
        
        Example Response::
        
            {
                "data": {},
                "messages":
                    [
                        {
                            "data": {},
                            "message": "Producer Complexes have been added successfully.",
                            "type": "success"
                        }
                    ]
            }
        
        """
        return {'data': {},
         'messages': [self.service.update_complexes(complexes)]}

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def status(self):
        """
        Returns a the status of the chat service
        
        :returns: List of Messages
        
        Example HTTP request::
        
            /messaging/status
        
        Example HTTP response::
        
        {
            "data": {
                "count": 9001
            },
            "messages": []
        }
        
        """
        result = self.service.status()
        return {'messages': result['messages'],
         'data': result['data']}
# okay decompyling ./core/api/messaging_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:05 CST
