# 2017.08.13 21:48:04 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\macropack_api.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.macropack_service import MacroPackService

class MacroPackAPI(API):

    def __init__(self, core):
        super(MacroPackAPI, self).__init__(core)
        self.service = MacroPackService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.macropack_information)
        cherrypy.engine.publish('cclisten', 'request_macropack_information', self.macropack_information)

    def macropack_information(self, payload):
        """
        Handles `request_macropack_information` event from Circuit Core.
        
        Sent as part of the start up sync. Send all macropack and
        macropack placeholder information up to Circuit Core.
        """
        macro_packs = self.service.macro_packs(show_deleted=True)
        cherrypy.engine.publish('ccpush', 'macropack_information', {'macropacks': macro_packs}, target=payload['url'])
        cherrypy.engine.publish('ccpush', 'request_macro_placeholders', target=payload['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['macro_packs'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save(self, macro_packs):
        """
        Saves or updates macro packs currently in the DB
        
        :param macro_packs: list of macro packs
        :returns: status message
        
        Example HTTP request::
        
            /macro_pack/save?macro_packs=[
                {
                    "uuid":null,
                    "macro_placeholder_uuid":"201d9185-9b8d-5582-9d58-fc8d7aad153a",
                    "device_uuid":"7d4cb238-4425-400c-bed6-a91c13e96a28",
                    "event_list":[{"type":"composition","cpl_id":"948ca9aa-f35e-4973-8684-b190af9cf93d","duration_in_seconds":9.25,"duration_in_frames":222,"edit_rate":[24,1],"text":"BFI-JELLYBEAN_S_EN-XX_UK_0_2K_BFI_20120606_AAM_OV","automation":[]}
                    ]
                }]
        
        Example HTTP response::
        {
            messages: [
                {
                    "message" : "Macro Pack created",
                    "type" : success,
                    "macro_pack_uuid" : "d2027dd2-0b1d-46df-9694-09abb68acc1b"
                }
            ],
            data: { }
        }
        """
        messages = self.service.save(macro_packs)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['macro_pack_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, macro_pack_uuids, hard = False):
        """
        Deletes the specified macro packs from core;
        
        :param macro_pack_uuids: list of macro pack identifiers
        :returns: status message
        
        Example HTTP request::
        
           /macro_pack/delete?macro_pack_uuids=["2b509e73-f482-45c4-9d7c-0ad147d60589"]
        
        Example HTTP response::
        {
            messages: [
               {
                  'type':'success',
                  'message': 'Macro Pack(s) deleted',
                },
            data: { }
        }
        """
        message = self.service.delete(macro_pack_uuids, hard=hard)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['macro_pack_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def macro_packs(self, macro_pack_uuids = [], show_deleted = False):
        """
        Return list of macro packs
        
        :param macro_pack_uuids: optional list of macro pack identifiers
        :returns: list of macro packs
        
        Example HTTP request::
        
           /macro_pack/macro_packs?macro_pack_uuids=["2b509e73-f482-45c4-9d7c-0ad147d60589"]
        
        Example HTTP response::
        {
            messages: [ ],
            data: {
                2b509e73-f482-45c4-9d7c-0ad147d60589: {
                    event_list: [
                        {
                            duration_in_frames: 120,
                            cpl_id: "eada2b14-5c56-4830-bd3c-4cca34eec19e",
                            edit_rate: null,
                            text: "BLACK05_XSN_S_XX-XX_INT_51_2K_Qube_20090428_QUBE",
                            automation: [ ],
                            duration_in_seconds: 5,
                            type: "composition",
                            content_kind: "transitional"
                        },
                        {
                            duration_in_frames: 120,
                            cpl_id: "7450e532-f003-4cea-a711-552f605518d9",
                            edit_rate: null,
                            text: "BLACK05_XSN_F_XX-XX_INT_51_2K_Qube_20090428_QUBE",
                            automation: [ ],
                            duration_in_seconds: 5,
                            type: "composition",
                            content_kind: "transitional"
                        }
                    ],
                    last_modified: 1357819721.654,
                    uuid: "2b509e73-f482-45c4-9d7c-0ad147d60589",
                    macro_placeholder_uuid: "38b4e40f-2cf2-50ff-acd5-f3e53b6baa71",
                    device_uuid: "495b3327-aeed-4047-b2c6-250116c3f497"
                }
            }
        }
        """
        macro_pack_details = self.service.macro_packs(macro_pack_uuids, show_deleted)
        return {'data': macro_pack_details,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def macro_placeholders(self, auto_transition = False):
        """
        Return list of macro placeholders
        
        :param auto_transition: Optional boolean parameter for auto-transitions. Default is False.
        
        :returns: list of macro placeholders
        
        Example HTTP request::
        
           /macro_pack/macro_placeholders
        
        Example HTTP response::
           {
             "messages": [],
             "data": {
                b9ce2845-46c5-5157-976a-64d8d4df31c8: {
                    transition: false,
                    has_content: true,
                    uuid: "b9ce2845-46c5-5157-976a-64d8d4df31c8",
                    can_delete: true,
                    name: "placeholder"
                }
             }
           }
        """
        macro_placeholder_details = self.service.macro_placeholders(auto_transition)
        return {'data': macro_placeholder_details,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['has_content'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_macro_placeholder(self, macro_placeholder_name, has_content = True):
        """
        Save the given macro placeholder
        
        :param macro_placeholder_name: required name of macro placeholder
        :param has_content: optional flag specifying whether there is content associated with this macro placeholder
        
        :returns: status message
        
        Example HTTP request::
        
           /macro_pack/save_macro_placeholder?macro_placeholder_name="My Placeholder"
        
        Example HTTP response::
        
           {
             "messages": [{
                "type": "success",
                "message": "Macro Placeholder saved."
             }],
             "data": {}
           }
        """
        message = self.service.save_macro_placeholder(macro_placeholder_name, has_content)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['macro_placeholder_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_macro_placeholders(self, macro_placeholder_uuids = []):
        """
        Deletes the specified macro placeholders and associated macro packs
        
        :param macro_placeholder_uuids: list of macropack placeholder identifiers
        :returns: status message
        
        Example HTTP request::
        
           /macro_pack/delete_macro_placeholders?macro_placeholder_uuids=["aaec87d7-bc77-411d-8987-87023d93c49f"]
        
        Example HTTP response::
        
           {
             "messages": [{
                "type":"success",
                "message":_("Macro Placeholder deleted."),
                "placeholder_uuid": "aaec87d7-bc77-411d-8987-87023d93c49f"
             }],
             "data": {}
           }
        """
        messages = self.service.delete_macro_placeholders(macro_placeholder_uuids)
        return {'data': {},
         'messages': messages}
# okay decompyling ./core/api/macropack_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:04 CST
