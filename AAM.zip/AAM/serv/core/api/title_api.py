# 2017.08.13 21:48:13 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\title_api.py
import cherrypy
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.title_service import TitleService

class TitleAPI(API):

    def __init__(self, core):
        super(TitleAPI, self).__init__(core)
        self.service = TitleService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.config_synced)

    def config_synced(self, data):
        """
        Handle `config_synced` event from Circuit Core.
        
        Sent as part of the start up sync. We send all title_uuid with
        last_modified and Circuit Core will send us all missing/updated.
        """
        cherrypy.engine.publish('ccpush', 'title_maps', {'title_maps': self.service.external_titles()}, target=data['url'])
        cherrypy.engine.publish('ccpush', 'cpl_titles', {'cpl_uuids': cherrypy.core.contents.keys(),
         'titles_last_modified': self.service.producer_last_modified()}, target=data['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['title'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save(self, title, from_producer = False):
        """
        Saves a new or existing Title.
        
        .. http_method_uri:: title/save
            :category: Title
        
        :param title: The Title.
        :param from_producer: Set true if saving from Producer [default: False].
        :type title: JSON dict
        :type from_producer: Bool
        
        :returns: Status message (JSON)
        
        Example Request::
        
            {
                "title": {
                    "uuid": null,    # If present and exists, edits this title
                    "name": "Gladiator",    # [Required]
                    "cpls": ["37137e08-d515-4bec-a08f-c4a28e22e827"],    # CPLs associated with this title [Required]
                    "external_titles": [{    # [Required]
                        "external_id": "4a6a8379-b6f3-4e11-8383-fa46fc10abc1",    # Source ID
                        "source": "AAM"    # Source name
                    }],
                    "last_modified": 1401992664,    # [Required if from_producer=True]
                    "year": 1991,    # [Default: <current_year>]
                    "credits_offset": 5000,    # Seconds from start
                    "ratings": [{
                        "territory": "UK",
                        "rating": "PG"
                    }],
                }
            }
        
        Example Response::
        
            {
                "data": {},
                "messages": [
                     {
                        "message": "Saved Gladiator",
                        "type": "success"
                    }
                ],
                "uuid": "bc13ae08-d515-4bec-a08f-c4a28e22e2df"
            }
        
        """
        uuid, message = self.service.save(title, from_producer)
        return {'data': {},
         'messages': [message],
         'uuid': uuid}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['title_list'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_multiple(self, title_list):
        """
        Saves multiple titles at once.
        
        .. http_method_uri:: title/save_multiple
            :category: Title
        
        :param title_list: all titles to save.
        :type title_list: JSON list of dicts
        
        :returns: Status messages as for 'save', one per title specified (JSON)
        
        """
        messages, uuids = self.service.save_multiple(title_list)
        return {'data': {'uuids': uuids},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def last_modified(self):
        """
        Returns a list of all title last_modified timestamps
        
        .. http_method_uri:: title/last_modified
            :category: Title
        
        :returns: last_modified info for all titles
        
        Example HTTP response::
        
            {
                "messages": [],
                "data": {
                    "37137e08-d515-4bec-a08f-c4a28e22e827": 1351153234.8455,
                    "30eda2c4-d071-413a-a416-f26bfded01b0": 1359627141.39653,
                }
            }
        
        """
        return {'data': self.service.last_modified(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['title_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, title_uuids):
        """
        Deletes the specified titles from core
        
        .. http_method_uri:: title/delete
            :category: Title
        
        :param title_uuids: list of title identifiers
        :type title_uuids: JSON list of strings
        
        :returns: status message
        
        Example HTTP request::
        
           /delete?title_uuids=["70b86c59-4018-4d2f-bca6-be9bb16a0e64"]
        
        Example HTTP response::
        
            {
                messages: [
                    {
                        message: "Titles deleted: [My Title]",
                        type: "success"
                    }
                ],
                data: {}
            }
        
        """
        messages = self.service.delete(title_uuids)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['cpl_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_title_with_cpl(self, cpl_uuid):
        """
        Retrieves information about all titles that reference the given CPL identifier
        
        .. http_method_uri:: title/get_title_with_cpl
            :category: Title
        
        :param cpl_uuid: required CPL identifier
        
        :returns: list of titles that reference CPL
        
        Example HTTP request::
        
           /title/get_title_with_cpl?cpl_uuid="70b86c59-4018-4d2f-bca6-be9bb16a0e64"
        
        Example HTTP response::
        
            {
                "messages": [],
                "data": [{
                    "uuid": "70b86c59-4018-4d2f-bca6-be9bb16a0e64",
                    "name": "Gladiator"
                }]
            }
        
        """
        titles_with_cpls_list = self.service.get_title_with_cpl(cpl_uuid)
        return {'data': titles_with_cpls_list,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def external_titles(self, uuids = None):
        """
        Returns information about external titles with the given uuids (or all if this not supplied)
        
        .. http_method_uri:: title/external_titles
            :category: Title
        
        :returns: dict of external_titles
        
        Example HTTP response::
        
            {
                "messages": [],
                "data": [
                    {
                        title_uuid: "51869acf-c94d-47c0-aeee-7fba0433cb73",
                        producer_last_modified: null,
                        name: "Best Ever Feature",
                        source_type: "AAM",
                        source: "AAM",
                        external_id: "51869acf-c94d-47c0-aeee-7fba0433cb73"
                    }
                ]
            }
        
        """
        return {'data': self.service.external_titles(uuids),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def unmatched_titles(self):
        """
        Get all the feature titles from the POS table and Packs that have not been matched to a Title
        
        .. http_method_uri:: title/unmatched_titles
            :category: Title
        
        :returns: list of unmatched titles
        
        Example HTTP request::
        
            /core/title/unmatched_titles
        
        Example HTTP response::
        
            {
                "messages": [],
                "data": {
                    "vista": [
                        "27 Dresses",
                        "Gladiator"
                    ]
                }
            }
        
        """
        return {'data': self.service.unmatched_titles(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['title_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def title(self, title_uuids = []):
        """
        Returns information about Titles
        
        .. http_method_uri:: title/title
            :category: Title
        
        
        :param title_uuids: list of title identifiers (*Optional) [default: all]
        
        :returns: dictionary of title information
        
        Example HTTP request::
        
           /title/title?title_uuids=["70b86c59-4018-4d2f-bca6-be9bb16a0e64"]
        
        Example Response::
        
            {
                "messages": [],
                "data": {
                    "70b86c59-4018-4d2f-bca6-be9bb16a0e64": {    # title uuid
                        "ratings": [ ],    # List of territories and ratings, otherwise empty list
                        "uuid": "70b86c59-4018-4d2f-bca6-be9bb16a0e64",    # title uuid
                        "cpl_uuids": [    # associated CPL UUIDs for this title
                            "62d9c37c-9f82-4de7-8696-4a376040869b",
                            "b4324dc0-8a74-45d2-8641-d3c3d0d0b56f"
                        ],
                        "last_modified": 1378720818,    # last modified time stamp
                        "external_ids": [    # This is the matching between this Title, and third party title names
                            {
                                "source": "AAM",
                                "external_id": "2999171e-2c7d-4b7b-915f-545cbd064fcc"
                            },
                            {
                            "source": "vista",    # someone has associated this title with the name from vista
                            "external_id": "silver_linings_playbook"
                            }
                        ],
                        "name": "Silver Linings Playbook"
                    },
                }
            }
        
        """
        return {'data': self.service.title(title_uuids),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['source', 'external_id', 'title_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def unmatch_external_title(self, source, external_id, title_uuid):
        """
        Un-maps an external Title (from POS, Pack feed etc) from a Title
        
        .. http_method_uri:: title/unmatch_external_title
            :category: Title
        
        :param source: required string identifying title's source
        :param external_id: required string identifying title
        :param title_uuid: required uuid of title to be mapped
        
        :returns: status message
        
        Example HTTP request::
        
           /title/unmatch_external_title?source="pos"&external_id="Gladiator"&title_uuid="70b86c59-4018-4d2f-bca6-be9bb16a0e64"
        
        Example HTTP response::
        
            {
                "messages": [
                    {
                        "type": "success",
                        "message": "Title mapping deleted"
                    }
                ],
                "data": {}
            }
        
        """
        message = self.service.unmatch_external_title(source, external_id, title_uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['source', 'external_id', 'title_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def match_external_title(self, source, external_id, title_uuid):
        """
        Maps an external Title (from POS, Pack feed etc) to a Title
        
        .. http_method_uri:: title/match_external_title
            :category: Title
        
        :param source: required string identifying title's source
        :param external_id: required string identifying title
        :param title_uuid: required uuid of title to be mapped
        
        :returns: status message
        
        Example HTTP request::
        
           /title/match_external_title?source="pos"&external_id="Gladiator"&title_uuid="70b86c59-4018-4d2f-bca6-be9bb16a0e64"
        
        Example HTTP response::
        
            {
                "messages": [
                    {
                        "type" : "success",
                        "message" : "External Title has been mapped"
                    }
                ],
                "data": {}
            }
        
        """
        message = self.service.match_external_title(source, external_id, title_uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['external_titles', 'title_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def match_external_titles(self, external_titles, title_uuid = None):
        """
        Maps external Titles (from POS, Pack feed etc) to a Title.
        This is essentially the same as match_external_title as it calls that service multiple times
        and returns the accumulated results.
        
        .. http_method_uri:: title/match_external_titles
            :category: Title
        
        :param external_titles: required list of external titles
        :param title_uuid: uuid of title to be mapped - leave null to create new title
        
        :returns: status messages
        
        """
        messages = self.service.match_external_titles(external_titles, title_uuid)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['source_title_uuid', 'destination_title_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def merge(self, destination_title_uuid, source_title_uuid):
        """
        Merges a Title (source) into another Title (destination)
        Note: The source_title will be deleted!
        Anything pointing at it, will be re-mapped to the destination title after execution of this method.
        Specifically, this method:
        1. Updates TitleCplMap
        2. Updates TitleRatingMap
        3. Updates ExternalTitleMaps
        4. Updates Pack  (this is different to producer where packs are mapped to title_map_uuids)
        5. Delete source title
        6. Updates last modified time for destination title
        
        .. http_method_uri:: title/merge
            :category: Title
        
        :param destination_title_uuid: string, UUID of the destination title
        :param source_title_uuid: string, UUID of the source title
        :type destination_title_uuid: UUID
        :type source_title_uuid: UUID
        
        :returns: status message
        
        Example HTTP request::
        
           merge?source_title_uuid="3506cd49-c097-4569-86f6-0721eae3f50b"&destination_title_uuid="70b86c59-4018-4d2f-bca6-be9bb16a0e64"
        
        Example HTTP response::
        
            {
                "messages": [
                    {
                        "type" : "success",
                        "message" : "Titles merged successfully"
                    }
                ],
                "data": {}
            }
        
        """
        message = self.service.merge(destination_title_uuid, source_title_uuid)
        return {'data': {},
         'messages': [message]}
# okay decompyling ./core/api/title_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:13 CST
