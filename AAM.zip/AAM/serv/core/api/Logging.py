# 2017.08.13 21:48:04 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\Logging.py
import cherrypy
from serv.lib.utilities.helper_methods import API
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.core.services.logging_service import LoggingService
import serv.lib.cherrypy.custom_tools.all

class Logging(API):

    def __init__(self, core):
        super(Logging, self).__init__(core)
        self.log_manager = core.log_manager
        self.service = LoggingService(core)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def playbacks(self, modified_after = 0, chunk_size = 0):
        """
        Get playback information.
        
        .. http_method_uri:: logging/playbacks
            :category: Logging
        
        :param modified_after: Timestamp playbacks have been modified after.
        :param chunk_size: Maximum number of playbacks to fetch.
        :type modified_after: Integer
        :type chunk_size: Integer
        
        :returns: Playback information (JSON)
        
        Example Request::
        
            /logging/playbacks?modified_after=1399568731&chunk_size=100
        
        Example Response::
        
            {
                "data":[
                    {
                        "uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "start": 1399568731,
                        "end": 1399568731,
                        "duration": 6000,
                        "intermission_start": 1399568731,
                        "intermission_end": 1399568731,
                        "dnqualifier": "dnqualifier",
                        "device_ip_address": "127.0.0.1",
                        "serial": 0000001,
                        "feature_cpl_uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "content_kind": "feature",
                        "cpl_uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "merge_error_code": 0,
                        "live_log_uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "meta": {},
                    }
                ],
                "messages": []
            }
        
        """
        return {'data': self.service.playbacks(int(modified_after), int(chunk_size)),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def playback_groups(self, modified_after = 0, chunk_size = 0):
        """
        Returns a collection of uuids modified after `modified_after`, grouped together by their last_modified time,
        the number of groups being determined by chunk_size.
        
        .. http_method_uri:: logging/playback_groups
            :category: Logging
        
        :param modified_after: POSIX timestamp of the lowest possible last_modified timestamp requested.
        :param chunk_size: The amount of groups we should return.
        :type modified_after: Integer
        :type chunk_size: Integer
        
        :returns: Playback information list (JSON)
        
        Example Request::
        
            /logging/playback_groups?modified_after=1399568731&chunk_size=100
        
        Example Response::
        
            [{
                "last_modified": "1395240310",
                "uuids": ["24970bc0-af75-11e3-a5e2-0800200c9a66"]
            }, {
                "last_modified": "1395240316",
                "uuids": ["456afa00-af75-11e3-a5e2-0800200c9a66",
                          "4c227d50-af75-11e3-a5e2-0800200c9a66"]
            }, {
                "last_modified": "1395240317",
                "uuids": ["57811a80-af75-11e3-a5e2-0800200c9a66"]
            }, {
                "last_modified": "1395240320",
                "uuids": ["5b5776e0-af75-11e3-a5e2-0800200c9a66",
                          "62e62050-af75-11e3-a5e2-0800200c9a66",
                          "6762a7c0-af75-11e3-a5e2-0800200c9a66"]
            }]
        
        """
        return {'data': self.service.playback_groups(int(modified_after), int(chunk_size)),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def playbacks_by_uuids(self, uuids = []):
        """
        Returns a dictionary of playbacks for given UUIDs.
        
        .. http_method_uri:: logging/playbacks_by_uuids
            :category: Logging
        
        :param uuids: List of playback identifiers
        :type uuids: JSON
        
        :returns: Playback information (JSON)
        
        
        Example Request::
        
            /logging/playbacks_by_uuids?uuids=["24970bc0-af75-11e3-a5e2-0800200c9a66"]
        
        Example Response::
        
            {
                "data": {
                    "24970bc0-af75-11e3-a5e2-0800200c9a66":{
                        "uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "start": 1399568731,
                        "end": 1399568731,
                        "duration": 6000,
                        "intermission_start": 1399568731,
                        "intermission_end": 1399568731,
                        "dnqualifier": "dnqualifier",
                        "device_ip_address": "127.0.0.1",
                        "serial": 0000001,
                        "feature_cpl_uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "content_kind": "feature",
                        "cpl_uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "merge_error_code": 0,
                        "live_log_uuid": "24970bc0-af75-11e3-a5e2-0800200c9a66",
                        "meta": {},
                    }
                },
                "messages": []
            }
        
        """
        data, messages = self.service.playbacks_by_uuids(uuids)
        return {'data': data,
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def recollect_smpte_logs(self, screen_identifiers = [], start_timestamp = None, end_timestamp = None):
        """
        Mark SMPTE log files for recollection (which will also do a reparse and remerge).
        Non-extant logs will have placeholders made for them so initial collection can be attempted.
        
        .. http_method_uri:: logging/recollect_smpte_logs
            :category: Logging
        
        :param screen_identifiers: List of screen identifiers to recollect SMPTE logs from *(optional)* *(default=All)*
        :param start_timestamp: Recollect logs from here onwards (inclusive). *(optional)* *(default=Yesterday)*
        :param end_timestamp: Last collection time (inclusive). *(optional)* *(default=Yesterday)*
        :type screen_identifiers: JSON
        :type start_timestamp: Integer
        :type end_timestamp: Integer
        
        :returns: Info about which logs have been marked for collection, and which have had placeholders made for them (JSON)
        
        Example Request::
        
            /logging/recollect_smpte_logs?screen_identifiers=["1"]&start_timestamp=1399568731&end_timestamp=1399868731
        
        Example Response::
        
            {
                "data": {
                    "repull": {
                        1: ["2014-01-01"]
                    },
                    "newpull": {
                        1: ["2014-01-02"]
                    }
                },
                "messages": []
            }
        
        """
        device_ips = self.log_manager.get_screen_ips(screen_identifiers)
        output = {'messages': [],
         'data': self.log_manager.recollect_smpte_logs(device_ips, start_timestamp, end_timestamp)}
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def recollect_smpte_logs_by_uuid(self, uuids = []):
        """
        Mark SMPTE log files for recollection (which will also do a reparse and remerge).
        Skips log for which the uuids do not exist.
        
        .. http_method_uri:: logging/recollect_smpte_logs_by_uuid
            :category: Logging
        
        :param uuids: List of log file identifiers we want to recollect
        :type uuids: JSON
        
        :returns: List of identifiers for new log files (JSON)
        
        Example Request::
        
            /logging/recollect_smpte_logs_by_uuid?uuids=["24970bc0-af75-11e3-a5e2-0800200c9a66"]
        
        Example Response::
        
            {
                "data": {
                    "non_existant_uuids": [
                        "24970bc0-af75-11e3-a5e2-0800200c9a66"
                    ]
                },
                "messages": []
            }
        
        """
        output = {'messages': [],
         'data': self.log_manager.recollect_smpte_logs_by_uuid(uuids)}
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def reparse_smpte_logs(self, screen_identifiers = [], start_timestamp = None, end_timestamp = None):
        """
        Reparse SMPTE log files to get updated playouts, then start a re-merge.
        
        .. http_method_uri:: logging/reparse_smpte_logs
            :category: Logging
        
        :param screen_identifiers: List of screen identifiers whose logs should be recollected. *(optional)*
        :param start_timestamp: Recollect logs from here onwards (inclusive). *(optional)* *(default=Yesterday)*
        :param end_timestamp: Last collection time (inclusive). *(optional)* *(default=Yesterday)*
        :type screen_identifiers: JSON
        :type start_timestamp: Integer
        :type end_timestamp: Integer
        
        :returns: Info for each parsed log with counts of full and partial playouts (JSON)
        
        Example Request::
        
            /logging/reparse_smpte_logs?screen_identifiers=["2"]&start_timestamp=1399568731&end_timestamp=1399868731
        
        Example Response::
        
            {
                "data": [
                    {
                        "device": "10.58.4.72",
                        "date": "2014-01-01",
                        "uncrypt": true,
                        "result": {
                            "full": 34,
                            "partial": 5,
                            "resolved_partial": 1
                        }
                    },
                    {
                        "device": "10.58.4.72",
                        "date": "2014-01-02",
                        "uncrypt": true,
                        "error": "db_log exists but is un-pulled: Collection ERROR: No XML returned"
                    },
                    
                ],
                "messages": []
            }
        
        """
        device_ips = self.log_manager.get_screen_ips(screen_identifiers)
        output = {'messages': [],
         'data': self.log_manager.reparse_smpte_logs(device_ips, start_timestamp, end_timestamp)[0]}
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def remerge_smpte_logs(self, screen_identifiers = [], start_timestamp = None, end_timestamp = None):
        """
        Remerge SMPTE log files to get updated playbacks.
        
        .. http_method_uri:: logging/remerge_smpte_logs
            :category: Logging
        
        :param screen_identifiers: List of screen identifiers whose logs should be recollected. *(optional)* *(default=All)*
        :param start_timestamp: Recollect logs from here onwards (inclusive). *(optional)* *(default=24 Hours ago)*
        :param end_timestamp: Last collection time (exclusive). *(optional)* *(default=Now)*
        :type screen_identifiers: JSON
        :type start_timestamp: Integer
        :type end_timestamp: Integer
        
        :returns: Status Message (JSON)
        
        Example Request::
        
            /logging/remerge_smpte_logs?screen_identifiers=["2"]&start_timestamp=1399568731&end_timestamp=1399868731
        
        Example Response::
        
            {
                "data": {
                    "unmapped": 1,
                    "reset": 4,
                    "deleted": 2,
                },
                "messages": []
            }
        
        """
        device_ips = self.log_manager.get_screen_ips(screen_identifiers)
        output = {'messages': [],
         'data': self.log_manager.remerge_smpte_logs(device_ips, start_timestamp, end_timestamp)}
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def log_files(self, modified_after = 0, chunk_size = 0, include_raw = False):
        """
        Retrieve log file information.
        
        .. http_method_uri:: logging/log_files
            :category: Logging
        
        :param modified_after: POSIX timestamp of the lowest possible last_modified timestamp requested. *(optional)*
        :param chunk_size: The amount log_files to return.
        :param include_raw: Flag to specify whether to include raw log data.
        :type modified_after: Integer
        :type chunk_size: Integer
        :type include_raw: Boolean
        
        :returns: Information for retrieved log files (JSON)
        
        Example Request::
        
            /logging/log_files?modified_after=1399568731
        
        Example Response::
        
            {
                "data": {
                    "log_files": [{
                        "uuid": "e23dfebc-9444-47c3-ac53-5ca6c17e5707",
                        "created": 1392914570,
                        "dnqualifier": "Gio9Szty8daEiFpFUVMv2uiackk=",
                        "error_message": null,
                        "signed": null,
                        "screen_identifier": "1",
                        "absolute_file_path": "/lms-data/device_store/1/2014-02-19.zip",
                        "unencrypted": false,
                        "device_ip_address": "10.58.4.26",
                        "last_modified": 1392914570,
                        "repull_marked": false,
                        "date": "2014-02-19",
                        "serial": "510541",
                        "parse_attempted": false,
                        "pulled": false,
                        "parsed": true,
                        "pull_attempted": true,
                        "no_playouts": null
                    }]
                },
                "messages": []
            }
        
        """
        log_files, messages = self.service.log_files(modified_after, chunk_size, include_raw)
        return {'data': {'log_files': log_files},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.gzip(mime_types=['application/json'], compress_level=9)
    @cherrypy.tools.json_input(json_list=['log_file_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def raw(self, log_file_uuids = []):
        """
        Get log file information for given log file uuids, including the raw log data.
        
        .. http_method_uri:: logging/raw
            :category: Logging
        
        :param log_file_uuids: List of log file identifiers.
        :type log_file_uuids: JSON
        
        :returns: Information for given log file uuids. (JSON)
        
        Example Request::
        
            /logging/raw?log_file_uuids=["e23dfebc-9444-47c3-ac53-5ca6c17e5707"]
        
        Example Response::
        
            {
                "data": {
                    "e23dfebc-9444-47c3-ac53-5ca6c17e5707": {
                        "uuid": "e23dfebc-9444-47c3-ac53-5ca6c17e5707",
                        "created": 1392914570,
                        "dnqualifier": "Gio9Szty8daEiFpFUVMv2uiackk=",
                        "error_message": null,
                        "signed": null,
                        "screen_identifier": "1",
                        "absolute_file_path": "/lms-data/device_store/1/2014-02-19.zip",
                        "unencrypted": false,
                        "device_ip_address": "10.58.4.26",
                        "last_modified": 1392914570,
                        "repull_marked": false,
                        "date": "2014-02-19",
                        "serial": "510541",
                        "parse_attempted": false,
                        "pulled": false,
                        "parsed": true,
                        "pull_attempted": true,
                        "no_playouts": null,
                        "xml": '<?xml version="1.0" encoding="UTF-8"?> <!-- Result has been filtered by: --> <!-- timestamp_min: 2013-06-08T00:00:00+01:00 --> <!-- timestamp_max: 2013-06-09T00:00:00+01:00 --> <lr:LogReport xmlns:dcml="http://www.smpte-ra.org/schemas/433/2008/dcmlTypes/" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:lr="http://www.smpte-ra.org/schemas/430-4/2008/LogRecord/" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"> <lr:reportDate>2013-09-05T14:02:22+01:00</lr:reportDate> <lr:reportingDevice> <dcml:DeviceIdentifier idtype="CertThumbprint">DpHWiU+RffUen33GcZ9jW+kPs+g=</dcml:DeviceIdentifier> <dcml:DeviceTypeID scope="http://www.smpte-ra.org/schemas/433/2008/DCMLTypes/#DeviceTypeTokens">SM</dcml:DeviceTypeID> <dcml:DeviceSerial>219319</dcml:DeviceSerial> <dcml:ManufacturerName>Doremi Labs, Inc.</dcml:ManufacturerName> <dcml:DeviceName>DevDoremiDCP1.aam.local</dcml:DeviceName> <dcml:ModelNumber>DCP2000</dcml:ModelNumber> <dcml:VersionInfo> <dcml:Name>Software Version</dcml:Name> <dcml:Value>2.4.2-0</dcml:Value> <dcml:Name>Firmware Version</dcml:Name> <dcml:Value>21.3s</dcml:Value> </dcml:VersionInfo> </lr:reportingDevice> </lr:LogReport> '
                    }
                },
                "messages": []
            }
        
        """
        log_files, messages = self.service.log_files_by_uuid(log_file_uuids)
        return {'data': log_files,
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def log_file_groups(self, modified_after = 0, chunk_size = 0):
        """
        Get log file uuids grouped by last modified time.
        
        .. http_method_uri:: logging/log_file_groups
            :category: Logging
        
        :param modified_after: POSIX timestamp of the lowest possible last_modified timestamp requested.
        :param chunk_size: The amount of groups we should return.
        :type modified_after: Integer
        :type chunk_size: Integer
        
        :returns: Grouped log file uuids (JSON)
        
        Example Request::
        
            /logging/log_file_groups?modified_after=1399568731
        
        Example Response::
        
            {
                messages: [ ],
                data: [
                    {
                        last_modified: 1397520713,
                        uuids: [
                            "2a0bf33d-0df6-5781-be11-0f36b6881eca"
                        ]
                    },
                    {
                        last_modified: 1397520749,
                        uuids: [
                            "c71b973d-8209-5b30-aeaa-534ae3622d5d"
                        ]
                    },
                ]
            }
        
        """
        groups = self.service.log_file_groups(modified_after, chunk_size)
        return {'data': groups,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def log_files_by_uuids(self, uuids):
        """
        Get a dictionary of log files given by UUIDs including raw xml log data.
        
        .. http_method_uri:: logging/log_files_by_uuids
            :category: Logging
        
        :param uuids: List of uuids for which we want log files.
        :type uuids: JSON
        
        :returns: List of log_files for a given list of uuids. (JSON)
        
        Example Request::
        
            /logging/log_files_by_uuids?uuids=["2a0bf33d-0df6-5781-be11-0f36b6881eca"]
        
        Example Response::
        
            {
                "messages": [],
                "data": {
                    "e9902299-9402-5f9e-83fe-e1b300d809a3": {
                        "xml": "<?xml version=1.0 encoding=UTF-8 standalone=yes ?> <...",
                        "uuid": "e9902299-9402-5f9e-83fe-e1b300d809a3",
                        "created": 1397176148,
                        "dnqualifier": "Gio9Szty8daEiFpFUVMv2uiackk=",
                        "error_message": "Parser WARNING: some playouts parsed with an unexpected date",
                        "signed": false,
                        "screen_identifier": "2",
                        "absolute_file_path": "/lms-data/device_store/2/2014-04-09_Unencrypted.zip",
                        "unencrypted": true,
                        "device_ip_address": "10.58.4.26",
                        "last_modified": 1397520764,
                        "repull_marked": false,
                        "no_playouts": false,
                        "date": "2014-04-09",
                        "serial": "510541",
                        "parse_attempted": true,
                        "pulled": true,
                        "parsed": true,
                        "pull_attempted": true
                    }
                }
            }
        
        """
        log_files, messages = self.service.log_files_by_uuid(uuids)
        return {'data': log_files,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def trigger_collect_smpte_logs(self):
        """
        Initiate log manager to collect device logs. Force overrides any TMS config about timeframes etc.
        Beware that this call may timeout as the collection process can take a virtually unbounded amount of time to run.
        
        .. http_method_uri:: logging/trigger_collect_smpte_logs
            :category: Logging
        
        :returns: Status Message (JSON)
        
        Example Request::
        
            /logging/trigger_collect_smpte_logs
        
        Example Response::
        
            {
                "data": "Successfully collected and parsed 3 logs. 15 marked for recollection",
                "messages": []
            }
        
        """
        message = self.log_manager.collect_smpte_logs(True)
        return {'data': message,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_schedule_divergence(self):
        """
        Get schedule divergence information, ie. discrepancies between POS show times and actual show times.
        
        .. http_method_uri:: logging/get_schedule_divergence
            :category: Logging
        
        :returns: pre-calculated POS/Playback mappings (JSON)
        
        Example Request::
        
            /logging/get_schedule_divergence
        
        Example Response::
        
            {
                "data": {
                    "schedule_map": [{
                        "display_date": "2014-03-14",
                        "screen_identifier": "2",
                        "playback_uuid": "b2f6c08b-cce3-4905-92c9-f3149630ba04",
                        "playback_feature_start_timestamp": 1394829000, #Approx. adjusted start based on POS feature_duration
                        "playback_end_timestamp": 1395199803,
                        "playback_cpl_uuid": "f2f6c08b-cce3-4905-92c9-f3149630ba04",
                        "playback_cpl_pos_title": "The Wolf Of Wall Street", # POS title associated to this CPL via external_title_map
                        "pos_uuid": "b2f6c08b-cce3-4905-92c9-f3149630ba07",
                        "pos_feature_title": "300: RISE OF AN EMPIRE",
                        "pos_source": "aam_extreme_pos",
                        "pos_start_timestamp": 1394829000,
                        "pos_end_timestamp": 1395199800,
                        "start_match": true, # POS and playback start times are within leeway
                        "end_match": false,
                        "title_match": false, # playback_cpl_pos_title == pos_title
                    }],
                    "from_timestamp": 1394199800
                },
                "messages": []
            }
        """
        return {'data': self.log_manager.get_schedule_divergence_data(),
         'messages': []}
# okay decompyling ./core/api/Logging.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:04 CST
