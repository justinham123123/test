# 2017.08.13 21:48:06 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\pack_api.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.pack_service import PackService

class PackAPI(API):

    def __init__(self, core):
        super(PackAPI, self).__init__(core)
        self.service = PackService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.request_packs)

    def request_packs(self, payload):
        cherrypy.engine.publish('ccpush', 'request_packs', {}, target=payload['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def add_pack_xml(self, pack):
        """
        Upload Pack XML.
        
        :param pack: - XML string representing pack to save
        Example HTTP request::
        
            /pack/add_pack_xml?pack="< your pack xml>"
        
        Example HTTP response::
        
        <?xml version="1.0" encoding="UTF-8"?>
        <AAMPack xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="pack_schema.xsd">
            <UUID>SOME UUID</UUID> ->> Optional, this is created if none provided, and return it from the call. Send pack again with same uuid to update
            <AnnotationText>Pack API Test My movie</AnnotationText> ->> The title of the pack
            <IssueDate>2011-08-10T15:00:00Z</IssueDate> ->> Date this pack was created/issued
            <Issuer>Ad Agency</Issuer> ->> Issuer of the pack
            <Placeholder>Silver Screen Ads</Placeholder> ->> we auto create the placeholder in the TMS if the placeholder does not exist in the system already.
            <PrintNumber>1</PrintNumber> ->> Optional - can be used to tie the pack to a print number
            <ComplexName>SomeComplex</ComplexName>
                        Date /time ranges not required - if no dates then pack is valid for every date, no times then pack is valid for all the day
            <NotValidBeforeDate>2013-08-01</NotValidBeforeDate> Optional: If not specified, pack is valid from now until the NotValidAfterDate date.
            <NotValidBeforeTime>10:00:00</NotValidBeforeTime> Optional: If not specified, pack is valid from now until the NotValidAfterTime value
            <NotValidAfterDate>2013-08-10</NotValidAfterDate> Optional: If not specified, pack is valid from the NotValidBeforeDate date and beyond
            <NotValidAfterTime>15:00:00</NotValidAfterTime> Optional: If not specified, pack is valid from NotValidBeforeTime until the end of the day
            <TargetRatingCertificate>PG</TargetRatingCertificate> - rating associated with the TMS territory
            <FilmTitle>My Movie</FilmTitle> ->> Optional if the pack is tied to a title, we create a new title if we cannot find a title for this issuer and this given Film Title
            <ScreenList><Screen>1</Screen><Screen>2</Screen></ScreenList> ->> optional, screens for the pack - they shoudl be the screen identifiers
            <ShowAttributes><ShowAttribute>3_D</ShowAttribute><ShowAttribute>Mommie and Me</ShowAttribute></ShowAttributes> ->> Optional, used to target packs towards specific showings
            <ElementList>
                <Element>
                    <ContentTitleText>Best ad Ever</ContentTitleText>
                    <CplUUID>1f66d340-a648-43c1-bfc6-639185337b28</CplUUID>
                    <Duration>312</Duration> ->> Duration in frames
                    <EditRate>24 1</EditRate>
                </Element>
                <Element>
                    <ContentTitleText>6BIG-BUCK-BUNN_ADV-1_C_EN-XX_INT-TL_2K_20120905_AAM_OV</ContentTitleText>
                    <CplUUID>198798f1-f059-4ecb-9695-055432744c53</CplUUID>
                    <Duration>312</Duration>
                    <EditRate>24 1</EditRate>
                </Element>
                <Element>
                    <ContentTitleText>ART-BLACK-LOGO_ADV_178_EN-XX_UK_20_ART_20100420_AAM_OV</ContentTitleText>
                    <CplUUID>284930ab-f68a-42e8-8bb1-ae71fdde8e02</CplUUID>
                    <Duration>312</Duration>
                    <EditRate>24 1</EditRate>
                </Element>
            </ElementList>
        </AAMPack>
        
        :returns: messages
        """
        messages = cherrypy.core.pack_service.add_pack_xml(pack=pack)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def last_modified(self):
        """
        Returns a list of all pack last_modified timestamps stored on this core
        
        :returns: list of pack last_modified timestamps
        
        Example HTTP request::
        
            /pack/last_modified
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    a5a14b4d-3f54-48f0-a934-4e1b1131d69e: 1359391993.7,
                    5a60cc47-0a8f-429b-bfbb-56999a662ed8: 1361278136.299,
                    bfbb8efb-66a4-42ce-9ed8-b43e6a5d524d: 1358184187.561,
                    5c957d78-ee70-470a-a621-52e67c788d6b: 1361190216.51915,
                    e0209b51-789a-4c09-bf2b-d9db76c57fe0: 1358173103.332,
                    7ab7a0ce-514d-4313-8ea3-ceb023432105: 1360003229.44713,
                    643e1b12-a5a4-4c61-b1e2-dd630fe7b27b: 1358428716.206,
                    8a9dc423-39c7-475b-aaa6-b9d92d383dd7: 1358334879.677,
                    e2a91318-55b1-4765-b527-51af22f8ea79: 1358173086.547,
                    0b5bd534-3654-4062-9595-a82a41c68c7b: 1358337222.06,
                    21e63cc9-9faf-4b2d-82be-35e2aebfed6c: 1358963396.709,
                    f52ea120-cac7-48c9-9ea3-fa3e73c51ddd: 1360249178.56,
                    d515f791-6c06-4781-b779-e1dc630f4cf3: 1359559599.605,
                    d8b05d9c-0777-4371-ad68-7be773565435: 1358433887.242,
                    aac6c99b-379e-4929-8015-c3a4b5057c1c: 1359727733.105
                }
            }
        
        """
        last_modified_info = self.service.last_modified()
        return {'data': last_modified_info,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['packs'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save(self, packs):
        """
        Save the pack/s on core
        
        :param packs: list of packs to be created/updated
        
        :returns: status message
        
        Example HTTP request::
        
            /pack/save?packs=[
                {"packs":
                    [{
                        "uuid": "6c915ba4-2e6c-4cf2-b8dd-6512957cdc7d", - > uuid of pack. Optional, one is created if not provided. If the uuid exists in the system the pack is updated
                        "clips": [ - list of CPLS for ad pack - order added to playlist is order stated
                                - all values in each clip are required
                          {'cpl_id': '134fb6c8-3fbe-480b-bf0c-a68fe6eac279', CPL UUID
                           'edit_rate': '24 1', - CPL Edit rate
                           'text': '3DMMA_SHR_177_EN-XX_20_2K_BENB', - CPL content title text (or pretty name), if CPL is found on the system we will grab the content title text and replace this
                           'duration': 4376 - Duration in frames - DEPRICATED please use duration_in_frames or seconds
                           'duration_in_frames': 4376 - Duration in frames - OR / BOTH
                           'duration_in_seconds': 13 - Duration in seconds
                           },
                          {
                            "cpl_id": "73e158a5-0089-4efa-a893-b295a3f5ce8c",
                            "text": "USAIN-BOLT-3D_RTG_F_U-CERT_EN-XX_UK-U_51_2K_20090626_TEU"
                            'duration_in_frames': 4376
                            'edit_rate': '24 1',
                          },
                        ],
                        --Time Range and Date range for pack validity
                        -If neither dates are specified, pack is valid for every day
                        -if neither times are specified, pack is valid for all of the day
        
                        "date_from": "2013-07-25", Optional: If date_from is not specified, pack is valid from now until the date_to date.
                        "date_to": "2013-07-29", Optional: If date_to is not specified, pack is valid from the date_from date and beyond
                        "time_from": "19:00:00", Optional: time_from is not specified, pack is valid from now until the time_to value
                        "time_to": "19:29:00", Optional: Time_to not specified, pack is valid from time_from until the end of the day
                        "print_no": 1, Optional - will be used if the POS session has a print specified to help select the correct print
                        "priority": Optional used to force a pack to be more important 1 is highest, greater numbers have less priority
                        "issuer": " Some Ad Agency "  issuer of ad pack
                        "name": "My Ad Pack for a Movie,
                        --Placeholder must be specified, either with a name or the actual TMS UUID for that placeholder
                        "placeholder_name": "National Advertisement", This is used for where in the preshow to place the clips. If the name cannot be matched to an existing placeholder in the system, a new one will be created OR
                        "placeholder_uuid": "65e158a5-1189-4efa-a893-y425a3f5ce8c", This is used for where in the preshow to place the clips. This must be an existing placeholder in the system
                        "title_name":"A'Movie", Optional - name of the title for the ad (to allow title specific targeting).
                        --Screens -either field can be used, if both are specified we will use the screen uuid values
                        "screen_identifiers": ["1","2"],  Optional: Screens to associate the packs to - must match our Screen Identifiers (via the screen api call). If no screen specified Pack will be used for all screens
                        "screen_uuids": ["1","2"],  Optional: Screens to associate the packs to - must match our Screen UUIDS (via the screen api call). If no screen specified Pack will be used for all screens
                        "external_show_attribute_maps":[{ "source":" Some Ad Agency ","external_id":"3D"}], -> Any attributes desired for this POS - such as 3D, DBOX, Autism Friendly
                    }]
                }]
        
        Example HTTP response::
        
            {
                "messages":[
                    {
                        "message":"Pack My Pack saved",
                        "type": "success",
                        "uuid": "5a60cc47-0a8f-429b-bfbb-56999a662ed8"
                    }
                ],
                "data":{}
            }
        
        """
        messages = self.service.save(packs)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pack_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, pack_uuids):
        """
        Delete the specified packs from core
        
        :param pack_uuids: list of pack identifiers
        
        :returns: status message
        
        Example HTTP request::
        
            /pack/delete?pack_uuids=["e0209b51-789a-4c09-bf2b-d9db76c57fe0"]
        
        Example HTTP response::
        
            {
                data: {},
                messages: [
                    {
                        'type': 'success',
                        'message': "Deleted: <pack name>"
                    }
                ]
            }
        
        """
        messages = self.service.delete(pack_uuids)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pack_uuids', 'screen_uuids', 'placeholder_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def edit(self, pack_uuids, screen_uuids = None, placeholder_uuid = None):
        """
        Edit the screen number and/or placeholder uuid of a batch of Packs
        
        :param pack_uuids: list of pack identifiers
        :param screen_uuids: list of screen identifiers
        :param placeholder_uuid: placeholder identifier
        
        :returns: status message
        
        Example HTTP request::
        
            /pack/edit?pack_uuids=["e0209b51-789a-4c09-bf2b-d9db76c57fe0"]&screen_uuids=["848c33eb-342b-4e17-84e7-0151b2685836"]
        
        Example HTTP response::
        
            {
                data: {},
                messages: [
                    {
                        'type': 'success',
                        'message': "12 Pack(s) updated'
                    }
                ]
            }
        
        """
        message = self.service.edit(pack_uuids, screen_uuids, placeholder_uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pack_uuids', 'requested_data_items'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def packs(self, pack_uuids = [], datatable_query = False, requested_data_items = []):
        """
        Retrieve packs from the database
        
        :param pack_uuids: optional list of pack identifiers
        :param datatable_query: flag specifying whether this is a jquery datatables query, default False
        :param requested_data_items: optional list of data items required for the pack. e.g, uuid, name
        
        :returns: JSON dict of packs containing specified CPL
        
        Example HTTP request::
        
            /pack/packs?pack_uuids=["e0209b51-789a-4c09-bf2b-d9db76c57fe0"]
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    6c915ba4-2e6c-4cf2-b8dd-6512957cdc7d: {
                    print_no: int - specified print number or null,
                    title_uuid: uuid or null ,
                    uuid: "6c915ba4-2e6c-4cf2-b8dd-6512957cdc7d",
                    placeholder_name: "National Advertisement",
                    issuer: "ad agency",
                    date_from: "2013-09-20", - date_from or null
                    time_from: "05:00:00", - time_from or null
                    screens: [
                    "f7065a64-d15a-4355-85c6-91974b3cd6dd"
                    ], - list of internal screen uuids that this pack belongs to
                    clips: [
                        {
                            duration_in_frames: 168,
                            cpl_id: "73e158a5-0089-4efa-a893-b295a3f5ce8c",
                            edit_rate: [
                            24,
                            1
                            ],
                            text: "USAIN-BOLT-3D_RTG_F_U-CERT_EN-XX_UK-U_51_2K_20090626_TEU",
                            duration_in_seconds: 7,
                            playback_mode: "3D",
                            type: "composition",
                        },
                        {
                            duration_in_frames: 20145,
                            cpl_id: "8f764364-704f-4955-adc3-54b217ff2efc",
                            edit_rate: [
                            24,
                            1
                            ],
                            text: "2012-10-12_13.30-13.59-Untouchable-2D-S3 Part 1",
                            duration_in_seconds: 839.375,
                            playback_mode: "2D",
                            type: "composition",
                        }
                    ],
                    priority: 1000, - priority or null
                    external_show_attribute_maps: [
                    {
                        source: "ad agency",
                        external_id: "3D"
                    }
                    ], - Empty list if none
                    date_to: "2013-09-29", - date to or null
                    title_name: null, - title name or null (not needed if title uuid is specified)
                    placeholder_uuid: "3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0",
                    time_to: "19:29:00" - time to or null,
                    name: "AD PACK Example - DIARY OF A WIMPY KID: DOG DAYS"
                    }
                }
            }
        
        """
        pack_info = self.service.packs(pack_uuids, datatable_query, requested_data_items)
        return {'data': pack_info,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pack_title'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def pack_name_exists(self, pack_name):
        """Confirm presence of pack in the database that matching the specified pack_name
        :param pack_name: required, the pack name
        :returns: True if a pack with the specified name exists, otherwise False
        
         Example HTTP request::
        
            /pack/pack_name_exists?pack_name="My Pack"
        
        Example HTTP response::
        
            {
                True
            }
        
        """
        return {'data': self.service.pack_name_exists(pack_name),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['cpl_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def find_pack(self, cpl_uuid):
        """
        Find all packs containing CPL matching given CPL identifier. Used for the Content page
        
        :param cpl_uuid: required CPL identifier
        
        :returns: JSON dict of packs containing specified CPL
        
        Example HTTP request::
        
            /pack/find_pack?cpl_uuid="848c33eb-342b-4e17-84e7-0151b2685836"
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    848c33eb-342b-4e17-84e7-0151b2685836: {
                        placeholder_uuid: "f85dbe52-c665-5828-be4c-2fbadb7554f9",
                        uuid: "e0209b51-789a-4c09-bf2b-d9db76c57fe0",
                        name: "2D Pack"
                    }
                }
            }
        
        """
        return {'data': self.service.find_pack(cpl_uuid),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def sync_history(self):
        return {'data': self.service.sync_history(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def match_pack(self, placeholder_uuid, screen_uuid, show_attribute_names, title_uuid, print_number):
        """
        opened up for debugging purposes - maybe useful at some point in the future
        """
        import datetime
        play_datetime = datetime.datetime.now()
        return {'data': self.service.match_pack(placeholder_uuid, screen_uuid, show_attribute_names, play_datetime, title_uuid, print_number),
         'messages': []}
# okay decompyling ./core/api/pack_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:06 CST
