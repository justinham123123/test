# 2017.08.13 21:48:13 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\template_api.py
import cherrypy
from serv.lib.utilities.helper_methods import API
from serv.core.services.template_service import TemplateService
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler

class TemplateAPI(API):

    def __init__(self, core):
        super(TemplateAPI, self).__init__(core)
        self.service = TemplateService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.template_information)

    def template_information(self, data):
        """
        Handle `config_synced` request from Circuit Core.
        
        Request all template information that Circuit core has for this
        complex.
        """
        templates, messages = self.service.template()
        cherrypy.engine.publish('ccpush', 'template_information', {'uuids': templates.keys()}, target=data['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['template_uuid'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_active(self, template_uuid):
        """
        Sets a template to be active and de-actives all others
        
        :param template_uuid: required template identifier
        :returns: status message
        
        Example HTTP request::
        
           /template/set_active?template_uuid=["9c36bf1d-bfef-4d44-bd74-5b9c9be22be8"]
        
        Example HTTP response::
        
           {
             "data": {},
             "messages": [{
               "success": true,
               "message": "Template [9c36bf1d-bfef-4d44-bd74-5b9c9be22be8] marked active.",
             }]
           }
        """
        output = {'data': {},
         'messages': []}
        message = self.service.set_active(template_uuid)
        output['messages'] = [message]
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['template_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, template_ids):
        """
        Deletes specified templates
        
        :param template_ids: required list of template identifiers
        :returns: status message
        
        Example HTTP request::
        
           /template/delete?template_ids=["9c36bf1d-bfef-4d44-bd74-5b9c9be22be8"]
        
        Example HTTP response::
        
           {
             "data": {},
             "messages": [{
               "type": "success",
               "template_uuid": "9c36bf1d-bfef-4d44-bd74-5b9c9be22be8",
               "message": "Template [TEST_TEMPLATE] deleted",
             }]
           }
        """
        output = {'data': {},
         'messages': []}
        messages = self.service.delete(template_ids)
        output['messages'] = messages
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['templates'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save(self, templates = []):
        """
        Saves a list of templates
        :param template: a template in JSON format
        :returns: status message
        
        Example template in *JSON* format::
        
           {
              "uuid": "1c19dd1d-6f72-46a8-b747-975babd94a78",
              "name": "Test template",
              "text": "playlist text",
              "circuit_group_uuid": "9c36bf1d-bfef-4d44-bd74-5b9c9be22be8"
              "event_list": [{
                        text: "Advertisement",
                        transition: "",
                        type: "content_placeholder",
                        uuid: "94c4da49-8157-45e4-95df-b3220ac0c236",
                        credit_offset: false
                    },
                    {
                        text: "Trailer",
                        transition: "",
                        type: "content_placeholder",
                        uuid: "a260a866-0c96-5728-a91c-796f0bdfa5eb",
                        credit_offset: false
                    },
                    {
                        text: "Feature",
                        transition: "",
                        type: "title_placeholder",
                        uuid: "af4e412f-d9c9-5dcb-beb7-fa52d7abd6e9",
                        credit_offset: false
                    }]
           }
        
        Example HTTP request::
        
           /template/save?templates=[{...}]
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "Saved [Test template]",
               "type": "success"
             }],
             "data": {}
           }
        """
        output = {'data': {},
         'messages': []}
        uuids, messages = self.service.save(templates)
        output['messages'] = messages
        output['data'] = uuids
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['template_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def template(self, template_ids = [], requested_data_items = []):
        """
        Returns specified templates
        
        :param template_ids: optional list of template identifiers
        :param requested_data_items: optional list of keys defining the keys of the returned dictionary.
        :returns: template data
        
        Example HTTP request::
        
           /template/template?template_ids=["bfb7a2c1-8299-45c2-a3d3-003ec0df716a","5e074383-ecb1-4540-ac1b-a16b8a5aa2e2"]
        
        Example HTTP response::
           {
               --template that is active is marked to use auto transitioning
                data: {
                    5e074383-ecb1-4540-ac1b-a16b8a5aa2e2: {
                        uuid: "5e074383-ecb1-4540-ac1b-a16b8a5aa2e2", - Template UUID
                        created: 1375979410.896, - Created timestamp
                        event_list: [
                            {
                            text: "Show Start Transition", - The show start macro pack is inserted into here, which one (3D flat or 2D Flat depends on content of playlist)
                            type: "auto_transition"
                            },
                            {
                            text: "Local Advertisement",
                            type: "content_placeholder",
                            uuid: "f50c0acd-0583-5675-9c90-cff4594a0cf9"
                            },
                            {
                            text: "Trailer 1",
                            type: "content_placeholder",
                            uuid: "12026af2-657b-5c57-8835-fae593a0b2ef"
                            },
                            {
                            text: "National Advertisement",
                            type: "content_placeholder",
                            uuid: "3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0"
                            },
                            {                          {
                            text: "Trailer 2",
                            type: "content_placeholder",
                            uuid: "44026af2-787b-5c57-8835-f23e593a0b2ef"
                            },
                            {
                            text: "Feature Start Transition",  - The feature start start macro pack is inserted into here, which one (flat or scope) is determined via feature selected
                            type: "auto_transition"
                            },
                            {
                            text: "Feature", - we will auto select the feature from the title based on POS show attributes and capabilities of screen
                            type: "title_placeholder",
                            uuid: "af4e412f-d9c9-5dcb-beb7-fa52d7abd6e9",
                            credit_offset: true - Add the credit offset macro pack to this feature, will only happen if the Credit offset is set for the final CPL
                            },
                            {
                            text: "Show End Transition", - Show end marcro is put in here
                            type: "auto_transition"
                            }
                        ],
                        active: true, - Is this the active template? This key will not be there if it is not
                        cpl_transitions: true, - Auto slot in transitions for scope to flat changes between CPLS
                        last_modified: 1376560368.21262, - last modified time stamp
                        name: "My Active Template"
                    },
                    -- template that does not use auto transitions, and slots in its own macros
                    bfb7a2c1-8299-45c2-a3d3-003ec0df716a: {
                        uuid: "bfb7a2c1-8299-45c2-a3d3-003ec0df716a",
                        created: 1360258226.748,
                        event_list: [
                            {
                            text: "To 2D",
                            type: "macro",
                            uuid: "e28451a1-35aa-5a54-9f08-7fc6fc0bddb8",
                            },
                            {
                            text: "National Advertisement",
                            type: "placeholder",
                            uuid: "3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0",
                            },
                            {
                            text: "Trailers 1",
                            type: "placeholder",
                            uuid: "12026af2-657b-5c57-8835-fae593a0b2ef"
                            },
                            {
                            text: "Feature",
                            type: "title_placeholder",
                            uuid: "af4e412f-d9c9-5dcb-beb7-fa52d7abd6e9",
                            credit_offset: false
                            },
                        ],
                        last_modified: 1360258226.748,
                        name: "My inactive Template"
                    }
                }
                messages:{
        
                }
           }
        """
        output = {'data': {},
         'messages': []}
        templates, messages = self.service.template(template_ids, requested_data_items)
        output['data'] = templates
        output['messages'] = messages
        return output
# okay decompyling ./core/api/template_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:13 CST
