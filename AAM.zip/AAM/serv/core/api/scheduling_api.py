# 2017.08.13 21:48:12 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\scheduling_api.py
import cherrypy, json
import logging
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.scheduling_service import SchedulingService

class SchedulingAPI(API):

    def __init__(self, core):
        super(SchedulingAPI, self).__init__(core)
        self.service = SchedulingService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.schedule_dict_list)
        cherrypy.engine.publish('cclisten', 'request_schedule_info', self.request_schedule_information)
        cherrypy.engine.publish('cclisten', 'request_schedule_errors', self.request_schedule_errors)

    def schedule_dict_list(self, payload):
        """
        Handle `schedule_sync` event from Circuit Core.
        
        Returns a dict with schedule_uuids as keys and the corresponding
        last modified time. Used by Circuit Core to determine what schedule
        information to pull back.
        """
        cherrypy.engine.publish('ccpush', 'schedule_dict_list', {'schedules': self.service.last_modified(deleted=False)}, target=payload['url'])

    def request_schedule_information(self, payload):
        """
        Handle `schedule_sync` event from Circuit Core.
        
        Circuit is asking for all available schedule information. Performed
        as part of start up sync.
        """
        schedule_uuids = payload['data']['schedule_uuids']
        if not schedule_uuids or len(schedule_uuids) > 100:
            schedule_uuids = []
        schedule_info, errors = self.service.schedule(schedule_uuids=schedule_uuids, ignore_time=True)
        cherrypy.engine.publish('ccpush', 'schedule_information', {'schedule_information': schedule_info}, target=payload['url'])

    def request_schedule_errors(self, payload):
        """
        Handle `request_schedule_errors` event from Circuit Core.
        
        Send as part of start up sync. Circuit Core requests all the current
        errors with schedules by sending a list of schedule uuids producer
        knows about.
        """
        schedule_uuids = payload['data']['schedule_uuids']
        cherrypy.core.schedule_validation.mass_update_validation(schedule_uuids)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['schedule_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, schedule_uuids, deleted_timestamp = None, sync_schedules = True):
        """
        Deletes specified schedules from devices
        
        :param schedule_uuids: required list of schedule identifiers
        :param deleted_timestamp: optional POSIX timestamp specifying when the schedule should be marked as deleted
        :param sync_schedules: optional boolean specifying whether a schedule sync should be queued after schedules are marked for deletion. Default is True.
        
        :returns: status message
        
        Example HTTP request::
        
           /scheduling/delete?schedule_uuids=["94d0038c-31c3-4b56-8934-b5b7c714cce5"]
        
        Example HTTP response::
        
            {
                messages: [
                    {
                        message: "Deleting schedule on 2",
                        device_id: "7d4cb238-4425-400c-bed6-a91c13e96a28",
                        type: "action",
                        schedule_uuid: "94d0038c-31c3-4b56-8934-b5b7c714cce5",
                        action_id: "46ce04d7-1af3-442c-baff-5eaa66554b53"
                    }
                ],
                data: { }
            }
        
        """
        messages = self.service.delete(schedule_uuids, deleted_timestamp, sync_schedules)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['start_time',
     'end_time',
     'device_uuids',
     'schedule_uuids',
     'information_requested',
     'full_validation',
     'include_show_end',
     'include_deleted'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def schedule(self, start_time = None, end_time = None, device_uuids = [], schedule_uuids = [], full_validation = False, information_requested = [], include_show_end = True, include_deleted = False):
        """
        Returns the playback schedule for a device within a given date range.
        If no device is specified, the schedules for all devices that support this are returned.
        If a date range is not specified then all schedules for the next year are returned.
        If details is true, then the details of the playlists are also returned.
        
        :param device_ids: optional list of device identifiers
        :param start_time: optional datetime value for range
        :param end_time: optional datetime value for range
        :param schedule_uuids: optional schedule uuid list for filtering
        :param full_validation: optional boolean parameter defining whether to include full validation issue list in response. Default is False.
        :param information_requested: optional list of keys defining subsets of information to be returned. Values: [device_information, template_information, placeholder_information, pos_information]. By defult we return everything.
        :param include_show_end: optional boolean parameter defining whether to include shows that end in the specified range but begin before start_time. Default is True.
        :param include_deleted: optional boolean parameter defining whether to include shows marked as deleted. Default is False.
        
        :returns: JSON dictionary
        
        Example HTTP request::
        
           /scheduling/schedule?
               device_uuids=
                   [
                       "7d4cb238-4425-400c-bed6-a91c13e96a28"
                   ]&
               start_time="2013-2-19 04:00:00"&
               end_time="2013-2-20 04:00:00"
        
        
        Example HTTP response::
        
            {
                "messages":[],
                "data":
                {
                    f8fdd373-b474-43e3-bd77-86a712b365a2: {
                        device_information: {
                            device_schedule_id: "bd947dad-8f79-49d8-a6d0-80c445687c1d", - Schedule uuid on Screen Server
                            device_playlist_duration: 849, - Playlist duration from screen server
                            device_playlist_uuid: "9b9fbc23-5e40-4b89-a568-e01b457f1722", - Playlist uuid on screen server
                            device_uuid: "7ab8ae4a-2281-4b86-9bf6-9feb86b95fbf" - TMS Device UUID
                        },
                        start_timestamp: 1379947800, - timestamp of schedule start time
                        display_name: "My scheduled playlist",
                        uuid: "f8fdd373-b474-43e3-bd77-86a712b365a2", - TMS schedule UUID
                        created: 1379943598.43167, - timestamp created by
                        deleted: false, - marked as deleted or not
                        screen_uuid: "ee7613dd-8d1f-496e-b841-20626e21d21d", - TMS Screen UUID
                        start_time: "15:50:00", - localtime start time
                        source_playlist_uuid: null, - if playlist was created using an LMS playlist, this is the source playlist on the LMS
                        playlist_issue: false, - Are there problems with playlist or not?
                        last_modified: 1379943598.43122, - last modified timestamp.
        
                        --This is for schedules where the original playlist was an LMS
                        - The term template here implies playlist using placeholders interchanged with actual CPLS
                        (example ads are done via a placeholder but the feature CPL is specified)
        
                        template_information: {
                            source_playlist_uuid: null, - The source playlist on the LMS
                            print_no: null, - print number if scheduled via pos and print number was specified
                            is_template: false - Was the playlist on the LMS
                        },
                        placeholder_information: {
                            placeholder_type: null,
                            placeholder_duration: null
                        },
                        duration: 849,
                        content_issue: false,
                        templating_issues: [ ],
                        type: "server",
                        start_date: "2013-09-23", - local start time of schedule
                        --Are there KDM issues with final playlist, false if no, true if yes
                        kdm_issue: false
                    }
                    0ca71e39-a211-44c0-a570-0f9c1009cd1d: {
                        device_information: {
                            device_schedule_id: "afb8e327-1cfc-492e-875f-acb4d9f9ddd8",
                            device_playlist_duration: 13852.58267,
                            device_playlist_uuid: "73c175cd-ac5f-4063-820e-6f6ea3cbf3d6",
                            device_uuid: "fd9d3d40-c8a7-4186-92d9-40df88dedac6"
                        },
                        start_timestamp: 1379957400,
                        display_name: "W38C7_Karen Demo_09.23_18:30",
                        uuid: "0ca71e39-a211-44c0-a570-0f9c1009cd1d",
                        created: 1379953438.1486,
                        deleted: false,
                        screen_uuid: "bf507fe0-23ca-4935-aa7d-9638ecbe8037",
                        start_time: "18:30:00",
                        source_playlist_uuid: "6766752e-0fd3-4e58-aab8-fd653c2c15db",
                        playlist_issue: false,
                        last_modified: 1379953441.48161,
                        --A playlist with placeholders was used to create this scheduled itemf
                        template_information: {
                            source_playlist_uuid: "6766752e-0fd3-4e58-aab8-fd653c2c15db",
                            print_no: null,
                            is_template: true
                        },
                        -- Does this scheduled session have a 35mm/DVD/Blueray scheduling placeholder associated with it?
                        --If so, this states what type, and for how long. If there is an actual playlist associated
                        --with this scheduled session, then this scheduling placeholder follows it (used as a reference / visual marker only)
                        placeholder_information: {
                                placeholder_type: null,
                                placeholder_duration: null
                        },
                        duration: 13852,
                        --Missing or corrupt content?
                        content_issue: true,
                        --if using playlist placeholders or auto playlist creation, what matching problems arose
                        templating_issues: [
                            {
                                uuid: null,
                                level: "WARNING",
                                text: "Unknown",
                                placeholder_type: "macro_pack",
                                inserted_ids: [ ],
                                message: "Not configured",
                                placeholder_uuid: "dd9f737b-6a6d-5d90-92ea-2a36ab4a134f"
                            },
                            {
                                uuid: null,
                                level: "WARNING",
                                text: "Local Advertisement",
                                placeholder_type: "pack",
                                inserted_ids: [ ],
                                message: "Unable to locate matching pack",
                                placeholder_uuid: "12026af2-657b-5c57-8835-fae593a0b2ef"
                            },
                            {
                                uuid: null,
                                level: "WARNING",
                                text: "National Advertisement",
                                placeholder_type: "pack",
                                inserted_ids: [ ],
                                message: "Unable to locate matching pack",
                                placeholder_uuid: "3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0"
                            }
                        ],
                        -- Schedule was created via POS mapping.
                        type: "pos",
                        start_date: "2013-09-23",
                        pos_information: {
                            pos_id: "f70bfe5f-d9fa-43bd-adde-68a1b7a07e10",
                            show_attributes: { },
                            pos_duration: 3600,
                            pos_unassigned: false,
                            seats_sold: null
                        },
                        --KDM issues were found with scheduled playlist
                        kdm_issue: true
                    },
            }
        
        """
        schedule_details, device_errors = self.service.schedule(start_time, end_time, device_uuids, schedule_uuids, full_validation, information_requested, include_show_end, include_deleted)
        return {'data': schedule_details,
         'messages': device_errors}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_content_schedules(self, content_uuids, device_uuids = [], start_time = None, end_time = None, ids_only = False):
        """
        Gives back a dictionary: list of affected schedules(as served by self.schedule) for each content_uuid.
        
        :param content_uuids: List of content uuids we want the information about.
        :param device_uuids: Only interested in these devices. If left empty, all the devices will be checked.
        :param start_time: Schedules timeframe start
        :param end_time: Schedules timeframe end
        :param ids_only: If this is set to True, we don't return whole schedule items, we only return the uuids of those schedules
        
        :returns: JSON dictionary of schedules
        
        If the selected content is involved in any schedules the dictionary will look like the following:
        
        Example HTTP response:
        'data':{
        'd3dd263f-c512-4af9-9486-0359087f571e':[
            {'id':...,
             'device_uuid':...,
             ...(schedule_data)...
            },
            {
             ...(schedule_data)...
            }],
        '21768e2b-03c0-45f3-8010-fba36c834504':[
            ....
            ]
        },
        'messages':[]
        """
        return_values = self.service.get_content_schedules(content_uuids, device_uuids, start_time, end_time, ids_only)
        return return_values

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_playlist_schedules(self, playlist_uuids, device_uuids = [], start_time = None, end_time = None, ids_only = False):
        """
        Gives back a dictionary: list of affected schedules(as served by self.schedule) for each playlist_uuid.
        
        :param playlist_uuids: List of playlist uuids we want the information about.
        :param device_uuids: Only interested in these devices. If left empty, all the devices will be checked.
        :param start_time: Schedules timeframe start
        :param end_time: Schedules timeframe end
        :param ids_only: If this is set to True, we don't return whole schedule items, we only return the uuids of those schedules
        
        :returns: JSON dictionary of schedules
        
        If the playlist is involved in any schedules the dictionary will look like the following:
        
        Example HTTP response:
        'data':{
        'd3dd263f-c512-4af9-9486-0359087f571e':[
            {'id':...,
             'device_uuid':...,
             ...(schedule_data)...
            },
            {
             ...(schedule_data)...
            }],
        '21768e2b-03c0-45f3-8010-fba36c834504':[
            ....
            ]
        },
        'messages':[]
        """
        return_values = self.service.get_playlist_schedules(playlist_uuids, device_uuids, start_time, end_time, ids_only)
        return return_values

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def create(self, schedule_dicts, sync_schedules = True):
        """
        Schedules a playlist to playback on a device for a list of date times.
        
        :param schedule_dict: JSON dictionary
        :param sync_schedules: optional boolean specifying whether a schedule sync should be queued after schedules are created. Default is True.
        
        :returns: status message
        
        
        Example HTTP request::
        
           /scheduling/create?
               schedule_dict=
                   {
                       "device_id":"1368172e-23d9-4ff0-8042-a475e3fcd33a",
                       "start_time":"2013-2-19T20:32:0",
                       "display_name":"My Playlist",
                       "spl_duration":7760.5,
                       "playlist_id":"8c3654ec-8324-44a8-be2b-63e530cb22d2",
                       "templating_issues": [{
                            'inserted_ids': []
                            'level': 'WARNING',
                            'message': "Unable to locate matching pack",
                            'placeholder_type': "pack",
                            'placeholder_uuid': "12026af2-657b-5c57-8835-fae593a0b2ef",
                            'text': "Local Advertisement",
                            'uuid': null
                        }]
                   }
        
        Example HTTP response::
        
            {
                "messages":
                    [
                        {
                            "message":"Playlist queued to be scheduled [8c3654ec-8324-44a8-be2b-63e530cb22d2] on device [1368172e-23d9-4ff0-8042-a475e3fcd33a]",
                            "type":"action",
                            "action_id":"3ebf0d79-d678-447a-9395-95e09def166a"
                        }
                    ],
                "data":{}
            }
        
        """
        messages = self.service.create(schedule_dicts, sync_schedules)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['deleted'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def last_modified(self, deleted = False):
        """
        Returns a list of all schedule last_modified timestamps stored on this core
        
        :param deleted: flag specifying whether to pull timestamps for schedules makred as "deleted"
        
        :returns: dictionary of timestamps
        
        Example HTTP request::
        
            /schedule/last_modified?deleted=true
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    58cd81be-921b-44e6-9602-da372738a3ae: 1360855803.71,
                    d32bda1f-5492-4fb3-8062-c016bc7268ac: 1360855803.698,
                    a45b945c-d8c3-4464-896b-9909ee0eaffa: 1360855803.721,
                    294b7183-cb58-4b7b-97e6-bd87e26c97ea: 1360855803.702,
                }
            }
        
        """
        return {'data': self.service.last_modified(deleted),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['short'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def sync_status(self, short = False):
        """
        Returns the current status of the schedule syncing thread
        
        :param short: flag specifying whether to pull full schedule sync details or just latest
        
        :returns: JSON dictionary
        
        Example HTTP request::
        
            /scheduling/sync_status?short=true
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    syncing: false,
                    message: "Schedule Synchronization finished in 0.0 ms",
                    error: null
                }
            }
        
        """
        return {'data': self.service.sync_status(short),
         'messages': []}
# okay decompyling ./core/api/scheduling_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:12 CST
