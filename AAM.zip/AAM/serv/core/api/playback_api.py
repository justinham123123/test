# 2017.08.13 21:48:10 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\playback_api.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.playback_service import PlaybackService

class PlaybackAPI(API):

    def __init__(self, core):
        super(PlaybackAPI, self).__init__(core)
        self.service = PlaybackService(core)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def audio_device_states(self):
        """
        Get the status of all audio devices
        
        .. http_method_uri:: playback/audio_device_states
            :category: Playback
        
        :returns: Status Message (JSON)
        
        Example Request::
        
           /playback/audio_device_states
        
        Example Response::
        
            {
                "messages": [],
                "data": {
                    "5775eb89-75f5-48dd-820d-aee823736528": {
                        "volume": 40,
                        "input": {
                            "id": "last",
                            "text": "Last"
                        },
                        "mute": false
                    }
                }
            }
        """
        data, message = self.service.audio_device_states()
        return {'data': data,
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def toggle_mute(self, device_uuid, mute):
        """
        Toggles the mute state of an audio device
        
        .. http_method_uri:: playback/toggle_mute
            :category: Playback
        
        :param device_uuid: Device identifier
        :param mute: 0 to mute, 1 to unmute
        :type device_uuid: String
        :type mute: int
        
        :returns: Success Message (JSON)
        
        Example Request::
        
           /playback/toggle_mute?device_uuid=5775eb89-75f5-48dd-820d-aee823736528&mute=1
        
        Example Response::
        
            {
                "messages": [{
                    "message": "Muted",
                    "type": "success"
                }],
                "data": {}
            }
        
        """
        message = self.service.toggle_mute(device_uuid, mute)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_volume(self, device_uuid, volume):
        """
        Sets the volume of an audio device
        
        .. http_method_uri:: playback/set_volume
            :category: Playback
        
        :param device_uuid: Device identifier
        :param volume: 0 - 100
        :type device_uuid: String
        :type volume: int
        
        :returns: Success Message (JSON)
        
        Example Request::
        
           /playback/set_volume?device_uuid=5775eb89-75f5-48dd-820d-aee823736528&volume=40
        
        Example Response::
        
            {
                "messages": [{
                    "message": "Volume changed: 40",
                    "type": "success"
                }],
                "data": {}
            }
        
        """
        message = self.service.set_volume(device_uuid, volume)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_input(self, device_uuid, input):
        """
        Sets the input channel of an audio device
        
        .. http_method_uri:: playback/set_input
            :category: Playback
        
        :param device_uuid: Device identifier
        :param input: input id
        :type device_uuid: String
        :type input: String
        
        :returns: Success Message (JSON)
        
        Example Request::
        
           /playback/set_input?device_uuid=5775eb89-75f5-48dd-820d-aee823736528&input=analog
        
        Example HTTP response::
        
            {
                "messages": [{
                    message: "Input changed: analog",
                    type: "success"
                }],
                "data": {}
            }
        
        """
        message = self.service.set_input(device_uuid, input)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def eject(self, device_id):
        """
        Ejects a loaded playlist from a device
        
        .. http_method_uri:: playback/eject
            :category: Playback
        
        :param device_id: required device identifier
        :type device_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/eject?device_id=9bcc1900-0c67-4128-9d6c-7296e41df709
        
        Example HTTP response::
        
            {
                "messages": [{
                    "message": "Ejecting playlist PLAYLIST-1 on C1",
                    "type": "action",
                    "action_id": "f1d27cbd-ba7a-4f96-af2c-da509972e1b8"
                }],
                "data": {}
            }
        
        """
        message = self.service.eject(device_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def load(self, device_id, playlist_id):
        """
        Loads a playlist on a device in preparation for playback
        
        .. http_method_uri:: playback/load
            :category: Playback
        
        :param device_id: required device identifier
        :param playlist_id: required playlist id
        :type device_id: String
        :type playlist_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/load?device_id=aaec87d7-bc77-411d-8987-87023d93c49f&
              playlist_id=6ed476e7-5709-4974-b7db-ccfdbd579c4d
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "Loading playlist PLAYLIST-1 on C1",
               "type": "action",
               "action_id": "0bbeb756-ced5-47a8-825e-2200a24ae1fc"
              }],
              "data": {}
            }
        
        """
        message = self.service.load(device_id, playlist_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def pause(self, device_id):
        """
        Pauses playback
        
        .. http_method_uri:: playback/pause
            :category: Playback
        
        :param device_id: required device identifier
        :type device_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/pause?device_id=aaec87d7-bc77-411d-8987-87023d93c49f
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "C1 is not playing at the moment",
               "type": "error"
             }],
             "data": {}
           }
        
        """
        message = self.service.pause(device_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def play(self, device_id):
        """
        Starts playback of the loaded playlist
        
        .. http_method_uri:: playback/play
            :category: Playback
        
        :param device_id: required device identifier
        :type device_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/play?device_id=aaec87d7-bc77-411d-8987-87023d93c49f
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "Starting playback on C1",
               "type": "action",
               "action_id": "4ef96556-5d66-4509-9f6f-29bd13969af7"
             }],
             "data": {}
           }
        
        """
        message = self.service.play(device_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def stop(self, device_id):
        """
        Stops playback
        
        .. http_method_uri:: playback/stop
            :category: Playback
        
        :param device_id: required device identifier
        :type device_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/stop?device_id=aaec87d7-bc77-411d-8987-87023d93c49f
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "C1 stopping",
               "type": "action",
               "action_id": "4ef96556-5d66-4509-9f6f-29bd13969af7"
             }],
             "data": {}
           }
        
        """
        message = self.service.stop(device_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def skip_forward(self, device_id):
        """
        Skips to the next item in the currently loaded playlist
        
        .. http_method_uri:: playback/skip_forward
            :category: Playback
        
        :param device_id: required device identifier
        :type device_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/skip_forward?device_id=aaec87d7-bc77-411d-8987-87023d93c49f
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "C1 skipping forward",
               "type": "action",
               "action_id": "42710cb5-f28d-44e0-a242-24e886f475d9"
             }],
             "data": {}
           }
        
        """
        message = self.service.skip_forward(device_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def skip_backward(self, device_id):
        """
        Skips to the previous item in the currently loaded playlist
        
        .. http_method_uri:: playback/skip_backward
            :category: Playback
        
        :param device_id: required device identifier
        :type device_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/skip_backward?device_id=aaec87d7-bc77-411d-8987-87023d93c49f
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "C1 skipping backward",
               "type": "action",
               "action_id": "86f83bea-d16a-4548-b017-1a4df33980bd"
             }],
             "data": {}
           }
        
        """
        message = self.service.skip_backward(device_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['mode'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_mode(self, device_id, mode):
        """
        Sets a mode on a device; a device might have multiple modes (i.e. scheduled & looping); throws an error if the mode is not supported.
        
        .. http_method_uri:: playback/set_mode
            :category: Playback
        
        :param device_id: required device identifier
        :param mode: mode identifier, check supported modes for more details.
        :type device_id: String
        :type mode: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/set_mode?device_id=aaec87d7-bc77-411d-8987-87023d93c49f&mode="loop"
        
        Example HTTP response::
        
           {
             "messages": [{
               "message": "Updating playback mode to loop on C1",
               "type": "action",
               "action_id": "86f83bea-d16a-4548-b017-1a4df33980bd"
             }],
             "data": {}
           }
        
        """
        message = self.service.set_mode(device_id, mode)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def interrupt_intermission(self, device_uuid):
        """
        Calls for the intermission to be interrupted on the given device
        
        .. http_method_uri:: playback/interrupt_intermission
            :category: Playback
        
        :param device_uuid: the device uuid
        :type device_id: String
        
        :returns: Success Message (JSON)
        
        Example HTTP request::
        
           /playback/interrupt_intermission?device_uuid="aaec87d7-bc77-411d-8987-87023d93c49f"
        
        Example HTTP response::
        
            {
                "messages": [{
                  "message": "Interrupting intermission on C1",
                  "type": "action",
                  "action_id": "86f83bea-d16a-4548-b017-1a4df33980bd"
                }],
                "data": {}
            }
        
        """
        message = self.service.interrupt_intermission(device_uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def state(self, device_ids = []):
        """
        Returns the playback state of the device
        
        .. http_method_uri:: playback/state
            :category: Playback
        
        :param device_ids: optional list of devices; if none is specified then all known device states are returned
        :type device_ids: List
        
        :returns: the playback state of servers
        
        Example HTTP request::
        
           /playback/state?device_ids=["aaec87d7-bc77-411d-8987-87023d93c49f"]
        
        Example HTTP response::
        
           {
             "data": {
               "21768e2b-03c0-45f3-8010-fba36c834504": {
                    "spl_title": "aladin",
                    "spl_uuid": "fb4abf07-2175-4bc8-b3e0-2ced2cec5a52",
                    "last_updated": 1377697387.732,
                    "modes": {
                        scheduler_enabled: true,
                        loop_mode: "play_then_eject",
                        playback_mode: "2D"
                    },
                    "intermission": false,
                    "spl_duration": 1,
                    "playback_state": "stop",
                    "cpl_uuid": "198798f1-f059-4ecb-9695-055432744c53",
                    "content_title_text": "6BIG-BUCK-BUNN_ADV-1_C_EN-XX_INT-TL_2K_20120905_AAM_OV",
                    "element_index": 0,
                    "element_id": "9c0c4194-24ba-49cf-becc-c2f6de79c5e1",
                    "spl_position": 1,
                    "content_kind": "advertisement",
                    "element_position": 1,
                    "element_duration": 1
                }
             },
             "messages": []
           }
        
        """
        device_playback_status, device_errors = self.service.state(device_ids)
        return {'data': device_playback_status,
         'messages': device_errors}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def supported_modes(self, device_ids = []):
        """
        Returns a list of supported playback modes for the device (for example, loop, scheduled, etc.).
        
        .. http_method_uri:: playback/supported_modes
            :category: Playback
        
        :param device_ids: required list of device identifiers
        :type device_ids: List
        
        :returns: status message
        
        Example HTTP request::
        
           /playback/supported_modes?device_ids=["aaec87d7-bc77-411d-8987-87023d93c49f"]
        
        Example HTTP response::
        
           {
               "data": {
                   "a6b2126a-a17b-449d-af5e-78ceda0b0976": {
                       "schedule_modes": [
                           "schedule_on",
                           "schedule_off"
                       ],
                       "loop_modes": [
                           "do_not_loop",
                           "loop",
                           "play_then_rewind",
                           "play_then_eject"
                        ]
                    }
               },
               "messages": []
           }
        
        """
        device_supported_modes, device_errors = self.service.supported_modes(device_ids)
        return {'data': device_supported_modes,
         'messages': device_errors}
# okay decompyling ./core/api/playback_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:11 CST
