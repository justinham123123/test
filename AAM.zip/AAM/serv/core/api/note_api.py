# 2017.08.13 21:48:05 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\note_api.py
import cherrypy
from serv.lib.cherrypy.cherrypy_utils import json_out_handler, cherrypy_peformance_log
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities.helper_methods import API
from serv.core.services.note_service import NoteService

class NoteAPI(API):
    """
    Note API
    """

    def __init__(self, core):
        super(NoteAPI, self).__init__(core)
        self.service = NoteService(core)

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['end_time'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    @cherrypy_peformance_log
    def notes(self, end_time = None, start_time = None):
        """
        Returns a list of all notes.
        
        .. http_method_uri:: note/notes
            :category: Note
        
        :param end_time: Only return notes which will be raised between now and that time. *(optional)*
        :param start_time: Notes' next_raised time is relative to this rather than now. *(optional)*
        :type end_time: Integer
        :type start_time: Integer
        
        :returns: List of notes (JSON)
        
        Example Request::
        
            /note/notes?end_time=1400610061
        
        Example HTTP response::
        
            {
                "data": {
                    "notes": [
                        {
                            "created": 1401901978,
                            "detail": "code",
                            "group": "blue",
                            "icon": "flag",
                            "id": 3,
                            "subject": "No reminder"
                        },
                        {
                            "created": 1401902978,
                            "detail": "flower",
                            "group": "",
                            "icon": "clock",
                            "id": 3,
                            "subject": "One-time reminder",
                            "remind": {
                                "next": 1402075440,
                                "date": "2014-06-06",
                                "time": "18:24:00"
                            }
                        },
                        {
                            "group": "blue",
                            "created": 1391731205,
                            "detail": "weekly",
                            "remind": {
                                "next": 1400610060,
                                "repeat": {
                                    "type": "week",
                                    "frequency": 1,
                                    "starting": 1391731200,
                                    "days": [2, 4],
                                    "at": "19:21:00"
                                }
                            },
                            "icon": "flag",
                            "id": 1,
                            "subject": "Repeat reminder"
                        }
                    ]
                },
                "messages": []
            }
        """
        output = {'data': {},
         'messages': []}
        output['data']['notes'] = self.service.get_all(end_time, start_time)
        return output

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['note'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def create(self, note):
        """
        Create a new note.
        
        .. http_method_uri:: note/create
            :category: Note
        
        :param note: A dictionary containing the desired fields for the note.
        :type note: JSON
        
        :returns: A status message and details of the created note (JSON)
        
        Example Request::
        
           {
           "note": {    # All optional. If repeat_type is present, raised_at is ignored
                "subject": "Clean the seats on top-floor screens",    # 80 chars max. Default: ''
                "detail": "top-to-bottom, please",    # 500 chars max. Default: ''
                "group": "blue",    # Options: red, green, blue, null. Default: null
                "icon": "flag",    # Options: bell, clock, wand, bin.... Default: flag
                "raised_at": 1400610060,    # Unix timestamp for one-time reminder. Default: null (no reminder)
                "repeat_type": "week",    # Options: day, week, null. Default: null (no repeat),
                "repeat_at": "19:21:00",    # For repeat_type != null only. Time string for when to repeat the reminder. Default: "00:00"
                "repeat_from": "2014-02-07", # For repeat_type != null only. Date string for when to start the repeat reminder. Default: <current_date>
                "repeat_days": [2, 4],    # For repeat_type == week only. Options: 0-6, 0 being Sunday. Default: []
                "repeat_frequency": 3    # For repeat_type == week only. Any integer > 0. Default: 1
            }
            }
        
        Example Response::
        
            {
                "messages": [{
                    "message": "Created note #1",
                    "type": "success"
                }],
                "data": {
                    "note": {
                        "group": "blue",
                        "created": 1391731205,
                        "detail": "Scrub them real good to rid them of dirt and stuff",
                        "remind": {
                            "next": 1400610060,
                            "repeat": {
                                "type": "week",
                                "frequency": 1,
                                "starting": 1391731200,
                                "days": [2, 4],
                                "at": "19:21:00"
                            },
                        },
                        "icon": "flag",
                        "id": 1,
                        "subject": "Clean the seats on top-floor screens"
                    }
                }
            }
        """
        output = {'data': {},
         'messages': []}
        success, details = self.service.create(note)
        if success:
            output['messages'].append({'type': 'success',
             'message': _('Created note #%s') % details['id']})
            output['data']['note'] = details['note']
        else:
            output['messages'].append({'type': 'error',
             'message': _('Could not save note: %s') % details['error']})
        return output

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['note'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def edit(self, note):
        """
        Edit an existing note.
        
        .. http_method_uri:: note/edit
            :category: Note
        
        :param note: A dictionary containing the id of the note you wish to edit, and the fields you wish to edit.
        Set repeat_type to null to turn off repeat, and raised_at to null to turn off one-time reminders
        :type note: JSON
        
        :returns: A status message and details of the edited note (JSON)
        
        Example Request::
        
            {
            "note": {
                "id": 1,
                "subject": "Only once actually",
                "repeat_type": null
            }
            }
        
        Example Response::
        
            {
                "messages": [{
                    "message": "Edit successful",
                    "type": "success"
                }],
                "data": {
                    "note": {
                        "group": "blue",
                        "created": 1391731205,
                        "detail": "Scrub them real good to rid them of dirt and stuff",
                        "remind": {
                            "next": 1402075440,
                            "date": "2014-06-06",
                            "time": "18:24:00"
                        },
                        "icon": "flag",
                        "id": 1,
                        "subject": "Only once actually"
                    }
                }
            }
        """
        output = {'data': {},
         'messages': []}
        success, detail = self.service.edit(note)
        if success:
            output['messages'].append({'type': 'success',
             'message': _('Edit successful')})
            output['data']['note'] = detail
        else:
            output['messages'].append({'type': 'error',
             'message': detail})
        return output

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def delete(self, ids):
        """
        Delete notes with the given ids.
        
        .. http_method_uri:: note/delete
            :category: Note
        
        :param ids: A list of note ids.
        :type ids: JSON
        
        :returns: Status message.
        
        Example Request::
        
            /note/delete?ids=[1]
        
        Example Response::
        
            {
                "messages": [
                    {
                        "message": "Deleted successfully",
                        "type": "success"
                    },
                    {
                        "message": "1 rows affected",
                        "type": "info"
                    },
                ],
                "data": {}
            }
        """
        output = {'data': {},
         'messages': []}
        success, rows = self.service.delete(ids)
        if success:
            output['messages'].append({'type': 'success',
             'message': _('Deleted #%s successfully') % ','.join(map(str, ids))})
            output['messages'].append({'type': 'info',
             'message': _('%d rows affected') % rows})
        else:
            output['messages'].append({'type': 'error',
             'message': _('Nothing to delete')})
        return output
# okay decompyling ./core/api/note_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:06 CST
