# 2017.08.13 21:48:01 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\configuration_api.py
import time
import copy
import re
import cherrypy
from serv.configuration import cfg
from serv.core import VERSION
from serv.lib.utilities.helper_methods import API
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.cherrypy import cherrypy_utils
from serv.core.services.configuration_service import ConfigurationService

class ConfigurationAPI(API):

    def __init__(self, core):
        super(ConfigurationAPI, self).__init__(core)
        self.service = ConfigurationService(core)
        cherrypy.engine.publish('cclisten', 'approved', self.handle_sync_request)
        cherrypy.engine.publish('cclisten', 'request_screen_information', self.handle_screen_information)
        cherrypy.engine.publish('cclisten', 'request_device_information', self.handle_device_information)
        cherrypy.engine.publish('cclisten', 'request_external_device_maps', self.handle_external_device_maps)
        cherrypy.engine.publish('cclisten', 'config_synced', self.handle_config_synced)
        cherrypy.engine.publish('cclisten', 'config_synced', self.handle_request_log_settings)
        cherrypy.engine.publish('cclisten', 'request_log_settings', self.handle_request_log_settings)

    def handle_sync_request(self, data):
        """
        Handles `approved` event from Circuit Core.
        
        Sent when our websocket client connection has been authorized by Circuit
        Core. Take it as a cue to start our startup sync process and send
        Circuit Core basic TMS information and screen and device last modified
        lists.
        
        :note:  This was being done in the core_main startup, which is fine for
                syncing when Core starts up, but not when Circuit Core restarts.
                Hence why it's been moved into here to handle both cases.
        """
        license = copy.deepcopy(cherrypy.aam_auth.get_license()['license'])
        if 'expiry' in license:
            license['expiry'] = time.mktime(license['expiry'].timetuple())
        cherrypy.engine.publish('ccpush', 'tms_info', {'timezone': cfg.timezone(),
         'version': VERSION,
         'start_time': cherrypy.core.start_time,
         'license': license}, target=data['url'])
        cherrypy.engine.publish('ccpush', 'screen_uuid_dict', {'screen_uuid_dict': self.service.screen_last_modified()}, target=data['url'])
        cherrypy.engine.publish('ccpush', 'device_uuid_dict', {'device_uuid_dict': self.service.device_last_modified()}, target=data['url'])

    def handle_screen_information(self, data):
        """
        Handles the `request_screen_information` event from Circuit Core.
        
        Sent during the start up sync when Circuit Core requires more
        information about a set of screens. Contains a list of screen_uuids we
        would like to know more about.
        """
        cherrypy.engine.publish('ccpush', 'screen_information', {'screens': self.service.screen(data['data']['screen_uuids'])}, target=data['url'])

    def handle_device_information(self, data):
        """
        Hanldes the `request_device_information` event from Circuit Core.
        
        Sent during the start up sync when Circuit Core requires more
        information about a set of devices. Contains a list of device_uuids we
        would like to know more about.
        """
        cherrypy.engine.publish('ccpush', 'device_information', {'devices': self.service.device(data['data']['device_uuids'])}, target=data['url'])

    def handle_external_device_maps(self, data):
        """
        Handles the `request_external_device_maps` event from Circuit Core.
        
        Sent during the start up sync. Circuit core is gathering external device
        mappings.
        """
        cherrypy.engine.publish('ccpush', 'external_device_mapping', {'external_device_maps': self.service.external_device_maps()}, target=data['url'])

    def handle_config_synced(self, data):
        """
        Handles the `config_synced` event from circuit_core.
        
        Sent once circuit_core has synced all device information.
        Core sends all its external_show_attributes and a uuid-
        """
        ex_sams = self.service.external_show_attribute_maps(False).values()
        cherrypy.engine.publish('ccpush', 'exsam_information', ex_sams, target=data['url'])
        cherrypy.engine.publish('ccpush', 'custom_device_specifications', target=data['url'])

    def handle_request_log_settings(self, data):
        """
        Handles the `request_log_settings` event from Circuit Core.
        
        Sends the log settings to Circuit Core.
        """
        cherrypy.engine.publish('ccpush', 'log_settings', {'log_settings': self.service.log_settings()}, target=data['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['screen_type_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def show_attribute(self, include_screen = True, include_cpl = True, include_other = True):
        """
        Returns the show attributes configured - optionally filters on
        screen attributes, cpl attributes, or show attributes marked with neither
        
        :param include_screen: bool, indicates whether show_attributes with the screen field set to True should be returned
        :param include_cpl: bool, indicates whether show_attributes with the cpl field set to True should be returned
        :param include_other: and bool, indicates whether show_attributes with neither the cpl or screen field set to True, should be returned  # @IgnorePep8
        
        :return: JSON dictionary containing show_attribue data, or error messages
        
        Example HTTP request::
        
           GET /core/configuration/show_attribute
        
        Example HTTP Response::
           {
                "messages": [ ],
                "data": {
                    755db849-2913-5f3c-be99-dd6219a6c1f2: {
                        cpl_attribute: true,
                        uuid: "755db849-2913-5f3c-be99-dd6219a6c1f2",
                        custom: false,
                        external_show_attribute_maps: {
                            e3868723-b46a-53b1-8dca-31592cc6c74d: {
                                source: "aam",
                                show_attribute_uuid: "755db849-2913-5f3c-be99-dd6219a6c1f2",
                                external_id: "3D",
                                uuid: "e3868723-b46a-53b1-8dca-31592cc6c74d"
                            },
                            eee2e3fd-eb9e-5465-9e01-00a0d1f8900f: {
                                source: "vista",
                                show_attribute_uuid: "755db849-2913-5f3c-be99-dd6219a6c1f2",
                                external_id: "3d",
                                uuid: "eee2e3fd-eb9e-5465-9e01-00a0d1f8900f"
                            }
                        },
                        screen_attribute: true,
                        name: "3D"
                        },
                }
            }
        
        """
        screen_type = self.service.show_attribute(include_screen, include_cpl, include_other)
        return {'data': screen_type,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['show_attribute'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_show_attribute(self, show_attribute):
        """
        Updates or creates a show attribute
        :param show_attribute: a dictionary defining a show attribute
           {
               "uuid":, "<uuid of the show attribute being updated/created>",
               "name":  "<the name of the new show attribute>",
               "custom": <bool, whether this is custom show attribute or not>,
               "screen_attribute: <bool, whether this is a screen attribute or not>,
               "cpl_attribute": <bool, whether this is a cpl attribute or not>
               "external_show_attr": <optional, uuid of external_show_attribute this is mapped too>
           }
        
        Note: if the show_attribute is from producer, we use the 'name' field to
              identify it rather than the uuid (which may differ).
        """
        message = self.service.save_show_attribute(show_attribute)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def unmatch_show_attribute(self, uuid):
        """
        Unmatches the specified external show attribute
        :param ex_sam_uuid: the uuid of the ex_sam to unmatch
        """
        message = self.service.unmatch_show_attribute(uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['show_attribute'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def match_show_attribute(self, show_attribute):
        """
        Saves a show attribute mapping
        :param show_attribute: JSON string containing the show attribute matching to add:
                    {'show_attr_uuid':<matched show attribute uuid>,
                    'uuid':<external show attribute to match>,
                    'is_screen':<is this a screen attribute>},
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           POST /core/configuration/save_screen_type
           Data: {"uuid":"<external show attr uuid>","is_screen":"true/false", 'show_attr_uuid':<show attribute uuid>}
        
        Example HTTP Response::
           {
               "messages": [
                   {
                       "message":"Saved: [3D]",
                       "type":"success"
                   }
               ],
               "data": { }
           }
        
        """
        message = self.service.match_show_attribute(show_attribute)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_show_attribute(self, uuid):
        """
        Deletes the specified show attribute
        :param uuid: uuid of show attribute to delete
        
        Note: also deletes
        - any related external show attribute maps with a source of 'aam'
        - any pack attribute maps pointing to above mentioned ex_sams
        All other related external show attribute maps are updated with
        show_atttribute_uuid=Null
        
        See: ShowAttributeUtils(db).delete() for details
        """
        message = self.service.delete_show_attribute(uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def external_show_attribute_maps(self, include_aam = True):
        """
        Returns a dictionary containing all external_show_attribute_maps for the complex
        
        :param include_aam: bool, default True - allows filtering out the aam ex_sams by setting to False
        :returns: JSON dictionary containing response messages
         and the data - a dictionary containing the external show attribute maps, key'ed on uuid
        
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/external_show_attribute_maps
        
        Example HTTP Response::
           {
                "messages": [ ],
                "data": {
                    4c656183-b785-53aa-ba27-a23e0eb1c76c: {
                        source: "aam",
                        show_attribute_uuid: "06233c3f-b308-5e6c-91e6-f53b68a5affa",
                        external_id: "HOH",
                        uuid: "4c656183-b785-53aa-ba27-a23e0eb1c76c"
                    },
                 }
            }
        """
        ex_sams = self.service.external_show_attribute_maps(include_aam)
        return {'data': ex_sams,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['external_show_attribute_maps'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_external_show_attribute_maps(self, external_show_attribute_maps):
        """
        Saves a external show attribute map
        :param external_show_attribute_maps: list of dictionaries of external show attribute
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           POST /core/configuration/external_show_attribute_maps
            Data: "external_show_attribute_maps":[{
                                                    'uuid': <uuid, optional - if not specified, created>,
                                                    'source': '<map source>',
                                                    'external_id': '<external_id>',
                                                    show_attribute_uuid': '<show attribute uuid>'
                                                },... ]
        Example HTTP Response::
          {
               "messages": [
                   {
                       "message":"Saved: f27d9855-b044-4a43-a843-0bb1ad91bf40",
                       "type":"success"
                   }, ...
               ],
               "data": { }
           }
        """
        message = self.service.save_external_show_attribute_maps(external_show_attribute_maps)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def screen_last_modified(self):
        """
        Returns a list of all screen last_modified timestamps stored on this core
        :return: JSON string containing screen identifiers and corresponding last modified timestamps
        
        Example HTTP request::
        
           GET /core/configuration/screen_last_modified
        
        Example HTTP Response::
           {
                "messages": [ ],
                "data": {
                    "8f86b56c-803b-48f6-bbb0-efb6bb3bd4fb": 1358349684.732,
                    "e04cc995-be8a-466b-a8fd-6654338c03ae": 1349178505,
                    "86238fa4-db95-4066-b606-9f2c39c5627f": 1348498286,
                    "086adf40-6aeb-4330-98a5-9b0bd27603c3": 1349178572,
                    "5116e6d3-f4f9-47c2-9108-42e4957bce7d": 1361189768.486,
                    "77ab2c13-99c3-437e-ae22-893fe30d2d3f": 1359385603.89,
                    "04a9c404-6987-4628-bb33-f20a4ef9f3d8": 1357643799.969
                }
            }
        
        """
        last_modified_info = self.service.screen_last_modified()
        return {'data': last_modified_info,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['screen_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def screen(self, screen_uuids = []):
        """
        Returns screen configuration information
        :param screen_uuids: optional list of screen identifiers
        :return: JSON string containing screen configuration information
        
        Example HTTP request::
        
           GET /core/configuration/screen?screen_uuids=["8f86b56c-803b-48f6-bbb0-efb6bb3bd4fb"]
        
        Example HTTP Response::
           {
                "messages": [ ],
                "data": {
                    29dc6432-9bb1-4ba7-b49f-35e4966c3cde: {
                        uuid: "29dc6432-9bb1-4ba7-b49f-35e4966c3cde",
                        title: "Gold Screen 1",
                        devices: [
                            "21768e2b-03c0-45f3-8010-fba36c834504",
                            "2a471a5d-a833-4033-a472-ac55a7d112d8"
                        ],
                        show_attributes: [],
                        last_modified: 1375703405.532,
                        capabilities: [
                            {
                                name: "vi",
                                order: 1
                            },
                            {
                                name: "audio",
                                value: "7.1",
                                order: 2
                            }
                        ],
                        identifier: "2"
                    },
                }
            }
        
        """
        screen_info = self.service.screen(screen_uuids)
        return {'data': screen_info,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['screens'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_screen(self, screens):
        """
        Saves a screen
        :param screen: JSON string containing screen information
        :return: JSON string containing the identifier of the saved screen
        
        Example HTTP request::
        
           POST /core/configuration/save_screen
           Data: {{"screens":[{"uuid":"5116e6d3-f4f9-47c2-9108-42e4957bce7d","identifier":"1","title":"1","show_attributes":["3D"],"screen_type_uuid":null,"capabilities":[]}]}}
        
        Example HTTP Response::
           {
               "messages":[
                       {
                           "message":"Screen Saved : [1]",
                           "type":"success"
                       }
                   ],
               "data":{
                   "uuid":"5116e6d3-f4f9-47c2-9108-42e4957bce7d"
               }
           }
        
        """
        screen_data, messages = self.service.save_screen(screens)
        return {'data': screen_data,
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['screen_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_screen(self, screen_uuids):
        """
        Deletes the specified screens from core
        :param screen_uuids: list of screen identifiers
        
        Example HTTP request::
        
           GET /core/configuration/delete_screen?screen_uuids=["8f86b56c-803b-48f6-bbb0-efb6bb3bd4fb"]
        
        Example HTTP Response::
           {
               "messages":[
                   {
                       "message":"Screens deleted: [9]",
                       "type":"success"
                   }
               ],
               "data":{}
           }
        
        """
        message = self.service.delete_screen(screen_uuids)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def device_last_modified(self):
        """
        Returns a list of all device last_modified timestamps stored on this core
        :return: JSON string containing all device identifiers and corresponding last modified timestamps
        
        Example HTTP request::
        
           GET /core/configuration/device_last_modified
        
        Example HTTP Response::
           {
                "messages": [ ],
                "data": {
                    "bdc51058-b678-466a-b88b-79e77eac9c32": 1360942969.397,
                    "04318138-20ab-4f5a-9828-b2f250b73e35": 1359385665.237,
                    "d03e97a3-e77d-4893-bb80-b606d5ad5648": 1359563729.394,
                    "11f200db-ef9d-4c44-9aac-9b37174390ed": 1351184396.983,
                    "d36fca84-d666-42e0-b4dd-763329e85513": 1359737849.327,
                    "6544fd74-6768-4e33-ad3e-27aa096db3d1": 1357211258.273,
                    "165bd9ce-498f-4350-b4a8-ee3beb02f386": 1360942969.634,
                    "0580f23d-04a8-4d37-a2ff-f91b704e255c": 1352376158.894,
                }
            }
        
        """
        last_modified_info = self.service.device_last_modified()
        return {'data': last_modified_info,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def device(self, device_ids = []):
        """
        Returns device configuration information
        :param device_ids: optional list of device identifiers
        :return: JSON string containing device configuration information
        
        Example HTTP request::
        
           GET /core/configuration/device/device_ids=["bdc51058-b678-466a-b88b-79e77eac9c32"]
        
        Example HTTP Response::
           {
                "messages": [ ],
                "data": {
                    "bdc51058-b678-466a-b88b-79e77eac9c32": {
                        "category": "screen_server",
                        "ftp_port": 21,
                        "ftp_username": "dolbyftp",
                        "ip": "10.58.4.26",
                        "api_password": null,
                        "screen_uuid": "5116e6d3-f4f9-47c2-9108-42e4957bce7d",
                        "port": 8080,
                        "ftp_ip": "10.58.4.26",
                        "ftp_password": "dolbyftp",
                        "api_username": null,
                        "path": null,
                        "screen_identifier": "1",
                        "type": "dolby",
                        "id": "bdc51058-b678-466a-b88b-79e77eac9c32",
                        "enabled": true,
                        "name": null
                    }
                }
            }
        
        """
        device_info = self.service.device(device_ids)
        return {'data': device_info,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['matched_only'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def external_device_maps(self, source_type = None, matched_only = False):
        """
        Returns external device maps
        :param source_type: optional source type string, eg. "pack", "pos"
        :param matched_only: optional boolean for returning matched only or all external device maps
        :return: JSON string containing external device configuration information
        
        Example HTTP request::
        
           GET /core/configuration/external_device_maps
        
        Example HTTP Response::
            {
                u'pos': {
                    u'901535f5-4d48-4a8a-aa9d-02bca99019ed': {
                        u'11': None,
                        u'10': None,
                        u'13': None,
                        u'12': None,
                        u'14': None,
                        u'1': u'10dae80c-0197-4f37-ae34-8fca6398b0ea',
                        u'3': None,
                        u'2': u'660b8583-218b-4bb3-a442-e5d35f1aa7d6',
                        u'5': None,
                        u'4': None,
                        u'7': None,
                    }
                }
            }
        
        """
        external_device_info = self.service.external_device_maps(source_type, matched_only)
        return {'data': external_device_info,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_maps'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_external_device_maps(self, device_maps):
        """
        Saves external device map configuration
        :param device_maps: json string specifying external device maps to be saved
        :return: JSON status string
        
        Example HTTP request::
        
           GET /core/configuration/save_external_device_maps?device_maps={
                u'pos': {
                    u'901535f5-4d48-4a8a-aa9d-02bca99019ed': {
                        u'11': None,
                        u'10': None,
                        u'13': None,
                        u'12': None,
                        u'14': None,
                        u'1': u'10dae80c-0197-4f37-ae34-8fca6398b0ea',
                        u'3': None,
                        u'2': u'660b8583-218b-4bb3-a442-e5d35f1aa7d6',
                        u'5': None,
                        u'4': None,
                        u'7': None,
                    }
                }
           }
        
        Example HTTP Response::
           {
               "messages":[
                   {
                       "message":"Device Maps Saved",
                       "type":"success",
                   ],
                   "data":{}
           }
        
        """
        response = self.service.save_external_device_maps(device_maps)
        return {'data': {},
         'messages': [response]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_device(self, device):
        """
        Saves a device
        TODO: write device format
        :param device: JSON string containing device configuration information
        :return: JSON string containing success or error messages
        
         Example HTTP request::
        
           POST /core/configuration/save_device
           Data: {"device":
                   {
                        "uuid":"11f200db-ef9d-4c44-9aac-9b37174390ed",
                       "type":"doremi",
                       "enabled":true,
                       "ip":"10.58.2.76",
                       "port":"11730",
                       "api_username":"user",
                       "api_password":"pass",
                       "ftp_ip":"10.58.2.76",
                       "ftp_port":"21",
                       "ftp_username":user",
                       "ftp_password":"pass",
                       "screen_uuid":"8f86b56c-803b-48f6-bbb0-efb6bb3bd4fb",
                       "category":"screen_server"
                   }
               }
        
        Example HTTP Response::
           {
               "messages":[
                   {
                       "message":"Device Saved (awaiting initialization) : [doremi]",
                       "type":"action",
                       "action_id":"b00cc261-49f6-47d9-b80d-99b11ac81d65"}
                   ],
                   "data":{}
           }
        
        """
        messages = self.service.save_device(device)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids', 'enabled'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_enabled(self, device_id, enabled = True):
        """
        Set the enabled state of a device
        :param device_id: Identifier of device
        :param enabled: Boolean representing if the device is to be enabled(True)/disabled(False). Default is true.
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/set_enabled?device_id=11f200db-ef9d-4c44-9aac-9b37174390ed&enabled=true
        
        Example HTTP Response::
           {
               "messages":[
                   {
                       "message":"Device Enabled : [doremi:11f200db-ef9d-4c44-9aac-9b37174390ed]",
                       "type":"success"
                   }
               ],
               "data":{}
           }
        
        """
        message = self.service.set_enabled(device_id, enabled)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_device(self, device_ids):
        """
        Delete device(s) from core
        :param device_ids: list of device identifiers for deletion
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/delete_device?device_ids=["11f200db-ef9d-4c44-9aac-9b37174390ed"]
        
        Example HTTP Response::
           {
               "messages":[
                   {
                       "message":"Deleted device id: [11f200db-ef9d-4c44-9aac-9b37174390ed] of type:[doremi]",
                       "type":"success"
                   }
               ],
               "data":{}
           }
        
        """
        messages = self.service.delete_device(device_ids)
        return {'data': {},
         'messages': messages}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_kdm_email_configuration(self, user, passw, server, protocol, enabled):
        """
        Saves KDM email settings
        :param user: username of email account
        :param passw: password of email account
        :param server: server of email account
        :param protocol: email protocol to use for email retrieval
        :param enabled: boolean representing if the KDM email is enabled(True)/disabled(False)
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_email?user="user"&passw="pass"&server="imap.gmail.com"&protocol="IMAP"&enabled=true
        
        Example HTTP Response::
           {
               "messages":[
                   {
                       "message":"Email settings saved",
                       "type":"success"
                   }
               ],
               "data":{}
           }
        
        """
        message = self.service.save_kdm_email_configuration(user, passw, server, protocol, enabled)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_kdm_email_configuration(self):
        """
        Returns KDM email configuration information
        :return: JSON string containing KDM email configuration information
        
        Example HTTP request::
        
           GET /core/configuration/get_kdm_email_configuration
        
        Example HTTP Response::
           {
               "messages":[],
               "data":
                    {
                        "username":"user,
                        "protocol":"IMAP,
                        "password":"pass",
                        "enabled":true,
                        "server":"imap.gmail.com"
                    }
            }
        
        """
        return {'data': self.service.get_kdm_email_configuration(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_chat_email_configuration(self):
        """
        Returns chat email configuration information
        :return: JSON string containing KDM email configuration information
        
        Example HTTP request::
        
           GET /core/configuration/chat_email
        
        Example HTTP Response::
           {
               "messages":[],
               "data":
               {
                   "cc":"example@yahoo.com",
                   "to":"example@gmail.com",
                   "from":"example@artsalliancemedia.com",
                   "port":25,
                   "server":"example.aam.local"
               }
           }
        
        """
        chat_email_data = self.service.get_chat_email_configuration()
        return {'data': chat_email_data,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_chat_email_configuration(self, server, port, to, cc, from_):
        """
        Saves chat email configuration information
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_chat_email?server="example.aam.local"&port=25&from_="example@artsalliancemedia.com"&to="example@gmail.com"&cc="example@yahoo.com"
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.save_chat_email_configuration(server, port, to, cc, from_)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_complex_settings(self, name = None, timezone = None, sub_lang = None, audio_lang = None):
        """
        Saves complex configuration information
        :param name: optional complex name
        :param timezone: optional complex timezone
        :param sub_lang: optional complex language for subtitles
        :param audio_lang: optional complex language for audio
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_complex_settings?name="Complex Name"&telephone="12345"&country="UK"
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.save_complex_settings(name, timezone, sub_lang, audio_lang)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_transfer_settings(self, tonight_hours = None, tonight_minutes = None, auto_transfer_enabled = False, auto_transfer_asap = False):
        """
        Saves transfer time settings to specify the exact time for the transfer "tonight" option
        :param tonight_hours: optional hour
        :param tonight_minutes: optional minutes
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_transfer_settings?tonight_hours=01&tonight_minutes=30
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.save_transfer_settings(tonight_hours, tonight_minutes, auto_transfer_enabled, auto_transfer_asap)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def transfer_settings(self):
        """
        Returns transfer time settings specifying the exact time for the transfer "tonight" option
        :return: JSON string containing transfer time settings details
        
        Example HTTP request::
        
           GET /core/configuration/transfer_settings
        
        Example HTTP Response::
           {
               "messages":[],
               "data":{
                    tonight_hours: 1,
                    auto_transfer_enabled: true,
                    tonight_minutes: 30,
                    auto_transfer_asap: false
               }
           }
        
        """
        return {'data': self.service.transfer_settings(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def trailer_rating_content(self):
        """
        Returns list of cpls specified as trailer rating cpls - used in adding rating cards before trailers
        :return: JSON list of CPL uuids
        
        Example HTTP request::
        
           GET /core/configuration/trailer_rating_content
        
        Example HTTP Response::
           {
               "messages":[],
               "data":{
                    cpls: ['198798f1-f059-4ecb-9695-055432744c53','236798f1-f059-4ecb-9695-055432744c53',...],
               }
           }
        
        """
        return {'data': self.service.trailer_rating_content(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_trailer_rating_content(self, cpls):
        """
        Saves list of rating cpl for use in trailer packs
        :param cpls: cpl uuid list
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_trailer_rating_content?cpls=['198798f1-f059-4ecb-9695-055432744c53','236798f1-f059-4ecb-9695-055432744c53',...]
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.save_trailer_rating_content(cpls)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def log_settings(self):
        """
        Returns log collection time settings that specify the exact time for SMPTE log collection to start and end
        :return: JSON string containing transfer time settings details
        
        Example HTTP request::
        
           GET /core/configuration/transfer_settings
        
        Example HTTP Response::
           {
               "messages":[],
               "data":{
                    "start_hours": 2,
                    "start_minutes": 30,
                    "end_hours": 8,
                    "end_minutes": 30,
                    "store_device_logs": true,
                    "storage_limit": 2342,
                    "log_day_average": 44,
                    "retry_days": 3,
                    "collection_only": false
               }
           }
        
        """
        return {'data': self.service.log_settings(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_log_settings(self, start_hours = None, start_minutes = None, end_hours = None, end_minutes = None, store_device_logs = None, retry_days = None, storage_limit = None):
        """
        Saves log collection time settings to specify the exact time for SMPTE log collection to start and end
        :param start_hours: start hour
        :param start_minutes: start minutes
        :param end_hours: end hour
        :param end_minutes: end minutes
        :param store_device_logs: boolean to represent if log collection is enabled
        :param retry_days: How long to retry a failed collection attempt
        :param storage_limit: storage_limit
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_log_settings?start_hours=01&start_minutes=30&end_hours=01&end_minutes=30
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":'Saved',
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.save_log_settings(start_hours, start_minutes, end_hours, end_minutes, store_device_logs, retry_days, storage_limit)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['settings'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    def delete_log_timeframe(self, uuid):
        message = self.service.delete_log_timeframe(uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['settings'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    def save_log_timeframe(self, start, end, uuid = None, screens = [], default = False):
        uuid, message = self.service.save_log_timeframe(start, end, uuid, screens, default)
        return {'data': {'uuid': uuid},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def get_log_timeframes(self):
        data, message = self.service.get_log_timeframes()
        return {'data': data,
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def reboot_device(self, device_uuid):
        """
        Reboots device
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/reboot_device?device_uuid=01223930-e174-48b2-804f-ed3ea086229a
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Screen Server rebooting",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.reboot_device(device_uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_bookend_settings(self):
        """
        Returns bookend settings
        :return: JSON string containing bookend settings information
        
        Example HTTP request::
        
           GET /core/configuration/get_bookend_settings
        
        Example HTTP Response::
           {
               "messages":[],
               "data":{
                    end_of_day: {
                        "active": false,
                        "spl_offset": 200,
                        "spl_uuid": ""
                    },
                    playlists: { ... },
                    start_of_day: {
                        "active": false,
                        "spl_offset": 200,
                        "spl_uuid": ""
                    }
               }
           }
        
         """
        return {'data': self.service.get_bookend_settings(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_bookend_settings(self, start_active, start_spl_offset, start_spl_uuid, end_active, end_spl_offset, end_spl_uuid):
        """
        Saves bookend settings
        :param start_active: boolean representing if start of day bookend is active
        :param start_spl_offset: int representing the offset of the start of day bookend in the spl
        :param start_spl_uuid: idenftifier of the start of day bookend playlist
        :param end_active: boolean representing if end of day bookend is active
        :param end_spl_offset: int representing the offset of the end of day bookend in the spl
        :param end_spl_uuid: idenftifier of the end of day bookend playlist
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_bookend_settings?start_active=true&start_spl_offset=200&start_spl_uuid="eb115835-2519-4aca-a4cd-051790dcb2d5"&end_active=true&end_spl_offset=200&end_spl_uuid="eb115835-2519-4aca-a4cd-051790dcb2d5"
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.save_bookend_settings(start_active, start_spl_offset, start_spl_uuid, end_active, end_spl_offset, end_spl_uuid)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def ftp_rescan(self, ftp_device_id):
        """
        Rescan an ftp folder
        :param ftp_device_id: Device identifier of the ftp folder
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/ftp_rescan?ftp_device_id=9dbe2773-4a34-486a-b252-a740f61a1cc7
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Rescan started",
                           "type":"action",
                           "action_id": "1533641c-69c9-47d5-86ab-94e98bf4a17f"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.ftp_rescan(ftp_device_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['device_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def test_connection(self, device_uuids):
        """
        Tests the management and content connection of device(s)
        :param device_uuids: list of device identifiers to be tested
        :return: JSON string containing action ids of the testing actions
        
        Example HTTP request::
        
           GET /core/configuration/test_connection?device_uuids=["24c87450-946e-4b7f-be2b-7d84ffe8821e"]
        
        Example HTTP Response::
           {
               "messages":[],
               "data":{
                    "24c87450-946e-4b7f-be2b-7d84ffe8821e": {
                        "content": "beca297c-24c0-4e30-8988-d7f9d38d53f1",
                        "management": "25cde50b-7dbf-4a44-b818-07260a29dbef"
                    }
               }
           }
        
        """
        return {'data': self.service.test_connection(device_uuids),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.ignore_authentication()
    def regenerate_flmx(self):
        """
        Hidden utility url to rewrite the flmx feed on demand.
        
        :return: Whether it is success or a 500 error.
        
        Example HTTP request::
        
            GET /core/configuration/regenerate_flmx
        
        Example HTTP Response::
        
            {"type": "success"}
        """
        return {'data': {},
         'messages': [self.service.regenerate_flmx()]}

    @cherrypy.expose
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def get_auto_cleanup_settings(self):
        """
        Get the settings for the Automatic cleanup function.
        
        :return: JSON string representing the settings.
        
        Example HTTP request::
        
           GET /core/configuration/get_auto_cleanup_settings
        
        Example HTTP Response::
            {
                core_auto_cleanup_pos: true,
                core_auto_cleanup_playlists: true,
                core_auto_cleanup_packs: true,
                core_auto_cleanup_transfers: true,
                core_auto_cleanup_schedules: true,
                core_auto_cleanup_titles: true,
                core_auto_cleanup_playlists_expiry_days: 7,
                core_auto_cleanup_log_files: true,
                core_auto_cleanup_kdms: true
                core_auto_cleanup_watchfolder: true
            }
        
        """
        return {'data': self.service.get_auto_cleanup_settings(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['settings'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def save_auto_cleanup_settings(self, settings):
        """
        Save the settings for the Automatic cleanup function.
        
        :param settings: JSON dictionary of settings
        
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_auto_cleanup_settings?settings={core_auto_cleanup_kdms: True, core_auto_cleanup_packs: True, core_auto_cleanup_schedules: True, core_auto_cleanup_pos: True, core_auto_cleanup_titles: True, core_auto_cleanup_transfers: True, core_auto_cleanup_log_files: True, core_auto_cleanup_playlists: True, core_auto_cleanup_watchfolder: True, core_auto_cleanup_playlists_expiry_days: 7}"
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ]
           }
        
        """
        return {'messages': self.service.save_auto_cleanup_settings(settings),
         'data': {}}

    @cherrypy.expose
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def get_auto_playlist_generation_settings(self):
        """
        Get the settings for the Automatic playlist generation.
        
        :return: JSON string representing the settings.
        
        Example HTTP request::
        
           GET /core/configuration/get_auto_playlist_generation_settings
        
        Example HTTP Response::
            {
                name_choices: [...],
                core_templated_playlist_date_format: "%m.%d_%H:%M",
                date_choices: [...],
                core_templated_playlist_name: "{original_playlist_title}_{weekscreen}_{scheduled_playback_date}"
            }
        
        """
        return {'data': self.service.get_auto_playlist_generation_settings(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['settings'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy.tools.authenticate()
    def save_auto_playlist_generation_settings(self, settings):
        """
        Save the settings for the Automatic playlist generation.
        
        :param settings: JSON dictionary of settings
        
        :return: JSON string containing success or error messages
        
        Example HTTP request::
        
           GET /core/configuration/save_auto_playlist_generation_settings?settings={core_templated_playlist_name: "{original_playlist_title}_{weekscreen}_{scheduled_playback_date}", core_templated_playlist_date_format: "%m.%d_%H:%M"}"
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ]
           }
        
        """
        return {'data': {},
         'messages': [self.service.save_auto_playlist_generation_settings(settings)]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pos_auto_playlist_name_pattern', 'pos_auto_playlist_date_format'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def test_naming_pattern(self, pos_auto_playlist_name_pattern, pos_auto_playlist_date_format = None):
        return_data = self.service.test_naming_pattern(pos_auto_playlist_name_pattern, pos_auto_playlist_date_format)
        return {'data': return_data,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_default_naming_pattern(self):
        return_data = self.service.get_default_naming_pattern()
        return {'data': return_data,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_contact(self, contact_id = None, name = None, phone1 = None, email = None, type = None):
        messages = self.validate_contact(name, phone1, email, type)
        if not messages:
            message = self.service.save_contact(name, phone1, email, type, contact_id=contact_id)
            messages.append(message)
        return {'data': {},
         'messages': messages}

    def validate_contact(self, name, phone1, email, type):
        messages = []
        if not email:
            if not phone1:
                if not name:
                    if not type:
                        messages.append({'type': 'error',
                         'message': 'Form is blank'})
                    if not name:
                        messages.append({'type': 'error',
                         'message': 'Name is a required field'})
                    email or phone1 or messages.append({'type': 'error',
                     'message': 'Please provide an email and/or a phone number'})
                matches = email and re.match("[A-Za-z0-9!#$%&'*+/=?\\^_`{|}~-]+(\\.[A-Za-z0-9!#$%&'*+/=?\\^_`{|}~-]+)*@([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?\\.)+[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?", email)
                (not matches or len(email) < 7) and messages.append({'type': 'error',
                 'message': 'Email Address Invalid'})
        return messages

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_contacts(self, st = None):
        return {'data': self.service.get_contacts(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_contact(self, id):
        """
        Deletes contact configuration information
        :param id: required primary key of row
        
        Example HTTP request::
        
           GET /core/configuration/delete_contact/id
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Delete",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.delete_contact(id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_address(self, type = None, addressee = None, streetaddress = None, streetaddress2 = None, city = None, province = None, postcode = None, country = None, address_id = None):
        """
        Saves address configuration information
        :param addressee: optional addressee name
        :param streetaddress: required streeaddress
        :param streetaddress2: optional streeaddress2
        :param province: required province
        :param postcode: optional postcode
        :param country: required country
        
        Example HTTP request::
        
           GET /core/configuration/save_address_settings?addressee="addressee"&streetaddress="streetaddress"&streetaddress2="streetaddress2"&province="province"&postcode="postcode"&country="UK"
        
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Saved",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        messages = self.validate_address(type, addressee, streetaddress, streetaddress2, city, province, postcode, country)
        if messages:
            return {'data': {},
             'messages': messages}
        data_message = self.service.save_address(type, addressee, streetaddress, streetaddress2, city, province, postcode, country, address_id=address_id)
        return {'data': {},
         'messages': [data_message]}

    def validate_address(self, type, addressee, streetaddress, streetaddress2, city, province, postcode, country):
        messages = []
        if not streetaddress:
            messages.append({'type': 'error',
             'message': 'Street Address is required field'})
        if not city:
            messages.append({'type': 'error',
             'message': 'City is required field'})
        if not province:
            messages.append({'type': 'error',
             'message': 'Province is required field'})
        return messages

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_addresses(self):
        return {'data': self.service.get_addresses(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete_address(self, address_id):
        """
        Deletes address configuration information
        :param id: required primary key of row
        
        Example HTTP request::
        
           GET /core/configuration/delete_address/id
        Example HTTP Response::
           {
               "messages":
                   [
                       {
                           "message":"Delete",
                           "type":"success"
                       }
                   ],
               "data":{}
           }
        
        """
        message = self.service.delete_address(address_id)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_sync_settings(self):
        """
        Get Sync settings
        # TODO - Docstrings
        """
        return {'data': self.service.get_sync_settings(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['settings'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_sync_settings(self, settings = {}, preset = None):
        """
        Set Sync settings
        # TODO - Docstrings
        """
        message = self.service.set_sync_settings(settings, preset)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['configs'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_configuration(self, configs):
        """
        Get Configs
        # TODO - Docstrings
        """
        data = self.service.get_configuration(configs)
        return {'data': data,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['configs'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_configuration(self, configs):
        """
        Set Configs
        # TODO - Docstrings
        """
        message = self.service.set_configuration(configs)
        return {'data': {},
         'messages': [message]}
# okay decompyling ./core/api/configuration_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:03 CST
