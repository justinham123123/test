# 2017.08.13 21:48:14 CST
# Embedded file name: build\bdist.win32\egg\serv\core\core_main.py
"""
AAM TMS Core Base
(c) 2010 Arts Alliance Media

This base class for the Theatre Core. It provides
the basic API (for the most part the functions exposed by
the dormei api.) The core class inherits from this
file and builds on it, providing more complex queries
"""
import os
import sys
import time
import logging
import threading
import traceback
import uuid
import random
import socket
import Queue
import json
import tempfile
import subprocess
from multiprocessing import Process
import inspect
from copy import copy
from _collections import deque
from datetime import datetime, timedelta
from urllib2 import URLError
import hashlib
from serv.lib.email.email_imap import email_imap
from serv.lib.network import ftp_server as FTPServer
from sqlalchemy.sql.expression import not_, and_
from pympler.asizeof import asizeof
import cherrypy
from cherrypy.process.plugins import Monitor
from serv.lib.utilities import date_utils, config
from serv.lib.utilities.utils import get_macs, kill_process
from serv.lib.cherrypy.cherrypy_utils import TmsMonitor, DeviceMonitor, json_out_handler, cherrypy_peformance_log
from serv.lib.dcinema.parsers.parsers import parse_kdm
from serv.lib.dcinema.constants import TERRITORIES
from serv.lib.network.snmp import SnmpManager
from serv.lib.utilities.os_drive_helper import get_os_mounted_drives
from serv.lib.email.email_pop import email_pop
from serv import WIN32
from serv.core.tasks import schedule_sync
from serv.core.devices.base.audio_controller import AudioController
from serv.core.devices.base.projection import Projection
from serv.bin.restart_services import restart_services
if WIN32:
    from serv.lib.utilities.windows_removable_media import check_cdrom_drive as windows_cd_check
from serv.core.tasks import pack_sync, log_manager, auto_cleanup, marker_clip_processor
from serv.core.devices.sms.doremi import doremi, factory as doremi_factory
from serv.core.devices.sms.dolby import dolby, factory as dolby_factory
from serv.core.devices.sms.gdc import gdc
from serv.core.devices.sms.sony import sony_sms
from serv.core.devices.sms.christie import christie_imb
from serv.core.devices.sms.christie.christie_utils import Timeout
from serv.core.devices.sms.qube import qube
from serv.core.devices.sms.aam import aam as aam_sms
from serv.core.devices.sms.imax import imax
from serv.core.devices.sms.barco import barco as barco_imb
from serv.core.devices.audio.dolby import dolby_cp750
from serv.core.devices.audio.dolby import dolby_cp850
from serv.core.devices.qc.usl import lss100
from serv.core.devices.camera.axis import axis
from serv.core.devices.camera.foscam import foscam
from serv.core.devices.projector.nec import nec_series_1, factory as nec_factory
from serv.core.devices.projector.barco import barco_series_1, factory as barco_factory
from serv.core.devices.projector.christie import christie_series_1, factory as christie_factory
from serv.core.devices.projector.sony import sony_projector, factory as sony_factory
from serv.core.devices.projector.aam import aam as aam_projector
from serv.core.devices.projector.imax import imax as imax_projector
from serv.core.devices.content.aamLMS import aamLMS
from serv.core.devices.content.logical_drive import logical_drive
from serv.core.devices.content.watchfolder import watchfolder
from serv.core.devices.content.ftp_drive import ftp_drive
from serv.core.devices.pos.vista import vista
from serv.core.devices.pos.newman import newman
from serv.core.devices.pos.sarft import sarft
from serv.core.devices.pos.compeso import compeso
from serv.core.devices.pos.markus import markus
from serv.core.devices.pos.ebillet import ebillet
from serv.core.devices.pos.kinodk import kinodk
from serv.core.devices.pos.dolphin import dolphin
from serv.core.devices.pos.dingxin import dingxin
from serv.core.devices.pos.aam import aam as aam_pos
from serv.core.devices.pos.merlin import merlin
from serv.core.devices.pos.onestepahead import onestepahead
from serv.core.devices.pos.dx import dx
from serv.core.devices.pos.generic import generic_pos
from serv.core.devices.base import camera as base_camera
from serv.core.devices.base import content as base_content
from serv.core.devices.base import mount_point as base_mount_point
from serv.core.devices.base import custom
from serv.core.devices.base.playback import Playback
from serv.configuration.constants import *
from serv.lib.network.snmp import SNMPTimeout
from serv.storage.database.playback import database as playback_db
from serv.storage.database.audit import database as audit_db
from serv.storage.database.primary import database as db
from serv.configuration import cfg
from serv.core import VERSION
from serv.lib.utilities.helper_methods import get_transfer_time
from serv.lib.utilities.helper_methods import create_screen_or_device_uuid, get_complex_device_uuids_from_metadata, get_screen_uuids_from_metadata
from serv.core.api.paginated import Paginated
from serv.core.api.Logging import Logging as Logging_API
from serv.lib.utilities.action import Action
from serv.core.api.playlist_api import PlaylistAPI
from serv.core.api.content_api import ContentAPI
from serv.core.api.placeholder_api import PlaceholderAPI
from serv.core.api.title_api import TitleAPI
from serv.core.api.pack_api import PackAPI
from serv.core.api.macropack_api import MacroPackAPI
from serv.core.api.playback_api import PlaybackAPI
from serv.core.api.automation_api import AutomationAPI
from serv.core.api.scheduling_api import SchedulingAPI
from serv.core.api.monitoring_api import MonitoringAPI
from serv.core.api.camera_api import CameraAPI
from serv.core.api.projection_api import ProjectionAPI
from serv.core.api.configuration_api import ConfigurationAPI
from serv.core.api.pos_api import POS_API
from serv.core.api.messaging_api import MessagingAPI
from serv.core.api.note_api import NoteAPI
from serv.core.api.template_api import TemplateAPI
from serv.lib.utilities.show_attribute_utils import ShowAttributeUtils
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.cherrypy.i18n_tool import update_language
from serv.storage.memory.content_store import ContentStore
from serv.storage.memory.playlist_store import PlaylistValidationStore
from serv.storage.memory.schedule_store import ScheduleValidationStore
from serv import app_dir

def __close_session():
    db.Session.remove()
    playback_db.Session.remove()
    audit_db.Session.remove()


cherrypy.request.hooks.attach('on_end_request', __close_session)
update_language(cfg.core_language.get())

class TheatreCore(object):
    """
    Manages a set of screen servers, and acts as a factory for the dynamic creation of
    appropriate screen server types.
    """

    def shutdown(self):
        """
        Shutdown TMS.
        """

        def _kill(pid):
            if pid:
                logging.info('Stopping Process [%s]' % str(pid))
                kill_process(pid)

        logging.info('Stopping Device Monitors')
        cherrypy.engine.shutdown_servers = True
        self.log_manager.shutdown()
        device_ids, errors = self.get_devices(enabled_only=False)
        for device_id in device_ids:
            self._action(self.devices[device_id].shutdown)

        time.sleep(3)
        if getattr(cherrypy, 'ftpproc', False):
            _kill(cherrypy.ftpproc.pid)
        if getattr(cherrypy, 'snmp', False):
            _kill(cherrypy.snmp.pid)
        try:
            if not WIN32:
                os.remove(os.path.join(cfg.data_dir(), 'lock', 'cinema_services.pid'))
        except:
            pass
        finally:
            _kill(os.getpid())

    def startup(self):
        self.messaging_service.start()
        self.initialize_devices()
        if cfg.pos_enabled():
            self.pos_service.update_mapping_overview()

    def restart(self):
        """
        Restart TMS
        """
        self.restarting_services = True
        is_32bit_Linux = True if not WIN32 and 'x86_64' not in str(self.popen('uname -a')).lower() else False
        executable_command = '/opt/python-2.6.4/bin/python2.6' if is_32bit_Linux else 'python'
        if not WIN32:
            jemalloc_path_32bit = '/usr/lib/libjemalloc.so'
            jemalloc_path_64bit = '/usr/lib64/libjemalloc.so'
            if os.path.exists(jemalloc_path_32bit):
                executable_command = 'LD_PRELOAD="%s" ' % jemalloc_path_32bit + executable_command
            elif os.path.exists(jemalloc_path_64bit):
                executable_command = 'LD_PRELOAD="%s" ' % jemalloc_path_64bit + executable_command
        startup_command = executable_command + ' ' + cfg.service_start_command.get()
        pid_file_location = os.path.join(cfg.data_dir(), 'lock', 'cinema_services.pid')
        pids = [os.getpid(), cherrypy.ftpproc.pid, cherrypy.snmp.pid]
        logging.info('Restarting services with command [%s]' % startup_command)
        p = Process(target=restart_services, args=(pids, startup_command, pid_file_location))
        p.daemon = False
        p.start()
        self.shutdown()

    def queue_schedule_sync(self):
        self.schedule_sync_queue.put(True)

    def queue_packs_for_dcp_creation(self, pack_uuids):
        self.dcp_queue.put(list(pack_uuids))

    def queue_all_packs_for_dcp_creation(self):
        self.queue_packs_for_dcp_creation(self.pack_service.packs().keys())

    def queue_cpl_for_dcp_creation(self, cpl_uuid):
        pack_uuids = []
        for pack in db.Session.query(db.Pack).filter(db.Pack.clips.like('%' + cpl_uuid + '%')).all():
            pack_uuids.append(pack.uuid)

        if pack_uuids:
            self.dcp_queue.put(pack_uuids)

    def content_device_syncing_started(self):
        self.content_devices_syncing += 1

    def content_device_syncing_complete(self):
        self.content_devices_syncing -= 1

    def monitor_top(self):
        if not self.arch:
            self.arch = '64bit' if 'x86_64' in str(self.popen('uname -a')).lower() else '32bit'
        if not self.top_summary:
            self.top_summary = {'arch': self.arch,
             'memory': {},
             'processes': {}}
        for line in self.popen('top -b -n1 -c'):
            line = line.lower()
            if line.startswith('mem:'):
                mem = [ a for a in line.split(' ') if a ]
                self.top_summary['memory']['total'] = mem[1]
                self.top_summary['memory']['used'] = mem[3]
                self.top_summary['memory']['free'] = mem[5]

        postgres_pids = []
        main_pid = str(os.getpid())
        ftp_pid = str(cherrypy.ftpproc.pid)
        snmp_pid = str(cherrypy.snmp.pid)
        emulator_pids = {}
        for uuid, device in self.devices.iteritems():
            if str(device.device_configuration['type']) in ('aam', 'emulator') and device.device_configuration['category'] != 'projector':
                emulator_pids[str(device.process.pid)] = '%s Emulator [Port %s]' % (device.device_configuration['category'].upper(), str(device.device_configuration['port']))

        def _resolve_pid(pid):
            pid = str(pid)
            if pid == main_pid:
                return 'Main TMS Process'
            elif pid == ftp_pid:
                return 'FTP Server'
            elif pid == snmp_pid:
                return 'SNMP Manager'
            elif pid in postgres_pids:
                return 'Postgres'
            else:
                return emulator_pids.get(pid)

        pid_stats = {}
        for i in xrange(0, 5):
            for line in self.popen('top -b -n1 -c'):
                if 'python' in line or 'postmaster' in line:
                    proc = [ a for a in line.split(' ') if a ]
                    pid = proc[0]
                    if 'postmaster' in line:
                        postgres_pids.append(pid)
                    if not self.top_summary['processes'].has_key(pid):
                        self.top_summary['processes'][pid] = {'mem': deque(maxlen=100),
                         'cpu': deque(maxlen=100),
                         'uptime': None}
                        self.top_summary['processes'][pid]['uptime'] = proc[10]
                        self.top_summary['processes'][pid]['command'] = _resolve_pid(pid)
                        if not self.top_summary['processes'][pid]['command']:
                            self.top_summary['processes'][pid]['command'] = ''
                            for word in proc[11:]:
                                self.top_summary['processes'][pid]['command'] += word.replace('\n', '') + ' '

                    if pid not in pid_stats:
                        pid_stats[pid] = {'cpu': [],
                         'mem': []}
                    pid_stats[pid]['cpu'].append(int(float(proc[8])))
                    pid_stats[pid]['mem'].append(int(float(proc[9])))

        for pid in self.top_summary['processes']:
            if pid in pid_stats:
                self.top_summary['processes'][pid]['cpu'].append({'value': sum(pid_stats[pid]['cpu']) / len(pid_stats[pid]['cpu']),
                 'stamp': time.time()})
                self.top_summary['processes'][pid]['mem'].append({'value': sum(pid_stats[pid]['mem']) / len(pid_stats[pid]['mem']),
                 'stamp': time.time()})

        return

    def popen(self, command):
        f = tempfile.TemporaryFile()
        p = subprocess.Popen(command.split(' '), stdout=f)
        time.sleep(3)
        p.terminate()
        p.wait()
        f.seek(0)
        output = []
        while True:
            line = f.readline()
            if not line:
                break
            output.append(line)

        f.close()
        return output

    def log_query(self, query):
        self.db_query_queue.put(query)

    def monitor_dbs(self):
        while not cherrypy.engine.shutdown_servers:
            query = self.db_query_queue.get(True)
            hash = hashlib.md5(query['statement']).hexdigest()
            self.db_query_stats.setdefault(hash, {'statement': query['statement'],
             'tracebacks': [query['traceback']],
             'time': 0,
             'count': 0})['time'] += query['time_taken']
            self.db_query_stats[hash]['count'] += 1
            if query['traceback'] not in self.db_query_stats[hash]['tracebacks']:
                self.db_query_stats[hash]['tracebacks'].append(query['traceback'])
            self.db_query_queue.task_done()

    def monitor_memory(self):
        """
        Peridoically check the sizes of the data stores
        """
        analyse_this = {'core.contents.store': self.contents.store,
         'core.contents.playlist_content': self.contents.playlist_content,
         'core.playlist_validation.devices': self.playlist_validation.devices,
         'core.playlist_validation.schedule_map': self.playlist_validation.schedule_map,
         'core.schedule_validation.validation': self.schedule_validation.validation,
         'core.schedule_validation.clashes': self.schedule_validation.clashes,
         'cherrypy.engine': cherrypy.engine,
         'core': self,
         'core.log_manager': self.log_manager}
        for uuid, device in self.devices.iteritems():
            analyse_this['device-' + str(self.get_pretty_name(uuid))] = device

        analyse_this['db'] = db
        analyse_this['playback_db'] = playback_db
        analyse_this['audit_db'] = audit_db
        dump = open('memory_profile.json', 'w')
        for key in analyse_this:
            try:
                current_size = asizeof(analyse_this[key])
                if not self.memory_profile.has_key(key):
                    self.memory_profile[key] = {'current': current_size,
                     'increase': [],
                     'rate': None}
                else:
                    spectrum = self.memory_profile[key]['increase']
                    spectrum.append(current_size - self.memory_profile[key]['current'])
                    if len(spectrum) > 20:
                        spectrum.pop(0)
                    self.memory_profile[key]['current'] = current_size
                    self.memory_profile[key]['max'] = current_size if current_size > self.memory_profile[key].get('max', 0) else self.memory_profile[key]['max']
                    delta = 0
                    for increase in self.memory_profile[key]['increase']:
                        delta += increase

                    delta_string = '+' + str(delta) if delta > 0 else str(delta)
                    self.memory_profile[key]['rate'] = delta_string + ' last ' + str(len(spectrum) * 3) + ' minutes'
                    if delta != 0:
                        dump.write(key + ' ' + str(current_size) + ' [' + self.memory_profile[key]['rate'] + '][max ' + str(self.memory_profile[key]['max']) + ']\n')
                        dump.write(json.dumps(spectrum) + '\n\n')
            except:
                logging.error('Error tracking object [%s]' % key, exc_info=True)

        dump.close()
        return

    def __init__(self):
        cherrypy.core = self
        self.start_time = time.time()
        self.devices = {}
        self.ignored_cdrom_drives = set()
        self.cdrom_ignore_lock = threading.Lock()
        self.screens = {}
        self.content_lock = threading.RLock()
        self.contents = ContentStore()
        self.memory_profile = {}
        self.playlist_validation = PlaylistValidationStore()
        self.schedule_validation = ScheduleValidationStore()
        self.playlists = {}
        self.kdm_email_status = None
        self.kdm_email_history = deque(maxlen=20)
        self.kdm_email_read_uidls = []
        self.log_queue = Queue.Queue()
        self.db_query_queue = Queue.Queue()
        self.db_query_stats = {}
        self.dcp_queue = Queue.Queue()
        self.schedule_sync_queue = Queue.Queue()
        self.core_show_attributes = {}
        self.macro_placeholders = {}
        self.servers_purged = 0
        self.monitor_frequency = None
        self.ftp_server_running = True
        self.restarting_services = False
        self.content_devices_syncing = 0
        self.emulation = {}
        self.top_summary = {}
        self.exception_cache = None
        self.performance_cache = {}
        self.api_call_size_cache = {}
        self.log_all_api_requests = False
        self.version_string = '%(major)s.%(minor)s.%(build)s-%(commit)s' % VERSION
        self.arch = None
        self.automation = AutomationAPI(self)
        self.camera = CameraAPI(self)
        self.messaging = MessagingAPI(self)
        self.note = NoteAPI(self)
        self.configuration = ConfigurationAPI(self)
        self.content = ContentAPI(self)
        self.macro_pack = MacroPackAPI(self)
        self.monitoring = MonitoringAPI(self)
        self.pack = PackAPI(self)
        self.placeholder = PlaceholderAPI(self)
        self.playback = PlaybackAPI(self)
        self.playlist = PlaylistAPI(self)
        self.pos = POS_API(self)
        self.projection = ProjectionAPI(self)
        self.scheduling = SchedulingAPI(self)
        self.title = TitleAPI(self)
        self.template = TemplateAPI(self)
        self.paginated = Paginated(self)
        self.automation_service = self.automation.service
        self.camera_service = self.camera.service
        self.messaging_service = self.messaging.service
        self.configuration_service = self.configuration.service
        self.content_service = self.content.service
        self.macro_pack_service = self.macro_pack.service
        self.monitoring_service = self.monitoring.service
        self.pack_service = self.pack.service
        self.placeholder_service = self.placeholder.service
        self.playback_service = self.playback.service
        self.playlist_service = self.playlist.service
        self.pos_service = self.pos.service
        self.projection_service = self.projection.service
        self.scheduling_service = self.scheduling.service
        self.title_service = self.title.service
        self.template_service = self.template.service
        self.log_manager = log_manager.Log_Manager(self)
        self.schedule_synchroniser = schedule_sync.Schedule_Synchroniser(self)
        self.pack_synchroniser = pack_sync.Pack_Synchroniser(self)
        self.auto_cleanup = auto_cleanup.Auto_Cleanup(self)
        if cfg.marker_clip_templating():
            self.marker_clip_processor = marker_clip_processor.MarkerClipProcessor(self)
        self.logging = Logging_API(self)
        self.logging_service = self.logging.service
        self._configure_core_monitor_frequency()
        datetime.strptime('2010-01-01 00:00:00.000000', '%Y-%m-%d %H:%M:%S.%f')
        self.snmp_manager = SnmpManager(timeout=1)
        self.snmp_manager_thread = threading.Thread(target=self.snmp_manager.safe_run)
        self.snmp_manager_thread.daemon = True
        self._load_monitoring_types()
        self.schedule_lock = threading.RLock()
        cherrypy.engine.shutdown_servers = False
        cherrypy.engine.subscribe('stop', self.shutdown, 0)
        cherrypy.engine.subscribe('content_device_syncing_started', self.content_device_syncing_started)
        cherrypy.engine.subscribe('content_device_syncing_complete', self.content_device_syncing_complete)
        if cfg.core_log_collection_only():
            frequency = cfg.core_log_collection_only_frequency() * 60
            TmsMonitor(cherrypy.engine, self.log_manager.run, frequency, 'LogManager Runner', 900).subscribe()
        else:
            self.start_worker_threads()
        self.initialise_defaults()
        cherrypy.engine.subscribe('start', self.startup, 100)
        self._load_core_show_attributes()
        self.load_macro_pack_placeholders()
        self.licensing_checks()
        cherrypy.engine.subscribe('license_updated', self.licensing_checks)
        cherrypy.engine.subscribe('device_snmp_update', self.device_snmp_update)
        return

    def start_worker_threads(self):
        cherrypy.engine.subscribe('queue_schedule_sync', self.queue_schedule_sync)
        self.core_schedule_synchroniser = Monitor(cherrypy.engine, self.process_schedule_sync_queue, SCHEDULE_SYNC_CYCLE, 'Schedule Sync')
        self.core_schedule_synchroniser.subscribe()
        cherrypy.engine.subscribe('log_entry', self.log_manager.collect_live_logs, 0)
        Monitor(cherrypy.engine, self.log_manager.flush_live_logs, 5, 'Live Log Parser').subscribe()
        Monitor(cherrypy.engine, self.log_manager.flush_audit_logs, 5, 'Audit Logger').subscribe()
        TmsMonitor(cherrypy.engine, self.log_manager.run, LOG_MANAGER_CYCLE, 'LogManager Runner', 900).subscribe()
        Monitor(cherrypy.engine, self.auto_cleanup.clean, AUTO_CLEANUP_CYCLE, 'Auto Cleanup').subscribe()
        if cfg.core_monitor_memory.get():
            Monitor(cherrypy.engine, self.monitor_memory, MEMORY_MONITOR_CYCLE, 'Memory monitor').subscribe()
        if cfg.core_monitor_dbs.get():
            cherrypy.engine.subscribe('log_query', self.log_query, 0)
            Monitor(cherrypy.engine, self.monitor_dbs, 5, 'DB monitor').subscribe()
        if not WIN32:
            Monitor(cherrypy.engine, self.monitor_top, TOP_MONITOR_CYCLE, 'Top Monitor').subscribe()
        cherrypy.engine.subscribe('start', self.snmp_manager_thread.start, 80)
        if WIN32:
            from serv.lib.utilities.windows_removable_media import WindowsMediaInsertionThread
            self.windows_media_thread = WindowsMediaInsertionThread(self)
            cherrypy.engine.subscribe('start', self.windows_media_thread.start, 90)
            cherrypy.engine.subscribe('stop', self.windows_media_thread.stop)
        Monitor(cherrypy.engine, self.start_transfers, TRANSFER_MANAGER_CYCLE, 'Transfer Manager').subscribe()
        Monitor(cherrypy.engine, self.auto_transfer, AUTO_TRANSFER_CYCLE, 'Auto Transfer Manager').subscribe()
        if cfg.auto_generate_dcps.get():
            cherrypy.engine.subscribe('queue_all_packs_for_dcp_creation', self.queue_all_packs_for_dcp_creation)
            cherrypy.engine.subscribe('queue_packs_for_dcp_creation', self.queue_packs_for_dcp_creation)
            cherrypy.engine.subscribe('queue_cpl_for_dcp_creation', self.queue_cpl_for_dcp_creation)
            Monitor(cherrypy.engine, self.process_DCPs, PACKAGE_MANAGER_CYCLE, 'Composite DCP Manager').subscribe()
        Monitor(cherrypy.engine, self.email_handler, EMAIL_HANDLER_CYCLE, 'Email Manager').subscribe()
        Monitor(cherrypy.engine, self.image_getter, IMAGE_GETTER_CYCLE, 'Image Getter').subscribe()
        Monitor(cherrypy.engine, self.update_drive_list, DRIVE_LIST_VALIDITY, 'Drive Manager').subscribe()
        Monitor(cherrypy.engine, self.pack_synchroniser.sync, PACK_SYNC_CYCLE, 'Pack Synchroniser').subscribe()
        if cfg.marker_clip_templating():
            Monitor(cherrypy.engine, self.run_marker_clip_templating, 60, 'Marker Clip Templating').subscribe()

    @db.close_session
    def validate_device_uuids(self, metadata, mac_address_list):
        """
        For auto configured sites we want to make sure we have unique and consistent device UUIDs
        """
        self._refresh_lms(create_screen_or_device_uuid({'type': 'aamlms'}, mac_address_list))
        valid_screen_uuids = get_screen_uuids_from_metadata(metadata, mac_address_list)
        screens_to_remove = []
        for screen_uuid in self.configuration_service.screen():
            if screen_uuid not in valid_screen_uuids:
                screens_to_remove.append(screen_uuid)

        if screens_to_remove:
            self.configuration_service.delete_screen(screens_to_remove)
        valid_device_uuids = get_complex_device_uuids_from_metadata(metadata, mac_address_list)
        devices_to_remove = []
        device_categories_to_remove = ['pos', 'content']
        db_devices = self.configuration_service.device()
        for device_uuid in db_devices:
            if device_uuid not in valid_device_uuids:
                if db_devices[device_uuid]['category'] in device_categories_to_remove:
                    devices_to_remove.append(device_uuid)

        if devices_to_remove:
            self.configuration_service.delete_device(devices_to_remove)

    @db.close_session
    def _refresh_lms(self, new_lms_uuid = None):
        """
        Ensure we have an LMS.
        Optionally update it's UUID
        """
        lms_uuid = cfg.lms_uuid()
        if lms_uuid == '' or new_lms_uuid and lms_uuid != new_lms_uuid:
            lms_uuid = str(uuid.uuid4()) if not new_lms_uuid else new_lms_uuid
            cfg.lms_uuid.set(lms_uuid)
            config.save()
        if not db.Session.query(db.Device).filter(and_(db.Device.type == 'aamlms', db.Device.uuid == lms_uuid)).count():
            db.Session.query(db.Device).filter(db.Device.type == 'aamlms').delete()
            lms_device = db.Device()
        else:
            lms_device = db.Session.query(db.Device).filter(and_(db.Device.type == 'aamlms', db.Device.uuid == lms_uuid)).first()
        lms_device.uuid = lms_uuid
        lms_device.category = 'lms'
        lms_device.type = 'aamlms'
        lms_device.name = 'LMS'
        lms_device.ftp_ip_address = cfg.lms_ftp_ip()
        lms_device.ftp_port = cfg.lms_ftp_port()
        lms_device.ftp_username = cfg.lms_ftp_username()
        lms_device.ftp_password = cfg.lms_ftp_password()
        lms_device.enabled = cfg.lms_enabled()
        db.Session.add(lms_device)
        db.Session.commit()

    @db.close_session
    def _add_default_placeholders(self):
        """
        Add default Pack placeholders
        """
        db_placeholders = [ x.name for x in db.Session.query(db.Placeholder).all() ]
        if not db_placeholders:
            for placeholder_name in DEFAULT_PLACEHOLDERS:
                if placeholder_name not in db_placeholders:
                    new_placeholder = db.Placeholder(name=placeholder_name, uuid=str(uuid.uuid5(uuid.NAMESPACE_DNS, placeholder_name)))
                    db.Session.add(new_placeholder)

            db.Session.commit()

    @db.close_session
    def _add_default_macro_placeholders(self):
        """
        Add default Macro Pack placeholders
        """
        db_macro_placeholders = [ x.name for x in db.Session.query(db.MacroPlaceholder).all() ]
        for macro_placeholder_name, transition, can_delete, has_content in DEFAULT_MACRO_PLACEHOLDERS:
            if macro_placeholder_name not in db_macro_placeholders:
                new_macro_placeholder = db.MacroPlaceholder(uuid=str(uuid.uuid5(uuid.NAMESPACE_DNS, macro_placeholder_name)), name=macro_placeholder_name, transition=transition, can_delete=can_delete, has_content=has_content)
                db.Session.add(new_macro_placeholder)
                db.Session.commit()

    @db.close_session
    def _add_default_show_attributes(self):
        """
        Add default Show Attributes
        """
        db_show_attributes = [ x.name for x in db.Session.query(db.ShowAttribute).all() ]
        for show_attribute_name, cpl_attr, screen_attr in DEFAULT_SHOW_ATTRIBUTES:
            if show_attribute_name not in db_show_attributes:
                sa = {'name': show_attribute_name,
                 'cpl_attribute': cpl_attr,
                 'screen_attribute': screen_attr,
                 'custom': False}
                ShowAttributeUtils(db).create(sa)

    @db.close_session
    def _configure_country_code(self):
        """
        Our configured country code needs to be a key in the Territories dict for default ratings to work.
        """
        if cfg.country() not in TERRITORIES:
            for _id, _value in TERRITORIES.iteritems():
                if cfg.country().lower() == _value.get('name', '').lower():
                    cfg.country.set(_id)
                    config.save()
                    break

    @db.close_session
    def initialise_defaults(self):
        """
        Initialise defaults
        """
        self._refresh_lms()
        self._add_default_placeholders()
        self._add_default_macro_placeholders()
        self._add_default_show_attributes()
        self._configure_country_code()

    def _configure_core_monitor_frequency(self):
        server_count = db.Session.query(db.Device).filter(db.Device.category == 'sms').count()
        self.monitor_frequency = int(server_count / 2) if server_count > 10 else 5

    def load_macro_pack_placeholders(self):
        """
        for lookup reasons - load in the macro pack placeholders in a nice lookup table so we can get the uuid for a name
        """
        self.macro_placeholders = {}
        for mp in db.Session.query(db.MacroPlaceholder).all():
            self.macro_placeholders[mp.name] = mp.uuid

    def _load_core_show_attributes(self):
        """
        for lookup reasons - load in the non custom show attributes in a nice lookup table so we can get the uuid for a name
        """
        for show_attribute in db.Session.query(db.ShowAttribute).filter(db.ShowAttribute.custom == False).all():
            self.core_show_attributes[show_attribute.name] = show_attribute.uuid

    @db.close_session
    def licensing_checks(self):
        self.purge_unauthorised_servers()

    def device_snmp_update(self, data):
        device_uuid = data.get('device_uuid')
        device = self.devices.get(device_uuid)
        if device:
            try:
                info = data.get('info')
                device.handle_snmp_update(info)
            except AttributeError:
                logging.warning('Received snmp data for device that does not implement monitoring [%s]' % device_uuid)

        else:
            logging.warning('Received snmp data for unknown device [%s]' % device_uuid)

    @db.close_session
    def purge_unauthorised_servers(self):
        if cherrypy.aam_auth.license:
            allowed = cherrypy.aam_auth.license['options']['screen_count'] if cherrypy.aam_auth.license else 0
            actual = db.Session.query(db.Device).filter(db.Device.category == 'sms').count()
            unauthorised = actual - allowed
            remove_these = []
            for device in db.Session.query(db.Device).filter(db.Device.category == 'sms').order_by(db.Device.created.desc()):
                if unauthorised > 0:
                    logging.info('Removing unauthorised device [%s]' % device.uuid)
                    remove_these.append(device.uuid)
                    unauthorised = unauthorised - 1
                else:
                    break

            if len(remove_these) > 0:
                self.servers_purged = len(remove_these)
                self.configuration_service.delete_device(remove_these)

    def max_servers_reached(self):
        if cherrypy.aam_auth.license:
            allowed = cherrypy.aam_auth.license['options']['screen_count'] if cherrypy.aam_auth.license else 0
            actual = db.Session.query(db.Device).filter(db.Device.category == 'sms').count()
            return allowed <= actual
        else:
            return True

    def drive_ignore_list(self):
        ignore_list = cfg.core_mount_drives_ignore().split(',')
        return ignore_list

    def check_cd_drive(self, drive_path):
        if WIN32:
            return windows_cd_check(drive_path)
        return True

    def enable_cdrom_drive(self, drive_path):
        with self.cdrom_ignore_lock:
            try:
                self.ignored_cdrom_drives.remove(drive_path)
            except KeyError as e:
                pass

    def update_drive_list(self):
        self.cdrom_ignore_lock.acquire()
        try:
            mounted_drives = get_os_mounted_drives()
            existing_drives, errors = self.get_devices(required_api=base_mount_point.MountPoint)
            new_drives = {}
            keepers = []
            delete_us = []
            for device_path, drive_type in mounted_drives:
                if device_path in self.drive_ignore_list() or device_path in self.ignored_cdrom_drives:
                    continue
                else:
                    keepers.append(device_path)
                add = True
                for existing_drive_uuid in existing_drives:
                    drive = self.devices[existing_drive_uuid]
                    if drive.device_configuration['path'] == device_path:
                        add = False
                        break

                if add:
                    if drive_type == 'cd':
                        if not self.check_cd_drive(device_path):
                            self.ignored_cdrom_drives.add(device_path)
                            logging.info('CDROM drive {letter} is empty. Ignoring'.format(letter=device_path))
                            continue
                    device_id = str(uuid.uuid4())
                    new_drive = logical_drive.LogicalDrive(device_id, {'id': device_id,
                     'path': device_path,
                     'name': device_path,
                     'type': drive_type,
                     'enabled': True,
                     'ftp_ip': cfg.lms_ftp_ip(),
                     'ftp_port': cfg.lms_ftp_port(),
                     'ftp_username': cfg.lms_ftp_username(),
                     'ftp_password': cfg.lms_ftp_password(),
                     'category': 'external'})
                    new_drives[device_id] = new_drive
                    if cfg.auto_export_dcps.get() and drive_type in ('usb', 'drive'):
                        if os.listdir(device_path) == [] and os.listdir(os.path.join(cfg.lms_library_directory(), 'COMPOSITE')) != []:
                            logging.info('Exporting Composite DCPs to [%s]' % device_path)
                            self.content_service.export_composite_DCPs(device_path)

            for drive_id in new_drives.keys():
                self.devices[drive_id] = new_drives[drive_id]
                device_state_monitor = DeviceMonitor(cherrypy.engine, self.device_state_monitor, self.monitor_frequency, 'State Manager Device %s' % drive_id, drive_id)
                device_state_monitor.subscribe()
                device_state_monitor.start()
                device_acion_monitor = DeviceMonitor(cherrypy.engine, self.device_action_queue_handler, ACTION_MANAGER_CYCLE, 'Action Manager Device %s' % drive_id, drive_id)
                device_acion_monitor.subscribe()
                device_acion_monitor.start()

            configured_device_ids = self.configuration_service.device().keys()
            for key in self.devices.keys():
                if isinstance(self.devices[key], logical_drive.LogicalDrive) and key not in configured_device_ids:
                    if self.devices[key].device_configuration['path'] not in keepers:
                        delete_us.append(key)
                    elif self.devices[key].device_configuration['type'] == 'cd':
                        if not self.check_cd_drive(self.devices[key].device_configuration['path']):
                            logging.info('CDROM drive {letter} is empty. Removing'.format(letter=self.devices[key].device_configuration['path']))
                            self.ignored_cdrom_drives.add(self.devices[key].device_configuration['path'])
                            delete_us.append(key)

            for device_id in delete_us:
                self.configuration_service.remove_device(device_id)
                db.Session.query(db.Transfer).filter(db.Transfer.destination_device_uuid == device_id).delete(False)
                db.Session.commit()

            if cfg.lms_custom_ftp_enabled():
                if len(new_drives) or len(delete_us):
                    self.resync_ftp_server()
        except Exception:
            logging.error('Unable to mount an external device', exc_info=True)

        self.cdrom_ignore_lock.release()

    def resync_ftp_server(self):

        def _get_new_ftp_fs(devices):
            new_ftp_file_structure = {}
            for key in devices.keys():
                if isinstance(devices[key], logical_drive.LogicalDrive) and devices[key].device_configuration['path']:
                    new_ftp_file_structure[key] = devices[key].device_configuration['path']
                elif devices[key].device_configuration['type'] == 'aamlms':
                    new_ftp_file_structure[key] = os.path.join(cfg.lms_library_directory(), 'INGEST')

            new_ftp_file_structure['tmp'] = os.path.join(cfg.lms_library_directory(), 'tmp')
            new_ftp_file_structure['Composite_CPLs'] = os.path.join(cfg.lms_library_directory(), 'COMPOSITE')
            return new_ftp_file_structure

        def _resync_ftp_server(ftp_file_system):
            cherrypy.ftp_fs = ftp_file_system
            FTPServer.refresh_fs(ftp_file_system, cfg.lms_ftp_username(), cfg.lms_ftp_password(), host=(cfg.lms_ftp_ip(), cfg.lms_ftp_port()))

        def _restart_ftp_server():
            from CinemaServices import start_ftp
            start_ftp()

        self.ftp_server_running = False
        retries = 3
        while not self.ftp_server_running and retries > 0:
            try:
                _resync_ftp_server(_get_new_ftp_fs(self.devices))
                self.ftp_server_running = True
            except:
                logging.error('Error Resyncing FTP Server, attempting to restart', exc_info=True)
                _restart_ftp_server()
            finally:
                retries -= 1
                time.sleep(1)

    def _action(self, command, *args, **kwargs):
        action = Action(command, *args, **kwargs)
        command.__self__.push_action_stack(action)
        return action.action_id

    def _create_device(self, device_id, device_info):
        logging.debug('Creating default instance for device [%s]' % device_id)
        new_device = None
        unknown = False
        if device_info.get('custom', False):
            new_device = custom.Custom(device_id, device_info)
        elif device_info['category'] == 'sms':
            if device_info['type'] == 'doremi':
                new_device = doremi.DCP2000(device_id, device_info)
            elif device_info['type'] == 'qube':
                new_device = qube.Qube(device_id, device_info)
            elif device_info['type'] == 'aam':
                new_device = aam_sms.AAMulator(device_id, device_info)
            elif device_info['type'] == 'christie':
                new_device = christie_imb.ChristieIMB(device_id, device_info)
            elif device_info['type'] == 'dolby':
                new_device = dolby.Dolby(device_id, device_info, self.snmp_manager)
            elif device_info['type'] == 'gdc':
                new_device = gdc.GDC(device_id, device_info, self.snmp_manager)
            elif device_info['type'] == 'sony':
                new_device = sony_sms.SonySMS(device_id, device_info)
            elif device_info['type'] == 'imax':
                new_device = imax.IMAX(device_id, device_info)
            elif device_info['type'] == 'barco':
                new_device = barco_imb.Barco(device_id, device_info)
            else:
                unknown = True
        elif device_info['category'] == 'projector':
            if device_info['type'] == 'sony':
                new_device = sony_projector.SonyProjector(device_id, device_info)
            elif device_info['type'] == 'nec':
                new_device = nec_series_1.NECSeries1(device_id, device_info, self.snmp_manager)
            elif device_info['type'] == 'christie':
                new_device = christie_series_1.ChristieSeries1(device_id, device_info, self.snmp_manager)
            elif device_info['type'] == 'barco':
                new_device = barco_series_1.BarcoSeries1(device_id, device_info, self.snmp_manager)
            elif device_info['type'] == 'aam':
                new_device = aam_projector.AAMulator(device_id, device_info)
            elif device_info['type'] == 'imax':
                new_device = imax_projector.IMAX(device_id, device_info)
            else:
                unknown = True
        elif device_info['category'] == 'camera':
            if device_info['type'] == 'axis':
                new_device = axis.AXIS_M1011(device_id, device_info)
            elif device_info['type'] == 'foscam':
                new_device = foscam.Foscam(device_id, device_info)
            else:
                unknown = True
        elif device_info['category'] == 'audio':
            if device_info['type'] == 'dolby':
                if device_info['model'] == 'cp750':
                    new_device = dolby_cp750.DolbyCP750(device_id, device_info)
                elif device_info['model'] == 'cp850':
                    new_device = dolby_cp850.DolbyCP850(device_id, device_info)
                else:
                    unknown = True
            else:
                unknown = True
        elif device_info['category'] == 'qc':
            if device_info['type'] == 'usl':
                new_device = lss100.LSS100(device_id, device_info)
        elif device_info['category'] == 'pos':
            if device_info['type'] == 'vista':
                new_device = vista.Vista(device_id, device_info, self)
            elif device_info['type'] == 'newman':
                new_device = newman.Newman(device_id, device_info, self)
            elif device_info['type'] == 'sarft':
                new_device = sarft.SARFTPOS(device_id, device_info, self)
            elif device_info['type'] == 'compeso':
                new_device = compeso.Compeso(device_id, device_info, self)
            elif device_info['type'] == 'markus':
                new_device = markus.Markus(device_id, device_info, self)
            elif device_info['type'] == 'ebillet':
                new_device = ebillet.Ebillet(device_id, device_info, self)
            elif device_info['type'] == 'kinodk':
                new_device = kinodk.KinoDK(device_id, device_info, self)
            elif device_info['type'] == 'dolphin':
                new_device = dolphin.Dolphin(device_id, device_info, self)
            elif device_info['type'] == 'dingxin':
                new_device = dingxin.DingXin(device_id, device_info, self)
            elif device_info['type'] == 'emulator':
                new_device = aam_pos.AAMulator(device_id, device_info, self)
            elif device_info['type'] == 'merlin':
                new_device = merlin.Merlin(device_id, device_info, self)
            elif device_info['type'] == 'onestepahead':
                new_device = onestepahead.OneStepAhead(device_id, device_info, self)
            elif device_info['type'] == 'dx':
                new_device = dx.DX(device_id, device_info, self)
            elif device_info['type'] == 'generic':
                new_device = generic_pos.GenericPOS(device_id, device_info, self)
            else:
                unknown = True
        elif device_info['type'] == 'aamlms':
            new_device = aamLMS.AAMLMS(device_id, device_info)
        elif device_info['type'] == 'ftp':
            new_device = ftp_drive.FTPDrive(device_id, device_info)
        elif device_info['type'] == 'local':
            new_device = logical_drive.LogicalDrive(device_id, device_info)
        elif device_info['type'] == 'watchfolder':
            new_device = watchfolder.Watchfolder(device_id, device_info)
        elif device_info['type'] == 'cd':
            new_device = logical_drive.LogicalDrive(device_id, device_info)
        else:
            unknown = True
        if unknown:
            raise ValueError('Unknown device type [%s] for [%s]' % (str(device_info['type']), device_id))
        new_device.device_status['confirmed'] = False if device_info['type'] not in ('aam', 'emulator') else True
        new_device.activate(True)
        return new_device

    def _assess_device(self, device_id, device_info):
        """
        Assess device is supposed to handle all the device auto-detection stuff. If a device requires different interfaces
        depending on certain assessments of various device calls, (such as getting software version, or device model...etc) move the
        auto-detection logic to the respective device models folder into a factory file and call it's assess_device method from this function.
        That way this function can stay clean and legible.
        """
        try:
            new_device = None
            unknown = False
            if device_info.get('custom', False):
                new_device = self.devices[device_id]
            elif device_info['category'] == 'sms':
                if device_info['type'] == 'doremi':
                    new_device = self.devices[device_id]
                    new_device = doremi_factory.assess_device(device_id, new_device)
                elif device_info['type'] == 'christie':
                    new_device = self.devices[device_id]
                elif device_info['type'] == 'dolby':
                    new_device = self.devices[device_id]
                    new_device = dolby_factory.assess_device(device_id, new_device, self.snmp_manager)
                elif device_info['type'] == 'gdc':
                    new_device = self.devices[device_id]
                elif device_info['type'] == 'qube':
                    new_device = self.devices[device_id]
                elif device_info['type'] == 'aam':
                    new_device = self.devices[device_id]
                elif device_info['type'] == 'sony':
                    new_device = self.devices[device_id]
                elif device_info['type'] == 'imax':
                    new_device = self.devices[device_id]
                elif device_info['type'] == 'barco':
                    new_device = self.devices[device_id]
                else:
                    unknown = True
            elif device_info['category'] == 'projector':
                if device_info['type'] == 'sony':
                    new_device = self.devices[device_id]
                    new_device = sony_factory.assess_device(device_id, new_device)
                elif device_info['type'] == 'aam':
                    new_device = self.devices[device_id]
                elif device_info['type'] == 'nec':
                    new_device = self.devices[device_id]
                    new_device = nec_factory.assess_device(device_id, new_device, self.snmp_manager)
                elif device_info['type'] == 'christie':
                    new_device = self.devices[device_id]
                    new_device = christie_factory.assess_projector(device_id, new_device, self.snmp_manager)
                elif device_info['type'] == 'barco':
                    new_device = self.devices[device_id]
                    new_device = barco_factory.assess_device(device_id, new_device, self.snmp_manager)
                elif device_info['type'] == 'imax':
                    new_device = self.devices[device_id]
                else:
                    unknown = True
            elif device_info['category'] == 'camera':
                if device_info['type'] == 'axis':
                    new_device = axis.AXIS_M1011(device_id, device_info)
                    device_information = new_device.get_device_information()
                    if device_information['type'] == 'M1011':
                        pass
                    elif device_information['type'] == 'M1113':
                        new_device = axis.AXIS_M1113(device_id, device_info)
                    elif device_information['type'] == 'M1014':
                        new_device = axis.AXIS_M1014(device_id, device_info)
                    else:
                        raise ValueError('Unknown AXIS device type %s' % device_information['type'])
                elif device_info['type'] == 'foscam':
                    new_device = foscam.Foscam(device_id, device_info)
                else:
                    unknown = True
            elif device_info['category'] == 'audio':
                if device_info['type'] == 'dolby':
                    new_device = self.devices[device_id]
            elif device_info['category'] == 'qc':
                if device_info['type'] == 'usl':
                    new_device = self.devices[device_id]
            elif device_info['category'] == 'pos':
                if device_info['type'] in POS_DEVICE_TYPES:
                    new_device = self.devices[device_id]
                else:
                    unknown = True
            elif device_info['type'] == 'aamlms':
                new_device = self.devices[device_id]
                new_device.sync_content_store()
            elif device_info['type'] in ('watchfolder', 'local', 'ftp', 'cd', 'usb', 'drive', 'network'):
                new_device = self.devices[device_id]
            else:
                unknown = True
            if unknown:
                raise ValueError('Unknown device type [%s]' % str(device_info['type']))
            new_device.device_status['confirmed'] = True
            new_device.device_status['alive'] = True
            new_device.device_status['status'] = 'ok'
            new_device._device_sync_device_information()
        except (IOError,
         socket.error,
         URLError,
         Timeout,
         SNMPTimeout) as ex:
            if new_device:
                logging.error('Connection Problem initiating device [%s] - appears to be offline or unreachable' % device_id, exc_info=True)
                new_device.device_status['confirmed'] = False
                new_device.device_status['status'] = 'error'
                new_device.device_status['alive'] = False
                new_device.device_status['error_messages']['_assess_device'] = str(ex)
            else:
                raise
        except Exception as ex:
            logging.error('Problem initiating device [%s]' % device_id, exc_info=True)
            if new_device:
                new_device.device_status['confirmed'] = False
                new_device.device_status['status'] = 'error'
                new_device.device_status['error_messages']['_assess_device'] = str(ex)
            else:
                raise

        if new_device:
            new_device.device_status['last_assess_time'] = time.time()
        return new_device

    def _is_emulated(self, device):
        if not isinstance(device, aam_sms.AAMulator):
            if not isinstance(device, aam_pos.AAMulator):
                return False
        return True

    def _replace_device(self, device_uuid, new_device_instance):
        device = self.devices[device_uuid]
        if device and not self._is_emulated(device):
            new_device_instance.messages = device.messages
            new_device_instance.message_list = device.message_list
            if not new_device_instance.first_sync:
                new_device_instance.first_sync = device.first_sync
                device.cycle_action_handler = True
                self._action(device.shutdown)
                device._cleanup(device)
                del self.devices[device_uuid]
            self.devices[device_uuid] = new_device_instance
            ignored_snmp_device_types = SNMP_IGNORE_LIST.get(new_device_instance.device_configuration['category'], [])
            new_device_instance and new_device_instance.device_configuration['type'] not in ignored_snmp_device_types and cherrypy.engine.publish('device_update', new_device_instance)
        new_device_instance.activate(True)

    @db.close_session
    def initialize_devices(self):
        """
        Adds devices to theatre core from the db. Device are defined by the dictionary
        structures appropriate for the device type:

        screens :
        {
            'screen_uuid:
                    { 'id',
                      'identifier'
                      'title'
                      'three_d'
                      'hi'
                      'vi'
                      'cc'
                      'audio'
                      'audio_priority'
                      'screen_type_uuid'
                      'screen_type'
                      'devices':[device_id]}
        }

        devices:
        {
            'device id': {
                'ftp_ip': 'X.X.X.X', 'ftp_password': 'password', 'ftp_port': 21,
                'ftp_username': 'user', 'ip': 'X.X.X.X', 'live_stream_url': '',
                'type': 'Doremi v1.x.x', 'number': 1, 'enabled': True, 'port': 11730
            }
        }
        """
        try:
            self.purge_unauthorised_servers()
            self.screens = self.configuration_service.screen()
            screen_meta = {}
            for screen_uuid in self.screens:
                screen_meta[screen_uuid] = self.screens[screen_uuid]['last_modified']

            cherrypy.engine.publish('ccpush', 'screen_uuid_dict', {'screen_uuid_dict': screen_meta})
            devices = self.configuration_service.device()
            if cfg.lms_custom_ftp_enabled():
                self.resync_ftp_server()
            db.Session.query(db.Transfer).filter(not_(db.Transfer.destination_device_uuid.in_(devices.keys()))).delete(False)
            db.Session.commit()
            for device_id in devices.keys():
                try:
                    self.devices[device_id] = self._create_device(device_id, devices[device_id])
                except ValueError as e:
                    logging.error(e)
                    del devices[device_id]

            for device_id in devices:
                if self.devices[device_id]:
                    if not cfg.core_log_collection_only():
                        time.sleep(0.5)
                        device_state_monitor = DeviceMonitor(cherrypy.engine, self.device_state_monitor, self.monitor_frequency, 'State Manager Device %s' % device_id, device_id)
                        device_state_monitor.subscribe()
                        device_state_monitor.start()
                        device_acion_monitor = DeviceMonitor(cherrypy.engine, self.device_action_queue_handler, ACTION_MANAGER_CYCLE, 'Action Manager Device %s' % device_id, device_id)
                        device_acion_monitor.subscribe()
                        device_acion_monitor.start()
                else:
                    del self.devices[device_id]

            cherrypy.engine.publish('device_load')
            if cfg.lms_custom_ftp_enabled():
                self.resync_ftp_server()
            cherrypy.engine.publish('ccpush', 'screen_uuid_dict', {'screen_uuid_dict': screen_meta})
        except Exception:
            logging.error('Error initializing the screens/devices', exc_info=True)
            raise

    def get_devices(self, device_ids = [], required_api = object, enabled_only = True, exclusions = []):
        output_device_ids = []
        output_errors = {'messages': []}
        if device_ids:
            for device_id in device_ids:
                try:
                    device = self.devices[device_id]
                    if not self._is_excluded(device, exclusions):
                        if self._is_supported(device, required_api):
                            if self._is_enabled_if_required(device, enabled_only):
                                output_device_ids.append(device_id)
                except KeyError:
                    output_errors['messages'].append({'type': 'error',
                     'device_id': device_id,
                     'message': 'Device [%s] does not exist' % device_id})

        else:
            output_device_ids = self._get_supported_device_ids(required_api, enabled_only, exclusions)
        for message in output_errors.get('messages', []):
            logging.error(message['message'])

        return (output_device_ids, output_errors)

    def _get_supported_device_ids(self, required_api, enabled_only, exclusions):
        devices = []
        for device_uuid in self.devices.keys():
            device = self.devices[device_uuid]
            if not self._is_excluded(device, exclusions):
                if self._is_supported(device, required_api):
                    if self._is_enabled_if_required(device, enabled_only):
                        devices.append(device_uuid)

        return devices

    def _is_excluded(self, device, exclusions):
        for device_type in exclusions:
            if isinstance(device, device_type):
                return True

        return False

    def _is_enabled_if_required(self, device, enabled_only):
        return enabled_only and device.device_configuration['enabled'] or not enabled_only

    def _is_supported(self, device, required_api):
        return isinstance(device, required_api)

    def device_state_monitor(self, device_id):
        try:
            if self.devices[device_id].device_configuration['enabled'] and not self.devices[device_id].device_status['confirmed']:
                if self.devices[device_id].ready_to_check():
                    assessed_device = self._assess_device(device_id, self.devices[device_id].device_configuration)
                    if assessed_device.device_status['confirmed'] or assessed_device.device_configuration['category'] in ('projector', 'camera'):
                        self._replace_device(device_id, assessed_device)
            if self.devices[device_id].device_configuration['enabled'] and self.devices[device_id].device_status['confirmed']:
                sync_content = self.content_devices_syncing < cfg.core_content_sync_limit.get() and not self.schedule_synchroniser.syncing
                self.devices[device_id].monitor_device_state(sync_content)
                self.devices[device_id].initial_sync_complete = True
        except Exception:
            logging.error('Problem in device_state_monitor Manager [%s]', device_id, exc_info=True)

    def device_action_queue_handler(self, device_id):
        try:
            self.devices[device_id].handle_action_queue()
        except Exception:
            logging.error('Problem in device_action_queue_handler Manager [%s]', device_id, exc_info=True)

    def resolve_auto_source(self, content_id, destination_device_id):
        dest_transfer_methods = set(self.devices[destination_device_id].transfer_methods())
        device_keys, device_errors = self.get_devices([], base_content.Content, exclusions=[watchfolder.Watchfolder])
        lms_id = self.get_lms_id()
        if lms_id in self.devices and self.devices[lms_id].device_status['confirmed'] and self.contents.valid_on_device(content_id, lms_id) and dest_transfer_methods & set(self.devices[lms_id].transfer_methods()) and destination_device_id != lms_id:
            return (True, lms_id)
        random.shuffle(device_keys)
        for device_key in device_keys:
            device = self.devices[device_key]
            if isinstance(device, logical_drive.LogicalDrive) and device.device_status['confirmed'] and self.contents.valid_on_device(content_id, device_key) and dest_transfer_methods & set(device.transfer_methods()) and destination_device_id != device_key:
                return (True, device_key)

        for device_key in device_keys:
            if not isinstance(self.devices[device_key], base_mount_point.MountPoint) and self.devices[device_key].content_information and self.devices[device_key].device_status['confirmed'] and self.contents.valid_on_device(content_id, device_key) and dest_transfer_methods & set(self.devices[device_key].transfer_methods()) and destination_device_id != device_key:
                return (True, device_key)

        for device_key in device_keys:
            if isinstance(self.devices[device_key], base_mount_point.MountPoint) and self.devices[device_key].content_information and self.devices[device_key].device_status['confirmed'] and self.contents.valid_on_device(content_id, device_key) and dest_transfer_methods & set(self.devices[device_key].transfer_methods()) and destination_device_id != device_key:
                return (True, device_key)
        else:
            logging.info('Unable to find suitable source for transfer of content [%s] to device [%s].' % (content_id, destination_device_id))
            return (False, '')

    def _thread_status(self):
        code = []
        threads = {}
        for thread in threading.enumerate():
            threads[thread._Thread__ident] = thread

        for threadId, stack in sys._current_frames().items():
            thread_name = 'unknown'
            if threadId in threads:
                thread_name = threads[threadId]._Thread__name
            trace = [thread_name]
            for filename, lineno, name, line in traceback.extract_stack(stack):
                x = '"%s": %d >> %s >> %s' % (filename,
                 lineno,
                 name,
                 line)
                trace.append(x)

            code.append(trace)

        code.sort(key=lambda trace: trace[0])
        return code

    @db.close_session
    def start_transfers(self):
        device_ids, errors = self.get_devices(required_api=base_content.Content)
        now = time.time()
        for device_id in device_ids:
            if not self.devices[device_id].transfer_initial_sync:
                continue
            if device_id == self.get_lms_id() and self.devices[device_id].sync_status['content_scan_active']:
                continue
            if hasattr(self.devices[device_id], 'last_transfer_action_id'):
                if self.devices[device_id].messages.has_key(self.devices[device_id].last_transfer_action_id):
                    del self.devices[device_id].messages[self.devices[device_id].last_transfer_action_id]
                    delattr(self.devices[device_id], 'last_transfer_action_id')
                else:
                    continue
            if self.devices[device_id].transfer_information['queue']:
                dest_device = self.devices[device_id]
                device_ready_for_kdms = dest_device.ready_for_kdm_transfer()
                queue = dest_device.transfer_information['queue'][:]
                for transfer_request in queue:
                    try:
                        if transfer_request['type'] != 'KDM':
                            if transfer_request['not_before'] and float(transfer_request['not_before']) > now:
                                continue
                            source = transfer_request['source']
                            if source == 'Auto':
                                success, source = self.resolve_auto_source(transfer_request['content_id'], device_id)
                                if not success:
                                    source = None
                            if source == self.get_lms_id() and self.devices[source].sync_status['content_scan_active']:
                                continue
                            if not dest_device.device_status['alive']:
                                logging.error('Could not start transfer, destination device unreachable [%s]' % transfer_request['id'])
                                continue
                            if dest_device.ready_for_transfer(source):
                                if transfer_request['source'] != source:
                                    transfer_request['source'] = source
                                    db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_request['id']).one().source = source
                                    db.Session.commit()
                            else:
                                continue
                            logging.debug('Transfer Manager starting transfer:\n' + str(transfer_request))
                            self._start_transfer(device_id, transfer_request)
                            break
                        elif transfer_request['type'] == 'KDM' and device_ready_for_kdms:
                            logging.debug('Transfer Manager starting transfer:\n' + str(transfer_request))
                            dest_device.content_add_key_helper(transfer_request)
                    except:
                        logging.error('Error starting transfer [%s]' % transfer_request['id'], exc_info=True)

        return

    def _start_transfer(self, destination_device_id, transfer_request):
        dest_device = self.devices[destination_device_id]
        if transfer_request['source'] == 'Auto':
            success, auto_source = self.resolve_auto_source(transfer_request['content_id'], destination_device_id)
            if success:
                transfer_request['source'] = auto_source
                db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_request['id']).one().source = auto_source
                db.Session.commit()
            else:
                transfer_request['source'] = None
            logging.info('Resolved auto source for transfer [%s] of [%s] as [%s]' % (transfer_request['id'], transfer_request['content_id'], str(transfer_request['source'])))
        connection_details = {}
        content_validation_info = None
        if self.devices.has_key(transfer_request['source']) and self.contents.content_on_device(transfer_request['content_id'], transfer_request['source']):
            source_device = self.devices[transfer_request['source']]
            source_type = source_device.device_configuration['type']
            content_validation_info = source_device.get_content_validation_information([transfer_request['content_id']])
            if content_validation_info['content_validation_dict'].has_key(transfer_request['content_id']):
                content_validation_info = content_validation_info['content_validation_dict'][transfer_request['content_id']]
            else:
                content_validation_info = None
            if 'local' in source_device.transfer_methods() and 'local' in dest_device.transfer_methods():
                ingest_path = self.devices[transfer_request['source']].get_ingest_path(transfer_request['content_id'])
                connection_details = {'type': 'local',
                 'ingest_source_type': source_type,
                 'ingest_path': ingest_path}
            elif 'ftp' in source_device.transfer_methods() and 'ftp' in dest_device.transfer_methods():
                if cfg.lms_custom_ftp_enabled() and isinstance(source_device, logical_drive.LogicalDrive):
                    ingest_path = self.contents.get_ingest_path(transfer_request['content_id'], transfer_request['source'])
                    norm_ingest_path = os.path.normpath(ingest_path)
                    norm_case_ingest_path = os.path.normcase(norm_ingest_path)
                    ordered_fs = sorted(cherrypy.ftp_fs.items(), key=lambda x: len(x[0]), reverse=True)
                    for device_uuid, device_path in ordered_fs:
                        norm_device_path = os.path.normcase(os.path.normpath(device_path))
                        if norm_case_ingest_path.startswith(norm_device_path):
                            remainder_ingest_path = norm_ingest_path[len(norm_device_path):]
                            if norm_device_path.endswith(os.path.sep):
                                norm_ingest_path = device_uuid + os.path.sep + remainder_ingest_path
                            elif remainder_ingest_path.startswith(os.path.sep) or remainder_ingest_path == '':
                                norm_ingest_path = device_uuid + remainder_ingest_path
                            else:
                                continue
                            ingest_path = norm_ingest_path.replace(os.path.sep, '/')
                            if not ingest_path.startswith('/'):
                                ingest_path = '/' + ingest_path
                            break

                else:
                    ingest_path = self.contents.get_ingest_path(transfer_request['content_id'], transfer_request['source'])
                connection_details = {'type': 'ftp',
                 'ingest_path': ingest_path,
                 'ingest_source_type': source_type,
                 'ftp_ip': source_device.device_configuration['ftp_ip'],
                 'ftp_port': source_device.device_configuration['ftp_port'],
                 'ftp_username': source_device.device_configuration['ftp_username'],
                 'ftp_password': source_device.device_configuration['ftp_password']}
            else:
                connection_details['ingest_path'] = None
        else:
            connection_details['ingest_path'] = None
        dest_device.last_transfer_action_id = self._action(dest_device.transfer_helper, transfer_request, connection_details, content_validation_info)
        return

    # auto_transfer decoded failed here
    def auto_transfer(self):


    def email_handler(self):
        email_protocol = cfg.email_protocol()
        list_of_emails = []
        if cfg.kdm_email_enabled() and cfg.email_server() != '' and cfg.email_username() != '' and cfg.email_password() != '':
            try:
                SSL = False
                if 'SSL' in email_protocol:
                    SSL = True
                if 'POP' in email_protocol:
                    email_checker = email_pop(cfg.email_server(), cfg.email_username(), cfg.email_password(), SSL)
                elif 'IMAP' in email_protocol:
                    email_checker = email_imap(cfg.email_server(), cfg.email_username(), cfg.email_password(), SSL)
                list_of_emails = email_checker.check_for_mail(self.kdm_email_read_uidls)
                self.kdm_email_status = email_checker.valid_details
            except Exception:
                logging.error('Problem retrieving email list from [%s:%s@%s]' % (cfg.email_username(), cfg.email_password(), cfg.email_server()), exc_info=True)

            for email in list_of_emails:
                self.kdm_email_read_uidls.append(email['UIDL'])
                for attachment_dict in email['attachment(s)']:
                    try:
                        unparsed_kdm = attachment_dict['attachment_text']
                        add_key_messages = self.content_service.add_key(unparsed_kdm)
                        kdm = parse_kdm(unparsed_kdm, load_from_file=False)
                        if kdm != {}:
                            cpl_name = kdm['cpl_text']
                            kdm_id = kdm['id']
                            self.kdm_email_history.append({'messages': add_key_messages,
                             'cpl_name': cpl_name,
                             'kdm_id': kdm_id})
                    except Exception:
                        logging.error('Problem passing kdm from email to screen server [%s]' % str(attachment_dict.get('filename')), exc_info=True)

    def image_getter(self):
        device_uuids, errors = self.get_devices(required_api=base_camera.Camera)
        for device_uuid in device_uuids:
            device = self.devices[device_uuid]
            if not device.device_status['alive'] or not device.device_configuration['active_image_pull']:
                continue
            try:
                device.store_internal_image()
            except Exception:
                logging.error('Error pulling image for camera [%s]' % device_uuid, exc_info=True)

    def get_lms_id(self):
        if cfg.lms_uuid() != '':
            return cfg.lms_uuid()
        else:
            return None

    def get_pretty_name(self, device_id):
        try:
            device = self.devices[device_id]
        except KeyError as e:
            logging.error('get_pretty_name failed to look up device, returning uuid')
            return device_id

        if device.device_configuration['category'] in ('sms', 'projector', 'camera'):
            return self.screens[device.device_configuration['screen_uuid']]['identifier']
        elif device.device_configuration['category'] == 'lms':
            return 'LMS'
        elif device.device_configuration['category'] == 'pos':
            return device.device_configuration['type'].lower().capitalize() + ' - ' + device.device_configuration['ip']
        elif device.device_configuration.get('name', None):
            return device.device_configuration['name']
        else:
            return '%s - %s' % (device.device_configuration['category'], device_id)
            return

    def process_schedule_sync_queue(self):
        """ Wait for pack uuids to be pushed to the DCP queue and then process them """
        lms = self.devices[self.get_lms_id()]
        while not cherrypy.engine.shutdown_servers:
            self.schedule_sync_queue.get(True)
            if not lms.content_ready():
                self.schedule_synchroniser.wait()
                time.sleep(5)
                self.queue_schedule_sync()
            elif cfg.marker_clip_templating() or time.time() - self.schedule_synchroniser.last_sync > 2:
                self.schedule_synchroniser.sync()
            self.schedule_sync_queue.task_done()

    def process_DCPs(self):
        """ Wait for pack uuids or device uuids to be pushed to the DCP queue and then process them """
        while not cherrypy.engine.shutdown_servers:
            pack_uuids = self.dcp_queue.get(True)
            logging.info('Building Composite DCPs for %s pack(s)' % str(len(pack_uuids)))
            lms = self.devices[self.get_lms_id()]
            lms.content_store_lock.acquire()
            try:
                for pack_uuid in pack_uuids:
                    self.content_service.pack_to_composite_CPL(pack_uuid)

                self.dcp_queue.task_done()
            finally:
                lms.content_store_lock.release()

    def _load_monitoring_types(self):
        from serv.core.websockets.shared.constants import CRITICAL_MONITORING_TYPES, DEFAULT_MONITORING_TYPES
        monitoring_types = db.Session.query(db.MonitoringType.name, db.MonitoringType.type)
        self.monitoring_types = dict(monitoring_types)
        for monitoring_type in DEFAULT_MONITORING_TYPES:
            name = monitoring_type['name']
            mtype = monitoring_type['type']
            self.monitoring_types[name] = mtype

        self.critical_monitoring_types = set(CRITICAL_MONITORING_TYPES)

    def emulate(self, count = 8):
        """
        Create aamulator complex
        """
        try:
            start_index = int(max([ screen['identifier'] for id, screen in self.screens.iteritems() ])) + 1 if self.screens else 1
        except ValueError:
            start_index = 1

        for index in range(start_index, start_index + count):
            port = int(cfg.cherry_port.get()) + index
            screen_uuid = str(uuid.uuid4())
            self.configuration.save_screen([{'uuid': screen_uuid,
              'identifier': str(index),
              'title': str(index),
              'capabilities': []}])
            self.configuration.save_device({'type': 'aam',
             'category': 'sms',
             'ip': cfg.cherry_host.get(),
             'port': port,
             'enabled': True,
             'screen_uuid': screen_uuid})
            self.configuration.save_device({'type': 'aam',
             'category': 'projector',
             'ip': cfg.cherry_host.get(),
             'port': port,
             'enabled': True,
             'screen_uuid': screen_uuid})

        self.configuration.save_device({'type': 'emulator',
         'category': 'pos',
         'ip': cfg.cherry_host.get(),
         'port': int(cfg.cherry_port.get()) - 1,
         'enabled': True})

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def run_marker_clip_templating(self, force = False):
        return self.marker_clip_processor.run(force)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out()
    def query_stats(self, sEcho = 0, iDisplayStart = 0, iDisplayLength = 0, iSortingCols = 0, sSearch = None, **kwargs):
        aaData = []
        for stmt in self.db_query_stats.itervalues():
            stmt['average'] = stmt['time'] / stmt['count']
            aaData.append(stmt)

        key = ''
        sort_no = int(iSortingCols)
        for i in range(sort_no):
            col = int(kwargs['iSortCol_%d' % i])
            if col == 1:
                key = 'count'
            elif col == 2:
                key = 'average'
            elif col == 3:
                key = 'time'

        aaData = sorted(aaData, key=lambda k: k[key], reverse=True)
        return {'sEcho': int(sEcho),
         'iTotalRecords': 0,
         'iDisplayStart': iDisplayStart,
         'iDisplayLength': iDisplayLength,
         'iTotalDisplayRecords': 0,
         'aaData': aaData}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def device_metadata(self):
        return {'data': {'screen_device_metadata': self.screen_device_metadata,
                  'complex_device_metadata': self.complex_device_metadata},
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def test_ready(self, device_uuids = []):
        """
        Determine whether the system is ready to be tested.
        """
        if not db.Session.query(db.POSItem.start > datetime.now()).count():
            return 'POS'
        if not db.Session.query(db.ShowAttribute).count():
            return 'Show attributes'
        for key in device_uuids or self.devices.keys():
            if key not in self.devices:
                return 'Device %s not found' % key
            if not self.devices[key].device_status['confirmed']:
                return 'Device %s not confirmed' % key
            if not self.devices[key].device_configuration['enabled']:
                return 'Device %s not enabled' % key

        if self.devices[self.get_lms_id()].playlist_information.keys() == ['last_updated']:
            return 'Playlists'
        if self.contents == {}:
            return 'Content'
        return 'Ready'

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def generate_kdms(self):
        """
        Grab complex dnqualifiers
        Grab content info
        Generate a bunch of KDMs
        Dump them on the LMS
        Resync
        """
        from serv.lib.utilities import kdm_generator
        dnqualifiers = []
        for device_uuid in self.devices:
            try:
                dnqualifiers.append(self.devices[device_uuid].device_information['device_dnqualifier'])
            except KeyError:
                pass
            except AttributeError:
                pass

        content = {}
        for cpl_uuid, cpl in self.contents.iteritems():
            content[cpl_uuid] = cpl.get('content_title_text')

        lms = self.devices[self.get_lms_id()]
        dump_directory = lms.storage_configuration['kdm_folder']
        kdm_generator.generate(dnqualifiers, dump_directory, content)
        lms.sync_content_store()
        return {'messages': [{'type': 'success',
                       'message': _('Done')}]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def auto_configure(self, mode):
        """
        Auto configure complex, three modes:
        - test: 1 of each device with pre-defined uuids for integration testing
        - demo: 1 of each complex device and an array of emulated projectors + servers for demoing
        - dev: 1 of each complex device and all of the test devices in the lab for developing against
        """
        macs = get_macs()
        if mode == 'demo':
            metadata = json.loads(open(os.path.join(app_dir, 'configuration', 'demo_device_metadata.json'), 'r').read())
        elif mode == 'dev':
            metadata = json.loads(open(os.path.join(app_dir, 'configuration', 'development_device_metadata.json'), 'r').read())
        elif mode == 'test':
            metadata = json.loads(open(os.path.join(app_dir, 'configuration', 'test_device_metadata.json'), 'r').read())
        elif mode == 'sandbox':
            metadata = json.loads(open(os.path.join(app_dir, 'configuration', 'sandbox_device_metadata.json'), 'r').read())
            if macs:
                self.validate_device_uuids(metadata, macs)
        devices_used = []
        messages = {}
        for screen in metadata.get('screens', []):
            _screen = {'identifier': screen['identifier'],
             'title': screen['title'],
             'capabilities': screen.get('capabilities', [])}
            _screen['uuid'] = create_screen_or_device_uuid(screen, macs)
            if _screen['uuid'] not in self.screens:
                self.configuration_service.save_screen([_screen])
            for device in screen['devices']:
                device['screen_uuid'] = _screen['uuid']
                device['uuid'] = create_screen_or_device_uuid(device, macs)
                devices_used.append(device['uuid'])
                if device['uuid'] not in self.devices:
                    messages[device['uuid']] = self.configuration_service.save_device(device)

        for complex_device in metadata.get('complex_devices', []):
            complex_device['uuid'] = create_screen_or_device_uuid(complex_device, macs)
            m = None
            if complex_device['uuid'] not in self.devices:
                if 'platform' in complex_device:
                    if WIN32 and complex_device['platform'] == 'win':
                        m = self.configuration_service.save_device(complex_device)
                    elif not WIN32 and complex_device['platform'] == 'linux':
                        m = self.configuration_service.save_device(complex_device)
                else:
                    m = self.configuration_service.save_device(complex_device)
                if m:
                    messages[complex_device['uuid']] = m
                    devices_used.append(complex_device['uuid'])
            else:
                devices_used.append(complex_device['uuid'])

        return {'messages': [{'type': 'success',
                       'message': _('Done')}],
         'data': {'device_uuids': devices_used,
                  'issues': messages}}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def execute(self, code):
        output = {'data': {},
         'messages': []}
        import sys
        from StringIO import StringIO
        buffer = StringIO()
        sys.stdout = buffer
        exec str(code)
        sys.stdout = sys.__stdout__
        stdout = buffer.getvalue()
        output['messages'].append({'type': 'success',
         'message': str(stdout)})
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def introspect(self, eval_string):
        output = {'data': {},
         'messages': []}
        eval_string = str(eval_string)
        try:
            database = None
            if eval_string.startswith('db '):
                database = db
            elif eval_string.startswith('pdb '):
                database = playback_db
            elif eval_string.startswith('adb '):
                database = audit_db
            if database:
                result = database.Session.execute(eval_string[3:] if database == db else eval_string[4:])
                if 'select ' in eval_string.lower():
                    response = str(result.fetchall())
                else:
                    response = 'Committed %s rows' % result.rowcount
                    database.Session.commit()
            else:
                response = str(eval(eval_string))
            output['messages'].append({'type': 'success',
             'message': response})
        except Exception as ex:
            output['messages'].append({'type': 'error',
             'message': str(ex)})

        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_db_schema(self):
        """
        Get column names of every table of all three DBs
        :returns dict: nested data of above in 'schema',
            sorted model names in 'models'
        """
        schema = {}
        models = {}
        for _db in [db, playback_db, audit_db]:
            db_name = _db.__package__.split('.')[-1]
            sqlalc_models = [ n for n, o in inspect.getmembers(_db) if inspect.isclass(o) and _db.Base in inspect.getmro(o) and n != 'Base' ]
            schema[db_name] = {}
            sqlalc_models.sort()
            models[db_name] = sqlalc_models
            for tbl_name in sqlalc_models:
                columns = getattr(_db, tbl_name).__table__.columns.keys()
                schema[db_name][tbl_name] = [ col for col in columns ]

        return {'schema': schema,
         'models': models}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def introspect_dir(self, eval_string):
        output = {'data': {'options': []},
         'messages': []}
        try:
            output['data']['type'] = str(type(eval(eval_string)))
            options = dir(eval(eval_string))
            for option in options:
                output['data']['options'].append({'type': str(type(option)),
                 'str': str(option)})

        except Exception:
            output['messages'].append({'type': 'error',
             'message': 'Ooops - contact Darth Vader'})

        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def uptime(self):
        """
        Time the server has been up for

        @return json DICT
        """
        return {'data': {'uptime': time.time() - self.start_time},
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_mac_addresses(self):
        """
        Return Mac Addresses

        @return json DICT
        """
        return {'data': {'macs': get_macs()},
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_time(self):
        """
        Call to get the time details of the Core2 server

        @return json DICT
        {
            time FLOAT : POSIX timestamp of the server's current time
            tz STRING : server's timezone name e.g. 'Europe/London'
        }
        """
        timezone = cfg.timezone()
        if not timezone:
            raise Exception('TMS timezone has not been configured')
        t = time.time()
        if time.localtime(t).tm_isdst and time.daylight:
            timezone_offset_seconds = time.altzone
        else:
            timezone_offset_seconds = time.timezone
        return {'data': {'time': t,
                  'tz': timezone,
                  'timezone_offset_seconds': timezone_offset_seconds,
                  'local_time': date_utils.posix_to_local_datetime(time.time(), cfg.timezone()).strftime('%Y-%m-%d %H:%M:%S')},
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out()
    @cherrypy_peformance_log
    def get_version(self):
        return {'data': dict(VERSION, string=self.version_string),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def complex(self):
        """
        Returns real-time complex information.
        This call should return only in-memory data and only data that we absolutely need in real time, eg. server time.
        This call shouldn't touch the DB or the file system as it's called from each active browser tab every 1500 ms.

        @return                    json DICT
        """
        data = {'status': {},
         'audio': {},
         'playback': {},
         'projection': {}}
        for device_uuid in self.devices.keys():
            device = self.devices[device_uuid]
            status = device.device_status
            data['status'][device_uuid] = {'status': status.get('status'),
             'current_time': status.get('current_time'),
             'confirmed': status.get('confirmed'),
             'last_assess_time': status.get('last_assess_time'),
             'alive': status.get('alive'),
             'error_messages': status.get('error_messages', []),
             'serial': status.get('serial'),
             'last_updated': status.last_updated}
            if isinstance(device, AudioController):
                data['audio'][device_uuid] = device.get_audio_status()
            if isinstance(device, Playback):
                data['playback'][device_uuid] = self.playback_service.playback_status(device_uuid)
            if isinstance(device, Projection):
                data['projection'][device_uuid] = device.device_get_projection_status()

        data['pos'] = self.pos_service.status()
        servers_purged = self.servers_purged
        self.servers_purged = 0
        data['servers_purged'] = servers_purged
        data['kdm_email_status'] = self.kdm_email_status
        data['kdm_email_history'] = list(self.kdm_email_history)
        data['sched_sync'] = self.schedule_synchroniser.syncing
        data['sched_sync_stamp'] = self.schedule_synchroniser.last_sync
        data['ftp_server_running'] = self.ftp_server_running
        return {'data': data,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def device_infos(self):
        """
        Returns device specific information
        Period for this call is less frequent than the complex call as the data is less likely to change, eg. serial number

        @return                    json DICT
        """
        devices = {}
        for key in self.devices.keys():
            device = self.devices[key]
            devices[key] = device.device_configuration
            if isinstance(device, base_content.Content):
                devices[key] = dict(devices[key], **device.sync_status)
                devices[key]['transfer_methods'] = device.transfer_methods()
                devices[key]['initial_sync_complete'] = device.initial_sync_complete
            cache = device.device_information
            devices[key]['device_information'] = {'id': cache.get('id'),
             'serial': cache.get('serial'),
             'model': cache.get('model'),
             'software_version': cache.get('software_version'),
             'firmware_version': cache.get('firmware_version'),
             'ftp_ip_address': cache.get('ftp_ip_address'),
             'disk_usage': {'total_size': cache.get('storage_total'),
                            'available': cache.get('storage_available'),
                            'used': cache.get('storage_used')},
             'raid_status': cache.get('raid_status', []),
             'dnqualifiers': cache.get('dnqualifiers', []),
             'product_certificates': cache.get('product_certificates', []),
             'product_id': cache.get('product_id'),
             'error_messages': cache.get('error_messages', []),
             'last_updated': cache.last_updated}
            if 'inputs' in cache:
                devices[key]['device_information']['inputs'] = cache['inputs']

        return {'data': {'devices': devices,
                  'screens': self.screens},
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def complex_infos(self):
        """
        Returns complex information that we don't need in real-time, eg. version number.
        Period for this call is less frequent than the complex call as the data is less likely to change.

        @return                    json DICT        """
        license_expiry_timestamp = cherrypy.aam_auth.license_expires
        servers_purged = copy(self.servers_purged)
        self.servers_purged = 0
        return {'data': {'version': self.version_string,
                  'name': cfg.complex_name(),
                  'timezone': cfg.timezone(),
                  'country_code': cfg.country(),
                  'audio_lang': cfg.audio_language(),
                  'sub_lang': cfg.subtitle_language(),
                  'license_expiry': license_expiry_timestamp,
                  'allow_server_reboot': cfg.core_allow_server_reboot(),
                  'allow_sync_page': cfg.core_allow_sync_page(),
                  'allow_auto': cfg.core_allow_auto(),
                  'license_agreement_accepted': cfg.license_agreement_accepted(),
                  'password_change_reminder_displayed': cfg.password_change_reminder_displayed(),
                  'language': str(cherrypy.response.i18n.locale),
                  'territories': TERRITORIES,
                  'kdm_email_enabled': cfg.kdm_email_enabled.get(),
                  'kdm_email_status': self.kdm_email_status,
                  'kdm_email_history': list(self.kdm_email_history),
                  'ftp_server_running': self.ftp_server_running,
                  'servers_purged': servers_purged,
                  'flm_complex_id': cfg.flm_complex_id(),
                  'lamp_threshold_unit': cfg.lamp_threshold_unit(),
                  'lamp_yellow_threshold': cfg.lamp_yellow_threshold(),
                  'lamp_red_threshold': cfg.lamp_red_threshold(),
                  'disk_yellow_threshold': cfg.disk_yellow_threshold(),
                  'disk_red_threshold': cfg.disk_red_threshold(),
                  'log_collection_only': cfg.core_log_collection_only()},
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def exception_info(self):
        output = {'data': {},
         'messages': []}
        output['data']['exceptions'] = list(self.exception_cache)
        output['data']['exceptions'].sort(key=lambda x: x['stamp'])
        output['data']['exceptions'].reverse()
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def performance_info(self):
        output = copy(self.top_summary)
        if output:
            output['processes'] = []
            for pid in self.top_summary.get('processes', {}):
                process = copy(self.top_summary['processes'][pid])
                process['pid'] = str(pid)
                process['mem'] = list(process['mem'])
                process['cpu'] = list(process['cpu'])
                process['overhead'] = sum([ mem['value'] for mem in process['mem'] ]) + sum([ cpu['value'] for cpu in process['cpu'] ])
                output['processes'].append(process)

            output['processes'] = sorted(output['processes'], key=lambda p: p['overhead'], reverse=True)
        return {'data': output,
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def api_performance_info(self):
        output = {'data': {'api_performance': [],
                  'api_response_sizes': []},
         'messages': []}

        def __precise_float(imprecise_float):
            return float('{0:.2f}'.format(imprecise_float))

        def _get_stats(cache, k):
            for api_call, performance in cache.iteritems():
                recent = performance['recent']
                if len(recent):
                    output['data'][k].append({'api_call': api_call,
                     'average': __precise_float(performance['total'] / performance['count']),
                     'last': recent[-1],
                     'worst': performance['worst'],
                     'count': performance['count'],
                     'total': int(performance['total'])})

            output['data'][k].sort(key=lambda x: x['average'], reverse=True)

        _get_stats(self.api_call_size_cache, 'api_response_sizes')
        _get_stats(self.performance_cache, 'api_performance')
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def lms_resync(self):
        return {'data': {},
         'messages': [{'type': 'action',
                       'action_id': self.devices[self.get_lms_id()].sync_content_store(),
                       'message': _('Resync started')}]}# decompiled 0 files: 0 okay, 1 failed, 0 verify failed
# 2017.08.13 21:48:21 CST
