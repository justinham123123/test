# 2017.08.13 21:50:57 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\title_service.py
from datetime import datetime
import logging
import uuid
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.constants import TERRITORIES
from serv.lib.utilities.helper_methods import audit_log, sqlite_chunk
from serv.core.services.base_service import Service
from serv.configuration import cfg
from serv.configuration.constants import POS_DEVICE_TYPES, HFR_FPS
from serv.storage.database.primary import database as db
from sqlalchemy.orm import subqueryload
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_, or_
import cherrypy
import json

class TitleService(Service):

    def save(self, title, from_producer = False):
        """
        Creates/updates a title using the supplied data
        """
        try:
            db_title = None
            title_uuid = title.get('uuid')
            if title_uuid:
                db_title = db.Session.query(db.Title).get(title_uuid)
            if not db_title:
                db_title = db.Title()
                if title_uuid:
                    db_title.uuid = title_uuid
                db.Session.add(db_title)
            db_title.name = title['name']
            db_title.credits_offset = title.get('credits_offset')
            db_title.year = title.get('year') or str(datetime.now().year)
            db.Session.query(db.TitleRatingMap).filter(db.TitleRatingMap.title_uuid == db_title.uuid).delete(synchronize_session='fetch')
            for rating in title.get('ratings', []):
                db_rating_map = db.TitleRatingMap()
                db_rating_map.title_uuid = db_title.uuid
                db_rating_map.territory = rating['territory']
                db_rating_map.rating = rating['rating']
                db.Session.add(db_rating_map)

            new_cpls = title.get('cpls', [])
            for cpl_map in db_title.title_cpl_maps:
                if cpl_map.cpl_uuid not in new_cpls:
                    db.Session.delete(cpl_map)

            already_mapped_cpls = [ cpl for cpl, in db.Session.query(db.TitleCplMap.cpl_uuid).filter(db.TitleCplMap.cpl_uuid.in_(new_cpls)) ]
            cpls_to_add = set(new_cpls) - set(already_mapped_cpls)
            for cpl_uuid in cpls_to_add:
                db_title.title_cpl_maps.append(db.TitleCplMap(cpl_uuid=cpl_uuid))

            local = []
            for ext_id in db_title.external_ids:
                local.append((ext_id.source, ext_id.external_id))

            local = [ (x.source, x.external_id) for x in db_title.external_ids ]
            remote = [ (x['source'], x['external_id']) for x in title['external_titles'] ]
            etm_to_delete = set(local) - set(remote)
            for etm in etm_to_delete:
                if etm[0] != 'AAM':
                    self.unmatch_external_title(etm[0], etm[1], title_uuid)

            for external_title in title['external_titles']:
                try:
                    ext_title_map = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.source == external_title['source'], db.ExternalTitleMap.external_id == external_title['external_id'])).one()
                    if from_producer:
                        ext_title_map.producer_last_modified = title.get('last_modified')
                    db_title.external_ids.append(ext_title_map)
                except NoResultFound:
                    db_title.external_ids.append(db.ExternalTitleMap(external_id=external_title['external_id'], source=external_title['source'], name=external_title['name'] if external_title.has_key('name') else external_title['external_id'], producer_last_modified=title.get('last_modified') if from_producer else None))

            try:
                aam_title_map = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.source == 'AAM', db.ExternalTitleMap.external_id == db_title.uuid)).one()
                if from_producer:
                    aam_title_map.producer_last_modified = title.get('last_modified')
            except NoResultFound:
                db.Session.add(db.ExternalTitleMap(source='AAM', external_id=db_title.uuid, title_uuid=db_title.uuid, name=title['name'], producer_last_modified=title.get('last_modified') if from_producer else None))

            db_title.set_modified(title.get('last_modified', None) if from_producer else None, from_producer)
            db.Session.commit()
            audit_log('Title saved: {title:title}', meta={'title': title}, tags=['title', 'save'])
        except:
            logging.error('unknown error saving title', exc_info=True)
            db.Session.rollback()
            raise

        return (db_title.uuid, {'type': 'success',
          'message': _('Saved: %s') % db_title.name})

    def save_multiple(self, title_list):
        messages = []
        uuids = []
        if title_list:
            for title in title_list:
                uuid, message = self.save(title)
                messages.append(message)
                uuids.append(uuid)

        return (messages, uuids)

    def last_modified(self):
        """
        Returns a list of all title last_modified timestamps stored on this core
        """
        titles = db.Session.query(db.Title)
        return dict(((title.uuid, title.last_modified) for title in titles))

    def producer_last_modified(self):
        """
        Returns a list of producer last_modified timestamps for all AAM title maps
        """
        titles = db.Session.query(db.Title.uuid, db.ExternalTitleMap.producer_last_modified).join('external_ids').filter(db.ExternalTitleMap.source == 'AAM')
        return dict(((title.uuid, title.producer_last_modified) for title in titles))

    def _is_cpl_compatible(self, cpl, capability):
        if capability['name'] == 'audio':
            compat, match = self.audio_match(cpl['audio_type'], capability['value'])
            return match
        else:
            if capability['name'] == 'cc':
                if cpl['subtitle_language'] is not None and cpl['subtitle_language'].lower() == 'cc' or cpl['content_title_text'].find('CCAP') != -1:
                    return True
            elif capability['name'] == 'hi':
                if cpl['narrative_description_language'] is not None and 'hi' in [ x.lower() for x in cpl['narrative_description_language'] ]:
                    return True
            elif capability['name'] == 'vi':
                if cpl['narrative_description_language'] is not None and 'vi' in [ x.lower() for x in cpl['narrative_description_language'] ]:
                    return True
            return False

    def audio_match(self, cpl_audio, screen_audio):

        def parse_int(cap):
            try:
                return (int(cap.replace('.', '')) if cap else 51, None)
            except ValueError:
                return (None, cap)

            return None

        screen_audio_number, screen_audio_string = parse_int(screen_audio)
        if cpl_audio == None:
            cpl_audio = ['51']
        all_cpl_audios_result = []
        for cpl_audio_type in cpl_audio:
            cpl_audio_number, cpl_audio_string = parse_int(cpl_audio_type)
            if screen_audio_string != None:
                if cpl_audio_string != None:
                    equal = screen_audio_string.lower() == cpl_audio_string.lower()
                    all_cpl_audios_result.append((equal, equal))
                elif cpl_audio_number != None:
                    all_cpl_audios_result.append((True, False))
            elif screen_audio_number != None:
                if cpl_audio_number != None:
                    all_cpl_audios_result.append((True, screen_audio_number == cpl_audio_number))
                else:
                    all_cpl_audios_result.append((False, False))

        compat = False
        match = False
        for result in all_cpl_audios_result:
            if result[0]:
                compat = True
            if result[1]:
                match = True

        return (compat, match)

    def get_title_uuid_for_cpl(self, playlist):
        """
        :param playlist:
        """
        title_uuid = None
        cpl_text = ''
        title_name = ''
        cpls = [ x for x in playlist['events'] if x['type'] == 'composition' ]
        cpl_uuids = [ x['cpl_id'] for x in cpls ]
        cpl_uuids_to_request = []
        titles = db.Session.query(db.Title).outerjoin(db.TitleCplMap).filter(db.TitleCplMap.cpl_uuid.in_(cpl_uuids))
        cpls.reverse()
        for cpl in cpls:
            cpl_uuid = cpl['cpl_id']
            if cpl.get('content_kind', 'unknown') == 'feature' or cpl.get('content_kind') is None and cpl.get('duration_in_seconds') > 1800:
                for title in titles:
                    if cpl_uuid in [ map.cpl_uuid for map in title.title_cpl_maps ]:
                        title_uuid = title.uuid
                        title_name = title.name
                        cpl_text = cpl['text']
                        break

                cpl_uuids_to_request.append(cpl_uuid)
            if title_uuid is not None:
                break

        if cpl_uuids_to_request:
            cherrypy.engine.publish('ccpush', 'cpl_titles', {'cpl_uuids': cpl_uuids_to_request,
             'titles_last_modified': None})
        return (title_uuid, title_name, cpl_text)

    def _match_title(self, title, show_attributes, screen):
        re = {'feature_cpl': None,
         'rating_cpl': None,
         'error_message': None,
         'warning_messages': []}
        not_enabled = []
        rating_cpls = []
        screen_attributes = screen['show_attributes']
        show_three_d = self.core.core_show_attributes['3D'] in show_attributes
        show_hoh = self.core.core_show_attributes['HOH'] in show_attributes
        show_hfr = self.core.core_show_attributes['HFR'] in show_attributes
        show_dbox = self.core.core_show_attributes['DBOX'] in show_attributes
        show_sub = self.core.core_show_attributes['SUB'] in show_attributes
        for attr in db.Session.query(db.ShowAttribute).filter(db.ShowAttribute.screen_attribute == True).all():
            if attr.uuid in show_attributes and attr.uuid not in screen_attributes:
                not_enabled.append(attr.name)

        if not_enabled:
            re['warning_messages'].append('Screen is not ' + ' or '.join(not_enabled) + ' enabled')
        audio_capability = [ x for x in screen['capabilities'] if x['name'] == 'audio' ]
        ordered_capabilities = sorted(screen['capabilities'], key=lambda capability: capability['order'])
        if len(audio_capability) > 0:
            last = ordered_capabilities[len(ordered_capabilities) - 1]['order']
            if audio_capability[0]['value'] in ('atmos', 'auro'):
                ordered_capabilities.extend([{'name': 'audio',
                  'value': '7.1',
                  'order': last + 1}, {'name': 'audio',
                  'value': '5.1',
                  'order': last + 2}])
            elif audio_capability[0]['value'] == '7.1':
                ordered_capabilities.append({'name': 'audio',
                 'value': '5.1',
                 'order': last + 1})
        else:
            audio_capability = [{'name': 'audio',
              'value': '5.1'}]
        if title.title_cpl_maps:
            content = self.core.content_service.content(content_ids=[ map.cpl_uuid for map in title.title_cpl_maps ])[0]
            cpls = []
            if len(content) > 0:
                fail_message = _('Title does not have an associated feature CPL')
                for content_uuid, content_dict in content.iteritems():
                    if content_dict.get('edit_rate') and len(content_dict) > 1 and not content_dict.get('error_message'):
                        if content_dict['content_kind'] == 'feature':
                            fail_message = None
                            language_ok = True
                            fail_message = show_sub and content_dict['subtitle_language'] is not None and (content_dict['subtitle_language'] == 'XX' or not content_dict['subtitle_language'].upper() == cfg.subtitle_language()) and _('No subtitled feature CPL was found for the configured subtitle language')
                            language_ok = False
                    elif content_dict['audio_language'] is not None and content_dict['audio_language'] != 'XX' and not content_dict['audio_language'].upper() == cfg.audio_language():
                        fail_message = _('No feature CPL was found for the configured audio language')
                        language_ok = False
                    content_three_d = language_ok and content_dict['playback_mode'] == '3D'
                    if not (content_dict['subtitle_language'] is not None and content_dict['subtitle_language'].lower() == 'hoh'):
                        content_hoh = 'hoh' in content_dict['content_title_text'].lower()
                        content_hfr = int(content_dict['edit_rate'][0]) / int(content_dict['edit_rate'][1]) > HFR_FPS
                        if not (content_dict['subtitle_language'] is not None and content_dict['subtitle_language'].lower() == 'dbox'):
                            if content_dict['motion_simulator_format'] is not None:
                                content_dbox = content_dict['motion_simulator_format'].lower() == 'dbox'
                                compat, match = self.audio_match(content_dict['audio_type'], audio_capability[0]['value'])
                                if compat:
                                    if show_three_d == content_three_d:
                                        if show_hoh == content_hoh:
                                            if show_hfr == content_hfr:
                                                if show_dbox == content_dbox:
                                                    content_dict['uuid'] = content_uuid
                                                    cpls.append(content_dict)
                                                elif show_dbox:
                                                    fail_message = _('No DBOX feature CPL was found for Title')
                                                else:
                                                    fail_message = _('Only DBOX feature CPL was found for Title')
                                            elif show_hfr:
                                                fail_message = _('No HFR feature CPL was found for Title')
                                            else:
                                                fail_message = _('Only HFR feature CPL was found for Title')
                                        elif show_hoh and not content_hoh:
                                            fail_message = _('No HOH feature CPL was found for Title')
                                        elif content_hoh and not show_hoh:
                                            fail_message = _('Only HOH feature CPL was found for Title')
                                    elif show_three_d:
                                        fail_message = _('No 3D feature CPL was found for Title')
                                    else:
                                        fail_message = _('No 2D feature CPL was found for Title')
                                else:
                                    fail_message = _('No feature CPL with a suitable audio capability was found for Title')
                        elif content_dict['content_kind'] == 'rating':
                            if content_dict['territory'] == cfg.country() and content_dict['rating']:
                                content_dict['uuid'] = content_uuid
                                rating_cpls.append(content_dict)

                if len(cpls) == 0:
                    re['error_message'] = fail_message
                    return re
            else:
                re['error_message'] = _('Title has no associated CPL')
                return re
        else:
            re['error_message'] = _('Title has no associated CPL')
            return re

        def compare_cpl(cpl1, cpl2):
            for capability in ordered_capabilities:
                cpl1c = self._is_cpl_compatible(cpl1, capability)
                cpl2c = self._is_cpl_compatible(cpl2, capability)
                if cpl1c and not cpl2c:
                    return -1
                if cpl2c and not cpl1c:
                    return 1

            return 0

        cpls = sorted(cpls, compare_cpl)
        if len(cpls) > 0:
            feature = cpls[0]
            re['feature_cpl'] = feature
            if not feature['rating_hardlocked']:
                for rating in rating_cpls:
                    if rating['territory'] == cfg.country():
                        if feature['territory'] == rating['territory'] and feature.get('rating'):
                            if feature['rating'] == rating['rating']:
                                re['rating_cpl'] = rating
                                break
                        else:
                            for rating_map in title.ratings:
                                if rating_map.territory == rating['territory'] and rating_map.rating == rating['rating']:
                                    re['rating_cpl'] = rating
                                    break

            return re
        else:
            re['error_message'] = _('No suitable feature CPL was found for screen')
            return re
            return

    def delete(self, title_uuids):
        """Deletes the specified titles from core
        :param title_uuids: a list of title uuids to delete
        :returns: list of message dictionaries indicating success/error for each specified title_uuid
        """
        messages = []
        ext_title_maps = db.Session.query(db.ExternalTitleMap).filter(db.ExternalTitleMap.title_uuid.in_(title_uuids)).all()
        title_maps_to_delete, maps_used_by_packs = self.get_title_maps_to_delete(ext_title_maps, pack_validation=True)
        title_uuids_used_by_packs = [ map.title_uuid for map in ext_title_maps if map.uuid in maps_used_by_packs and map.title_uuid ]
        producer_title_map_uuids = []
        for title_map in ext_title_maps:
            if title_map.title_uuid not in title_uuids_used_by_packs:
                if title_map.uuid in title_maps_to_delete:
                    db.Session.delete(title_map)
                else:
                    title_map.title_uuid = None
                    producer_title_map_uuids.append(title_map.uuid)

        titles = db.Session.query(db.Title).filter(db.Title.uuid.in_(title_uuids))
        title_names = []
        for title in titles:
            if title.uuid in title_uuids_used_by_packs:
                messages.append({'type': 'error',
                 'message': _('Cannot delete Title [%s] because it is referenced by a Pack') % title.name})
            else:
                db.Session.delete(title)
                title_names.append(title.name)
                audit_log('Title deleted: {title:title}', meta={'title': {'uuid': title.uuid,
                           'name': title.name}}, tags=['title', 'delete'])

        if len(title_names):
            messages.append({'type': 'success',
             'message': _('Deleted: %s') % ', '.join(title_names)})
        db.Session.commit()
        if producer_title_map_uuids:
            cherrypy.engine.publish('ccpush', 'title_maps', {'title_maps': self.core.title_service.external_titles(producer_title_map_uuids)})
        return messages

    def get_title_maps_to_delete(self, ext_title_maps, source_type = None, pack_validation = False):
        """
        Given a list of db title maps, checks if they are used by either packs or pos
        depending on source type. If no source type given, checks both.
        Returns list of title maps that are not used
        If pack_validation is true, also returns list of external title map uuids used by packs
        """
        pack_title_map_uuids = set()
        ext_title_map_source_ids = {}
        for ext_title_map in ext_title_maps:
            ext_title_map_source_ids[ext_title_map.source, ext_title_map.external_id] = ext_title_map.uuid

        if not source_type or source_type == 'pack':
            for map_uuids_chunk in sqlite_chunk(ext_title_map_source_ids.values()):
                pack_title_map_uuids = pack_title_map_uuids.union(set([ pack.external_title_map_uuid for pack in db.Session.query(db.Pack.external_title_map_uuid).filter(db.Pack.external_title_map_uuid.in_(map_uuids_chunk)) ]))

        pos_title_map_uuids = set()
        if not source_type or source_type == 'pos':
            for map_uuids_chunk in sqlite_chunk(ext_title_map_source_ids.values()):
                pos_title_map_uuids = pos_title_map_uuids.union(set([ pos.external_title_map_uuid for pos in db.Session.query(db.POSItem.external_title_map_uuid).filter(db.POSItem.external_title_map_uuid.in_(map_uuids_chunk)) ]))

        all_used_map_ids = pack_title_map_uuids.union(pos_title_map_uuids)
        maps_to_delete = set(ext_title_map_source_ids.values()) - all_used_map_ids
        if not source_type or source_type == 'pack' and pack_validation:
            return (maps_to_delete, pack_title_map_uuids)
        return maps_to_delete

    def get_title_with_cpl(self, cpl_uuid):
        titles_with_cpls_list = []
        title_cpl_maps = db.Session.query(db.TitleCplMap).filter(db.TitleCplMap.cpl_uuid == cpl_uuid)
        for title_cpl_map in title_cpl_maps:
            try:
                title = db.Session.query(db.Title).filter(db.Title.uuid == title_cpl_map.title_uuid).one()
                titles_with_cpls_list.append({'uuid': title.uuid,
                 'name': title.name})
            except Exception:
                pass

        return titles_with_cpls_list

    def external_titles(self, uuids = None):
        ex_titles = []
        if uuids:
            db_ex_titles = db.Session.query(db.ExternalTitleMap).filter(db.ExternalTitleMap.uuid.in_(uuids))
        else:
            db_ex_titles = db.Session.query(db.ExternalTitleMap)
        for db_ex_title in db_ex_titles:
            if db_ex_title.source == 'AAM':
                source_type = 'AAM'
            else:
                source_type = 'pos' if db_ex_title.source in POS_DEVICE_TYPES + ['tms_pos', 'aamlms'] else 'pack'
            ex_titles.append({'source': db_ex_title.source,
             'external_id': db_ex_title.external_id,
             'title_uuid': db_ex_title.title_uuid,
             'producer_last_modified': db_ex_title.producer_last_modified,
             'name': db_ex_title.name,
             'source_type': source_type})

        return ex_titles

    def unmatched_titles(self):
        output = {}
        external_title_maps = self.external_titles()
        pos_device_type_id_pairs = {'aamlms': self.core.get_lms_id()}
        for pos_device in db.Session.query(db.Device.type, db.Device.uuid).filter(db.Device.category == 'pos'):
            pos_device_type_id_pairs[pos_device.type] = pos_device.uuid

        territory_ratings = []
        territory_code = cfg.country()
        if cfg.country() in TERRITORIES:
            territory_ratings = TERRITORIES[cfg.country()].get('ratings', [])
        else:
            for _id, _value in TERRITORIES.iteritems():
                if _value['name'].lower() == cfg.country().lower():
                    territory_ratings = _value.get('ratings', [])
                    territory_code = _id
                    break

        for map in external_title_maps:
            if not map['title_uuid']:
                mapping = {'external_id': map['external_id'],
                 'name': map['name']}
                if map['source_type'] == 'pos':
                    pos_item_device_uuid = None
                    if map['source'] in pos_device_type_id_pairs:
                        pos_item_device_uuid = pos_device_type_id_pairs[map['source']]
                    pos_item = db.Session.query(db.POSItem).filter(and_(db.POSItem.feature_title == map['external_id'], or_(map['source'] == 'tms_pos', db.POSItem.device_uuid == pos_item_device_uuid))).first()
                    if pos_item and pos_item.rating in territory_ratings:
                        mapping['rating'] = pos_item.rating
                        mapping['territory'] = territory_code
                elif map['source_type'] == 'pack':
                    pack_rating_for_this_region = db.Session.query(db.PackRatingMap.rating).join(db.Pack, db.Pack.uuid == db.PackRatingMap.pack_uuid).filter(db.Pack.title_external_ids.like('%' + map['source'] + '%' + map['external_id'] + '%'), db.PackRatingMap.region == cfg.country()).first()
                    if pack_rating_for_this_region:
                        mapping['rating'] = pack_rating_for_this_region.rating
                        mapping['territory'] = cfg.country()
                if map['source'] not in output:
                    output[map['source']] = []
                output[map['source']].append(mapping)

        return output

    def title(self, title_uuids = []):
        title_info = {}
        db_titles = db.Session.query(db.Title).options(subqueryload('external_ids'), subqueryload('title_cpl_maps'), subqueryload('ratings'))
        if len(title_uuids) > 0:
            db_titles = db_titles.filter(db.Title.uuid.in_(title_uuids))
        for title in db_titles:
            title_info[title.uuid] = {'uuid': title.uuid,
             'name': title.name,
             'credits_offset': title.credits_offset,
             'year': title.year,
             'ratings': [ {'territory': rating.territory,
                         'rating': rating.rating} for rating in title.ratings ],
             'external_ids': [ {'source': ex_id.source,
                              'external_id': ex_id.external_id} for ex_id in title.external_ids ],
             'cpl_uuids': [ map.cpl_uuid for map in title.title_cpl_maps ],
             'last_modified': datetime.fromtimestamp(title.last_modified)}

        return title_info

    def merge(self, destination_title_uuid, source_title_uuid):
        """Merges the source title into the specified destination title
          :param destination_title_uuid: string, UUID of the destination title
          :param source_title_uuid: string, UUID of the source title
        
          Note: The source_title will be deleted! Anything pointing at it,
          will be re-mapped to the destination title after execution of this method.
          This will be called by producer:
          1. Updates TitleCplMap
          2. Updates TitleRatingMap
          3. Update Packs pointing at the source title aam title map
          4. Update External Title Maps pointing at source title
          5. Delete source title
          6. Updates last modified time for destination title
        
          Note: params are keyword params due to the way they called by producer task: titlemerge
        """
        destination_title = db.Session.query(db.Title).get(destination_title_uuid)
        source_title = db.Session.query(db.Title).get(source_title_uuid)
        if not destination_title:
            return {'type': 'error',
             'message': _('Destination Title was not found')}
        if not source_title:
            return {'type': 'error',
             'message': _('Source Title was not found')}
        try:
            source_cpl_maps = db.Session.query(db.TitleCplMap).filter(db.TitleCplMap.title_uuid == source_title_uuid)
            destination_cpl_maps = db.Session.query(db.TitleCplMap).filter(db.TitleCplMap.title_uuid == destination_title_uuid)
            for source_cpl_map in source_cpl_maps:
                if destination_cpl_maps.filter_by(cpl_uuid=source_cpl_map.cpl_uuid).count():
                    db.Session.delete(source_cpl_map)
                else:
                    source_cpl_map.title_uuid = destination_title_uuid

            source_rating_maps = db.Session.query(db.TitleRatingMap).filter_by(title_uuid=source_title_uuid).all()
            for source_rating_map in source_rating_maps:
                destination_rating_map = db.Session.query(db.TitleRatingMap).filter(and_(db.TitleRatingMap.title_uuid == destination_title_uuid, db.TitleRatingMap.territory == source_rating_map.territory))
                if not destination_rating_map:
                    source_rating_map.title_uuid = destination_title_uuid

            packs = db.Session.query(db.Pack).join('external_title_map').filter(and_(db.ExternalTitleMap.source == 'AAM', db.ExternalTitleMap.external_id == source_title_uuid))
            for pack in packs:
                destination_aam_title_map_uuid = db.Session.query(db.ExternalTitleMap.uuid).filter(and_(db.ExternalTitleMap.source == 'AAM', db.ExternalTitleMap.title_uuid == destination_title_uuid)).first()[0]
                pack.external_title_map_uuid = destination_aam_title_map_uuid

            source_title_maps = db.Session.query(db.ExternalTitleMap).filter(db.ExternalTitleMap.title_uuid == source_title_uuid)
            for source_title_map in source_title_maps:
                if source_title_map.source == 'AAM' and source_title_map.title_uuid == source_title_uuid:
                    db.Session.delete(source_title_map)
                else:
                    source_title_map.title_uuid = destination_title_uuid

            if source_title:
                db.Session.delete(source_title)
            destination_title.set_modified()
            db.Session.commit()
            audit_log('Titles merged: {source:title} with {dest:title}', meta={'source': {'uuid': source_title.uuid,
                        'name': source_title.name},
             'dest': {'uuid': destination_title.uuid,
                      'name': destination_title.name}}, tags=['title', 'modified'])
        except:
            db.Session.rollback()
            raise

        return {'type': 'success',
         'message': _('Saved')}

    def match_external_titles(self, external_titles, title_uuid):
        messages = []
        success_counter = 0
        title_count = len(external_titles)
        for title in external_titles:
            message = self.match_external_title(title['source'], title['external_id'], title_uuid, title.get('rating', None), title.get('territory', None))
            if message['type'] == 'success':
                success_counter += 1
            else:
                logging.error(str(message))

        messages.append({'type': 'success',
         'message': _('{succ} out of {all} titles have been successfully mapped.').format(succ=success_counter, all=title_count)})
        return messages

    def match_external_title(self, source, external_id, title_uuid, rating = None, territory = None):
        message = None
        try:
            etm = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.source == source, db.ExternalTitleMap.external_id == external_id)).one()
            if not title_uuid:
                title_uuid = str(uuid.uuid4())
                ratings = []
                if rating:
                    ratings.append({'rating': rating,
                     'territory': territory})
                self.save({'uuid': title_uuid,
                 'name': external_id,
                 'ratings': ratings,
                 'cpls': [],
                 'external_ids': [],
                 'external_titles': []})
                etm.title_uuid = title_uuid
            else:
                if etm.title_uuid == title_uuid:
                    message = {'type': 'error',
                     'message': _('External Title is already mapped')}
                    return message
                if db.Session.query(db.Title).filter(db.Title.uuid == title_uuid).count():
                    etm.title_uuid = title_uuid
                else:
                    cherrypy.engine.publish('ccpush', 'title_maps', {'title_maps': self.core.title_service.external_titles([etm.uuid])})
            if rating and etm.title:
                if len([ x for x in etm.title.ratings if x.rating == rating if x.territory == territory ]) == 0:
                    db_rating_map = db.TitleRatingMap()
                    db_rating_map.title_uuid = title_uuid
                    db_rating_map.territory = territory
                    db_rating_map.rating = rating
                    db.Session.add(db_rating_map)
            ex_title_map_uuid = etm.uuid
            pos_sources = POS_DEVICE_TYPES + ['tms_pos', 'aamlms']
            if source not in pos_sources:
                packs = db.Session.query(db.Pack).join('external_title_map').filter(and_(db.ExternalTitleMap.source == source, db.ExternalTitleMap.external_id == external_id)).all()
                for pack in packs:
                    pack.external_title_map_uuid = ex_title_map_uuid

            else:
                pos_source_device_uuid = None
                for device in self.core.devices:
                    if self.core.devices[device].device_configuration['type'] == source:
                        pos_source_device_uuid = device
                        break

                pos_items = db.Session.query(db.POSItem).filter(and_(db.POSItem.device_uuid == pos_source_device_uuid, db.POSItem.feature_title == external_id)).all()
                for pos in pos_items:
                    pos.external_title_map_uuid = ex_title_map_uuid

            db.Session.commit()
            audit_log('Title mapped: %s mapped to {title:title}' % external_id, meta={'title': {'uuid': etm.title_uuid}}, tags=['title', 'modified'])
            message = {'type': 'success',
             'message': _('External Title has been mapped.')}
        except NoResultFound:
            message = {'type': 'success',
             'message': _('External Title does not exist')}

        return message

    def unmatch_external_title(self, source, external_id, title_uuid):
        if source in POS_DEVICE_TYPES + ['tms_pos', 'aamlms']:
            exmaps = db.Session.query(db.ExternalTitleMap).filter(and_(or_(db.ExternalTitleMap.source == source, db.ExternalTitleMap.source == 'tms_pos'), db.ExternalTitleMap.external_id == external_id, db.ExternalTitleMap.title_uuid == title_uuid)).all()
            if not len(exmaps):
                return {'type': 'error',
                 'message': _('Title mapping was not found')}
        else:
            exmaps = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.source == source, db.ExternalTitleMap.external_id == external_id, db.ExternalTitleMap.title_uuid == title_uuid)).all()
            if not len(exmaps):
                return {'type': 'error',
                 'message': _('Title mapping was not found')}
        audit_log('Title unmapped: %s unmapped from {title:title}' % external_id, meta={'title': {'uuid': title_uuid,
                   'name': exmaps[0].title.name}}, tags=['title', 'modified'])
        title_maps_to_delete = self.get_title_maps_to_delete(exmaps)
        for exmap in exmaps:
            if exmap.uuid in title_maps_to_delete:
                db.Session.delete(exmap)
            else:
                exmap.title_uuid = None

        db.Session.commit()
        return {'type': 'success',
         'message': _('Deleted')}
# okay decompyling ./core/services/title_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:59 CST
