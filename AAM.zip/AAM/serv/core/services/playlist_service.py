# 2017.08.13 21:50:27 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\playlist_service.py
from datetime import datetime
from serv.lib.utilities import date_utils
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.core.devices.base.playback import Playback
from serv.core.devices.base.playlist import Playlist
from serv.lib.utilities.helper_methods import audit_log
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
from sqlalchemy.sql.expression import and_, or_
from sqlalchemy.orm.exc import NoResultFound
import logging
import time
import uuid
import copy
import cherrypy
from serv.lib.utilities.helper_methods import marker_clip_templating_log, get_playlist_cpl_uuids
EMPTY_SCREEN_PLAYLIST_PLAYLIST = {'title': None,
 'text': None,
 'events': [],
 'is_hfr': False,
 'is_3d': False,
 'duration': 0}
DEFAULT_COMPOSITION_EVENT = {'text': None,
 'duration_in_frames': '',
 'duration_in_seconds': 0,
 'edit_rate': None,
 'encrypted': None,
 'content_kind': None,
 'cpl_id': None,
 'type': 'composition',
 'automation': [],
 'playback_mode': '2D'}

class PlaylistService(Service):

    def playlist(self, device_ids = [], playlist_ids = [], request_data_items = [], validate = False, flatten = False):
        """Returns a mapping of devices to playlists and any device error messages"""
        device_playlists = {}
        device_ids, device_errors = self._get_devices(device_ids, Playlist)
        for device_id in device_ids:
            device_playlists[device_id] = self.core.devices[device_id]._device_get_playlist_information(playlist_ids, request_data_items)

        if validate is not False:
            if validate is True:
                validate_timestamp = time.time()
            else:
                validate_timestamp = date_utils.parse_date(validate)
            for device_id in device_playlists.keys():
                for playlist in device_playlists[device_id].values():
                    try:
                        playlist_validation = self.core.playlist_validation.get_validation(playlist['id'], device_id, validate_timestamp)
                        playlist['validation'] = playlist_validation
                    except KeyError:
                        pass

        if flatten:
            flat_playlists = {}
            for _device_playlists in device_playlists.itervalues():
                for p_id, playlist in _device_playlists.iteritems():
                    flat_playlists[p_id] = playlist

            return (flat_playlists, device_errors['messages'])
        return (device_playlists, device_errors['messages'])

    def get_playlist_detailed(self, device_uuid, playlist_uuid, validate = True, playback = False, when = None, **kwargs):
        output = {'data': {},
         'messages': {}}
        device = self.core.devices[device_uuid]
        if playback:
            playlist_call = helper_methods.copy_by_value(device.get_playlist_playback_information(playlist_uuid)[playlist_uuid])
        else:
            playlist_call = helper_methods.copy_by_value(device._device_get_playlist_information([playlist_uuid])[playlist_uuid])
        if 'error_messages' in playlist_call:
            output['messages'] = playlist_call['error_messages']
            return output
        else:
            playlist = playlist_call['playlist']
            cpl_uuids = set()
            for event in playlist['events']:
                if 'cpl_id' in event and event['cpl_id']:
                    cpl_uuids.add(event['cpl_id'])

            cpl_info = self.core.content_service.get_content_detailed(device_uuid, cpl_uuids, key_info=validate, validate_datetime=when)
            for cpl_uuid in cpl_uuids:
                cpl = cpl_info[cpl_uuid]
                if 'error_messages' in cpl:
                    continue
                cpl['validation'] = cpl['devices'][device_uuid]
                del cpl['devices']

            for event in playlist['events']:
                if 'cpl_id' in event and event['cpl_id'] in cpl_info:
                    cpl = cpl_info[event['cpl_id']]
                    if not event['edit_rate'] or not event['edit_rate'][0] and not event['edit_rate'][1]:
                        logging.warn('Playlist composition event found without edit rate: Playlist: {0}  Event: {1}'.format(str(playlist_uuid), str(event['cpl_id'])))
                        if 'edit_rate' in cpl:
                            event['edit_rate'] = cpl['edit_rate']
                        else:
                            event['edit_rate'] = [24, 1]
                    for key in cpl.keys():
                        if key in event:
                            if not event[key]:
                                event[key] = cpl[key]
                        else:
                            event[key] = cpl[key]

                if 'automation' in event:
                    for automation_dict in event['automation']:
                        if automation_dict['type'] == 'intermission' and device.device_configuration['type'] == 'doremi':
                            intermission_spl_title = None
                            intermission_spl_info = device.playlist_information.get(automation_dict['type_specific']['spl_uuid'])
                            if intermission_spl_info:
                                intermission_spl_title = intermission_spl_info['playlist']['title']
                            automation_dict['type_specific']['spl_title'] = intermission_spl_title

            return playlist

    def save(self, device_id, playlist, lms_playlist_reschedule = False):
        """Saves the specified playlist on the specified device and returns a message"""
        if not playlist.get('id'):
            playlist['id'] = str(uuid.uuid4())
        helper_methods.validate_playlist_events(playlist['events'])
        for event in playlist['events']:
            if event['type'] == 'composition' and event['cpl_id'] in self.core.contents:
                event['content_kind'] = self.core.contents[event['cpl_id']]['content_kind']

        action_id = self._action(self.core.devices[device_id].playlist_save_helper, playlist)
        audit_log('Saved playlist: {playlist:playlist} on {device:device_uuid}', meta={'playlist': playlist,
         'device': device_id}, tags=['playlist', 'save'])
        message = {'type': 'action',
         'action_id': action_id,
         'device_id': device_id,
         'playlist_uuid': playlist['id'],
         'message': _('Saving: %s') % playlist['title']}
        if lms_playlist_reschedule:
            schedules_uuids = [ schedule.uuid for schedule in db.Session.query(db.Schedule.uuid).filter(db.Schedule.source_playlist_uuid == playlist['id']) ]
            if schedules_uuids:
                self.core.scheduling_service.reschedule(schedule_uuids=schedules_uuids)
        return message

    def delete(self, playlist_ids, device_ids = []):
        """Deletes specified playlists from devices
           Playlist cannot be deleted if:
                - is playing
                - is configured as start or end of day playlist
                - is assigned to a POS session
        """

        def is_assigned(playlist_id):
            """Returns true if the specified playlist is assigned to active POS Item or Manual Schedule
            """
            return bool(db.Session.query(db.POSItem).filter(and_(db.POSItem.playlist_uuid == playlist_id, db.POSItem.state != 'deleted', db.POSItem.start > datetime.now())).count()) or bool(db.Session.query(db.Schedule).filter(and_(db.Schedule.is_template == True, db.Schedule.source_playlist_uuid == playlist_id, db.Schedule.start_timestamp > time.time())).count())

        messages = []
        device_ids, device_errors = self._get_devices(device_ids, Playlist)
        messages.extend(device_errors['messages'])
        for device_id in device_ids:
            if isinstance(self.core.devices[device_id], Playback):
                playback_status = self.core.devices[device_id].device_get_playback_information()
                loaded_spl_uuid = playback_status['spl_uuid']
            else:
                loaded_spl_uuid = None
            for playlist_id in playlist_ids:
                if playlist_id == loaded_spl_uuid:
                    message = _('Playlist cannot be deleted because it is currently loaded')
                    messages.append({'type': 'error',
                     'message': message,
                     'playlist_id': playlist_id,
                     'device_id': device_id})
                elif playlist_id == cfg.core_bookend_start_spl_uuid():
                    message = _('Playlist cannot be deleted because it is configured as the Start of Day Playlist')
                    messages.append({'type': 'error',
                     'message': message,
                     'playlist_id': playlist_id,
                     'device_id': device_id})
                elif playlist_id == cfg.core_bookend_end_spl_uuid():
                    message = _('Playlist cannot be deleted because it is configured as the End of Day Playlist')
                    messages.append({'type': 'error',
                     'message': message,
                     'playlist_id': playlist_id,
                     'device_id': device_id})
                elif not cfg.marker_clip_templating() and is_assigned(playlist_id) and device_id == self.core.get_lms_id():
                    message = _('Playlist cannot be deleted because it is assigned to a POS Session or Templated Schedule')
                    messages.append({'type': 'error',
                     'message': message,
                     'playlist_id': playlist_id,
                     'device_id': device_id})
                elif playlist_id not in self.core.devices[device_id].playlist_information:
                    message = _('Item does not exist')
                    messages.append({'type': 'success',
                     'message': message,
                     'playlist_id': playlist_id,
                     'device_id': device_id})
                else:
                    playlist = self.core.devices[device_id].playlist_information[playlist_id]['playlist']
                    action_id = self._action(self.core.devices[device_id].playlist_delete_helper, playlist_id)
                    audit_log('Playlist deleted: {playlist:playlist} from {device:device_uuid}', meta={'playlist': playlist,
                     'device': device_id}, tags=['playlist', 'delete'])
                    message = _('Deleting: %s') % playlist['title']
                    messages.append({'type': 'action',
                     'success': True,
                     'message': message,
                     'action_id': action_id,
                     'playlist_id': playlist_id,
                     'device_id': device_id})

        return messages

    def transfer(self, sending_device_id, receiving_device_ids, playlist_ids, not_before = None, playlists_json = []):
        """Transfers specified playlists from one device to another and returns messages"""
        messages = []
        for playlist_id in playlist_ids:
            sender = self.core.devices[sending_device_id]
            playlists = sender.playlist_information
            ignore = []
            for playlist_json in playlists_json:
                if playlist_json['id'] in playlists:
                    ignore.append(playlist_json['id'])
                else:
                    playlists[playlist_json['id']] = playlist_json

            for receiving_device_id in receiving_device_ids:
                reciever = self.core.devices[receiving_device_id]
                if not reciever.device_status['alive']:
                    messages.append({'type': 'error',
                     'message': _('Error communicating with device'),
                     'playlist_id': playlist_id,
                     'device_id': receiving_device_id})
                    continue
                if playlist_id in playlists:
                    playlist = self.update_event_metadata(playlists[playlist_id])
                    if self.contains_placeholder(playlist['playlist']):
                        screen = helper_methods.get_screen(receiving_device_id)
                        playlist = self.create_screen_playlist(playlist['playlist'], [], screen, None, None)
                    sender_type = sender.device_configuration['type']
                    receiver_type = reciever.device_configuration['type']
                    for event in playlist['events']:
                        for automation in event['automation']:
                            if automation['type'] == 'intermission':
                                if receiver_type in automation['name'].lower() or receiver_type == 'aamlms':
                                    if 'christie' in [sender_type, receiver_type]:
                                        automation_spl_uuid = helper_methods.get_intermission_playlist(automation)['playlist']['id']
                                    else:
                                        automation_spl_uuid = automation['type_specific']['spl_uuid']
                                    self.transfer(sending_device_id, receiving_device_ids, [automation_spl_uuid], not_before)

                    action_id = self._action(reciever.playlist_save_helper, playlist['playlist'])
                    audit_log('Playlist transferred: {playlist:playlist} from {from:device_uuid} to {to:device_uuid}', meta={'playlist': playlist['playlist'],
                     'from': sending_device_id,
                     'to': receiving_device_id}, tags=['playlist', 'transfer'])
                    messages.append({'type': 'action',
                     'message': _('Playlist [%s] has been queued for transfer on device [%s]') % (playlist_id, receiving_device_id),
                     'action_id': action_id,
                     'playlist_id': playlist_id,
                     'device_id': receiving_device_id})
                    content_uuids = get_playlist_cpl_uuids(playlist)
                    for content_uuid in set(content_uuids):
                        self.core.content_service.transfer_content(sending_device_id, receiving_device_id, content_uuid, not_before, playlist_id)

                else:
                    messages.append({'type': 'error',
                     'message': _('Cannot find playlist %s on %s') % (playlist_id, self.core.get_pretty_name(sending_device_id)),
                     'playlist_id': playlist_id,
                     'device_id': receiving_device_id})

            for playlist_json in playlists_json:
                if playlist_json['id'] in playlists and playlist_json['id'] not in ignore:
                    playlists.pop(playlist_json['id'])

        return messages

    def create_composition_event_from_cpl(self, cpl_dict):
        """
        Creates a new composition event  using the cpl dictionary
        If the core.contents{} contains an entry for this cpl,
        and that entry has been loaded from XML, then we first
        update the provided cpl dictionary using the core.contents info
        """
        if not cpl_dict.get('cpl_id'):
            if not cpl_dict.get('cpl_uuid'):
                cpl_uuid = cpl_dict.get('uuid')
                if not cpl_uuid:
                    raise Exception(cpl_dict['error_message'])
                new_event = copy.deepcopy(DEFAULT_COMPOSITION_EVENT)
                cpl = self.core.contents.get(cpl_uuid, {})
                cpl_dict = dict(cpl_dict.items() + cpl.items())
                new_event['cpl_id'] = cpl_uuid
                if 'duration_in_frames' in cpl_dict:
                    new_event['duration_in_frames'] = cpl_dict['duration_in_frames']
                if 'duration' in cpl_dict:
                    new_event['duration_in_frames'] = cpl_dict['duration']
                if 'edit_rate' in cpl_dict:
                    new_event['edit_rate'] = cpl_dict['edit_rate']
                if 'text' in cpl_dict:
                    new_event['text'] = cpl_dict['text']
                elif 'content_title_text' in cpl_dict:
                    new_event['text'] = cpl_dict['content_title_text']
                if 'content_kind' in cpl_dict and cpl_dict['content_kind']:
                    new_event['content_kind'] = cpl_dict['content_kind']
                if 'duration_in_seconds' in cpl_dict:
                    new_event['duration_in_seconds'] = cpl_dict['duration_in_seconds']
                if 'encrypted' in cpl_dict:
                    new_event['encrypted'] = cpl_dict['encrypted']
                if 'rating' in cpl_dict:
                    new_event['rating'] = cpl_dict['rating']
                if 'territory' in cpl_dict:
                    new_event['territory'] = cpl_dict['territory']
                new_event['automation'] = 'automation' in cpl_dict and cpl_dict['automation']
            new_event['trimming_weight'] = 'trimming_weight' in cpl_dict and cpl_dict['trimming_weight']
        return new_event

    def match_placeholders(self, playlist, screen, showstart_datetime, cpl_transitions, title_uuid, show_attributes, print_number = None):
        """
        Given a playlist dictionary containing an event list which includes placeholders,
        this method returns a new playlist dictionary with the placeholders matched
        and replaced with appropriate events.
        
        :param playlist: a playlist dictionary (not nested)
        :param screen: a screen dictionary
        :param showstart_datetime: start time of show
        :param cpl_transitions: do we do cpl transitions (flat <-> scope) for pack content?
        :param title_uuid: uuid of the title - used in matching
        :param show_attributes: a list of show attribute uuids to use in the matching
        :returns: tuple consisting of:
                    -    a playlist dictionary based off the input dictionary, but with the placeholders replaced
                    -    a list of template matching messages relating to the matching (see below for format)
        
        :raises: Exception - If the playlist contains a feature placeholder and that
        a suitable title, or cpl matched to the title cannot be found, then an
        exception is raised.
        
        Note: templates contain  different names for the placeholders,
        compared to placeholders in templated playlists created on TMS
        
             template messages =  [
                  {
                    'level': 'INFO', 'WARNING', 'ERROR'
                    'placeholder_uuid': ...
                    'placeholder_type': ...,
                    'uuid': ..
                    'text': ..
                    'message': ...
                    'inserted_ids': [..]
                  },
                 ...
              ]
        
        """

        def match_content_placeholder(placeholder_uuid, show_attributes, placeholder_name = None):
            """
            Matches the specified placeholder and show_attributes against
            available packs.
            :param placeholder_uuid: uuid of the placeholder (placeholder type)
            :param show_attributes: list of show attributes (normally from a pos session) to match against
            :returns: a list of templating issues/messages, and either a list of playlist events from the matched pack or None if no pack matched
            """
            marker_clip_templating = False
            if cfg.marker_clip_templating():
                marker_clip_templating = True
            pack_events = []
            messages = []
            placeholder = db.Session.query(db.Placeholder).get(placeholder_uuid)
            if not placeholder:
                messages.append({'level': 'ERROR',
                 'placeholder_uuid': placeholder_uuid,
                 'placeholder_type': 'pack',
                 'uuid': None,
                 'text': placeholder_name,
                 'message': _('Placeholder does not exist on the system. Remove the Placeholder from the Playlist'),
                 'inserted_ids': []})
            pack = self.core.pack_service.match_pack(placeholder_uuid, screen['uuid'], show_attributes, showstart_datetime, title_uuid, print_number)
            trailer_rating_cpls = {}
            for cpl_uuid in self.core.configuration_service.trailer_rating_content()['cpls']:
                if cpl_uuid in self.core.contents:
                    cpl = self.core.contents[cpl_uuid]
                    if 'rating' in cpl and cpl['rating'] and 'territory' in cpl and cpl['territory']:
                        key = '%s-%s' % (cpl['territory'], cpl['rating'])
                        if key not in trailer_rating_cpls:
                            trailer_rating_cpls[key] = cpl

            if pack and placeholder:
                if marker_clip_templating:
                    marker_clip_templating_log('Matched Pack UUID %s for PST %s on screen %s' % (pack['uuid'], showstart_datetime.strftime('%Y-%m-%d %H:%M:%S'), screen['title']))
                if 'clips' not in pack or not pack['clips']:
                    messages.append({'level': 'INFO',
                     'placeholder_uuid': placeholder_uuid,
                     'placeholder_type': 'pack',
                     'uuid': pack['uuid'],
                     'text': placeholder.name,
                     'message': _('Pack does not contain any clips') + ': ' + pack.get('name', 'unknown'),
                     'inserted_ids': []})
                else:
                    inserted_ids = []
                    scope = False
                    three_d = playlist['is_3d']
                    for cpl in pack['clips']:
                        if cpl['type'] == 'pattern':
                            pack_event = cpl
                        else:
                            pack_event = self.create_composition_event_from_cpl(cpl)
                            if pack_event['cpl_id'] in self.core.contents:
                                cpl_details = self.core.contents[pack_event['cpl_id']]
                                if cpl_details['content_kind'] == 'trailer' and not cpl_details['rating_hardlocked']:
                                    if 'rating' in cpl_details and cpl_details['rating'] and cpl_details['rating'] != 'XX' and 'territory' in cpl_details and cpl_details['territory']:
                                        key = '%s-%s' % (cpl_details['territory'], cpl_details['rating'])
                                        if key in trailer_rating_cpls:
                                            pack_events.append(self.create_composition_event_from_cpl(trailer_rating_cpls[key]))
                                if cpl_transitions:
                                    previous_scope = scope
                                    if 'aspect_ratio' in cpl_details and cpl_details['aspect_ratio'] != None:
                                        cpl_ratio = cpl_details['aspect_ratio'].lower()
                                        scope = True if 's' in cpl_ratio else False
                                    if previous_scope != scope:
                                        if scope and three_d:
                                            placeholder_name = 'To 3D Scope'
                                        elif scope and not three_d:
                                            placeholder_name = 'To 2D Scope'
                                        elif not scope and three_d:
                                            placeholder_name = 'To 3D Flat'
                                        else:
                                            placeholder_name = 'To 2D Flat'
                                        macro_placeholder_uuid = self.core.macro_placeholders[placeholder_name]
                                        pack_events.append({'type': 'macro_pack',
                                         'text': placeholder_name,
                                         'uuid': macro_placeholder_uuid})
                        pack_events.append(pack_event)
                        inserted_ids.append(pack_event['cpl_id'])

                    messages.append({'level': 'INFO',
                     'placeholder_uuid': placeholder_uuid,
                     'placeholder_type': 'pack',
                     'uuid': pack['uuid'],
                     'text': placeholder.name,
                     'message': _('Added CPLs from Pack') + ': ' + pack.get('name', 'unknown'),
                     'inserted_ids': inserted_ids})
            elif not pack:
                if marker_clip_templating:
                    marker_clip_templating_log('Could not match pack for PST %s on screen %s' % (showstart_datetime.strftime('%Y-%m-%d %H:%M:%S'), screen['title']))
                messages.append({'level': 'WARNING',
                 'placeholder_uuid': placeholder_uuid,
                 'placeholder_type': 'pack',
                 'uuid': None,
                 'text': placeholder_name,
                 'message': _('Matching Pack not found'),
                 'inserted_ids': []})
            return (messages, pack_events)

        def match_title_placeholder(title_uuid, show_attributes, screen, credit_offset):
            """
            Matches the appropriate CPL for the screen, title and show_attributes
            :param title_uuid: uuid of title
            :param show_attributes: a list of show attribute names
            :param screen: a dictionary containing a screen
            :param credit_offset: bool - indicates if credit offset should be applied for automation
            :returns: a list of templating issues/messages, and a single
            composition event referencing the matched CPL - or none, if no match
            
            :assumption:  templates only contain one title
            """
            messages = []
            feature_event = None
            rating_event = None
            try:
                title = db.Session.query(db.Title).filter(db.Title.uuid == title_uuid).one()
                matched_ret = self.core.title_service._match_title(title, show_attributes, screen)
                title_match_error = matched_ret.get('error_message')
                title_match_warnings = matched_ret.get('warning_messages')
                cpl_title_text = _('Unknown')
                if title_match_warnings:
                    for tmw in title_match_warnings:
                        message = {'level': 'WARNING',
                         'placeholder_uuid': None,
                         'placeholder_type': 'title',
                         'uuid': title_uuid,
                         'text': title.name,
                         'message': _(tmw),
                         'inserted_ids': []}
                        messages.append(message)

                if not title_match_error:
                    feature_event = self.create_composition_event_from_cpl(matched_ret['feature_cpl'])
                    try:
                        cpl_title_text = matched_ret['feature_cpl']['content_title_text']
                        offset = matched_ret['feature_cpl']['credits_offset']
                        if offset == None:
                            offset = title.credits_offset
                    except Exception:
                        offset = None

                    if credit_offset and offset:
                        msgs, event = match_credit_offset(feature_event, offset)
                        messages.extend(msgs)
                    feature_event['text'] = cpl_title_text
                    feature_event['title_event'] = True
                    feature_event['title_uuid'] = title_uuid
                    feature_event['uuid'] = title_uuid
                    message = {'level': 'INFO',
                     'placeholder_uuid': None,
                     'placeholder_type': 'title',
                     'uuid': title_uuid,
                     'text': title.name if title else 'unknown',
                     'message': _('Matched Title') + ': ' + cpl_title_text,
                     'inserted_ids': [matched_ret['feature_cpl']['uuid']]}
                    messages.append(message)
                    if matched_ret['rating_cpl']:
                        rating_event = self.create_composition_event_from_cpl(matched_ret['rating_cpl'])
                        cpl_title_text = matched_ret['rating_cpl']['content_title_text']
                        rating_event['text'] = cpl_title_text
                        rating_event['title_uuid'] = title_uuid
                        rating_event['uuid'] = title_uuid
                        message = {'level': 'INFO',
                         'placeholder_uuid': None,
                         'placeholder_type': 'title',
                         'uuid': title_uuid,
                         'text': title.name if title else 'unknown',
                         'message': _('Matched Rating') + ': ' + cpl_title_text,
                         'inserted_ids': [matched_ret['rating_cpl']['uuid']]}
                        messages.append(message)
                else:
                    message = {'level': 'ERROR',
                     'placeholder_uuid': None,
                     'placeholder_type': 'title',
                     'uuid': title_uuid,
                     'text': title.name,
                     'message': title_match_error,
                     'inserted_ids': []}
                    messages.append(message)
            except NoResultFound:
                message = {'level': 'ERROR',
                 'placeholder_uuid': None,
                 'placeholder_type': 'title',
                 'uuid': title_uuid,
                 'text': None,
                 'message': _('Title does not exist'),
                 'inserted_ids': []}
                messages.append(message)

            return (messages, feature_event, rating_event)

        def match_placeholders_in_events(input_events):
            """
            Given a list of events which may contain placeholders, returns
            a list of events with the placeholders matched (if possible), and a list
            of associated template matching issues
            :param input_events: list of playlist events
            :returns:templating_issues, output_events: a list of message generated during placeholder matching
                     and a list of playlist events (with placeholders removed/replaced)
            """
            templating_issues = []
            output_events = []
            marker_clip_templating = False
            if cfg.marker_clip_templating():
                marker_clip_templating = True
                preshow_end_placeholder = cfg.marker_clip_preshow_end().upper()
            for event in input_events:
                messages = None
                if event['type'] == 'content_placeholder' or event['type'] == 'placeholder' and showstart_datetime:
                    messages, pack_events = match_content_placeholder(event['uuid'], show_attributes, event.has_key('text') and event['text'])
                    messages[0]['offset_cpl_index'] = None
                    if pack_events:
                        output_events.extend(pack_events)
                        if marker_clip_templating:
                            messages[0]['last_cpl_spl_index'] = len(output_events) - 1
                            if event['text'] == preshow_end_placeholder:
                                marker_clip_templating_log('Setting end of pre-show cpl as: %s for PST %s' % (messages[0]['inserted_ids'][-1], showstart_datetime.strftime('%Y-%m-%d %H:%M:%S')))
                                messages[0]['offset_cpl_index'] = len(output_events) - 1
                    elif marker_clip_templating and event['text'] == preshow_end_placeholder:
                        if input_events.index(event) != 0 and len(output_events):
                            messages[0]['offset_cpl_index'] = len(output_events) - 1
                            marker_clip_templating_log('Setting end of pre-show cpl: %s for PST %s' % (output_events[-1]['cpl_id'], showstart_datetime.strftime('%Y-%m-%d %H:%M:%S')))
                        else:
                            messages[0]['offset_cpl_index'] = None
                            marker_clip_templating_log('No preshow added for PST %s' % showstart_datetime.strftime('%Y-%m-%d %H:%M:%S'))
                elif event['type'] == 'title_placeholder' or event['type'] == 'title':
                    if title_uuid:
                        messages, feature_event, rating_event = match_title_placeholder(title_uuid, show_attributes, screen, event.get('credit_offset', False))
                        if rating_event:
                            rating_event['rating_event'] = True
                            output_events.append(rating_event)
                        if feature_event:
                            feature_event['title_event'] = True
                            output_events.append(feature_event)
                    else:
                        messages = [{'level': 'ERROR',
                          'placeholder_uuid': None,
                          'placeholder_type': 'title',
                          'uuid': None,
                          'text': None,
                          'message': _('Title not specified'),
                          'inserted_ids': []}]
                elif event['type'] == 'macro_placeholder' or event['type'] == 'macro_pack':
                    messages, macro_pack_events = match_macro_pack_placeholder(event['uuid'], screen)
                    if macro_pack_events:
                        output_events.extend(macro_pack_events)
                else:
                    for automation in event.get('automation', []):
                        if automation['type'] == 'credit_offset':
                            messages, event = match_credit_offset(event, automation['type_specific']['offset_in_seconds'])
                            event['automation'].remove(automation)

                    output_events.append(event)
                if messages:
                    templating_issues.extend(messages)

            return (templating_issues, output_events)

        def match_credit_offset(event, offset):
            found = False
            messages = []
            for device_id in screen['devices']:
                device = self.core.devices[device_id]
                if isinstance(device, Playback) and offset != None:
                    found, event = device.attach_credit_offset(event, offset)
                    break

            if not found or offset == None:
                messages.append({'level': 'WARNING',
                 'placeholder_uuid': None,
                 'placeholder_type': 'macro_pack',
                 'uuid': None,
                 'text': 'Credit Offset',
                 'message': _('Not configured'),
                 'inserted_ids': []})
            if found:
                messages.append({'level': 'INFO',
                 'placeholder_uuid': None,
                 'placeholder_type': 'macro_pack',
                 'uuid': '',
                 'text': 'Credit Offset',
                 'message': _('Configured'),
                 'inserted_ids': ''})
            return (messages, event)

        def match_macro_pack_placeholder(macropack_placeholder_uuid, screen):
            pack_events = []
            messages = []
            macro_placeholder_name = None
            for key in self.core.macro_placeholders:
                if self.core.macro_placeholders[key] == macropack_placeholder_uuid:
                    macro_placeholder_name = key

            pack = self.core.macro_pack_service.match_pack(macropack_placeholder_uuid, screen)
            if pack:
                if 'events' not in pack or not pack['events']:
                    messages = [{'level': 'INFO',
                      'placeholder_uuid': macropack_placeholder_uuid,
                      'placeholder_type': 'macro_pack',
                      'text': macro_placeholder_name,
                      'uuid': pack['uuid'],
                      'message': _('Macro pack does not contain any events'),
                      'inserted_ids': []}]
                else:
                    inserted_ids = []
                    for pack_event in pack['events']:
                        pack_events.append(pack_event)
                        inserted_ids.append(pack_event.get('cpl_id'))

                    messages = [{'level': 'INFO',
                      'placeholder_uuid': macropack_placeholder_uuid,
                      'placeholder_type': 'macro_pack',
                      'uuid': pack['uuid'],
                      'text': macro_placeholder_name,
                      'message': _('Macro Pack has been matched'),
                      'inserted_ids': inserted_ids}]
            else:
                messages = [{'level': 'WARNING',
                  'placeholder_uuid': macropack_placeholder_uuid,
                  'placeholder_type': 'macro_pack',
                  'uuid': None,
                  'text': macro_placeholder_name,
                  'message': _('Matching Macro Pack not found'),
                  'inserted_ids': []}]
            return (messages, pack_events)

        def match_auto_transitions(playlist):
            events_len = len(playlist['events'])
            feature = None
            for index in xrange(events_len):
                event = playlist['events'][index]
                if event['type'] in ('auto_transition', 'empty_placeholder'):
                    if index == 0:
                        macro_placeholder_uuid = None
                        macro_placeholder_name = None
                        if playlist['is_3d']:
                            macro_placeholder_name = 'Show Start 3D'
                        else:
                            macro_placeholder_name = 'Show Start 2D'
                        macro_placeholder_uuid = self.core.macro_placeholders[macro_placeholder_name]
                        playlist['events'][index] = {'type': 'macro_pack',
                         'text': macro_placeholder_name,
                         'uuid': macro_placeholder_uuid}
                    elif index == events_len - 1:
                        macro_placeholder_uuid = self.core.macro_placeholders['Show End']
                        playlist['events'][index] = {'type': 'macro_pack',
                         'text': 'Show End',
                         'uuid': macro_placeholder_uuid}
                    else:
                        scope = False
                        three_d = False
                        if not feature:
                            for subindex in xrange(index, events_len):
                                subevent = playlist['events'][subindex]
                                if not feature and 'title_uuid' in subevent:
                                    feature = subevent

                        if feature:
                            lms_feature = self.core.contents[feature['cpl_id']]
                            if 'aspect_ratio' in lms_feature and lms_feature['aspect_ratio'] != None:
                                cpl_ratio = lms_feature['aspect_ratio'].lower()
                            else:
                                cpl_ratio = 'flat'
                            scope = True if 's' in cpl_ratio else False
                            three_d = lms_feature['playback_mode'] == '3D'
                        if scope and three_d:
                            placeholder_name = 'To 3D Scope'
                        elif scope and not three_d:
                            placeholder_name = 'To 2D Scope'
                        elif not scope and three_d:
                            placeholder_name = 'To 3D Flat'
                        else:
                            placeholder_name = 'To 2D Flat'
                        macro_placeholder_uuid = self.core.macro_placeholders[placeholder_name]
                        playlist['events'][index] = {'type': 'macro_pack',
                         'text': placeholder_name,
                         'uuid': macro_placeholder_uuid}

            return playlist

        new_playlist = dict(EMPTY_SCREEN_PLAYLIST_PLAYLIST.items() + copy.deepcopy(playlist).items())
        new_playlist['is_template'] = False
        new_playlist['duration_in_seconds'] = 0
        new_playlist['duration_in_frames'] = 0
        old_events = playlist['events']
        templating_issues, new_events = match_placeholders_in_events(old_events)
        if self.is_template(playlist):
            new_playlist['id'] = str(uuid.uuid4())
        else:
            new_playlist['id'] = playlist['id']
        new_playlist['events'] = new_events
        for event in new_playlist['events']:
            event_duration_seconds = event.get('duration_in_seconds', 0)
            event_duration_seconds = int(event_duration_seconds) if event_duration_seconds else 0
            event_duration_frames = event.get('duration_in_frames', 0)
            event_duration_frames = int(event_duration_frames) if event_duration_frames else 0
            new_playlist['duration_in_seconds'] += event_duration_seconds
            new_playlist['duration_in_frames'] += event_duration_frames

        messages = []
        messages.extend(templating_issues)
        new_playlist = match_auto_transitions(new_playlist)
        templating_issues, new_events = match_placeholders_in_events(new_playlist['events'])
        new_playlist['events'] = new_events
        messages.extend(templating_issues)
        return (new_playlist, messages)

    def auto_create_playlist(self, pos_item_uuid = None, pos_item = None, pos_dict = None, show_attributes = []):
        """
            Given a pos_item with a playlist id set to 'auto', this method attempts to
            generate a suitable playlist.
        
            The active template is used
        
            After generating and assigning this playlist, the new playlist uuid and
            the uuid of the template used to create it, are returned.
        
            Either a pos_item instance, or a pos_item uuid  can be provided.
        
            :param pos_item_uuid: UUID identifying a pos item, or
            :param pos_item: a instance of db.POSItem
            :returns: a dictionary containing the playlist
        
            e.g.
             {
               'title': ...,
               'text': ...,
               'events': [...],
                ...
             }
        """

        def get_screen(pos_item):
            """Retrieves the screen details for the screen referred to in the pos item
            """
            screen_uuid = pos_item.external_device_map.device.screen.uuid
            if not screen_uuid:
                raise Exception('No Screen UUID found for POS Item [%s]' % pos_item.uuid)
            screen = self.core.configuration_service.screen([screen_uuid])
            return screen[screen_uuid]

        def set_playlist_attributes(playlist):
            if self.core.core_show_attributes['3D'] in show_attributes:
                playlist['is_3d'] = True
            if self.core.core_show_attributes['HFR'] in show_attributes:
                playlist['is_hfr'] = True

        def make_fake_pos_item(pos_dict):
            pos_item = db.POSItem()
            pos_item.screen_identifier = pos_dict.get('screen_identifier')
            pos_item.feature_title = pos_dict.get('feature_title')
            pos_item.start = pos_dict.get('start')
            pos_item.source_start = pos_dict.get('source_start')
            pos_item.playlist_uuid = 'auto'
            pos_item.print_number = None
            return pos_item

        if pos_item_uuid:
            pos_item = db.Session.query(db.POSItem).get(pos_item_uuid)
        if pos_item:
            title_uuid = self.core.pos_service.get_title_uuid(pos_item)
            screen = get_screen(pos_item)
        elif pos_dict:
            pos_item = make_fake_pos_item(pos_dict)
            title_uuid = pos_dict['title_uuid']
            screen = helper_methods.get_screen(pos_dict['device_uuid'])
        template = self.core.template_service.get_active()
        if not template:
            raise Exception(_('Active Template not found'))
        template_choice_message = {'level': 'INFO',
         'placeholder_uuid': None,
         'placeholder_type': 'template',
         'uuid': None,
         'text': _('Template'),
         'message': _('Created using Template: {name}').format(name=template['name']),
         'inserted_ids': None}
        showstart_datetime = pos_item.source_start
        playlist = copy.deepcopy(EMPTY_SCREEN_PLAYLIST_PLAYLIST)
        set_playlist_attributes(playlist)
        playlist['title'] = self.core.schedule_synchroniser._create_scheduled_playlist_title('AUTO_' + pos_item.feature_title, [], pos_item.start, screen['identifier'], screen['title'], pos_item=pos_item)
        playlist['text'] = playlist['title']
        playlist['events'].extend(template['event_list'])
        new_playlist, messages = self.match_placeholders(playlist, screen, showstart_datetime, template['cpl_transitions'], title_uuid, show_attributes, pos_item.print_number)
        final_playlist = {}
        final_playlist['duration_in_frames'] = new_playlist['duration_in_frames']
        final_playlist['duration_in_seconds'] = new_playlist['duration_in_seconds']
        new_playlist['duration'] = new_playlist['duration_in_seconds']
        if 'templating_issues' in new_playlist:
            del new_playlist['templating_issues']
        final_playlist['templating_issues'] = [template_choice_message] + messages
        final_playlist['playlist'] = new_playlist
        final_playlist['content_ids'] = get_playlist_cpl_uuids(new_playlist)
        final_playlist['id'] = new_playlist['id']
        final_playlist['title'] = new_playlist['title']
        return final_playlist

    def update_event_metadata(self, playlist):
        """
        Given a playlist dictionary,  this method updates any events with any
        additional CPL information provided by core.contents  and returns
        the updated playlist dictionary
        """
        new_playlist = copy.deepcopy(playlist)
        new_playlist['events'] = []
        if 'playlist' in playlist:
            event_list = playlist['playlist'].get('events', [])
        else:
            event_list = playlist.get('events', [])
        for event in event_list:
            if event['type'] == 'composition' and event.get('cpl_id'):
                composition_event = dict(DEFAULT_COMPOSITION_EVENT.items() + event.items())
                if 'id' not in event:
                    composition_event['id'] = str(uuid.uuid4())
                cpl = self.core.contents.get(event['cpl_id'], {})
                if cpl.get('parsed_from_xml'):
                    composition_event = dict(composition_event.items() + cpl.items())
                new_playlist['events'].append(composition_event)
            else:
                if event['type'] == 'pattern':
                    if event['text'].find('3D') != -1 or event['text'].find('3d') != -1:
                        event['playback_mode'] = '3d'
                    else:
                        event['playback_mode'] = '2D'
                    if event['text'].find('48') != -1:
                        if event['playback_mode'] == '3d':
                            event['edit_rate'] = [96, 1]
                        else:
                            event['edit_rate'] = [48, 1]
                new_playlist['events'].append(event)

        return new_playlist

    def create_screen_playlist(self, source_playlist, show_attributes, screen, showstart_datetime = None, pos_item = None):
        """Creates a screen server ready playlist from a source playlist, having
        used supplied parameters to match and replace any placeholders in the
        source playlist.
        
        :param source_playlist: playlist dictionary, possibly containing placeholders in the event list
        :param show_attributes: a list of show attribute names (used for placeholder matching)
        :param showstart_datetime: intended start time for playlist (used for matching placeholders)
        :param title_uuid: uuid of the title (used for matching placeholders)
        :returns: nested playlist dictionary in the format:
        
                {
                    'playlist': {
                                     // the new screen playlist
                                     with placeholders replaced with CPLs (where matched)
                                  }
                }
        """

        def get_title_uuid_from_events():
            """
            Looks through the playlists events for a event uuid and returns it if found
            """
            match_info = {'level': 'INFO',
             'placeholder_uuid': None,
             'placeholder_type': 'pos',
             'uuid': None,
             'text': '',
             'message': ''}
            for event in source_playlist['events']:
                if 'title' in event or event['type'] == 'title':
                    match_info['text'] = event['text']
                    match_info['placeholder_type'] = 'title'
                    match_info['message'] = _('Title specified')
                    title = self.core.title_service.title([event['uuid']])
                    if not title:
                        cherrypy.engine.publish('ccpush', 'title_maps', {'title_maps': [{'source': u'AAM',
                                         'title_uuid': event['uuid'],
                                         'producer_last_modified': None,
                                         'external_id': event['uuid'],
                                         'source_type': 'AAM'}]})
                    return (event['uuid'], match_info)
                if event.get('title_event', False):
                    return (event['uuid'], None)

            if pos_item:
                for title_map in db.Session.query(db.ExternalTitleMap).filter(and_(or_(db.ExternalTitleMap.source == pos_item.device.type, db.ExternalTitleMap.source == 'tms_pos'), db.ExternalTitleMap.external_id == pos_item.feature_title)).all():
                    match_info['text'] = pos_item.feature_title
                    match_info['message'] = _('Title specified')
                    if not title_map.title_uuid:
                        cherrypy.engine.publish('ccpush', 'title_maps', {'title_maps': self.core.title_service.external_titles([title_map.uuid])})
                        continue
                    return (title_map.title_uuid, match_info)

            found_title_uuid, title_name, cpl_text = self.core.title_service.get_title_uuid_for_cpl(source_playlist)
            if found_title_uuid != None:
                match_info['text'] = title_name
                match_info['placeholder_type'] = 'title'
                match_info['message'] = _('Title found for CPL: [%s]') % cpl_text
                return (found_title_uuid, match_info)
            else:
                return (None, None)
                return

        title_uuid, title_match_message = get_title_uuid_from_events()
        print_number = None
        if pos_item:
            print_number = pos_item.print_number
        screen_playlist, templating_issues = self.match_placeholders(source_playlist, screen, showstart_datetime, False, title_uuid, show_attributes, print_number)
        if title_match_message:
            templating_issues.insert(0, title_match_message)
        for device_id in screen['devices']:
            if device_id in self.core.devices and isinstance(self.core.devices[device_id], Playback):
                device_uuid = device_id
                break

        for event in screen_playlist['events']:
            if 'validation' in event:
                del event['validation']
                event['validation'] = cherrypy.core.contents[event['cpl_id']].get_validation(device_uuid)

        final_playlist = copy.deepcopy(source_playlist)
        final_playlist['duration_in_frames'] = screen_playlist['duration_in_frames']
        final_playlist['duration_in_seconds'] = screen_playlist['duration_in_seconds']
        screen_playlist['duration'] = final_playlist['duration_in_seconds']
        if 'templating_issues' in screen_playlist:
            del screen_playlist['templating_issues']
        final_playlist['templating_issues'] = templating_issues
        final_playlist['playlist'] = screen_playlist
        final_playlist['content_ids'] = get_playlist_cpl_uuids(screen_playlist)
        final_playlist['id'] = screen_playlist['id']
        return final_playlist

    def contains_placeholder(self, playlist_dict):
        """
        Checks if there is any kind of placeholder in the playlist
        """
        template_events = ['macro_pack',
         'macro_placeholder',
         'title',
         'title_placeholder',
         'placeholder',
         'content_placeholder']
        events = playlist_dict.get('events', [])
        for event in events:
            event_type = event.get('type')
            if event_type and event_type in template_events:
                return True
            if event.get('automation', []):
                for automation in event.get('automation', []):
                    if automation['type'] == 'credit_offset':
                        return True

        return False

    def is_template(self, playlist_dict):
        """
        Checks if the playlist contains content/title placeholders
        """
        template_events = ['title',
         'title_placeholder',
         'placeholder',
         'content_placeholder']
        events = playlist_dict.get('events', [])
        for event in events:
            event_type = event.get('type')
            if event_type and event_type in template_events:
                return True

        return False

    def has_template_problems(self, playlist_dict):
        """Checks a playlist (dictionary) for templating issues
        :param playlist_dictionary: a dictionary containing a playlist
        :returns: True if playlist contains WARNING or ERROR templating issues
        """
        templating_issues = playlist_dict.get('templating_issues', [])
        for issue in templating_issues:
            if issue['level'] in ('WARNING', 'ERROR'):
                return True

        return False
# okay decompyling ./core/services/playlist_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:41 CST
