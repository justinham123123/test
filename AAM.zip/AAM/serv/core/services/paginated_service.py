# 2017.08.13 21:50:20 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\paginated_service.py
pass
# okay decompyling ./core/services/paginated_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:20 CST
