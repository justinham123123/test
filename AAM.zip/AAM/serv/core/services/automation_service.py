# 2017.08.13 21:50:02 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\automation_service.py
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.base.automation import Automation
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db

class AutomationService(Service):

    def cues(self, device_ids = []):
        device_ids, device_errors = self._get_devices(device_ids, Automation)
        device_automation_info = {}
        for device_id in device_ids:
            device_automations = self.core.devices[device_id]._device_get_automation_information().copy()
            device_automations.pop('last_updated', None)
            device_automation_info[device_id] = device_automations

        return (device_automation_info, device_errors['messages'])

    def trigger(self, device_id, cue_id, parameterized = False, parameterized_value = 0):
        device = self.core.devices[device_id]
        try:
            if device.automation[cue_id]['type'] in ('cue', 'volume', 'sony_function'):
                return {'type': 'action',
                 'message': _('Triggering %s on %s') % (cue_id, self.core.get_pretty_name(device_id)),
                 'action_id': self._action(device.automation_trigger, cue_id, parameterized, parameterized_value)}
            return {'type': 'error',
             'message': _('Triggers cannot be executed directly')}
        except KeyError:
            return {'type': 'error',
             'message': _('Cannot find cue %s on %s') % (cue_id, device_id)}

    def get_automation_configuration(self):
        output = {}
        session = db.Session()
        automation_configs = session.query(db.AutomationConfiguration).all()
        for automation_config in automation_configs:
            output[automation_config.automation_name] = {'automation_name': automation_config.automation_name,
             'intermission': automation_config.has_flag('intermission'),
             'show_start': automation_config.has_flag('show_start'),
             'credits': automation_config.has_flag('credits')}

        session.close()
        return output
# okay decompyling ./core/services/automation_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:02 CST
