# 2017.08.13 21:50:23 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\playback_service.py
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.constants import NULL_UUID
from serv.lib.utilities import helper_methods
from serv.lib.utilities.helper_methods import audit_log
from serv.core.devices.base.playback import Playback
from serv.core.services.base_service import Service
from serv.core.devices.base.audio_controller import AudioController

class PlaybackService(Service):

    def eject(self, device_id):
        if not self.core.devices.has_key(device_id):
            return {'type': 'error',
             'message': _('Server [%s] does not exist') % device_id}
        elif self.core.devices[device_id].playback_information['spl_uuid'] != NULL_UUID and self.core.devices[device_id].playback_information['spl_uuid'] is not None:
            device = self.core.devices[device_id]
            playlist_uuid = device.playback_information['spl_uuid']
            audit_log('Playlist ejected: {playlist:playlist} from {device:device_uuid} ', meta={'device': device_id,
             'playlist': device.playlist_information[playlist_uuid]['playlist']}, tags=['playback', 'eject'])
            return {'type': 'action',
             'message': _('Ejecting Playlist %s on %s') % (device.get_playlist_display(playlist_uuid), self.core.get_pretty_name(device_id)),
             'action_id': self._action(device.playback_eject)}
        else:
            return {'type': 'error',
             'message': _('No Playlist loaded on %s') % self.core.get_pretty_name(device_id)}
            return

    def load(self, device_id, playlist_id):
        ready_to_load = self.core.devices[device_id].playback_ready_to_load()
        if ready_to_load['ready']:
            audit_log('Playlist loaded: {playlist:playlist} on {device:device_uuid}', meta={'device': device_id,
             'playlist': self.core.devices[device_id].playlist_information[playlist_id]['playlist']}, tags=['playback', 'loaded'])
            return {'type': 'action',
             'action_id': self._action(self.core.devices[device_id].playback_load_helper, playlist_id),
             'message': _('Loading Playlist %s on %s') % (self.core.devices[device_id].get_playlist_display(playlist_id), self.core.get_pretty_name(device_id))}
        else:
            return {'type': 'error',
             'message': ready_to_load['message']}

    def pause(self, device_id):
        if self.core.devices[device_id].device_get_playback_information()['playback_state'] == 'play':
            audit_log('Playback paused: {device:device_uuid}', meta={'device': device_id}, tags=['playback', 'pause'])
            return {'type': 'action',
             'message': _('Pausing %s') % self.core.get_pretty_name(device_id),
             'action_id': self._action(self.core.devices[device_id].playback_pause)}
        else:
            return {'type': 'error',
             'message': _('%s is not playing') % self.core.get_pretty_name(device_id)}

    def play(self, device_id):
        playback_status = self.core.devices[device_id].device_get_playback_information()
        if playback_status['spl_uuid'] and playback_status['spl_uuid'] != NULL_UUID:
            audit_log('Playback started: {device:device_uuid}', meta={'device': device_id}, tags=['playback', 'play'])
            return {'type': 'action',
             'message': _('Starting playback on %s') % self.core.get_pretty_name(device_id),
             'action_id': self._action(self.core.devices[device_id].playback_play)}
        else:
            return {'type': 'error',
             'message': _('Please load a Playlist first on %s') % self.core.get_pretty_name(device_id)}

    def stop(self, device_id):
        if self.core.devices[device_id].is_stoppable():
            audit_log('Playback stopped:  {device:device_uuid}', meta={'device': device_id}, tags=['playback', 'stop'])
            return {'type': 'action',
             'message': _('%s stopping') % self.core.get_pretty_name(device_id),
             'action_id': self._action(self.core.devices[device_id].playback_stop)}
        else:
            return {'type': 'error',
             'message': _('%s is not playing') % self.core.get_pretty_name(device_id)}

    def skip_forward(self, device_id):
        if self.core.devices[device_id].device_get_playback_information()['spl_uuid'] and self.core.devices[device_id].device_get_playback_information()['spl_uuid'] != NULL_UUID:
            audit_log('Playback skipped forward: {device:device_uuid}', meta={'device': device_id}, tags=['playback', 'forward'])
            return {'type': 'action',
             'message': _('%s skipping forward') % self.core.get_pretty_name(device_id),
             'action_id': self._action(self.core.devices[device_id].playback_skip_forward)}
        else:
            return {'type': 'error',
             'message': _('Please load a Playlist first on %s') % self.core.get_pretty_name(device_id)}

    def skip_backward(self, device_id):
        if self.core.devices[device_id].device_get_playback_information()['spl_uuid'] and self.core.devices[device_id].device_get_playback_information()['spl_uuid'] != NULL_UUID:
            audit_log('Playback skipped backwards: {device:device_uuid}', meta={'device': device_id}, tags=['playback', 'backward'])
            return {'type': 'action',
             'message': _('%s skipping backward') % self.core.get_pretty_name(device_id),
             'action_id': self._action(self.core.devices[device_id].playback_skip_backward)}
        else:
            return {'type': 'error',
             'message': _('Please load a Playlist first on %s') % self.core.get_pretty_name(device_id)}

    def set_mode(self, device_id, mode):
        audit_log('Playback mode updated: mode="%s" on {device:device_uuid}' % mode, meta={'device': device_id}, tags=['playback', 'updated'])
        return {'type': 'action',
         'message': _('Updating playback mode to %s on %s') % (mode, self.core.get_pretty_name(device_id)),
         'action_id': self._action(self.core.devices[device_id].playback_set_mode, mode)}

    def interrupt_intermission(self, device_uuid):
        audit_log('Interrupting intermission: {device:device_uuid}', meta={'device': device_uuid}, tags=['playback', 'forward'])
        return {'type': 'action',
         'message': _('Interrupting intermission on %s') % self.core.get_pretty_name(device_uuid),
         'action_id': self._action(self.core.devices[device_uuid].playback_interrupt_intermission)}

    def state(self, device_ids = []):
        device_playback_status = {}
        device_ids, device_errors = self._get_devices(device_ids, Playback)
        for device_id in device_ids:
            playback_status = self.playback_status(device_id)
            device_playback_status[device_id] = helper_methods.copy_by_value(playback_status)

        return (device_playback_status, device_errors['messages'])

    def playback_status(self, device_uuid):
        playback_status = self.core.devices[device_uuid].device_get_playback_information()
        playlist_info = self.core.devices[device_uuid]._device_get_playlist_information()
        if playlist_info.has_key(playback_status['spl_uuid']):
            spl_info = playlist_info[playback_status['spl_uuid']]
            playback_status['spl_title'] = spl_info['title']
            if playback_status.has_key('cpl_uuid'):
                if self.core.contents.has_key(playback_status['cpl_uuid']):
                    playback_status['content_title_text'] = self.core.contents[playback_status['cpl_uuid']]['content_title_text']
                    playback_status['content_kind'] = self.core.contents[playback_status['cpl_uuid']]['content_kind']
                else:
                    playback_status['content_title_text'] = 'Unknown CPL'
                    playback_status['content_kind'] = 'unknown'
        elif playback_status['playback_state'] in ('playback_unknown', 'error', 'projector_disconnected'):
            playback_status['spl_title'] = _('Unknown')
        elif playback_status['spl_uuid'] == '00000000-0000-0000-0000-000000000000' or playback_status['spl_uuid'] == None:
            playback_status['spl_title'] = _('No Playlist loaded')
        else:
            playback_status['spl_title'] = _('Unknown Playlist')
        return playback_status

    def supported_modes(self, device_ids = []):
        device_ids, device_errors = self._get_devices(device_ids, Playback)
        device_supported_modes = dict(((device_id, helper_methods.copy_by_value(self.core.devices[device_id]._device_get_supported_modes_information())) for device_id in device_ids))
        return (device_supported_modes, device_errors['messages'])

    def audio_device_states(self):
        out = {}
        device_uuids, device_errors = self._get_devices([], AudioController)
        for device_uuid in device_uuids:
            device = self.core.devices[device_uuid]
            status = {'input': device.get_input(),
             'mute': device.get_mute(),
             'volume': device.get_volume()}
            out[device_uuid] = status

        return (out, device_errors['messages'])

    def toggle_mute(self, device_uuid, mute):
        success = self.core.devices[device_uuid].set_mute(mute)
        if success:
            message = {'type': 'success',
             'message': _('Muted') if mute else _('Unmuted')}
        else:
            message = {'type': 'error',
             'message': _('Failed to mute') if mute else _('Failed to unmute')}
        return message

    def set_volume(self, device_uuid, volume):
        success = self.core.devices[device_uuid].set_volume(volume)
        if success:
            message = {'type': 'success',
             'message': _('Volume changed: ' + str(volume))}
        else:
            message = {'type': 'error',
             'message': _('Failed to change volume')}
        return message

    def set_input(self, device_uuid, input):
        success = self.core.devices[device_uuid].set_input(input)
        if success:
            message = {'type': 'success',
             'message': _('Input changed: ' + input)}
        else:
            message = {'type': 'error',
             'message': _('Failed to change input')}
        return message
# okay decompyling ./core/services/playback_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:27 CST
