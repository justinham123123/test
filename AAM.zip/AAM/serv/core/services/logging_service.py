# 2017.08.13 21:50:12 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\logging_service.py
from datetime import datetime, timedelta
import logging
import os.path
import zipfile
import cherrypy
from sqlalchemy import func
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import or_
from serv.core.services.base_service import Service
from serv.core.tasks.reconcile_logs import LEVEL_UNKNOWN, LEVEL_BUGGY_MATCH, CODE_PLAYBACK_CREATED_FROM_SMPTE
from serv.lib.utilities.helper_methods import sqlite_chunk
from serv.storage.database.helpers import int_timestamp_default
from serv.storage.database.playback import database as pldb
MAX_PLAYBACK_CHUNK = 200
EARLIEST_PRODUCER_TIME = datetime(1991, 7, 4)

class LoggingService(Service):

    def __init__(self, core):
        super(LoggingService, self).__init__(core)
        self.producer_newest_playback_datetime = datetime.now() - timedelta(days=10)
        cherrypy.engine.publish('cclisten', 'request_playback_groups', self._request_playback_groups)
        cherrypy.engine.publish('cclisten', 'request_playback_information', self._request_playback_log_information)
        cherrypy.engine.publish('cclisten', 'request_log_file_groups', self._request_log_file_groups)
        cherrypy.engine.publish('cclisten', 'request_log_file_information', self._request_log_file_information)

    def _request_playback_groups(self, payload):
        modified_after = payload['data']['modified_after']
        chunk_size = payload['data']['chunk_size']
        playback_groups = self.playback_groups(modified_after, chunk_size)
        cherrypy.engine.publish('ccpush', 'playback_groups', {'playback_groups': playback_groups}, target=payload['url'])

    def _request_playback_log_information(self, payload):
        uuids = payload['data']['uuids']
        playbacks, messages = self.playbacks_by_uuids(uuids)
        cherrypy.engine.publish('ccpush', 'playback_log_information', {'playbacks': playbacks}, target=payload['url'])

    def playback_log_update(self):
        """
        Notify circuit core that new playbacks have been saved.
        This triggers the playback update process via web sockets,
        causing circuit core to send a 'request_playback_log_information' message.
        """
        cherrypy.engine.publish('ccpush', 'playback_log_update')

    def _request_log_file_groups(self, payload):
        modified_after = payload['data']['modified_after']
        chunk_size = payload['data']['chunk_size']
        log_file_groups = self.log_file_groups(modified_after, chunk_size)
        cherrypy.engine.publish('ccpush', 'log_file_groups', {'log_file_groups': log_file_groups}, target=payload['url'])

    def _request_log_file_information(self, payload):
        uuids = payload['data']['uuids']
        log_files, messages = self.log_files_by_uuid(uuids)
        cherrypy.engine.publish('ccpush', 'log_file_information', {'log_files': log_files.values()}, target=payload['url'])

    def log_file_update(self):
        """
        Notify circuit core that new log files have been saved.
        This triggers the log file update process via web sockets,
        causing circuit core to send a 'request_log_file_information' message.
        """
        cherrypy.engine.publish('ccpush', 'log_file_update')

    @pldb.close_session
    def playback_last_modified(self):
        """
        Returns a dictionary of playback UUID -> last_modified.
        """
        playback_last_modified = pldb.Session.query(pldb.Playback.uuid, pldb.Playback.last_modified)
        return dict(playback_last_modified)

    @pldb.close_session
    def playbacks(self, modified_after = 0, chunk_size = 0):
        """
        Returns a list of playbacks as dictionaries modified after given time.
        
        :param modified_after: Timestamp playbacks have been modified after.
        
        :param chunk_size: Maximum number of playbacks to fetch.
        """
        mappings = pldb.Session.query(pldb.LogFilePlayout.playback_uuid, func.min(pldb.LogFilePlayout.merge_confidence_level).label('min'), func.max(pldb.LogFilePlayout.merge_confidence_level).label('max')).join(pldb.Playback, pldb.Playback.uuid == pldb.LogFilePlayout.playback_uuid).group_by(pldb.LogFilePlayout.playback_uuid)
        if modified_after > 0:
            mappings = mappings.filter(pldb.Playback.last_modified > modified_after)
        min_levels = dict(((m.playback_uuid, m.min) for m in mappings))
        max_levels = dict(((m.playback_uuid, m.max) for m in mappings))
        playbacks = pldb.Session.query(pldb.Playback).order_by(pldb.Playback.last_modified)
        if modified_after > 0:
            playbacks = playbacks.filter(pldb.Playback.last_modified > modified_after)
        if chunk_size > 0:
            playbacks = playbacks.limit(chunk_size)
        playback_dicts = []
        for playback in playbacks:
            p = playback.to_dict()
            p['verified'] = max_levels.get(playback.uuid, LEVEL_UNKNOWN) >= LEVEL_BUGGY_MATCH
            p['worst_confidence_level'] = min_levels.get(playback.uuid, LEVEL_UNKNOWN)
            playback_dicts.append(p)

        return playback_dicts

    @pldb.close_session
    def playbacks_by_uuids(self, uuids):
        """
        Returns a dictionary of playbacks given by UUIDs.
        
        :param uuids:  (list) Playback UUIDs to fetch.
        
        :returns: (playbacks, messages)
        """
        playback_data = {}
        messages = []
        limited_uuids = uuids[:MAX_PLAYBACK_CHUNK]
        remaining_uuids = uuids[MAX_PLAYBACK_CHUNK:]
        while limited_uuids:
            playbacks = pldb.Session.query(pldb.Playback).filter(pldb.Playback.uuid.in_(limited_uuids)).all()
            for playback in playbacks:
                playback_data[playback.uuid] = playback.to_dict()

            limited_uuids = remaining_uuids[:MAX_PLAYBACK_CHUNK]
            remaining_uuids = remaining_uuids[MAX_PLAYBACK_CHUNK:]

        missing_uuids = set(uuids) - set(playback_data.keys())
        for missing_uuid in missing_uuids:
            messages.append({'type': 'error',
             'log_file_uuid': missing_uuid,
             'message': 'Playback entry not found in system.'})

        return (playback_data, messages)

    @pldb.close_session
    def delete_playbacks(self, uuids):
        """
        Marks all playbacks as deleted.
        
        :param uuids: UUIDs of the playbacks to mark deleted.
        
        :returns: Number of playbacks marked.
        """
        if not uuids:
            return 0
        deleted = 0
        for id_chunk in sqlite_chunk(uuids):
            deleted += pldb.Session.query(pldb.Playback.uuid).filter(pldb.Playback.uuid.in_(id_chunk)).update({'deleted': True,
             'last_modified': int_timestamp_default()}, False)

        pldb.Session.commit()
        return deleted

    @pldb.close_session
    def reset_playbacks(self, ips, start_timestamp, end_timestamp):
        """
        Nullifies the playback_uuid for all LogFilePlayouts that match the filter condition.
        And resets the error codes on any playbacks, and deletes all SMPTE-derived playbacks.
        This makes remerging possible for this time/screen range
        
        :param ips:                 (list) List of Device IPs (strings) to filter playbacks by.
        :param start_timestamp:     (int) Start time (UNIX timestamp) to filter playbacks by (inclusive).
        :param end_timestamp:       (int) End time (UNIX timestamp) to filter playbacks by (inclusive).
        
        :returns: Number of playbacks (playouts_unmapped, updated, deleted).
        """
        nullified_mappings = pldb.Session.query(pldb.LogFilePlayout).filter(pldb.LogFilePlayout.id.in_(pldb.Session.query(pldb.LogFilePlayout.id).join(pldb.LogFile, pldb.LogFile.uuid == pldb.LogFilePlayout.log_file_uuid).filter(or_(pldb.LogFilePlayout.start_time >= start_timestamp, pldb.LogFilePlayout.end_time >= start_timestamp), or_(pldb.LogFilePlayout.start_time <= end_timestamp, pldb.LogFilePlayout.end_time <= end_timestamp), pldb.LogFilePlayout.playback_uuid != None, pldb.LogFile.device_ip_address.in_(ips)))).update({'playback_uuid': None,
         'merge_confidence_level': None}, False)
        deleted = pldb.Session.query(pldb.Playback).filter(pldb.Playback.device_ip_address.in_(ips), or_(pldb.Playback.start >= start_timestamp, pldb.Playback.end >= start_timestamp), or_(pldb.Playback.start <= end_timestamp, pldb.Playback.end <= end_timestamp), pldb.Playback.merge_error_code == CODE_PLAYBACK_CREATED_FROM_SMPTE, pldb.Playback.deleted == False).update({'deleted': True,
         'last_modified': int_timestamp_default()}, False)
        updated = pldb.Session.query(pldb.Playback).filter(pldb.Playback.device_ip_address.in_(ips), pldb.Playback.end >= start_timestamp, pldb.Playback.start <= end_timestamp, pldb.Playback.merge_error_code != CODE_PLAYBACK_CREATED_FROM_SMPTE, pldb.Playback.merge_error_code != None).update({'merge_error_code': None,
         'last_modified': int_timestamp_default()}, False)
        pldb.Session.commit()
        return (nullified_mappings, updated, deleted)

    def playback_groups(self, modified_after = 0, chunk_size = 0):
        """
        Returns a collection of uuids modified after :param modified_after:,
        grouped together by their last_modified time, the number of groups being
        determined by chunk_size.
        
        :param modified_after:  Integer timestamp of the lowest possible
                                last_modified timestamp requested.
        
        :param chunk_size:      The amount of groups we should return.
        
        :returns:               List in the form:
            [
                {
                    "last_modified": "1395240310",
                    "uuids": ["24970bc0-af75-11e3-a5e2-0800200c9a66"]
                },
                {
                    "last_modified": "1395240316",
                    "uuids": ["456afa00-af75-11e3-a5e2-0800200c9a66",
                              "4c227d50-af75-11e3-a5e2-0800200c9a66"]
                },
                {
                    "last_modified": "1395240317",
                    "uuids": ["57811a80-af75-11e3-a5e2-0800200c9a66"]
                },
                {
                    "last_modified": "1395240320",
                    "uuids": ["5b5776e0-af75-11e3-a5e2-0800200c9a66",
                              "62e62050-af75-11e3-a5e2-0800200c9a66",
                              "6762a7c0-af75-11e3-a5e2-0800200c9a66"]
                }
            ]
        """
        playback_groups = pldb.Session.query(pldb.Playback.last_modified, func.array_agg(pldb.Playback.uuid).label('uuids')).filter(pldb.Playback.last_modified >= modified_after).group_by(pldb.Playback.last_modified).order_by(pldb.Playback.last_modified)
        if chunk_size > 0:
            playback_groups = playback_groups.limit(chunk_size)
        self.producer_newest_playback_datetime = datetime.fromtimestamp(modified_after)
        if self.producer_newest_playback_datetime < EARLIEST_PRODUCER_TIME:
            self.producer_newest_playback_datetime = EARLIEST_PRODUCER_TIME
        return [ {'last_modified': p.last_modified,
         'uuids': p.uuids} for p in playback_groups.all() ]

    @pldb.close_session
    def log_files(self, modified_after = 0, chunk_size = 0, include_raw = False):
        """
        Returns a list of log files as dictionaries modified after given time.
        
        :param modified_after:  (int) Timestamp log files have been modified after.
        :param chunk_size:      (int) Maximum number of log files to fetch.
        :param include_raw:     (bool) Whether to include raw xml log data.
        
        :returns: (log_files, messages)
        """
        log_files = pldb.Session.query(pldb.LogFile).filter(pldb.LogFile.last_modified > modified_after).order_by(pldb.LogFile.last_modified)
        if chunk_size > 0:
            log_files = log_files.limit(chunk_size)
        log_files, messages = self._prepare_log_files(log_files, include_raw)
        return (log_files.values(), messages)

    @pldb.close_session
    def log_files_by_uuid(self, log_file_uuids):
        """
        Returns a dictionary of log files given by UUIDs
        including raw xml log data.
        
        :param log_file_uuids:  (list) LogFile UUIDs to fetch.
        
        :returns: (log_files, messages)
        """
        log_files = []
        messages = []
        for log_file_uuid in log_file_uuids:
            try:
                log_file = pldb.Session.query(pldb.LogFile).filter(pldb.LogFile.uuid == log_file_uuid).one()
                log_files.append(log_file)
            except NoResultFound:
                messages.append({'type': 'error',
                 'log_file_uuid': log_file_uuid,
                 'message': 'Log file entry not found in system.'})
                continue

        log_files, _messages = self._prepare_log_files(log_files, True)
        messages.extend(_messages)
        return (log_files, messages)

    def _prepare_log_files(self, log_files, include_raw):
        """
        Format a list of log files and include raw xml log data if requested.
        
        :param log_files:   (list) List of LogFile objects.
        :param include_raw: (bool) Whether to include raw xml log data.
        
        :returns: (data, messages)
            data - Dictionary of log files keyed by LogFile UUID.
            messages - List of error/warning messages.
        """
        messages = []
        data = {}
        for log_file in log_files:
            data[log_file.uuid] = {'uuid': log_file.uuid,
             'created': log_file.created,
             'last_modified': log_file.last_modified,
             'date': log_file.date.strftime('%Y-%m-%d'),
             'screen_identifier': log_file.screen_identifier,
             'dnqualifier': log_file.dnqualifier,
             'serial': log_file.serial,
             'device_ip_address': log_file.device_ip_address,
             'unencrypted': log_file.unencrypted,
             'pull_attempted': log_file.pull_attempted,
             'pulled': log_file.pulled,
             'parse_attempted': log_file.parse_attempted,
             'parsed': log_file.parsed,
             'repull_marked': log_file.repull_marked,
             'absolute_file_path': log_file.absolute_file_path,
             'error_message': log_file.error_message,
             'no_playouts': log_file.no_playouts,
             'signed': log_file.signed}
            if include_raw:
                data[log_file.uuid]['xml'] = None
            if include_raw and log_file.absolute_file_path:
                if os.path.exists(log_file.absolute_file_path):
                    try:
                        zp = zipfile.ZipFile(log_file.absolute_file_path)
                        for zip_asset in zp.namelist():
                            data[log_file.uuid]['xml'] = zp.open(zip_asset).read()

                        zp.close()
                    except Exception:
                        msg = 'There was a problem opening the log file [%(absolute_file_path)s]' % {'absolute_file_path': log_file.absolute_file_path}
                        logging.error(msg, exc_info=True)
                        messages.append({'type': 'error',
                         'log_file_uuid': log_file.uuid,
                         'message': msg})

                else:
                    msg = 'Log file missing unexpectedly [%(absolute_file_path)s]' % {'absolute_file_path': log_file.absolute_file_path}
                    logging.error(msg, exc_info=True)
                    messages.append({'type': 'error',
                     'log_file_uuid': log_file.uuid,
                     'message': msg})

        return (data, messages)

    @pldb.close_session
    def log_file_groups(self, modified_after = 0, chunk_size = 0):
        log_file_groups = pldb.Session.query(pldb.LogFile.last_modified, func.array_agg(pldb.LogFile.uuid).label('uuids')).filter(pldb.LogFile.last_modified >= modified_after).group_by(pldb.LogFile.last_modified).order_by(pldb.LogFile.last_modified)
        if chunk_size > 0:
            log_file_groups = log_file_groups.limit(chunk_size)
        return [ {'last_modified': g.last_modified,
         'uuids': g.uuids} for g in log_file_groups ]
# okay decompyling ./core/services/logging_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:13 CST
