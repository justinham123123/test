# 2017.08.13 21:50:14 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\messaging_service.py
import abc
import datetime
import logging
import smtplib
import ssl
from threading import Thread
import time
from sleekxmpp.clientxmpp import ClientXMPP
from sqlalchemy.orm.exc import NoResultFound
from lib.openfire import UserService
from lib.sleekxmpp.exceptions import IqError
from serv.configuration import cfg
from serv.core import VERSION
from serv.core.services.base_service import Service
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities import config
from serv.storage.database.primary import database as db

class BaseChatClient(object):
    __metaclass__ = abc.ABCMeta

    def __init__(self, *args, **kwargs):
        self.conversations = {}
        self.load_conversations()

    def load_conversations(self):
        for message in db.Session.query(db.Message).order_by(db.Message.recieved_time.desc()):
            conversation = self.get_conversation(message.jid)
            conversation['messages'].append({'body': message.body,
             'sent': message.sent,
             'time': message.recieved_time,
             'success': message.success})
            if message.unread:
                conversation['unread'] += 1
            if message.recieved_time > conversation['last']:
                conversation['last'] = message.recieved_time

    def get_conversation(self, username):
        return self.conversations.setdefault(username, {'messages': [],
         'unread': 0,
         'last': 0})

    @abc.abstractmethod
    def get_connected(self):
        pass

    @abc.abstractmethod
    def kill(self):
        pass

    @abc.abstractmethod
    def send_msg(self, to, body):
        pass

    @abc.abstractmethod
    def get_roster_(self):
        pass

    @abc.abstractmethod
    def get_status(self):
        pass

    def get_unread_roster_count(self):
        count = 0
        for contact in self.get_roster_():
            if contact['unread'] > 0:
                count += 1

        return count

    def get_unread_conversations(self):
        unread = {}
        for contact in self.get_roster_():
            if contact['unread'] > 0:
                unread[contact['username']] = contact['unread']

        return unread

    def store_message(self, username, msg, ts = None, sent = False, success = True):
        if ts is None:
            ts = str(time.time())
        conversation = self.get_conversation(username)
        conversation['messages'].append({'body': msg,
         'sent': sent,
         'time': ts,
         'success': success})
        if ts > conversation['last']:
            conversation['last'] = ts
        unicode_msg = msg.decode('utf-8')
        if not sent:
            conversation['unread'] += 1
        db_message = db.Message()
        db_message.jid = username
        db_message.body = unicode_msg
        db_message.recieved_time = ts
        db_message.sent = sent
        db_message.success = success
        db.Session.add(db_message)
        db.Session.commit()
        return


class OfflineChatClient(BaseChatClient):

    def __init__(self):
        super(OfflineChatClient, self).__init__()
        self.support_contact = {'username': 'support',
         'name': _('Email Support'),
         'unread': 0,
         'last': 0}

    def send_msg(self, to, body):
        success = self.send_email('TMS Chat Message', 'Offline Chat', body)
        self.store_message(to, body, sent=True, success=success)

    def get_roster_(self):
        return [self.support_contact]

    def kill(self):
        pass

    def get_connected(self):
        return True

    def get_status(self):
        return [('live', False)]

    def send_email(self, title, author, body):
        """
        Sends the email to TMS feedback email address specified in the config.
        
        title = title,
        author = author,
        body = body
        
        """
        toaddrs = [ x.replace(' ', '') for x in cfg.core_chat_email_to.get().split(',') if x.replace(' ', '') != '' ]
        ccaddrs = [ x.replace(' ', '') for x in cfg.core_chat_email_cc.get().split(',') if x.replace(' ', '') != '' ]
        if len(toaddrs) + len(ccaddrs) == 0:
            logging.error('No valid email recipients')
            return False
        else:
            fromaddr = cfg.core_chat_email_from.get()
            chat_email_server = cfg.core_chat_email_server.get()
            chat_email_port = cfg.core_chat_email_port.get()
            build_version = str(VERSION['major']) + '.' + str(VERSION['minor']) + '.' + str(VERSION['build'])
            subject = '%s [%s] %s - %s' % (cfg.complex_name.get(),
             cfg.cherry_host.get(),
             build_version,
             title)
            msg = '%s : %s\r\n\r\n%s\r\n\r\n' % (author, datetime.datetime.now().strftime('%H:%M, %a, %d %b %Y'), body)
            server = None
            try:
                server = smtplib.SMTP(chat_email_server, chat_email_port)
                server.set_debuglevel(1)
                server.sendmail(fromaddr, toaddrs + ccaddrs, 'To: %s\r\nCC: %s\r\nSubject:%s\r\n\r\n%s' % (','.join(toaddrs),
                 ','.join(ccaddrs),
                 subject,
                 msg))
                return True
            except Exception as e:
                logging.info('Sending chat email failed %s' % e, exc_info=True)
                return False
            finally:
                if server is not None:
                    server.quit()

            return


class LiveChatClient(Thread, ClientXMPP, BaseChatClient):

    def __init__(self, username, circuits = []):
        self.server_cfg = (cfg.core_chat_server_ip(), cfg.core_chat_server_port())
        self.server_name = cfg.core_chat_server_name()
        jid, password = self.gen_login(username)
        BaseChatClient.__init__(self)
        ClientXMPP.__init__(self, jid, password)
        Thread.__init__(self)
        self.registered = False
        self.ssl_version = ssl.PROTOCOL_SSLv3
        self.add_event_handler('connected', self.session_connect)
        self.add_event_handler('session_start', self.session_start)
        self.add_event_handler('message', self.message_handler)
        self.add_event_handler('failed_auth', self.failed_auth)
        self.add_event_handler('disconnected', self.session_disconnect)
        self.groups = ['screenwriter_users']
        self.groups.extend(circuits)
        self.start()

    def run(self):
        self.connect(self.server_cfg, reattempt=False)
        self.process(block=True)

    def gen_login(self, username):
        jid = '%s@%s/tms' % (username, self.server_name)
        password = 'password_' + jid
        return (jid, password)

    def kill(self):
        self.disconnect()
        self.abort()

    def session_connect(self, *args, **kwargs):
        url = 'http://%s:%s/' % (self.server_cfg[0], 9090)
        self.openfire = UserService(url, 'secret')

    def session_disconnect(self, *args, **kwargs):
        pass

    def failed_auth(self, something):
        self.registered = False
        self.register()

    def session_start(self, event):
        try:
            self.openfire.update_user(self.boundjid.username, self.password, groups=self.groups)
        except:
            logging.error('Failed to update user groups')

        self.send_presence()
        self.get_roster(callback=self.roster_updated)
        self.registered = True

    def register(self):
        try:
            self.openfire.add_user(self.boundjid.username, self.password, name=self.boundjid.username, groups=self.groups)
        except Exception as e:
            logging.error('Could not register account: %s' % e)

    def get_connected(self):
        return self.state.current_state() == 'connected'

    def get_status(self):
        re = [('live', True),
         ('connected', self.get_connected()),
         ('registered', self.registered),
         ('authenticated', self.authenticated)]
        return re

    def roster_updated(self, roster):
        db_roster = db.Session.query(db.ProducerComplex).filter(db.ProducerComplex.current == False).all()
        for contact in db_roster:
            if contact.name not in roster:
                self.add_to_roster(contact.name)

    def send_msg(self, to, body):
        success = True
        if self.get_connected():
            jid = '%s@%s' % (to, self.server_name)
            self.send_message(mto=jid, mbody=body, mtype='chat')
        else:
            success = False
        self.store_message(to, body, sent=True, success=success)

    def add_to_roster(self, username):
        jid = '%s@%s' % (username, self.server_name)
        try:
            self.update_roster(jid, name=username)
        except IqError as e:
            logging.error('Error adding %s to roster: %s' % (jid, e))

    def get_roster_(self):
        if self.get_connected():
            return self.get_live_roster()
        else:
            return []

    def get_live_roster(self):
        re = []
        for jid in self.client_roster.keys():
            if jid == self.boundjid.bare:
                continue
            username = jid.split('@')[0]
            conversation = self.get_conversation(username)
            re.append({'username': username,
             'name': self.client_roster[jid]['name'],
             'unread': conversation['unread'],
             'last': conversation['last']})

        return re

    def message_handler(self, msg):
        if msg['type'] in ('chat', 'normal'):
            self.store_message(msg.get_from().username, str(msg['body']))


class MessagingService(Service):

    def __init__(self, core):
        super(MessagingService, self).__init__(core)
        self.client = None
        self.live_client = None
        self.offline_client = None
        self.timer = None
        return

    def start(self):
        username = None
        try:
            username = db.Session.query(db.ProducerComplex).filter(db.ProducerComplex.current == True).one().name
        except NoResultFound:
            pass

        self.start_chat_client(username)
        return

    def start_chat_client(self, username = None):
        self.client = self.offline_client = OfflineChatClient()
        try:
            if cfg.core_chat_live_enabled() and username:
                if self.live_client:
                    self.live_client.kill()
                self.live_client = LiveChatClient(username)

                def start(*args, **kwargs):
                    self.client = self.live_client

                def stop(*args, **kwargs):
                    self.client = self.offline_client

                self.live_client.add_event_handler('session_start', start)
                self.live_client.add_event_handler('disconnected', stop)
        except Exception as e:
            logging.error('Error starting live chat client: %s' % str(e))

    def get_settings(self):
        re = {'email_server': cfg.core_chat_email_server(),
         'email_port': cfg.core_chat_email_port(),
         'chat_server_name': cfg.core_chat_server_name(),
         'chat_server_ip': cfg.core_chat_server_ip(),
         'chat_server_port': cfg.core_chat_server_port(),
         'chat_enabled': cfg.core_chat_live_enabled()}
        return re

    def set_settings(self, email_server = None, email_port = None, chat_server_name = None, chat_server_ip = None, chat_server_port = None, chat_enabled = None):
        if email_server:
            cfg.core_chat_email_server.set(email_server)
        if email_port:
            cfg.core_chat_email_port.set(email_port)
        if chat_server_ip:
            cfg.core_chat_server_ip.set(chat_server_ip)
        if chat_server_name:
            cfg.core_chat_server_name.set(chat_server_name)
        if chat_server_port:
            cfg.core_chat_server_port.set(chat_server_port)
        if chat_enabled:
            cfg.core_chat_live_enabled.set(chat_enabled)
        config.save()
        self.start()
        return {'messages': [{'type': 'success',
                       'message': _('Saved')}],
         'data': {}}

    def status(self):
        data = {'status': {},
         'unread': {}}
        data['unread'] = self.client.get_unread_conversations()
        data['status'] = self.client.get_status()
        re = {'messages': [],
         'data': data}
        return re

    def get_roster(self):
        roster = self.client.get_roster_()
        roster = sorted(roster, key=lambda x: x['last'], reverse=True)
        return {'messages': [],
         'data': {'roster': roster}}

    def get_conversation(self, username):
        conversation = self.client.get_conversation(username)
        conversation['messages'] = sorted(conversation['messages'], key=lambda x: x['time'])
        conversation['unread'] = 0
        return {'messages': [],
         'data': {'messages': conversation['messages']}}

    def send_message(self, username, body):
        self.client.send_msg(username, body)
        if username == 'support' and isinstance(self.client, LiveChatClient):
            self.offline_client.send_msg(username, body)
        return {'messages': [{'type': 'success',
                       'message': _('Message sent')}],
         'data': {}}

    def update_complexes(self, complexes):
        delete_complexes = []
        add_update_complexes = []
        external_complexes = {}
        for complex in complexes:
            external_complexes[complex['external_id']] = {'name': complex['name'].replace(' ', ''),
             'current': complex['current']}

        db_complexes = db.Session.query(db.ProducerComplex).all()
        for db_complex in db_complexes:
            if db_complex.external_id in external_complexes:
                if external_complexes[db_complex.external_id]['name'] != db_complex.name:
                    add_update_complexes.append({'name': external_complexes[db_complex.external_id]['name'],
                     'external_id': db_complex.external_id,
                     'current': external_complexes[db_complex.external_id]['current']})
                    if external_complexes[db_complex.external_id]['current']:
                        self.start_chat_client(external_complexes[db_complex.external_id]['name'])
                del external_complexes[db_complex.external_id]
            else:
                delete_complexes.append(db_complex.external_id)

        for external_id, data in external_complexes.iteritems():
            add_update_complexes.append({'name': data['name'],
             'external_id': external_id,
             'current': data['current']})
            if data['current']:
                self.start_chat_client(data['name'])

        if len(delete_complexes) > 0:
            db.Session.query(db.ProducerComplex).filter(db.ProducerComplex.external_id.in_(delete_complexes)).delete(False)
        for add_update in add_update_complexes:
            pc = db.ProducerComplex(external_id=add_update['external_id'], name=add_update['name'], current=add_update['current'])
            db.Session.merge(pc)

        db.Session.commit()
        return {'type': 'success',
         'message': _('Producer Complexes have been added')}
# okay decompyling ./core/services/messaging_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:15 CST
