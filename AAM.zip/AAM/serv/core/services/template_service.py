# 2017.08.13 21:50:56 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\template_service.py
from datetime import datetime
from serv.lib.utilities import date_utils
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.lib.utilities import config
from serv.lib.utilities.helper_methods import audit_log
from serv.core.services.base_service import Service
from serv.core.devices.content.aamLMS.plugins.copy_plugins import create_dir
import logging
import time
import uuid
import os
import json
import shutil

class TemplateService(Service):

    def delete(self, template_ids):
        """Deletes specified templates and returns messages"""
        lms = self.core.get_lms_id()
        messages = []
        for uuid in template_ids:
            if uuid in self.core.devices[lms].content_store['templates']:
                template = self.core.devices[lms].content_store['templates'][uuid]
                template_name = template['name']
                full_path = os.path.join(self.core.devices[lms].storage_configuration['template_folder'], uuid)
                with self.core.devices[lms].content_store_lock:
                    del self.core.devices[lms].content_store['templates'][uuid]
                if os.path.exists(full_path):
                    shutil.rmtree(full_path)
                logging.info('Deleted template [%s] [%s]' % (template_name, uuid))
                audit_log('Template deleted: {template:template}', meta={'template': template}, tags=['template', 'delete'])
                messages.append({'message': _('Deleted: %s') % template_name,
                 'type': 'success',
                 'template_uuid': uuid})
            else:
                messages.append({'message': _('Item does not exist'),
                 'type': 'error',
                 'template_uuid': uuid})

        self._assert_template_config()
        return messages

    def save(self, templates):
        """Saves a template/s and returns a message"""
        lms = self.core.get_lms_id()
        messages = []
        uuids = []
        for template in templates:
            if not template['uuid']:
                template['uuid'] = str(uuid.uuid4())
                template['created'] = time.time()
            elif self.core.devices[lms].content_store['templates'].has_key(template['uuid']):
                template['created'] = self.core.devices[lms].content_store['templates'][template['uuid']]['created']
            template['last_modified'] = time.time()
            full_path = os.path.join(self.core.devices[lms].storage_configuration['template_folder'], template['uuid'], template['uuid'] + '.json')
            create_dir(full_path)
            with open(full_path, 'w') as template_file:
                template_file.write(json.dumps(template))
            with self.core.devices[lms].content_store_lock:
                self.core.devices[lms].content_store['templates'][template['uuid']] = template
            uuids.append(template['uuid'])
            audit_log('Template saved: {template:template}', meta={'template': template}, tags=['template', 'save'])
            messages.append({'message': _('Saved: %s') % template['name'],
             'type': 'success'})

        if len(templates) > 0:
            cfg.core_active_template.set(templates[0]['uuid'])
            config.save()
        return (uuids, messages)

    def template(self, template_ids = [], requested_data_items = []):
        """Returns templates and any device error messages"""
        lms = self.core.get_lms_id()
        templates = self.core.devices[lms].content_store['templates']
        if template_ids:
            mod_templates = {}
            for uuid in template_ids:
                mod_templates[uuid] = templates[uuid]

            templates = mod_templates
        if requested_data_items:
            mod_templates = {}
            for uuid in templates:
                mod_templates[uuid] = {}
                for item in requested_data_items:
                    mod_templates[uuid][item] = templates[uuid][item]

            templates = mod_templates
        self._assert_template_config()
        messages = []
        return (templates, messages)

    def _assert_template_config(self):
        template_hash = self.core.devices[self.core.get_lms_id()].content_store['templates']
        cfg_value = cfg.core_active_template.get()
        if not cfg_value or not template_hash.has_key(cfg_value):
            if len(template_hash.keys()) > 0:
                for uuid in template_hash:
                    cfg.core_active_template.set(uuid)
                    break

            else:
                cfg.core_active_template.set('')
            config.save()

    def set_active(self, template_uuid):
        cfg.core_active_template.set(template_uuid)
        config.save()
        template = self.core.devices[self.core.get_lms_id()].content_store['templates'][template_uuid]
        audit_log('Template activated: {template:template}', meta={'template': template}, tags=['template', 'modified'])
        return {'message': _('Activated: %s') % template['name'],
         'type': 'success'}

    def get_active(self):
        self._assert_template_config()
        return self.core.devices[self.core.get_lms_id()].content_store['templates'].get(cfg.core_active_template.get())
# okay decompyling ./core/services/template_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:56 CST
