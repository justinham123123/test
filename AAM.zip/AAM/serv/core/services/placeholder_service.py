# 2017.08.13 21:50:21 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\placeholder_service.py
import logging
import uuid
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities.natsort import natsorted
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import or_, func

class PlaceholderService(Service):

    def last_modified(self):
        placeholders = db.Session.query(db.Placeholder)
        return dict(((placeholder.uuid, placeholder.last_modified) for placeholder in placeholders))

    def placeholders(self, placeholder_uuids = [], titles = False, sorted_list = False):
        placeholders = db.Session.query(db.Placeholder)
        if placeholder_uuids:
            placeholders = placeholders.filter(db.Placeholder.uuid.in_(placeholder_uuids))
        placeholders_info = {}
        for placeholder in placeholders:
            placeholders_info[placeholder.uuid] = {'name': placeholder.name,
             'uuid': placeholder.uuid,
             'type': 'content_placeholder'}

        feature_placeholder_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, str('Feature')))
        if titles and (placeholder_uuids == [] or feature_placeholder_id in placeholder_uuids):
            placeholders_info[feature_placeholder_id] = {'name': 'Feature',
             'uuid': feature_placeholder_id,
             'type': 'title_placeholder'}
        if sorted_list is True:
            placeholders_info = natsorted(placeholders_info.itervalues(), key=lambda k: k['name'])
        return placeholders_info

    def save(self, placeholders):
        overwritten_placeholder_uuids = {}
        for placeholder in placeholders:
            if 'uuid' not in placeholder:
                placeholder['uuid'] = str(uuid.uuid4())
            try:
                core_placeholder = db.Session.query(db.Placeholder).filter(or_(db.Placeholder.uuid == placeholder['uuid'], func.lower(db.Placeholder.name) == func.lower(placeholder['name']))).one()
            except NoResultFound:
                core_placeholder = db.Placeholder(uuid=placeholder['uuid'])
                db.Session.add(core_placeholder)
            else:
                if core_placeholder.uuid != placeholder['uuid']:
                    overwritten_placeholder_uuids[str(core_placeholder.uuid)] = str(placeholder['uuid'])
                    core_placeholder.uuid = placeholder['uuid']

            core_placeholder.name = placeholder['name']
            core_placeholder.set_modified(placeholder.get('last_modified', None))

        db.Session.commit()
        self._propagate_overwritten_uuids(overwritten_placeholder_uuids)
        return {'type': 'success',
         'message': _('Saved: [%s]') % ','.join([ x['name'] for x in placeholders ])}

    def delete(self, placeholder_uuids):
        if db.Session.query(db.Pack).filter(db.Pack.placeholder_uuid.in_(placeholder_uuids)).count():
            return {'type': 'error',
             'message': _('Pack references placeholder, cannot delete')}
        lms_id = self.core.get_lms_id()
        self.core.devices[self.core.get_lms_id()].get_playlist_uuid_list()
        lms_playlists = self.core.devices[lms_id].get_playlist_information(self.core.devices[lms_id].get_playlist_uuid_list()['playlist_uuid_list'])['playlist_info_dict']
        for playlist_uuid in lms_playlists:
            playlist_events = lms_playlists[playlist_uuid]['playlist']['events']
            for plevent in playlist_events:
                try:
                    if plevent['type'] == 'content_placeholder' or plevent['type'] == 'placeholder':
                        if plevent['uuid'] in placeholder_uuids:
                            return {'type': 'error',
                             'message': _('Playlist references placeholder, cannot delete')}
                except KeyError as e:
                    logging.error(str(e))

        placeholders = db.Session.query(db.Placeholder).filter(db.Placeholder.uuid.in_(placeholder_uuids))
        placeholders.delete(False)
        db.Session.commit()
        return {'type': 'success',
         'message': _('Deleted')}

    def _propagate_overwritten_uuids(self, overwritten_placeholder_uuids):
        for pack in db.Session.query(db.Pack).filter(db.Pack.placeholder_uuid.in_(overwritten_placeholder_uuids.keys())).all():
            new_uuid = overwritten_placeholder_uuids[pack.placeholder_uuid]
            pack.placeholder_uuid = new_uuid

        db.Session.commit()
        playlists = self.core.playlist_service.playlist(device_ids=[self.core.get_lms_id()])[0][self.core.get_lms_id()]
        for playlist_uuid in playlists:
            changed = False
            playlist = playlists[playlist_uuid]['playlist']
            if playlists[playlist_uuid].get('is_template'):
                for event in playlist['events']:
                    if event.get('type') == 'placeholder':
                        if overwritten_placeholder_uuids.has_key(event.get('uuid')):
                            event['uuid'] = overwritten_placeholder_uuids[event['uuid']]
                            changed = True

            if changed:
                self.core.playlist_service.save(self.core.get_lms_id(), playlist)
# okay decompyling ./core/services/placeholder_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:23 CST
