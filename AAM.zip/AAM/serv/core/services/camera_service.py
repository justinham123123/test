# 2017.08.13 21:50:03 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\camera_service.py
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.services.base_service import Service

class CameraService(Service):

    def get_image(self, device_uuid):
        return self.core.devices[device_uuid].get_stored_image()

    def save_image(self, device_id, image):
        self.core.devices[device_id].store_external_image(image)
        return {'type': 'success',
         'message': _('Saved')}
# okay decompyling ./core/services/camera_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:03 CST
