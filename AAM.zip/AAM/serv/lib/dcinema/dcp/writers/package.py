# 2017.08.13 21:51:47 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\writers\package.py
"""
DCP Package dcp_creation.

Provides:  write_DCP()    -  creates a new DCP using the supplied information

changelog
    - added dcp_creation.py  (for generating DCP XML)
    - removed jinja templating
    - general cleanup
    - split into interop & SMPTE outputs
"""
import os.path
import logging
import shutil
from serv.lib.dcinema.dcp.writers.helpers import new_uuid
from serv.lib.dcinema.dcp.writers.helpers import sha_digest
from serv.lib.utilities.linking import create_hard_link
from serv.lib.dcinema.dcp.writers import smpte_dcp
from serv.lib.dcinema.dcp.writers import interop_dcp

def write_DCP(package_dict, target_folder, include_assets = True, SMPTE_compliant = False, link = False):
    """ Creates a new DCP package in a subfolder under the target folder, containing copies/links of all the required assets and XML comprising the package.
    :param package_dict: dictionary of information required to create the new DCP
    :param target_folder: folder path for storing the new DCP DCP will be placed under a subfolder named on CPL ID.
    :param include_assets: flag to copy/link assets into the DCP (default, True) or CPL only (False).
    :param SMPTE_compliant: False: (Default) Interop DCP create, True: SMPTE compliant output)
    :param link: False (Default): Assets and existing XMLs are copied into the target Folder
                 True:   Use filesystem hard linkinking instead of copying
    :returns: a tuple consisting of the newly created DCP/CPL id, and a list of the files in the package
    
    IMPORTANT
    Note: if a folder with the same Package ID already exists in the target
    folder, then it will be deleted.
    """
    if not target_folder:
        raise AssertionError, 'Target folder must be specified'
        dcp_data_dict = _package_DCP(package_dict, include_assets, SMPTE_compliant)
        logging.debug('Finished packaging DCP')
        package_id = dcp_data_dict['cpl']['id']
        dcp_folder = os.path.join(target_folder, package_dict['cpl_name'])
        logging.debug('New DCP CPL ID: {0}  - new folder: {1}'.format(package_id, dcp_folder))
        os.path.exists(dcp_folder) and shutil.rmtree(dcp_folder)
    return (package_id, _store_DCP(dcp_data_dict, dcp_folder, link))


def _package_DCP(package_dict, include_assets = True, SMPTE_compliant = False):
    r"""
    Generates DCP related XML (e.g. ASSETMAP, CPL, PKL) using the supplied data
    :param package_dict: dictionary of information required to create the new DCP
    :param include_assets: flag to copy/link assets into the DCP (default, True) or CPL only (False).
    :param SMPTE_compliant: False: (Default) Interop DCP create, True: SMPTE compliant output)
    :returns :
        dictionary containing xml files and list of related asset file paths:
            dict(
                assetmap  = {'filename' : 'ASSETMAP',
                             'content'  : '<xml>...' },
                pkl       = {'filename' : 'pkl.xml',
                             'content'  : '<xml>...' },
                cpl       = {'filename' : '<cpl_uuid>.xml',
                             'content'  : '<xml>...'
                             'id':      : '<uuid>',
                             },
    
                file_list = [
                    {'fullpath' : 'C:\Path\myfile1.mxf', 'path' : 'myfile1.mxf'},
                    {'fullpath' : 'C:\Path\myfile2.mxf', 'path' : 'myfile2.mxf'},
                    ...
                ]
            )
    
    IMPORTANT
        Assumes package_dict contains information relvant to the SMPTE
        or InterOp, and does not validate this date is suitable.
    
        This method is adapted from Ronan Delacroix's code,  and
        modified to work on the AAM TMS.
    """
    logging.debug('Packaging DCP')
    cpl_id = new_uuid()
    cpl = dict(id=cpl_id, text=package_dict['cpl_name'], type=package_dict['type'], issue_date=package_dict['issue_date'], reels=package_dict['reels'], namespaces=package_dict['namespace_dict'])
    cpl_xml = smpte_dcp.create_cpl(cpl) if SMPTE_compliant else interop_dcp.create_cpl(cpl)
    logging.debug('Created CPL xml')
    cpl_filename = cpl_id + '.xml'
    if include_assets:
        file_list = package_dict['file_list']
        file_list = filter(lambda x: (x if 'exists' in x and x['exists'] is True else None), file_list)
    else:
        file_list = []
    filepath_list = []
    for asset_file in file_list:
        filepath_list.append({'fullpath': asset_file['fullpath'],
         'path': asset_file['path']})

    cpl_hash = sha_digest(cpl_xml)
    cpl_size = len(cpl_xml)
    file_list.append({'id': cpl_id,
     'hash': cpl_hash,
     'size': cpl_size,
     'type': 'text/xml;asdcpKind=CPL',
     'originalfilename': cpl_filename,
     'path': cpl_filename})
    pkl_id = new_uuid()
    pkl = dict(id=pkl_id, text=package_dict['text'], issue_date=package_dict['issue_date'], file_list=file_list)
    pkl_filename = 'pkl.xml'
    pkl_xml = smpte_dcp.create_pkl(pkl) if SMPTE_compliant else interop_dcp.create_pkl(pkl)
    logging.debug('Created PKL')
    file_list.append({'id': pkl_id,
     'hash': sha_digest(pkl_xml),
     'size': len(pkl_xml),
     'type': 'text/xml;asdcpKind=PKL',
     'originalfilename': pkl_filename,
     'path': pkl_filename})
    assetmap_id = new_uuid()
    assetmap = dict(id=assetmap_id, issue_date=package_dict['issue_date'], file_list=file_list)
    assetmap_xml = smpte_dcp.assetmap_xml(assetmap) if SMPTE_compliant else interop_dcp.create_assetmap(assetmap)
    logging.debug('Created AssetMap xml')
    vol_index_xml = create_volumeindex_xml()
    logging.debug('Created VOLINDEX xml')
    return dict(assetmap={'filename': 'ASSETMAP',
     'content': assetmap_xml}, pkl={'filename': pkl_filename,
     'content': pkl_xml}, cpl={'filename': cpl_filename,
     'content': cpl_xml,
     'id': cpl_id}, vol={'filename': 'VOLINDEX',
     'content': vol_index_xml}, file_list=filepath_list)


def _store_DCP(xmls, output_path, link = False):
    """store_dcp creates the files for a dcp described by a dictionary (result of function package_dcp)
    :param xmls : dictionary, result of function package_dcp
    :param output_path : folder path that will be created
    :param link: False: Default - Assets and existing XMLs are copied into the target Folder
                 True: Use filesystem hard linkinking instead of copying
    :returns: list of files in the package
    """
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    else:
        raise os.path.isdir(output_path) or AssertionError, '%s should be a valid folder'
    logging.debug('Storing DCP')
    result_file_list = []
    logging.debug('Writing XML files')
    for xml_type in ['cpl',
     'pkl',
     'assetmap',
     'vol']:
        filename = xmls[xml_type]['filename']
        content = xmls[xml_type]['content']
        output_file = os.path.join(output_path, filename)
        with open(output_file, 'wb') as f:
            f.write(content)
        result_file_list.append(output_file)

    logging.debug('Writing Asset files. Using HardLinks: ' + str(link))
    for asset in xmls['file_list']:
        full_path = asset['fullpath']
        relative_path = asset['path']
        filename = os.path.split(relative_path)[1]
        output_filepath = os.path.join(output_path, relative_path)
        output_folderpath = os.path.split(output_filepath)[0]
        if not os.path.isdir(output_folderpath):
            os.makedirs(output_folderpath)
        if link and not os.path.exists(output_filepath):
            create_hard_link(full_path, output_filepath)
        elif not os.path.exists(output_filepath):
            shutil.copy(full_path, output_filepath)
        result_file_list.append(output_filepath)

    return result_file_list


def create_volumeindex_xml():
    """returns generic SMPTE volume index
    """
    return '\n    <?xml version="1.0" encoding="UTF-8"?>\n    <VolumeIndex xmlns="http://www.smpte-ra.org/schemas/429-9/2007/AM">\n    <Index>1</Index>\n    </VolumeIndex>\n    '
# okay decompyling ./lib/dcinema/dcp/writers/package.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:48 CST
