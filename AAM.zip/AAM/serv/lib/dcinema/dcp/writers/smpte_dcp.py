# 2017.08.13 21:51:48 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\writers\smpte_dcp.py
"""
DCP Creation utils
(c) 2013 Arts Alliance Media
description : provides methods for creating SMPTE Compliant XML for ASSETMAP,
CPL & PKL. These methods are used by the dcp repackager module.

   create_cpl()
   create_pkl()
   create_assetmap()

 Not Implemented:
 ---------------
    - Ratings - created CPL xml always contains <RatingList />
    - IconId in CPLs
    - Signer in CPLs
    - Signature in CPLs

"""
import xml.etree.cElementTree as ET
from serv.lib.dcinema.dcp.writers.helpers import DEFAULT_CREATOR_LABEL
from serv.lib.dcinema.dcp.writers.helpers import DEFAULT_ISSUER_LABEL
from serv.lib.dcinema.dcp.writers.helpers import create_child_element

def create_cpl(data):
    """Creates CPL XML using the supplied dictionary
    :param data: a dictionary containing the required information
    :returns: a string containing the CPL XML
    
    data format:
    
        {
            'id':    "<cpl uuid>",
            'text':  "<used for both ContentTitleText & AnnotationText>",
            'issue_date': "<IssueDate>",
            'issuer':   "<Issuer, default: DEFAULT_ISSUER_LABEL">,
            'creator':  "<Creator, default: DEFAULT_CREATOR_LABEL">,
             'type' :  "<ContentKind>",
             'reels': [
                {
                    'asset_list': {
                            <'assettype, e.g. MainPicture>': {
                                    .. properties ...
                                    eg. 'Duration': 12,
                            }
                    }
                }, ...
             ]
        }
    
    For properties of the assets, see the requirements of the methods below:
            main_markers_asset()
            main_picture_track_asset()
            main_sound_track_asset()
            subtitle_track_asset()
            track_asset()
            generic_asset()
    
    Not supported:  RatingList, Signer, Signature
    """

    def main_markers_asset(parent, properties):
        """
        Id                   - UUID, required
        AnnotationText       - str, optional
        EditRate             - rational, required
        IntrinsicDuration    - long, required
        entry_point          - long, optional
        Duration             -  long, optional
        Markers [{ .. }, ..]
            Label  -  string, required
            AnnotationText - string, optional
            Offset - integer, required
        """
        el = generic_asset(parent, 'MainMarkers', properties)
        markers_list = properties.get('markers_list')
        if markers_list:
            markers_list_el = ET.SubElement(el, 'MarkerList')
            for marker in markers_list:
                marker_el = ET.SubElement(markers_list_el, 'Marker')
                create_child_element(marker_el, 'Label', marker['Label'])
                if 'AnnotationText' in marker:
                    create_child_element(marker_el, 'AnnotationText', marker['Label'])
                create_child_element(marker_el, 'Offset', marker['Offset'])

        return el

    def main_picture_track_asset(parent, properties):
        """
           Id                   - UUID, required
           AnnotationText       - str, optional
           EditRate             - rational, required
           IntrinsicDuration    - long, required
           entry_point          - long, optional
           Duration             -  long, optional
           KeyId - UUID, optional
           Hash  - base64Binary, optional
           FrameRate   - Rational, Required
           ScreenAspectRatio  - Rational, Required
                   - should be in SMPTE format  (2 numbers, seperated by space)
                   e.g. 2048 1094
                   - not ratio format (e.g. 1.85) - as that is interop
        """
        el = track_asset(parent, 'MainPicture', properties)
        create_child_element(el, 'FrameRate', properties['FrameRate'])
        create_child_element(el, 'ScreenAspectRatio', properties['ScreenAspectRatio'])
        return el

    def main_sound_track_asset(parent, properties):
        """
            UUID, required
            AnnotationText       - str, optional
            EditRate             - rational, required
            IntrinsicDuration    - long, required
            entry_point          - long, optional
            Duration             -  long, optional
            KeyId - UUID, optional
            Hash  - base64Binary, optional
            Language   - language, optional
        """
        el = track_asset(parent, 'MainSound', properties)
        if 'Language' in properties:
            create_child_element(el, 'Language', properties['Language'])
        return el

    def subtitle_track_asset(parent, properties):
        """
            UUID, required
            AnnotationText       - str, optional
            EditRate             - rational, required
            IntrinsicDuration    - long, required
            entry_point          - long, optional
            Duration             -  long, optional
            KeyId - UUID, optional
            Hash  - base64Binary, optional
            Language   - language, optional
        """
        el = track_asset(parent, 'Subtitle', properties)
        if 'Language' in properties:
            create_child_element(el, 'Language', properties['Language'])
        return el

    def track_asset(parent, name, properties):
        """
            KeyId - UUID, optional
            Hash  - base64Binary, optional
        """
        el = generic_asset(parent, name, properties)
        if 'KeyId' in properties:
            create_child_element(el, 'KeyId', 'urn:uuid:' + properties['KeyId'])
        if 'Hash' in properties:
            create_child_element(el, 'Hash', properties['Hash'])
        return el

    def generic_asset(parent, name, properties):
        """
            Id                   - UUID, required
            AnnotationText       - str, optional
            EditRate             - rational, required
            IntrinsicDuration    - long, required
            entry_point          - long, optional
            Duration             -  long, optional
        """
        el = ET.SubElement(parent, name)
        ns = name.split(':')[0]
        if data.has_key('namespaces') and data['namespaces'].has_key(ns):
            el.attrib['xmlns:' + ns] = data['namespaces'][ns]
        create_child_element(el, 'Id', 'urn:uuid:' + properties['Id'])
        if 'AnnotationText' in properties:
            create_child_element(el, 'AnnotationText', properties['AnnotationText'])
        create_child_element(el, 'EditRate', properties['EditRate'])
        create_child_element(el, 'IntrinsicDuration', properties['IntrinsicDuration'])
        if 'EntryPoint' in properties:
            create_child_element(el, 'EntryPoint', properties['EntryPoint'])
        if 'Duration' in properties:
            create_child_element(el, 'Duration', properties['Duration'])
        return el

    def add_reel(parent, reel_data):
        reel_el = ET.SubElement(parent, 'Reel')
        create_child_element(reel_el, 'Id', 'urn:uuid:' + reel['id'])
        if 'text' in reel_data:
            create_child_element(reel_el, 'AnnotationText', reel_data['text'])
        assets = reel_data['asset_list']
        asset_list_el = ET.SubElement(reel_el, 'AssetList')
        for asset in assets:
            for asset_name, properties in asset.items():
                if asset_name == 'MainMarkers':
                    main_markers_asset(asset_list_el, properties)
                elif asset_name == 'MainPicture':
                    main_picture_track_asset(asset_list_el, properties)
                elif asset_name == 'MainSound':
                    main_sound_track_asset(asset_list_el, properties)
                elif asset_name == 'MainSubtitle':
                    subtitle_track_asset(asset_list_el, properties)
                else:
                    generic_asset(asset_list_el, asset_name, properties)

    root = ET.Element('CompositionPlaylist')
    root.attrib['xmlns'] = 'http://www.smpte-ra.org/schemas/429-7/2006/CPL'
    create_child_element(root, 'Id', 'urn:uuid:' + data['id'])
    create_child_element(root, 'AnnotationText', data['text'])
    create_child_element(root, 'IssueDate', data['issue_date'].strftime('%Y-%m-%dT%H:%M:%S'))
    create_child_element(root, 'Issuer', DEFAULT_ISSUER_LABEL)
    create_child_element(root, 'Creator', data.get('ceator', DEFAULT_CREATOR_LABEL))
    create_child_element(root, 'ContentTitleText', data['text'])
    create_child_element(root, 'ContentKind', data['type'])
    cv = ET.SubElement(root, 'ContentVersion')
    cv_id_text = 'urn:uri:{0}_{1}'.format(data['id'], data['issue_date'].strftime('%Y-%m-%dT%H:%M:%S'))
    create_child_element(cv, 'Id', cv_id_text)
    cv_label_text = '{0}_{1}'.format(data['id'], data['issue_date'].strftime('%Y-%m-%dT%H:%M:%S'))
    create_child_element(cv, 'LabelText', cv_label_text)
    ET.SubElement(root, 'RatingList')
    reel_list_el = ET.SubElement(root, 'ReelList')
    for reel in data.get('reels', []):
        add_reel(reel_list_el, reel)

    return ET.tostring(root, encoding='UTF-8')


def create_pkl(data):
    """Creates PKL XML using the supplied dictionary
    :param data: a dictionary containing the required information
    :returns: a string containing the PKL XML
    
    data format:
    
        {
           'id':  '<pkl uuid>',
           'text': '<AnnotationText>',
           'issue_date': <IssueDate, DateTime()>,
           'issuer':   "<Issuer, default: DEFAULT_ISSUER_LABEL">,
           'creator':  "<Creator, default: DEFAULT_CREATOR_LABEL">,
           'file_list': [
                {
                    'id':   '<uuid>',
                    'hash': '<sha base64 digest of file>',
                    'size': <file size>,
                    'type': "<file type,  e.g. cpl type is: text/xml;asdcpKind=CPL",
                    'originalfilename': '<filename>',
                    'path':  '<filename>',
                },
                ...
           ]
        }
    
    IMPORTANT
    ---------
    Note: 'file_list' should contain a reference to each CPL and asset files
    Unsupported: GroupId, Signer, ds:Signature
    """
    root = ET.Element('PackingList')
    root.attrib['xmlns'] = 'http://www.smpte-ra.org/schemas/429-8/2007/PKL'
    create_child_element(root, 'Id', 'urn:uuid:' + data['id'])
    create_child_element(root, 'AnnotationText', data['text'])
    create_child_element(root, 'IssueDate', data['issue_date'].strftime('%Y-%m-%dT%H:%M:%S'))
    create_child_element(root, 'Issuer', data.get('issuer', DEFAULT_ISSUER_LABEL))
    create_child_element(root, 'Creator', data.get('creator', DEFAULT_CREATOR_LABEL))
    asset_list = ET.SubElement(root, 'AssetList')
    for f in data.get('file_list', []):
        asset = ET.SubElement(asset_list, 'Asset')
        create_child_element(asset, 'Id', 'urn:uuid:' + f['id'])
        if 'hash' in f:
            create_child_element(asset, 'Hash', f['hash'])
        if 'size' in f:
            create_child_element(asset, 'Size', str(f['size']))
        elif 'length' in f:
            create_child_element(asset, 'Size', str(f['length']))
        if 'type' in f:
            create_child_element(asset, 'Type', str(f['type']))
        if 'originalfilename' in f:
            create_child_element(asset, 'OriginalFileName', str(f['originalfilename']))

    return ET.tostring(root, encoding='UTF-8')


def create_assetmap(data):
    """Creates AssetMap XML using the supplied dictionary
    :param data: a dictionary containing the required information
    :returns: a string containing the AssetMap XML (compliant against: SMPTE-429-9-2007-AM.xsd)
    
    data format:
    
        {
            'id':  '<assetmap uuid>',
           'creator':  "<Creator, default: DEFAULT_CREATOR_LABEL">,
        'issue_date': <IssueDate, DateTime()>,
           'issuer':   "<Issuer, default: DEFAULT_ISSUER_LABEL">,
            'file_list': [
                {
                    'id':   '<e.g. cpl_uuid or pkl_uuid>',
                    'hash': '<sha base64 digest>',
                    'size': <filesize>,
                    'type': '<file type, e.g. "text/xml;asdcpKind=CPL">'
                    'originalfilename': '<xml filename>',
                    'path':  '<xml filename>',
                },
           ]
        }
    
    IMPORTANT
    ---------
    Note: Only the PKL and CPLs within 'file_list' are curently supported.
    Note: 'file_list' should contain a reference to each CPL and the PKL
        CPL 'type' is  text/xml;asdcpKind=CPL
        PKL 'type' is  text/xml;asdcpKind=PKL
    """
    root = ET.Element('AssetMap')
    root.attrib['xmlns'] = 'http://www.smpte-ra.org/schemas/429-9/2007/AM'
    create_child_element(root, 'Id', 'urn:uuid:' + data['id'])
    create_child_element(root, 'AnnotationText', 'AAM TMS ASSETMAP - ' + data['id'])
    create_child_element(root, 'Creator', data.get('creator', DEFAULT_CREATOR_LABEL))
    create_child_element(root, 'VolumeCount', '1')
    create_child_element(root, 'IssueDate', data['issue_date'].strftime('%Y-%m-%dT%H:%M:%S'))
    create_child_element(root, 'Issuer', data.get('issuer', DEFAULT_ISSUER_LABEL))
    asset_list = ET.SubElement(root, 'AssetList')
    for f in data.get('file_list', []):
        asset = ET.SubElement(asset_list, 'Asset')
        create_child_element(asset, 'Id', 'urn:uuid:' + f['id'])
        if f['type'] == 'text/xml;asdcpKind=PKL':
            create_child_element(asset, 'PackingList', 'true')
        chunk_list = ET.SubElement(asset, 'ChunkList')
        chunk = ET.SubElement(chunk_list, 'Chunk')
        create_child_element(chunk, 'Path', f['path'])
        create_child_element(chunk, 'VolumeIndex', '1')
        create_child_element(chunk, 'Offset', '0')
        if 'size' in f:
            create_child_element(chunk, 'Length', str(f['size']))
        elif 'length' in f:
            create_child_element(chunk, 'Length', str(f['length']))

    return ET.tostring(root, encoding='UTF-8')
# okay decompyling ./lib/dcinema/dcp/writers/smpte_dcp.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:49 CST
