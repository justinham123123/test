# 2017.08.13 21:51:42 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\dcp.py
import logging
import traceback
import pdb
from xml.etree import ElementTree
from serv.lib.dcinema.dcp.utils import IGNORE_NAMESPACE_XPATH_EXPR, ParsingException, ChunkedAssetmapException, ParsingException
from serv.lib.dcinema.dcp.asset import Asset, AssetType
from serv.lib.dcinema.dcp.cpl import CPL
from serv.lib.dcinema.dcp.file_handlers import FileHandler, FTPHandler
from serv.lib.dcinema import dcp as DCP_CONSTANTS

class DCP:
    """
    A class that holds DCP information
    """

    def __init__(self, dcp_path, conn = None, logging_level = None):
        """
        Creates a new DCP object from the provided path
        """
        if conn is None:
            self.conn = FileHandler()
        else:
            self.conn = conn
        if not self.conn.exists(dcp_path):
            msg = '%s does not exist' % dcp_path
            raise IOError(msg)
        if logging_level:
            self.logging_level = logging_level
        else:
            self.logging_level = logging.DEBUG
        self.path = dcp_path
        self.assetmap_path = None
        self.errors = []
        self.assets = {}
        self.pkls = []
        self.cpls = []
        self.__analyse_dcp()
        return

    def __log(self, message):
        if message:
            logging.log(self.logging_level, message)

    def __analyse_dcp(self):
        """
        Takes a DCP package and does the following:
        * Scans the DCP for an asset map
        * Scans the asset map for the asset list
        * Determines which assets in the list are PKLs
        * Scans the PKLs to extract the CPL information
        * Scans the CPLs to find which assets each needs
        """
        self.__log('Analysing DCP: %s' % self.path)
        for possible_name in ['ASSETMAP',
         'assetmap',
         'ASSETMAP.xml',
         'ASSETMAP.XML',
         'assetmap.xml',
         'assetmap.XML']:
            if self.conn.exists(self.conn.join(self.path, possible_name)):
                self.assetmap_path = self.conn.join(self.path, possible_name)
                break

        if not self.assetmap_path:
            self.__log('No asset maps found for DCP %s' % self.path)
            self.errors.append(DCP_CONSTANTS.NOT_A_DCP)
            return
        else:
            assetmap_xml = self.conn.open(self.assetmap_path).read()
            try:
                assets_xml = ElementTree.fromstring(assetmap_xml.strip().replace('xmlns=""', ''))
            except ParsingException as ex:
                self.__log('Could not parse assetmap %s' % self.assetmap_path, exc_info=True)
                self.errors.append(DCP_CONSTANTS.NOT_A_DCP)
                return

            ns = str(assets_xml.tag).replace('{', '').replace('AssetMap', '').replace('}', '')
            if ns:
                ns = '{%s}' % ns
            for asset_xml in assets_xml.findall('%sAssetList/%sAsset' % (ns, ns)):
                try:
                    asset = Asset(asset_xml, ns)
                except ChunkedAssetmapException as ex:
                    self.__log('Found invalid asset in %s' % self.assetmap_path, exc_info=True)
                    self.errors.append(DCP_CONSTANTS.ASSETMAP_CHUNKED)
                except Exception as ex:
                    self.__log('Found invalid asset in %s' % self.assetmap_path, exc_info=True)
                    self.errors.append(DCP_CONSTANTS.MALFORMED_ASSETMAP)
                else:
                    asset.full_path = self.conn.join(self.path, asset.relative_path.replace('file://', ''))
                    if not self.conn.exists(asset.full_path):
                        asset.errors.append(DCP_CONSTANTS.FILE_MISSING)
                        asset.missing = True
                    else:
                        asset.fs_size = self.conn.get_size(asset.full_path)
                    self.assets[asset.uuid] = asset

            pkls = [ asset for asset in self.assets.values() if asset.type == AssetType.PKL ]
            if len(pkls) == 0:
                self.errors.append(DCP_CONSTANTS.NO_PKL_FOUND)
                return
            for pkl in [ asset for asset in self.assets.values() if asset.type == AssetType.PKL ]:
                errors = set(pkl.errors).difference([DCP_CONSTANTS.SIZE_MISMATCH])
                if errors:
                    self.__log('%s error in %s' % (str(errors), pkl.uuid))
                    if len(errors) == 1 and errors.pop() == DCP_CONSTANTS.FILE_MISSING:
                        self.errors.append(DCP_CONSTANTS.PKL_FILE_MISSING)
                    else:
                        self.errors.append(DCP_CONSTANTS.INVALID_PKL)
                else:
                    pkl_xml = None
                    try:
                        pkl_xml = ElementTree.fromstring(self.conn.open(pkl.full_path).read())
                    except ParsingException as ex:
                        self.__log('Could not parse PKL %s' % pkl.full_path)
                        continue

                    self.pkls.append(pkl)
                    pkl_ns = str(pkl_xml.tag).replace('{', '').replace('PackingList', '').replace('}', '')
                    if pkl_ns:
                        pkl_ns = '{%s}' % pkl_ns
                    pkl_assets_xml = pkl_xml.findall('%sAssetList/%sAsset' % (pkl_ns, pkl_ns))
                    for asset_xml in pkl_assets_xml:
                        asset_uuid = asset_xml.find('%sId' % pkl_ns).text[9:]
                        hash = asset_xml.find('%sHash' % pkl_ns).text if asset_xml.find('%sHash' % pkl_ns) != None else None
                        pkl_size = int(asset_xml.find('%sSize' % pkl_ns).text) if asset_xml.find('%sSize' % pkl_ns) != None else None
                        mime_type = asset_xml.find('%sType' % pkl_ns).text if asset_xml.find('%sType' % pkl_ns) != None else None
                        try:
                            asset = self.assets[asset_uuid]
                        except KeyError as ex:
                            self.__log('PKL references asset which was not listed in ASSETMAP: %s' % asset_uuid)
                            self.errors.append(DCP_CONSTANTS.PKL_REFERENCES_UNKNOWN_ASSET)
                            continue

                        asset.hash = hash
                        asset.mime_type = mime_type
                        asset.pkl_size = pkl_size
                        asset.in_pkl = True

            for asset in self.assets.values():
                if not asset.missing:
                    try:
                        if not isinstance(self.conn, FTPHandler):
                            self.conn.open(asset.full_path)
                    except IOError:
                        asset.errors.append(DCP_CONSTANTS.SIZE_MISMATCH)

            for cpl_asset in [ asset for asset in self.assets.values() if (asset.type == AssetType.CPL or asset.type == AssetType.UNKNOWN and asset.mime_type and 'text/xml' in asset.mime_type) and DCP_CONSTANTS.FILE_MISSING not in asset.errors ]:
                try:
                    cpl_xml = self.conn.open(cpl_asset.full_path).read()
                except IOError as ex:
                    logging.error('Could not parse CPL %s' % cpl_asset.full_path, exc_info=True)
                else:
                    if cpl_asset.type == AssetType.UNKNOWN and cpl_xml.find('CompositionPlaylist') > -1:
                        cpl_asset.mime_type = 'text/xml;asdcpKind=CPL'
                    if cpl_asset.type == AssetType.CPL:
                        cpl = CPL(cpl_xml, relative_path=cpl_asset.relative_path, full_path=cpl_asset.full_path, hash=cpl_asset.hash, size=cpl_asset.fs_size, dcp=self)
                        self.cpls.append(cpl)

            if len(self.cpls) == 0:
                self.errors.append(DCP_CONSTANTS.NO_CPLS_FOUND)
            return
# okay decompyling ./lib/dcinema/dcp/dcp.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:43 CST
