# 2017.08.13 21:51:40 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\cpl.py
import logging
import os
import posixpath
import re
from serv.lib.dcinema.dcp.asset import AssetType
from serv.lib.dcinema.dcp.utils import ParsingException
from serv.lib.dcinema import dcp as DCP_CONSTANTS
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities.xml_utils import iterparse_xml
_audio_and_subtitle_lang_re = re.compile('([A-Z]{2,3})(?:-([A-Z]{2,3}))?', re.I | re.U)

class CPL(object):

    @staticmethod
    def is_subtitle_tag(tag):
        return tag.endswith('Subtitle') or tag.endswith('Caption')

    @staticmethod
    def parse_cpl(cpl_source, load_from_file = True):
        """Parses a CPL xml descriptor.
        
        A note about namespaces:
            CPLs may contain extension/non-standard Assets in Reels.
            These Assets have their namespace attached to them.
            They are needed in one of the DCP writer (see
            cinema_services/lib/dcinema/dcp/writers/package.py) to rebuild
            a valid XML file.
            For this reason if an Asset tag has a different namespace than the
            AssetList tag we assume it is an extension/non-standard tag and
            associate the namespace to it.
        
        Args:
            :param cpl_source: The XML to parse or the path to the file storing it.
            :param load_from_file: if true the content should be loaded from file.
        
        :return:
            A dictionary with this structure: {
                'Id': <CompositionPlaylist/Id>,
                'ContentTitleText': <CompositionPlaylist/ContentTitleText>
                'AnnotationText': <CompositionPlaylist/AnnotationText>,
                'ContentKind': <CompositionPlaylist/ContentKind>,
                'IssueDate': <CompositionPlaylist/IssueDate>,
                'Issuer': <CompositionPlaylist/issuer>,
                'Creator': <CompositionPlaylist/Creator>,
                'RatingList': [{
                    'agency': <CompositionPlaylist/RatingList/Rating/Agency>,
                    'label': <CompositionPlaylist/RatingList/Rating/Label>
                }],
                'ReelList': [{
                    'Id': <CompositionPlaylist/ReelList/Reel/Id>,
                    'AnnotationText': <CompositionPlaylist/ReelList/Reel/AnnotationText>,
                    'AssetList': [{
                        'AssetType': <CompositionPlaylist/ReelList/Reel/AssetList/<AssetTag>>,
                        'Id': <CompositionPlaylist/ReelList/Reel/AssetList/<AssetTag>/Id>,
                        'Duration': <CompositionPlaylist/ReelList/Reel/AssetList/<AssetTag>/Duration>,
                        'EditRate': <CompositionPlaylist/ReelList/Reel/AssetList/<AssetTag>/EditRate>,
                        'KeyId': <CompositionPlaylist/ReelList/Reel/AssetList/<AssetTag>/KeyId>,
                        'ScreenAspectRatio': <CompositionPlaylist/ReelList/Reel/AssetList/<AssetTag>/ScreenAspectRatio>,
                        'xmlns:<AssetType>': <Namespace of the Tag, if different from AssetList's namespace>,
                    }]
                }]
            }
        """

        def parse_loop(event, element, state, **kwargs):
            if event == 'start':
                state['nest_level'] += 1
                if element.tag.endswith('RatingList'):
                    state['in_ratings'] = True
                elif element.tag.endswith('ReelList'):
                    state['in_reels'] = True
                elif state['nest_level'] == 3 and element.tag.endswith('AssetList'):
                    namespace = element.tag.rsplit('}', 1)[0][1:] if element.tag.find('}') != -1 else ''
                    state['asset_list_ns'] = namespace
                elif state['in_reels'] and state['nest_level'] == 4:
                    state['reel_asset'] = element.tag.rsplit('}', 1)[-1]
            elif event == 'end':
                state['nest_level'] -= 1
                if state['nest_level'] == 0:
                    if element.tag.endswith('Id'):
                        state['out']['Id'] = element.text[9:]
                    elif element.tag.endswith('ContentTitleText'):
                        state['out']['ContentTitleText'] = element.text
                    elif element.tag.lower().endswith('annotationtext'):
                        state['out']['AnnotationText'] = element.text
                        if 'ContentTitleText' not in state['out']:
                            state['out']['ContentTitleText'] = element.text
                    elif element.tag.endswith('ContentKind'):
                        state['out']['ContentKind'] = element.text
                    elif element.tag.endswith('IssueDate'):
                        state['out']['IssueDate'] = element.text
                    elif element.tag.endswith('Issuer'):
                        state['out']['Issuer'] = element.text
                    elif element.tag.endswith('Creator'):
                        state['out']['Creator'] = element.text
                elif state['in_ratings']:
                    if state['nest_level'] == 2:
                        if element.tag.endswith('Agency'):
                            state['partials']['rating']['agency'] = element.text
                        elif element.tag.endswith('Label'):
                            state['partials']['rating']['label'] = element.text
                    elif state['nest_level'] == 1 and element.tag.endswith('Rating'):
                        state['out']['RatingList'].append(state['partials']['rating'])
                        state['partials']['rating'] = {}
                if state['in_reels']:
                    if state['nest_level'] == 1 and element.tag.endswith('Reel'):
                        state['out']['ReelList'].append(state['partials']['reel'])
                        state['partials']['reel'] = {'AssetList': []}
                    elif state['nest_level'] == 2:
                        if element.tag.endswith('Id'):
                            state['partials']['reel']['Id'] = element.text[9:]
                        elif element.tag.lower().endswith('annotationtext'):
                            state['partials']['reel']['AnnotationText'] = element.text
                    elif state['nest_level'] == 4:
                        if state['reel_asset'] in ('MainPicture', 'MainSound', 'MainStereoscopicPicture', 'AuxData') and element.tag.endswith('KeyId'):
                            state['partials']['asset']['KeyId'] = element.text
                        elif element.tag.endswith('Id') and not element.tag.endswith('KeyId'):
                            state['partials']['asset']['Id'] = element.text[9:]
                        elif state['reel_asset'] in ('MainPicture', 'MainSound', 'MainStereoscopicPicture', 'MainPictureLeftEye') and element.tag.endswith('IntrinsicDuration'):
                            state['partials']['asset']['IntrinsicDuration'] = element.text
                        elif state['reel_asset'] in ('MainPicture', 'MainSound', 'MainStereoscopicPicture', 'MainPictureLeftEye') and element.tag.endswith('Duration'):
                            state['partials']['asset']['Duration'] = element.text
                        elif state['reel_asset'] in ('MainPicture', 'MainSound', 'MainStereoscopicPicture') and element.tag.endswith('EditRate'):
                            state['partials']['asset']['EditRate'] = element.text
                        elif state['reel_asset'] in ('MainPicture', 'MainSound', 'MainStereoscopicPicture') and element.tag.endswith('FrameRate'):
                            state['partials']['asset']['FrameRate'] = element.text
                        elif CPL.is_subtitle_tag(state['reel_asset']) and element.tag.endswith('Language'):
                            state['partials']['asset']['Language'] = element.text
                        elif state['reel_asset'] in ('MainPicture', 'MainStereoscopicPicture', 'MainPictureLeftEye') and element.tag.endswith('ScreenAspectRatio'):
                            state['partials']['asset']['ScreenAspectRatio'] = element.text
                    elif state['nest_level'] == 3:
                        asset = state['partials']['asset']
                        namespace = element.tag.rsplit('}', 1)[0][1:] if element.tag.find('}') != -1 else None
                        asset['AssetType'] = state['reel_asset']
                        if namespace and namespace != state['asset_list_ns']:
                            asset['xmlns:' + state['reel_asset']] = namespace
                        state['partials']['asset'] = {}
                        state['partials']['reel']['AssetList'].append(asset)
                    elif state['nest_level'] == 6 and state['reel_asset'] == 'MainMarkers':
                        if element.tag.endswith('Label'):
                            state['partials']['asset'].setdefault('labels', []).append(element.text)
                        elif element.tag.endswith('Offset'):
                            state['partials']['asset'].setdefault('offsets', []).append(element.text)
                if element.tag.endswith('RatingList'):
                    state['in_ratings'] = False
                elif element.tag.endswith('ReelList'):
                    state['in_reels'] = False
                element.clear()
            return state

        cpl = open(cpl_source, 'r') if load_from_file else cpl_source
        state = iterparse_xml(cpl, parse_loop, {'asset_list_ns': None,
         'in_ratings': False,
         'in_reels': False,
         'nest_level': -1,
         'reel_asset': '',
         'out': {'RatingList': [],
                 'ReelList': []},
         'partials': {'asset': {},
                      'rating': {},
                      'reel': {'AssetList': []}}})
        if load_from_file:
            cpl.close()
        return state['out']

    @property
    def mime_type(self):
        return 'text/xml;asdcpKind=CPL'

    @property
    def picture_encryption(self):
        if self.crypto_id_list:
            return 1
        return 0

    @property
    def sound_encryption(self):
        if self.crypto_id_list:
            return 1
        return 0

    @property
    def crypto_no_items(self):
        return len(self.crypto_id_list)

    @property
    def crypto_item_length(self):
        return 16

    @property
    def picture_encoding(self):
        return 0

    @property
    def sound_encoding(self):
        return 0

    @property
    def sound_channel_count(self):
        return 'Unknown'

    @property
    def sound_quantization_bits(self):
        return 'Unknown'

    @property
    def filename(self):
        return os.path.split(self._relative_path)[-1]

    @filename.setter
    def filename(self, value):
        relative_folder = posixpath.split(self._relative_path)[0]
        self._relative_path = posixpath.join(relative_folder, value)

    def __str__(self):
        """
        Returns a string representation of the asset
        """
        return 'uuid: %s content_title_text: %s total_asset_size: %s errors: %s, content_kind %s' % (str(self.uuid),
         self.content_title_text,
         str(self.total_asset_size),
         str(self.errors),
         str(self.content_kind))

    def __init__(self, xml, relative_path = None, full_path = None, hash = None, size = None, dcp = None, load_from_file = False):
        """
        PARAMS:
            xml             : XML string to parse
            relative_path   : ?
            full_path       : ?
            hash            : The file hash (from the pkl?)
            size            : The file size (from the pkl?)
            dcp             : Instance of dcp.DCP which this cpl is from
            default_to_none : Set defaults to None instead of legacy TMS expectations (''/0/etc.)
            load_from_file  : xml is a file path so load from there
        """
        self._relative_path = relative_path.replace('\\', '/') if relative_path else None
        self.full_path = full_path.replace('\\', '/') if full_path else None
        self._xml = xml
        self.hash = hash
        self.size = size
        self.assets = []
        self.meta_assets = []
        self.errors = []
        self.complete = True
        self.total_asset_size = 0
        self.is3d = False
        self.crypto_id_list = []
        self.is_ingestible = True
        self.ratings = []
        self.aspect_ratios = {}
        self.cpl_aspect_ratio = None
        self.asset_ids = []
        self.cpl_reels = []
        self.mainmarkers = {}
        self.duration = 0
        self.edit_rate_a = ''
        self.edit_rate_b = ''
        self.picture_width = 'Unknown'
        self.picture_height = 'Unknown'
        self.subtitle = False
        self.subtitle_lang = ''
        cpl = None
        try:
            cpl = CPL.parse_cpl(self._xml, load_from_file)
        except Exception as ex:
            self.is_ingestible = False
            raise ParsingException(str(ex))

        reel_list = cpl['ReelList']
        self.ratings = cpl['RatingList']
        self.uuid = cpl['Id']
        self.content_kind_text = cpl['ContentKind']
        self.content_title_text = cpl['ContentTitleText'] if 'ContentTitleText' in cpl else None
        self.issue_date = cpl['IssueDate']
        self.content_kind = self.content_kind_text
        self.issuer = cpl['Issuer'] if 'Issuer' in cpl else None
        self.creator = cpl['Creator'] if 'Creator' in cpl else None
        if 'AnnotationText' in cpl:
            self.annotation_text = cpl['AnnotationText']
        else:
            self.annotation_text = self.content_title_text if self.content_title_text else 'Unknown'
        if self.content_title_text is None:
            self.content_title_text = self.annotation_text
        if len(reel_list) == 0:
            self.errors.append(_('There are no Assets for this CPL'))
            self.is_ingestible = False
        movie_edit_rate = ''
        reel_index = 1
        sound_edit_rate = ''
        processed_assets = set()
        asset_ids = set()
        self.crypto_id_list = []
        for reel in reel_list:
            if 'Id' in reel:
                self.cpl_reels.append({'id': reel['Id'],
                 'asset_list': [ {asset['AssetType']: asset} for asset in reel['AssetList'] ],
                 'position': reel_index})
            for asset in reel['AssetList']:
                sound_duration = 0
                movie_duration = 0
                asset_type = asset['AssetType']
                asset_info = {'meta_asset': False}
                asset_info['uuid'] = asset['Id'] if 'Id' in asset else ''
                asset_uuid = asset_info['uuid']
                if asset_uuid not in processed_assets:
                    processed_assets.add(asset_uuid)
                    if 'KeyId' in asset and asset_type in ('MainPicture', 'MainSound', 'AuxData'):
                        self.crypto_id_list.append(asset['KeyId'])
                    asset_info['reel'] = reel_index
                    asset_info['annotation_text'] = asset['AnnotationText'] if 'AnnotationText' in asset else ''
                    if asset_type == 'MainMarkers':
                        asset_info['meta_asset'] = True
                        asset_info['type'] = AssetType.MARKER
                        asset_info['mimetype'] = 'application/x-smpte-mxf;asdcpKind=Marker'
                        if 'labels' in asset and len(asset['labels']) == len(asset.get('offsets', [])):
                            for i, label in enumerate(asset['labels']):
                                self.mainmarkers[label] = int(asset['offsets'][i])

                    elif asset_type == 'MainPicture' or asset_type == 'MainStereoscopicPicture':
                        asset_info['type'] = AssetType.PICTURE
                        asset_info['mimetype'] = 'application/x-smpte-mxf;asdcpKind=Picture'
                        movie_duration = int(asset['Duration']) if 'Duration' in asset else 0
                        movie_edit_rate = asset['EditRate'] if 'EditRate' in asset else ''
                        if asset_type == 'MainStereoscopicPicture':
                            self.is3d = True
                    elif asset_type == 'MainSound':
                        asset_info['type'] = AssetType.SOUND
                        asset_info['mimetype'] = 'application/x-smpte-mxf;asdcpKind=Sound'
                        sound_duration = int(asset['Duration']) if 'Duration' in asset else 0
                        sound_edit_rate = asset['EditRate'] if 'EditRate' in asset else ''
                    elif asset_type == 'CompositionMetadataAsset':
                        asset_info['type'] = AssetType.METADATA
                        asset_info['meta_asset'] = True
                    elif asset_type == 'AuxData':
                        asset_info['type'] = AssetType.AUXDATA
                    elif self.is_subtitle_tag(asset_type):
                        self.subtitle = True
                        self.subtitle_lang = asset.get('Language', self.subtitle_lang)
                        asset_info['type'] = AssetType.SUBTITLE
                        asset_info['mimetype'] = 'text/xml;asdcpKind=Subtitle'
                        if dcp and asset_uuid in dcp.assets and DCP_CONSTANTS.FILE_MISSING not in dcp.assets[asset_uuid].errors:
                            dcp.assets[asset_uuid].parent_folder = asset_uuid
                        if dcp:
                            subtitle_assets = [ dcp_asset for dcp_asset in dcp.assets.values() if asset_uuid in dcp_asset.relative_path and dcp_asset.uuid != asset_uuid ]
                            for subtitle_asset in subtitle_assets:
                                subtitle_info = {'uuid': subtitle_asset.uuid,
                                 'annotation_text': None,
                                 'reel': reel_index,
                                 'type': subtitle_asset.type,
                                 'mimetype': subtitle_asset.mime_type,
                                 'from_this_dcp': True}
                                if subtitle_info['uuid'] in dcp.assets and DCP_CONSTANTS.FILE_MISSING not in dcp.assets[subtitle_info['uuid']].errors:
                                    dcp.assets[subtitle_info['uuid']].parent_folder = asset_uuid
                                self.assets.append(subtitle_info)

                    else:
                        asset_info['type'] = AssetType.UNKNOWN
                        asset_info['mimetype'] = ''
                    if asset_type not in self.aspect_ratios and asset_type in ('MainPicture', 'MainStereoscopicPicture', 'MainPictureLeftEye') and 'ScreenAspectRatio' in asset:
                        self.aspect_ratios[asset_type] = asset['ScreenAspectRatio']
                    if not dcp or not dcp.assets.has_key(asset_uuid):
                        asset_info['from_this_dcp'] = False
                    elif dcp:
                        ass_size = dcp.assets[asset_uuid].fs_size or dcp.assets[asset_uuid].am_size or dcp.assets[asset_uuid].pkl_size or 0
                        self.total_asset_size += int(ass_size)
                        asset_info['from_this_dcp'] = True
                    if dcp and dcp.assets.has_key(asset_uuid):
                        asset_errors = set(dcp.assets[asset_uuid].errors)
                        critical_asset_errors = asset_errors.difference([DCP_CONSTANTS.SIZE_MISMATCH, DCP_CONSTANTS.FILE_MISSING])
                        if critical_asset_errors:
                            logging.error('Asset [%s] has critical errors [%s]' % (str(asset_uuid), str(critical_asset_errors)))
                            self.is_ingestible = False
                        if asset_errors:
                            self.complete = False
                    elif not asset_info['meta_asset']:
                        self.complete = False
                    if asset_info['meta_asset']:
                        self.meta_assets.append(asset_info)
                    else:
                        self.assets.append(asset_info)
                        if asset_uuid:
                            asset_ids.add(asset_uuid)
                elif asset_type == 'MainPicture' or asset_type == 'MainStereoscopicPicture':
                    movie_duration = int(asset.get('Duration', 0))
                self.duration += int(movie_duration)

            reel_index += 1

        if not self.subtitle and self.content_title_text:
            title_parts = self.content_title_text.split('_')
            if len(title_parts) >= 4:
                match = _audio_and_subtitle_lang_re.match(title_parts[3])
                if match:
                    self.subtitle_lang = match.group(2) if match.group(2) else self.subtitle_lang
                    self.subtitle = self.subtitle_lang not in ('XX', '')
        if dcp and dcp.assets.has_key(self.uuid):
            asset_errors = set(dcp.assets[self.uuid].errors)
            critical_asset_errors = asset_errors.difference([DCP_CONSTANTS.SIZE_MISMATCH, DCP_CONSTANTS.FILE_MISSING])
            if critical_asset_errors:
                logging.error('CPL [%s] has critical errors [%s]' % (str(self.uuid), str(critical_asset_errors)))
                self.is_ingestible = False
            if asset_errors:
                self.complete = False
        best_aspect_ratio = self.aspect_ratios.get('MainPicture', self.aspect_ratios.get('MainStereoscopicPicture', self.aspect_ratios.get('MainPictureLeftEye')))
        if best_aspect_ratio:
            if ' ' in best_aspect_ratio:
                match = re.match('(\\d+) +(\\d+)', best_aspect_ratio).groups()
                best_aspect_ratio = '{0:.2f}'.format(float(match[0]) / float(match[1]))
            elif best_aspect_ratio.count('.') > 1:
                match = re.match('(\\d+).+(\\d+)', best_aspect_ratio).groups()
                best_aspect_ratio = match[0] + '.' + match[1]
        self.cpl_aspect_ratio = best_aspect_ratio
        self.asset_ids = list(asset_ids)
        if movie_edit_rate == '' and sound_edit_rate == '':
            logging.error('CPL [%s] has no discernible edit rate, defaulting to 24:1', self.uuid)
            edit_rate = '24 1'
        elif movie_edit_rate == '':
            edit_rate = sound_edit_rate
        else:
            edit_rate = movie_edit_rate
        a, b = edit_rate.split()
        self.edit_rate_a = a[0:2]
        self.edit_rate_b = b[0:1]
        self.duration_in_seconds = self.duration * float(self.edit_rate_b) / float(self.edit_rate_a)
        return


if __name__ == '__main__':
    uuid = 'b40eb3ed-bab8-4cf5-a704-6a33aae6ffb3'
    cpl_path = 'D:\\lms-data\\CPL\\%s\\%s.xml' % (uuid, uuid)
    cpl = CPL(cpl_path, load_from_file=True)
    print cpl.__dict__
# okay decompyling ./lib/dcinema/dcp/cpl.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:42 CST
