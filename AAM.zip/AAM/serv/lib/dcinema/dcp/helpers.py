# 2017.08.13 21:51:45 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\helpers.py
import logging, os, traceback, datetime, random, re, uuid
from serv.lib.dcinema.dcp.dcp import DCP
from serv.lib.dcinema import constants
from serv.lib.dcinema.parsers.parsers import parse_kdm
from serv.lib.cherrypy.i18n_tool import ugettext as _

def _analyze_cpl(fileHandler, content_path):
    """
    analyze a folder via a given file handler and return any error messages / messages about it
    ret {
        file_name:
            { 
            status : Error or Valid
            message: Relative informative message that will make sense to everyone
            }
        }
    """
    ret = {}
    if content_path == None or not fileHandler.exists(content_path):
        logging.error('CPL file was not found: %s' % content_path)
        ret[content_path] = {'status': 'error',
         'message': _('CPL file was not found: %s') % content_path}
        return ret
    else:
        folder = True
        path = content_path
        depth = 5
        count = 0
        while folder and count < depth:
            folder = os.path.split(path)[0]
            if _folder_is_package(folder, fileHandler):
                break
            count = count + 1

        if folder == False:
            logging.error('Assetmap was not found: [%s]' % content_path)
            ret[content_path] = {'status': 'error',
             'message': _('Assetmap was not found: [%s]') % content_path}
            return ret
        dcp = None
        try:
            dcp = DCP(folder, fileHandler)
        except Exception as ex:
            logging.error('Error validating the DCP in the folder[%s]' % str(folder), exc_info=True)
            ret[content_path] = {'status': 'error',
             'message': _('Error validating the DCP in the folder [%s] :%s') % (str(folder), str(ex))}
            return ret

        cpls = [ cpl for cpl in dcp.cpls if cpl.full_path == content_path.replace('\\', '/') ]
        if len(cpls) != 1:
            if not len(dcp.pkls):
                logging.error('[%s] PKL(s) found in DCP for given DCP path: [%s]' % (str(len(dcp.pkls)), content_path))
                ret[content_path] = {'status': 'error',
                 'message': _('[%s] PKL(s) found in DCP: [%s]') % (str(len(dcp.pkls)), content_path)}
                return ret
            logging.error('[%s] cpl(s) found in DCP for given cpl path: [%s]' % (str(len(cpls)), content_path))
            ret[content_path] = {'status': 'error',
             'message': _('[%s] CPL(s) found in DCP: [%s]') % (str(len(cpls)), content_path)}
            return ret
        cpl = cpls[0]
        cpl.errors.extend(dcp.assets[cpl.uuid].errors)
        if cpl.errors:
            ret[cpl.filename] = {'status': 'error',
             'message': str(cpl.errors),
             'type': 'CPL'}
        else:
            ret[cpl.filename] = {'status': 'valid',
             'message': _('The CPL file is valid: [%s]') % cpl.filename,
             'type': 'CPL'}
        for asset in cpl.assets:
            if asset['from_this_dcp']:
                actual_asset = dcp.assets[asset['uuid']]
                if actual_asset.errors:
                    ret[actual_asset.filename] = {'status': 'error',
                     'message': str(actual_asset.errors),
                     'type': asset['type'],
                     'reel': asset['reel']}
                else:
                    ret[actual_asset.filename] = {'status': 'valid',
                     'message': _('The asset file is valid: [%s]') % actual_asset.filename,
                     'name': 'CPL XML',
                     'type': asset['type'],
                     'reel': asset['reel']}
            else:
                ret['uuid: [%s] type: [%s]' % (asset['uuid'], asset['type'])] = {'status': 'error',
                 'message': _('The CPL requires an asset that is not in this DCP: [%s]') % asset['uuid'],
                 'type': asset['type'],
                 'reel': asset['reel']}

        return ret


def _force_contents(file_path, contents):
    """
    Ensures file at file_path has content
    @param
        file_path: string #path of the file in question
        contents: string #contents the file needs to have
    @return
        None
    """
    with open(file_path, 'wb') as file:
        file.write(contents)


def _folder_is_package(root, handler):
    """
    Looks for assetmap files in a folder to see if the folder contains a DCP
    Only used in __update_mounted_drive_content
    """
    for possible_assetmap_name in ['ASSETMAP',
     'assetmap',
     'ASSETMAP.xml',
     'ASSETMAP.XML',
     'assetmap.xml',
     'assetmap.XML']:
        if handler.exists(handler.join(root, possible_assetmap_name)):
            return True
    else:
        return False


DATE_FORMAT = '%Y-%m-%dT%H:%M:%S-00:00'
ASSETMAP_TEMPLATE = u'<?xml version="1.0" encoding="UTF-8"?>\n<AssetMap xmlns="http://www.digicine.com/PROTO-ASDCP-AM-20040311#">\n<Id>urn:uuid:%(uuid)s</Id>\n<AnnotationText>%(annotation_text)s</AnnotationText>\n<VolumeCount>1</VolumeCount>\n<IssueDate>%(issue_date)s</IssueDate>\n<Issuer>Arts Alliance Media</Issuer>\n<Creator>TMS</Creator>\n<AssetList>\n%(assets)s\n</AssetList>\n</AssetMap>\n'
ASSETMAP_ASSET_TEMPLATE = u'\n<Asset>\n<Id>urn:uuid:%(uuid)s</Id>\n%(packing_list)s\n<ChunkList>\n<Chunk>\n<Path>%(path)s</Path>\n<VolumeIndex>1</VolumeIndex>\n<Offset>0</Offset>\n<Length>%(length)s</Length>\n</Chunk>\n</ChunkList>\n</Asset>\n'
PKL_TEMPLATE = u'<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n<PackingList xmlns="http://www.digicine.com/PROTO-ASDCP-PKL-20040311#">\n<Id>urn:uuid:%(uuid)s</Id>\n<AnnotationText>%(annotation_text)s</AnnotationText>\n<IssueDate>%(issue_date)s</IssueDate>\n<Issuer>Arts Alliance Media</Issuer>\n<Creator>TMS</Creator>\n<AssetList>\n%(assets)s\n</AssetList>\n</PackingList>\n'
PKL_ASSET_TEMPLATE = u'\n<Asset>\n<Id>urn:uuid:%(uuid)s</Id>\n%(hash)s\n<Size>%(length)s</Size>\n<Type>%(type)s</Type>\n</Asset>\n'
VOLINDEX_TEMPLATE = '\n<?xml version="1.0" encoding="UTF-8"?>\n<VolumeIndex xmlns="http://www.smpte-ra.org/schemas/429-9/2007/AM">\n  <Index>1</Index>\n</VolumeIndex>\n'

def _get_assetmap_pkl_volindex(cpl, asset_store, missing_font_details):
    """
        param cpl obj
        returns assetmap_xml, pkl_xml
    """
    cpl_uuid_obj = uuid.UUID(cpl['uuid'])
    pkl_uuid = uuid.uuid3(cpl_uuid_obj, 'pkl')
    pkl_annotation_text = cpl['content_title_text']
    assetmap_uuid = str(uuid.uuid4())
    pkl_asset_xmls = []
    assetmap_asset_xmls = []
    pkl_asset_xmls.append(PKL_ASSET_TEMPLATE % {'uuid': cpl['uuid'],
     'length': cpl['size'],
     'hash': '<Hash>%s</Hash>' % cpl['hash'] if cpl['hash'] else '',
     'type': cpl['type']})
    cpl_file_name = cpl['file_name']
    assetmap_asset_xmls.append(ASSETMAP_ASSET_TEMPLATE % {'uuid': cpl['uuid'],
     'packing_list': '',
     'path': cpl_file_name,
     'length': cpl['size']})
    for asset_uuid in cpl['assets']:
        asset = asset_store[asset_uuid]
        if asset['status'] != None:
            pkl_asset_xmls.append(PKL_ASSET_TEMPLATE % {'uuid': asset['uuid'],
             'length': asset['size'],
             'hash': '<Hash>%s</Hash>' % asset['hash'] if asset['hash'] else '',
             'type': asset['type']})
            path = asset['parent_folder'] + '/' + asset['file_name'] if asset['parent_folder'] else asset['file_name']
            path = path.replace('&', '&amp;').replace('"', '&quot;').replace("'", '&apos;')
            assetmap_asset_xmls.append(ASSETMAP_ASSET_TEMPLATE % {'uuid': asset['uuid'],
             'packing_list': '',
             'path': path,
             'length': asset['size']})
        elif missing_font_details != None and asset['uuid'] == missing_font_details['missing_font_id']:
            pkl_asset_xmls.append(PKL_ASSET_TEMPLATE % {'uuid': missing_font_details['missing_font_id'],
             'length': missing_font_details['missing_font_size'],
             'hash': '<Hash>%s</Hash>' % missing_font_details['missing_font_hash'] if missing_font_details['missing_font_hash'] else '',
             'type': 'application/ttf'})
            assetmap_asset_xmls.append(ASSETMAP_ASSET_TEMPLATE % {'uuid': missing_font_details['missing_font_id'],
             'packing_list': '',
             'path': missing_font_details['missing_font_path'],
             'length': '0'})

    pkl_asset_xml = '\n'.join(pkl_asset_xmls)
    try:
        pkl_xml = PKL_TEMPLATE % {'uuid': pkl_uuid,
         'annotation_text': pkl_annotation_text,
         'issue_date': datetime.datetime.now().strftime(DATE_FORMAT),
         'assets': pkl_asset_xml}
    except Exception:
        logging.info('Problem generating PKL asset XML with annotation: %s (%s)' % (str(pkl_annotation_text), str(type(pkl_annotation_text))))
        raise

    assetmap_asset_xmls.append(ASSETMAP_ASSET_TEMPLATE % {'uuid': pkl_uuid,
     'packing_list': '<PackingList>true</PackingList>',
     'path': 'pkl.xml',
     'length': len(pkl_xml)})
    assetmap_asset_xml = '\n'.join(assetmap_asset_xmls)
    assetmap_xml = ASSETMAP_TEMPLATE % {'uuid': assetmap_uuid,
     'annotation_text': 'TMS ASSETMAP - %s' % assetmap_uuid,
     'issue_date': datetime.datetime.now().strftime(DATE_FORMAT),
     'assets': assetmap_asset_xml}
    volindex_xml = VOLINDEX_TEMPLATE
    return (assetmap_xml, pkl_xml, volindex_xml)
# okay decompyling ./lib/dcinema/dcp/helpers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:45 CST
