# 2017.08.13 21:51:43 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\file_handlers.py
"""
(c) 2011 - Arts Alliance Media
File Handlers
  
File handlers for various protocols including local fole systems and FTP.
It abstracts out accessing file listings and access so that multiple
implementations can be used transparently.
  
Replaces file_handler_local.py, file_handler_ftp.py
and file_handler_exceptions.py

@author: Matt Sullivan
"""
import os
import StringIO
import shutil
import posixpath
from urlparse import urlparse, ParseResult
from abc import ABCMeta, abstractmethod
from serv.lib.dcinema.dcp.ftp_wrapper import EnhancedFTP

class AbstractHandler(object):
    """
    An abstract base class for defining the method contracts
    for all handlers
    """
    __metaclass__ = ABCMeta

    def __enter__(self):
        return self

    def __exit__(self):
        self.close_connection()
        return False

    @staticmethod
    def get_handler(uri, ftp_encoding = 'utf_8'):
        """
        Returns the appropriate handler and file path
        for a URI
        
        @return (path, handler)
        """
        if uri.find(':') == 1:
            parsed_url = ParseResult('', '', uri, '', '', '')
        else:
            parsed_url = urlparse(uri)
        if not parsed_url.scheme or parsed_url.scheme == 'file':
            return (parsed_url.path, FileHandler())
        elif parsed_url.scheme == 'ftp':
            return (parsed_url.path, FTPHandler(host=parsed_url.hostname, port=parsed_url.port if parsed_url.port is not None else 21, user=parsed_url.username, passwd=parsed_url.password, encoding=ftp_encoding))
        else:
            raise ValueError('Unsupported URL scheme: %s' % parsed_url.scheme)
            return None

    @abstractmethod
    def join(self, root, file_path):
        """
        Joins elements together to form a correct os path
        """
        pass

    @abstractmethod
    def exists(self, file_path):
        """
        Checks for the existence of a file
        """
        pass

    @abstractmethod
    def isdir(self, file_path):
        """
        Checks whether a path is a directory
        """
        pass

    @abstractmethod
    def get_size(self, file_path):
        """
        TODO: Rename this to 'size'
        Returns the size of a file in bytes
        """
        pass

    @abstractmethod
    def walk(self, file_path):
        """
        Walks through the directory hierarchy in an
        identical manner to os.walk()
        """
        pass

    @abstractmethod
    def close_connection(self):
        """
        TODO: Remove this function
        """
        pass

    @abstractmethod
    def open(self, file_path, mode = 'r'):
        """
        Should return a file-like object
        """
        pass

    @abstractmethod
    def last_modified(self, file_path):
        """
        Should return a file-like object
        """
        pass


class FileHandler(AbstractHandler):
    """
    Wraps file management for a local file system
    """

    def __init__(self):
        self.type = 'file'

    def join(self, root, file_path):
        """
        Joins elements together to form a correct os path
        """
        return os.path.join(root, file_path)

    def exists(self, file_path):
        """
        Checks for the existence of a file
        """
        return os.path.exists(file_path)

    def delete_dir(self, file_path):
        """
        Delete the directory containing the file
        """
        if os.path.exists(file_path):
            shutil.rmtree(os.path.dirname(file_path))

    def isdir(self, file_path):
        """
        Checks whether a path is a directory
        """
        return os.path.isdir(file_path)

    def get_size(self, file_path):
        """
        TODO: Rename this to 'size'
        Returns the size of a file in bytes
        """
        return os.path.getsize(file_path)

    def walk(self, file_path):
        """
        Walks through the directory hierarchy in an
        identical manner to os.walk()
        """
        return os.walk(file_path)

    def close_connection(self):
        """
        TODO: Remove this function
        """
        pass

    def open(self, file_path, mode = 'r'):
        """
        Returns a file like object
        """
        return open(file_path, mode)

    def last_modified(self, file_path):
        """
        Returns a file like object
        """
        return long(os.path.getmtime(file_path))


class FTPFile(object):
    """
    Class to mimic a file-handle to a remote file
    The internal buffer is loaded by the callback function of a retrbinary or retrlines call on an ftp connection
    NOTE: Only read mode currently supported
    """

    def __init__(self, name, mode):
        self._file = StringIO.StringIO()
        self.name = name
        self.mode = mode
        self.closed = False
        self.newline = None
        self.softspace = 0
        return

    def __getattr__(self, name):
        """
        Delegate (hopefully) non-modifying methods to the buffer
        """
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def _async_load_write(self, block):
        """
        Used by the retr_x callback functions to populate the internal buffer
        """
        if 'b' not in self.mode:
            newlines = tuple() if self.newline is None else self.newline
            if '\r\n' not in newlines and '\r\n' in block:
                newlines = ('\r\n',) + newlines
            if '\r' not in newlines and '\r' in block:
                newlines = newlines + ('\r',)
            if '\n' not in newlines and '\n' in block:
                newlines = newlines + ('\n',)
            for newline in newlines:
                if newline != '\n':
                    block = block.replace(newline, '\n')

            if newlines:
                self.newline = newlines
        self._file.seek(0, os.SEEK_END)
        self._file.write(block)
        self._file.seek(0, os.SEEK_SET)
        return

    def close(self):
        if self.mode.startswith('w') or self.mode.startswith('a'):
            self.flush()
        self._file.close()
        self.closed = True

    def flush(self):
        if self.mode.startswith('w') or self.mode.startswith('a'):
            raise NotImplemented()

    def write(self, str):
        if not self.mode.startswith('w') and not self.mode.startswith('a'):
            raise IOError('File not open for reading')
        raise NotImplemented()

    def writelines(self, sequence):
        if not self.mode.startswith('w') and not self.mode.startswith('a'):
            raise IOError('File not open for reading')
        raise NotImplemented()


class FTPHandler(AbstractHandler):
    """
    Wraps file management across an FTP connection
    """

    def __init__(self, host = '', user = '', passwd = '', port = 21, encoding = 'utf_8'):
        self.type = 'ftp'
        self._ftp = EnhancedFTP(host=host, user=user, passwd=passwd, port=port, encoding=encoding)

    def exists(self, file_path):
        """
        Checks for the existence of a file or a directory
        """
        return self._ftp.exists(file_path)

    def isdir(self, file_path):
        """
        Checks whether a path is a directory
        """
        return self._ftp.isdir(file_path)

    def join(self, root, file_path):
        """
        Joins elements together to form a correct unix based os path
        """
        return posixpath.join(root, file_path)

    def get_size(self, file_path):
        r"""
        TODO: Rename this to 'size'
        Returns the size of a file in bytes
        >>> os.path.realpath('/repository/secondary/1ad5ff20-69f4-4b16-b841-79eb65815752/main.xml -> ../../../repository/primary/1ad5ff20-69f4-4b16-b841-79eb6
        5815752.xml')
        'C:\repository\secondary\repository\primary\1ad5ff20-69f4-4b16-b841-79eb65815752.xml'
        
        replacecing -> with ../../ lets realpath work properly with ftp'd symlinks... 
        
        """
        return self._ftp.size(file_path)

    def retrieve_binary(self, file_path, callback, buffersize = None):
        """
        The cwd'ified version of retrbinary
        """
        return self._ftp.retrieve_binary(file_path, callback, buffersize)

    def walk(self, file_path):
        """
        Walks through the directory hierarchy in an
        identical manner to os.walk()
        """
        return self._ftp.walk(file_path)

    def close_connection(self):
        """
        TODO: Remove this function
        """
        self._ftp.close()

    def open(self, file_path, mode = 'r'):
        """
        Returns a file like object
        """
        file_obj = FTPFile(name=posixpath.split(file_path)[1], mode=mode)
        if not mode.startswith('w'):
            self._ftp.retrieve_binary(file_path, file_obj._async_load_write)
        return file_obj

    def ftp_details(self):
        """
        Returns the FTP connection details.
        
        @return (host, port, user, passwd)
        """
        return (self._ftp.host,
         self._ftp.user,
         self._ftp.passwd,
         self._ftp.port)

    def last_modified(self, file_path):
        """
        Returns the last modified time of the file
        
        format YYYYMMDDhhmmss
        """
        return self._ftp.last_modified(file_path)
# okay decompyling ./lib/dcinema/dcp/file_handlers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:43 CST
