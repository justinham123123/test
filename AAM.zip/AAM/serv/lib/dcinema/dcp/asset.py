# 2017.08.13 21:51:40 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\asset.py
import os, posixpath, logging
from serv.lib.dcinema.dcp import SIZE_MISMATCH
from serv.lib.dcinema.dcp.utils import ParsingException, ChunkedAssetmapException, IGNORE_NAMESPACE_XPATH_EXPR

class AssetType:
    """
    Asset types
    """
    PKL = 'Pkl'
    CPL = 'Cpl'
    SOUND = 'Sound'
    PICTURE = 'Picture'
    SUBTITLE = 'Subtitle'
    FONT = 'Font'
    MARKER = 'Marker'
    METADATA = 'Metadata'
    AUXDATA = 'AuxData'
    UNKNOWN = 'Unknown'


class Asset(object):
    """
    Stores info about assets, including physical multimedia assets,
    CPLs and PKLs
    """

    @property
    def mime_type(self):
        return self._mime_type

    @mime_type.setter
    def mime_type(self, value):
        """
        Sets the mime_type. Mime_type is required in the PKL schema.
        """
        self._mime_type = value
        if 'asdcpKind=Sound' in self._mime_type:
            self.type = AssetType.SOUND
        elif 'asdcpKind=Picture' in self._mime_type:
            self.type = AssetType.PICTURE
        elif 'asdcpKind=Subtitle' in self._mime_type:
            self.type = AssetType.SUBTITLE
        elif 'application/ttf' in self._mime_type:
            self.type = AssetType.FONT
        elif 'asdcpKind=CPL' in self._mime_type:
            self.type = AssetType.CPL
        else:
            self.type = AssetType.UNKNOWN

    @property
    def filename(self):
        return os.path.split(self.relative_path)[-1]

    @filename.setter
    def filename(self, value):
        relative_folder = posixpath.split(self.relative_path)[0]
        self.relative_path = posixpath.join(relative_folder, value)

    @property
    def full_path(self):
        return self._full_path

    @full_path.setter
    def full_path(self, value):
        if value == None:
            self._full_path = None
        else:
            self._full_path = value.replace('\\', '/')
        return

    @property
    def fs_size(self):
        return self._fs_size

    @fs_size.setter
    def fs_size(self, value):
        self._fs_size = value
        self.__check_sizes_match()

    @property
    def am_size(self):
        return self._am_size

    @am_size.setter
    def am_size(self, value):
        self._am_size = value
        self.__check_sizes_match()

    @property
    def pkl_size(self):
        return self._pkl_size

    @pkl_size.setter
    def pkl_size(self, value):
        self._pkl_size = value
        self.__check_sizes_match()

    @property
    def info(self):
        info = {}
        if self.fs_size != None:
            info['size'] = self.fs_size
        if self.hash != None:
            info['hash'] = self.hash
        if self.mime_type != None:
            info['mimetype'] = self.mime_type
        return info

    def __init__(self, xml, ns):
        """
        Creates a new asset object
        """
        self._full_path = None
        self.hash = None
        self.annotation_text = None
        self._mime_type = None
        self.errors = []
        self.in_pkl = False
        self._am_size = None
        self._pkl_size = None
        self._fs_size = None
        self.uuid = None
        self.parent_folder = None
        self.missing = False
        self.uuid = xml.find('%sId' % ns).text[9:]
        self.annotation_text = xml.find('%sAnnotationText' % ns).text if xml.find('%sAnnotationText' % ns) != None else ''
        packing_list_element = xml.find('%sPackingList' % ns)
        self.is_pkl = True if packing_list_element != None and packing_list_element.text != 'false' else False
        if not (self.is_pkl and AssetType.PKL):
            self.type = AssetType.UNKNOWN
            chunks = xml.findall('%sChunkList/%sChunk' % (ns, ns))
            if len(chunks) > 1:
                raise ChunkedAssetmapException('Cannot parse asset "%s" because it is chunked' % self.uuid)
            self.relative_path = chunks[0].find('%sPath' % ns).text.replace('file:///', '').replace('\\', '/')
            asset_size = chunks[0].find('%sLength' % ns).text if chunks[0].find('%sLength' % ns) != None else ''
            self._am_size = len(asset_size) != 0 and int(asset_size)
        return

    def __str__(self):
        """
        Returns a string representation of the asset
        """
        return self.uuid

    def __check_sizes_match(self):
        if SIZE_MISMATCH in self.errors:
            self.errors.remove(SIZE_MISMATCH)
        if self._am_size:
            if self._pkl_size and self._pkl_size != self._am_size:
                self.errors.append(SIZE_MISMATCH)
            elif (self._fs_size or self._fs_size == 0) and self._fs_size != self._am_size:
                self.errors.append(SIZE_MISMATCH)
        if self._pkl_size and SIZE_MISMATCH not in self.errors and (self._fs_size or self._fs_size == 0) and self._pkl_size != self._fs_size:
            self.errors.append(SIZE_MISMATCH)
# okay decompyling ./lib/dcinema/dcp/asset.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:40 CST
