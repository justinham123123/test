# 2017.08.13 21:51:50 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\logs\legacy_doremi.py
"""
SMPTE secure log parsing functionality
"""
from xml.dom import minidom
from serv.lib.utilities.date_utils import parse_date, parse_simple_duration
PLAYOUT_EVENT_ORDER = {'FrameSequencePlayed': 0,
 'CPLEnd': 1,
 'PlayoutComplete': 2,
 'CPLStart': 3}

def parse_doremi_event(event_node):
    """
    Parses a doremi event from a DOM node into a dictionary
    """
    event = {}
    event['id'] = event_node.getElementsByTagNameNS('*', 'EventID')[0].firstChild.nodeValue
    time_stamp = event_node.getElementsByTagNameNS('*', 'TimeStamp')[0].firstChild.nodeValue
    event['timestamp'] = parse_date(time_stamp) if time_stamp else 0
    event['type'] = event_node.getElementsByTagNameNS('*', 'EventType')[0].firstChild.nodeValue
    if event_node.getElementsByTagNameNS('*', 'CompositionID'):
        event['cpl_uuid'] = event_node.getElementsByTagNameNS('*', 'CompositionID')[0].firstChild.nodeValue.replace('urn:uuid:', '')
    if event_node.getElementsByTagNameNS('*', 'EventSubType'):
        event['subtype'] = event_node.getElementsByTagNameNS('*', 'EventSubType')[0].firstChild.nodeValue
    for parameter in event_node.getElementsByTagNameNS('*', 'Parameter'):
        name = parameter.getElementsByTagNameNS('*', 'Name')
        value = parameter.getElementsByTagNameNS('*', 'Value')
        if name and name[0] and name[0].firstChild and value and value[0] and value[0].firstChild:
            event[name[0].firstChild.nodeValue] = value[0].firstChild.nodeValue

    if event_node.getElementsByTagNameNS('*', 'recordDescriptionText'):
        event['record_description_text'] = event_node.getElementsByTagNameNS('*', 'recordDescriptionText')[0].firstChild.nodeValue
    return event


def process_doremi_playout_events(doremi_events):
    """
    Filters out the playlist events
    """
    events = []
    for doremi_event in doremi_events:
        if not doremi_event.has_key('subtype') or doremi_event['subtype'] != 'AsRunLogEvent' or not doremi_event.has_key('record_description_text'):
            continue
        start_time, end_time = doremi_event['record_description_text'].replace('"', '').split(',')[2:4]
        seconds_played = parse_simple_duration(end_time) - parse_simple_duration(start_time)
        if seconds_played < 0:
            seconds_played *= -1
        events.append({'start_timestamp': doremi_event['timestamp'] - seconds_played,
         'end_timestamp': doremi_event['timestamp'],
         'cpl_uuid': doremi_event.get('cpl_uuid'),
         'seconds_played': seconds_played})

    return events


class DoremiLegacyLog(object):
    """
    Log manager for Doremi legacy logs (http://www.smpte-ra.org/430.4/2006/LogRecord)
    """

    def __init__(self, xml):
        self.xml = xml
        self._dom = minidom.parseString(xml)
        self._events = None
        return

    thumbprint = None
    serial = None

    @property
    def has_playouts(self):
        """
        Returns True if the log has any playout events
        """
        return bool(self.events(subfilter=['AsRunLogEvent']))

    @property
    def first_playout_timestamp(self):
        """
        Returns the timestamp of the earliest playout event
        """
        if self.has_playouts:
            return self.events(subfilter=['AsRunLogEvent'])[0]['timestamp']
        else:
            return None

    @property
    def last_playout_timestamp(self):
        """
        Returns the timestamp of the latest playout event
        """
        if self.has_playouts:
            return self.events(subfilter=['AsRunLogEvent'])[-1]['timestamp']
        else:
            return None

    @property
    def playouts(self):
        """
        Returns the playouts calculated from the Playout events
        """
        return process_doremi_playout_events(self.events(sorted=True, subfilter=['AsRunLogEvent']))

    def events(self, sorted = False, filter = None, subfilter = []):
        """
        Returns logged events that can be optionally sorted by timestamp and filtered
        """
        if not self._events:
            self._events = [ parse_doremi_event(e) for e in self._dom.getElementsByTagNameNS('*', 'LogRecordElement') ]
        result = self._events
        if filter:
            result = [ e for e in result if e['type'] == filter ]
        if subfilter:
            result = [ e for e in result if e['subtype'] in subfilter ]
        if sorted:
            result.sort(key=lambda e: e['timestamp'])
        return result
# okay decompyling ./lib/dcinema/logs/legacy_doremi.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:51 CST
