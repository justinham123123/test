# 2017.08.13 21:51:50 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\logs\__init__.py
pass
# okay decompyling ./lib/dcinema/logs/__init__.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:50 CST
