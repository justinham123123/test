# 2017.08.13 21:51:35 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\cherrypy\cherrypy_utils.py
"""
Utility methods for cherrypy
"""
import sys
import os
import logging
import inspect
import signal
import logging.handlers
import time
import threading
from collections import deque
import ujson
from decorator.decorator import decorator
from cherrypy._cpcompat import get_daemon
import cherrypy
WIN32 = False
POSIX = False
if os.name == 'nt':
    WIN32 = True
elif os.name == 'posix':
    POSIX = True

def get_resource(resource):
    """
    Gets an absolute resource path, either using setuptool's package resources, or
    simply with __file__ if it is not installed. We need to do this as __file__ will
    fail if the code is packaged into a zipped egg.
    """
    try:
        from pkg_resources import resource_filename
    except ImportError:
        return os.path.join(os.path.dirname(__file__), resource)

    return resource_filename('serv', resource)


def get_ip_address():
    """
    Returns a IP address associated with the executing machine.
    Works on Windows, Mac and some flavours of Linux.
    """
    import sys, os
    if sys.platform == 'win32':
        for line in os.popen('ipconfig /all'):
            if line.lstrip().startswith('IP Address') or line.lstrip().startswith('IPv4 Address'):
                return line.split(':')[1].strip().replace('(Preferred)', '')

    else:
        en0 = False
        for line in os.popen('/sbin/ifconfig'):
            if line.find('en0') > -1:
                en0 = True
            if line.find('inet addr:') > -1:
                return line.split()[1].strip().replace('addr:', '')
            if line.find('inet ') > -1 and en0:
                return line.split()[1]


def config_authentication(user_name, password):
    """
    Enable user authentication in cherrypy with the supplied
    user name and password
    """
    logging.debug('Enabling authentication in CherryPy')
    cherrypy.config.update({'tools.basic_auth.on': True,
     'tools.basic_auth.realm': 'aam',
     'tools.basic_auth.users': {user_name: password}})


def config_gzip():
    """
    Enable gzip compression in cherrypy
    """
    logging.debug('Enabling gzip in CherryPy')
    cherrypy.config.update({'tools.gzip.on': True,
     'tools.gzip.mime_types': ['text/html', 'text/plain', 'text/xml']})


def config_ssl(cert, key):
    """
    Enable SSL in cherrypy with the supplied cert and key
    """
    logging.debug('Enabling SSL in CherryPy')
    cherrypy.config.update({'cherrypy.server.ssl_certificate': cert,
     'cherrypy.server.ssl_private_key': key})


def config_cherrypy_logging_time_rotation(days = 7):
    """
    Configures cherrypy's application and default logging to time rotation
    """
    log_format = logging.Formatter('[%(asctime)s] [%(filename)s:%(lineno)d] %(levelname)s - %(message)s', '%d/%b/%Y:%H:%M:%S')
    error_log_file = cherrypy.log.error_file
    for handler in cherrypy.log.error_log.handlers:
        if handler.__class__ == logging.FileHandler:
            log_level = handler.level
            cherrypy.log.error_log.removeHandler(handler)

    log_handler = logging.handlers.TimedRotatingFileHandler(error_log_file, 'D', days)
    log_handler.setFormatter(log_format)
    log_handler.setLevel(log_level)
    cherrypy.log.error_log.addHandler(log_handler)
    access_log_file = cherrypy.log.access_file
    for handler in cherrypy.log.access_log.handlers:
        if handler.__class__ == logging.FileHandler:
            log_level = handler.level
            cherrypy.log.access_log.removeHandler(handler)

    log_handler = logging.handlers.TimedRotatingFileHandler(access_log_file, 'D', days)
    log_handler.setLevel(log_level)
    cherrypy.log.access_log.addHandler(log_handler)
    if cherrypy.config['debug']:
        log_level = logging.DEBUG
    else:
        log_level = logging.INFO
    debug_log_file = cherrypy.config['log.debug_file']
    log_handler = logging.handlers.TimedRotatingFileHandler(debug_log_file, 'D', days)
    log_handler.setFormatter(log_format)
    log_handler.setLevel(log_level)
    log = logging.getLogger('debug')
    log.addHandler(log_handler)
    log.propagate = False


def configure_cherrypy(config):
    """
    Configures cherrypy from AAM-named config parameters dictionary
    
    The parameter mappings are as follows:
        environment -> env (defaults to production)
        server.socket_host -> ip (defaults to get_ip_address() if not present)
        server.socket_port -> port (defaults to 8080)
        log.error_file -> log_file
        log.access_file -> access_log_file
        server.thread_pool -> thread_pool (defaults to 50)
        engine.autoreload_on -> auto_reload (default to False)
    
    Non-cherrypy required settings:
    
        root_path - the root path from which files hang
    """
    if not os.path.exists(config['root_path']):
        os.mkdir(config['root_path'])
    cherrypy.config.update({'environment': config.get('env', 'production'),
     'server.socket_host': config.get('ip', get_ip_address()),
     'server.socket_port': config.get('port', 8080),
     'log.error_file': os.path.join(config['root_path'], 'log', config['log_file']),
     'log.access_file': os.path.join(config['root_path'], 'log', config['access_log_file']),
     'log.debug_file': os.path.join(config['root_path'], 'log', config['debug_log_file']),
     'server.thread_pool': config.get('thread_pool', 150),
     'engine.autoreload.on': config.get('auto_reload', False),
     'pid_file': os.path.join(config['root_path'], 'lock', config['pid_file']),
     'debug': config.get('debug', False)})
    if hasattr(cherrypy.engine, 'signal_handler'):
        cherrypy.engine.signal_handler.subscribe()
    if hasattr(cherrypy.engine, 'console_control_handler'):
        WindowsServiceHandler(cherrypy.engine).subscribe()
    config_cherrypy_logging_time_rotation()


def start_cherrypy(options, nt_service_class = None):
    """
    Start the cherrypy service
    """
    if POSIX:
        from cherrypy.process.plugins import Daemonizer, PIDFile
        cherrypy.log('Will start on a POSIX compliant OS')
        if options.stop_daemon:
            try:
                pid = open(cherrypy.config['pid_file'], 'r').read()
                cherrypy.log('Shutting down service')
                print 'Stopping Director daemon'
                os.kill(int(pid), signal.SIGINT)
            except IOError:
                cherrypy.log('No PID file found, aborting shutdown')

            sys.exit(1)
        if not options.start_console:
            if os.path.exists(cherrypy.config['pid_file']):
                print 'Application is already running. Exiting. Pid file exists:' + cherrypy.config['pid_file']
                sys.exit(1)
            Daemonizer(cherrypy.engine).subscribe()
            PIDFile(cherrypy.engine, cherrypy.config['pid_file']).subscribe()
            print 'Director running in daemon mode on {ip}:{port}'.format(ip=cherrypy.config['server.socket_host'], port=cherrypy.config['server.socket_port'])
        else:
            print 'Director running in console mode on {ip}:{port}'.format(ip=cherrypy.config['server.socket_host'], port=cherrypy.config['server.socket_port'])
        _start_cherrypy()
    elif WIN32:
        cherrypy.engine.log('Running on Windows')
        if len([ argument for argument in sys.argv if argument in ('start', 'stop', 'restart', 'debug', 'install', 'remove') ]) != 0:
            import win32serviceutil
            windows_argv = [ argument for argument in sys.argv if argument in [sys.argv[0],
             'start',
             'stop',
             'restart',
             'debug',
             'install',
             'remove'] ]
            win32serviceutil.HandleCommandLine(nt_service_class, argv=windows_argv)
        else:
            cherrypy.engine.log('Will start as Windows Console')
            print 'Director running in console mode on {ip}:{port}'.format(ip=cherrypy.config['server.socket_host'], port=cherrypy.config['server.socket_port'])
            _start_cherrypy()
    else:
        cherrypy.log('Running on an unsupported OS: %s. Exiting ...' % os.name)


def _start_cherrypy():
    cherrypy.engine.start()
    cherrypy.engine.block()


def exposed_methods(api_class):
    """
    Returns a dictionary of the exposed methods, their arguments,
    their doc strings and any associated json schemas.
    Currently returns no args for decorated methods
    
    { '<method name>' : { 'args' : (<arg_list>,), 'doc' : <doc string> } }
    """
    exposed_methods = {}
    ignored_methods = ['default', 'documentation']
    for method_name, method in inspect.getmembers(api_class, inspect.ismethod):
        if (getattr(method, 'exposed', False) or method_name.startswith('handle_')) and method_name.lower() not in ignored_methods:
            if not getattr(method, 'exposed', False) and method_name.startswith('handle_'):
                method_name = method_name.replace('handle_', '', 1)
            exposed_methods[method_name] = {}
            arg_spec = inspect.getargspec(method)
            args = arg_spec.args[1:]
            if args:
                exposed_methods[method_name]['args'] = args
            if arg_spec.varargs:
                exposed_methods[method_name]['varargs'] = arg_spec.varargs
            if arg_spec.keywords:
                exposed_methods[method_name]['keywords'] = arg_spec.keywords
            if method.__doc__:
                exposed_methods[method_name]['doc'] = method.__doc__

    return exposed_methods


class WebserverShutdownInProgress(Exception):
    pass


def stop_if_webserver_shutting_down(func):
    """
    This decorator wraps functions to prevent their execution if the webserver is shutting down.
    
    Be very careful which functions you wrap, you must ensure that the DB etc would be left in a consistent
    if execution stops at the call of the function which this code wraps.
    """

    def wrapper(*args, **kwargs):
        if cherrypy.engine.state == cherrypy.process.wspbus.states.STOPPING:
            raise WebserverShutdownInProgress()
        return func(*args, **kwargs)

    return wrapper


if WIN32:

    class Win32Service(cherrypy.process.win32.PyWebService):
        """
        Manages the app as a Windows Service
        """
        _exe_name_ = None
        _svc_name_ = 'AAM Cinema Services'
        _svc_display_name_ = 'AAM Cinema Services'
        _svc_description_ = 'AAM Cinema Services'

        def SvcDoRun(self):
            logging.debug('Will start as Windows Service')
            cherrypy.config.update({'global': {'engine.autoreload.on': False,
                        'engine.SIGHUP': None,
                        'engine.SIGTERM': None}})
            main()
            return


    import win32con

    class WindowsServiceHandler(cherrypy.process.win32.ConsoleCtrlHandler):
        """A WSPBus plugin for handling Win32 console events (like Ctrl-C)."""

        def handle(self, event):
            """Handle console control events (like Ctrl-C)."""
            if event in (win32con.CTRL_LOGOFF_EVENT,):
                self.bus.log('Service event %s: ignoring this!' % event)
                return 1
            elif event in (win32con.CTRL_C_EVENT,
             win32con.CTRL_BREAK_EVENT,
             win32con.CTRL_SHUTDOWN_EVENT,
             win32con.CTRL_CLOSE_EVENT):
                self.bus.log('Console event %s: shutting down bus' % event)
                try:
                    self.stop()
                except ValueError:
                    pass

                self.bus.exit()
                return 1
            else:
                self.bus.log('Unhandled event %s' % event)
                return 0


class TmsBackgroundTask(cherrypy.process.plugins.BackgroundTask):
    """
    Flexible Background Tasks
    """

    def __init__(self, frequency, callback, bus, first_run_offset):
        super(TmsBackgroundTask, self).__init__(frequency, callback, bus=bus)
        self.first_run_offset = first_run_offset

    def run(self):
        self.running = True
        if self.first_run_offset is not None:
            self._run_once()
        while self.running:
            time.sleep(self.interval)
            self._do_run()

        return

    def _do_run(self):
        if not self.running:
            return
        try:
            self.function(*self.args, **self.kwargs)
        except Exception:
            if self.bus:
                self.bus.log('Error in background task thread function %r.' % self.function, level=40, traceback=True)

    def _run_once(self):
        time.sleep(self.first_run_offset)
        self._do_run()


class TmsMonitor(cherrypy.process.plugins.Monitor):
    """
    Flexible Background Task running
    """

    def __init__(self, bus, callback, frequency, name, first_run_offset = None):
        """
        :param first_run_offset: Default is None, meaning task is NOT run at start_up.
            If set (integer), run the task ONCE this many seconds after start_up, then as scheduled
        """
        super(TmsMonitor, self).__init__(bus, callback, frequency, name)
        self.first_run_offset = first_run_offset

    def start(self):
        if self.frequency > 0:
            if not self.name:
                threadname = self.__class__.__name__
                self.thread = self.thread is None and TmsBackgroundTask(self.frequency, self.callback, self.bus, self.first_run_offset)
                self.thread.setName(threadname)
                self.thread.start()
                self.bus.log('Started monitor thread %r.' % threadname)
            else:
                self.bus.log('Monitor thread %r already started.' % threadname)
        return

    start.priority = 90


class DeviceMonitor(cherrypy.process.plugins.Monitor):
    """
    Extension of the Cherrypy Monitor class that also takes arguments for its callback function
    """

    def __init__(self, bus, callback, frequency, name, *args):
        super(DeviceMonitor, self).__init__(bus, callback, frequency)
        self.name = name
        self.args = [callback]
        self.args.extend(args)

    def callback_wrapper(self, *args, **kwags):
        try:
            args[0](*args[1:])
        except Exception as ex:
            logging.error('There was a problem in DeviceMonitor [%s]' % self.name, exc_info=True)

    def device_remove(self, device):
        if device.device_id in self.args:
            self.unsubscribe()
            self.stop(join=True)

    def start(self):
        """Start our callback in its own perpetual timer thread."""
        if self.frequency > 0:
            if not self.name:
                threadname = self.__class__.__name__
                self.thread = self.thread is None and cherrypy.process.plugins.BackgroundTask(self.frequency, self.callback_wrapper, self.args)
                self.thread.setName(threadname)
                self.thread.bus = self.bus
                self.thread.start()
            else:
                logging.debug('Monitor thread %r already started.' % threadname)
        return

    start.priority = 90

    def stop(self, join = False):
        """Stop our callback's background task thread."""
        if self.thread is None:
            self.bus.log('No thread running for %s.' % self.name or self.__class__.__name__)
        else:
            if self.thread is not threading.currentThread():
                name = self.thread.getName()
                self.thread.cancel()
                if not get_daemon(self.thread) or join:
                    self.bus.log('Joining %r' % name)
                    self.thread.join()
                self.bus.log('Stopped thread %r.' % name)
            self.thread = None
        return


def json_input(json_list = [], is_default = False):
    if is_default:
        cherrypy.request.headers['is_default'] = True
    if cherrypy.request.headers.has_key('content-type') and 'application/json' in cherrypy.request.headers['content-type'].lower():
        body = cherrypy.request.body.read()
        params = ujson.loads(body)
        for k, v in params.items():
            cherrypy.request.params[k.encode('ascii')] = v

    elif json_list:
        for k, v in cherrypy.request.params.items():
            if k in json_list:
                cherrypy.request.params[k.encode('ascii')] = ujson.loads(v)


MIN_API_RESPONSE_SIZE_TO_LOG = 256000

def json_out_handler(*args, **kwargs):
    value = cherrypy.serving.request._json_inner_handler(*args, **kwargs)
    cherrypy.response.headers['Cache-Control'] = 'no-cache'
    cherrypy.response.headers['Max-Age'] = '-1'
    try:
        call = cherrypy.request.path_info
        user = cherrypy.request.user.get('username', 'Unknown')
    except AttributeError:
        call = 'None'
        user = 'None'

    if cherrypy.core.log_all_api_requests:
        logging.info('Jsonifying output from %s for %s', call, user)
    try:
        output = ujson.dumps(value)
    except (MemoryError, OverflowError):
        logging.critical('Out of memory jsonifying output from %s for user %s', call, user, exc_info=True)
        raise

    try:
        size = len(output)
        input_size = float(cherrypy.request.headers.get('Content-Length', 0))
        if size > MIN_API_RESPONSE_SIZE_TO_LOG:
            _record_api_offenses(cherrypy.core.api_call_size_cache, call, size / 1024.0 / 1024.0)
        if input_size > MIN_API_RESPONSE_SIZE_TO_LOG:
            _record_api_offenses(cherrypy.core.api_call_size_cache, 'IN>%s' % call, input_size / 1024.0 / 1024.0)
    except Exception as e:
        logging.error('Error in request stat grab: %s', e)

    return output


def json_out_handler_raw(*args, **kwargs):
    value = cherrypy.serving.request._json_inner_handler(*args, **kwargs)
    cherrypy.response.headers['Cache-Control'] = 'no-cache'
    cherrypy.response.headers['Max-Age'] = '-1'
    return ujson.dumps(value, ensure_ascii=False)


def ignore_input(ignore_list = ['_']):
    for k in cherrypy.request.params.keys():
        if k in ignore_list:
            del cherrypy.request.params[k]


@decorator
def cherrypy_peformance_log(func, *args, **kwargs):
    """
    This function can be decorated on another function to
    remove threaded parameters
    """
    then = time.time()
    output = func(*args, **kwargs)
    duration = time.time() - then
    if duration > 1:
        call = func.__module__ + '.' + func.__name__
        _record_api_offenses(cherrypy.core.performance_cache, call, duration)
    return output


def _record_api_offenses(cache, call, value):
    try:
        user = cherrypy.request.user.get('username', 'Unknown')
    except AttributeError:
        user = 'None'

    offender = {'value': value,
     'at': time.time(),
     'user': user}
    offenses = {'recent': deque(maxlen=5),
     'worst': None,
     'total': 0,
     'count': 0}
    call_offenses = cache.setdefault(call, offenses)
    call_offenses['recent'].append(offender)
    call_offenses['count'] += 1
    call_offenses['total'] += value
    if call_offenses['worst'] is None or value > call_offenses['worst']['value']:
        call_offenses['worst'] = offender
    return
# okay decompyling ./lib/cherrypy/cherrypy_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:37 CST
