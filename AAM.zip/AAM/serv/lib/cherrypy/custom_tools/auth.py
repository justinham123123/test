# 2017.08.13 21:51:38 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\cherrypy\custom_tools\auth.py
import cherrypy
if not hasattr(cherrypy.tools, 'authenticate'):
    import serv.auth.auth_main
# okay decompyling ./lib/cherrypy/custom_tools/auth.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:38 CST
