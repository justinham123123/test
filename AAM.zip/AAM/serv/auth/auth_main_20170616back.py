# 2017.08.13 21:47:44 CST
# Embedded file name: /usr/lib/python2.6/site-packages/aam_screenwriter-2.4.1.1.393-py2.6.egg/serv/auth/auth_main.py
"""
Authentication manager for CherryPy apps
"""
import os
import logging
import json
import random
import hashlib
import re
import time
import urllib
import gettext
import cherrypy
from cherrypy.lib.static import serve_file
from serv import static_dir
from serv.configuration.constants import DEFAULT_USERS
from serv.lib.utilities import config
from serv.auth.license_auth_map import LICENSES, USER_GROUPS, FEATURE_SETS
from serv.auth.license import decrypt
from serv.lib.cherrypy.cherrypy_utils import json_out_handler
from serv.lib.utilities.utils import get_macs
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.cherrypy.i18n_tool import update_language, i18n_mo_dir, i18n_domain
from serv.lib.utilities.helper_methods import audit_log
from serv.configuration import cfg
import serv.lib.cherrypy.custom_tools.handlers
TIMEOUT = 120
COMPILED_AUTH_MATCH = re.compile('(?P<subme>.*)\\/([\\d]+|[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12})$')
invalid_license = None
invalid_license_reason = None
license_map = {}
group_permission_map = {}

def authenticate(unlock_session = True):
    global invalid_license
    global license_map
    global invalid_license_reason
    global group_permission_map
    try:
        path = ''.join([cherrypy.request.script_name, cherrypy.request.path_info]).strip('/')
        reg_match = re.match(COMPILED_AUTH_MATCH, path)
        if reg_match:
            path = reg_match.group(1)
        user_id = None
        username = None
        password = None
        if 'username' in cherrypy.request.params and 'password' in cherrypy.request.params:
            username = cherrypy.request.params.pop('username')
            password = cherrypy.request.params.pop('password')
        elif 'username' in cherrypy.request.body.params and 'password' in cherrypy.request.body.params:
            username = cherrypy.request.body.params.pop('username')
            password = cherrypy.request.body.params.pop('password')
        if username is not None and password is not None:
            user_id = cherrypy.aam_auth._check_user(username, password)
        else:
            user_id = cherrypy.session.get('user_id')
        if cfg.audit_requests_enabled.get():
            audit_log('HTTP Request - ' + str(cherrypy.request.path_info) + '  |  ' + str(cherrypy.request.params), tags=['request'])
        if not user_id or cherrypy.aam_auth.get_user(user_id) is None:
            cherrypy.session.delete()
            if cherrypy.request.method == 'GET':
                redirect = '/'
                relative_url = cherrypy.url(qs=cherrypy.request.query_string, relative='server')
                if relative_url:
                    redirect += '?redirect=' + urllib.quote(relative_url)
                cherrypy.response.headers['Cache-Control'] = 'no-cache'
                cherrypy.response.headers['Pragma'] = 'no-cache'
                raise cherrypy.HTTPRedirect(redirect)
            raise cherrypy.HTTPError(401, _('You must be logged in to continue'))
        if not cherrypy.aam_auth.license or not cherrypy.aam_auth.license_expires:
            invalid_license = True
            invalid_license_reason = _('Your license is invalid. You now have read-only privileges. To extend your license please contact your software distributor.')
        elif time.mktime(cherrypy.aam_auth.license_expires.timetuple()) < time.time():
            invalid_license = True
            invalid_license_reason = _('Your license has expired. You now have read-only privileges. To extend your license please contact your software distributor.')
        elif str(cherrypy.aam_auth.license['mac']) not in [ mac.upper() for mac in cherrypy.aam_auth.macs ]:
            invalid_license = True
            invalid_license_reason = _('Licensed MAC address does not match. You now have read-only privileges. To extend your license please contact your software distributor.')
        else:
            cherrypy.request.user = cherrypy.aam_auth.users[user_id].copy()
            invalid_license = False
            invalid_license_reason = None
        if invalid_license:
            user_id, user = cherrypy.aam_auth.get_read_only()
        if not invalid_license and path not in license_map:
            raise cherrypy.HTTPError(403, _('You are not licensed to use this feature. To extend your license please contact your software distributor.') + path)
        group = cherrypy.aam_auth.users[user_id]['group']
        if path not in group_permission_map[group]:
            raise cherrypy.HTTPError(403, _('You do not have sufficient rights to continue'))
    finally:
        if unlock_session:
            cherrypy.session.release_lock()

    return


cherrypy.tools.authenticate = cherrypy.Tool('before_handler', authenticate, priority=60)

def ignore_authentication():
    """
    When a URI end point is not decorated with authenticate and credentials are
    passed in a POST, the server throws a 400 due to the unexpected 'username' and
    'password' parameters.
    
    This CherryPy tool will check for these parameters and strip them out of the request.
    """
    if 'username' in cherrypy.request.params and 'password' in cherrypy.request.params:
        cherrypy.request.params.pop('username')
        cherrypy.request.params.pop('password')
    if 'username' in cherrypy.request.body.params and 'password' in cherrypy.request.body.params:
        cherrypy.request.body.params.pop('username')
        cherrypy.request.body.params.pop('password')


cherrypy.tools.ignore_authentication = cherrypy.Tool('before_handler', ignore_authentication, priority=60)

class Auth(object):
    """
    Core object that exposes the original Core api, and translates functionality and behaviour
    from core2 into traditional core
    """

    def __init__(self, cfg, db):
        """
        Takes a Core2 instance to allow the beacon api to call directly into core2
        """
        cherrypy.aam_auth = self
        self.cfg = cfg
        self.db = db
        current_users = [ user[0] for user in db.Session.query(db.User.username).all() ]
        for required_user in DEFAULT_USERS:
            if required_user['username'] not in current_users:
                self.db.Session.add(self.db.User(**required_user))

        self.db.Session.commit()
        self.db.Session.close()
        self.users = self.load_users()
        try:
            self.license = decrypt(self.cfg.license())
            self.license_expires = self.license.get('expiry')
        except Exception:
            logging.warning('Unable to load license', exc_info=True)
            self.license = {}
            self.license_expires = None

        self.load_mac_address_identifier()
        self.build_group_permissions()
        self.build_license()
        return

    def build_license(self):
        global license_map
        if self.license:
            if invalid_license or self.license['product'] == 'scr-':
                self.license['licensed'] = ['tms_general_license',
                 'tms_pos_license',
                 'tms_camera_license',
                 'tms_smart_playlist_license']
            if self.license['product'] == 'scr':
                self.license['licensed'] = ['tms_general_license', 'tms_pos_license']
            elif self.license['product'] == 'scr+':
                self.license['licensed'] = ['tms_general_license',
                 'tms_pos_license',
                 'tms_camera_license',
                 'tms_smart_playlist_license']
        new_license_map = {}
        if self.license:
            for module in self.license['licensed']:
                if LICENSES.has_key(module):
                    for feature in LICENSES[module]['features']:
                        for feature_set in FEATURE_SETS[feature]:
                            for action in feature_set:
                                new_license_map[action] = True

        license_map = new_license_map

    def build_group_permissions(self):
        global group_permission_map
        group_permission_map = {}
        for group_name, group in USER_GROUPS.iteritems():
            group_permission_map[group_name] = {}
            for feature in group['features']:
                for feature_set in FEATURE_SETS[feature]:
                    for action in feature_set:
                        group_permission_map[group_name][action] = True

    def load_mac_address_identifier(self):
        macs = get_macs()
        self.full_macs = []
        self.macs = []
        self.generate_license_tokens(macs)
        for mac in macs:
            self.full_macs.append(mac)
            primary_mac = mac.split(':')
            self.macs.append(str(primary_mac[-2]) + str(primary_mac[-1]))

    def license_m2t_helper(self, input, d):
        inputmap = map(lambda x: int(x, 16), list(input))
        outputmap = map(lambda x: (x + d) % 16, inputmap)
        outputchars = map(lambda x: '%x' % x, outputmap)
        return outputchars

    def license_m2t(self, input):
        cleaned_input = input.replace(':', '')
        if len(cleaned_input) == 12:
            lastcharslist = list(cleaned_input[-8:])
            inputlist = self.license_m2t_helper(list(cleaned_input), 3)
            almostthere = lastcharslist[0:2] + inputlist[0:1] + lastcharslist[2:3] + inputlist[1:2] + lastcharslist[3:4] + inputlist[2:4] + lastcharslist[4:5] + inputlist[4:7] + lastcharslist[5:6] + inputlist[7:10] + lastcharslist[6:] + inputlist[10:]
            return re.sub('(\\w\\w\\w\\w)(\\w\\w\\w\\w)(\\w\\w\\w\\w)(\\w\\w\\w\\w)(\\w\\w\\w\\w)', '\\1-\\2-\\3-\\4-\\5', ''.join(almostthere).upper())
        else:
            return ''

    def license_t2m(self, input):
        inputlist = list(input.replace('-', ''))
        cleaned_input = inputlist[2:3] + inputlist[4:5] + inputlist[6:8] + inputlist[9:12] + inputlist[13:16] + inputlist[18:]
        outputstr = ''.join(self.license_m2t_helper(cleaned_input, -3))
        return re.sub('(\\w\\w)(\\w\\w)(\\w\\w)(\\w\\w)(\\w\\w)(\\w\\w)', '\\1:\\2:\\3:\\4:\\5:\\6', outputstr)

    def generate_license_tokens(self, macs):
        self.license_tokens = []
        for mac in macs:
            self.license_tokens.append(self.license_m2t(mac))

        self.license_tokens = list(set(self.license_tokens))

    def load_users(self):
        session = self.db.Session()
        output = {}
        users = session.query(self.db.User).all()
        for user in users:
            output[str(user.id)] = {'password': user.password,
             'username': user.username,
             'group': user.group,
             'display_name': user.display_name}

        session.close()
        return output

    def get_read_only(self):
        for id in self.users:
            if self.users[id]['username'] == 'read_only' and self.users[id]['group'] == 'read_only':
                return (id, self.users[id].copy())

        return (None, None)

    def get_user(self, user_id):
        return self.users.get(user_id, None)

    @cherrypy.expose
    @cherrypy.tools.response_headers(headers=[('Cache-Control', 'no-cache'), ('Pragma', 'no-cache')])
    def index(self, *args, **kwargs):
        return serve_file(os.path.join(static_dir, 'html/pages/login.html'))

    def _check_user(self, username, password):
        for user_id, user in self.users.iteritems():
            if user['username'] == username and self._check_password(password, user['password']):
                return user_id

        return None

    def _login_user(self, username, password):
        user_id = self._check_user(username, password)
        if user_id is not None:
            cherrypy.session.delete()
            cherrypy.session['user_id'] = user_id
            return True
        else:
            return False
            return

    @cherrypy.expose
    @cherrypy.tools.json_input()
    def login_user(self, username = None, password = None, redirect = None):
        if self._login_user(username, password):
            if redirect:
                raise cherrypy.HTTPRedirect(urllib.unquote(redirect))
            else:
                raise cherrypy.HTTPRedirect(self.cfg.default_url)
        else:
            raise cherrypy.HTTPRedirect('/?login_error=true')

    @cherrypy.expose
    def logout_user(self):
        cherrypy.session.delete()
        raise cherrypy.HTTPRedirect('/')

    @cherrypy.expose
    @cherrypy.tools.authenticate(unlock_session=False)
    @cherrypy.tools.json_out(handler=json_out_handler)
    def get_user_information(self):
        licensed_and_authenticated = set([])
        licensed = self.license['licensed'] if self.license.has_key('licensed') else ['tms_general_license', 'tms_pos_license', 'tms_unknown']
        if invalid_license:
            licensed = ['tms_core_only_license']
        for module in licensed:
            if module in LICENSES:
                licensed_and_authenticated = licensed_and_authenticated.union(LICENSES[module]['features'])

        enabled = {}
        enabled['lms'] = self.cfg.lms_enabled.get()
        enabled['pos'] = self.cfg.pos_enabled.get()
        enabled['audit_log'] = self.cfg.audit_log_enabled.get()
        enabled['live_chat_enabled'] = self.cfg.core_chat_live_enabled.get()
        enabled['mail_enabled'] = self.cfg.core_chat_email_enabled.get()
        if invalid_license:
            user_id, read_only = self.get_read_only()
            username = read_only['display_name']
            group = read_only['group']
            group_features = USER_GROUPS.get(group, {'features': []})['features']
            licensed_and_authenticated = list(licensed_and_authenticated.intersection(group_features))
        else:
            user_id = cherrypy.session.get('user_id')
            username = self.get_user(user_id)['display_name']
            group = cherrypy.aam_auth.users[user_id]['group']
            group_features = USER_GROUPS.get(group, {'features': []})['features']
            licensed_and_authenticated = list(licensed_and_authenticated.intersection(group_features))
        output = {'username': username,
         'licensed_and_authenticated': licensed_and_authenticated,
         'enabled': enabled,
         'invalid_license': invalid_license,
         'invalid_license_reason': invalid_license_reason,
         'license_type': self.license['product'] if self.license else 'scr'}
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate(unlock_session=False)
    @cherrypy.tools.json_out(handler=json_out_handler)
    def get_user_accounts(self):
        output = {'users': [],
         'groups': {}}
        user_id = cherrypy.session.get('user_id')
        user = self.get_user(user_id)
        user_group = USER_GROUPS[user['group']]
        for group_name, details in USER_GROUPS.iteritems():
            if details['rank'] <= user_group['rank']:
                output['groups'][group_name] = details['name']

        users = self.db.Session.query(self.db.User).filter(self.db.User.group.in_(output['groups'].keys()))
        for user in users:
            output['users'].append({'user_id': user.id,
             'username': user.username,
             'group': user.group,
             'display_name': user.display_name})

        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def edit_user(self, user):
        if user['user_id']:
            return self.modify_user(user['user_id'], user['username'], user['current_password'], user['new_password'], user['confirm_new_password'], user['display_name'], user['group'])
        else:
            return self.add_user(user['username'], user['new_password'], user['confirm_new_password'], user['display_name'], user['group'])

    def modify_user(self, user_id, new_username, current_password, new_password, confirm_new_password, display_name, group):
        output = {'data': {},
         'messages': []}
        try:
            user = self.db.Session.query(self.db.User).filter(self.db.User.id == user_id).one()
            if self._check_password(current_password, user.password):
                if new_username != user.username:
                    existing_users = self.db.Session.query(self.db.User).filter(self.db.User.username == new_username).count()
                    if existing_users > 0:
                        output['messages'].append({'type': 'error',
                         'message': _('Username is already in use')})
                        return output
                user.username = new_username
                if new_password != '':
                    if new_password == confirm_new_password:
                        user.password = self._set_password(new_password)
                    else:
                        output['messages'].append({'type': 'error',
                         'message': _('Password Confirmation incorrect')})
                        return output
                user.display_name = display_name
                user.group = group
                self.db.Session.commit()
                self.users = self.load_users()
                output['messages'].append({'type': 'success',
                 'message': _('User modified')})
            else:
                output['messages'].append({'type': 'error',
                 'message': _('Incorrect password')})
                return output
        except Exception as e:
            output['messages'].append({'type': 'error',
             'message': _('Error modifying user')})
            logging.error('Error modifying user: ' + str(e))

        return output

    def add_user(self, new_username, new_password, confirm_new_password, display_name, group):
        output = {'data': {},
         'messages': []}
        try:
            existing_users = self.db.Session.query(self.db.User).filter(self.db.User.username == new_username).count()
            if existing_users > 0:
                output['messages'].append({'type': 'error',
                 'message': _('Username is already in use')})
            elif new_password == confirm_new_password:
                new_user = self.db.User(username=new_username, password=self._set_password(new_password), display_name=display_name, group=group)
                self.db.Session.add(new_user)
                self.db.Session.commit()
                cherrypy.engine.publish('add_user', new_user.id)
                self.users = self.load_users()
                output['messages'].append({'type': 'success',
                 'message': _('Saved')})
            else:
                output['messages'].append({'type': 'error',
                 'message': _('Password Confirmation incorrect')})
                return output
        except Exception as e:
            output['messages'].append({'type': 'error',
             'message': _('Error adding user')})
            logging.error('Error modifying user: ' + str(e))

        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def delete_user(self, user_id):
        user = self.db.Session.query(self.db.User).filter(self.db.User.id == user_id).one()
        output = {'data': {},
         'messages': []}
        user_id = user.id
        self.db.Session.delete(user)
        self.db.Session.commit()
        cherrypy.engine.publish('delete_user', user_id)
        self.users = self.load_users()
        output['messages'].append({'type': 'success',
         'message': _('Deleted')})
        return output

    @cherrypy.expose
    @cherrypy.tools.json_out(handler=json_out_handler)
    def get_license(self):
        if self.cfg.license.get() and self.license:
            self.license['license_string'] = self.cfg.license()
        return {'license': self.license,
         'tokens': self.license_tokens}

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def save_license(self, license):
        output = {'messages': []}
        if license != self.cfg.license():
            try:
                license_info = decrypt(license)
            except:
                output['messages'].append({'type': 'error',
                 'message': _('License is invalid')})
                return output

            self.cfg.license.set(license)
            config.save()
            cherrypy.aam_auth.license = license_info
            cherrypy.aam_auth.license_expires = self.license['expiry']
            self.load_mac_address_identifier()
            self.build_group_permissions()
            self.build_license()
            output['messages'].append({'type': 'success',
             'message': 'New license saved'})
            cherrypy.engine.publish('license_updated')
        else:
            output['messages'].append({'type': 'success',
             'message': 'License already active'})
        return output

    @cherrypy.expose
    @cherrypy.tools.response_headers(headers=[('Cache-Control', 'no-cache'), ('Content-Type', 'text/javascript')])
    def i18n(self):
        output = "\n        var catalog = new Array();\n\n        function pluralidx(count) { return (count == 1)?0:1; }\n\n        function gettext(msgid) {\n          var value = catalog[msgid];\n          if (typeof(value) == 'undefined') {\n            return msgid;\n          } else {\n            return (typeof(value) == 'string')?value:value[0];\n          }\n        }\n        "
        ustring_re = re.compile(u'([\x80-\uffff])')

        def javascript_quote(s, quote_double_quotes = True):

            def fix(match):
                return '\\u%04x' % ord(match.group(1))

            if type(s) == str:
                s = s.decode('utf-8')
            elif type(s) != unicode:
                raise TypeError, s
            s = s.replace('\\', '\\\\')
            s = s.replace('\r', '\\r')
            s = s.replace('\n', '\\n')
            s = s.replace('\t', '\\t')
            s = s.replace("'", "\\'")
            if quote_double_quotes:
                s = s.replace('"', '&quot;')
            return str(ustring_re.sub(fix, s))

        loc = cherrypy.response.i18n.locale
        y = gettext.translation(i18n_domain, i18n_mo_dir, [str(loc)])
        for k, v in y._catalog.iteritems():
            if k != '':
                output += 'catalog["%s"]="%s";\n' % (javascript_quote(k), javascript_quote(v))

        output += 'var lang = "%s";\n' % str(loc)
        return output

    @cherrypy.expose
    @cherrypy.tools.json_out(handler=json_out_handler)
    def i18n2(self, loc = None):
        """Retrieves a all the displayed strings for the front end, translated into the
           current users language (using the local in the HTTP request)
        
           The strings are converted first into unicode if not alread (e.g. UTF-8), and
           double quotes are converted escaped with: &quot;
        
        Returns:
            json dict containing:
                * catalog - dictionary of strings & their translated value
                * lang    - language used (as identified in the request
                * locales - a list of available locales we can translate to
        
        Raises:
            TypeError
        
        """
        catalog = {}
        loc_data = {}
        if loc is None:
            cookie = cherrypy.request.cookie
            if 'etms_lang' in cookie and cookie['etms_lang'].value:
                loc = cookie['etms_lang'].value
            else:
                loc = cherrypy.response.i18n.locale

        def javascript_quote(s):

            def fix(match):
                return '\\u%04x' % ord(match.group(1))

            if type(s) == str:
                s = s.decode('utf-8')
            elif type(s) != unicode:
                raise TypeError, s
            s = s.replace('"', '&quot;')
            return s.encode('utf-8')

        def get_available_locales():
            return filter(lambda x: x != 'templates' and x.find('.') == -1, os.listdir(i18n_mo_dir))

        try:
            y = gettext.translation(i18n_domain, i18n_mo_dir, [str(loc)])
        except IOError:
            loc = cherrypy.response.i18n.locale
            y = gettext.translation(i18n_domain, i18n_mo_dir, [str(loc)])

        for k, v in y._catalog.iteritems():
            if k != '':
                catalog[javascript_quote(k)] = javascript_quote(v)

        loc_data['lang'] = str(loc)
        loc_data['catalog'] = catalog
        loc_data['locales'] = get_available_locales()
        return loc_data

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    def set_language(self, lang_code):
        cherrypy.response.cookie['serv_language'] = lang_code
        cherrypy.response.cookie['serv_language']['max-age'] = 604800
        cherrypy.response.cookie['serv_language']['path'] = '/'
        cherrypy.response.cookie['serv_language']['version'] = 1
        cfg.core_language.set(lang_code)
        config.save()
        update_language(lang_code)
        raise cherrypy.HTTPRedirect(self.cfg.default_url)

    def _check_password(self, password, check_password):
        try:
            salt, enc_password = check_password.split('$')
            return self._encode_password(salt, password) == enc_password
        except Exception:
            logging.error('Error checking password [%s] against [%s]' % (password, check_password))
            return False

    def _set_password(self, password):
        try:
            salt = os.urandom(128 / 8).encode('hex')
        except NotImplementedError:
            salt = self._encode_password(unicode(random.random()), unicode(random.random()))[:5]

        return '$'.join([salt, self._encode_password(salt, password)])

    def _encode_password(self, salt, password):
        return hashlib.sha1((salt + password).encode('utf-8')).hexdigest()

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.response_headers(headers=[('Content-Type', 'text/javascript')])
    def config(self):
        return 'var CONFIG = %s;\n' % json.dumps(config.summary())
# okay decompyling ./auth/auth_main_20170616back.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:47:48 CST
