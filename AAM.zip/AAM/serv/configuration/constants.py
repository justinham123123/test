# 2017.08.13 21:47:59 CST
# Embedded file name: build\bdist.win32\egg\serv\configuration\constants.py
"""
Useful constant values
"""
from serv.lib.cherrypy.i18n_tool import ugettext_lazy as __
from serv.lib.cherrypy.i18n_tool import ugettext as _
TRANSFER_MANAGER_CYCLE = 10
LOG_MANAGER_CYCLE = 1800
ACTION_MANAGER_CYCLE = 5
AUTO_CLEANUP_CYCLE = 18000
IMAGE_GETTER_CYCLE = 10
DRIVE_LIST_VALIDITY = 30
EMAIL_HANDLER_CYCLE = 600
DOWNLOAD_MANAGER_CYCLE = 10
SCHEDULE_MAPPER_CYCLE = 28800
PACK_SYNC_CYCLE = 120
MEMORY_MONITOR_CYCLE = 180
TOP_MONITOR_CYCLE = 3600
AUTO_TRANSFER_CYCLE = 7200
PACKAGE_MANAGER_CYCLE = 60
SCHEDULE_SYNC_CYCLE = 30
SCHEDULE_ERROR_CYCLE = 300
MARKER_CLIP_TEMPLATING_CYCLE = 1800
AUTO_CLEANUP_KDM_VALIDITY = 2
AUTO_CLEANUP_PACK_VALIDITY = 2
AUTO_CLEANUP_POS_VALIDITY = 30
AUTO_CLEANUP_SCHEDULE_VALIDITY = 7
AUTO_CLEANUP_TITLE_VALIDITY = 30
AUTO_CLEANUP_WATCHFOLDER_VALIDITY = 30
AUTO_CLEANUP_AUDIT_VALIDITY = 5000
AUTO_CLEANUP_TRANSFER_VALIDITY = 2000
MOUNT_POINT_SCAN_DEPTH = 8
DB_BACKUP_COUNT = 12
TRANSFER_STATES = {'queued': __('Queued'),
 'request_sent': __('Request Sent'),
 'queued_on_device': __('Queued on Device'),
 'active': __('Active'),
 'paused': __('Paused'),
 'verifying': __('Verifying'),
 'success': __('Success'),
 'cancelled': __('Cancelled'),
 'failed': __('Failed')}

class ContentStates:
    INFORMATION_ONLY = -2
    KEY_ONLY = -1
    VALID = 0
    MISSING_ASSETS = 1
    CORRUPT = 2
    TRANSFERRING = 3
    QUEUED_FOR_TRANSFER = 4


SESSION_ATTRIBUTES = {'hfr': ['hfr', 'high frame rate'],
 'three_d': ['3d', 'threed', 'three_d'],
 'hoh': ['hoh',
         'hard of hearing',
         'hearing impaired',
         'hi'],
 'vi': ['vi', 'visually impaired'],
 'cc': ['cc', 'closed captioned'],
 'dbox': ['dbox']}
DEFAULT_SHOW_ATTRIBUTES = [('3D', True, True),
 ('HOH', True, False),
 ('CC', True, False),
 ('VI', True, False),
 ('HI', True, False),
 ('DBOX', True, True),
 ('HFR', True, True),
 ('SUB', True, False)]
HFR_FPS = 30
POS_DEVICE_TYPES = ['vista',
 'newman',
 'sarft',
 'compeso',
 'markus',
 'dolphin',
 'dx',
 'dingxin',
 'merlin',
 'onestepahead',
 'ebillet',
 'kinodk',
 'generic',
 'emulator']
SNMP_IGNORE_LIST = {'sms': ['christie', 'barco']}
DEFAULT_PLACEHOLDERS = ['Advertisement',
 'Local Advertisement',
 'National Advertisement',
 'Gold Spot Advertisement',
 'Trailer']
DEFAULT_MACRO_PLACEHOLDERS = [('Show Start 2D',
  False,
  False,
  True),
 ('Show Start 3D',
  False,
  False,
  True),
 ('To 2D Scope',
  True,
  False,
  True),
 ('To 2D Flat',
  True,
  False,
  True),
 ('To 3D Scope',
  True,
  False,
  True),
 ('To 3D Flat',
  True,
  False,
  True),
 ('Show End',
  False,
  False,
  True),
 ('Credit Offset',
  True,
  False,
  False)]
DEFAULT_PATTERNS = [('D45DBD8A-EC4F-4C8D-86A0-EFD68E7B244B', 'Black', 0, '2D'),
 ('F3CD8A7E-9AE6-4BBC-A84A-D37C1EC985D4', 'Black', 5, '2D'),
 ('217FA9F8-CFD7-4293-A836-6363B0F883BA', 'Black', 10, '2D'),
 ('68F9BFC9-943C-46A6-A77C-80DEDF4DC7B9', 'Black', 30, '2D'),
 ('0DA0DFEB-24FC-4F7F-ACB2-A8C7EC58FDCF', 'Black', 60, '2D'),
 ('D7708EA8-BBBF-472B-9347-A69CC92BAEF5', 'Black', 120, '2D'),
 ('1D0BA658-90E6-464C-A19F-CC21D7DF83FC', 'Black', 300, '2D'),
 ('E70E5693-262E-4D2A-B700-F05D9B2C0830', 'Black 3D', 0, '3D'),
 ('A365681E-A85E-4000-B72F-14978BAA8FBD', 'Black 3D', 5, '3D'),
 ('970C63BA-C26B-4BF7-AFE2-E003D9D47E69', 'Black 3D', 10, '3D'),
 ('3C386EAB-B110-4360-85A8-9064AAEE8012', 'Black 3D', 30, '3D'),
 ('A4EE294A-6D9B-45E7-AC25-A6EBDE7067B4', 'Black 3D', 60, '3D'),
 ('1BF7AFAD-085A-4604-BCE5-6EDE186EE057', 'Black 3D', 120, '3D'),
 ('048093D8-AB0E-41FD-8A0A-6509F171BA60', 'Black 3D', 300, '3D')]
DAYS = [__('Monday'),
 __('Tuesday'),
 __('Wednesday'),
 __('Thursday'),
 __('Friday'),
 __('Saturday'),
 __('Sunday')]
SHORTDAYS = [__('Mon'),
 __('Tue'),
 __('Wed'),
 __('Thu'),
 __('Fri'),
 __('Sat'),
 __('Sun')]
MONTHS = [__('Jan'),
 __('Feb'),
 __('Mar'),
 __('Apr'),
 __('May'),
 __('Jun'),
 __('Jul'),
 __('Aug'),
 __('Sep'),
 __('Oct'),
 __('Nov'),
 __('Dec')]
AUTO_PLAYLIST_NAMES = ['{original_playlist_title}_{weekscreen}_{scheduled_playback_date}',
 '{original_playlist_title}_{screenonly}_{scheduled_playback_date}',
 '{weekscreen}_{original_playlist_title}_{scheduled_playback_date}',
 '{weekonly}_{original_playlist_title}_{scheduled_playback_date}']
AUTO_PLAYLIST_DATES = ['%Y.%m.%d_%H:%M',
 '%m.%d_%H:%M',
 '%d.%m.%Y_%H:%M',
 '%d.%m_%H:%M',
 '%m.%d.%Y_%H:%M']

def SYNC_PRESETS():
    return [{'id': 'low',
      'name': _('Low Frequency')}, {'id': 'mid',
      'name': _('Mid Frequency')}, {'id': 'high',
      'name': _('High Frequency')}]


DEFAULT_USERS = [{'username': 'read_only',
  'password': 'df38bd3cbd269697b06188e1f0f9f1b8$f29155716ee684246ebd1580ac7530687a872bfe',
  'display_name': 'Read Only',
  'group': 'read_only'},
 {'username': 'admin',
  'password': '8b90968c2a63de1c56da9237979c37db$4544a53b81790f219f0e351aede164d03d995321',
  'display_name': 'Administrator',
  'group': 'admin'},
 {'username': 'aam_support',
  'password': '3949d6ba36f807ff1378ac6d00fe32ee$f38f1a859c3a93e0352cfd8371ac38d9952e053b',
  'display_name': 'AAM Support',
  'group': 'aam_support'},
 {'username': 'aam_admin',
  'password': '7ffc014e59b16a68e4c7776fbeb4fb1c$b04cd60b22ad3dec3cdabeee6705abb32e04f9fb',
  'display_name': 'AAM Admin',
  'group': 'aam_admin'},
 {'username': 'jenkins',
  'password': 'f6b2550e12c3028703760101a6239b4f$08b5da79bb9ca9eb0142eb07f7f3977d66962ce4',
  'display_name': 'Jenkins',
  'group': 'aam_admin'},
 {'username': 'producer',
  'password': '576c7cfafd64a952ef15316a52040031$f15e283147dc709891d0d46209082af04c99df60',
  'display_name': 'Producer',
  'group': 'aam_admin'}]
# okay decompyling ./configuration/constants.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:00 CST
