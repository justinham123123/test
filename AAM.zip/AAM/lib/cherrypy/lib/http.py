# 2017.08.13 23:34:55 CST
# Embedded file name: build\bdist.win32\egg\lib\cherrypy\lib\http.py
import warnings
warnings.warn('cherrypy.lib.http has been deprecated and will be removed in CherryPy 3.3 use cherrypy.lib.httputil instead.', DeprecationWarning)
from cherrypy.lib.httputil import *
# okay decompyling ./lib/http.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 23:34:55 CST
