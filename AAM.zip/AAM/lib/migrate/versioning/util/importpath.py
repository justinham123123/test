# 2017.08.16 21:51:38 CST
# Embedded file name: build\bdist.win32\egg\lib\migrate\versioning\util\importpath.py
import os
import sys

def import_path(fullpath):
    """ Import a file with full path specification. Allows one to
        import from anywhere, something __import__ does not do. 
    """
    path, filename = os.path.split(fullpath)
    filename, ext = os.path.splitext(filename)
    sys.path.append(path)
    module = __import__(filename)
    reload(module)
    del sys.path[-1]
    return module
# okay decompyling ./util/importpath.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 21:51:38 CST
