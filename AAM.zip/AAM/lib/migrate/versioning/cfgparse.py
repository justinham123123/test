# 2017.08.16 21:51:25 CST
# Embedded file name: build\bdist.win32\egg\lib\migrate\versioning\cfgparse.py
"""
   Configuration parser module.
"""
from ConfigParser import ConfigParser
from migrate.versioning.config import *
from migrate.versioning import pathed

class Parser(ConfigParser):
    """A project configuration file."""

    def to_dict(self, sections = None):
        """It's easier to access config values like dictionaries"""
        return self._sections


class Config(pathed.Pathed, Parser):
    """Configuration class."""

    def __init__(self, path, *p, **k):
        """Confirm the config file exists; read it."""
        self.require_found(path)
        pathed.Pathed.__init__(self, path)
        Parser.__init__(self, *p, **k)
        self.read(path)
# okay decompyling ./cfgparse.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 21:51:26 CST
