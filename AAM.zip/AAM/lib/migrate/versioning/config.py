# 2017.08.16 21:51:26 CST
# Embedded file name: build\bdist.win32\egg\lib\migrate\versioning\config.py
from sqlalchemy.util import OrderedDict
__all__ = ['databases', 'operations']
databases = ('sqlite', 'postgres', 'mysql', 'oracle', 'mssql', 'firebird')
operations = OrderedDict()
operations['upgrade'] = 'upgrade'
operations['downgrade'] = 'downgrade'
# okay decompyling ./config.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 21:51:26 CST
