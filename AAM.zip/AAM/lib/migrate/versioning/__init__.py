# 2017.08.16 21:51:24 CST
# Embedded file name: build\bdist.win32\egg\lib\migrate\versioning\__init__.py
"""
   This package provides functionality to create and manage
   repositories of database schema changesets and to apply these
   changesets to databases.
"""
pass
# okay decompyling ./__init__.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 21:51:24 CST
