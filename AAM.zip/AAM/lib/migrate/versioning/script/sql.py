# 2017.08.16 21:51:34 CST
# Embedded file name: build\bdist.win32\egg\lib\migrate\versioning\script\sql.py
import logging
import shutil
from migrate.versioning.script import base
from migrate.versioning.template import Template
log = logging.getLogger(__name__)

class SqlScript(base.BaseScript):
    """A file containing plain SQL statements."""

    @classmethod
    def create(cls, path, **opts):
        """Create an empty migration script at specified path
        
        :returns: :class:`SqlScript instance <migrate.versioning.script.sql.SqlScript>`"""
        cls.require_notfound(path)
        src = Template(opts.pop('templates_path', None)).get_sql_script(theme=opts.pop('templates_theme', None))
        shutil.copy(src, path)
        return cls(path)

    def run(self, engine, step = None, executemany = True):
        """Runs SQL script through raw dbapi execute call"""
        text = self.source()
        conn = engine.connect()
        try:
            trans = conn.begin()
            try:
                dbapi = conn.engine.raw_connection()
                if executemany and getattr(dbapi, 'executescript', None):
                    dbapi.executescript(text)
                else:
                    conn.execute(text)
                trans.commit()
            except:
                trans.rollback()
                raise

        finally:
            conn.close()

        return
# okay decompyling ./script/sql.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 21:51:35 CST
