# 2017.08.16 21:51:33 CST
# Embedded file name: build\bdist.win32\egg\lib\migrate\versioning\script\__init__.py
from migrate.versioning.script.base import BaseScript
from migrate.versioning.script.py import PythonScript
from migrate.versioning.script.sql import SqlScript
# okay decompyling ./script/__init__.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 21:51:33 CST
