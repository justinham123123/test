# 2017.08.13 23:20:00 CST
# Embedded file name: build\bdist.win32\egg\lib\decorator\decorator.py
"""
Decorator module, see http://pypi.python.org/pypi/decorator
for the documentation.
"""
__version__ = '3.4.0'
__all__ = ['decorator', 'FunctionMaker', 'contextmanager']
import sys, re, inspect
if sys.version >= '3':
    from inspect import getfullargspec

    def get_init(cls):
        return cls.__init__


else:

    class getfullargspec(object):
        """A quick and dirty replacement for getfullargspec for Python 2.X"""

        def __init__(self, f):
            self.args, self.varargs, self.varkw, self.defaults = inspect.getargspec(f)
            self.kwonlyargs = []
            self.kwonlydefaults = None
            return

        def __iter__(self):
            yield self.args
            yield self.varargs
            yield self.varkw
            yield self.defaults


    def get_init(cls):
        return cls.__init__.im_func


DEF = re.compile('\\s*def\\s*([_\\w][_\\w\\d]*)\\s*\\(')

class FunctionMaker(object):
    """
    An object with the ability to create functions with a given signature.
    It has attributes name, doc, module, signature, defaults, dict and
    methods update and make.
    """

    def __init__(self, func = None, name = None, signature = None, defaults = None, doc = None, module = None, funcdict = None):
        self.shortsignature = signature
        if func:
            self.name = func.__name__
            if self.name == '<lambda>':
                self.name = '_lambda_'
            self.doc = func.__doc__
            self.module = func.__module__
            if inspect.isfunction(func):
                argspec = getfullargspec(func)
                self.annotations = getattr(func, '__annotations__', {})
                for a in ('args', 'varargs', 'varkw', 'defaults', 'kwonlyargs', 'kwonlydefaults'):
                    setattr(self, a, getattr(argspec, a))

                for i, arg in enumerate(self.args):
                    setattr(self, 'arg%d' % i, arg)

                if sys.version < '3':
                    self.shortsignature = self.signature = inspect.formatargspec(formatvalue=(lambda val: ''), *argspec)[1:-1]
                else:
                    allargs = list(self.args)
                    allshortargs = list(self.args)
                    if self.varargs:
                        allargs.append('*' + self.varargs)
                        allshortargs.append('*' + self.varargs)
                    elif self.kwonlyargs:
                        allargs.append('*')
                    for a in self.kwonlyargs:
                        allargs.append('%s=None' % a)
                        allshortargs.append('%s=%s' % (a, a))

                    if self.varkw:
                        allargs.append('**' + self.varkw)
                        allshortargs.append('**' + self.varkw)
                    self.signature = ', '.join(allargs)
                    self.shortsignature = ', '.join(allshortargs)
                self.dict = func.__dict__.copy()
        if name:
            self.name = name
        if signature is not None:
            self.signature = signature
        if defaults:
            self.defaults = defaults
        if doc:
            self.doc = doc
        if module:
            self.module = module
        if funcdict:
            self.dict = funcdict
        if not hasattr(self, 'name'):
            raise AssertionError
            raise hasattr(self, 'signature') or TypeError('You are decorating a non function: %s' % func)
        return

    def update(self, func, **kw):
        """Update the signature of func with the data in self"""
        func.__name__ = self.name
        func.__doc__ = getattr(self, 'doc', None)
        func.__dict__ = getattr(self, 'dict', {})
        func.func_defaults = getattr(self, 'defaults', ())
        func.__kwdefaults__ = getattr(self, 'kwonlydefaults', None)
        func.__annotations__ = getattr(self, 'annotations', None)
        callermodule = sys._getframe(3).f_globals.get('__name__', '?')
        func.__module__ = getattr(self, 'module', callermodule)
        func.__dict__.update(kw)
        return

    def make(self, src_templ, evaldict = None, addsource = False, **attrs):
        """Make a new function from a given template and update the signature"""
        src = src_templ % vars(self)
        if not evaldict:
            evaldict = {}
            mo = DEF.match(src)
            if mo is None:
                raise SyntaxError('not a valid function template\n%s' % src)
            name = mo.group(1)
            names = set([name] + [ arg.strip(' *') for arg in self.shortsignature.split(',') ])
            for n in names:
                if n in ('_func_', '_call_'):
                    raise NameError('%s is overridden in\n%s' % (n, src))

            if not src.endswith('\n'):
                src += '\n'
            try:
                code = compile(src, '<string>', 'single')
                exec code in evaldict
            except:
                print >> sys.stderr, 'Error in generated code:'
                print >> sys.stderr, src
                raise

            func = evaldict[name]
            attrs['__source__'] = addsource and src
            self.update(func, **attrs)
            return func

    @classmethod
    def create(cls, obj, body, evaldict, defaults = None, doc = None, module = None, addsource = True, **attrs):
        """
        Create a function from the strings name, signature and body.
        evaldict is the evaluation dictionary. If addsource is true an attribute
        __source__ is added to the result. The attributes attrs are added,
        if any.
        """
        if isinstance(obj, str):
            name, rest = obj.strip().split('(', 1)
            signature = rest[:-1]
            func = None
        else:
            name = None
            signature = None
            func = obj
        self = cls(func, name, signature, defaults, doc, module)
        ibody = '\n'.join(('    ' + line for line in body.splitlines()))
        return self.make(('def %(name)s(%(signature)s):\n' + ibody), evaldict, addsource, **attrs)


def decorator(caller, func = None):
    """
    decorator(caller) converts a caller function into a decorator;
    decorator(caller, func) decorates a function using a caller.
    """
    if func is not None:
        evaldict = func.func_globals.copy()
        evaldict['_call_'] = caller
        evaldict['_func_'] = func
        return FunctionMaker.create(func, 'return _call_(_func_, %(shortsignature)s)', evaldict, undecorated=func, __wrapped__=func)
    else:
        if inspect.isclass(caller):
            name = caller.__name__.lower()
            callerfunc = get_init(caller)
            doc = 'decorator(%s) converts functions/generators into factories of %s objects' % (caller.__name__, caller.__name__)
            fun = getfullargspec(callerfunc).args[1]
        elif inspect.isfunction(caller):
            name = '_lambda_' if caller.__name__ == '<lambda>' else caller.__name__
            callerfunc = caller
            doc = caller.__doc__
            fun = getfullargspec(callerfunc).args[0]
        else:
            name = caller.__class__.__name__.lower()
            callerfunc = caller.__call__.im_func
            doc = caller.__call__.__doc__
            fun = getfullargspec(callerfunc).args[1]
        evaldict = callerfunc.func_globals.copy()
        evaldict['_call_'] = caller
        evaldict['decorator'] = decorator
        return FunctionMaker.create('%s(%s)' % (name, fun), 'return decorator(_call_, %s)' % fun, evaldict, undecorated=caller, __wrapped__=caller, doc=doc, module=caller.__module__)
        return


def __call__(self, func):
    """Context manager decorator"""
    return FunctionMaker.create(func, 'with _self_: return _func_(%(shortsignature)s)', dict(_self_=self, _func_=func), __wrapped__=func)


try:
    from contextlib import _GeneratorContextManager
    ContextManager = type('ContextManager', (_GeneratorContextManager,), dict(__call__=__call__))
except ImportError:
    from contextlib import GeneratorContextManager

    def __init__(self, f, *a, **k):
        return GeneratorContextManager.__init__(self, f(*a, **k))


    ContextManager = type('ContextManager', (GeneratorContextManager,), dict(__call__=__call__, __init__=__init__))

contextmanager = decorator(ContextManager)
# okay decompyling decorator.pyc
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 23:20:01 CST
