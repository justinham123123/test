# 2017.08.16 17:18:08 CST
# Embedded file name: /Users/whatsthat/Development/AAM/lib/babel/__init__.py
"""Integrated collection of utilities that assist in internationalizing and
localizing applications.

This package is basically composed of two major parts:

 * tools to build and work with ``gettext`` message catalogs
 * a Python interface to the CLDR (Common Locale Data Repository), providing
   access to various locale display names, localized number and date
   formatting, etc.

:see: http://www.gnu.org/software/gettext/
:see: http://docs.python.org/lib/module-gettext.html
:see: http://www.unicode.org/cldr/
"""
from babel.core import *
__docformat__ = 'restructuredtext en'
try:
    from pkg_resources import get_distribution, ResolutionError
    try:
        __version__ = get_distribution('Babel').version
    except ResolutionError:
        __version__ = None

except ImportError:
    __version__ = None
# okay decompyling ./__init__.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 17:18:08 CST
