# 2017.08.16 17:18:22 CST
# Embedded file name: build\bdist.win32\egg\lib\babel\messages\jslexer.py
"""A simple JavaScript 1.5 lexer which is used for the JavaScript
extractor.
"""
import re
from babel.util import itemgetter
operators = ['+',
 '-',
 '*',
 '%',
 '!=',
 '==',
 '<',
 '>',
 '<=',
 '>=',
 '=',
 '+=',
 '-=',
 '*=',
 '%=',
 '<<',
 '>>',
 '>>>',
 '<<=',
 '>>=',
 '>>>=',
 '&',
 '&=',
 '|',
 '|=',
 '&&',
 '||',
 '^',
 '^=',
 '(',
 ')',
 '[',
 ']',
 '{',
 '}',
 '!',
 '--',
 '++',
 '~',
 ',',
 ';',
 '.',
 ':']
operators.sort(lambda a, b: cmp(-len(a), -len(b)))
escapes = {'b': '\x08',
 'f': '\x0c',
 'n': '\n',
 'r': '\r',
 't': '\t'}
rules = [(None, re.compile('\\s+(?u)')),
 (None, re.compile('<!--.*')),
 ('linecomment', re.compile('//.*')),
 ('multilinecomment', re.compile('/\\*.*?\\*/(?us)')),
 ('name', re.compile('(\\$+\\w*|[^\\W\\d]\\w*)(?u)')),
 ('number', re.compile('(?x)(\n        (?:0|[1-9]\\d*)\n        (\\.\\d+)?\n        ([eE][-+]?\\d+)? |\n        (0x[a-fA-F0-9]+)\n    )')),
 ('operator', re.compile('(%s)' % '|'.join(map(re.escape, operators)))),
 ('string', re.compile('(?xs)(\n        \'(?:[^\'\\\\]*(?:\\\\.[^\'\\\\]*)*)\'  |\n        "(?:[^"\\\\]*(?:\\\\.[^"\\\\]*)*)"\n    )'))]
division_re = re.compile('/=?')
regex_re = re.compile('/(?:[^/\\\\]*(?:\\\\.[^/\\\\]*)*)/[a-zA-Z]*(?s)')
line_re = re.compile('(\\r\\n|\\n|\\r)')
line_join_re = re.compile('\\\\' + line_re.pattern)
uni_escape_re = re.compile('[a-fA-F0-9]{1,4}')

class Token(tuple):
    """Represents a token as returned by `tokenize`."""
    __slots__ = ()

    def __new__(cls, type, value, lineno):
        return tuple.__new__(cls, (type, value, lineno))

    type = property(itemgetter(0))
    value = property(itemgetter(1))
    lineno = property(itemgetter(2))


def indicates_division(token):
    """A helper function that helps the tokenizer to decide if the current
    token may be followed by a division operator.
    """
    if token.type == 'operator':
        return token.value in (')', ']', '}', '++', '--')
    return token.type in ('name', 'number', 'string', 'regexp')


def unquote_string(string):
    """Unquote a string with JavaScript rules.  The string has to start with
    string delimiters (``'`` or ``"``.)
    
    :return: a string
    """
    if not (string and string[0] == string[-1] and string[0] in '"\''):
        raise AssertionError, 'string provided is not properly delimited'
        string = line_join_re.sub('\\1', string[1:-1])
        result = []
        add = result.append
        pos = 0
        while 1:
            escape_pos = string.find('\\', pos)
            if escape_pos < 0:
                break
            add(string[pos:escape_pos])
            next_char = string[escape_pos + 1]
            if next_char in escapes:
                add(escapes[next_char])
            elif next_char in 'uU':
                escaped = uni_escape_re.match(string, escape_pos + 2)
                if escaped is not None:
                    escaped_value = escaped.group()
                    if len(escaped_value) == 4:
                        try:
                            add(unichr(int(escaped_value, 16)))
                        except ValueError:
                            pass
                        else:
                            pos = escape_pos + 6
                            continue

                    add(next_char + escaped_value)
                    pos = escaped.end()
                    continue
                else:
                    add(next_char)
            else:
                add(next_char)
            pos = escape_pos + 2

        pos < len(string) and add(string[pos:])
    return u''.join(result)


def tokenize(source):
    r"""Tokenize a JavaScript source.
    
    :return: generator of `Token`\s
    """
    may_divide = False
    pos = 0
    lineno = 1
    end = len(source)
    while pos < end:
        for token_type, rule in rules:
            match = rule.match(source, pos)
            if match is not None:
                break
        else:
            if may_divide:
                match = division_re.match(source, pos)
                token_type = 'operator'
            else:
                match = regex_re.match(source, pos)
                token_type = 'regexp'
            if match is None:
                pos += 1
                continue

        token_value = match.group()
        if token_type is not None:
            token = Token(token_type, token_value, lineno)
            may_divide = indicates_division(token)
            yield token
        lineno += len(line_re.findall(token_value))
        pos = match.end()

    return
# okay decompyling ./messages/jslexer.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 17:18:23 CST
