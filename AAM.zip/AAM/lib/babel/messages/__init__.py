# 2017.08.16 17:18:15 CST
# Embedded file name: build\bdist.win32\egg\lib\babel\messages\__init__.py
"""Support for ``gettext`` message catalogs."""
from babel.messages.catalog import *
# okay decompyling ./messages/__init__.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.16 17:18:15 CST
