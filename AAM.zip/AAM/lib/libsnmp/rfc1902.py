# 2017.08.13 23:41:01 CST
# Embedded file name: build\bdist.win32\egg\lib\libsnmp\rfc1902.py
import util
import logging
import types
from rfc1155 import *
log = logging.getLogger('rfc1902')
log.setLevel(logging.INFO)
asnTagNumbers['Counter64'] = 6

class Integer32(Integer):
    """ A 32 bit integer
    """
    MINVAL = -2147483648L
    MAXVAL = 2147483648L


class Counter32(Counter):
    """ A 32 bit counter
    """
    pass


class Guage32(Guage):
    """ A 32 bit Guage
    """
    pass


class Counter64(Counter):
    """ A 64 bit counter
    """
    MINVAL = 0L
    MAXVAL = 18446744073709551615L
    asnTagClass = asnTagNumbers['Counter64']


class OctetString(OctetString):
    """ An SNMP v2 OctetString must be between
        0 and 65535 bytes in length
    """

    def __init__(self, value = ''):
        if len(value) > 65535:
            raise ValueError('OctetString must be shorter than 65535 bytes')
        OctetString.__init__(self, value)


tagDecodeDict[2] = Integer32
tagDecodeDict[65] = Counter32
tagDecodeDict[66] = Guage32
tagDecodeDict[70] = Counter64
# okay decompyling ./rfc1902.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 23:41:01 CST
