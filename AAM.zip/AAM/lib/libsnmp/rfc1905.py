# 2017.08.13 23:41:01 CST
# Embedded file name: build\bdist.win32\egg\lib\libsnmp\rfc1905.py
import logging
import rfc1157
from rfc1902 import *
log = logging.getLogger('rfc1905')
asnTagNumbers['GetBulk'] = 5
asnTagNumbers['Inform'] = 6
asnTagNumbers['TrapV2'] = 7
asnTagNumbers['Report'] = 8
max_bindings = 2147483647L

class VarBind(rfc1157.VarBind):
    """ VarBind redefined here to place it in the same namespace
    """
    pass


class NoSuchObject(rfc1157.Null):

    def __str__(self):
        return 'No Such Object'


class NoSuchInstance(rfc1157.Null):

    def __str__(self):
        return 'No Such Instance'


class EndOfMibView(rfc1157.Null):

    def __str__(self):
        return 'EndOfMibView'


class VarBindList(rfc1157.VarBindList):
    """ An SNMPv2 VarBindList has a maximum size of max_bindings
    """

    def __init__(self, value = []):
        if len(value) > max_bindings:
            raise ValueError('A VarBindList must be shorter than %d' % max_bindings)
        rfc1157.VarBindList.__init__(self, value)


class Message(rfc1157.Message):

    def __init__(self, version = 1, community = 'public', data = None):
        rfc1157.Message.__init__(self, version, community, data)


class ErrorStatus(rfc1157.ErrorStatus):
    """ An SNMPv2 Error status
    """

    def __init__(self, value):
        rfc1157.ErrorStatus.__init__(self, value)
        self.errString[6] = 'Access is not permitted'
        self.errString[7] = 'Type is incorrect'
        self.errString[8] = 'Length is incorrect'
        self.errString[9] = 'Encoding is incorrect'
        self.errString[10] = 'Value is incorrect'
        self.errString[11] = 'No creation'
        self.errString[12] = 'Value is inconsistent'
        self.errString[13] = 'Resourse Unavailable'
        self.errString[14] = 'Commit Failed'
        self.errString[15] = 'Undo Failed'
        self.errString[16] = 'Authorization Error'
        self.errString[17] = 'Not Writable'
        self.errString[18] = 'Inconsistent Name'
        self.errNum[6] = 'noAccess'
        self.errNum[7] = 'wrongType'
        self.errNum[8] = 'wrongLength'
        self.errNum[9] = 'wrongEncoding'
        self.errNum[10] = 'wrongValue'
        self.errNum[11] = 'noCreation'
        self.errNum[12] = 'inconsistentValue'
        self.errNum[13] = 'resourceUnavailable'
        self.errNum[14] = 'commitFailed'
        self.errNum[15] = 'undoFailed'
        self.errNum[16] = 'authorizationError'
        self.errNum[17] = 'notWritable'
        self.errNum[18] = 'inconsistentName'


class PDU(rfc1157.PDU):
    """ SNMPv2 PDUs are very similar to SNMPv1 PDUs
    """
    asnTagClass = asnTagClasses['CONTEXT']

    def __init__(self, requestID = 0, errorStatus = 0, errorIndex = 0, varBindList = []):
        rfc1157.PDU.__init__(self)
        if errorIndex > max_bindings:
            raise ValueError('errorIndex must be <= %d' % max_bindings)
        self.requestID = Integer32(requestID)
        self.errorStatus = ErrorStatus(errorStatus)
        self.errorIndex = Integer(errorIndex)
        self.varBindList = VarBindList(varBindList)
        self.value = [self.requestID,
         self.errorStatus,
         self.errorIndex,
         self.varBindList]


class BulkPDU(Sequence):
    """ BulkPDU is a new type of PDU specifically for doing GetBulk
        requests in SNMPv2.
    """
    asnTagClass = asnTagClasses['CONTEXT']

    def __init__(self, requestID = 0, nonRepeaters = 0, maxRepetitions = 0, varBindList = []):
        Sequence.__init__(self)
        if nonRepeaters > max_bindings:
            raise ValueError('nonRepeaters must be <= %d' % max_bindings)
        if maxRepetitions > max_bindings:
            raise ValueError('nonRepeaters must be <= %d' % max_bindings)
        self.requestID = Integer32(requestID)
        self.nonRepeaters = Integer(nonRepeaters)
        self.maxRepetitions = Integer(maxRepetitions)
        self.varBindList = VarBindList(varBindList)
        self.value = [self.requestID,
         self.nonRepeaters,
         self.maxRepetitions,
         self.varBindList]

    def decodeContents(self, stream):
        """ Decode into a BulkPDU object
        """
        objectList = Sequence.decodeContents(self, stream)
        if len(self.value) != 4:
            raise PDUError('Malformed BulkPDU: Incorrect length %d' % len(self.value))
        for item in objectList[3]:
            myVarList.append(VarBind(item[0], item[1]))

        return self.__class__(int(objectList[0]), int(objectList[1]), int(objectList[2]), myVarList)


class Get(PDU):
    """ An SNMPv2 Get Request PDU
    """
    asnTagNumber = asnTagNumbers['Get']


class GetNext(PDU):
    """ An SNMPv2 Get Next Request PDU
    """
    asnTagNumber = asnTagNumbers['GetNext']


class Response(PDU):
    """ An SNMPv2 Response PDU
    """
    asnTagNumber = asnTagNumbers['Response']


class Set(PDU):
    """ An SNMPv2 Set Request PDU
    """
    asnTagNumber = asnTagNumbers['Set']


class GetBulk(BulkPDU):
    """ An SNMPv2 Get Next Request PDU
    """
    asnTagNumber = asnTagNumbers['GetBulk']


class Inform(PDU):
    """ An SNMPv2 Get Next Request PDU
    """
    asnTagNumber = asnTagNumbers['Inform']


class TrapV2(PDU):
    """ An SNMPv2 Trap PDU
    """
    asnTagNumber = asnTagNumbers['TrapV2']


class Report(PDU):
    """ An SNMPv2 Report PDU
    """
    asnTagNumber = asnTagNumbers['Report']


class PDUError(Exception):

    def __init__(self, args = None):
        self.args = args


tagDecodeDict[162] = Response
tagDecodeDict[165] = GetBulk
tagDecodeDict[166] = Inform
tagDecodeDict[167] = TrapV2
tagDecodeDict[168] = Report
tagDecodeDict[128] = NoSuchObject
tagDecodeDict[129] = NoSuchInstance
tagDecodeDict[130] = EndOfMibView
# okay decompyling ./rfc1905.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 23:41:02 CST
