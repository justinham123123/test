# 2017.08.13 23:40:58 CST
# Embedded file name: build\bdist.win32\egg\lib\libsnmp\debug.py
import logging
import os

class snmpLogger(logging.Logger):

    def __init__(self, name):
        pid = os.getpid()
        FORMAT = '%(asctime)s [' + str(pid) + '] %(name)s: %(levelname)s - %(message)s'
        level = logging.DEBUG
        logging.Logger.__init__(self, name, level)
        handler = logging.StreamHandler()
        formatter = logging.Formatter(FORMAT)
        handler.setFormatter(formatter)
        self.addHandler(handler)


logging.setLoggerClass(snmpLogger)
# okay decompyling ./debug.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 23:40:58 CST
