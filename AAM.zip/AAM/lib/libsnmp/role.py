# 2017.08.13 23:41:02 CST
# Embedded file name: build\bdist.win32\egg\lib\libsnmp\role.py
import socket
import logging
import time
from libsnmp import rfc1155
from libsnmp import rfc1157
log = logging.getLogger('v1.SNMP')

class manager:

    def __init__(self, dest, interface = ('0.0.0.0', 0), socksize = 65536):
        self.dest = dest
        self.interface = interface
        self.socket = None
        self.socksize = socksize
        self.request_id = 1
        return

    def __del__(self):
        self.close()

    def get_socket(self):
        return self.socket

    def open(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(self.interface)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, self.socksize)
        return self.socket

    def send(self, request, dst = (None, 0)):
        if not self.socket:
            self.open()
        self.socket.sendto(request, dst)

    def read(self):
        if not self.socket:
            raise ValueError('Socket not initialized')
        message, src = self.socket.recvfrom(self.socksize)
        return (message, src)

    def close(self):
        if self.socket:
            self.socket.close()
        self.socket = None
        return
# okay decompyling ./role.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 23:41:02 CST
