# 2017.08.13 23:41:04 CST
# Embedded file name: build\bdist.win32\egg\lib\libsnmp\util.py


def octetsToHex(octets):
    """ convert a string of octets to a string of hex digits
    """
    result = ''
    while octets:
        byte = octets[0]
        octets = octets[1:]
        result += '%.2x' % ord(byte)

    return result


def octetsToOct(octets):
    """ convert a string of octets to a string of octal digits
    """
    result = ''
    while octets:
        byte = octets[0]
        octets = octets[1:]
        result += '%.4s,' % oct(ord(byte))

    return result
# okay decompyling ./util.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 23:41:04 CST
