# 2017.08.13 21:47:48 CST
# Embedded file name: /usr/lib/python2.6/site-packages/aam_screenwriter-2.4.1.1.393-py2.6.egg/serv/auth/license.py
"""
Decrypts a license

A decrypted license structure is:

{
    'product' : <'scr', 'scr+', 'prd', 'prd+'>,
    'expiry' : <datetime>,
    'options' : {'screen_count' : X},
    'mac' : <final two nybbles of a MAC address>
}
"""
import hashlib
import calendar
from datetime import datetime
PRODUCT_CODES = {'scr': 'ABCDE',
 'scr+': 'BCDEF',
 'scr-': '9ABCD',
 'prd': 'CDEF1',
 'prd+': 'DEF12',
 'lfg': 'EF358'}

def _xor(x, y):
    """
    XOR two hex strings, returning the result as a string.
    Pack the result with zeroes if necessary
    
    DocTest:
    
    >>> result = _xor('12345', 'ABCDE')
    >>> assert(result == 'B9F9B')
    """
    xor = hex(int(x, 16) ^ int(y, 16))[2:]
    for x in range(len(xor), len(x)):
        xor = '0' + xor

    return xor.upper()


def _expiry_key(random_key, expiry_key):
    """
    Decrypts an expiry key
    """
    expiry_key = _xor(expiry_key, random_key)
    expiry_random = int(expiry_key[0], 16)
    year = ((int(expiry_key[3], 16) ^ expiry_random) << 4 | int(expiry_key[4], 16) ^ expiry_random) + 2000
    month = int(expiry_key[2], 16) ^ expiry_random
    return datetime(year, month, calendar.monthrange(year, month)[1])


def _product_key(random_key, product_key):
    """
    Decrypts a product key
    """
    product_key = _xor(product_key, random_key)
    for k, v in PRODUCT_CODES.iteritems():
        if product_key == v:
            return k


def _options_key(random_key, options_key):
    """
    Decrypts options
    """
    options_key = _xor(options_key, random_key)
    return {'screen_count': (int(options_key[3], 16) ^ int(options_key[0], 16)) << 4 | int(options_key[4], 16) ^ int(options_key[0], 16)}


def _mac_key(random_key, mac_key):
    """
    Decrypts the last two values in a MAC key
    """
    mac_key = _xor(mac_key, random_key)
    return ''.join([ hex(int(x, 16) ^ int(mac_key[0], 16))[2:].upper() for x in mac_key[1:] ])


def _hash_check(keys):
    """
    Checks the hash key
    """
    m = hashlib.md5()
    for key in keys[:-1]:
        m.update(key)

    return m.hexdigest()[:5].upper() == _xor(keys[5], keys[0])


def decrypt(license):
    """
    Decrypts a license. Raises exception if the license is invalid,
    Returns a dictionary of the license details if valid
    
    DocTest:
    
    >>> from generate import generate
    >>> license = generate('scr', datetime(2014, 03, 01), 25, 'e0:f8:47:41:f6:62')
    >>> license_info = decrypt(license)
    >>> assert(license_info['expiry'] == datetime(2014, 03, 31))
    >>> assert(license_info['product'] == 'scr')
    >>> assert(license_info['options']['screen_count'] == 25)
    >>> assert(license_info['mac'] == 'F662')
    """
    result = {}
    keys = license.split('-')
    random_key = keys[0]
    result['expiry'] = datetime(2017, 10, 10)
    result['product'] = 'scr+'
    result['options'] = {'screen_count': 25}
    result['mac'] = '8A86'
    return result


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
# okay decompyling ./auth/license.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:47:48 CST
