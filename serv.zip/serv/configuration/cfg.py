# 2017.08.13 21:47:58 CST
# Embedded file name: build\bdist.win32\egg\serv\configuration\cfg.py
import logging
import os.path
from serv.lib.utilities import config as c
from serv import WIN32
from serv.lib.cherrypy.i18n_tool import ugettext_lazy as _
mn = 60
hr = mn * 60
default_url = '/tms'
theme = c.OptionStr('app', 'theme', 'aam', description='The theme applied to the TMS User Interface. Contact your AAM representative if you require a custom themed UI.')
ssl_certificate_path = c.OptionStr('app', 'ssl_certificate_path', '', description='If blank, not active. Otherwise the full path to the ssl certificate, if you want to run the TMS through HTTPS')
ssl_private_key_path = c.OptionStr('app', 'ssl_private_key_path', '', description='If blank, not active. Otherwise the full path to the ssl key path, if you want to run the TMS through HTTPS')
cherry_host = c.OptionStr('app', 'host', '127.0.0.1', description='The listen address for the TMS webserver. it will listen on all available network addresses if set to 0.0.0.0')
cherry_port = c.OptionNum('app', 'port', 8080, description='The port that the TMS webserver listens on.')
thread_pool = c.OptionNum('app', 'thread_pool', 50, description='The number of threads available to the webserver.')
cherry_ssl_port = c.OptionNum('app', 'ssl_port', 8081, description='The port that the webserver listens on if ssl certificate and ssl private key has been provided.')
if os.name == 'nt':
    data_dir = c.OptionStr('app', 'data_dir', 'C:\\aam-lms', description='Fullpath to where the TMS stores some data required during runtime.')
    log_dir = c.OptionStr('app', 'log_dir', 'C:\\aam-lms\\log', description='Fullpath to where the TMS puts the log files it generates during runtime.')
else:
    data_dir = c.OptionStr('app', 'data_dir', '/aam-lms/', description='Fullpath to where the TMS stores some data required during runtime.')
    log_dir = c.OptionStr('app', 'log_dir', '/aam-lms/log', description='Fullpath to where the TMS puts the log files it generates during runtime.')
log_file_size = c.OptionNum('app', 'log_size', 5242880, False, description='Max log file size for the Log files in Bytes.')
logging_level = c.OptionLogLevel('app', 'logging_level', logging.INFO, description='Level at which the general log file accepts messages, available choices 10, 20, 30, 40, 50 or DEBUG, INFO, WARNING, ERROR, CRITICAL')
lm_logging_level = c.OptionLogLevel('app', 'lm_logging_level', logging.INFO, description='Level at which the log_manager log file accepts messages, options as above')
audit_log_enabled = c.OptionBool('app', 'audit_log_enabled', True, description='The Audit log contains user and system actions that make permanent changes (add, edit, delete)')
audit_requests_enabled = c.OptionBool('app', 'audit_requests_enabled', False, description='Create an audit log for each HTTP request received by the TMS Server')
pos_feed_file_count = c.OptionNum('app', 'pos_log_count', 5, False, description='The number of pos update files to keep in the system. Every time the POS updates either through Sync, or manual upload, a new file is created.')
config_file = c.OptionStr('app', 'config_file', os.path.join(os.path.dirname(__file__), '..', '..', 'cinema_services.cfg'), False, False)
complex_name = c.OptionStr('app', 'complex_name', 'No Complex Name', description='[configurable through ui] Name of the Complex, this will included in emails sent by the site and displayed on the TMS UI. ')
rentrak_id = c.OptionStr('app', 'rentrak_id', None, description='[feature in development] The sites rentrak_id')
cadien_id = c.OptionStr('app', 'cadien_id', None, description='[feature in development] The sites cadien_id')
audio_language = c.OptionStr('app', 'audio_language', 'EN', description='[configurable through ui] The DCNC language code - based on ISO code  - for the audio language of the TMS - used in CPL selection for automated playlists.')
subtitle_language = c.OptionStr('app', 'subtitle_language', 'EN', description='[configurable through ui] The DCNC language code - based on ISO code  - for the subtitled language of the TMS - used in CPL selection for automated playlists.')
timezone = c.OptionStr('app', 'timezone', 'Europe/London', description='The timezone that the TMS is in. It is important to set this correctly to avoid scheduling issues use http://en.wikipedia.org/wiki/List_of_tz_database_time_zones as a reference for valid entries.')
license = c.OptionStr('app', 'license', '', description='The License for the TMS, please contact your TMS representative to receive a new license.')
global_triggers_enabled = c.OptionBool('app', 'global_triggers_enabled', False, description='This allows adding global playlist triggers to playlists on Doremi Servers. As these can be configured permanently on Doremi servers now this is False by default')
license_agreement_accepted = c.OptionBool('app', 'license_agreement_accepted', False, description='Flag used to determine whether the license agreement has been accepted. This needs to be accepted once when the system is first used.')
password_change_reminder_displayed = c.OptionBool('app', 'password_change_reminder_displayed', False, description='Flag used to determine whether the password change reminder has been displayed.')
lamp_threshold_unit = c.OptionStr('app', 'lamp_threshold_unit', 'percentage', description='Set whether the lamp threshold should be in hours or as percentage of lamp life.')
lamp_yellow_threshold = c.OptionNum('app', 'lamp_yellow_threshold', 80, description='Set level at which yellow warning colour is displayed for lamp life report. Number is percentage if lamp_threshold_unit is set to percentage, else number is hours before end of lamp life.')
lamp_red_threshold = c.OptionNum('app', 'lamp_red_threshold', 100, description='Set level at which red warning colour is displayed for lamp life report. Number is percentage if lamp_threshold_unit is set to percentage, else number is hours before end of lamp life.')
disk_yellow_threshold = c.OptionNum('app', 'disk_yellow_threshold', 80, description='Set level at which yellow warning colour is displayed for disk usage report. Number is a percentage of disk usage.')
disk_red_threshold = c.OptionNum('app', 'disk_red_threshold', 100, description='Set level at which red warning colour is displayed for disk usage report. Number is a percentage of disk usage.')
db_engine = c.OptionStr('app', 'db_engine', 'sqlite3', description='Database type to use, available options are sqlite3 and postgresql.')
db_user = c.OptionStr('app', 'db_user', 'postgres', description='If postgresql specified, the postgresql user account.')
db_password = c.OptionStr('app', 'db_password', 'postgres', description='If postgresql specified, the postgresql user password.')
db_port = c.OptionStr('app', 'db_port', '5432', description='If postgresql specified, the postgresql port')
db_pg_name = c.OptionStr('app', 'db_pg_name', 'tms2', description='If postgresql specified, the name of the postgresql database')
if os.name == 'nt':
    db_name = c.OptionStr('app', 'db_name', 'C:\\aam-lms\\db\\cinema_services.db', description='If sqlite3 the fullpath to the database, if postgresql specified name of the postgresql database.')
    audit_db_name = c.OptionStr('app', 'audit_db_name', 'C:\\aam-lms\\db\\audit_log.db', description='If sqlite3 the fullpath to the database, if postgresql specified name of the postgresql database.')
    playback_db_name = c.OptionStr('app', 'playback_db_name', 'C:\\aam-lms\\db\\playback_log.db', description='If sqlite3 the fullpath to the database, if postgresql specified name of the postgresql database.')
else:
    db_name = c.OptionStr('app', 'db_name', '/aam-lms/db/cinema_services.db', description='If sqlite3 the fullpath to the database, if postgresql specified name of the postgresql database.')
    audit_db_name = c.OptionStr('app', 'audit_db_name', '/aam-lms/db/audit_log.db', description='If sqlite3 the fullpath to the database, if postgresql specified name of the postgresql database.')
    playback_db_name = c.OptionStr('app', 'playback_db_name', '/aam-lms/db/playback_log.db', description='If sqlite3 the fullpath to the database, if postgresql specified name of the postgresql database.')
if os.name == 'nt':
    service_start_command = c.OptionStr('app', 'service_start_command', 'C:\\aam-lms\\bin\\CinemaServices.py --console --config C:\\aam-lms\\bin\\cinema_services.cfg', description='The command to be used when restarting services.')
    python_executable = c.OptionStr('app', 'python_executable', 'C:\\Python26\\python.exe', description='The absolute path to the python executable, only important to set if TMS is installed to run as a Windows Service.')
else:
    service_start_command = c.OptionStr('app', 'service_start_command', '/aam-lms/bin/CinemaServices.py --start --config /aam-lms/bin/cinema_services.cfg', description='The command to be used when restarting services.')
    python_executable = c.OptionStr('app', 'python_executable', '', description='The absolute path to the python executable, only important to set if TMS is installed to run as a Windows Service.')
core_monitor_memory = c.OptionBool('core', 'monitor_memory', False, description='Set to True to monitor python memory usage.')
core_monitor_snmp = c.OptionBool('core', 'monitor_snmp', True, description='Set to True to monitor SNMP devices.')
core_monitor_dbs = c.OptionBool('core', 'monitor_dbs', False, description='Set to True to monitor Db communication.')
core_log_manager_enabled = c.OptionBool('core', 'log_manager_enabled', True, description='Set to True to enable the log manager.')
core_store_device_logs = c.OptionBool('core', 'store_device_logs', True, description='Set to True to collect secure screen server log files.')
core_store_live_logs = c.OptionBool('core', 'store_live_logs', True, description='Set to True to collect live playback logs from screen servers.')
core_log_storage_limit = c.OptionNum('core', 'core_log_storage_limit', 10000, description='The maximum amount of storage allowed for log storage in MB')
core_log_start_hour = c.OptionNum('core', 'core_log_start_hour', 23, description='[configurable through ui] The hour to start collecting SMPTE logs from Screen Servers.')
core_log_start_minute = c.OptionNum('core', 'core_log_start_minute', 0, description='[configurable through ui] The minute to start collecting SMPTE logs from Screen Servers.')
core_log_retry_days = c.OptionNum('core', 'core_log_retry_days', 5, description='[UI configurable] The number of days to keep retrying a failed/empty SMPTE log collection')
core_log_end_hour = c.OptionNum('core', 'core_log_end_hour', 7, description='[configurable through ui] The hour to stop collecting SMPTE logs from Screen Servers.')
core_log_end_minute = c.OptionNum('core', 'core_log_end_minute', 0, description='[configurable through ui] The minute to stop collecting SMPTE logs from Screen Servers.')
core_min_storage_days_playbacks = c.OptionNum('core', 'core_min_storage_days_playbacks', 30, description='Store playbacks (and their source TMS/SMPTE playouts) for no fewer than this many days. Setting this below 30 will affect reporting of schedule divergence.')
core_earliest_date_smpte_collection = c.OptionStr('core', 'core_earliest_date_smpte_collection', '2000-01-01', description='Prevent historic collection of SMPTE logs from before this date. Format: YYYY-mm-dd.')
core_log_collection_only = c.OptionBool('core', 'log_collection_only', False, description='Disables all non-log-collection-related activities to free up system resources')
core_log_collection_only_frequency = c.OptionNum('core', 'log_collection_only_frequency', 60, description='How often, in minutes, to run log collection if log-collection-only-mode is on. Increase to reduce CPU load by slowing down historic collection')
core_language = c.OptionStr('core', 'core_language', 'en', description='[configurable through ui] The language preference for the system.')
core_tonight_hour = c.OptionNum('core', 'core_tonight_hour', 1, description='[configurable through ui] The hour to set for transfers when tonight is specified as the start time.')
core_tonight_minute = c.OptionNum('core', 'core_tonight_minute', 30, description='[configurable through ui] The minute to set for transfers when tonight is specified as the start time.')
core_detect_content_video_encoding = c.OptionBool('core', 'detect_content_video_encoding', False, description='Enable to aggressively parse content to determine if it is MPEG encoded.')
core_cherry_access_log_level = c.OptionLogLevel('core', 'cherry_access_log_level', logging.WARNING, description='Level at which the access log accepts messages, available choices 10, 20, 30, 40, 50 or DEBUG, INFO, WARNING, ERROR, CRITICAL')
core_allow_server_reboot = c.OptionBool('core', 'core_allow_server_reboot', True, description='Enable to allow users to reboot servers through the TMS UI.')
core_allow_sync_page = c.OptionBool('core', 'core_allow_sync_page', True, description='Enable to allow users to access the sync config page through the TMS UI.')
core_auto_schedule_resync_gap_minutes = c.OptionNum('core', 'core_auto_schedule_resync_gap_minutes', 120, description='Auto re-sync of schedules will ignore all schedules between "now" and this many minutes from now.')
core_auto_schedule_resync = c.OptionBool('core', 'core_auto_schedule_resync', True, description='Auto re-sync schedules when system receives new Packs.')
core_auto_transfer_kdms_to_devices = c.OptionBool('core', 'core_auto_transfer_kdms_to_devices', True, description='Flag to specify whether the system should attempt to transfer a KDM to a device automatically when it ingests KDMs. Should be disabled if complex uses Dolby Screen Servers as their KDM memory is limited.')
core_auto_transfer_content = c.OptionBool('core', 'core_auto_transfer_content', False, description='Auto transfer content to devices when schedules exist with missing content.')
core_auto_transfer_content_asap = c.OptionBool('core', 'core_auto_transfer_content_asap', False, description='Auto transfer missing content to devices as soon as possible. If False then content will be queued for tonight.')
core_auto_cleanup_playlists = c.OptionBool('core', 'auto_cleanup_playlists', False, description='Automatically delete playlists that were generated by the automatic playlist creation.')
core_auto_cleanup_playlists_expiry_days = c.OptionNum('core', 'core_auto_cleanup_playlists_expiry_days', 7, description='Automatically delete playlists that were played this many days ago.')
core_auto_cleanup_lms_playlists = c.OptionBool('core', 'auto_cleanup_lms_playlists', False, description='Automatically delete old lms playlists')
core_auto_cleanup_lms_playlists_expiry_days = c.OptionNum('core', 'core_auto_cleanup_lms_playlists_expiry_days', 30, description='Automatically delete lms playlists that were last edited this many days ago.')
core_auto_cleanup_kdms = c.OptionBool('core', 'core_auto_cleanup_kdms', True, description='KDM cleanup')
core_auto_cleanup_packs = c.OptionBool('core', 'core_auto_cleanup_packs', True, description='Pack cleanup')
core_auto_cleanup_schedules = c.OptionBool('core', 'core_auto_cleanup_schedules', True, description='Schedule cleanup')
core_auto_cleanup_pos = c.OptionBool('core', 'core_auto_cleanup_pos', True, description='POS cleanup')
core_auto_cleanup_titles = c.OptionBool('core', 'core_auto_cleanup_titles', True, description='Title cleanup')
core_auto_cleanup_transfers = c.OptionBool('core', 'core_auto_cleanup_transfers', True, description='Transfer cleanup')
core_auto_cleanup_log_files = c.OptionBool('core', 'core_auto_cleanup_log_files', True, description='Log file cleanup')
core_auto_cleanup_tms_log_files = c.OptionBool('core', 'core_auto_cleanup_tms_log_files', True, description='TMS log file cleanup')
core_auto_cleanup_watchfolder = c.OptionBool('core', 'core_auto_cleanup_watchfolder', True, description='Watchfolder cleanup')
core_content_sync_limit = c.OptionNum('core', 'core_content_sync_limit', 8, description='Maximum number of concurrently syncing content devices. 0 to disable.', minval=0)
complex_id = c.OptionNum('core', 'complex_id', -1, description='ID Circuit Core uses to uniquely identify this complex. -1 if not defined.')
flm_complex_id = c.OptionStr('core', 'flm_complex_id', '', description='ID used to uniquely identify this complex. Blank if not defined. Suggested format: exhibitor:cinema_name')
if WIN32:
    core_mount_drives_ignore = c.OptionStr('core', 'mount_drives_ignore', 'C:\\,P:\\,U:\\,E:\\', description='[configurable through ui] Drives to Ignore and never show on the TMS UI.')
else:
    core_mount_drives_ignore = c.OptionStr('core', 'mount_drives_ignore', '/,/lms-data,/dev,/boot,/dev/pts,/dev/shm,/proc,/sys,/proc/sys/fs/binfmt_misc,/var,/var/tmp,/tmp,/opt,/root/.gvfs', description='[configurable through ui] Drives to Ignore and never show on the TMS UI.')
core_schedule_mapper_leeway = c.OptionNum('core', 'schedule_mapper_leeway', 30, minval=0, description='The number of minutes the start/end times of a POS session and playback log may differ while still being mapped to each other.')
core_check_schedules_on_content_delete = c.OptionBool('core', 'check_schedules_on_content_delete', True, description='Check for affected schedules when user tries to delete content from a screenserver')
email_protocol = c.OptionStr('app', 'email_protocol', 'pop', description='[configurable through ui] Email protocol to use to check emails with (for KDM email scanning)')
email_server = c.OptionStr('app', 'email_server', '', description='[configurable through ui] Email server to use to check emails with (for KDM email scanning)')
email_username = c.OptionStr('app', 'email_username', '', description='[configurable through ui] Email username to use to check emails with (for KDM email scanning)')
email_password = c.OptionStr('app', 'email_password', '', description='[configurable through ui] Email password to use to check emails with (for KDM email scanning)')
kdm_email_enabled = c.OptionBool('app', 'kdm_email_enabled', False, description='[configurable through ui] Enable to scan Email for KDMs.')
pos_cinema_identifier = c.OptionStr('pos', 'pos_cinema_identifier', '', description='[configurable through ui] Cinema identifiers to accept when parsing POS files or talking to POS servers. Comma separate without spaces to allow for multiple cinema identifiers.')
pos_week_offset = c.OptionNum('pos', 'pos_week_offset', 0, description='[configurable through ui] Used to name identified weeks, leave at 0 to stay with the standard ISO week.')
pos_first_day_of_week = c.OptionNum('pos', 'pos_first_day_of_week', 0, description='[configurable through ui] Used to group POS schedule data by week. (0: Monday, 1: Tuesday ... ')
pos_feed_type = c.OptionStr('pos', 'pos_feed_type', '', description='[configurable through ui] Specific value to enable custom POS feed parsing, talk to your TMS representative if this becomes necessary.')
pos_enabled = c.OptionBool('pos', 'pos_enabled', False, description='[configurable through ui] Enable to turn on POS integration')
pos_auto_transfer_time = c.OptionBool('pos', 'pos_auto_transfer_time', True, description='[configurable through ui] Enable smart automatic content transfer scheduling')
pos_default_session_length = c.OptionNum('pos', 'pos_default_session_length', 120, description='[configurable through ui] Default POS Session length in minutes if none found in POS feed.')
pos_vista_feature_stamp = c.OptionBool('pos', 'pos_vista_feature_stamp', False, description="[configurable through ui] Enable to use Vista 'Session_dtmFeature' value instead of 'Session_dtmShowing' for Session start time.")
beacon_active = c.OptionBool('beacon', 'active', False, description='Enable to activate Beacon. Beacon is used to query alternative AAM services for Keys or Advertisement Packs.')
beacon_locksmith_url = c.OptionStr('beacon', 'locksmith_url', 'https://locksmith.artsalliancemedia.com', description='Locksmith URL')
beacon_circuit_core_url = c.OptionStr('beacon', 'circuit_core_url', 'https://producer.artsalliancemedia.com', description='Producer URL')
beacon_kdm_update_rate = c.OptionNum('beacon', 'kdm_update_rate', 300, description='Frequency at which to check Locksmith for Keys. 0 to disable')
beacon_kdm_report_rate = c.OptionNum('beacon', 'kdm_report_rate', 30, description='Frequency at which to report the status of uploaded KDMs to Locksmith. 0 to disable')
beacon_kdm_full_report_rate = c.OptionNum('beacon', 'kdm_full_report_rate', 600, description='Frequency at which to report all KDMs on devices to Locksmith. 0 to disable, KDMs will only be reported once, resets with server restart.')
beacon_kdm_save_location = c.OptionStr('beacon', 'kdm_save_location', '.', description='Path of the location you wish to store the KDM save file. Defaults to directory TMS is running in.')
beacon_schedule_report_rate = c.OptionNum('beacon', 'schedule_report_rate', 300, description='Frequency at which to report KDM schedule problems to Locksmith. 0 to disable')
beacon_pack_update_rate = c.OptionNum('beacon', 'pack_update_rate', 0, description='Frequency at which to query Producer for available Packs. 0 to disable')
if WIN32:
    circuit_core_config_file = c.OptionStr('circuit_core', 'circuit_core_config_file', 'C:\\aam-lms\\bin\\circuit_core_cfg.json', description='Configuration File for Circuit Cores that this TMS will speak to.')
else:
    circuit_core_config_file = c.OptionStr('circuit_core', 'circuit_core_config_file', '/aam-lms/bin/circuit_core_cfg.json', description='Configuration File for Circuit Cores that this TMS will speak to.')
wsw_enabled = c.OptionBool('circuit_core', 'wsw_enabled', False, description='Enable or disable the circuit core web socket communication')
wsw_certificate_path = c.OptionStr('circuit_core', 'wsw_certificate_path', '', description='Certificate required for communicating with Circuit Core via Websockets')
wsw_ca_certificate_path = c.OptionStr('circuit_core', 'wsw_ca_certificate_path', '', description='If blank, CA authorisation not performed. CA Certificate required for communicating with Circuit Core via Websockets')
wsw_private_key_path = c.OptionStr('circuit_core', 'wsw_private_key_path', '', description='Private key required for communicating with Circuit Core via Websockets')
wsw_buffering = c.OptionBool('circuit_core', 'wsw_buffering', True, description='Enable or disable message buffering of web socket events')
wsw_compression = c.OptionStr('circuit_core', 'wsw_compression', 'zlib', description='Compression algorithm to use for ws communication (Supported: zlib, lz4, lz4hc)')
wsw_retention = c.OptionNum('circuit_core', 'wsw_retention', 86400, description='Message log retention time in seconds (time frame to keep messages when connection is offline)')
lms_uuid = c.OptionStr('lms', 'uuid', '', description='UUID that the LMS uses to identify it. the TMS will set this automatically. Never use the same UUID for multiple LMSs across different TMS systems to ensure future compatibility.')
lms_custom_ftp_enabled = c.OptionBool('lms', 'custom_ftp_enabled', True, description='Enable to use the Python FTP service, this allows direct from drive transfers. Else Configure your own ftp Server to run.')
lms_custom_ftp_timeout = c.OptionNum('lms', 'custom_ftp_timeout', 60.0, description='Set the custom FTP timeout (in seconds). Default is 60.0 second. (Originally 1.0 second, inherited from pyftplib.)')
lms_ftp_ip = c.OptionStr('lms', 'ftp_ip', '192.168.50.200', description='[configurable through ui] IP address for the FTP server to listen on. 0.0.0.0 NOT a valid ip address for this entry.')
lms_ftp_port = c.OptionNum('lms', 'ftp_port', 2121, description='[configurable through ui] Port for the FTP server to run on.')
lms_ftp_username = c.OptionStr('lms', 'ftp_username', 'pullingest', description='[configurable through ui] Username for the FTP server')
lms_ftp_password = c.OptionStr('lms', 'ftp_password', 'pullingest', description='[configurable through ui] Password for the FTP server')
lms_enabled = c.OptionBool('lms', 'enabled', True, description='[configurable through ui] Enable to enable LMS functionalities')
if WIN32:
    lms_library_directory = c.OptionStr('lms', 'library', 'D:\\lms-data', description='Full path to the library storage location.')
else:
    lms_library_directory = c.OptionStr('lms', 'library', '/lms-data/', description='Full path to the library storage location.')
core_chat_live_enabled = c.OptionBool('core', 'chat_live_enabled', False, description='Enables the live chat services')
core_chat_server_ip = c.OptionStr('core', 'chat_server_ip', '10.58.4.4', description='XMPP server ip')
core_chat_server_name = c.OptionStr('core', 'chat_server_name', '127.0.0.1', description='XMPP server name')
core_chat_server_port = c.OptionNum('core', 'chat_server_port', 5222, description='XMPP server port')
core_chat_email_enabled = c.OptionBool('core', 'chat_email_enabled', True, description='Enable sending emails through the TMS messaging functionality.')
core_chat_email_to = c.OptionStr('core', 'chat_email_to', 'tmsfeedback@artsalliancemedia.com', description='[configurable through ui] Chat emails get sent to these email accounts, separate with a semi-colon.')
core_chat_email_cc = c.OptionStr('core', 'chat_email_cc', '', description='[configurable through ui] Chat emails cc these email accounts, separate with a semi-colon.')
core_chat_email_from = c.OptionStr('core', 'chat_email_from', 'tmsfeedback@artsalliancemedia.com', description='[configurable through ui] Chat emails come from this email address, suggest to put the sitename into this. email address does not have to exits, and is not used to read emails.')
core_chat_email_server = c.OptionStr('core', 'chat_email_server', 'aam-ex-1.aam.local', description='[configurable through ui] Email server to chat send Emails through.')
core_chat_email_port = c.OptionNum('core', 'chat_email_port', 25, description='[configurable through ui] Port of the email server to send chat emails through.')
core_bookend_start_active = c.OptionBool('core', 'bookend_start_active', False, description='[configurable through ui] Enable to use start of day playlists.')
core_bookend_start_spl_offset = c.OptionNum('core', 'bookend_start_spl_offset', 200, description='[configurable through ui] Time in seconds between the first scheduled playlist and the start of day playlist.')
core_bookend_start_spl_uuid = c.OptionStr('core', 'bookend_start_spl_uuid', '', description='[configurable through ui] Playlist UUID to use for start of day playlist.')
core_bookend_start_macro_offset = c.OptionNum('core', 'bookend_start_macro_offset', 200, description='[configurable through ui] Time in seconds between the start of day playlist and the start of day macro.')
core_bookend_start_macro_id = c.OptionStr('core', 'bookend_start_macro_id', '', description='[configurable through ui] Macro id to use as the start of day macro.')
core_bookend_end_active = c.OptionBool('core', 'bookend_end_active', False, description='[configurable through ui] Enable to use end of day playlists.')
core_bookend_end_spl_offset = c.OptionNum('core', 'bookend_end_spl_offset', 200, description='[configurable through ui] Time in seconds between the last scheduled playlist and the end of day playlist.')
core_bookend_end_spl_uuid = c.OptionStr('core', 'bookend_end_spl_uuid', '', description='[configurable through ui] Playlist UUID to use for end of day playlist.')
core_bookend_end_macro_offset = c.OptionNum('core', 'bookend_end_macro_offset', 200, description='[configurable through ui] Time in seconds between the end of day playlist and the end of day macro.')
core_bookend_end_macro_id = c.OptionStr('core', 'bookend_end_macro_id', '', description='[configurable through ui] Macro id to use as the end of day macro.')
core_allow_auto = c.OptionStr('core', 'allow_auto', False, description='Allow for auto playlist creation for scheduled items, using fully-templated playlists')
core_active_template = c.OptionStr('core', 'active_template', '', description="[configurable through ui] UUID of core's active template, ie. the template that will be used for auto-assignments.")
core_templated_playlist_name = c.OptionStr('core', 'templated_playlist_name', '{original_playlist_title}_{weekscreen}_{scheduled_playback_date}', description='Automatic playlist templating takes this option to generate the name of the constructed playlist')
core_templated_playlist_date_format = c.OptionStr('core', 'templated_playlist_date_format', '%m.%d_%H:%M', description='This is how the dates will be rendered in the templated playlist titles')
core_trailer_rating_cpls = c.OptionStr('core', 'trailer_rating_cpls', '', description='[configurable through ui] comma separated UUID list of generic rating CPLs to use in trailer packs. If configured and rating is not hard locked for trailer, rating cpl for trailer is added to final playlist')
marker_clip_templating = c.OptionBool('marker_clip_templating', 'marker_clip_templating', False, description='Enable auto playlist scheduling based on marker clips')
auto_run_marker_clip_templating = c.OptionBool('marker_clip_templating', 'auto_run_marker_clip_templating', False, description='Enable auto running of marker clip templating job whenever new schedules are synced from screen server')
marker_clip_eps_uuid = c.OptionStr('marker_clip_templating', 'marker_clip_eps_uuid', '', description='CPL UUID(s) of EPS marker clip, seperated by commas')
marker_clip_lps_uuid = c.OptionStr('marker_clip_templating', 'marker_clip_lps_uuid', '', description='CPL UUID(s) of LPS marker clip, seperated by commas')
marker_clip_preshow_end = c.OptionStr('marker_clip_templating', 'marker_clip_preshow_end', 'LPS', description='Sets the clip at which the Published Show Time should occur(LPS/EPS). If not EPS or LPS, no offsetting occurs and the PS is assumed to be the start of the SPL')
marker_clip_job_start_hour = c.OptionNum('marker_clip_templating', 'marker_clip_job_start_hour', 1, description='The hour at which the marker clip job should start. There must be a minimum 30 minute gap between the configured start and end time')
marker_clip_job_start_minutes = c.OptionNum('marker_clip_templating', 'marker_clip_job_start_minutes', 0, description='The minute at which the marker clip job should start. There must be a minimum 30 minute gap between the configured start and end time')
marker_clip_job_end_hour = c.OptionNum('marker_clip_templating', 'marker_clip_job_end_hour', 2, description='The hour at which the marker clip job should end. There must be a minimum 30 minute gap between the configured start and end time')
marker_clip_job_end_minutes = c.OptionNum('marker_clip_templating', 'marker_clip_job_end_minutes', 0, description='The minute at which the marker clip job should end. There must be a minimum 30 minute gap between the configured start and end time')
marker_clip_schedule_timeframe = c.OptionNum('marker_clip_templating', 'marker_clip_schedule_timeframe', 48, description='The number of hours in the future we should reschedule marker clip schedules')
preshow_trimming_enabled = c.OptionBool('marker_clip_templating', 'preshow_trimming_enabled', False, description='Enable preshow trimming')
preshow_trimming_minimum_schedule_gap = c.OptionNum('marker_clip_templating', 'preshow_trimming_minimum_schedule_gap', 10, description='The minimum number of minutes to be left between schedules after preshow trimming')
marker_clip_reschedule_invalid_shows_frequency = c.OptionNum('marker_clip_templating', 'marker_clip_reschedule_invalid_shows_frequency', 10, description='How often, in minutes, to check-for and reschedule if necessary, scheduled shows with missing/invalid CPLs.')
marker_clip_reschedule_invalid_shows_timeframe = c.OptionNum('marker_clip_templating', 'marker_clip_reschedule_invalid_shows_timeframe', 180, description='The timeframe in minutes beyond the rescheduling safety buffer (core_auto_schedule_resync_gap_minutes) during which to reschedule_invalid_shows')
auto_generate_dcps = c.OptionBool('dcp_generation', 'auto_generate_dcps', False, description='Enables automatic creation of a package whenever a pack is saved')
smpte_dcp_creation = c.OptionBool('dcp_generation', 'smpte_dcp_creation', False, description='Enables SMPTE compliant DCPS: PKLS/ASSETMAPS and CPLS. If not enabled, InterOp complaint DCPs are created')
auto_export_dcps = c.OptionBool('dcp_generation', 'auto_export_dcps', False, description='Auto push created DCPs to empty external media when available.')
cherry_pyformance_enabled = c.OptionBool('cherry_pyformance', 'cherry_pyformance_enabled', False, description='Enable cherrypyformance client in tms.')
sync_automation_info_validity = c.OptionNum('sync', 'automation_info_validity', 1 * hr, description=_('Check for new Automations or Cues'), presets={'max': 1 * mn,
 'high': 5 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=0, icon='macro-pack')
sync_individual_automation_validity = c.OptionNum('sync', 'individual_automation_validity', 1 * hr, description=_('Validate current Automations or Cues'), presets={'max': 1 * mn,
 'high': 10 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=1, icon='macro-pack')
sync_key_info_validity = c.OptionNum('sync', 'key_info_validity', 1 * hr, description=_('Check for new KDMs'), presets={'max': 1 * mn,
 'high': 5 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=2, icon='key')
sync_individual_key_info_validity = c.OptionNum('sync', 'individual_key_info_validity', 1 * hr, description=_('Validate current KDMs'), presets={'max': 1 * mn,
 'high': 10 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=3, icon='key')
sync_content_info_validity = c.OptionNum('sync', 'content_info_validity', 1 * hr, description=_('Check for new CPLs'), presets={'max': 1 * mn,
 'high': 5 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=4, icon='content')
sync_individual_content_info_validity = c.OptionNum('sync', 'individual_content_info_validity', 1 * hr, description=_('Validate current CPLs'), presets={'max': 1 * mn,
 'high': 10 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=5, icon='content')
sync_playlist_info_validity = c.OptionNum('sync', 'playlist_info_validity', 1 * hr, description=_('Check for new SPLs'), presets={'max': 1 * mn,
 'high': 5 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=6, icon='playlist')
sync_individual_playlist_info_validity = c.OptionNum('sync', 'individual_playlist_info_validity', 1 * hr, description=_('Validate current SPLs'), presets={'max': 1 * mn,
 'high': 10 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=7, icon='playlist')
sync_schedule_info_validity = c.OptionNum('sync', 'schedule_info_validity', 1 * hr, description=_('Check for new Schedules'), presets={'max': 1 * mn,
 'high': 5 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=8, icon='schedule')
sync_individual_schedule_info_validity = c.OptionNum('sync', 'individual_schedule_info_validity', 1 * hr, description=_('Validate current Schedules'), presets={'max': 1 * mn,
 'high': 10 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=9, icon='schedule')
sync_device_info_validity = c.OptionNum('sync', 'device_info_validity', 1 * hr, description=_('Check Device Information'), presets={'max': 1 * mn,
 'high': 30 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=1 * mn, maxval=2 * hr, incval=mn, index=10, icon='screen-server')
sync_device_state_validity = c.OptionNum('sync', 'device_state_validity', 10 * mn, description=_('Check Device State'), presets={'max': 1 * mn,
 'high': 2 * mn,
 'mid': 10 * mn,
 'low': 15 * mn}, minval=1 * mn, maxval=1 * hr, incval=mn, index=11, icon='re-sync')
sync_watchfolder_scan_frequency = c.OptionNum('sync', 'watchfolder_scan_frequency', 10 * mn, description=_('Scan Watchfolder'), presets={'max': 1 * mn,
 'high': 2 * mn,
 'mid': 10 * mn,
 'low': 15 * mn}, minval=1 * mn, maxval=2 * hr, incval=mn, index=12, icon='watchfolder')
sync_pos_info_validity = c.OptionNum('sync', 'pos_info_validity', 6 * hr, description=_('Update POS Feed'), presets={'max': 30 * mn,
 'high': 4 * hr,
 'mid': 6 * hr,
 'low': 8 * hr}, minval=30 * mn, maxval=12 * hr, incval=30 * mn, index=13, icon='pos')
sync_playback_info_validity = c.OptionNum('sync', 'playback_info_validity', 15, description=_('Check Playback State'), presets={'max': 1,
 'high': 1,
 'mid': 15,
 'low': 30}, minval=0, maxval=10 * mn, incval=5, index=14, icon='controls')
sync_projection_status_validity = c.OptionNum('sync', 'projection_status_validity', 30, description=_('Check Projection State'), presets={'max': 5,
 'high': 10,
 'mid': 30,
 'low': 2 * mn}, minval=5, maxval=15 * mn, incval=5, index=15, icon='projector')
sync_transfer_info_validity = c.OptionNum('sync', 'transfer_info_validity', 20, description=_('Check Transfer State'), presets={'max': 5,
 'high': 10,
 'mid': 20,
 'low': 1 * mn}, minval=5, maxval=15 * mn, incval=5, index=16, icon='transfer')
sync_auto_sync_ftp_validity = c.OptionNum('sync', 'ftp_folder_content_validity', 1 * hr, description=_('Sync FTP Folder'), presets={'max': 10 * mn,
 'high': 30 * mn,
 'mid': 1 * hr,
 'low': 2 * hr}, minval=10 * mn, maxval=2 * hr, incval=mn, index=17, icon='drive')
sync_selected_preset = c.OptionStr('sync', 'selected_preset', 'mid', description='Sync settings preset value')
auto_sync_ftp_folders = c.OptionBool('sync', 'auto_ftp_sync', False, description='Enable/Disable automatic syncing of content from ftp folders')
complex_street = c.OptionStr('app', 'complex_street', '', description='Physical street of the site, required for FLMX feed.')
complex_city = c.OptionStr('app', 'complex_city', '', description='Physical city of the site, required for FLMX feed.')
complex_province = c.OptionStr('app', 'complex_province', '', description='Physical province of the site, required for FLMX feed.')
complex_postcode = c.OptionStr('app', 'complex_postcode', '', description='Physical postcode of the site, required for FLMX feed.')
country = c.OptionStr('app', 'country', 'UK', description='[configurable through ui] The country that the TMS is in. Needs to be country code')
gdc_schedule_with_content_version_id = c.OptionBool('gdc', 'schedule_with_content_version_id', False, description="Use Content Version ID when scheduling on a GDC. GDC Docs - 'If there are multiple SPLs with the same content version ID at playback time, the SPL with the most recent IssueDate shall be used for playback'.")
dolby_dnqualifier_from_cert = c.OptionBool('dolby', 'dolby_dnqualifier_from_cert', False, description='Retrieve dnqualifier from security certificate of Dolbys')
dolby_playback_check_before_kdm_transfer = c.OptionBool('dolby', 'dolby_playback_check_before_kdm_transfer', True, description='Verify that a Dolby is not playing back before attempting a KDM transfer. [Recommended by Dolby but not always required]]')
# okay decompyling ./configuration/cfg.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:47:59 CST
