# 2017.08.13 21:51:58 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\email\email_imap.py
import imaplib, base64, logging, traceback, email, email.iterators, zipfile, StringIO, time
from datetime import timedelta, datetime

class email_imap:

    def __init__(self, server, username, password, SSL):
        self.IMAP_SERVER = server
        self.USERNAME = username
        self.PASSWORD = password
        self.SSL = SSL
        self.valid_details = None
        return

    def check_for_mail(self, read_uidls):
        outer_list = []
        try:
            if self.SSL:
                conn = imaplib.IMAP4_SSL(self.IMAP_SERVER)
            else:
                conn = imaplib.IMAP4(self.IMAP_SERVER)
            conn.login(self.USERNAME, self.PASSWORD)
            self.valid_details = True
        except:
            self.valid_details = False
            return outer_list

        try:
            conn.select('INBOX')
            status, response = conn.uid('search', None, 'ALL')
            list_of_ids = response[0].split()
            for uid in reversed(list_of_ids):
                response_code, email_content = conn.uid('fetch', uid, '(RFC822)')
                email_message = email.message_from_string(email_content[0][1])
                recipient = email_message['Delivered-To']
                sender = email_message['Return-Path']
                subject = email_message['Subject']
                email_date = email_message['Date']
                date = time.mktime(email.Utils.parsedate(email_date))
                cut_off_time = datetime.now() - timedelta(days=14)
                cut_off_timestamp = time.mktime(cut_off_time.timetuple())
                if date >= cut_off_timestamp and uid not in read_uidls:
                    has_attachment = False
                    if email_message['Content-Type']:
                        if 'multipart/mixed' in email_message['Content-Type']:
                            has_attachment = True
                    else:
                        continue
                    attachment_list = []
                    text_found = False
                    email_body = ''
                    for part in email_message.walk():
                        if 'text/plain' in part['Content-Type'] and text_found == False:
                            email_body = part.get_payload()
                            text_found = True
                        if has_attachment == True:
                            if part['Content-Disposition'] != None:
                                filename_data = part['Content-Disposition'].split('=')
                                if filename_data:
                                    filename = filename_data[1]
                                    if '.zip' in filename:
                                        fileObj = StringIO.StringIO()
                                        decoded = part.get_payload(decode=True)
                                        fileObj.write(decoded)
                                        fileObj.seek(0)
                                        zip = zipfile.ZipFile(fileObj)
                                        for name in zip.namelist():
                                            data = zip.open(name)
                                            read_data = data.read()
                                            attachment_text_dict = {'filename': name,
                                             'attachment_text': read_data}
                                            attachment_list.append(attachment_text_dict)

                                    else:
                                        encoded_attachment_content = part.get_payload()
                                        decoded_attachment_content = base64.decodestring(encoded_attachment_content)
                                        attachment_text_dict = {'filename': filename,
                                         'attachment_text': decoded_attachment_content}
                                        attachment_list.append(attachment_text_dict)

                    main_dict = {'sender': sender,
                     'recipient': recipient,
                     'subject': subject,
                     'email_body': email_body,
                     'date': email_date,
                     'attachment(s)': attachment_list,
                     'UIDL': uid}
                    outer_list.append(main_dict)
                else:
                    break

        except Exception as ex:
            logging.error('Problem retrieving email', exc_info=True)

        conn.logout()
        return outer_list

    def validate_connection(self):
        try:
            if self.SSL:
                conn = imaplib.IMAP4_SSL(self.IMAP_SERVER)
            else:
                conn = imaplib.IMAP4(self.IMAP_SERVER)
            conn.login(self.USERNAME, self.PASSWORD)
            conn.logout()
            return True
        except Exception as ex:
            logging.error('Problem connecting to kdm email server:' + str(ex))
            return False
# okay decompyling ./lib/email/email_imap.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:58 CST
