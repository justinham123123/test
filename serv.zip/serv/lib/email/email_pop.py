# 2017.08.13 21:51:59 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\email\email_pop.py
import poplib, base64, logging, traceback, email, zipfile, StringIO, time
from datetime import timedelta, datetime

class email_pop:

    def __init__(self, server, username, password, SSL):
        self.POP_SERVER = server
        self.USERNAME = username
        self.PASSWORD = password
        self.SSL = SSL
        self.valid_details = None
        return

    def check_for_mail(self, read_uidls):
        list_of_emails = []
        try:
            if self.SSL:
                conn = poplib.POP3_SSL(self.POP_SERVER)
            else:
                conn = poplib.POP3(self.POP_SERVER)
            conn.user(self.USERNAME)
            conn.pass_(self.PASSWORD)
            self.valid_details = True
        except:
            self.valid_details = False
            return list_of_emails

        try:
            number_of_emails = len(conn.list()[1])
            for i in range(number_of_emails, 0, -1):
                email_uidl = conn.uidl(i).split()[2]
                email_content = conn.retr(i)[1]
                email_message = email.message_from_string('\n'.join(email_content))
                email_date = email_message['Date']
                date = time.mktime(email.Utils.parsedate(email_date))
                cut_off_time = datetime.now() - timedelta(days=14)
                cut_off_timestamp = time.mktime(cut_off_time.timetuple())
                if date >= cut_off_timestamp and email_uidl not in read_uidls:
                    attachment_list = []
                    recipient = email_message['Delivered-To']
                    sender = email_message['Return-Path']
                    subject = email_message['Subject']
                    has_attachment = False
                    if 'multipart/mixed' in email_message['Content-Type']:
                        has_attachment = True
                    text_found = False
                    email_body = ''
                    for part in email_message.walk():
                        if 'text/plain' in part['Content-Type'] and text_found == False:
                            email_body = part.get_payload()
                            text_found = True
                        if has_attachment == True:
                            if part['Content-Disposition'] != None:
                                filename_data = part['Content-Disposition'].split('=')
                                filename = filename_data[1]
                                if '.zip' in filename:
                                    fileObj = StringIO.StringIO()
                                    decoded = part.get_payload(decode=True)
                                    fileObj.write(decoded)
                                    fileObj.seek(0)
                                    zip = zipfile.ZipFile(fileObj)
                                    for name in zip.namelist():
                                        data = zip.open(name)
                                        read_data = data.read()
                                        attachment_text_dict = {'filename': name,
                                         'attachment_text': read_data}
                                        attachment_list.append(attachment_text_dict)

                                else:
                                    encoded_attachment_content = part.get_payload()
                                    decoded_attachment_content = base64.decodestring(encoded_attachment_content)
                                    attachment_text_dict = {'filename': filename,
                                     'attachment_text': decoded_attachment_content}
                                    attachment_list.append(attachment_text_dict)

                    main_dict = {'sender': sender,
                     'recipient': recipient,
                     'subject': subject,
                     'email_body': email_body,
                     'date': date,
                     'attachment(s)': attachment_list,
                     'UIDL': email_uidl}
                    list_of_emails.append(main_dict)
                else:
                    break

        except Exception as ex:
            logging.error('Problem retrieving email', exc_info=True)

        conn.quit()
        return list_of_emails

    def validate_connection(self):
        try:
            if self.SSL:
                conn = poplib.POP3_SSL(self.POP_SERVER)
            else:
                conn = poplib.POP3(self.POP_SERVER)
            conn.user(self.USERNAME)
            conn.pass_(self.PASSWORD)
            conn.quit()
            return True
        except Exception as ex:
            logging.error('Problem connecting to kdm email server:' + str(ex))
            return False
# okay decompyling ./lib/email/email_pop.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:59 CST
