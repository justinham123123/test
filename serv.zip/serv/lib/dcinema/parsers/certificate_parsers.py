# 2017.08.13 21:51:53 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\parsers\certificate_parsers.py
"""
Device Cert and dnQualifier parsers (split out of parsers.py so Producer don;t need to import pyopenssl)
"""
from OpenSSL import crypto
import types

def full_subject(subject):
    string = ','.join([ key + '=' + value for key, value in subject.get_components() ])
    return string


def parse_device_certificates(*certificate_chains):
    """
    Parses out the leaf (device) certificates from certificate chains.
    
    Any number of certificate chains can be passed in as arguments,
    returning a list of the dnQualifiers and certificates found at the leaves of the chains.
    """
    output = {'device_dnqualifier': None,
     'dnqualifiers': [],
     'product_certificates': {}}
    for chain in certificate_chains:
        if not isinstance(chain, list) and not isinstance(chain, types.GeneratorType):
            chain = [chain]
        dnqualifier_pairs = {}
        parsed_certificates = {}
        for certificate in chain:
            decoded_cert = crypto.load_certificate(crypto.FILETYPE_PEM, certificate)
            dnqualifier = _get_dn_qualifier_from_cert(decoded_cert)
            parsed_certificates[dnqualifier] = {'subject': decoded_cert.get_subject(),
             'certificate': certificate}
            issuer_dnqualifier = _get_issuer_dn_qualifier_from_cert(decoded_cert)
            if issuer_dnqualifier != dnqualifier:
                dnqualifier_pairs[issuer_dnqualifier] = dnqualifier
            else:
                dnqualifier_pairs['root'] = dnqualifier

        leaf_dnqualifier = _get_leaf_dnqualifier(dnqualifier_pairs)
        leaf_certificate = parsed_certificates[leaf_dnqualifier]
        if leaf_dnqualifier not in output['dnqualifiers']:
            output['dnqualifiers'].append(leaf_dnqualifier)
        subject = full_subject(leaf_certificate['subject'])
        if subject not in output['product_certificates']:
            output['product_certificates'][subject] = leaf_certificate['certificate']

    if output['dnqualifiers']:
        output['device_dnqualifier'] = output['dnqualifiers'][0]
    return output


def _get_leaf_dnqualifier(dnqualifier_pairs):
    """
    Retrives the device dnqualifier from a list of device:issuer dn qualifier pairs
    Returns None if not found
    """
    for issuer in dnqualifier_pairs:
        if dnqualifier_pairs[issuer] not in dnqualifier_pairs:
            return dnqualifier_pairs[issuer]

    return None


def _get_dn_qualifier_from_cert(cert):
    """
    Retrieves the dn qualifier from a certificate
    """
    subject = cert.get_subject()
    subject_dn_qualifier = ''
    for component in subject.get_components():
        if component[0] == 'dnQualifier':
            subject_dn_qualifier = component[1]

    return subject_dn_qualifier


def _get_issuer_dn_qualifier_from_cert(cert):
    """
    Retrieves the issuer dn qualifier from a certificate
    """
    subject = cert.get_issuer()
    subject_dn_qualifier = ''
    for component in subject.get_components():
        if component[0] == 'dnQualifier':
            subject_dn_qualifier = component[1]

    return subject_dn_qualifier
# okay decompyling ./lib/dcinema/parsers/certificate_parsers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:53 CST
