# 2017.08.13 21:51:53 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\parsers\parsers.py
"""
Simple regex parsers for playlists (doremi & dolby), KDMs, CPLs, PKLs and asset maps
"""
import csv
import datetime
import logging
import os.path
import re
from StringIO import StringIO
import time
import uuid
from datetime import timedelta
from serv.lib.utilities.date_utils import parse_date
from serv.lib.dcinema.constants import CONTENT_KIND_SHORT
from serv.lib.dcinema.dcp.utils import ParsingException
from serv.lib.dcinema.dcp.cpl import CPL as DCP_CPL
from serv.lib.utilities.utils import strip_urn, wrap_urn
from serv.lib.utilities.xml_utils import create_node, create_attribute, get_element_data, get_element_children, get_element_value, XMLBuilder
from serv.lib.utilities.xml_utils import iterparse_xml
from serv.configuration import cfg
from serv.configuration.constants import HFR_FPS
from xml.dom.minidom import Document
from xml.parsers.expat import ExpatError
import json
import xml.dom.minidom as minidom
DOM_IMPLEMENTATION = minidom.getDOMImplementation()
DEFAULT_POS_SESSION_LENGTH = cfg.pos_default_session_length() * 60

def _parse_map_assets(xml):
    """
    Parses the assets within an asset map. This is not generic as
    it would be vastly more complex to make it so.
    """
    result = []
    asset_list_re = re.compile('[<:]AssetList.*?>(.*?)</AssetList>', re.DOTALL)
    asset_list_xml = asset_list_re.search(xml).group()
    assets_re = re.compile('[<:]Asset.*?>(.*?)</Asset>', re.DOTALL)
    for asset_xml in assets_re.findall(asset_list_xml):
        asset_dict = {}
        asset_id_re = re.compile('[<:]Id.*?>(.*?)</Id>', re.DOTALL)
        asset_dict['id'] = asset_id_re.search(asset_xml).group(1)
        asset_dict['chunks'] = get_element_children(asset_xml, 'chunk', 'chunklist')
        result.append(asset_dict)

    return result


def _get_dn_qualifier(dn_str):
    """
    Retrieves the dn qualifier from a string
    """
    qualifier_re = re.compile('dnQualifier=(.*?=)', re.DOTALL)
    search_object = qualifier_re.search(dn_str)
    if not search_object:
        return '?'
    dn_qualifier = search_object.group(1)
    replace_anywhere = ['\\+',
     '\\,',
     '\\"',
     '\\<',
     '\\>',
     '\\;',
     '\\.']
    replace_at_beggining_or_end = ['\\ ', '\\#']
    dn_qualifier = dn_qualifier.replace('\\\\', '\\')
    for x in replace_anywhere:
        dn_qualifier = dn_qualifier.replace(x, x[1])

    for x in replace_at_beggining_or_end:
        if dn_qualifier.startswith(x):
            dn_qualifier = dn_qualifier.replace(x, x[1], 1)
        if dn_qualifier.endswith(x):
            dn_qualifier = dn_qualifier[:-2] + dn_qualifier[-1]

    return dn_qualifier


def _get_kdm_device_serial(subject_name_string):
    if 'DOREMILABS' in subject_name_string:
        substr = subject_name_string.split(',')
        regex = re.compile('(-)([^.]+)')
        result = regex.search(substr[1])
        if result:
            return result.group(2)
        else:
            return None
    else:
        return None
    return None


def _load_data_if_required(source, load_from_file):
    """
    Loads data from a file if the flag is set, returning the data
    """
    if load_from_file:
        f = open(source, 'r')
        data = f.read()
        f.close()
    else:
        data = source
    return data


CPL, PKL, ASSET_MAP, PLAYLIST, KDM = range(5)
_XML_TYPE = {CPL: 'compositionplaylist',
 PKL: 'packinglist',
 ASSET_MAP: '<assetmap',
 PLAYLIST: 'showplaylist',
 KDM: 'dcinemasecuritymessage'}

def find_files(scan_dir, file_type):
    """
    Recursively scan a directory hierarchy for xml files of a specified type
    """
    xml_list = []
    if scan_dir.find('.svn') != -1:
        return []
    if not os.path.exists(scan_dir) or not os.path.isdir(scan_dir):
        logging.error('The directory "%s" does not exist' % scan_dir)
        return xml_list
    path = os.path.abspath(scan_dir)
    for item in os.listdir(scan_dir):
        item_path = os.path.join(path, item)
        if os.path.isdir(item_path):
            xml_list.extend(find_files(item_path, file_type))
        elif os.path.isfile(item_path):
            f = open(item_path, 'r')
            if f.read(200).lower().find(_XML_TYPE[file_type]) != -1:
                xml_list.append(item_path)
            f.close()

    return xml_list


def parse_cpl(cpl_source, load_from_file = True):
    """
    Parses the CPL using serv.cinema_services.lib.dcinema.dcp.cpl.
    This is simply a reformatting function for that parser
    """
    try:
        cpl = DCP_CPL(cpl_source, load_from_file=load_from_file)
    except ParsingException:
        logging.error('Error parsing the cpl:', exc_info=True)
        raise

    return dict(id=cpl.uuid, text=cpl.content_title_text, type=cpl.content_kind, edit_rate=[int(cpl.edit_rate_a), int(cpl.edit_rate_b)], duration_in_seconds=cpl.duration_in_seconds, duration_in_frames=cpl.duration, subtitled=cpl.subtitle, subtitle_language=cpl.subtitle_lang if cpl.subtitle_lang not in ('XX', '') else None, playback_mode='3D' if cpl.is3d else '2D', aspect_ratio=cpl.cpl_aspect_ratio, encrypted=len(cpl.crypto_id_list) > 0, assets=cpl.asset_ids, parsed_info=parse_content_title_text(cpl.content_title_text), reels=cpl.cpl_reels)


def parse_pkl(pkl_source, load_from_file = True):
    """
    Parses the following information from a PKL xml file:
    """
    pkl = _load_data_if_required(pkl_source, load_from_file)
    pkl_id = get_element_data(pkl, 'Id')
    pkl_text = get_element_data(pkl, 'AnnotationText')
    pkl_issue_date = parse_date(get_element_data(pkl, 'IssueDate'))
    pkl_issuer = get_element_data(pkl, 'Issuer')
    pkl_creator = get_element_data(pkl, 'Creator')
    pkl_assets = get_element_children(pkl, 'Asset', 'AssetList')
    return dict(id=pkl_id, text=pkl_text, issue_date=pkl_issue_date, issuer=pkl_issuer, creator=pkl_creator, assets=pkl_assets)


def parse_asset_map(asset_map_source, load_from_file = True):
    """
    Parses the following information from an asset map xml file:
    """
    am = _load_data_if_required(asset_map_source, load_from_file)
    am_id = get_element_data(am, 'Id')
    am_issue_date = parse_date(get_element_data(am, 'IssueDate'))
    am_issuer = get_element_data(am, 'Issuer')
    am_creator = get_element_data(am, 'Creator')
    am_assets = _parse_map_assets(am)
    return dict(id=am_id, issue_date=am_issue_date, issuer=am_issuer, creator=am_creator, assets=am_assets)


def construct_smpte_playlist2(spl_dict):
    """
    Constructs a SMPTE430-8 XML playlist from a Python dictionary
    """
    spl_doc = DOM_IMPLEMENTATION.createDocument(None, 'ShowPlaylist', None)
    root_node = spl_doc.documentElement
    create_attribute(spl_doc, root_node, 'xmlns', 'http://www.smpte-ra.org/430-8/2006/SPL')
    create_node(spl_doc, root_node, 'Id', wrap_urn(spl_dict['id']))
    create_node(spl_doc, root_node, 'ShowTitleText', spl_dict['title'])
    create_node(spl_doc, root_node, 'Issuer', 'AAM')
    create_node(spl_doc, root_node, 'Creator', 'TMS')
    create_node(spl_doc, root_node, 'IssueDate', datetime.datetime.now().isoformat())
    content_v_node = create_node(spl_doc, root_node, 'ContentVersion')
    create_node(spl_doc, content_v_node, 'Id', str(uuid.uuid4()))
    create_node(spl_doc, content_v_node, 'LabelText', 'AAM SPL')
    pack_list_node = create_node(spl_doc, root_node, 'PackList')
    playlist_pack_node = create_node(spl_doc, pack_list_node, 'PlaylistPack')
    create_node(spl_doc, playlist_pack_node, 'Id', wrap_urn(str(uuid.uuid4())))
    playlist_type_choice_node = create_node(spl_doc, playlist_pack_node, 'PlaylistTypeChoice')
    create_node(spl_doc, playlist_type_choice_node, 'PlayCount', '1')
    playlist_node = create_node(spl_doc, playlist_pack_node, 'Playlist')
    for event in spl_dict['events']:
        if event['type'] in ('placeholder', 'title', 'macro_pack', 'pattern'):
            continue
        if event.has_key('automation'):
            for automation in event['automation']:
                if automation['type'] in ('cue', 'gdc_start_cue'):
                    marker_node = create_node(spl_doc, playlist_node, 'PlaylistMarker')
                    cue_id = str(uuid.uuid4())
                    create_node(spl_doc, marker_node, 'Id', wrap_urn(cue_id))
                    offset_in_frames = automation['type_specific']['offset_in_frames']
                    if automation['type_specific']['offset_from'] == 'end':
                        offset_in_frames = event['duration_in_frames'] - offset_in_frames if event['duration_in_frames'] else 0
                    create_node(spl_doc, marker_node, 'AnnotationText', automation['type_specific']['action'])
                    edit_rate_a, edit_rate_b = event['edit_rate']
                    create_node(spl_doc, marker_node, 'Label', automation['type_specific']['action'])
                    offset_node = create_node(spl_doc, marker_node, 'Offset', str(offset_in_frames))
                    create_attribute(spl_doc, offset_node, 'EditRate', '{0} {1}'.format(edit_rate_a, edit_rate_b))

        create_node(spl_doc, playlist_node, 'CompositionPlaylistId', wrap_urn(event['cpl_id']))

    return spl_doc.toxml('utf-8')


def construct_smpte_playlist(contents, playlist):
    doc = Document()
    builder = XMLBuilder(doc)
    root = builder.node(doc, 'ShowPlaylist')
    builder.attr(root, 'xmlns', 'http://www.smpte-ra.org/430-8/2006/SPL')
    builder.attr(root, 'xmlns:xsd', 'http://www.w3.org/2001/XMLSchema')
    builder.attr(root, 'xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
    playlist_uuid = playlist['id'] if playlist['id'] else uuid.uuid4()
    builder.node(root, 'Id', 'urn:uuid:' + str(playlist_uuid))
    builder.node(root, 'AnnotationText', playlist['title'])
    builder.node(root, 'IssueDate', str(datetime.datetime.now().isoformat()))
    builder.node(root, 'Issuer', 'AAM Screenwriter')
    builder.node(root, 'Creator', 'AAM Screenwriter')
    builder.node(root, 'ShowTitleText', playlist['title'])
    content_version = builder.node(root, 'ContentVersion')
    builder.node(content_version, 'Id', str(uuid.uuid4()))
    builder.node(content_version, 'LabelText', 'AAM SPL')
    pack_list = builder.node(root, 'PackList')
    for event in playlist.get('events', []):
        if event['type'] == 'composition':
            pack = builder.node(pack_list, 'PlaylistPack')
            core_cpl = contents.get(event['cpl_id'], {})
            builder.node(pack, 'PlaylistPackKind', core_cpl.get('content_kind', 'unknown'), attrs=[{'name': 'xmlns',
              'value': 'http://www.smpte-ra.org/430-8/2006/PPK'}])
            builder.node(pack, 'Id', 'urn:uuid:' + event['id'], attrs=[{'name': 'xmlns',
              'value': 'http://www.smpte-ra.org/430-8/2006/PPK'}])
            builder.node(pack, 'AnnotationText', event['text'], attrs=[{'name': 'xmlns',
              'value': 'http://www.smpte-ra.org/430-8/2006/PPK'}])
            playlist_node = builder.node(pack, 'Playlist', attrs=[{'name': 'xmlns',
              'value': 'http://www.smpte-ra.org/430-8/2006/PPK'}])
            for automation in event.get('automation', []):
                edit_rate = '{0} {1}'.format(event['edit_rate'][0], event['edit_rate'][1])
                automation_uuid = automation.get('id', str(uuid.uuid4()))
                if 'offset_in_frames' in automation['type_specific']:
                    offset = automation['type_specific']['offset_in_frames']
                else:
                    offset = automation['type_specific']['offset_in_seconds'] * (event['edit_rate'][0] / event['edit_rate'][1])
                playlist_marker = builder.node(playlist_node, 'PlaylistMarker')
                builder.node(playlist_marker, 'Id', 'urn:uuid:' + automation_uuid)
                builder.node(playlist_marker, 'Label', automation['name'])
                builder.node(playlist_marker, 'AnnotationText', automation['type_specific']['action'])
                builder.node(playlist_marker, 'Offset', str(offset), attrs=[{'name': 'EditRate',
                  'value': edit_rate}])

            builder.node(playlist_node, 'CompositionPlaylistId', 'urn:uuid:' + event['cpl_id'])

    return root.toxml()


def parse_smpte_playlist(content_store, playlist_xml):
    """
    Parses a SMPTE 430-8 XML playlist to a Python dictionary.
    Uses the mini DOM and not regular expressions (assumes well-formed XML)
    """
    root_node = minidom.parseString(playlist_xml.encode('utf-8'))
    playlist_id = strip_urn(root_node.getElementsByTagName('Id')[0].firstChild.data)
    content_version_id = None
    content_version = root_node.getElementsByTagName('ContentVersion')
    if len(content_version):
        content_version_id = content_version[0].getElementsByTagName('Id')[0].firstChild.data
    title_text = root_node.getElementsByTagName('ShowTitleText')[0].firstChild
    if title_text != None:
        playlist_title = root_node.getElementsByTagName('ShowTitleText')[0].firstChild.data
    else:
        playlist_title = playlist_id
    annotation_element = root_node.getElementsByTagName('AnnotationText')
    if len(annotation_element) > 0:
        playlist_text = annotation_element[0].firstChild.data
    else:
        playlist_text = playlist_title
    playlist_duration = 0
    playlist_is_3d = False
    playlist_is_hfr = False
    events = []
    automation = []
    playlist_nodes = root_node.getElementsByTagName('Playlist')
    for playlist_node in playlist_nodes:
        for child_node in [ n for n in playlist_node.childNodes if n.nodeType == n.ELEMENT_NODE ]:
            if child_node.tagName == 'CompositionPlaylistId':
                cpl_uuid = strip_urn(child_node.firstChild.data)
                try:
                    cpl = content_store[cpl_uuid]
                except KeyError:
                    content_title_text = cpl_uuid
                    edit_rate = None
                    duration_in_seconds = None
                    duration_in_frames = None
                else:
                    content_title_text = cpl['content_title_text']
                    if cpl['edit_rate'][0] is not None and cpl['edit_rate'][1] is not None:
                        edit_rate = (cpl['edit_rate'][0], cpl['edit_rate'][1])
                        for automation_dict in automation:
                            if automation_dict['type'] == 'cue':
                                automation_dict['type_specific']['offset_in_seconds'] = automation_dict['type_specific']['offset_in_frames'] / (1 * edit_rate[0] / edit_rate[1])

                        playlist_is_hfr |= cpl['edit_rate'][0] > HFR_FPS
                    else:
                        edit_rate = None
                    duration_in_seconds = cpl['duration_in_seconds'] if cpl['duration_in_seconds'] else 0
                    duration_in_frames = cpl['duration_in_frames']
                    playlist_duration += int(duration_in_seconds)
                    playlist_is_3d |= cpl['playback_mode'] == '3D'

                events.append({'id': str(uuid.uuid3(uuid.UUID(playlist_id), 'event_%d' % len(events))),
                 'main_id': None,
                 'automation': automation,
                 'cpl_id': cpl_uuid,
                 'type': 'composition',
                 'text': content_title_text,
                 'edit_rate': edit_rate,
                 'duration_in_seconds': duration_in_seconds,
                 'duration_in_frames': duration_in_frames})
                automation = []
            if child_node.tagName == 'PlaylistMarker':
                try:
                    offset = int(float(child_node.getElementsByTagName('Offset')[0].firstChild.data))
                except IndexError:
                    offset = 0

                id = strip_urn(child_node.getElementsByTagName('Id')[0].firstChild.data)
                text = child_node.getElementsByTagName('AnnotationText')[0].firstChild.data
                label_elements = child_node.getElementsByTagName('Label')
                label = label_elements[0].firstChild.data if label_elements[0].firstChild else None
                cue = {'id': id,
                 'name': text,
                 'type': 'cue',
                 'type_specific': {'offset_from': 'start',
                                   'offset_in_frames': offset,
                                   'offset_in_seconds': None,
                                   'action': label}}
                automation.append(cue)

    return {'id': playlist_id,
     'title': playlist_title,
     'text': playlist_text,
     'is_3d': playlist_is_3d,
     'is_hfr': playlist_is_hfr,
     'is_4k': False,
     'duration_in_seconds': playlist_duration,
     'events': events,
     'automation': automation,
     'content_version_id': content_version_id}


def parse_kdm(kdm_source, load_from_file = True):
    """
    Parses the following information from a KDM:
    """
    kdm = _load_data_if_required(kdm_source, load_from_file)
    start_date_element = get_element_data(kdm, 'ContentKeysNotValidBefore')
    if start_date_element == None:
        return {}
    else:
        kdm_start_date = parse_date(get_element_data(kdm, 'ContentKeysNotValidBefore'))
        kdm_id = strip_urn(get_element_data(kdm, 'MessageId'))
        kdm_text = get_element_data(kdm, 'AnnotationText')
        kdm_issue_date = parse_date(get_element_data(kdm, 'IssueDate'))
        kdm_dn_qualifier = _get_dn_qualifier(get_element_data(kdm, 'X509SubjectName'))
        kdm_device_serial = _get_kdm_device_serial(get_element_data(kdm, 'X509SubjectName'))
        kdm_end_date = parse_date(get_element_data(kdm, 'ContentKeysNotValidAfter'))
        kdm_cpl_id = strip_urn(get_element_data(kdm, 'CompositionPlaylistId'))
        kdm_cpl_text = get_element_data(kdm, 'ContentTitleText')
        kdm_authenticator = get_element_data(kdm, 'ContentAuthenticator')
        return dict(id=kdm_id, text=kdm_text, issue_date=kdm_issue_date, dn_qualifier=kdm_dn_qualifier, device_serial_number=kdm_device_serial, start_date=kdm_start_date, end_date=kdm_end_date, cpl_id=kdm_cpl_id, cpl_text=kdm_cpl_text, authenticator=kdm_authenticator)
        return


_content_title_re = re.compile('([A-Z0-9\\-]+)', re.I | re.U)
_content_kind_re = re.compile('([A-Z0-9\\-]+)', re.I | re.U)
_aspect_ratio_re = re.compile('(F|S|C)', re.I | re.U)
_audio_and_subtitle_lang_re = re.compile('([A-Z]{2,3})(?:-([A-Z]{2,3}))?', re.I | re.U)
_territory_and_rating_re = re.compile('([A-Z]{2}(?=-|$)|INT(?:-T[DL])?)(?:-([A-Z0-9]{1,3}))?', re.I | re.U)
_audio_type_and_description_lang = re.compile('(\\d{2})(?:-([A-Z]{2}(?=-|$)))?(?:-([A-Z]{2}(?=-|$)))?(?:-([A-Z]{4,5}))?(?:-([A-Z]{4,5}))?(?:-(DBOX))?', re.I | re.U)
_resolution_re = re.compile('(2K|4K|48)', re.I | re.U)
_studio_re = re.compile('([A-Z]{2,4})', re.I | re.U)
_date_re = re.compile('([0-9]{8})', re.I | re.U)
_facility_re = re.compile('([A-Z]{3})', re.I | re.U)
_three_d_spec_re = re.compile('(i3D(?:-n?gb)?)', re.I | re.U)
_package_type_re = re.compile('(OV|VF(?:-\\d+)?)', re.I | re.U)

def parse_content_title_text(content_title_text):
    cpl_details = {'playback_mode': None,
     'content_title': None,
     'content_kind': None,
     'aspect_ratio': None,
     'audio_language': None,
     'subtitle_language': None,
     'subtitled': False,
     'territory': None,
     'rating': None,
     'audio_type': None,
     'narrative_description_language': None,
     'resolution': None,
     'studio': None,
     'date': None,
     'facility': None,
     'ghostbusting': None,
     'package_type': None}
    if not content_title_text:
        return cpl_details
    else:
        title_parts = content_title_text.split('_')
        match = _content_title_re.match(title_parts[0])
        if match:
            cpl_details['content_title'] = match.group(1)
            if '3D' in cpl_details['content_title']:
                cpl_details['playback_mode'] = '3D'
            else:
                cpl_details['playback_mode'] = '2D'
        else:
            cpl_details['content_title'] = content_title_text
            return cpl_details
        if len(title_parts) >= 2:
            match = _content_kind_re.match(title_parts[1])
            if match:
                cpl_details['content_kind'] = match.group(1).split('-')[0]
                found = False
                for key in CONTENT_KIND_SHORT:
                    found = False
                    if cpl_details['content_kind'] in CONTENT_KIND_SHORT[key] or cpl_details['content_kind'] == CONTENT_KIND_SHORT[key]:
                        cpl_details['content_kind'] = key
                        found = True
                        break

                if not found:
                    cpl_details['content_kind'] = 'unknown'
                if '3D' in cpl_details['content_kind']:
                    cpl_details['playback_mode'] = '3D'
        if len(title_parts) >= 3:
            match = _aspect_ratio_re.match(title_parts[2])
            if match:
                cpl_details['aspect_ratio'] = match.group(1)
        if len(title_parts) >= 4:
            match = _audio_and_subtitle_lang_re.match(title_parts[3])
            if match:
                cpl_details['audio_language'] = match.group(1)
                cpl_details['subtitle_language'] = match.group(2)
                cpl_details['subtitled'] = cpl_details['subtitle_language'] != 'XX'
        if len(title_parts) >= 5:
            match = _territory_and_rating_re.match(title_parts[4])
            if match:
                cpl_details['territory'] = match.group(1)
                cpl_details['rating'] = match.group(2)
        if len(title_parts) >= 6:
            match = _audio_type_and_description_lang.match(title_parts[5])
            if match:
                audio_types = []
                if match.group(1):
                    audio_types.append(match.group(1))
                if match.group(4):
                    audio_types.append(match.group(4))
                if match.group(5):
                    audio_types.append(match.group(5))
                cpl_details['audio_type'] = audio_types if audio_types else None
                narratives = []
                if match.group(2):
                    narratives.append(match.group(2))
                if match.group(3):
                    narratives.append(match.group(3))
                cpl_details['narrative_description_language'] = narratives if narratives else None
                cpl_details['motion_simulator_format'] = match.group(6)
        if len(title_parts) >= 7:
            match = _resolution_re.match(title_parts[6])
            if match:
                cpl_details['resolution'] = match.group(1)
        if len(title_parts) >= 8:
            match = _studio_re.match(title_parts[7])
            if match:
                cpl_details['studio'] = match.group(1)
        if len(title_parts) >= 9:
            match = _date_re.match(title_parts[8])
            if match:
                try:
                    cpl_details['date'] = datetime.datetime.strptime(match.group(1), '%Y-%m-%d').date()
                except ValueError:
                    pass

        if len(title_parts) >= 10:
            match = _facility_re.match(title_parts[9])
            if match:
                cpl_details['facility'] = match.group(1)
        if len(title_parts) >= 11:
            match = _three_d_spec_re.match(title_parts[10])
            if match:
                cpl_details['playback_mode'] = '3D'
                if match.group(1) == 'i3D':
                    cpl_details['ghostbusting'] = 'INT'
                elif 'ngb' in match.group(1):
                    cpl_details['ghostbusting'] = 'NGB'
                else:
                    cpl_details['ghostbusting'] = 'GB'
        if len(title_parts) >= (12 if match else 11):
            match = _package_type_re.match(title_parts[11 if match else 10])
            if match:
                cpl_details['package_type'] = match.group(1)
        return cpl_details


def parse_deadlist_file(deadlist_string):
    dead_print_uuids = []
    empty = None
    parsable = None
    try:
        parsable = True
        dom = minidom.parseString(deadlist_string)
        nodes = dom.getElementsByTagName('print_no')
        if len(nodes) > 0:
            empty = False
        else:
            empty = True
        for node in dom.getElementsByTagName('print_no'):
            dead_print_uuids.append(node.getElementsByTagName('uuid')[0].firstChild.data)

    except ExpatError:
        parsable = False

    return (dead_print_uuids, {'parsable': parsable,
      'empty': empty})


def parse_pack_xml(xml):
    dom = minidom.parseString(xml)
    if len(dom.getElementsByTagName('AAMPack')) > 0:
        return parse_aam_pack(dom)
    issuer = dom.getElementsByTagName('issuer')
    if len(issuer) > 0:
        if get_element_value(issuer[0], 'company').lower() == 'val morgan cinema network':
            return parse_val_morgan(dom)
    raise Exception('Not an understood pack xml document')


def parse_aam_pack(dom):
    """
    <?xml version="1.0" encoding="utf-8" standalone="yes"?>
    <AAMPack>
        <Id>%(UUID)s</Id>
        <AnnotationText>%(annotation_text)s</AnnotationText>
        <IssueDate>%(issue_date)s</IssueDate>
        <Issuer>%(issuer)s</Issuer>
        <Placeholder>%(placeholder)s</Placeholder>
        <Version>%(version)s</Version>
        <ComplexName>%(complex_name)s</ComplexName>
        <TargetRatingCertificate>%(certificate)s</TargetRatingCertificate>
        <FilmTitle>%(film_title)s</FilmTitle>
        <ShowAttributes>
            <ShowAttribute>%(show_attribute)</ShowAttribute>
        </ShowAttributes>
        <ScreenList>
            <Screen>%(Identifer)s</Screen>
        </ScreenList>
        <not_valid_before_date>%(not_valid_before_date)s</not_valid_before_date>
        <not_valid_before_time>%(not_valid_before_time)s</not_valid_before_time>
        <not_valid_after_date>%(not_valid_after_date)s</not_valid_after_date>
        <not_valid_after_time>%(not_valid_after_time)s</not_valid_after_time>
        <element_list>
                <Element>
                    <ContentTitleText>%(annotation)s</ContentTitleText>
                    <CplUUID>%(cpl_id)s</CplUUID>
                    <Duration>%(duration in frames)s</Duration>
                    <EditRate>%(edit_rate)s</EditRate>
                </Element>
        </element_list>
    </AAMPack>
    """
    output = {}
    aam_pack = dom.getElementsByTagName('AAMPack')[0]
    uuid = get_element_value(aam_pack, 'UUID')
    output['uuid'] = strip_urn(uuid).lower() if uuid else None
    output['name'] = get_element_value(aam_pack, 'AnnotationText')
    output['issue_date'] = get_element_value(aam_pack, 'IssueDate')
    output['issuer'] = get_element_value(aam_pack, 'Issuer')
    output['placeholder_name'] = get_element_value(aam_pack, 'Placeholder')
    output['version'] = get_element_value(aam_pack, 'Version')
    output['complex_name'] = get_element_value(aam_pack, 'ComplexName')
    output['date_from'] = get_element_value(aam_pack, 'NotValidBeforeDate')
    output['time_from'] = get_element_value(aam_pack, 'NotValidBeforeTime')
    output['date_to'] = get_element_value(aam_pack, 'NotValidAfterDate')
    output['time_to'] = get_element_value(aam_pack, 'NotValidAfterTime')
    output['rating'] = get_element_value(aam_pack, 'TargetRatingCertificate')
    output['title_name'] = get_element_value(aam_pack, 'FilmTitle')
    output['priority'] = get_element_value(aam_pack, 'Priority')
    output['print_no'] = get_element_value(aam_pack, 'PrintNumber')
    output['external_show_attribute_maps'] = []
    for element in aam_pack.getElementsByTagName('ShowAttribute'):
        output['external_show_attribute_maps'].append({'source': output['issuer'],
         'external_id': get_element_value(element)})

    if output['version'] != None:
        output['name'] = output['name'] + '_' + output['version']
    output['screen_identifiers'] = []
    for element in aam_pack.getElementsByTagName('Screen'):
        output['screen_identifiers'].append(get_element_value(element))

    output['clips'] = []
    element_list = aam_pack.getElementsByTagName('ElementList')[0]
    for element in element_list.getElementsByTagName('Element'):
        tmp = {}
        tmp['text'] = get_element_value(element, 'ContentTitleText')
        tmp['type'] = 'composition'
        tmp['cpl_id'] = strip_urn(get_element_value(element, 'CplUUID'))
        tmp['duration_in_frames'] = get_element_value(element, 'Duration')
        tmp['edit_rate'] = get_element_value(element, 'EditRate')
        if tmp['duration_in_frames'] != None and tmp['edit_rate'] != None:
            cpl_edit_rate = [ int(i) for i in tmp['edit_rate'].split(' ') ]
            tmp['duration_in_seconds'] = long(tmp['duration_in_frames']) / (1.0 * int(cpl_edit_rate[0]) / int(cpl_edit_rate[1]))
        output['clips'].append(tmp)

    return [output]


def _create_vm_pack_defaults(show_time, title, show_attribute, pack_count):
    name = '%s_ads-%s_%s_%s' % (title['name'],
     pack_count,
     show_time['start'].strftime('%Y-%m-%d'),
     show_time['end'].strftime('%Y-%m-%d'))
    print 'name is!' + name
    return {'issuer': 'val_morgan',
     'issue_date': time.time(),
     'name': name,
     'uuid': str(uuid.uuid5(uuid.NAMESPACE_DNS, 'val_morgan_' + name.encode('utf-8'))),
     'placeholder_name': 'advertisement_%s' % pack_count,
     'time_from': None,
     'date_from': show_time['start'].strftime('%Y-%m-%d'),
     'time_to': None,
     'date_to': show_time['end'].strftime('%Y-%m-%d'),
     'title_name': title['name'],
     'title_external_ids': [{'source': 'val_morgan',
                             'external_id': title['id']}],
     'external_show_attribute_maps': [{'source': 'val_morgan',
                                       'external_id': show_attribute}],
     'clips': []}


def parse_val_morgan(dom):
    output = []
    placeholders = {}
    for placeholders_node in dom.getElementsByTagName('placeholders'):
        for placeholder_node in dom.getElementsByTagName('placeholder_no'):
            id = placeholder_node.attributes['placeholder_id'].value
            name = get_element_value(placeholder_node, 'placeholder_desc')
            placeholders[id] = {'name': name,
             'id': id}

    complexes = {}
    for complex_node in dom.getElementsByTagName('complexes'):
        id = get_element_value(complex_node, 'complex_no')
        name = get_element_value(complex_node, 'complex_name')
        complexes[id] = {'name': name,
         'id': id}

    titles = {}
    for movies_node in dom.getElementsByTagName('movies'):
        for movie_node in movies_node.getElementsByTagName('movie_no'):
            id = movie_node.attributes['movie_id'].value
            name = get_element_value(movie_node, 'movie_name')
            titles[id] = {'name': name,
             'id': id}

    prints = {}
    for prints_node in dom.getElementsByTagName('prints'):
        for print_node in prints_node.getElementsByTagName('print_no'):
            id = print_node.attributes['print_id'].value
            print_dict = {'name': get_element_value(print_node, 'print_name'),
             'content_title_text': get_element_value(print_node, 'filename'),
             'uuid': get_element_value(print_node, 'uuid'),
             'duration': long(get_element_value(print_node, 'duration'))}
            prints[id] = print_dict

    times = {}
    for valid_times_node in dom.getElementsByTagName('valid_times'):
        for time_node in valid_times_node.getElementsByTagName('time_no'):
            id = time_node.attributes['time_id'].value
            start = get_element_value(time_node, 'start_date')
            end = get_element_value(time_node, 'end_date')
            start = start.replace('00:00:00', '01:00:00')
            times[id] = {'start': datetime.datetime.strptime(start, '%d-%b-%Y  %I:%M:%S'),
             'end': datetime.datetime.strptime(end, '%d-%b-%Y  %I:%M:%S')}

    playlists = {}
    missing_prints = []
    for preshow_node in dom.getElementsByTagName('preshow'):
        for playlist_node in preshow_node.getElementsByTagName('playlist'):
            show_attribute = get_element_value(playlist_node, 'movie_dimension')
            show_time = times[get_element_value(playlist_node, 'time_id')]
            title = titles[get_element_value(playlist_node, 'movie_id')]
            current_placeholder = None
            pack_count = 1
            pack = _create_vm_pack_defaults(show_time, title, show_attribute, pack_count)
            show_sequence_node = playlist_node.getElementsByTagName('show_sequence')[0]
            for item_node in show_sequence_node.getElementsByTagName('item'):
                placeholder = get_element_value(item_node, 'placeholder_id')
                if placeholder != None:
                    if current_placeholder == None or current_placeholder != placeholder:
                        if len(pack['clips']) > 0:
                            output.append(pack)
                            pack_count = pack_count + 1
                            pack = _create_vm_pack_defaults(show_time, title, show_attribute, pack_count)
                        current_placeholder = placeholder
                else:
                    print_id = get_element_value(item_node, 'print_id')
                    if prints.has_key(print_id):
                        prnt = prints[print_id]
                        item = {}
                        item['type'] = 'composition'
                        item['content_kind'] = 'advertisement'
                        item['edit_rate'] = [24, 1]
                        item['text'] = prnt['content_title_text']
                        item['cpl_id'] = prnt['uuid']
                        item['duration_in_seconds'] = prnt['duration']
                        pack['clips'].append(item)
                    else:
                        try:
                            missing_prints.index(print_id)
                        except ValueError:
                            missing_prints.append(print_id)

    return output


def parse_pos(pos_string, pos_device_id, filename = '', default_session_length = DEFAULT_POS_SESSION_LENGTH):
    pos_preview = pos_string[0:350].lower() if len(pos_string) > 350 else pos_string.lower()
    sessions = None
    if 'aampos' in pos_preview:
        sessions = parse_aam_xml_pos(pos_string)
    elif 'boxofc' in pos_preview:
        sessions = parse_radiant_pos(pos_string)
    elif 'tms_export' in pos_preview:
        sessions = parse_dolphin_pos(pos_string, pos_device_id, default_session_length)
    elif filename.lower().endswith('iff') and pos_preview[0] == 'h':
        sessions = parse_diamond_pos(pos_string)
    elif filename.lower().endswith('csv') and pos_preview[1] == 'h':
        sessions = parse_ticketsoft_csv_pos(pos_string)
    elif 'pubdate' in pos_preview:
        sessions = parse_markus_pos(pos_string)
    elif 'circuit' in pos_preview and 'cinemas' in pos_preview:
        sessions = parse_merlin_pos(pos_string)
    elif 'eventgroup' in pos_preview:
        sessions = parse_newman_pos(pos_string, default_session_length)
    elif 'cinema_server' in pos_preview and 'screen_bytnum' in pos_preview:
        sessions = parse_aam_pos(pos_string)
    elif filename.lower().endswith('xml') and 'schedule' in pos_preview and 'show' in pos_preview:
        sessions = parse_admit_one_pos(pos_string, default_session_length)
    elif 'showtime' in pos_preview and 'movie' in pos_preview:
        sessions = parse_dx_pos(pos_string)
    elif 'eventlist' in pos_preview and 'organizers' in pos_preview:
        sessions = parse_ebillet_pos(pos_string)
    elif 'filmprogram' in pos_preview:
        sessions = parse_one_step_ahead_pos(pos_string, pos_device_id)
    elif 'data' in pos_preview or 'messages' in pos_preview:
        sessions = parse_aam_json_pos(pos_string)
    if sessions:
        return sanitise_pos(sessions)
    else:
        return sessions


def sanitise_pos(sessions):
    """
    Deal with non-ASCII chars that we are likely to get when integrating with third party systems/feeds
    """
    for session in sessions:
        for key in ['feature_title',
         'complex_identifier',
         'session_attributes',
         'screen_identifier']:
            val = session.get(key)
            if type(val) is str:
                session[key] = unicode(val, 'utf8')

    return sessions


def parse_aam_pos(pos_string):
    sessions = []
    for line in pos_string.split('\n'):
        session_row = [ n for n in line.split('\t') ]
        if len(session_row) != 11 or session_row[0] == 'ID':
            continue
        session = {}
        session['id'] = session_row[0]
        session['feature_title'] = session_row[4]
        session['start'] = datetime.datetime.strptime(session_row[5], '%Y-%m-%d %H:%M:%S')
        session['screen_identifier'] = session_row[2]
        session['complex_identifier'] = session_row[1]
        session['feature_duration'] = str(int(session_row[7]) * 60)
        session['overall_duration'] = str(int(session_row[7]) * 60)
        session['end'] = session['start'] + datetime.timedelta(seconds=int(session['feature_duration']))
        session['seats_available'] = session_row[9]
        session['seats_sold'] = session_row[8]
        sessions.append(session)

    return sessions


def parse_aam_json_pos(pos_string):
    sessions = []
    json_feed = json.loads(pos_string)['data']
    for week_number in json_feed:
        for device in json_feed[week_number]:
            for session_id, sess in json_feed[week_number][device].iteritems():
                session = {}
                for attribute in ['id',
                 'screen_identifier',
                 'complex_identifier',
                 'feature_duration',
                 'overall_duration',
                 'seats_available',
                 'seats_sold']:
                    session[attribute] = sess.get(attribute)

                session['feature_title'] = sess['title']
                session['start'] = datetime.datetime.fromtimestamp(sess['source_start'])
                session['end'] = datetime.datetime.fromtimestamp(sess['end'])
                session['session_attributes'] = ','.join(sess['unmatched_show_attributes'].values())
                sessions.append(session)

    return sessions


def parse_aam_xml_pos(pos_string):

    def aam_xml_loop_function(event, element, loop_vars, **kwargs):
        if event == 'end':
            if element.tag.endswith('id'):
                loop_vars['session']['id'] = element.text
            elif element.tag.endswith('complex_identifier'):
                loop_vars['session']['complex_identifier'] = element.text
                loop_vars['complex_identifier_exists'] = True
            elif element.tag.endswith('screen_identifier'):
                loop_vars['session']['screen_identifier'] = element.text
                loop_vars['screen_identifier_exists'] = True
            elif element.tag.endswith('title'):
                loop_vars['session']['feature_title'] = element.text
                loop_vars['title_exists'] = True
            elif element.tag.endswith('start'):
                loop_vars['session']['start'] = datetime.datetime.strptime(element.text, '%Y%m%d%H%M')
                loop_vars['start_exists'] = True
            elif element.tag.endswith('end'):
                loop_vars['session']['end'] = datetime.datetime.strptime(element.text, '%Y%m%d%H%M')
            elif element.tag.endswith('feature_duration'):
                loop_vars['session']['feature_duration'] = element.text
                loop_vars['feature_duration_exists'] = True
            elif element.tag.endswith('print_number'):
                if element.text:
                    loop_vars['session']['print_number'] = element.text
            elif element.tag.endswith('seats_available'):
                if element.text:
                    loop_vars['session']['seats_available'] = element.text
            elif element.tag.endswith('seats_sold'):
                if element.text:
                    loop_vars['session']['seats_sold'] = element.text
            elif element.tag.endswith('session_attribute'):
                loop_vars['session'].setdefault('session_attributes', [])
                loop_vars['session']['session_attributes'].append(element.text)
            elif element.tag.endswith('session'):
                show_time = loop_vars['session']['end'] - loop_vars['session']['start']
                loop_vars['session']['overall_duration'] = (int(show_time.seconds / 60) + int(show_time.days * 24 * 60)) * 60
                if 'session_attributes' in loop_vars['session']:
                    loop_vars['session']['session_attributes'] = ','.join(loop_vars['session']['session_attributes'])
                loop_vars['sessions'].append(loop_vars['session'])
                loop_vars['session'] = {}
            elif element.tag.endswith('sessions'):
                if not loop_vars['complex_identifier_exists'] or not loop_vars['screen_identifier_exists'] or not loop_vars['title_exists'] or not loop_vars['start_exists'] or not loop_vars['feature_duration_exists']:
                    raise ValueError('POS entry is missing one of the required fields: Complex Identifier, Screen Identifier, Title, Start, or Feature Duration')
            element.clear()
        return loop_vars

    loop_vars = {'complex_identifier_exists': False,
     'screen_identifier_exists': False,
     'title_exists': False,
     'start_exists': False,
     'feature_duration_exists': False,
     'sessions': [],
     'session': {}}
    result = iterparse_xml(pos_string, aam_xml_loop_function, loop_vars)
    return result['sessions']


def parse_dolphin_pos(pos_string, pos_device_id, default_session_length = DEFAULT_POS_SESSION_LENGTH):

    def dolphin_loop_function(event, element, loop_vars, **kwargs):
        if event == 'end':
            if element.tag.endswith('ShowID'):
                loop_vars['session']['id'] = element.text
            elif element.tag.endswith('Name'):
                loop_vars['session']['feature_title'] = element.text
            elif element.tag.endswith('ShowTime'):
                loop_vars['session']['start'] = datetime.datetime.strptime(element.text, '%Y-%m-%d %H:%M')
                loop_vars['session']['end'] = loop_vars['session']['start'] + datetime.timedelta(seconds=default_session_length)
            elif element.tag.endswith('Screen'):
                loop_vars['session']['screen_identifier'] = element.text
            elif element.tag.endswith('Rating'):
                loop_vars['session']['rating'] = element.text
            elif element.tag.endswith('Version'):
                loop_vars['session']['session_attributes'] = element.text
            elif element.tag.endswith('Show'):
                loop_vars['session']['feature_duration'] = default_session_length
                loop_vars['session']['overall_duration'] = default_session_length
                loop_vars['session']['complex_identifier'] = pos_device_id
                loop_vars['sessions'].append(loop_vars['session'])
                loop_vars['session'] = {}
            element.clear()
        return loop_vars

    loop_vars = {'sessions': [],
     'session': {}}
    result = iterparse_xml(pos_string, dolphin_loop_function, loop_vars)
    return result['sessions']


def parse_dx_pos_legacy(pos_string):

    def dx_loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.endswith('showTimes'):
                loop_vars['cinema_id'] = element.get('cinemaId')
                loop_vars['movie_id'] = element.get('movieId')
                loop_vars['screen_id'] = element.get('screenId')
        elif event == 'end':
            if element.tag.endswith('screen'):
                screen_id = element.get('id')
                loop_vars['screens'][screen_id] = {'name': element.get('name'),
                 'capacity': element.get('noOfSeats')}
            elif element.tag.endswith('movieTitle'):
                loop_vars['movie_title'] = element.text
            elif element.tag.endswith('runTime'):
                loop_vars['run_time'] = element.text
            elif element.tag.endswith('rating'):
                loop_vars['rating'] = element.text
            elif element.tag.endswith('movie'):
                movie_id = element.get('id')
                loop_vars['movies'][movie_id] = {'movie_title': loop_vars['movie_title'],
                 'run_time': loop_vars['run_time'],
                 'rating': loop_vars['rating']}
                loop_vars['rating'] = None
            elif element.tag.endswith('showTime'):
                show_time_id = element.get('id')
                loop_vars['show_times'][show_time_id] = {'cinema_id': loop_vars['cinema_id'],
                 'movie_id': loop_vars['movie_id'],
                 'screen_id': loop_vars['screen_id'],
                 'no_seats': element.get('noSeats'),
                 'available_seats': element.get('availableSeats'),
                 'show_time': element.text}
            elif element.tag.endswith('featureFilmPlayList'):
                for show_time_id, show_time in loop_vars['show_times'].iteritems():
                    movie_id = show_time['movie_id']
                    screen_id = show_time['screen_id']
                    cinema_id = show_time['cinema_id']
                    session = {'id': show_time_id,
                     'feature_title': loop_vars['movies'][movie_id]['movie_title'],
                     'feature_id': show_time['movie_id'],
                     'rating': loop_vars['movies'][movie_id]['rating'],
                     'start': datetime.datetime.strptime(show_time['show_time'][0:19], '%Y-%m-%dT%H:%M:%S'),
                     'feature_duration': loop_vars['movies'][movie_id]['run_time'],
                     'overall_duration': loop_vars['movies'][movie_id]['run_time'],
                     'screen_identifier': loop_vars['screens'][screen_id]['name']}
                    session['end'] = session['start'] + datetime.timedelta(seconds=int(session['feature_duration']))
                    if cinema_id:
                        session['complex_identifier'] = cinema_id
                    if '3D' in session['feature_title'].upper():
                        session['session_attributes'] = '3D'
                    seats = show_time['no_seats'] if show_time['no_seats'] else loop_vars['screens'][screen_id]['capacity']
                    seats_available = show_time['available_seats']
                    if seats and seats_available:
                        session['seats_available'] = seats_available
                        session['seats_sold'] = int(seats) - int(seats_available)
                    loop_vars['sessions'].append(session)

            element.clear()
        return loop_vars

    loop_vars = {'rating': None,
     'screens': {},
     'movies': {},
     'show_times': {},
     'sessions': []}
    result = iterparse_xml(pos_string, dx_loop_function, loop_vars)
    return result['sessions']


def parse_dx_pos(pos_string, complex_id):

    def dx_loop_function(event, element, loop_vars, **kwargs):
        dt_format = '%Y-%m-%d %H:%M'
        if event == 'start':
            pass
        elif event == 'end':
            if element.tag.endswith('ShowID'):
                loop_vars['session']['id'] = element.text
            if element.tag.endswith('ScreenID'):
                loop_vars['session']['screen_identifier'] = element.text
            if element.tag.endswith('ShowDate'):
                loop_vars['show_date'] = element.text
            if element.tag.endswith('ShowTime'):
                loop_vars['show_time'] = element.text
            if element.tag.endswith('EndTime'):
                loop_vars['end_time'] = element.text
            if element.tag.endswith('MovieTitle'):
                loop_vars['session']['feature_title'] = element.text
            if element.tag.endswith('MovieID'):
                loop_vars['session']['feature_id'] = element.text
            if element.tag.endswith('Rating'):
                if element.text:
                    loop_vars['session']['rating'] = element.text.strip()
            if element.tag.endswith('Ledig'):
                loop_vars['session']['seats_available'] = int(element.text) if element.text is not None else None
            if element.tag.endswith('AntallSolgt'):
                loop_vars['session']['seats_sold'] = int(element.text) if element.text is not None else None
            elif element.tag.endswith('Show'):
                datetime_str_start = '%s %s' % (loop_vars['show_date'], loop_vars['show_time'])
                datetime_str_end = '%s %s' % (loop_vars['show_date'], loop_vars['end_time'])
                start_dt = datetime.datetime.strptime(datetime_str_start, dt_format)
                end_dt = datetime.datetime.strptime(datetime_str_end, dt_format)
                if end_dt < start_dt:
                    end_dt += timedelta(days=1)
                loop_vars['session']['start'] = start_dt
                loop_vars['session']['end'] = end_dt
                loop_vars['session']['overall_duration'] = (end_dt - start_dt).seconds
                session_attrs = []
                test_title = loop_vars['session']['feature_title'].upper()
                if '3D' in test_title:
                    session_attrs.append('3D')
                if 'HFR' in test_title:
                    session_attrs.append('HFR')
                if session_attrs:
                    loop_vars['session']['session_attributes'] = ','.join(session_attrs)
                loop_vars['session']['complex_identifier'] = complex_id
                loop_vars['sessions'].append(loop_vars['session'])
                loop_vars['session'] = {}
            element.clear()
        return loop_vars

    loop_vars = {'show_date': None,
     'show_time': None,
     'end_time': None,
     'session': {},
     'sessions': []}
    result = iterparse_xml(pos_string, dx_loop_function, loop_vars)
    return result['sessions']


def parse_markus_pos(pos_string):

    def markus_loop_function(event, element, loop_vars, **kwargs):
        if event == 'end':
            if element.tag.endswith('TheatreID'):
                loop_vars['session']['complex_identifier'] = element.text
            elif element.tag.endswith('ID') and not element.tag.endswith('EventID') and not element.tag.endswith('TheatreID') and not element.tag.endswith('TheatreAuditriumID'):
                loop_vars['session']['id'] = element.text
            elif element.tag.endswith('Title') and not element.tag.endswith('OriginalTitle'):
                loop_vars['session']['feature_title'] = element.text
            elif element.tag.endswith('Rating'):
                loop_vars['session']['rating'] = element.text
            elif element.tag.endswith('dttmShowStart'):
                loop_vars['session']['start'] = datetime.datetime.strptime(element.text, '%Y-%m-%dT%H:%M:%S')
            elif element.tag.endswith('dttmShowEnd'):
                loop_vars['session']['end'] = datetime.datetime.strptime(element.text, '%Y-%m-%dT%H:%M:%S')
            elif element.tag.endswith('LengthInMinutes'):
                loop_vars['session']['feature_duration'] = int(element.text) * 60
            elif element.tag.endswith('TheatreAuditorium'):
                loop_vars['session']['screen_identifier'] = element.text
            elif element.tag.endswith('TypePresentationMethod'):
                if element.text is not None:
                    loop_vars['session']['session_attributes'] = element.data
            elif element.tag.endswith('Show'):
                show_time = loop_vars['session']['end'] - loop_vars['session']['start']
                loop_vars['session']['overall_duration'] = (int(show_time.seconds / 60) + int(show_time.days * 24 * 60)) * 60
                loop_vars['sessions'].append(loop_vars['session'])
                loop_vars['session'] = {}
            element.clear()
        return loop_vars

    loop_vars = {'sessions': [],
     'session': {}}
    result = iterparse_xml(pos_string, markus_loop_function, loop_vars)
    return result['sessions']


def parse_merlin_pos(pos_string):

    def merlin_loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.endswith('cinema'):
                loop_vars['cinema'] = element.get('Cinema').replace(' ', '-').replace(',', '')
            elif element.tag.endswith('film'):
                loop_vars['title'] = element.get('Title')
                loop_vars['running_time'] = element.get('RunningTime')
        elif event == 'end':
            if element.tag.endswith('showing'):
                show_date = element.get('ShowDate')
                show_time = element.get('ShowTime')
                screen = element.get('Screen')
                if screen is not None:
                    session_attributes = []
                    if element.get('HearingLoop') == 'true':
                        session_attributes.append('HearingLoop')
                    if element.get('Subtitles') == 'true':
                        session_attributes.append('Subtitles')
                    if element.get('LuxuryScreen') == 'true':
                        session_attributes.append('LuxuryScreen')
                    if element.get('AdultOnly') == 'true':
                        session_attributes.append('AdultOnly')
                    complex_id = loop_vars['cinema']
                    feature_title = loop_vars['title']
                    session_start = datetime.datetime.strptime(show_date + 'T' + show_time, '%d.%m.%YT%H:%M')
                    overall_duration = loop_vars['running_time']
                    if complex_id:
                        session_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, str(complex_id + feature_title + str(session_start)).upper().encode('punycode')))
                    else:
                        session_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, str(feature_title + str(session_start)).upper().encode('punycode')))
                    session = {'id': session_id,
                     'feature_title': feature_title,
                     'start': session_start,
                     'end': session_start + datetime.timedelta(minutes=int(overall_duration)),
                     'feature_duration': int(overall_duration) * 60,
                     'overall_duration': int(overall_duration) * 60,
                     'screen_identifier': screen,
                     'session_attributes': ', '.join(session_attributes)}
                    if complex_id:
                        session['complex_identifier'] = complex_id
                    loop_vars['sessions'].append(session)
            element.clear()
        return loop_vars

    loop_vars = {'sessions': []}
    result = iterparse_xml(pos_string, merlin_loop_function, loop_vars)
    return result['sessions']


def parse_diamond_pos(pos_string):
    sessions = []
    complex_id = None
    for line in pos_string.split('\n'):
        if len(line) > 0:
            if line[0] == 'H':
                complex_id = str(line[94:104].strip())
            elif line[0] == 'D':
                session = {}
                session['feature_title'] = str(line[38:98].strip())
                session['rating'] = str(line[98:108].strip())
                session['screen_identifier'] = str(line[26:28].strip())
                session['feature_duration'] = int(line[108:112].strip())
                session['overall_duration'] = int(line[108:112].strip())
                session['start'] = datetime.datetime.strptime(str(line[11:26].strip()), '%Y-%m-%d%H:%M')
                session['end'] = session['start'] + datetime.timedelta(seconds=int(session['overall_duration']))
                session['id'] = str(uuid.uuid5(uuid.NAMESPACE_DNS, str((complex_id + session['feature_title'] + str(session['start'])).upper().encode('punycode'))))
                if complex_id:
                    session['complex_identifier'] = complex_id
                sessions.append(session)

    return sessions


def parse_ticketsoft_csv_pos(pos_data):
    """
    Parses the TicketSoft CSV POS format
    
    TODO: The way this is handled should be merged into the Diamond POS parser (which is tab-delimited)
    """
    pos_reader = csv.reader(StringIO(pos_data), delimiter=',', quotechar='"')
    sessions = []
    complex_id = None
    for row in pos_reader:
        if row[0] == 'H':
            complex_id = row[3]
        elif row[0] == 'D':
            session = {}
            session['feature_title'] = row[6]
            session['rating'] = row[7]
            session['screen_identifier'] = row[4]
            session['feature_duration'] = row[8]
            session['overall_duration'] = row[8]
            session['start'] = datetime.datetime.strptime(row[2] + row[3], '%Y-%m-%d%H:%M')
            session['end'] = session['start'] + datetime.timedelta(seconds=int(row[5]))
            session['id'] = str(uuid.uuid5(uuid.NAMESPACE_DNS, str((complex_id + session['feature_title'] + str(session['start'])).upper().encode('punycode'))))
            if complex_id:
                session['complex_identifier'] = complex_id
                sessions.append(session)

    return sessions


def parse_admit_one_pos(pos_string, default_session_length = DEFAULT_POS_SESSION_LENGTH):

    def admit_one_loop_function(event, element, loop_vars, **kwargs):
        if event == 'end':
            if element.tag.endswith('feature'):
                loop_vars['session']['feature_title'] = element.get('title')
                loop_vars['session']['feature_id'] = element.get('extId')
            elif element.tag.endswith('show'):
                loop_vars['session']['id'] = element.get('extId')
                loop_vars['session']['screen_identifier'] = element.get('screenId')
                loop_vars['session']['start'] = datetime.datetime.strptime(element.get('time')[0:19], '%Y-%m-%dT%H:%M:%S') + datetime.timedelta(days=20)
                loop_vars['session']['end'] = loop_vars['session']['start'] + datetime.timedelta(seconds=default_session_length)
                loop_vars['session']['feature_duration'] = default_session_length
                loop_vars['session']['overall_duration'] = default_session_length
                uppercase_title = loop_vars['session']['feature_title']
                if '3D' in uppercase_title or '3-D' in uppercase_title:
                    loop_vars['session']['session_attributes'] = '3D'
                loop_vars['sessions'].append(loop_vars['session'])
                loop_vars['session'] = {}
            element.clear()
        return loop_vars

    loop_vars = {'sessions': [],
     'session': {}}
    result = iterparse_xml(pos_string, admit_one_loop_function, loop_vars)
    return result['sessions']


def parse_radiant_pos(pos_string):

    def radiant_loop_function(event, element, loop_vars, **kwargs):
        if event == 'end':
            if element.tag.endswith('SiteInfo'):
                loop_vars['complex_id'] = element.get('site_name')
            elif element.tag.endswith('Auditorium'):
                index = element.get('auditorium_index')
                name = element.get('name')
                loop_vars['auditoriums'][index] = name
            elif element.tag.endswith('FeatureRating'):
                feature_rating_id = element.get('feature_rating_id')
                feature_rating_code = element.get('feature_rating_code')
                loop_vars['feature_ratings'][feature_rating_id] = feature_rating_code
            elif element.tag.endswith('Feature'):
                feature_code = element.get('feature_code')
                loop_vars['features'][feature_code] = {'feature_name': element.get('feature_name'),
                 'film_length_minutes': element.get('film_length_minutes'),
                 'feature_rating_id': element.get('feature_rating_id')}
            elif element.tag.endswith('Performance'):
                performance = {'id': element.get('performance_id'),
                 'business_date': element.get('business_date'),
                 'show_datetime': element.get('show_datetime'),
                 'auditorium_index': element.get('auditorium_index'),
                 'feature_code': element.get('feature_code')}
                loop_vars['performances'].append(performance)
            elif element.tag.endswith('BoxOfc'):
                loop_vars['sessions'] = []
                for performance in loop_vars['performances']:
                    auditorium_name = loop_vars['auditoriums'][performance['auditorium_index']]
                    feature = loop_vars['features'][performance['feature_code']]
                    feature_rating = loop_vars['feature_ratings'][feature['feature_rating_id']]
                    session = {'id': performance['id'],
                     'screen_identifier': auditorium_name.replace('Aud', '').replace(' ', ''),
                     'feature_title': feature['feature_name'],
                     'feature_id': performance['feature_code'],
                     'feature_duration': int(feature['film_length_minutes']) * 60,
                     'overall_duration': int(feature['film_length_minutes']) * 60,
                     'rating': feature_rating.strip()}
                    hour = int(performance['show_datetime'][0:2])
                    if hour > 23:
                        hour = str(hour - 24)
                        if len(hour) == 1:
                            hour = '0' + hour
                        performance['show_datetime'] = hour + performance['show_datetime'][2:4]
                    session['start'] = datetime.datetime.strptime(performance['business_date'] + performance['show_datetime'], '%m%d%Y%H%M')
                    session['end'] = session['start'] + datetime.timedelta(seconds=int(session['overall_duration']))
                    if loop_vars['complex_id'] is not None:
                        session['complex_identifier'] = loop_vars['complex_id'].replace(' ', '-')
                    loop_vars['sessions'].append(session)

            element.clear()
        return loop_vars

    loop_vars = {'performances': [],
     'auditoriums': {},
     'feature_ratings': {},
     'features': {}}
    result = iterparse_xml(pos_string, radiant_loop_function, loop_vars)
    return result['sessions']


def parse_newman_pos(pos_string, default_session_length = DEFAULT_POS_SESSION_LENGTH):

    def newman_loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.endswith('eventgroup'):
                loop_vars['in_eventgroup'] = True
                loop_vars['session_attributes'] = []
            elif element.tag.endswith('contents'):
                loop_vars['in_eventgroup'] = False
                loop_vars['in_content'] = True
            elif element.tag.endswith('features'):
                loop_vars['in_content'] = False
                loop_vars['in_feature'] = True
            elif element.tag.endswith('venues'):
                loop_vars['in_feature'] = False
                loop_vars['in_venue'] = True
            elif element.tag.endswith('screen'):
                loop_vars['in_venue'] = False
                loop_vars['in_screen'] = True
            elif element.tag.endswith('event'):
                loop_vars['in_screen'] = False
                loop_vars['in_event'] = True
        elif event == 'end':
            if loop_vars['in_eventgroup']:
                if element.tag.endswith('longname'):
                    loop_vars['feature_title'] = element.text
                elif element.tag.endswith('certificate'):
                    loop_vars['rating'] = element.text
            elif loop_vars['in_content']:
                if element.tag.endswith('id'):
                    loop_vars['feature_id'] = element.text
                elif element.tag.endswith('content_type'):
                    loop_vars['session_attributes'].append(element.text)
                elif element.tag.endswith('dubbed') and element.text == 'True':
                    loop_vars['session_attributes'].append('dubbed')
                elif element.tag.endswith('subtitled') and element.text == 'True':
                    loop_vars['session_attributes'].append('subtitled')
            elif loop_vars['in_feature']:
                if element.tag.endswith('name'):
                    loop_vars['session_attributes'].append(element.text)
            elif loop_vars['in_venue']:
                if element.tag.endswith('id'):
                    loop_vars['complex_identifier'] = element.text
            elif loop_vars['in_screen']:
                if element.tag.endswith('longname'):
                    loop_vars['screen_identifier'] = element.text
            elif loop_vars['in_event']:
                if element.tag.endswith('id'):
                    loop_vars['event_id'] = element.text
                elif element.tag.endswith('datetime'):
                    loop_vars['start'] = datetime.datetime.strptime(element.text, '%Y-%m-%dT%H:%M:%S')
                elif element.tag.endswith('event'):
                    loop_vars['events'].append({'id': loop_vars['event_id'],
                     'start': loop_vars['start']})
                    loop_vars['event_id'] = loop_vars['start'] = None
                    loop_vars['in_event'] = False
            elif element.tag.endswith('events'):
                for event in loop_vars['events']:
                    session = {'id': event['id'],
                     'start': event['start'],
                     'complex_identifier': loop_vars['complex_identifier'],
                     'feature_title': loop_vars['feature_title'],
                     'feature_id': loop_vars['feature_id'],
                     'rating': loop_vars['rating'],
                     'screen_identifier': loop_vars['screen_identifier'],
                     'session_attributes': ','.join(loop_vars['session_attributes']),
                     'overall_duration': default_session_length,
                     'feature_duration': default_session_length,
                     'end': event['start'] + datetime.timedelta(seconds=default_session_length)}
                    loop_vars['sessions'].append(session)
                    session = {}
                    loop_vars['events'] = []

            elif element.tag.endswith('eventgroup'):
                loop_vars['complex_identifier'] = None
                loop_vars['feature_title'] = None
                loop_vars['feature_id'] = None
                loop_vars['rating'] = None
                loop_vars['screen_identifier'] = None
                loop_vars['event_id'] = None
                loop_vars['start'] = None
            element.clear()
        return loop_vars

    loop_vars = {'in_eventgroup': False,
     'in_content': False,
     'in_feature': False,
     'in_venue': False,
     'in_screen': False,
     'in_event': False,
     'sessions': [],
     'events': [],
     'complex_identifier': None,
     'feature_title': None,
     'feature_id': None,
     'rating': None,
     'screen_identifier': None,
     'session_attributes': [],
     'event_id': None,
     'start': None}
    result = iterparse_xml(pos_string, newman_loop_function, loop_vars)
    return result['sessions']


def parse_ebillet_feed_pos(pos_string):

    def ebillet_feed_loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.endswith('showTimes'):
                loop_vars['cinema_id'] = element.get('cinemaId')
                loop_vars['movie_id'] = element.get('movieId')
                loop_vars['screen_id'] = element.get('screenId')
        elif event == 'end':
            if element.tag.endswith('screen'):
                screen_id = element.get('id')
                loop_vars['screens'][screen_id] = {'name': element.get('name'),
                 'capacity': element.get('noOfSeats')}
            elif element.tag.endswith('movieTitle'):
                loop_vars['movie_title'] = element.text
            elif element.tag.endswith('runTime'):
                loop_vars['run_time'] = element.text
            elif element.tag.endswith('rating'):
                loop_vars['rating'] = element.text
            elif element.tag.endswith('movie'):
                movie_id = element.get('id')
                loop_vars['movies'][movie_id] = {'movie_title': loop_vars['movie_title'],
                 'run_time': loop_vars['run_time']}
            elif element.tag.endswith('showTime'):
                show_time = {'cinema_id': loop_vars['cinema_id'],
                 'movie_id': loop_vars['movie_id'],
                 'screen_id': loop_vars['screen_id'],
                 'show_time': element.text}
                loop_vars['show_times'].append(show_time)
            elif element.tag.endswith('featureFilmPlayList'):
                for show_time in loop_vars['show_times']:
                    movie_id = show_time['movie_id']
                    screen_id = show_time['screen_id']
                    cinema_id = show_time['cinema_id']
                    movie = loop_vars['movies'][movie_id]
                    session = {'feature_title': loop_vars['movies'][movie_id]['movie_title'],
                     'start': datetime.datetime.strptime(show_time['show_time'][0:19], '%Y-%m-%dT%H:%M:%S'),
                     'feature_duration': int(loop_vars['movies'][movie_id]['run_time']),
                     'overall_duration': int(loop_vars['movies'][movie_id]['run_time']),
                     'screen_identifier': loop_vars['screens'][screen_id]['name'],
                     'complex_identifier': cinema_id}
                    session['id'] = str(uuid.uuid5(uuid.NAMESPACE_DNS, str((cinema_id + movie['movie_title'] + str(session['start'])).upper().encode('punycode'))))
                    session['end'] = session['start'] + datetime.timedelta(seconds=int(session['feature_duration']))
                    loop_vars['sessions'].append(session)

            element.clear()
        return loop_vars

    loop_vars = {'screens': {},
     'movies': {},
     'show_times': [],
     'sessions': []}
    result = iterparse_xml(pos_string, ebillet_feed_loop_function, loop_vars)
    return result['sessions']


def parse_ebillet_pos(pos_string):

    def ebillet_loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.endswith('Location'):
                loop_vars['in_auditorium'] = True
            elif element.tag.endswith('Movie'):
                loop_vars['in_feature'] = True
            elif element.tag.endswith('Event'):
                loop_vars['in_event'] = True
            elif element.tag.endswith('EventType'):
                loop_vars['in_eventtype'] = True
            elif element.tag.endswith('Subjects'):
                for id, event in loop_vars['events'].iteritems():
                    auditorium = loop_vars['auditoria'].get(event['complex_identifier'], {}).get(event['location_no'], {})
                    feature = loop_vars['features'].get(event['movie_no'], {})
                    if auditorium and feature:
                        session = {'id': id,
                         'complex_identifier': event['complex_identifier'],
                         'screen_identifier': auditorium['name'],
                         'feature_title': feature['name'],
                         'feature_duration': feature['duration'],
                         'overall_duration': event['overall_duration'],
                         'start': event['start'],
                         'end': event['start'] + datetime.timedelta(seconds=int(event['overall_duration'])),
                         'seats_available': event['seats_available'],
                         'seats_sold': str(int(auditorium['seats']) - int(event['seats_available'])),
                         'session_attributes': loop_vars['eventtypes'].get(event['event_type_no'])}
                        loop_vars['sessions'].append(session)

        elif event == 'end':
            if loop_vars['in_auditorium']:
                if element.tag.endswith('Name') and not element.tag.endswith('SubName'):
                    loop_vars['auditorium']['auditorium_name'] = element.text
                elif element.tag.endswith('Seats'):
                    loop_vars['auditorium']['auditorium_seats'] = element.get('TotalCount')
                elif element.tag.endswith('Location'):
                    complex_id = element.get('OrganizerNo')
                    auditorium_id = element.get('No')
                    if not loop_vars['auditoria'].has_key(complex_id):
                        loop_vars['auditoria'][complex_id] = {}
                    loop_vars['auditoria'][complex_id][auditorium_id] = {'name': loop_vars['auditorium']['auditorium_name'],
                     'seats': loop_vars['auditorium']['auditorium_seats']}
                    loop_vars['auditorium'] = {}
                    loop_vars['in_auditorium'] = False
            elif loop_vars['in_feature']:
                if element.tag.endswith('Name') and not element.tag.endswith('SubName') and not element.tag.endswith('OriginalName'):
                    loop_vars['feature']['name'] = element.text
                elif element.tag.endswith('Length'):
                    loop_vars['feature']['duration'] = element.get('Seconds')
                elif element.tag.endswith('Movie'):
                    id = element.get('No')
                    loop_vars['features'][id] = {'name': loop_vars['feature']['name'],
                     'duration': loop_vars['feature']['duration'],
                     'id': id}
                    loop_vars['feature'] = {}
                    loop_vars['in_feature'] = False
            elif loop_vars['in_event']:
                if element.tag.endswith('DateTime'):
                    loop_vars['event']['start'] = datetime.datetime.strptime(element.text[0:19], '%Y-%m-%dT%H:%M:%S')
                elif element.tag.endswith('Duration'):
                    loop_vars['event']['overall_duration'] = element.get('Total')
                elif element.tag.endswith('Seats'):
                    loop_vars['event']['seats_available'] = element.get('FreeCount')
                elif element.tag.endswith('Event'):
                    id = element.get('No')
                    loop_vars['events'][id] = {'complex_identifier': element.get('OrganizerNo'),
                     'location_no': element.get('LocationNo'),
                     'movie_no': element.get('MovieNo'),
                     'event_type_no': element.get('EventTypeNo'),
                     'start': loop_vars['event']['start'],
                     'overall_duration': loop_vars['event']['overall_duration'],
                     'seats_available': loop_vars['event']['seats_available']}
                    loop_vars['event'] = {}
                    loop_vars['in_event'] = False
            elif loop_vars['in_eventtype']:
                if element.tag.endswith('Name'):
                    loop_vars['eventtype']['name'] = element.text
                elif element.tag.endswith('EventType'):
                    id = element.get('No')
                    loop_vars['eventtypes'][id] = loop_vars['eventtype']['name']
                    loop_vars['eventtype'] = {}
                    loop_vars['in_eventtype'] = False
            element.clear()
        return loop_vars

    loop_vars = {'in_auditorium': False,
     'in_feature': False,
     'in_event': False,
     'in_eventtype': False,
     'auditoria': {},
     'auditorium': {},
     'features': {},
     'feature': {},
     'events': {},
     'event': {},
     'eventtypes': {},
     'eventtype': {},
     'sessions': []}
    result = iterparse_xml(pos_string, ebillet_loop_function, loop_vars)
    return result['sessions']


def parse_one_step_ahead_pos(pos_string, pos_device_id):

    def one_step_ahead_loop_function(event, element, loop_vars, **kwargs):
        if event == 'start' and element.tag.endswith('forestilling'):
            loop_vars['in_forestilling'] = True
        elif event == 'end':
            if loop_vars['in_forestilling']:
                if element.tag.endswith('forestillingid'):
                    loop_vars['session']['id'] = element.text
                elif element.tag.endswith('sluttidspunkt'):
                    loop_vars['session']['end'] = datetime.datetime.strptime(element.text[0:16], '%d-%m-%Y %H:%M')
                elif element.tag.endswith('tidspunkt'):
                    loop_vars['session']['start'] = datetime.datetime.strptime(element.text[0:16], '%Y-%m-%d %H:%M')
                elif element.tag.endswith('sal'):
                    loop_vars['session']['screen_identifier'] = element.text
                elif element.tag.endswith('ledigepladser'):
                    loop_vars['session']['seats_available'] = element.text
                elif element.tag.endswith('forestilling'):
                    loop_vars['in_forestilling'] = False
                    loop_vars['session']['feature_duration'] = str((loop_vars['session']['end'] - loop_vars['session']['start']).seconds)
                    loop_vars['session']['overall_duration'] = loop_vars['session']['feature_duration']
                    loop_vars['session']['feature_title'] = loop_vars['titel']
                    loop_vars['session']['feature_id'] = loop_vars['filmid']
                    loop_vars['session']['complex_identifier'] = pos_device_id
                    loop_vars['sessions'].append(loop_vars['session'])
                    loop_vars['session'] = {}
            elif element.tag.endswith('filmid'):
                loop_vars['filmid'] = element.text
            elif element.tag.endswith('titel') and not element.tag.endswith('orgtitel'):
                loop_vars['titel'] = element.text
            element.clear()
        return loop_vars

    loop_vars = {'in_forestilling': False,
     'sessions': [],
     'session': {}}
    result = iterparse_xml(pos_string, one_step_ahead_loop_function, loop_vars)
    return result['sessions']


def parse_aamulator_pos(sessions):
    for session in sessions:
        session['overall_duration'] = session['end'] - session['start']
        session['feature_duration'] = session['overall_duration']
        session['start'] = datetime.datetime.fromtimestamp(session['start'])
        session['end'] = datetime.datetime.fromtimestamp(session['end'])
        session['session_attributes'] = session['attributes']

    return sessions
# okay decompyling ./lib/dcinema/parsers/parsers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:58 CST
