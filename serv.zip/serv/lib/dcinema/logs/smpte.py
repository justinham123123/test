# 2017.08.13 21:51:52 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\logs\smpte.py
"""
SMPTE secure log parsing functionality

Previous formulations of this class used an xml.dom.minidom parser rather than ElementTree,
but the DOM parser was found to have severe memory issues for large log files (peaking at
750MB memory for a 15MB log - the most a Doremi will return in one request).
"""
from serv.lib.utilities.xml_utils import iterparse_xml
from serv.lib.utilities.date_utils import parse_date
VALID_EVENTS = {'CPLEnd': 0,
 'CPLStart': 1}

class SMPTELog(object):
    """
    A SMPTE Log manager for accessing data
    stored in a SMPTE 430-4-2008 formatted log
    """

    def __init__(self, xml):

        def loop_function(event, element, loop_vars, **kwargs):
            if event == 'start' and element.tag.endswith('LogRecordElement'):
                loop_vars['in_log_event'] = True
                loop_vars['log_event'] = {}
            elif event == 'end':
                if 'thumbprint' not in loop_vars and element.tag.endswith(('DeviceIdentifier', 'PrimaryID')):
                    loop_vars['thumbprint'] = element.text
                elif 'serial' not in loop_vars and element.tag.endswith('DeviceSerial'):
                    loop_vars['serial'] = element.text
                elif element.tag.endswith('LogRecordSignature'):
                    loop_vars['is_signed'] = True
                if loop_vars['in_log_event']:
                    log_event = loop_vars['log_event']
                    if element.tag.endswith('EventSubType'):
                        if element.text in VALID_EVENTS:
                            log_event['subtype'] = element.text
                        else:
                            loop_vars['in_log_event'] = False
                    elif element.tag.endswith('TimeStamp'):
                        log_event['timestamp'] = parse_date(element.text, default_to_local_time=False)
                    elif element.tag.endswith('contentId'):
                        log_event['cpl_uuid'] = element.text.replace('urn:uuid:', '')
                    elif element.tag.endswith('LogRecordElement'):
                        if 'timestamp' in log_event and 'cpl_uuid' in log_event:
                            loop_vars['events'].append(log_event)
                        element.clear()
                        loop_vars['in_log_event'] = False
                else:
                    element.clear()
            return loop_vars

        initial_vars = {'in_log_event': False,
         'events': []}
        parsed_log = iterparse_xml(xml, loop_function, initial_vars)
        self.thumbprint = parsed_log.get('thumbprint', '')
        self.serial = parsed_log.get('serial', '')
        self.is_signed = parsed_log.get('is_signed', False)
        self.warnings = []
        self.raw_warnings = []
        if 'error_message' in parsed_log:
            self.warnings.append('encountered invalid xml')
            self.raw_warnings.append(parsed_log['error_message'])
        if self.bad_order(parsed_log['events']):
            self.warnings.append('had to pre-force events into order')
            parsed_log['events'] = self.reorder_events(parsed_log['events'])
        self.playouts, errors = self.process_smpte_playout_events(parsed_log['events'])
        if errors:
            self.warnings.append('encountered unexpected events')

    def bad_order(self, events):
        curr_time = 0
        for event in events:
            if event['timestamp'] < curr_time:
                return True
            curr_time = event['timestamp']

        return False

    def reorder_events(self, events):
        """
        Reorders events by timestamp and events that happen on
        the same timestamp are in an order that the fsm expects:
        
        CPLEnd < CPLStart
        
        Only used as a last resort when the native timestamp ordering is wrong, since the above event order can't always be trusted.
        
        """
        events.sort(key=lambda e: (e['timestamp'], VALID_EVENTS[e['subtype']]))
        return events

    def process_smpte_playout_events(self, events):
        """
        Processes and combines sorted list of SMPTE playout events
        into logical playout events. Modelled on a finite state
        machine for SMPTE playout events.
        """
        NOT_PLAYING, PLAYING = range(2)
        playouts = []
        error = False
        state = NOT_PLAYING
        for smpte_e in events:
            transition = smpte_e['subtype']
            if state == NOT_PLAYING:
                if transition == 'CPLStart':
                    state = PLAYING
                    playouts.append({'cpl_uuid': smpte_e['cpl_uuid'],
                     'start_timestamp': smpte_e['timestamp']})
                else:
                    state = NOT_PLAYING
                    playouts.append({'cpl_uuid': smpte_e['cpl_uuid'],
                     'end_timestamp': smpte_e['timestamp']})
            elif state == PLAYING:
                if transition == 'CPLEnd':
                    state = NOT_PLAYING
                    if playouts[-1]['cpl_uuid'] == smpte_e['cpl_uuid']:
                        playouts[-1]['end_timestamp'] = smpte_e['timestamp']
                    else:
                        error = True
                        playouts.append({'cpl_uuid': smpte_e['cpl_uuid'],
                         'end_timestamp': smpte_e['timestamp']})
                else:
                    state = PLAYING
                    playouts.append({'cpl_uuid': smpte_e['cpl_uuid'],
                     'start_timestamp': smpte_e['timestamp']})

        return (playouts, error)


if __name__ == '__main__':
    import sys
    with open(sys.argv[1], 'r') as f:
        parsed_log = SMPTELog(f.read())
        print 'Raw errors:'
        print parsed_log.raw_warnings
        print 'Warnings:'
        print parsed_log.warnings
        print 'Playouts:'
        for pl in parsed_log.playouts:
            print pl
# okay decompyling ./lib/dcinema/logs/smpte.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:52 CST
