# 2017.08.13 21:51:44 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\ftp_wrapper.py
"""
(c) 2011 - Arts Alliance Media
Enhanced FTP functionality

An enhanced FTP class that adds recursive directory walking and
more robust file size and existence checking.
    
Adapted from http://code.activestate.com/recipes/275594/

@author: Matt Sullivan
"""
import re
import logging
import ftplib
import socket
import posixpath
import pdb
from contextlib import contextmanager
from threading import RLock

def parse_windows(dirlines):
    """
    Parse the lines returned by ftplib.FTP.dir(), when called
    on a Windows ftp server. May not work for all servers.
    """
    fields = 'dates times trycwds sizes names'.split()
    typemap = {'<DIR>': True}
    if not dirlines:
        return dict(zip(fields, [[]] * len(fields)))
    maxlen = max((len(line) for line in dirlines))
    columns = [slice(0, 9),
     slice(9, 17),
     slice(17, 29),
     slice(29, 38),
     slice(38, maxlen + 1)]
    values = []
    for line in dirlines:
        vals = [ line[slc].strip() for slc in columns ]
        vals[2] = typemap.get(vals[2], False)
        values.append(vals)

    lists = zip(*values)
    raise len(lists) == len(fields) or AssertionError
    return dict(zip(fields, lists))


def parse_unix(dirlines, startindex = 0):
    """
    Parse the lines returned by ftplib.FTP.dir(), when called
    on a UNIX ftp server. May not work for all servers.
    """
    fields = 'trycwds tryretrs inodes users groups sizes dates names'.split()
    dirlines = dirlines[startindex:]
    if not dirlines:
        return dict(zip(fields, [[]] * len(fields)))
    pattern = re.compile('(.)(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?\\s+.*?\\s+.*?)\\s+(.*)', re.UNICODE)
    getmatches = lambda s: pattern.search(s)
    matches = filter(getmatches, dirlines)
    getfields = lambda s: pattern.findall(s)[0]
    lists = zip(*map(getfields, matches))
    lists[0] = [ 'd' == s for s in lists[0] ]
    raise len(lists) == len(fields) or AssertionError
    return dict(zip(fields, lists))


class EnhancedFTP(object):
    """
    Class adding recursive nlst() behavior to ftplib.FTP instance. The
    ftplib.FTP instance is available through the connection attribute, and
    is exposed through __getattr__.
    
    The behavior added by this class (recursive directory listing) is most
    appropriate for ftp connections on a local network over a fast connection, 
    or for small directories on remote ftp servers.
    
    The class relies on an externally defined callable, which can parse the
    lines returned by the ftplib.FTP.dir() method. This callable should be 
    bound to the 'dirparser' attribute on this object. The callable 'dirparser' 
    attribute can be initialized by passing it in to the constructor using the
    keyword argument 'dirparser', or by attaching the callable to the
    'dirparser' attribute after instantiation. 
    
    The callable should return parsed results as a dict. This class makes some
    assumptions about the contents of the dict returned by the user-defined 
    dirparser callable:
    
    -- the key 'trycwds' holds a list of booleans 
    
    -- the key 'names' holds a list of filenames in the dir() listing.
    
    -- The two lists should be the same length. A True value in the list
    referred to by the 'trycwds' key indicates the corresponding value
    in the list referred to by the 'names' key is a directory.
    
    -- The key names are based on fields in the ftpparse structure, from the   
    ftpparse module/C library.     
    
    -- Other keys can be included in the dict, but they are not used by the 
    rnlst() method.
    
    -- The callable should return an empty dict() if there is nothing to return
    from the dir listing.
    
    This module provides two parsers which seem to work ok, but it should
    be easy to create others if these don't work for some reason:
    
    -- parse_windows parses the dir listing from Windows ftp servers.
    -- parse_unix parses the dir listing from UNIX ftp servers.
    """

    def __init__(self, host = '', user = '', passwd = '', port = 21, dirparser = parse_unix, encoding = 'utf_8'):
        """
        Initialises the FTP client by wrapping ftplib.FTP
        Saves the connection details so it can reconnect if necessary
        """
        self.host = host.encode(encoding) if isinstance(host, basestring) else host
        self.port = port
        self.user = user
        self.passwd = passwd
        self.connection = ftplib.FTP()
        self.dirparser = dirparser
        self._connect_and_login()
        self.remotepathsep = posixpath.sep
        self.encoding = encoding
        self.cwd_lock = RLock()
        self.connection.set_pasv(False)
        logging.debug('FTP connection created for %s with user %s and password %s' % (host, user, passwd))

    def _connect_and_login(self):
        """
        (Re)Connects to an FTP site and logs in
        """
        connection = self.connection.connect(self.host, self.port)
        if 'Microsoft' in connection:
            self.dirparser = parse_windows
        self.connection.login(self.user, self.passwd)

    @contextmanager
    def __convert_path(self, path):
        """
        A context manager that temporarily changes the cwd to the dir one level below the full path
        This is used to work around dodgy FTP servers that won't retr files with spaces in the path
        """
        self.cwd_lock.acquire()
        path_head, path_tail = posixpath.split(path)
        cwd = self.connection.pwd()
        if cwd != path_head:
            self.connection.cwd(path_head.encode(self.encoding))
            yield path_tail
            self.connection.cwd(cwd)
        else:
            yield path_tail
        self.cwd_lock.release()

    def __getattr__(self, name):
        """
        Delegate most requests to the underlying FTP object. 
        """
        return getattr(self.connection, name)

    def _dir(self, path):
        """
        Call dir() on path, and use callback to accumulate
        returned lines. Return list of lines.
        """
        dir_list = []
        path = self._cleanpath(path)
        path_as_dir = posixpath.join(path, '.')
        try:
            try:
                with self.__convert_path(path_as_dir) as converted_path:
                    self.connection.dir(converted_path.encode(self.encoding), lambda x: dir_list.append(x.decode(self.encoding)))
            except ftplib.error_perm as ex:
                if ex.args[0].startswith('550'):
                    with self.__convert_path(path) as converted_path:
                        self.connection.dir(converted_path.encode(self.encoding), lambda x: dir_list.append(x.decode(self.encoding)))
                else:
                    raise ex

        except ftplib.error_perm:
            logging.info('Access denied for path %s' % path)
        except ftplib.error_temp:
            logging.info('No such file or directory exists: %s' % path)
        except socket.error:
            logging.info('Connection reset by peer for path %s' % path)
            self._connect_and_login()

        return dir_list

    def dir(self, path, callback):
        """
        Provides safe access to the underlying dir() function from ftplib.
        """
        path = posixpath.join(path, '.')
        with self.__convert_path(path) as converted_path:
            self.connection.dir(converted_path.encode(self.encoding), lambda x: callback(x.decode(self.encoding)))

    def parsedir(self, path = ''):
        """
        Method to parse the lines returned by the ftplib.FTP.dir(),
        when called on supplied path. Uses callable dirparser
        attribute. 
        """
        if self.dirparser is None:
            msg = 'Must set dirparser attribute to a callable before calling this method'
            raise TypeError(msg)
        dirlines = self._dir(path)
        dirdict = self.dirparser(dirlines)
        return dirdict

    def _cleanpath(self, path):
        """
        Clean up path - remove repeated and trailing separators. 
        """
        slashes = self.remotepathsep * 2
        while slashes in path:
            path = path.replace(slashes, self.remotepathsep)

        if path.endswith(self.remotepathsep) and path != self.remotepathsep:
            path = path[:-1]
        return path

    def _rnlst(self, path, filelist):
        """
        Recursively accumulate filelist starting at
        path, on the server accessed through this object's
        ftp connection.
        """
        path = self._cleanpath(path)
        dirdict = self.parsedir(path)
        trycwds = dirdict.get('trycwds', [])
        names = dirdict.get('names', [])
        sizes = dirdict.get('sizes', [])
        for trycwd, name, size in zip(trycwds, names, sizes):
            if name not in ('.', '..'):
                if trycwd:
                    filelist.append({'path': self.remotepathsep.join([path, name])})
                    self._rnlst(self.remotepathsep.join([path, name]), filelist)
                else:
                    filelist.append({'name': name,
                     'dir': path,
                     'path': self.remotepathsep.join([path, name]),
                     'size': int(size)})

        return filelist

    def _walk(self, top, topdown = True, onerror = None):
        """
        Generator for walking FTP directories.
        
        Returns the same information as os.walk(dir)
        Serves as an alternative to _rnlst()
        """
        top = self._cleanpath(top)
        with self.__convert_path(top) as converted_path:
            dirdict = self.parsedir(converted_path)
        trycwds = dirdict.get('trycwds', [])
        names = dirdict.get('names', [])
        dirs, nondirs = [], []
        for is_dir, name in zip(trycwds, names):
            if name not in ('.', '..'):
                if is_dir:
                    dirs.append(name)
                else:
                    nondirs.append(name)

        if topdown:
            yield (top, dirs, nondirs)
        for name in dirs:
            path = self.remotepathsep.join([top, name])
            for x in self._walk(path, topdown, onerror):
                yield x

        if not topdown:
            yield (top, dirs, nondirs)

    def rnlst(self, path = ''):
        """
        Recursive nlst(). Return a list of filenames under path.
        """
        return self._rnlst(path, [])

    def walk(self, path = ''):
        """
        Walks through an FTP directory; like os.walk()
        """
        return self._walk(path)

    def exists(self, file_path):
        """
        Checks to see if a file or directory exists
        """
        file_path = self._cleanpath(file_path)
        if file_path == self.remotepathsep:
            return True
        parent_path, target_name = posixpath.split(file_path)
        try:
            parent_dict = self.parsedir(parent_path)
            if target_name in parent_dict['names']:
                return True
            return False
        except (ftplib.error_temp, ftplib.error_perm) as ex:
            if ex.args and ex.args[0].startswith('550'):
                return False
            raise ex

    def isdir(self, file_path):
        """
        Checks whether a path on the FTP server is a directory
        """
        file_path = self._cleanpath(file_path)
        if file_path == self.remotepathsep:
            return True
        parent_path, target_name = posixpath.split(file_path)
        try:
            parent_dict = self.parsedir(parent_path)
            for index, name in enumerate(parent_dict['names']):
                if name == target_name:
                    return parent_dict['trycwds'][index]
            else:
                return False

        except (ftplib.error_temp, ftplib.error_perm) as ex:
            if ex.args and ex.args[0].startswith('550'):
                return False
            raise ex

    def size(self, file_path):
        """
        Returns the size of the file in bytes
        """
        file_path = self._cleanpath(file_path)
        with self.__convert_path(file_path) as converted_path:
            dirdict = self.parsedir(converted_path)
        if dirdict.has_key('sizes') and len(dirdict['sizes']) == 1:
            try:
                return int(dirdict['sizes'][0])
            except ValueError:
                logging.error('Error getting size of file from self._dir result:\n%s' % self._dir(file_path))
                raise

        else:
            raise IOError('Unable to access file [%s] to read size' % file_path)

    def retrieve_binary(self, file_path, callback, buffersize = None):
        """
        The cwd'ified version of retrbinary
        """
        file_path = self._cleanpath(file_path)
        with self.__convert_path(file_path) as converted_path:
            if buffersize:
                self.connection.retrbinary('RETR ' + converted_path.encode(self.encoding), callback, buffersize)
            else:
                self.connection.retrbinary('RETR ' + converted_path.encode(self.encoding), callback)

    def last_modified(self, file_path):
        """
        Returns the last modified time of the file
        
        format YYYYMMDDhhmmss
        """
        try:
            modified_time = self.connection.sendcmd('MDTM ' + file_path.encode(self.encoding))[3:]
            modified_time = modified_time.replace(' ', '').split('.')[0]
        except:
            logging.error('Error getting last modified time of file:\n%s' % file_path)
            return None

        return modified_time
# okay decompyling ./lib/dcinema/dcp/ftp_wrapper.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:45 CST
