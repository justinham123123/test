# 2017.08.13 21:51:46 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\mxf.py
import sys
import struct
MXF_KEYS = {'\x06\x0e+4\x02S\x01\x01\r\x01\x01\x01\x01\x01Q\x00': 'MPEG2VIDEODESCRIPTOR',
 '\x06\x0e+4\x02S\x01\x01\r\x01\x01\x01\x01\x01Z\x00': 'JPEG2000PICTURESUBDESCRIPTOR',
 '\x06\x0e+4\x02S\x01\x01\r\x01\x01\x01\x01\x01H\x00': 'WAVEAUDIODESCRIPTOR',
 '\x06\x0e+4\x02S\x01\x01\r\x01\x01\x01\x01\x017\x00': 'SOURCEPACKAGE',
 '\x06\x0e+4\x01\x02\x01\x01\r\x01\x03\x01\x15\x01\x05\x00': 'MPEG2ESSENCE',
 '\x06\x0e+4\x01\x02\x01\x01\r\x01\x03\x01\x15\x01\x08\x00': 'JPEG2000ESSENCE',
 '\x06\x0e+4\x01\x02\x01\x01\r\x01\x03\x01\x16\x01\x01\x00': 'WAVESSENCE'}

def _as_hex_str(bytes):
    """
    Pretty-prints bytes as hex values separated by dots
    """
    return '.'.join(map(lambda x: '%02X' % ord(x), bytes))


def _decode_ber_length(reader):
    """
    Dynamically works out a BER-encoded length value from a stream.read function.
    Returns the decoded length and nr of bytes read
    """
    length = struct.unpack('>B', reader(1))[0]
    bytes_read = 1
    if length > 127:
        bytes_read += length - 128
        length = int(reader(length - 128).encode('hex'), 16)
    return (length, bytes_read)


def klvs(stream):
    """
    Generator that iterates through KLVs that are
    dynamically read from a stream
    """
    klv_key_length = 16
    pos = 0
    while True:
        key = stream.read(klv_key_length)
        if not key:
            break
        length, len_bytes = _decode_ber_length(stream.read)
        value = stream.read(length)
        pos += 4 + len_bytes + length
        yield (MXF_KEYS.get(key, _as_hex_str(key)), value)


def print_klv_keys(mxf_file):
    """
    Prints out all klv keys found in an mxf file
    """
    for klv in klvs(mxf_file):
        print klv[0]


def essence_type(mxf_file):
    """
    Returns 'JPEG2000', 'MPEG2' or 'PCM' depending on the
    essence type contained within the mxf file
    """
    for klv in klvs(mxf_file):
        if klv[0] == 'JPEG2000PICTURESUBDESCRIPTOR':
            return 'JPEG2000'
        if klv[0] == 'MPEG2VIDEODESCRIPTOR':
            return 'MPEG2'
        if klv[0] == 'WAVEAUDIODESCRIPTOR':
            return 'PCM'
    else:
        return 'UNKNOWN'


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print 'USAGE: python mxf.py <mxf file name>'
    else:
        with open(sys.argv[1], 'rb') as f:
            print essence_type(f)
# okay decompyling ./lib/dcinema/dcp/mxf.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:46 CST
