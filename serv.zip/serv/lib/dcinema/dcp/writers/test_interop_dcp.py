# 2017.08.13 21:51:49 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\writers\test_interop_dcp.py
import datetime
import uuid
import hashlib
import base64
from serv.lib.dcinema.dcp.writers import interop_dcp

def sha_digest(string):
    sha1 = hashlib.sha1()
    sha1.update(string)
    return base64.b64encode(sha1.digest())


sample_cpl_data = {'id': str(uuid.uuid4()),
 'text': '<used for both ContentTitleText & AnnotationText>',
 'issue_date': datetime.datetime.now(),
 'type': 'Advertisement',
 'reels': [{'asset_list': [{u'MainPicture': {u'Duration': u'120',
                                             u'EditRate': u'24 1',
                                             u'EntryPoint': u'0',
                                             u'FrameRate': u'24 1',
                                             u'Hash': u'IDNDhKAy5aVChJdiJXZXrjs5A78=',
                                             u'Id': u'05f1df43-6d77-47c6-950b-db741feb491a',
                                             u'IntrinsicDuration': u'120',
                                             u'ScreenAspectRatio': u'1.85'}}, {u'MainSound': {u'Duration': u'120',
                                           u'EditRate': u'24 1',
                                           u'EntryPoint': u'0',
                                           u'Hash': u'LSyAw8lZUkgeOujXWVBdkMsqeTQ=',
                                           u'Id': u'4267ea07-1068-4dae-85dc-a0d2c04eea38',
                                           u'IntrinsicDuration': u'120',
                                           u'Language': u'en'}}],
            'id': str(uuid.uuid4()),
            'position': 1}, {'asset_list': [{u'MainPicture': {u'Duration': u'120',
                                             u'EditRate': u'24 1',
                                             u'EntryPoint': u'0',
                                             u'FrameRate': u'24 1',
                                             u'Hash': u'/u/dCM/qIXMcJFsLxr1MVmA/aVg=',
                                             u'Id': u'49d79772-a935-4176-8918-86d7d6ed9f9c',
                                             u'IntrinsicDuration': u'120',
                                             u'ScreenAspectRatio': u'1.85'}}, {u'MainSound': {u'Duration': u'120',
                                           u'EditRate': u'24 1',
                                           u'EntryPoint': u'0',
                                           u'Hash': u'UcOHUXJVh4+vlw6uYutbesmTccQ=',
                                           u'Id': u'd7202ed9-e387-46a1-a1b4-2f3c01bab140',
                                           u'IntrinsicDuration': u'120',
                                           u'Language': u'en'}}],
            'id': str(uuid.uuid4()),
            'position': 2}]}
cpl_xml = interop_dcp.create_cpl(sample_cpl_data)
cpl_uuid = sample_cpl_data['id']
cpl_filename = 'cpl_%s.xml' % cpl_uuid
sample_asset_file_list = [{'fullpath': u'c:\\lms-data\\ASSET\\05f1df43-6d77-47c6-950b-db741feb491a\\05f1df43-6d77-47c6-950b-db741feb491a.mxf',
  'hash': u'IDNDhKAy5aVChJdiJXZXrjs5A78=',
  'id': u'05f1df43-6d77-47c6-950b-db741feb491a',
  'originalfilename': u'05f1df43-6d77-47c6-950b-db741feb491a.mxf',
  'path': u'05f1df43-6d77-47c6-950b-db741feb491a.mxf',
  'size': 88709717,
  'type': u'application/x-smpte-mxf;asdcpKind=Picture'},
 {'fullpath': u'c:\\lms-data\\ASSET\\4267ea07-1068-4dae-85dc-a0d2c04eea38\\4267ea07-1068-4dae-85dc-a0d2c04eea38.mxf',
  'hash': u'LSyAw8lZUkgeOujXWVBdkMsqeTQ=',
  'id': u'4267ea07-1068-4dae-85dc-a0d2c04eea38',
  'originalfilename': u'4267ea07-1068-4dae-85dc-a0d2c04eea38.mxf',
  'path': u'4267ea07-1068-4dae-85dc-a0d2c04eea38.mxf',
  'size': 4339094,
  'type': u'application/x-smpte-mxf;asdcpKind=Sound'},
 {'fullpath': u'c:\\lms-data\\ASSET\\49d79772-a935-4176-8918-86d7d6ed9f9c\\49d79772-a935-4176-8918-86d7d6ed9f9c.mxf',
  'hash': u'/u/dCM/qIXMcJFsLxr1MVmA/aVg=',
  'id': u'49d79772-a935-4176-8918-86d7d6ed9f9c',
  'originalfilename': u'49d79772-a935-4176-8918-86d7d6ed9f9c.mxf',
  'path': u'49d79772-a935-4176-8918-86d7d6ed9f9c.mxf',
  'size': 88537821,
  'type': u'application/x-smpte-mxf;asdcpKind=Picture'},
 {'fullpath': u'c:\\lms-data\\ASSET\\d7202ed9-e387-46a1-a1b4-2f3c01bab140\\d7202ed9-e387-46a1-a1b4-2f3c01bab140.mxf',
  'hash': u'UcOHUXJVh4+vlw6uYutbesmTccQ=',
  'id': u'd7202ed9-e387-46a1-a1b4-2f3c01bab140',
  'originalfilename': u'd7202ed9-e387-46a1-a1b4-2f3c01bab140.mxf',
  'path': u'd7202ed9-e387-46a1-a1b4-2f3c01bab140.mxf',
  'size': 4339094,
  'type': u'application/x-smpte-mxf;asdcpKind=Sound'}]
sample_asset_file_list.append({'id': cpl_uuid,
 'hash': sha_digest(cpl_xml),
 'size': len(cpl_xml),
 'type': 'text/xml;asdcpKind=CPL',
 'originalfilename': cpl_filename,
 'path': cpl_filename})
sample_pkl_data = {'id': str(uuid.uuid4()),
 'text': '<AnnotationText>',
 'issue_date': datetime.datetime.now(),
 'file_list': sample_asset_file_list}
pkl_xml = interop_dcp.create_pkl(sample_pkl_data)
pkl_uuid = sample_pkl_data['id']
pkl_filename = 'pkl_%s.xml' % pkl_uuid
sample_asset_file_list.append({'id': pkl_uuid,
 'hash': sha_digest(pkl_xml),
 'size': len(pkl_xml),
 'type': 'text/xml;asdcpKind=PKL',
 'originalfilename': pkl_filename,
 'path': pkl_filename})
sample_assetmap_data = {'id': str(uuid.uuid4()),
 'issue_date': datetime.datetime.now(),
 'file_list': sample_asset_file_list}
asset_map_xml = interop_dcp.create_assetmap(sample_assetmap_data)
base = 'test/interop/'
with open(base + 'ASSETMAP', 'w') as f:
    f.write(asset_map_xml)
with open(base + pkl_filename, 'w') as f:
    f.write(pkl_xml)
with open(base + cpl_filename, 'w') as f:
    f.write(cpl_xml)
# okay decompyling ./lib/dcinema/dcp/writers/test_interop_dcp.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:50 CST
