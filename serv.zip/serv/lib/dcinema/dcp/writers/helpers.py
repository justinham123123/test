# 2017.08.13 21:51:46 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\writers\helpers.py
"""
DCP Writer helpers
(c) 2013 Arts Alliance Media

Provides some helper methods used by the DCP writers module
"""
import xml.etree.cElementTree as ET
import base64
import hashlib
import uuid
DEFAULT_CREATOR_LABEL = 'Arts Alliance Media TMS'
DEFAULT_ISSUER_LABEL = 'Arts Alliance Media'

def create_child_element(parent, el_name, el_val):
    """ElementTree Helper method to create a new element with a supplied value
    and attach that element to the specified parent
    :param parent: parent element
    :param el_name: name of the elemnt to create
    :param el_value: text value to be assigned to the element
    
      e.g.  on the xml, <root />, create_child_element(root, 'foo', 'hello')
      would create:    <root><foo>hello</foo></root>
    """
    el = ET.SubElement(parent, el_name)
    el.text = el_val
    return el


def sha_digest(string):
    """
    DCI compliant sha base64 digest of some data
    """
    sha1 = hashlib.sha1()
    sha1.update(string)
    return base64.b64encode(sha1.digest())


def new_uuid():
    """
    generates a uuid in string format
    """
    return str(uuid.uuid4())
# okay decompyling ./lib/dcinema/dcp/writers/helpers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:46 CST
