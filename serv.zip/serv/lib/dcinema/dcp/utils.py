# 2017.08.13 21:51:46 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\dcinema\dcp\utils.py
import logging
import os, re
import traceback

class ParsingException(Exception):
    pass


class ChunkedAssetmapException(ParsingException):
    pass


ns = {'cpl1': 'http://www.digicine.com/PROTO-ASDCP-CPL-20040511#',
 'cpl2': 'http://www.smpte-ra.org/schemas/429-7/2006/CPL"',
 'am1': 'http://www.digicine.com/PROTO-ASDCP-AM-20040311#',
 'am2': 'http://www.smpte-ra.org/schemas/429-9/2007/AM',
 'pkl1': 'http://www.digicine.com/PROTO-ASDCP-PKL-20040311#',
 'pkl2': 'http://www.smpte-ra.org/schemas/429-8/2007/PKL',
 'kdm1': 'http://www.digicine.com/PROTO-ASDCP-KDM-20040311#',
 'kdm2': 'http://www.smpte-ra.org/schemas/430-1/2006/KDM',
 'kdm3': 'http://www.smpte-ra.org/schemas/430-3/2006/ETM'}
IGNORE_NAMESPACE_XPATH_EXPR = './/*[local-name() = $name]'
schema_root = os.path.abspath(os.path.split(__file__)[0]) + '/schemas/'
NAMESPACE_MAP = {'http://www.smpte-ra.org/schemas/429-9/2007/AM': os.path.join(schema_root, 'SMPTE/429-9_2007_AM.xsd'),
 'http://www.smpte-ra.org/schemas/429-7/2006/CPL': os.path.join(schema_root, 'SMPTE/429-7_2006_CPL.xsd'),
 'http://www.smpte-ra.org/schemas/429-8/2007/PKL': os.path.join(schema_root, 'SMPTE/429-8_2007_PKL.xsd'),
 'http://www.smpte-ra.org/schemas/430-1/2006/KDM': os.path.join(schema_root, 'SMPTE/430-1_2006_KDM.xsd'),
 'http://www.smpte-ra.org/schemas/430-3/2006/ETM': os.path.join(schema_root, 'SMPTE/430-3_2006_ETM.xsd'),
 'http://www.digicine.com/PROTO-ASDCP-CPL-20040511#': os.path.join(schema_root, 'DIGICINE/PROTO-ASDCP-CPL-20040511.xsd'),
 'http://www.digicine.com/PROTO-ASDCP-AM-20040311#': os.path.join(schema_root, 'DIGICINE/PROTO-ASDCP-AM-20040311.xsd'),
 'http://www.digicine.com/PROTO-ASDCP-PKL-20040311#': os.path.join(schema_root, 'DIGICINE/PROTO-ASDCP-PKL-20040311.xsd')}
# okay decompyling ./lib/dcinema/dcp/utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:46 CST
