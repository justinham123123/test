# 2017.08.13 21:51:38 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\cherrypy\custom_tools\handlers.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
if 'tools.json_out.handler' not in cherrypy.config:
    cherrypy.config['tools.json_out.handler'] = cherrypy_utils.json_out_handler
if not hasattr(cherrypy.tools, 'json_input'):
    cherrypy.tools.json_input = cherrypy.Tool('before_handler', cherrypy_utils.json_input, priority=30)
if not hasattr(cherrypy.tools, 'ignore_input'):
    cherrypy.tools.ignore_input = cherrypy.Tool('before_handler', cherrypy_utils.ignore_input, priority=90)
# okay decompyling ./lib/cherrypy/custom_tools/handlers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:38 CST
