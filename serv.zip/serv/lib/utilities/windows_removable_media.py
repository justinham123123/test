# 2017.08.13 21:52:28 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\windows_removable_media.py
import win32api, win32con, win32gui, pywintypes
from ctypes import *
import logging
from threading import Thread
import time
DBT_DEVICEARRIVAL = 32768
DBT_DEVICEQUERYREMOVE = 32769
DBT_DEVICEQUERYREMOVEFAILED = 32770
DBT_DEVICEMOVEPENDING = 32771
DBT_DEVICEREMOVECOMPLETE = 32772
DBT_DEVICETYPESSPECIFIC = 32773
DBT_CONFIGCHANGED = 24
DBT_DEVTYP_OEM = 0
DBT_DEVTYP_DEVNODE = 1
DBT_DEVTYP_VOLUME = 2
DBT_DEVTYPE_PORT = 3
DBT_DEVTYPE_NET = 4
DBTF_MEDIA = 1
DBTF_NET = 2
WORD = c_ushort
DWORD = c_ulong

def check_cdrom_drive(drive_path):
    try:
        win32api.GetVolumeInformation(drive_path)
    except pywintypes.error as e:
        if e.winerror == 21:
            return False

    return True


class DEV_BROADCAST_HDR(Structure):
    _fields_ = [('dbch_size', DWORD), ('dbch_devicetype', DWORD), ('dbch_reserved', DWORD)]


class DEV_BROADCAST_VOLUME(Structure):
    _fields_ = [('dbcv_size', DWORD),
     ('dbcv_devicetype', DWORD),
     ('dbcv_reserved', DWORD),
     ('dbcv_unitmask', DWORD),
     ('dbcv_flags', WORD)]


def drive_from_mask(mask):
    n_drive = 0
    intmask = int(mask)
    while 1:
        if intmask == 2 ** n_drive:
            return n_drive
        n_drive += 1


class WindowsMediaInsertionThread(object):

    def __init__(self, core):
        logging.info('init thread')
        self.thread = None
        self.core = core
        return

    def start(self):
        logging.info('starting thread')
        self.running = True
        if not self.thread:
            self.thread = Thread(target=self.run, name='Windows Removable Media')
            self.thread.daemon = True
        self.thread.start()

    def stop(self):
        logging.info('stopping thread')
        if self.thread:
            self.thread = None
        self.running = False
        return

    def run(self):
        self.medialistener = WindowsMediaInsertionWrapper(self.core)
        win32gui.PumpMessages()
        while self.running:
            try:
                time.sleep(2)
            except:
                pass


class WindowsMediaInsertionWrapper:

    def __init__(self, core):
        message_map = {win32con.WM_DEVICECHANGE: self.onDeviceChange}
        wc = win32gui.WNDCLASS()
        hinst = wc.hInstance = win32api.GetModuleHandle(None)
        wc.lpszClassName = 'DeviceChangeDemo'
        wc.style = win32con.CS_VREDRAW | win32con.CS_HREDRAW
        wc.hCursor = win32gui.LoadCursor(0, win32con.IDC_ARROW)
        wc.hbrBackground = win32con.COLOR_WINDOW
        wc.lpfnWndProc = message_map
        classAtom = win32gui.RegisterClass(wc)
        style = win32con.WS_OVERLAPPED | win32con.WS_SYSMENU
        self.hwnd = win32gui.CreateWindow(classAtom, 'Device Change Demo', style, 0, 0, win32con.CW_USEDEFAULT, win32con.CW_USEDEFAULT, 0, 0, hinst, None)
        self.core = core
        return

    def onDeviceChange(self, hwnd, msg, wparam, lparam):
        dev_broadcast_hdr = DEV_BROADCAST_HDR.from_address(lparam)
        if wparam == DBT_DEVICEARRIVAL:
            if dev_broadcast_hdr.dbch_devicetype == DBT_DEVTYP_VOLUME:
                dev_broadcast_volume = DEV_BROADCAST_VOLUME.from_address(lparam)
                if dev_broadcast_volume.dbcv_flags and DBTF_MEDIA:
                    drive_letter = drive_from_mask(dev_broadcast_volume.dbcv_unitmask)
                    driveletter = '{letter}:\\'.format(letter=chr(ord('A') + drive_letter))
                    if check_cdrom_drive(driveletter):
                        logging.info('Media inserted in drive {driveletter}'.format(driveletter=driveletter))
                        self.core.enable_cdrom_drive(driveletter)
        return 1

    def onThreadStart(self):
        logging.info('Starting Windows Removable Media Insertion Listener')
        win32gui.PumpMessages()


if __name__ == '__main__':
    w = WindowsMediaInsertionWrapper()
    win32gui.PumpMessages()
# okay decompyling ./lib/utilities/windows_removable_media.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:29 CST
