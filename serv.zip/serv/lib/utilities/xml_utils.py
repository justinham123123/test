# 2017.08.13 21:52:29 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\xml_utils.py
"""
Utility functions for working with xml.dom.minidom objects and XML strings
"""
import re
from io import BytesIO
from xml.etree import ElementTree
ElementTree._namespace_map.update({'http://www.w3.org/2001/XMLSchema-instance': 'xsi',
 'http://www.smpte-ra.org/schemas/433/2008/dcmlTypes': 'dcml',
 'http://www.w3.org/2000/09/xmldsig#': 'ds',
 'http://www.w3.org/2001/XMLSchema': 'xs',
 'http://www.smpte-ra.org/schemas/430-4/2008/LogRecord': 'lr'})
from xml.parsers.expat import ExpatError as XMLParseError

def parse_xml(xml):
    """
    Parse XML into memory using ElementTree.
    
    :param xml: XML to be parsed, as a string or file-like object
    :returns: The root Element of the XML document.
    
    Where possible, iterparse_xml should be preferred over this function, parsing the entire XML
    into memory is only more useful in the case where you may want to make some minor changes
    then re-serialize it again.
    """
    try:
        if isinstance(xml, str) or isinstance(xml, unicode):
            return ElementTree.fromstring(xml)
        return ElementTree.parse(xml)
    except XMLParseError:
        raise


def iterparse_xml(xml, loop_function, initial_vars):
    """
    Iteratively parse XML using ElementTree's iterparse function.
    
    Parameters:
    :param xml: the XML to be parsed, can be a string or file-like object
    :param loop_function: the function to be called at each iteration of iterparse
    :param initial_vars: dictionary of initial variables to be passed into the loop function
    
    :returns: The result of calling your loop_function at every start or end tag in the XML
    
    The loop function needs to have the function definition (event, element, loop_vars),
    and return the loop_vars which will be passed on to the next call of the loop function.
    
    Loop function parameters: (I think this will break Sphinx)
    :param event: takes only the values 'start' or 'end', depending on whether the current tag is being opened or closed
    :param element: the XML Element object currently yielded.  Note that this will only be fully populated on an
        'end' event (once its contents have been parsed)
    :param loop_vars: the loop variant(s) in a dictionary, these can be used by successive calls of the loop function
        to keep track of state while parsing
    :param tree: the ElementTree iterator object
    """
    if isinstance(xml, unicode):
        regex = re.compile('encoding="([A-Z0-9\\-_]*?)"', re.I)
        match = regex.search(xml)
        if match and match.group(1):
            try:
                xml = xml.encode(match.group(1))
            except LookupError:
                raise XMLParseError(u"XML encoding '{0}' not recognised by Python".format(match.group(1)))

        else:
            xml = xml.encode('utf-8')
    if isinstance(xml, str):
        xml = BytesIO(xml)
    et = iter(ElementTree.iterparse(xml, ('start', 'end')))
    event, root = et.next()
    loop_vars = loop_function(event, root, initial_vars, tree=et)
    try:
        while True:
            event, element = et.next()
            loop_vars = loop_function(event, element, loop_vars, tree=et)

    except XMLParseError as e:
        loop_vars['error_message'] = str(e)
        return loop_vars
    except StopIteration:
        return loop_vars
    finally:
        root.clear()


def node_to_dict(tree, list_tags = None, attributes = False):
    """
    Create a dictionary from an ElementTree iterator.
    
    :param tree: An iterparse iterator over an XML document/fragment
    :param list_tags: A list of XML tag names which are guaranteed to return as lists
    :param attributes: Whether to collect attributes or not (default False)
    
    :returns: A (potentially nested) dictionary containing the contents of the XML
    
    This function will take an iterparse iterator and return a dictionary containing all
    the child elements of the node at the iterator's current position.  Call it from a
    'start' event matching the node you want to convert to a dict.
    
    Since this function is not aware of the structure of the XML before it parses it,
    it first assumes each tag is unique, then if it sees the same tag twice it will
    convert to a list.  You can override this behaviour by passing in the names of tags
    in 'list_tags' which if encountered will always be returned as lists.  This prevents
    problems where only one item is present but there can be many, such as asking for a
    list of UUIDs; if the tag isn't marked as always being a list then you may end up
    unintentionally iterating over a single UUID string instead.
    
    The keyword argument 'attributes' will collect the attributes of each node (except for
    namespaces) and attach them to the *parent's* dictionary under the key
    '<tag_name>__<attribute_name>'.  This means that you cannot check the attributes of the
    root node, but avoids complications with attributes of leaf nodes.
    
    So for example '<root><child attr='true'>text</child></root>' would return
    {'child': 'text', 'child__attr': 'true'} when called with 'tree' at the root's start tag.
    
    Note that when this function returns the iterator will be at the *closing* tag of the
    selected node (after the 'end' event) since the iterator is passed by reference.
    """
    result = _node_to_dict(tree, list_tags, attributes)[0]
    if result:
        return result
    return {}


def _node_to_dict(tree, list_tags = None, show_attributes = False):
    if not list_tags:
        list_tags = []
    event, element = tree.next()
    if event == 'end':
        contents = (element.text, element.items()) if show_attributes else (element.text, [])
        element.clear()
        return contents
    else:
        children = {}
        while event != 'end':
            tag_name = element.tag.rsplit('}', 1)[-1]
            if tag_name in list_tags and tag_name not in children:
                children[tag_name] = []
            if tag_name in children:
                if not isinstance(children[tag_name], list):
                    children[tag_name] = [children[tag_name]] if children[tag_name] else []
                contents, attributes = _node_to_dict(tree, list_tags, show_attributes)
                if contents is not None or attributes:
                    children[tag_name].append(contents)
            else:
                contents, attributes = _node_to_dict(tree, list_tags, show_attributes)
                children[tag_name] = contents
            for attribute, value in attributes:
                attribute = attribute.rsplit('}', 1)[-1]
                key = '{0}__{1}'.format(tag_name, attribute)
                if key in children and not isinstance(children[key], list):
                    children[key] = [children[key], value]
                elif key in children:
                    children[key].append(value)
                else:
                    children[key] = value

            event, element = tree.next()

        contents = (children, element.items()) if show_attributes else (children, [])
        element.clear()
        return contents


def write_xml(root):
    """
    Convert an ElementTree instance to a string.
    
    :param root: The ElementTree object or root Element
    :returns: An XML string of the tree rooted at the given element
    """
    return ElementTree.tostring(root, encoding='utf-8')


class XMLBuilder:

    def __init__(self, doc):
        self.doc = doc

    def attr(self, node, name, value):
        create_attribute(self.doc, node, name, value)

    def node(self, parent_node, name, text = None, cdata = False, empty = False, attrs = []):
        if not empty and not text and text is not None:
            return
        else:
            node = create_node(self.doc, parent_node, name, text, cdata)
            for attr in attrs:
                self.attr(node, attr['name'], attr['value'])

            return node

    def node_list(self, parent, name, list):
        if list:
            root = self.node(parent, name)
            for node_item in list:
                root.appendChild(node_item.xml())


def create_attribute(doc, node, name, value):
    """
    Creates a new attribute for the given node
    """
    attr = doc.createAttribute(name)
    if value is not None:
        if type(value).__name__ not in ('unicode',):
            value = str(value)
        attr.value = value
    node.setAttributeNode(attr)
    return


def create_node(doc, parent_node, name, text = None, cdata = False):
    """
    Creates a new node under the given parent and provides
    a child text node if the text is supplied.
    """
    node = doc.createElement(name)
    parent_node.appendChild(node)
    if text is not None:
        if not isinstance(text, unicode):
            text = str(text)
        if cdata:
            node.appendChild(doc.createCDATASection(text))
        else:
            node.appendChild(doc.createTextNode(text))
    return node


def has_element(dom, tag_name):
    """
    Checks whether the tag exists within the specified dom
    """
    return bool(dom.getElementsByTagName(tag_name))


def get_element_value(dom, tag_name = None):
    """
    Retrieves a value from the first element found with the
    specified tag name from the specified minidom
    """
    if tag_name is not None:
        elements = dom.getElementsByTagName(tag_name)
    else:
        elements = [dom]
    if elements and elements[0].firstChild:
        return elements[0].firstChild.data
    else:
        return
        return


def get_element_value_list(dom, tag_name):
    """
    Retrieves a list of values from the elements for with the
    specified tag name from the specified minidom.
    Automatically strips the urn if present
    """
    elements = dom.getElementsByTagName(tag_name)
    if elements and elements[0].firstChild:
        return [ e.firstChild.data for e in elements ]
    else:
        return []


def get_attributes(dom, tag_name):
    """
    Retrieves the attributes and values for the first element
    with the specified tag name from the specified minidom.
    Returns a dictionary.
    """
    result = {}
    attr = dom.getElementsByTagName(tag_name)
    if attr:
        for k, v in attr[0].attributes.items():
            result[k] = v

    return result


def get_attributes_list(dom, tag_name):
    """
    Retrieves the attributes and values for all elements
    with the specified tag name. Return a list of dictionaries
    """
    result = []
    for element in dom.getElementsByTagName(tag_name):
        attributes = {}
        for k, v in element.attributes.items():
            attributes[k] = v

        result.append(attributes)

    return result


def get_child_by_tag(dom, tag_name):
    """
    Retrieves the first child node that matches the tag name
    """
    for child_node in dom.childNodes:
        if child_node.localName == tag_name:
            return child_node
    else:
        return None

    return None


def get_children_by_tags(dom, tag_names):
    """
    Retrieves a list of child nodes that match the tag names
    """
    return [ child_node for child_node in dom.childNodes if child_node.localName in tag_names ]


def get_element_data(xml, tag, parent_tag = None, multi = False):
    """
    Returns the tag data for the first instance of the named
    tag, or for all instances if multi is true. If a parent tag
    is specified, then that will be required before the tag.
    """
    expr_str = '[<:]' + tag + '.*?>(?P<matched_text>.*?)<'
    if parent_tag:
        expr_str = '[<:]' + parent_tag + '.*?>.*?' + expr_str
    expr = re.compile(expr_str, re.DOTALL | re.IGNORECASE)
    if multi:
        ret = []
        for x in expr.findall(xml):
            if type(x).__name__ != 'unicode':
                x = x.decode('utf-8')
            ret.append(x)

        return ret
    elif expr.search(xml):
        x = expr.search(xml).group('matched_text').strip()
        if type(x).__name__ != 'unicode':
            x = x.decode('utf-8')
        return x
    else:
        None
        return


def get_element_children(xml, parent_tag, grand_parent_tag = None):
    """
    Returns the tag data for all named tags under the parent tag, returning
    multiple if they exist
    """
    result = []
    if grand_parent_tag:
        gp_re = re.compile('[<:]' + grand_parent_tag + '.*?>(.*?)</' + grand_parent_tag + '>', re.DOTALL | re.IGNORECASE)
        xml = gp_re.search(xml).group()
    parent_re = re.compile('[<:]' + parent_tag + '.*?>(.*?)</' + parent_tag + '>', re.DOTALL | re.IGNORECASE)
    for children in parent_re.findall(xml):
        children_dict = {}
        children_re = re.compile('[<:](?P<tag>\\w*?).*?>(.*?)</(?P=tag)>', re.DOTALL | re.IGNORECASE)
        child_scan = children_re.scanner(children)
        while True:
            child = child_scan.search()
            if not child:
                break
            children_dict[child.group(1).lower()] = child.group(2)

        result.append(children_dict)

    return result
# okay decompyling ./lib/utilities/xml_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:30 CST
