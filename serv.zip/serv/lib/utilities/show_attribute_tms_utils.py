# 2017.08.13 21:52:25 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\show_attribute_tms_utils.py
import cherrypy
from serv.lib.utilities.show_attribute_utils import CachedAttributeUtils
from serv.storage.database.primary import database as db

class TmsShowAttributeUtils(CachedAttributeUtils):
    """
    Caching version of `ShowAttributeUtils` with Screenwriter specific helpers.
    """

    def __init__(self, ccpush, exsam_to_cache = None, source = None):
        self._exsam_to_cache = exsam_to_cache
        self._ccpush = ccpush
        self._source = source
        super(TmsShowAttributeUtils, self).__init__(db)

    def insert_or_ignore_exam(self, exsam_dict):
        """
        Inserts a new exsam with the given data (without committing the current
        session) or does nothing.
        """
        ex_sam = self.lookup_exsam(exsam_uuid=self._get_exam_uuid(exsam_dict))
        if ex_sam is None:
            ex_sam = self.insert_or_update_exam(exsam_dict)
        return ex_sam

    def insert_or_update_exam(self, exsam_dict):
        """
        Inserts a new exsam or update an existing one with the given data
        and without committing the current session.
        """
        will_create = self.lookup_exsam(exsam_uuid=self._get_exam_uuid(exsam_dict)) is None
        ex_sam = super(CachedAttributeUtils, self)._create_exsam(exsam_dict)
        self._ex_sam_uuid_cache[ex_sam.uuid] = ex_sam
        self._ex_sam_id_cache[ex_sam.source, ex_sam.external_id] = ex_sam
        if will_create and self._ccpush:
            cherrypy.engine.publish('ccpush', 'external_show_attribute_save', {'external_id': ex_sam.external_id,
             'source': ex_sam.source,
             'uuid': ex_sam.uuid})
        return ex_sam

    def load_cache(self):
        """
        Loads only the needed indexes:
          * ex_sams are looked up only by uuid.
          * sas are looked up only by uuid.
        """
        query = db.Session.query(db.ExternalShowAttributeMap)
        if self._exsam_to_cache:
            query = query.filter(db.ExternalShowAttributeMap.uuid.in_(self._exsam_to_cache))
        if self._source:
            query = query.filter(db.ExternalShowAttributeMap.source == self._source)
        self._ex_sam_uuid_cache = dict(((ex_sam.uuid, ex_sam) for ex_sam in query))
        self._sa_uuid_cache = dict(((sa.uuid, sa) for sa in db.Session.query(db.ShowAttribute)))
# okay decompyling ./lib/utilities/show_attribute_tms_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:25 CST
