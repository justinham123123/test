# 2017.08.13 21:52:22 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\linking.py
"""
Exposes the CPLs and their assets in a DCP-compliant directory structure
"""
import sys
import os

def _create_sym_link(source_dir, sym_link_to):
    """
    Manages OS differences when creating sym links
    Creates a sym link from:
    @param
        source_dir  - source directory
        sym link to - to this location
    raises exception if it didnt work
    """
    if sys.platform == 'win32':
        from ctypes import windll
        from ctypes.wintypes import BOOLEAN, LPWSTR, DWORD, LPVOID
        CreateSymbolicLink = windll.kernel32.CreateSymbolicLinkW
        CreateSymbolicLink.argtypes = (LPWSTR, LPWSTR, DWORD)
        CreateSymbolicLink.restype = BOOLEAN
        GetLastError = windll.kernel32.GetLastError
        GetLastError.argtypes = ()
        GetLastError.restype = DWORD


def create_hard_link(source_file, hard_link_to):
    """
    Manages OS differences when creating hard links
    Creates a hard link from:
    @param
        source_file  - hard link this file
        hard_link_to - to this location
    raises exception if it didnt work
    """
    if sys.platform == 'win32':
        from ctypes import windll
        from ctypes.wintypes import BOOLEAN, LPWSTR, DWORD, LPVOID
        CreateHardLink = windll.kernel32.CreateHardLinkW
        CreateHardLink.argtypes = (LPWSTR, LPWSTR, LPVOID)
        CreateHardLink.restype = BOOLEAN
        GetLastError = windll.kernel32.GetLastError
        GetLastError.argtypes = ()
        GetLastError.restype = DWORD
        error_dict = {0: 'The operation completed successfully',
         2: 'The system cannot find the file specified',
         3: 'The system cannot find the path specified',
         183: 'Cannot create a file when that file already exists',
         1142: 'An attempt was made to create more links on a file than the file system supports'}
        if not CreateHardLink(hard_link_to, source_file, None):
            error_key = GetLastError()
            if error_key in error_dict:
                error = error_dict[error_key]
            else:
                error = 'ErrorKey[%s] not in Error_dict, goto http://msdn.microsoft.com/en-us/library/ms681382(VS.85).aspx for description ' % error_key
            error = error + '|| to: |' + str(hard_link_to) + '| source: |' + str(source_file) + '|'
            raise Exception(error)
    else:
        os.link(source_file, hard_link_to)
    return
# okay decompyling ./lib/utilities/linking.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:23 CST
