# 2017.08.13 21:52:23 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\messages.py
from abc import abstractproperty, ABCMeta
from serv.lib.cherrypy.i18n_tool import ugettext

class Message(object):
    __metaclass__ = ABCMeta

    def __init__(self, msg_text, **kwargs):
        self._msg_text = ugettext(msg_text)
        self._msg_args = kwargs
        self.formatted_msg = self._msg_text.format(**self._msg_args)

    @abstractproperty
    def msg_type(self):
        return NotImplementedError()

    def to_dict(self):
        msg_dict = {'type': self.msg_type,
         'message': self.formatted_msg}
        msg_dict.update(self._msg_args)
        return msg_dict

    def __str__(self):
        return self.formatted_msg

    def __repr__(self):
        return '%s(%s)'.format(self.__class__.__name__, self.formatted_msg)


class ErrorMessage(Message):
    msg_type = 'error'

    def __init__(self, msg_text, **kwargs):
        super(ErrorMessage, self).__init__(msg_text, **kwargs)


class SuccessMessage(Message):
    msg_type = 'success'

    def __init__(self, msg_text, **kwargs):
        super(SuccessMessage, self).__init__(msg_text, **kwargs)


class ActionMessage(Message):
    msg_type = 'action'

    def __init__(self, msg_text, action_id, **kwargs):
        super(ActionMessage, self).__init__(msg_text, **kwargs)
        self.action_id = action_id

    def to_dict(self):
        msg_dict = super(ActionMessage, self).to_dict()
        msg_dict['action_id'] = self.action_id
        return msg_dict
# okay decompyling ./lib/utilities/messages.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:23 CST
