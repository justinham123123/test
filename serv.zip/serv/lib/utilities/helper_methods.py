# 2017.08.13 21:52:19 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\helper_methods.py
"""
Generic functionality used throughout Theatre Core
"""
from multiprocessing.connection import Pipe
from multiprocessing.process import Process
from types import DictType, ListType
from collections import defaultdict
import uuid
from xml.sax.saxutils import escape
from uuid import uuid5, NAMESPACE_DNS
import copy
import datetime
import httplib
import logging
import re
import time
import sys
import os
from decorator.decorator import decorator
import cherrypy
from serv.configuration import cfg
from serv.configuration.constants import SHORTDAYS, DAYS, MONTHS
from serv.core.devices.base.cache import Cache
from serv.lib.cherrypy.i18n_tool import ugettext as _
UUID_PATTERN = re.compile('[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}')

class API(object):

    def __init__(self, core):
        self.core = core
        self._action = core._action
        self._get_devices = core.get_devices
        self._assess_device = core._assess_device


def natural_sort(l, k):
    """ Sort the given list in the way that humans expect."""
    convert = lambda text: (int(text) if text.isdigit() else text)
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key[k]) ]
    l.sort(key=alphanum_key)


def copy_by_value(input):
    """
    UPDATED VERSION
    Deep copy of a Python data structure
    will not work if input, or values inside the input are not
    dict, list, string, integer, or float
    """
    input_type = type(input)
    if input_type is DictType:
        output = {}
        for k, v in input.items():
            v_type = type(v)
            output[k] = copy_by_value(v) if v_type is DictType or v_type is ListType else v

    elif input_type is ListType:
        output = []
        for v in input[:]:
            v_type = type(v)
            output.append(copy_by_value(v) if v_type is DictType or v_type is ListType else v)

    else:
        output = input
    return output


def make_uuid5(*args):
    """
    Creates uuid based off arguments.
    """
    raise args and any(args) or AssertionError
    encoded_args = []
    for arg in args:
        try:
            encoded_args.append(str(arg))
        except UnicodeEncodeError:
            encoded_args.append(str(arg.encode('punycode')))

    return str(uuid5(NAMESPACE_DNS, ''.join(encoded_args)))


def match_uuid(string, uuid):
    return is_uuid(string) and string == uuid


def is_uuid(string):
    result = re.match(UUID_PATTERN, string)
    return result is not None


def merge_dictionary(dst, src):
    """
    Creates a merged dictionary of dst, and src, dst and src are untouched
    values in src have overwriting power onto values in dst
    """
    dst = copy_by_value(dst)
    stack = [(dst, src)]
    while stack:
        current_dst, current_src = stack.pop()
        for key in current_src:
            if key not in current_dst:
                current_dst[key] = current_src[key]
            else:
                current_src_key_type = type(current_src[key])
                current_dst_key_type = type(current_dst[key])
                if current_src_key_type is DictType and current_dst_key_type is DictType:
                    stack.append((current_dst[key], current_src[key]))
                elif current_src_key_type is ListType and current_dst_key_type is ListType:
                    current_dst[key] = current_dst[key] + current_src[key]
                else:
                    current_dst[key] = current_src[key]

    return dst


def make_hash(o):
    """
    Makes a hash from a dictionary, list, tuple or set to any level, that contains
    only other hashable types (including any lists, tuples, sets, and
    dictionaries).
    """
    if isinstance(o, set) or isinstance(o, tuple) or isinstance(o, list):
        return hash(tuple([ make_hash(e) for e in o ]))
    if not isinstance(o, dict):
        return hash(o)
    new_o = copy.deepcopy(o)
    for k, v in new_o.items():
        new_o[k] = make_hash(v)

    return hash(tuple(frozenset(new_o.items())))


def get_event_info(playlist, automations):
    ret = {}
    ret['has_show_start'] = False
    ret['has_intermission'] = False
    ret['show_start_offset'] = 0
    position = 0
    for event in playlist['events']:
        if 'automation' in event:
            for automation in event['automation']:
                if automation['name'] in automations:
                    if not ret['has_show_start']:
                        ret['has_show_start'] = automations[automation['name']]['show_start']
                        if automations[automation['name']]['show_start']:
                            if automation['type_specific']['offset_from'] == 'start':
                                ret['show_start_offset'] = position + automation['type_specific']['offset_in_seconds']
                            elif automation['type_specific']['offset_from'] == 'end':
                                ret['show_start_offset'] = position + event['duration_in_seconds'] - automation['type_specific']['offset_in_seconds']
                if not ret['has_intermission'] and (automation['type'] == 'intermission' or automations.get(automation['name'], {}).get('intermission')):
                    ret['has_intermission'] = True

        if event.get('duration_in_seconds'):
            position += int(event['duration_in_seconds'])

    return ret


def is_content_validation_info_clean(content_validation_dict):
    if content_validation_dict.get('cpl_validation_error_code', '') == 0:
        return True
    return False


def info_needs_updating(info_dict, seconds = 0, permanent = False):
    """
    Assumes static information will not need to be updated frequently;
    clean information will updated less frequently
    """
    now = time.time()
    if isinstance(info_dict, Cache):
        last_updated = info_dict.last_updated
    else:
        if 'last_updated' not in info_dict:
            raise KeyError('last_updated not in ' + str(info_dict)[:250])
        last_updated = info_dict.get('last_updated')
    if last_updated == None:
        last_updated = 0.0
    if permanent and info_dict.get('clean', False):
        return False
    else:
        if info_dict.get('clean', False):
            if now > last_updated + 6 * seconds:
                return True
        elif now > last_updated + seconds:
            return True
        return False


def tuple_to_string(tuple):
    """
    Pretty-prints a tuple with two items
    """
    return str(tuple[0]) + '=' + str(tuple[1])


def exception_wrapper(func):
    """
    This function can be decorated on another function to wrap
    exceptions in a consistent manner
    """

    def wrapper(*args, **kwargs):
        try:
            output = func(*args, **kwargs)
        except Exception as ex:
            log_string = 'There was a problem executing: %s, error: %s, args:(%s), kwargs:(%s)' % (func.__name__,
             str(ex),
             ', '.join(map(str, args[1:])),
             ', '.join(map(tuple_to_string, kwargs.iteritems())))
            logging.error(log_string, exc_info=True)
            output = {'error_messages': ['There was a problem executing %s' % func.__name__]}

        return output

    wrapper.__name__ = func.__name__
    return wrapper


def format_time(seconds):
    if seconds <= 60:
        return _('%01d Seconds') % seconds
    hours = seconds / 3600
    seconds -= 3600 * hours
    minutes = seconds / 60
    if hours < 1:
        if minutes == 1:
            return _('%01d Minute') % minutes
        else:
            return _('%01d Minutes') % minutes
    else:
        if hours > 1:
            return _('%01d Hours, %01d Mins') % (hours, minutes)
        return _('%01d Hour, %01d Mins') % (hours, minutes)


def format_timestamp(timestamp):
    if timestamp:
        timestamp = int(timestamp)
        date = datetime.datetime.fromtimestamp(timestamp)
        return format_datetime(date)
    else:
        return timestamp


def format_datetime(datetime_object, short = False, include_time = True):
    if datetime_object:
        if short and include_time:
            return SHORTDAYS[datetime_object.weekday()] + ' ' + str(datetime_object.day) + ' ' + MONTHS[datetime_object.month - 1] + ' ' + str(datetime_object.year) + ' ' + time.strftime('%H:%M:%S', datetime_object.timetuple())
        if short and not include_time:
            return SHORTDAYS[datetime_object.weekday()] + ' ' + str(datetime_object.day) + ' ' + MONTHS[datetime_object.month - 1]
        if not short and include_time:
            return DAYS[datetime_object.weekday()] + ', ' + str(datetime_object.day) + ' ' + MONTHS[datetime_object.month - 1] + ' ' + time.strftime('%H:%M:%S', datetime_object.timetuple())
        if not short and not include_time:
            return DAYS[datetime_object.weekday()] + ', ' + str(datetime_object.day) + ' ' + MONTHS[datetime_object.month - 1]
    else:
        return datetime_object


def seconds_to_hms(seconds):
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    return (h, m, s)


def hms_to_time(h, m, s):
    return datetime.time(h, m, s)


def seconds_to_time(seconds):
    h, m, s = seconds_to_hms(seconds)
    return hms_to_time(h, m, s)


def week_number(year, month, day, offset = True):
    start_week_day = cfg.pos_first_day_of_week.get()
    if offset:
        day = datetime.datetime(year, month, day) + datetime.timedelta(days=cfg.pos_week_offset.get() * 7)
    else:
        day = datetime.datetime(year, month, day)
    iso_year, iso_week, iso_day = day.isocalendar()
    if start_week_day != 1:
        start_week_day_iso = start_week_day
        if start_week_day == 0:
            start_week_day_iso = 7
        if start_week_day_iso > iso_day:
            iso_year, iso_week, iso_day = (day - datetime.timedelta(days=7)).isocalendar()
    return iso_week


def merge_content(dest_cpls, source_cpls):
    """
    Merges a dictionary of content with another; relies on the dictionaries
    being in the format as specified by the _device_get_content_information() function.
    
    This is based on the fact that only the device-specific portions of the dictionary
    will change and modifies the destination dictionary by those pieces only, or copies
    over any missing content in its entirety.
    """
    diff_cpls = set(source_cpls.keys()) - set(dest_cpls.keys())
    for cpl_id in diff_cpls:
        dest_cpls[cpl_id] = source_cpls[cpl_id]

    intersect_cpls = set(source_cpls.keys()) & set(dest_cpls.keys())
    for cpl_id in intersect_cpls:
        for device_id in source_cpls[cpl_id]['devices'].keys():
            dest_cpls[cpl_id]['devices'][device_id] = source_cpls[cpl_id]['devices'][device_id]


def validate_pack_events(event_list):
    for event in event_list:
        if 'type' not in event:
            event['type'] = 'composition'
        for required_key in ('cpl_id', 'text', 'edit_rate', 'duration_in_seconds', 'duration_in_frames'):
            if required_key not in event:
                event[required_key] = None

        if 'automation' not in event:
            event['automation'] = []

    return


def validate_playlist_events(event_list):
    for event in event_list:
        if event == 'last_updated':
            continue
        for required_key in ('type', 'cpl_id', 'text', 'content_kind', 'edit_rate', 'duration_in_seconds', 'duration_in_frames'):
            if required_key not in event:
                event[required_key] = None

        if 'automation' not in event:
            event['automation'] = []

    return


def get_playlist_cpl_uuids(playlist):
    """
    Given a playlist dictionary containing an events list,
    this method returns a list containing the cpl id of each event.
    If the event has a cpl uuid of None, this is also added to the list.
    This is because the list is sometimes used to find the position of
    a cpl in the playlist.
    :param playlist: dictionary containing a key 'events' - a list of
            playlist events
    :returns: a list of the cpl ids
    
    e.g.  ['fsdf-ufds-csfd-kdwsef', ...] etc
    """
    cpl_ids = []
    events = playlist.get('events', [])
    for event in events:
        cpl_id = event.get('cpl_id')
        cpl_ids.append(cpl_id)

    return cpl_ids


def get_intermission_playlist(automation, device = None):
    device_type = device.device_configuration['type'] if device else 'christie'
    if device_type == 'doremi':
        return device.playlist_information.get(automation['type_specific']['spl_uuid'], {})
    playlist_name = automation['type_specific']['spl_title']
    all_playlists = cherrypy.core.playlist_service.playlist()[0]
    for playlist in flatten_dict(all_playlists):
        if playlist['title'] == playlist_name:
            return playlist

    return {}


def audit_log(msg, tags = [], meta = {}, *args, **kwargs):
    """
    Convenience function for logging audit info
    """
    if cfg.audit_log_enabled():
        user = cherrypy.request.user['username'] if hasattr(cherrypy, 'request') and hasattr(cherrypy.request, 'user') else None
        ip = cherrypy.request.remote.ip if hasattr(cherrypy, 'request') and hasattr(cherrypy.request, 'remote') and hasattr(cherrypy.request.remote, 'ip') else '<NO_IP_INFO>'
        cherrypy.core.log_manager.collect_audit_logs(user, ip, msg, tags=tags, meta=meta)
    return


def packaging_log(msg, *args, **kwargs):
    """
    Convenience function for logging dcp repackaging info
    """
    packaging_logger = logging.getLogger('packaging')
    packaging_logger._log(logging.PACKAGING, msg, args, extra=None, **kwargs)
    return


def watchfolder_log(msg, *args, **kwargs):
    """
    Convenience function for logging watchfolder info
    """
    watchfolder_logger = logging.getLogger('watchfolder')
    watchfolder_logger._log(logging.WATCHFOLDER, msg, args, extra=None, **kwargs)
    return


def marker_clip_templating_log(msg, *args, **kwargs):
    """
    Convenience function for logging marker clip templating info
    """
    marker_clip_templating_logger = logging.getLogger('marker_clip_templating')
    marker_clip_templating_logger._log(logging.MARKER_CLIP_TEMPLATING, msg, args, extra=None, **kwargs)
    return


def get_screen(device_uuid):
    for screen in cherrypy.core.screens.itervalues():
        if device_uuid in screen['devices']:
            return screen


def console_status(done, total, only_every_percent = False):
    if only_every_percent:
        divisor = total / 100
        if divisor != 0 and done % divisor != 0:
            return
    progress = int(float(done) / float(total) * 100) if total != 0 else 100
    bar = '|' + progress * '=' + (100 - progress) * ' ' + '|' + str(progress) + '%'
    bar = bar + '\n' if ' ' not in bar else bar
    try:
        sys.stdout.write('\r' + bar)
        sys.stdout.flush()
    except IOError:
        pass


def safe_directory_name(unsafe_name):
    """
    Escapes a folder name for Windows/Unix
    This is because e.g. Windows disallows certain characters (?/:* etc.) and has reserved names (nul, con etc.)
    http://msdn.microsoft.com/en-us/library/aa365247.aspx
    """
    if unsafe_name.upper() in ('CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9', 'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'):
        unsafe_name += '_safe'
    safe_name = escape(unsafe_name, {'/': '_fslash_',
     '\\': '_bslash_',
     '*': '_star_',
     ':': '_colon_',
     '"': '_quote_',
     '|': '_pipe_',
     ' ': '_',
     '.': '_dot_',
     '?': '_quest_'})
    return safe_name[:255]


def all_files(path):
    paths = set()
    for root, dirs, files in os.walk(path):
        paths.update((os.path.join(root, name) for name in files))

    return paths


def sqlite_chunk(all):
    """
    Chunks a list into sqlite-manageable lists, since it has a limit of 999 parameters
    """
    return [ all[x:x + 950] for x in xrange(0, len(all), 950) ]


def flatten_dict(dict_):
    """
    Flattens a >= 2-deep nested dict, returning values from level 2
    Great for eliminating nested for loops when dealing with stuff which is grouped by device, like playlists
    e.g. {
    "41e72236-8e4c-46c6-b376-b047d8228b11":{
        "08858eb0-8553-45ee-b83d-ff8e803ac7ff":{
            "playlist": {...}
        },
        "ddc4816b-da32-4817-9d9e-4bdcb725c858":{
            "playlist": {...}
        },
    },
    "b83beb43-b7b1-4593-a36d-7f28b2bf1c32":{
        "8683fa11-e849-3d2a-add9-fe335aaaaf96":{
            "playlist": {...}
        },
    }
    would return an iterable of a list containing all the playlists
    """
    for it in dict_.itervalues():
        for element in it.itervalues():
            yield element


def multipassify_string(base_string):
    """
    Appends _[multipass_version_num] to a string if multipass is running
    """
    if hasattr(cherrypy, 'multipass_version'):
        return base_string + '_%s' % cherrypy.multipass_version
    return base_string


def tstamp(datetime_obj):
    """
    Converts a py datetime object into a unix timestamp
    """
    return time.mktime(datetime_obj.timetuple())


class BatchFlushChecker(object):
    """
    Checks whether a queue should be flushed given how long since the last flush and how large the queue is
    """

    def __init__(self, batch_size = 50, timeout = 20):
        self.batch_size = batch_size
        self.timeout = datetime.timedelta(minutes=timeout)
        self.update_last_flushed()

    def should_flush(self, list_size, live_queue_size, auto_update = True):
        timeout = datetime.datetime.now() - self.last_flush > self.timeout
        sizeout = list_size >= self.batch_size
        if (timeout or sizeout) and live_queue_size == 0 and list_size > 0:
            should = not cherrypy.engine.shutdown_servers
            should and auto_update and self.update_last_flushed()
        return should

    def update_last_flushed(self):
        self.last_flush = datetime.datetime.now()


class CsvWriter(object):
    """
    Helps with csv writing
    """

    def __init__(self, filename, response):
        self.filename = filename + '.csv'
        self.response = response
        self.output = u''

    def set_columns(self, *column_names):
        """Friendly alias for write_line"""
        self.write_line(*column_names)

    def write_line(self, *fields):
        self.output += ', '.join(map(str, fields))
        self.output += '\n'

    def get_output(self):
        self._set_headers()
        return self.output

    def _set_headers(self):
        self.response.headers['Content-Type'] = 'text/csv'
        self.response.headers['Content-Disposition'] = 'attachment;filename=' + self.filename


class DeviceStat(object):
    """
    Stores stats about Device syncing - count, and size of calls in MB (if available)
    Logs anything suspect
    """

    def __init__(self, device_name, size_log = 25, size_threshold = 5, count_log = 10000, time_threshold = 0.5):
        """
        :param size_threshold: Log calls larger than this, in MB
        :param count_threshold: Log every this many calls
        """
        self.device_name = device_name
        self.size_threshold = size_threshold
        self.size_log = size_log
        self.count_log = count_log
        self.time_threshold = time_threshold
        self.log_period_counts_start = time.time()
        self.log_period_sizes_start = time.time()
        self.call_counts = defaultdict(int)
        self.call_sizes = defaultdict(float)
        self.call_count_total = 0
        self.call_size_total = 0
        self.enabled = False

    def toggle(self):
        self.enabled = not self.enabled
        return self.enabled

    def stat_size(self, method, size):
        if not self.enabled:
            return
        if not size:
            return
        size_mb = int(size) / 1024.0 / 1024.0
        self.call_sizes[method] += size_mb
        self.call_size_total += size_mb
        if size_mb > self.size_threshold:
            msg = '[%s] MB response length for [%s]: [%s]' % (size_mb, self.device_name, method)
            logging.warn(msg)
            print msg
        if self.call_size_total > self.size_log:
            hrs_since_last = (time.time() - self.log_period_sizes_start) / 3600.0
            self.call_size_total = 0
            self.call_sizes.clear()
            self.log_period_sizes_start = time.time()
            msg = '[%s] MB throughput reached for [%s] in [%s] hrs' % (self.count_size, self.device_name, hrs_since_last)
            logging.info(msg)
            print msg
            if hrs_since_last < self.time_threshold:
                logging.warn(msg)

    def stat_count(self, method):
        if not self.enabled:
            return
        self.call_counts[method] += 1
        self.call_count_total += 1
        if self.call_count_total > self.count_log:
            hrs_since_last = (time.time() - self.log_period_counts_start) / 3600.0
            self.call_count_total = 0
            self.call_counts.clear()
            self.log_period_counts_start = time.time()
            cnt_msg = '[%s] calls reached for [%s] in [%s] hrs' % (self.count_log, self.device_name, hrs_since_last)
            logging.info(cnt_msg)
            print cnt_msg
            if hrs_since_last < self.time_threshold:
                logging.warn(cnt_msg)


class RemoteParser:

    def execute(self, getter, parser):
        i, o = Pipe()
        p = RemoteParseProcess(o, getter, parser)
        p.start()
        success, re = i.recv()
        p.join()
        p.terminate()
        if not success:
            return (success, {'type': 'error',
              'message': re})
        else:
            return (success, re)


class RemoteParseProcess(Process):

    def __init__(self, pipe, getter, parser):
        super(RemoteParseProcess, self).__init__()
        self.pipe = pipe
        self.getter = getter
        self.parser = parser

    def run(self):
        success = False
        try:
            re = self.getter.get()
            if self.parser:
                re = self.parser.parse(re)
            success = True
        except Exception as e:
            re = str(e)

        self.pipe.send((success, re))


class HTTPGetter:

    def __init__(self, ip, url):
        self.ip = ip
        self.url = url

    def get(self):
        try:
            domain = httplib.HTTPConnection(self.ip, timeout=10)
            domain.connect()
            domain.request('GET', self.url)
            response = domain.getresponse()
            if response.status != 200:
                raise httplib.HTTPException('Error making request: %s, %s' % (response.status, response.reason))
            return response.read()
        finally:
            if 'domain' in locals():
                domain.close()


class Timer:

    def __init__(self, start = True):
        self.times = {}
        if start:
            self.start()

    def start(self):
        self.started = True
        self.time = time.time()

    def lap(self, label):
        if not self.started:
            self.start()
        now = time.time()
        x = now - self.time
        self.times.setdefault(label, []).append(x)
        self.time = now

    def stop(self):
        if self.started:
            self._dump()
            self.started = False

    def _dump(self):
        for label, times in self.times.iteritems():
            tot = sum(times)
            cou = len(times)
            avg = tot / cou
            msg = str(label) + ': {0:.6f}'.format(avg) + ' (%s) - %s' % (cou, tot)
            print msg
            logging.warn(msg)


def get_transfer_time(scheduled_start_stamp = 0, not_before_stamp = None):
    """
    Given the start time of a show and the not_before value assigned to the content transfer,
    check the configuration values and decide when is best to actually transfer the content.
    Eg. cfg might say "tonight" but if the show starts in 30 mins that's useless to us.
    """
    if not_before_stamp and str(not_before_stamp) != 'tonight' and str(not_before_stamp) != 'ASAP':
        return not_before_stamp
    tonight_hour = cfg.core_tonight_hour()
    tonight_minute = cfg.core_tonight_minute()
    now = datetime.datetime.now()
    minutes_now = now.minute + now.hour * 60
    minutes_tonight = tonight_hour * 60 + tonight_minute
    tonight = datetime.datetime(now.year, now.month, now.day, tonight_hour, tonight_minute, 0)
    if minutes_now > minutes_tonight:
        tonight += datetime.timedelta(days=1)
    tonight = time.mktime(tonight.timetuple())
    if scheduled_start_stamp <= tonight or str(not_before_stamp) == 'ASAP' or not_before_stamp is None and cfg.core_auto_transfer_content_asap.get():
        return time.mktime(now.timetuple())
    else:
        return tonight


def create_screen_or_device_uuid(device, mac_addresses = []):
    """
    Create a consistent UUID for a device/screen.
    Use MAC address if available
    """
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, str(device.get('ip', '')) + str(device.get('type', '')) + str(device.get('category', '')) + str(device.get('ftp_ip', '')) + str(device.get('name', '')) + str(device.get('title', '')) + str(device.get('path', '')) + str(device.get('port', '')) + str(mac_addresses[0] if mac_addresses else '')))


def get_complex_device_uuids_from_metadata(metadata, mac_addresses):
    """
    Pull list of complex device uuids from device metadata JSON
    """
    device_uuids = []
    for device in metadata.get('complex_devices', []):
        device_uuids.append(create_screen_or_device_uuid(device, mac_addresses))

    return device_uuids


def get_screen_uuids_from_metadata(metadata, mac_addresses):
    """
    Pull list of complex device uuids from device metadata JSON
    """
    screen_uuids = []
    for screen in metadata.get('screens', []):
        screen_uuids.append(create_screen_or_device_uuid(screen, mac_addresses))

    return screen_uuids
# okay decompyling ./lib/utilities/helper_methods.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:22 CST
