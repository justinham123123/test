# 2017.08.13 21:52:25 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\show_attribute_utils.py
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm.exc import NoResultFound
from serv.lib.utilities.helper_methods import make_uuid5

def clean(some_string):
    """ Helper utility to 'clean up' a string for use in show attributes / maps
    
    :param some_string: input string
    :returns: a trimmed/uppercased version of the input string
    """
    return some_string.upper().strip()


def gen_ex_sam_uuid(source, external_id):
    """Generates a consistent UUID for an ExternalShowAttributeMap.
    
    :param string source: The source of the ExternalShowAttributeMap.
    :param string external_id: The identifier of the external show attribute
                               according to the source.
    :returns string: The UUID for the external show attribute map.
    """
    return make_uuid5(source, external_id)


def gen_sa_uuid(sa_name):
    """Generates a consistent UUID for a ShowAttribute based on its name.
    
    :param string sa_name: The ShowAttribute name.
    :returns string: The UUID for the show attribute.
    """
    return make_uuid5(clean(sa_name))


class ShowAttributeUtils(object):

    def __init__(self, db):
        self.db = db

    def _get_exam_uuid(self, ex_sam_dict):
        """Returns the uuid of an external show attribute based on it's data."""
        source = ex_sam_dict['source']
        external_id = ex_sam_dict['external_id']
        return gen_ex_sam_uuid(source, external_id)

    def _create_exsam(self, ex_sam_dict):
        """
        Creates an external show attribute map using the the supplied data
        but does NOT commit it to the database.
        """
        new_uuid = self._get_exam_uuid(ex_sam_dict)
        db_ex_sam = self.lookup_exsam(exsam_uuid=new_uuid)
        if not db_ex_sam:
            db_ex_sam = self.db.ExternalShowAttributeMap()
        ex_sam_dict['uuid'] = new_uuid
        self._populate_ex_sam(db_ex_sam, ex_sam_dict)
        self.db.Session.merge(db_ex_sam)
        return db_ex_sam

    def _populate_ex_sam(self, db_ex_sam, ex_sam_dict):
        """Used internally to populate an ex_sam with data."""
        db_ex_sam.from_dict(ex_sam_dict)

    def update(self, sa_dict, sa_uuid = None, sa_name = None):
        """Updates a show attribute using the data in the supplied dictionary.
        
        :param sa_dict: dictionary containing the new/updated show attribute fields
        :param sa_uuid: (original) uuid of the show attribute to be updated, optional
        :param sa_name: (original) name of the show attribute to be updated, optional
        :raises: ShowAttributeNotFound if no matching show attribute was located
        
        Note: sa_uuid or sa_name must be specified  - this is used to locate
        the show attribute that will be updated with the data in the supplied
        dictionary
        
        Note: the uuid may change, as it is generated off the name
        Note: the aam ex_sam will be updated with a new UUID and EXTERNAL_ID
        Note: other ex_sams mapped to the show attribute will remain mapped
              to this show attribute, via the new name
        """
        if not (sa_uuid or sa_name):
            raise AssertionError
            sa = self.lookup(sa_uuid=sa_uuid, sa_name=sa_name)
            original_name = sa.name if sa else None
            original_uuid = sa.uuid if sa else None
            sa_dict['uuid'] = 'name' in sa_dict and gen_sa_uuid(sa_dict['name'])
            sa_dict['name'] = clean(sa_dict['name'])
        sa.from_dict(sa_dict)
        self.db.Session.commit()
        if original_uuid != sa.uuid:
            original_aam_ex_sam = None
            try:
                original_aam_ex_sam = self.db.Session.query(self.db.ExternalShowAttributeMap).filter_by(source='aam', external_id=original_name).one()
            except NoResultFound:
                pass

            new_aam_ex_sam = None
            try:
                new_aam_ex_sam = self.db.Session.query(self.db.ExternalShowAttributeMap).filter_by(source='aam', external_id=sa.name).one()
            except NoResultFound:
                pass

            if new_aam_ex_sam and original_aam_ex_sam:
                pack_attribute_maps = self.db.Session.query(self.db.PackAttributeMap).filter(self.db.PackAttributeMap.external_show_attribute_map_uuid == sa_uuid)
                for pam in pack_attribute_maps:
                    pam.external_show_attribute_map_uuid = new_aam_ex_sam.uuid

                new_aam_ex_sam.show_attribute_uuid = sa.uuid
                self.db.Session.delete(original_aam_ex_sam)
                self.db.Session.commit()
            elif new_aam_ex_sam:
                new_aam_ex_sam.show_attribute_uuid = sa.uuid
            elif original_aam_ex_sam:
                new_aam_ex_sam = original_aam_ex_sam
                new_aam_ex_sam.external_id = sa.name
                new_aam_ex_sam.uuid = gen_ex_sam_uuid('aam', sa.name)
                new_aam_ex_sam.show_attribute_uuid = sa.uuid
                self.db.Session.commit()
            else:
                new_aam_ex_sam = self.db.ExternalShowAttributeMap()
                self.db.Session.add(new_aam_ex_sam)
                new_aam_ex_sam.external_id = sa.name
                new_aam_ex_sam.source = 'aam'
                new_aam_ex_sam.uuid = gen_ex_sam_uuid('aam', sa.name)
                new_aam_ex_sam.show_attribute_uuid = sa.uuid
                self.db.Session.commit()
        self.db.Session.flush()
        return sa

    def create(self, sa_dict):
        """Creates and returns a show attribute and it's corresponding aam ex_sam.
        
         :param sa_dict: ShowAttribute dictionary
         :returns: class:`db.ShowAttribute` instance (database committed)
        
        Note:
             - Show Attribute UUIDs are always consistent/predictable
                   See: gen_sa_uuid()
        
             - If sa_dict contains 'uuid', then this is ignored &
               a new predictable uuid will be created
        
             - The 'name' field  of sa_dict is trimmed of whitespace
                   see: clean()
        """
        sa_uuid = gen_sa_uuid(sa_dict['name'])
        sa_dict['uuid'] = gen_sa_uuid(sa_dict['name'])
        sa_dict['name'] = clean(sa_dict['name'])
        try:
            sa = self.db.Session.query(self.db.ShowAttribute).filter_by(uuid=sa_uuid).one()
            sa.from_dict(sa_dict)
            self.db.Session.commit()
        except NoResultFound:
            sa = self.db.ShowAttribute()
            self.db.Session.add(sa)
            sa.from_dict(sa_dict)
            self.db.Session.commit()
            self.create_aam_exsam(sa)
            try:
                self.db.Session.commit()
                self.create_aam_exsam(sa)
            except IntegrityError:
                self.db.Session.rollback()
                sa = self.lookup(sa_name)
                sa.from_dict(sa_dict)
                self.db.Session.commit()

        return sa

    def delete(self, sa_uuid):
        """Deletes the specified show attribute & the corresponding aam ex_sam
        
        :param sa_uuid:  uuid of the :class:`db.ShowAttribute` to delete
        :returns: the name of the show attribute deleted (for display purposes)
        :raises NoResultFound - if an attribute with the supplied UUID wasn't found
        """
        raise sa_uuid or AssertionError
        sa = self.db.Session.query(self.db.ShowAttribute).filter(self.db.ShowAttribute.uuid == sa_uuid).one()
        try:
            for ex_sam in sa.external_show_attribute_maps:
                if ex_sam.source == 'aam':
                    self.db.Session.query(self.db.PackAttributeMap).filter(self.db.PackAttributeMap.external_show_attribute_map_uuid == ex_sam.uuid).delete('fetch')
                    self.db.Session.delete(ex_sam)
                else:
                    ex_sam.show_attribute_uuid = None

            self.db.Session.delete(sa)
            self.db.Session.commit()
        except SQLAlchemyError:
            self.db.Session.rollback()
            raise

        return sa.name

    def lookup(self, sa_uuid = None, sa_name = None):
        """Retrieves the show attribute specified by either UUID or name
        
        :param sa_uuid:uuid of the show attribute to retrieve
        :param sa_name:name of the show attribute to retrieve
        :return: instance of :class:`db.ShowAttribute`
        
        #Note: The name parameter is whitespace trimmed prior to use
        #throws MultipleResultsFound if more then one found for the name
        #throws NoResultFound if no match is found
        """
        if not (sa_uuid or sa_name):
            raise AssertionError
            if sa_uuid:
                return self.db.Session.query(self.db.ShowAttribute).filter_by(uuid=sa_uuid).one()
            return sa_name and self.db.Session.query(self.db.ShowAttribute).filter_by(name=clean(sa_name)).one()

    def lookup_exsam(self, exsam_uuid = None, source = None, external_id = None):
        """Retrieves the ExternalShowAttributeMap (from the database),
        
        :param exsam_uuid: optional, uuid of ex_sam to retrieve
        :param source: source
        :param external_id:  external_id
        :returns: an instance of the matching :class:`db.ExternalShowAttributeMap`,
        
        Attempts to locate the ex_sam using the uuid (if supplied), and if that
        fails, tries using the source & external_id (if supplied)
        """
        if not (exsam_uuid or source and external_id):
            raise AssertionError
            return exsam_uuid and self.db.Session.query(self.db.ExternalShowAttributeMap).get(exsam_uuid)
        return self.db.Session.query(self.db.ExternalShowAttributeMap).filter_by(external_id=external_id, source=source).first()

    def update_exsam(self, ex_sam_dict):
        """Updates/Creates the external show attribute map (ex_sam) using the the supplied data (dictionary).
        
        :param ex_sam_dict: a dictionary describing the external show attribute map
        
        TODO:  merge the update_exsam +  create_exsam into a single save_exsam method
               This will require an update to producer as well
        
         e.g.
            {
              "uuid": "<uuid of the ex_sam being updated *>",
              "source": "<string>",
              "external_id": "<string>",
              "show_attribute_uuid": "<uuid of show attribute matched against>" or None,
              ...
              ...
            }
        
        Note: a new uuid will be generated if the source or external_id changes
        :returns: instance of the updated :class:`db.ExternalShowAttributeMap`
        """
        source = ex_sam_dict['source']
        external_id = ex_sam_dict['external_id']
        original_uuid = ex_sam_dict.get('uuid')
        new_uuid = gen_ex_sam_uuid(source, external_id)
        db_ex_sam = self.lookup_exsam(original_uuid, source, external_id)
        if not db_ex_sam:
            return self.create_exsam(ex_sam_dict)
        ex_sam_dict['uuid'] = new_uuid
        db_ex_sam.from_dict(ex_sam_dict)
        self.db.Session.merge(db_ex_sam)
        self.db.Session.commit()
        return db_ex_sam

    def create_exsam(self, ex_sam_dict):
        """
        Creates the external show attribute map using the the supplied data
        and commits it to the database.
        
        :param ex_sam_dict: A dictionary describing the external show attribute
            map:
        
            .. code-block:: json
        
                {
                    "source": "<string>",
                    "external_id": "<string>",
                    "show_attribute_uuid": "<uuid of show attribute matched against> or None"
                }
        
        :returns: instance of the new ex_sam
        """
        db_ex_sam = self._create_exsam(ex_sam_dict)
        self.db.Session.commit()
        return db_ex_sam

    def create_aam_exsam(self, db_sa):
        """Creates a AAM external show attribute map, matched against the supplied  attribute.
        
        :param db_show_attribute: a show attribute
        :returns: instance of the newly created :class:`db.ExternalShowAttributeMap`
                {
                  'source': 'aam'
                  'external_id': show_attribute.uuid
                }
        """
        ex_sam_dict = {'source': 'aam',
         'external_id': db_sa.name,
         'show_attribute_uuid': db_sa.uuid}
        return self.create_exsam(ex_sam_dict)


class CachedAttributeUtils(ShowAttributeUtils):
    """
    Extends `ShowAttributeUtils` to add a cache for `ShowAttributes` and
    `ExternalShowAttributeMap` and avoid checking the database for every
    operation.
    """

    def __init__(self, *args, **kwargs):
        super(CachedAttributeUtils, self).__init__(*args, **kwargs)
        self._sa_uuid_cache = {}
        self._sa_name_cache = {}
        self._ex_sam_uuid_cache = {}
        self._ex_sam_id_cache = {}
        self.load_cache()

    def create(self, sa_dict):
        sa = super(CachedAttributeUtils, self).create(sa_dict)
        self._sa_uuid_cache[sa.uuid] = sa
        self._sa_name_cache[sa.name] = sa
        return sa

    def create_exsam(self, ex_sam_dict):
        ex_sam = super(CachedAttributeUtils, self).create_exsam(ex_sam_dict)
        self._ex_sam_uuid_cache[ex_sam.uuid] = ex_sam
        self._ex_sam_id_cache[ex_sam.source, ex_sam.external_id] = ex_sam
        return ex_sam

    def delete(self, sa_uuid):
        name = super(CachedAttributeUtils, self).delete(sa_uuid)
        self._sa_uuid_cache.pop(sa_uuid)
        self._sa_name_cache.pop(name)
        return name

    def load_cache(self):
        """
        Loads the ShowAttributes and ExternalShowAttributes from the database.
        
        Data is cached into different dictionaries to allow lookup:
          * `self._sa_uuid_cache`: ShowAttribute instances indexed by uuid.
          * `self._sa_name_cache`: ShowAttribute instances indexed by name.
          * `self._ex_sam_uuid_cache`: ExternalShowAttributeMap instances
                                       indexed by uuid.
          * `self._ex_sam_id_cache`: ExternalShowAttributeMap instances indexed
                                     by (source, external_id) pair.
        """
        raise NotImplementedError('Cache loading has not been implemented for {0}'.format(self.__class__.__name__))

    def lookup(self, sa_uuid = None, sa_name = None):
        if not (sa_uuid or sa_name):
            raise AssertionError
            if sa_uuid:
                sa = self._sa_uuid_cache.get(sa_uuid)
                raise sa is None and NoResultFound()
            return sa
        elif sa_name:
            sa = self._sa_name_cache.get(clean(sa_name))
            if sa is None:
                raise NoResultFound()
            return sa
        else:
            return

    def lookup_exsam(self, exsam_uuid = None, source = None, external_id = None):
        if not (exsam_uuid or source and external_id):
            raise AssertionError
            return exsam_uuid and self._ex_sam_uuid_cache.get(exsam_uuid)
        return self._ex_sam_id_cache.get((source, external_id))

    def update(self, sa_dict, sa_uuid = None, sa_name = None):
        new_sa = super(CachedAttributeUtils, self).update(sa_dict, sa_uuid, sa_name)
        cache = self._sa_uuid_cache if sa_uuid else self._sa_name_cache
        key = sa_uuid if sa_uuid else sa_name
        sa = cache[key]
        if sa.uuid != new_sa.uuid or sa.name != new_sa.name:
            self._sa_uuid_cache.pop(sa.uuid)
            self._sa_name_cache.pop(sa.name)
            self._sa_uuid_cache[new_sa.uuid] = new_sa
            self._sa_name_cache[new_sa.name] = new_sa
        return new_sa

    def update_exsam(self, ex_sam_dict):
        new_ex_sam = super(CachedAttributeUtils, self).update_exsam(ex_sam_dict)
        source = ex_sam_dict['source']
        external_id = ex_sam_dict['external_id']
        original_uuid = ex_sam_dict.get('uuid')
        cache = self._ex_sam_uuid_cache if original_uuid else self._ex_sam_id_cache
        key = original_uuid if original_uuid else (source, external_id)
        ex_sam = cache[key]
        if ex_sam.uuid != new_ex_sam.uuid or ex_sam.external_id != new_ex_sam.external_id or ex_sam.source != new_ex_sam.source:
            self._ex_sam_uuid_cache.pop(ex_sam.uuid)
            self._ex_sam_id_cache.pop((ex_sam.source, ex_sam.external_id))
            self._ex_sam_uuid_cache[new_ex_sam.uuid] = new_ex_sam
            self._ex_sam_id_cache[new_ex_sam.source, new_ex_sam.external_id] = new_ex_sam
        return new_ex_sam
# okay decompyling ./lib/utilities/show_attribute_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:26 CST
