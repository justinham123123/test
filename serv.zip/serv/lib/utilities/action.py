# 2017.08.13 21:52:17 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\action.py
import uuid

class Action(object):
    """This Action object has been created to encapsulate different actions that are
    performed in the system, and to enable us to define behaviour based on action type.
    """
    report_messages = True

    def __init__(self, function, *args, **kwargs):
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.action_id = str(uuid.uuid4())
        self.success = None
        self.messages = []
        return

    def __call__(self):
        self.success, self.messages = self.function(*self.args, **self.kwargs)
        return (self.success, self.messages)

    @property
    def name(self):
        return self.function.__name__


class SyncAction(Action):
    """This is an action used to sync statuses and information within TMS. 
    A SyncAction may produce messages when called, but we generally do not 
    care about them in the context of the TMS.
    """
    report_messages = False
# okay decompyling ./lib/utilities/action.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:17 CST
