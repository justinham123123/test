# 2017.08.13 21:52:23 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\log_util.py
import logging, os
from serv import POSIX, WIN32
if WIN32:
    import msvcrt
    import _subprocess
    import codecs

    def duplicate(handle, inheritable = False):
        target_process = _subprocess.GetCurrentProcess()
        return _subprocess.DuplicateHandle(_subprocess.GetCurrentProcess(), handle, target_process, 0, inheritable, _subprocess.DUPLICATE_SAME_ACCESS).Detach()


    class NewRotatingFileHandler(logging.handlers.RotatingFileHandler):
        """
        Rotating file handler that works with Windows
        """

        def _open(self):
            """
            Open the current base file with the (original) mode and encoding.
            Return the resulting stream.
            """
            if self.encoding is None:
                stream = open(self.baseFilename, self.mode)
                newosf = duplicate(msvcrt.get_osfhandle(stream.fileno()), inheritable=False)
                newFD = msvcrt.open_osfhandle(newosf, os.O_APPEND)
                newstream = os.fdopen(newFD, self.mode)
                stream.close()
                return newstream
            else:
                stream = codecs.open(self.baseFilename, self.mode, self.encoding)
                return stream


else:
    NewRotatingFileHandler = logging.handlers.RotatingFileHandler

class CallbackLogHandler(logging.Handler):
    """
    Takes a function which gets executed when the logger emits a log.
    Record object is passed to the function.
    """

    def __init__(self, callback):
        logging.Handler.__init__(self)
        self.callback = callback

    def emit(self, record):
        self.callback(record)
# okay decompyling ./lib/utilities/log_util.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:23 CST
