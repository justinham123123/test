# 2017.08.13 21:52:23 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\make_hash.py
import copy

def make_hash(o):
    """
    Makes a hash from a dictionary, list, tuple or set to any level, that contains
    only other hashable types (including any lists, tuples, sets, and
    dictionaries).
    """
    if isinstance(o, set) or isinstance(o, tuple) or isinstance(o, list):
        return hash(tuple([ make_hash(e) for e in o ]))
    if not isinstance(o, dict):
        return hash(o)
    new_o = copy.deepcopy(o)
    for k, v in new_o.items():
        new_o[k] = make_hash(v)

    return hash(tuple(frozenset(new_o.items())))
# okay decompyling ./lib/utilities/make_hash.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:23 CST
