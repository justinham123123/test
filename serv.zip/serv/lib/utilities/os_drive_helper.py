# 2017.08.13 21:52:24 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\os_drive_helper.py
import logging, os, re, sys
from subprocess import Popen, PIPE
SYSTEM_ENCODING = sys.getfilesystemencoding()
drive_types = {0: 'unknown',
 1: 'unknown',
 2: 'usb',
 3: 'drive',
 4: 'network',
 5: 'cd',
 'file': 'drive',
 'ext3': 'drive',
 'ext2': 'drive',
 'vfat': 'usb',
 'fat': 'usb',
 'fuse': 'network',
 'curlftpfs': 'network',
 'ntfs-3g': 'network',
 'iso6990': 'cd',
 'udf': 'cd',
 'ftp': 'network'}
if os.name == 'nt':
    import win32api, win32file

def _parse_df_output(df_output_lines):
    """
    Parses the output of the UNIX 'df -a' command
    df_output should be an array of individual lines
    outputted by the 'df' command
    
    Tested on Ubuntu Server 10.4 and MacOSX 10.6
    """
    if len(df_output_lines) > 0 and len(df_output_lines[0].split()) > 6:
        dict_keys = ('file_system', 'blocks', 'used', 'available', 'Capacity', 'iused', 'ifree', 'used', 'mount_point')
        pattern = re.compile('(.*?)\\s+(\\d*?)\\s+(\\d*?)\\s+(\\d*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*)')
    else:
        dict_keys = ('file_system', 'blocks', 'used', 'available', 'used', 'mount_point')
        pattern = re.compile('(.*?)\\s+(\\d*?)\\s+(\\d*?)\\s+(\\d*?)\\s+(.*?)\\s+(.*)')
    matches = filter(lambda s: pattern.search(s), df_output_lines)
    drives = map(lambda s: pattern.findall(s)[0], matches)
    return map(lambda s: dict(zip(dict_keys, s)), drives)


def execute_df():
    """
    Executes "df -a" and returns the output as a dict
    
    @return [{'available': <available blocks>,
              'mount_point': <drive mount point>,
              'used': <% used>, 'blocks': <block count>,
              'file_system': <file system>}]
    """
    with Popen(['df -a'], shell=True, stdout=PIPE).stdout as pipe:
        return _parse_df_output(pipe.readlines()[1:])


def _parse_mount_output(mnt_output_lines):
    r""" 
    Parses the output of the UNIX 'mount' command
    df_output should be an array of individual lines
    outputted by the 'mount' command
    Pattern matching for Linux: on\s+(.*?) type (.*?)\s+
    Pattern matching for Mac: on\s+(.*?) \((.*?),
    
    Tested on Ubuntu Server 10.4 and MacOSX 10.6
    """
    pattern = re.compile('on\\s+(.*?) (?:(?:\\((.*?),)|(?:type (.*?)\\s+))')
    matches = filter(lambda s: pattern.search(s), mnt_output_lines)
    drives = map(lambda s: pattern.findall(s)[0], mnt_output_lines)
    drives = [ filter(lambda x: x, d) for d in drives ]
    dict_keys = ('mount_point', 'type')
    return map(lambda s: dict(zip(dict_keys, s)), drives)


def execute_mount():
    """
    Executes "mount" and returns the output as a dict
    
    @return [{'mount_point': <mount point>, 'type': <type>}]
    """
    with Popen('mount', shell=True, stdout=PIPE).stdout as pipe:
        return _parse_mount_output(pipe.readlines()[1:])


def __get_unix_drive_types():
    """
    Retrieve the drive types using the 'mount' command
    """
    types = {}
    try:
        for drive in execute_mount():
            types[drive['mount_point']] = drive_types.get(drive['type'], 'drive')

    except Exception:
        logging.error('There is a problem getting unix_drive_types', exc_info=True)

    return types


def get_os_mounted_drives():
    """
    Return a drive list
    
    @return [(drive_identifier, drive_path, drive_type)]
    """
    drives = []
    if os.name == 'nt':
        drive_strings = win32api.GetLogicalDriveStrings()
        drive_string_list = drive_strings.split('\x00')[:-1]
        for drive_string in drive_string_list:
            drive = drive_string.decode(SYSTEM_ENCODING)
            drives.append((drive, drive_types[win32file.GetDriveType(drive_string)]))

    else:
        types = __get_unix_drive_types()
        for drive_mnt in [ d['mount_point'] for d in execute_df() ]:
            if drive_mnt:
                type = types.get(drive_mnt, 'drive')
                drives.append((drive_mnt, type))

    return drives
# okay decompyling ./lib/utilities/os_drive_helper.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:25 CST
