# 2017.08.13 21:52:26 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\utilities\utils.py
"""
A set of utility functions
"""
from array import array
from collections import defaultdict
from operator import itemgetter
from struct import pack, unpack
from urlparse import urlparse
import logging
import os
import re
import socket
import traceback
import threading
import subprocess
from time import sleep

def async_execute(callback, *args):
    """Execute callback asynchroneously post-and-forget style."""

    def worker():
        try:
            callback(*args)
        except:
            logging.warning('Error in async call', exc_info=True)

    threading.Thread(target=worker).start()


def byte_array_test(byte_array):
    """
    helper method to give the byte representation of a string
    """
    if isinstance(byte_array, str):
        output = []
        for i in range(len(byte_array)):
            output.append(ord(byte_array[i]))

        return output
    else:
        return 'NOT IMPLEMENTED'


def byte_array_test_2(byte_array):
    """
    helper method to give the byte representation of a string
    """
    if isinstance(byte_array, str):
        output = []
        for i in range(len(byte_array)):
            output.append(byte_array[i])

        return output
    else:
        return 'NOT IMPLEMENTED'


def byte_array_2_word(byte_array):
    r"""
    Converts a 4 byte array (either as a string or an array) to a 32-bit unsigned int; assumes big-endian form
    
    Test with misc. string byte arrays:
        >>> byte_array_2_word('\x00\x00\x00\x01')
        1
        >>> byte_array_2_word('\x00\x00\x01\x01')
        257
        >>> byte_array_2_word('\x00\x01\x01\x01')
        65793
    
    Test with misc. array byte arrays:
        >>> byte_array_2_word(array('B', (0, 0, 0, 1)))
        1
        >>> byte_array_2_word(array('B', (0, 0, 1, 1)))
        257
        >>> byte_array_2_word(array('B', (0, 1, 1, 1)))
        65793
    
    Test incorrect type error:
        >>> byte_array_2_word(123)
        Traceback (most recent call last):
        ...
        TypeError
    """
    if isinstance(byte_array, str):
        return unpack('>I', pack('>BBBB', ord(byte_array[0]), ord(byte_array[1]), ord(byte_array[2]), ord(byte_array[3])))[0]
    if hasattr(byte_array, '__getitem__'):
        return unpack('>I', pack('>BBBB', byte_array[0], byte_array[1], byte_array[2], byte_array[3]))[0]
    raise TypeError


def byte_array_2_little_endian_word(byte_array):
    if isinstance(byte_array, str):
        return unpack('<I', pack('<BBBB', ord(byte_array[0]), ord(byte_array[1]), ord(byte_array[2]), ord(byte_array[3])))[0]
    if hasattr(byte_array, '__getitem__'):
        return unpack('<I', pack('<BBBB', byte_array[0], byte_array[1], byte_array[2], byte_array[3]))[0]
    raise TypeError


def byte_array_2_short(byte_array):
    if isinstance(byte_array, str):
        return unpack('>h', pack('>BB', ord(byte_array[0]), ord(byte_array[1])))[0]
    if hasattr(byte_array, '__getitem__'):
        return unpack('>h', pack('>BB', byte_array[0], byte_array[1]))[0]
    raise TypeError


def byte_array_2_long(byte_array):
    if isinstance(byte_array, str):
        return unpack('>Q', pack('>BBBBBBBB', ord(byte_array[0]), ord(byte_array[1]), ord(byte_array[2]), ord(byte_array[3]), ord(byte_array[4]), ord(byte_array[5]), ord(byte_array[6]), ord(byte_array[7])))[0]
    if hasattr(byte_array, '__getitem__'):
        return unpack('>Q', pack('>BBBBBBBB', byte_array[0], byte_array[1], byte_array[2], byte_array[3], byte_array[4], byte_array[5], byte_array[6], byte_array[7]))[0]
    raise TypeError


def byte_array_2_little_endian_long(byte_array):
    if isinstance(byte_array, str):
        return unpack('<Q', pack('<BBBBBBBB', ord(byte_array[0]), ord(byte_array[1]), ord(byte_array[2]), ord(byte_array[3]), ord(byte_array[4]), ord(byte_array[5]), ord(byte_array[6]), ord(byte_array[7])))[0]
    if hasattr(byte_array, '__getitem__'):
        return unpack('<Q', pack('<BBBBBBBB', byte_array[0], byte_array[1], byte_array[2], byte_array[3], byte_array[4], byte_array[5], byte_array[6], byte_array[7]))[0]
    raise TypeError


def word_2_byte_array(word):
    """
    Converts a 32-bit int to a byte array in big-endian form
    
    Test misc. 32-bit ints:
        >>> word_2_byte_array(1)
        (0, 0, 0, 1)
        >>> word_2_byte_array(257)
        (0, 0, 1, 1)
        >>> word_2_byte_array(65793)
        (0, 1, 1, 1)
    """
    return unpack('>BBBB', pack('>I', word))


def long_2_byte_array(longLong):
    """
    Converts a 64-bit long to a byte array in big-endian form
    """
    return unpack('>BBBBBBBB', pack('>Q', longLong))


def long_2_byte_array_little_endian(longLong):
    """
    Converts a 64-bit long to a byte array in big-endian form
    """
    return unpack('<BBBBBBBB', pack('<Q', longLong))


def short_2_byte_array(short):
    return unpack('>BB', pack('>H', short))


def uuid_bytes_2_canonical(some_bytes):
    r"""
    Creates a canonical representation of a byte-represented UUID
    
    Test a canonical UUID:
        >>> uuid_bytes_2_canonical('\xf8\x1dO\xae}\xec\x11\xd0\xa7e\x00\xa0\xc9\x1ek\xf6')
        'f81d4fae-7dec-11d0-a765-00a0c91e6bf6'
    """
    uuid = ''
    for byte in some_bytes[:4]:
        h = hex(ord(byte))[2:]
        if len(h) == 1:
            uuid += '0' + h
        else:
            uuid += h

    uuid += '-'
    for byte in some_bytes[4:6]:
        h = hex(ord(byte))[2:]
        if len(h) == 1:
            uuid += '0' + h
        else:
            uuid += h

    uuid += '-'
    for byte in some_bytes[6:8]:
        h = hex(ord(byte))[2:]
        if len(h) == 1:
            uuid += '0' + h
        else:
            uuid += h

    uuid += '-'
    for byte in some_bytes[8:10]:
        h = hex(ord(byte))[2:]
        if len(h) == 1:
            uuid += '0' + h
        else:
            uuid += h

    uuid += '-'
    for byte in some_bytes[10:16]:
        h = hex(ord(byte))[2:]
        if len(h) == 1:
            uuid += '0' + h
        else:
            uuid += h

    return uuid


def uuid_canonical_2_bytes(uuid_str):
    r"""
    Converts a UUID from its canonical form to an array of 16 bytes
    
    Test a canonical to bytes (return in string form to compare to uuid_bytes_2_canonical test):
        >>> uuid_canonical_2_bytes('f81d4fae-7dec-11d0-a765-00a0c91e6bf6').tostring()
        '\xf8\x1dO\xae}\xec\x11\xd0\xa7e\x00\xa0\xc9\x1ek\xf6'
    """
    if uuid_str == None:
        uuid_str = '00000000000000000000000000000000'
    else:
        uuid_str = uuid_str.replace('-', '')
    some_bytes = array('B')
    for i in xrange(0, len(uuid_str), 2):
        some_bytes.append(int(uuid_str[i:i + 2], 16))

    return some_bytes


def ip_to_little_endian_word(ip_str):
    """
    Converts a dotted quad notation IP address into
    a word in little endian format
    
    Returns - word
    
    Test an IP address:
        >>> ip_to_little_endian_word('192.168.10.50')
        839559360
    """
    return unpack('<L', socket.inet_aton(ip_str))[0]


def int_to_time(totalseconds):
    """
    Given a number of seconds,  this method returns a string
    that breaks it down into hours/minutes seconds in the format
    of hh:mm:ss
    
    Returns - string hh:mm:ss
    
    Test a seconds value:
        >>> int_to_time(5782)
        '01:36:22'
    """
    try:
        totalseconds = int(totalseconds)
    except (ValueError, TypeError):
        totalseconds = 0

    totalminuts, seconds = divmod(totalseconds, 60)
    hours, minutes = divmod(totalminuts, 60)
    return '%s:%s:%s' % (str(hours).zfill(2), str(minutes).zfill(2), str(seconds).zfill(2))


def check_response(some_dictionary):
    """
    Checks a TMS response dictionary for a key 'response' and returns True if
    this key exists and it has a positive/True value (which is 0 i.e. false
    and is thus backwards). Otherwise returns False
    
    Test TMS response dictionary:
        >>> check_response({'response' : 0})
        True
        >>> check_response({'response' : 1})
        False
        >>> check_response({'not_a_response' : 0})
        False
    """
    if some_dictionary and type(some_dictionary) == type({}):
        return not some_dictionary.get('response', True)
    return False


def sort_dictionary_list(dict_list, sort_key):
    """
    sorts a list of dictionarys based on the value of the
    'sort_key'
    
    someList - a list of dictionarys
    sort_key - a string that  identifies the common key in
               the dictionarys, to sort on.
    
    Test sorting a list of dictionaries:
        >>> sort_dictionary_list([{'b' : 1, 'value' : 2}, {'c' : 2, 'value' : 3}, {'a' : 3, 'value' : 1}], 'value')
        [{'a': 3, 'value': 1}, {'b': 1, 'value': 2}, {'c': 2, 'value': 3}]
    """
    if not dict_list or len(dict_list) == 0:
        return dict_list
    dict_list.sort(key=itemgetter(sort_key))
    return dict_list


traced_funcs = {}

def trace(func):
    """
    This function can be decorated on another function to
    add debug trace output
    """

    def wrapper(*args, **kwargs):
        log_string = 'Executing: %s(' % func.__name__
        for arg in args[1:]:
            log_string += '%s, ' % arg

        for arg, value in kwargs.items():
            log_string += '%s=%s, ' % (arg, value)

        if len(args) > 1 or kwargs:
            log_string = log_string[:-2]
        log_string += ')'
        logging.debug(log_string)
        return func(*args, **kwargs)

    try:
        traced_funcs[func.__name__] = func
    except:
        pass

    wrapper.__doc__ = func.__doc__
    return wrapper


def print_stack_trace_on_info():
    information = 'Debug stacktrace requested:\n'
    log_stmt = ''.join(traceback.format_list(traceback.extract_stack()[:-1]))
    logging.info(information + log_stmt)


def remove_thread_tags(func):
    """
    This function can be decorated on another function to
    remove threaded parameters
    """

    def wrapper(*args, **kwargs):
        output = func(*args, **kwargs)
        threading.currentThread().doremi_response_handler = None
        threading.currentThread().doremi_request_handler = None
        threading.currentThread().server_identifier = None
        threading.currentThread().time_start = None
        threading.currentThread().doremi_lock_count = None
        threading.currentThread().doremi_lock = None
        threading.currentThread().doremi_socket = None
        return output

    wrapper.__doc__ = func.__doc__
    return wrapper


def chunk(l, n):
    """
    Yield successive n-sized chunks from l.
    
    Useful for chunking input to SQL queries, which accept a maximum number of parameters
    """
    for i in xrange(0, len(l), n):
        yield l[i:i + n]


def synchronized(lock):
    """
    Synchronization decorator; provide thread-safe locking on a function
    http://code.activestate.com/recipes/465057/
    """

    def wrap(f):

        def synchronize(*args, **kw):
            lock.acquire()
            try:
                return f(*args, **kw)
            finally:
                lock.release()

        return synchronize

    return wrap


def parse_subject_name(subject_name):
    subject_name_parts = subject_name.split(',')
    subject_name_info = {}
    for part in subject_name_parts:
        part_name, part_value = part.split('=', 1)
        subject_name_info[part_name] = part_value

    return subject_name_info


def get_dnqualifier(subject_name):
    """
    Returns the dnQualifier from a subject name.
    
    Throws KeyError if dnQualifier cannot be parsed
    
    Can be done as reg expression, keep readable and be sure to RTFM
    http://www.openssl.org/docs/apps/x509.html
    """
    subject_parts = parse_subject_name(subject_name)
    dn_qualifier = subject_parts['dnQualifier']
    replace_anywhere = ['\\+',
     '\\,',
     '\\"',
     '\\<',
     '\\>',
     '\\;',
     '\\.']
    replace_at_beggining_or_end = ['\\ ', '\\#']
    for x in replace_anywhere:
        dn_qualifier = dn_qualifier.replace(x, x[1])

    for x in replace_at_beggining_or_end:
        if dn_qualifier.startswith(x):
            dn_qualifier = dn_qualifier.replace(x, x[1], 1)
        if dn_qualifier.endswith(x):
            dn_qualifier = dn_qualifier[:-2] + dn_qualifier[-1]

    return dn_qualifier


def extract_credentials(url):
    """
    Extracts a user's credentials from a url
    """
    u = urlparse(url)
    return ('%s://%s%s' % (u.scheme, u.hostname, u.path), u.username, u.password)


def duration_in_seconds_to_duration_in_frames(duration_in_seconds, edit_rate):
    """
        Returns the duration calaculated as a number of frames
    Params:
        duration_in_frames     - int
        edit_rate              - String (a_b)
    Returns:
       int        - number of seconds
    
    If an exception is thrown whilst calculating this, the duration is returned as None
    """
    duration = 0
    try:
        edit_rate_a = edit_rate[0]
        edit_rate_b = edit_rate[1]
        if int(edit_rate_a) > 0:
            duration = int(float(duration_in_seconds) * int(int(edit_rate_a) * int(edit_rate_b)))
    except Exception as ex:
        logging.error('exception in getting duration:%s' % str(ex))
        duration = None

    return duration


def strip_urn(_input):
    if _input:
        return _input.replace('urn:uuid:', '')
    else:
        return None


def wrap_urn(input):
    if not input.startswith('urn:uuid:'):
        return 'urn:uuid:' + input
    return input


def html_escape(text):
    """Produce entities within text."""
    html_escape_table = {'&': '&amp;',
     '"': '&quot;',
     "'": '&apos;',
     '>': '&gt;',
     '<': '&lt;'}
    return ''.join((html_escape_table.get(c, c) for c in text))


def defaultdict_set():
    return defaultdict(set)


def defaultdict_list():
    return defaultdict(list)


def get_macs():
    """
    Returns list of Mac addresses.
    """
    if os.name == 'posix':
        cmd = 'ifconfig'
    else:
        cmd = 'ipconfig /all'
    config = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE).stdout.read().lower()
    macs = []
    for mac in re.findall('((?:(?:[0-9a-f]){2}[-:]){5}(?:[0-9a-f]){2})', config, re.S):
        if mac != '00-00-00-00-00-00' and mac != '00:00:00:00:00:00':
            macs.append(mac.replace('-', ':'))

    return macs


def kill_process(pid):
    if os.name == 'posix':
        subprocess.Popen('kill -9 %i' % pid, shell=True)
    else:
        devnull = open(os.devnull, 'wb')
        subprocess.Popen('taskkill /F /PID %i' % pid, stderr=devnull, stdout=devnull)


certificate_regex = re.compile('-----BEGIN CERTIFICATE-----.+?-----END CERTIFICATE-----', re.MULTILINE | re.DOTALL)
# okay decompyling ./lib/utilities/utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:28 CST
