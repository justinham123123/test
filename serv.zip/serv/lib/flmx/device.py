# 2017.08.13 21:52:00 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\flmx\device.py
from serv.lib.utilities.xml_utils import XMLBuilder
from string import Template
from xml.dom.minidom import Document
import datetime

class Device:
    device_types = {'sms': 'PLY',
     'projector': 'PR'}

    def __init__(self, device):
        """Device constructor
        
        :param device: Dict of information about the device.
        
        .. code-block:: json
        
            {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "enabled": True,
                "category": "sms",
                "type": "doremi",
                "model": "DCP2000",
                "ip": "0.0.0.0",
                "ftp_ip": "0.0.0.0",
                "serial": "123456",
                "dnqualifiers": ["xbP+W/UGMiq81A0EYlR9NsGPu18=", ...],
                "certificates": {'OU=<OU>,O=<O>,CN=<CN>,dnQualifier=<dnQ>': '-----BEGIN CERT...', ...},
                "software_version": "1.0",
                "firmware_version": "1.0",
                "hardware_version": "1.0"
            }
        """
        self.type_id = self.device_types[device['category']]
        dnquals = device.get('dnqualifiers', [])
        if dnquals:
            self.id = {'type': 'CertThumbprint',
             'value': dnquals[0]}
        else:
            self.id = {'type': 'DeviceUID',
             'value': 'urn:uuid:{0}'.format(device['id'])}
        self.serial = device.get('serial', '')
        self.manufacturer = device.get('type', '')
        self.model_number = device.get('model', self.manufacturer)
        self.install_date = ''
        self.active = 'true'
        self.vpf_entity = ''
        self.vpf_start = ''
        self.ip_list = []
        if device.get('ip', None):
            self.ip_list.append(IPAddress(device['ip']))
        if device.get('ftp_ip', None):
            self.ip_list.append(IPAddress(device['ftp_ip']))
        self.software_list = []
        if 'software_version' in device and device['software_version']:
            self.software_list.append(Software('Software', device['software_version']))
        if 'firmware_version' in device and device['firmware_version']:
            self.software_list.append(Software('Firmware', device['firmware_version']))
        if 'hardware_version' in device and device['hardware_version']:
            self.software_list.append(Software('Hardware', device['hardware_version']))
        self.key_info_list = [ KeyInfo(*c) for c in device.get('certificates', {}).iteritems() ]
        self.watermarking_list = []
        self.kdm_method_list = []
        self.dcp_method_list = []
        return

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        device = builder.node(doc, 'Device')
        builder.node(device, 'DeviceTypeID', self.type_id)
        builder.node(device, 'DeviceIdentifier', self.id['value'], attrs=[{'name': 'idtype',
          'value': self.id['type']}])
        builder.node(device, 'DeviceSerial', self.serial)
        builder.node(device, 'ManufacturerName', self.manufacturer)
        builder.node(device, 'ModelNumber', self.model_number)
        builder.node(device, 'InstallDate', self.install_date)
        builder.node(device, 'IsActive', self.active)
        builder.node(device, 'VPFFinanceEntity', self.vpf_entity)
        builder.node_list(device, 'IPAddressList', self.ip_list)
        builder.node_list(device, 'SoftwareList', self.software_list)
        if self.key_info_list:
            builder.node_list(device, 'KeyInfoList', self.key_info_list)
        return device


class KeyInfo:

    def __init__(self, subject_name, certificate):
        """KeyInfo constructor
        
        We only send out leaf certificates in the flmx feed, this ensures the flmx
        consumer will have to establish the rest of the chain. This stops cinema owners
        maliciously spoofing an entire chain which they control with no respect to the
        manufacturer.
        
        :param subject_name: The subject name of the cert.
        :param certificate: The certificate text itself.
        """
        self.subject_name = subject_name
        self.certificate = certificate.replace('-----BEGIN CERTIFICATE-----', '').replace('-----END CERTIFICATE-----', '').replace('\n', '')

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        chain = builder.node(doc, 'ds:KeyInfo')
        cert = builder.node(chain, 'ds:X509Data')
        builder.node(cert, 'ds:X509SubjectName', self.subject_name)
        builder.node(cert, 'ds:X509Certificate', self.certificate)
        return chain


class IPAddress:

    def __init__(self, ip, host = None):
        self.ip = str(ip)
        self.host = host

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        address = builder.node(doc, 'IPAddress')
        builder.attr(address, 'xmlns:ds', 'http://www.w3.org/2000/09/xmldsig#')
        builder.node(address, 'Address', self.ip)
        builder.node(address, 'Host', self.host)
        return address


class Software:

    def __init__(self, kind, version, description = None, producer = None):
        self.kind = kind
        self.producer = producer
        self.description = description
        self.version = version

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        software = builder.node(doc, 'Software')
        builder.node(software, 'Description', self.description)
        builder.node(software, 'SoftwareKind', self.kind)
        builder.node(software, 'SoftwareProducer', self.producer)
        builder.node(software, 'Version', self.version)
        return software


class Watermarking:

    def __init__(self, manufacturer, kind = None, model = None, version = None):
        self.manufacturer = manufacturer
        self.kind = kind
        self.model = model
        self.version = version

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        watermarking = builder.node(doc, 'Watermarking')
        builder.node(watermarking, 'WatermarkManufacturer', self.manufacturer)
        builder.node(watermarking, 'WatermarkKind', self.kind)
        builder.node(watermarking, 'WatermarkModel', self.model)
        builder.node(watermarking, 'WatermarkVersion', self.version)
        return watermarking
# okay decompyling ./lib/flmx/device.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:00 CST
