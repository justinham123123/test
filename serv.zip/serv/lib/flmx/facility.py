# 2017.08.13 21:52:00 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\flmx\facility.py
from serv.lib.utilities.xml_utils import XMLBuilder
from string import Template
from xml.dom import minidom
from serv.lib.dcinema.constants import TERRITORIES
from xml.dom.minidom import Document
import datetime
import uuid

class Facility(object):

    def __init__(self, complex, contacts = None, addresses = None):
        """Facility constuctor
        
        :param complex: Details about the complex to generate into a FacilityInfo element.
        :param contacts: List of potential contacts for the complex.
        :param addresses: List of potential addresses for the complex.
        """
        if contacts is None:
            contacts = []
        if addresses is None:
            addresses = []
        self.id = complex['flm_complex_id']
        self.alt_ids = []
        self.name = complex['name']
        self.timezone = complex.get('timezone', None)
        self.circuit = None
        self.partial = False
        self.address_list = map(lambda a: Address(a), addresses)
        self.contact_list = map(lambda a: Contact(a), contacts)
        self.kdm_method_list = []
        self.dcp_method_list = []
        return

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        facility = builder.node(doc, 'FacilityInfo')
        builder.node(facility, 'FacilityID', 'urn:' + self.id)
        builder.node(facility, 'FacilityName', self.name)
        builder.node(facility, 'FacilityTimeZone', self.timezone)
        builder.node(facility, 'Circuit', self.circuit)
        builder.node(facility, 'FLMPartial', str(self.partial))
        builder.node_list(facility, 'AddressList', self.address_list)
        builder.node_list(facility, 'ContactList', self.contact_list)
        return facility


class Address(object):

    def __init__(self, address):
        """Address constructor
        
        :param address: Dict of address attributes.
        
        .. code-block:: json
        
            {
                "country": "UK", # Required
                "streetaddress": "123 Fake Street", # Required
                "city": "Hammersmith", # Required
                "province": "Greater London", # Required
                "type": "Physical", # Required
                "addressee": "John Smith", # Optional
                "streetaddress2": "Middle Buzzer", # Optional
                "postcode": "FK1 1FK" # Optional
            }
        """
        self.country = address['country'].upper()
        self.addressee = address.get('addressee', None)
        self.address_type = address['type'].capitalize()
        self.streetaddress = address['streetaddress']
        self.streetaddress2 = address.get('streetaddress2', None)
        self.city = address['city']
        self.province = address['province']
        self.postcode = address.get('postcode', None)
        return

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        address = builder.node(doc, 'Address')
        address_type = builder.node(address, self.address_type)
        builder.node(address_type, 'Addressee', self.addressee)
        builder.node(address_type, 'StreetAddress', self.streetaddress)
        builder.node(address_type, 'StreetAddress2', self.streetaddress2)
        builder.node(address_type, 'City', self.city)
        builder.node(address_type, 'Province', self.province)
        builder.node(address_type, 'PostalCode', self.postcode)
        builder.node(address_type, 'Country', self.country)
        return address


class Contact(object):

    def __init__(self, contact):
        """Contact constructor
        
        Contact must be named and have at least one method of communcation to be considered valid.
        
        :param contact: Dict of contact attributes
        
        .. code-block:: json
        
            {
                "name": "John Smith", # Required
                "phone1": "123", # Optional
                "email": "abc@bca.com", # Optional
                "type": "Manager" # Optional
            }
        """
        self.name = contact['name']
        self.phone1 = contact['phone1']
        self.email = contact['email']
        self.contact_type = contact.get('type', None)
        return

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        contactxml = builder.node(doc, 'Contact')
        builder.node(contactxml, 'Name', self.name)
        builder.node(contactxml, 'Phone1', self.phone1)
        builder.node(contactxml, 'Email', self.email)
        builder.node(contactxml, 'Type', self.contact_type)
        return contactxml
# okay decompyling ./lib/flmx/facility.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:01 CST
