# 2017.08.13 21:51:59 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\flmx\auditorium.py
from xml.dom.minidom import Document
from serv.lib.flmx.device import Device
from serv.lib.utilities.xml_utils import XMLBuilder

class Auditorium:

    def __init__(self, title, identifier, devices = None):
        """Auditorium constructor
        
        :param title: The title of the screen, longer than the identifier.
        :param identifier: The short identifier, this should map to the TLA.
        :param devices: List of dicts used to create Device instance, please see Device
            for details on the Device dict structure.
        """
        if devices is None:
            devices = []
        try:
            self.number = int(identifier)
        except Exception:
            self.number = ''

        self.name = title
        self.aspect_ratio = ''
        self.screen_mask = ''
        self.audio_format = ''
        self.install_date = ''
        self.large_format_type = ''
        self.devices = [ Device(d) for d in devices if d['enabled'] ]
        return

    def xml(self):
        doc = Document()
        builder = XMLBuilder(doc)
        auditorium = builder.node(doc, 'Auditorium')
        builder.node(auditorium, 'AuditoriumNumber', self.number)
        builder.node(auditorium, 'AuditoriumName', self.name)
        builder.node(auditorium, 'AdjustableScreenMask', self.screen_mask)
        builder.node(auditorium, 'AuditoriumInstallDate', self.install_date)
        devices_node = builder.node(auditorium, 'DeviceGroupList')
        if self.devices:
            builder.node_list(devices_node, 'DeviceGroup', self.devices)
        return auditorium
# okay decompyling ./lib/flmx/auditorium.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:59 CST
