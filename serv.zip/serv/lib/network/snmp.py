# 2017.08.13 21:52:15 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\network\snmp.py
"""
SNMP utilities

This requires the pySNMP library
"""
import threading, traceback, logging
from libsnmp import rfc1157, rfc1905
from libsnmp.snmpmanager import snmpManager

def oid_is_child(parent_oid, oid):
    """
    Checks whether an oid is a child (sub-type) of a parent_oid
    """
    if len(oid) <= len(parent_oid):
        return False
    for x in range(len(parent_oid)):
        if parent_oid[x] != oid[x]:
            return False

    return True


def oid_child_values(parent_oid, oid_list):
    """
    Returns all values of oids that are sub-types (children)
    of a parent oid
    """
    values = []
    for row in oid_list:
        oid = row[0][0]
        value = row[0][1]
        if oid_is_child(parent_oid, oid):
            values.append(value)

    return values

def snmp_get(oid, address, next = False):
    mgr = SnmpManager(timeout=5)
    thread = threading.Thread(target = mgr.safe_run)
    thread.start()
    value = ''
    try:
        value = mgr.snmpGet('.' + '.'.join(map(str, oid)), address, 2, 5, next)
    except Exception as e:
        print e
    finally:
        mgr.stoprequest.set()
        return value

class SNMPException(Exception):
    pass


class SNMPError(SNMPException):

    def __init__(self, error):
        self.error = error

    def __str__(self):
        return 'SNMP Error: {err}'.format(err=self.error)


class SNMPTimeout(SNMPException):

    def __init__(self, ip, oid):
        self.ip = ip
        self.oid = oid

    def __str__(self):
        return 'SNMP request timed out [{ip}, {oid}]'.format(ip=self.ip, oid=self.oid)


class SnmpManager(snmpManager):

    def __init__(self, queueEmpty = None, trapCallback = None, interface = ('0.0.0.0', 0), poll_interval = 0.25, timeout = 0.1, log = None):
        snmpManager.__init__(self, queueEmpty, trapCallback, interface, poll_interval)
        self.default_timeout = timeout
        self.stoprequest = threading.Event()

    def safe_run(self):
        while not self.stoprequest.isSet():
            try:
                self.run()
            except (ValueError, rfc1157.PDUError) as ex:
                logging.error('invalid response from device: [%s]' % str(ex))
            except Exception:
                logging.error('Problem in SNMP thread', exc_info=True)

    def handleV1Message(self, msg):
        """
        Handle reception of an SNMP version 1 message
        """
        snmpManager.handleV1Message
        if isinstance(msg.data, rfc1157.PDU):
            try:
                self.callbacks[msg.data.requestID](self, msg)
                del self.callbacks[msg.data.requestID]
            except KeyError:
                pass

        elif isinstance(msg.data, rfc1157.TrapPDU):
            self.trapCallback(self, msg)
        else:
            logging.debug('Unknown SNMPv1 Message type received')

    def handleV2Message(self, msg):
        """
        Handle reception of an SNMP version 2c message
        """
        if isinstance(msg.data, rfc1905.PDU):
            try:
                self.callbacks[msg.data.requestID](self, msg)
                del self.callbacks[msg.data.requestID]
            except KeyError:
                pass

        elif isinstance(msg.data, rfc1905.TrapPDU):
            self.trapCallback(self, msg)
        else:
            logging.debug('Unknown SNMPv2 Message type received')

    def snmpGet(self, oid, ip_address, version, timeout = None, next = False):
        """
        Returns the first bound variable from an SNMP call for the specified OID and IP address
        This method should only be called externally as the calling thread will block until the
        response is returned or the timeout is reached.
        """
        if timeout is None:
            timeout = self.default_timeout
        response_condition = threading.Condition()
        response_condition.acquire()
        response_container = []

        def cb(manager, message):
            response_condition.acquire()
            response_container.append(message.data)
            response_condition.notify()
            response_condition.release()

        try:
            if next:
                snmpManager.snmpGetNext(self, oid, (ip_address, 161), cb, version=version)
            else:
                snmpManager.snmpGet(self, oid, (ip_address, 161), cb, version=version)
            response_condition.wait(timeout)
            if response_container:
                request_id, error_status, error_index, var_binds = response_container[0]
                if int(error_status) == 0:
                    if next:
                        return var_binds
                    else:
                        return str(var_binds[0][1])
                raise SNMPError(error_status)
            else:
                raise SNMPTimeout(ip_address, oid)
        except Exception as ex:
            raise ex
        finally:
            response_condition.release()

        return
# okay decompyling ./lib/network/snmp.pyc
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:16 CST
