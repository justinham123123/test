# 2017.08.13 21:52:16 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\network\soap_utils.py
import httplib
from xml.dom.minidom import Document
from serv.lib.utilities.xml_utils import XMLBuilder, node_to_dict
from serv.lib.utilities.helper_methods import DeviceStat

class SOAPClient(object):

    def __init__(self, host, port = 80, timeout = 30, https = False, keep_alive = False, username = None, password = None):
        super(SOAPClient, self).__init__()
        self.host = host
        self.port = port
        self.https = https
        self.keep_alive = keep_alive
        self.timeout = timeout
        self.username = username
        self.password = password
        self.default_headers = {'Host': '{host}:{port}'.format(host=self.host, port=self.port),
         'Content-Type': 'text/xml; charset=utf-8',
         'Connection': 'Keep-Alive' if keep_alive else 'Close'}
        self.default_namespaces = {'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
         'xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
         'xmlns:soap': 'http://schemas.xmlsoap.org/soap/envelope/'}
        self.connection = None
        self.stat = DeviceStat(self.host)
        return

    def _create_connection(self):
        if self.https:
            return httplib.HTTPSConnection(self.host, self.port, timeout=self.timeout)
        else:
            return httplib.HTTPConnection(self.host, self.port, timeout=self.timeout)

    def _get_connection(self):
        if self.keep_alive:
            if self.connection is None:
                self.connection = self._create_connection()
                self.post_connect_process()
            return self.connection
        else:
            return self._create_connection()
            return

    def post_connect_process(self):
        pass

    def build_body(self, method = None, params = None, namespaces = None, default_request_namespace = 'ns0', default_param_namespace = 'ns0', **kwargs):
        if not method:
            return None
        else:
            if not namespaces:
                namespaces = {}
                params = params or {}
                doc = Document()
                builder = XMLBuilder(doc)
                method = default_request_namespace and ':' not in method and '{0}:{1}'.format(default_request_namespace, method)
            root = builder.node(doc, method, attrs=[ {'name': 'xmlns:{0}'.format(k),
             'value': v} for k, v in namespaces.iteritems() ])
            self._build_subtree(root, params, default_param_namespace, builder=builder)
            return root

    def build_header(self, **kwargs):
        return None

    def _build_subtree(self, root, params, default_namespace, builder = None):
        if not builder:
            builder = XMLBuilder(root)
        if isinstance(params, list):
            for param in params:
                self._build_subtree(root, param, default_namespace, builder)

        elif isinstance(params, dict):
            for tag, value in params.iteritems():
                if default_namespace and ':' not in tag:
                    tag = '{0}:{1}'.format(default_namespace, tag)
                if isinstance(value, dict):
                    new_root = builder.node(root, tag)
                    self._build_subtree(new_root, value, default_namespace, builder)
                elif isinstance(value, tuple):
                    builder.node(root, tag, value[0], attrs=value[1])
                else:
                    builder.node(root, tag, value)

        else:
            raise TypeError('Parameters for SOAP request must be dict, not {0}'.format(type(params)))

    def envelope(self, **kwargs):
        """
        Constructs the SOAP request envelope.
        
        Calls build_body and build_header with the arguments provided to construct the request XML.
        """
        doc = Document()
        builder = XMLBuilder(doc)
        root = builder.node(doc, 'soap:Envelope')
        for k, v in self.default_namespaces.iteritems():
            builder.attr(root, k, v)

        header_root = builder.node(root, 'soap:Header')
        header = self.build_header(**kwargs)
        if header:
            header_root.appendChild(header)
        body = self.build_body(**kwargs)
        if body:
            body_root = builder.node(root, 'soap:Body')
            body_root.appendChild(body)
        return root.toxml('utf-8')

    def request(self, path, method, soap_action, params = None, namespaces = None, headers = None, list_tags = None, timeout = None, default_param_namespace = 'ns0', default_request_namespace = 'ns0', force_return = False):
        """
        Makes a SOAP request to an endpoint on this SOAPClient's server.
        The response is checked for validity (its status is 200), or an exception is thrown.
        
        Parameters:
        :param path: The endpoint path to send the request to (appended onto the host), e.g. '/ContentService'
        :param method: The method you wish to execute on that endpoint, e.g. 'GetCPLList'
        :param soap_action: The value of the 'SOAPAction' HTTP header
        :param params: Extra parameters to pass in to build_body and build_header which are incorporated into the
            XML request body
        :param namespaces: A dictionary of namespaces needed by the XML request body
        :param headers: Dict of extra HTTP headers to send with the request, or overrides for existing ones
        :param list_tags: A list of tag strings which will be converted to lists while parsing the response
        :param force_return: If the respective POS's parse_response function does not need to be called, this should
            be set to True.
        """
        if timeout is None:
            timeout = self.timeout
        try:
            connection = self._get_connection()
            envelope = self.envelope(method=method, soap_action=soap_action, params=params, namespaces=namespaces, default_request_namespace=default_request_namespace, default_param_namespace=default_param_namespace)
            http_headers = {}
            http_headers.update(self.default_headers)
            if headers:
                http_headers.update(headers)
            http_headers.update({'Content-Length': len(envelope),
             'SOAPAction': soap_action})
            connection.request('POST', path, body=envelope, headers=http_headers)
            http_response = connection.getresponse()
            self.stat.stat_count(method)
            size = http_response.getheader('Content-Length')
            if len is not None:
                self.stat.stat_size(method, size)
            try:
                if force_return:
                    return str(http_response.read())
                return self.parse_response(http_response, method=method, list_tags=list_tags)
            except SOAPError:
                raise
            except Exception:
                if http_response.status != 200:
                    raise httplib.HTTPException('Error making request: %s, %s' % (http_response.status, http_response.reason))
                else:
                    if self.keep_alive:
                        self.connection = None
                    raise

        finally:
            if not self.keep_alive and 'connection' in locals():
                connection.close()

        return

    def fault(self, iterator):
        fault = node_to_dict(iterator, attributes=True)
        raise SOAPError(fault)

    def parse_response(self, response, list_tags = None, **kwargs):
        return response.read()


class SOAPError(Exception):
    """
    Exception class to represent a SOAP Fault from a device.
    
    Raise it with a dictionary containing the results of the 'Fault' tag
    (which can be created by node_to_dict in xml_utils.py).
    """

    def __init__(self, fault_dict, *args):
        super(SOAPError, self).__init__(fault_dict, *args)
        self.faultcode = fault_dict.get('faultcode')
        self.faultstring = fault_dict.get('faultstring')
        self.detail = fault_dict.get('detail')
        if self.detail and 'fault' in self.detail:
            self.reason = self.detail['fault'].get('reason')
            self.type = self.detail.get('fault__type')
        else:
            self.reason = None
            self.type = None
        return

    def __str__(self):
        return self.reason or self.faultstring or 'Unknown error, SOAP Fault has no <faultstring>'
# okay decompyling ./lib/network/soap_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:16 CST
