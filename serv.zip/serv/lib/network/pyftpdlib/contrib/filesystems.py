# 2017.08.13 21:52:04 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\network\pyftpdlib\contrib\filesystems.py
from serv.lib.network.pyftpdlib.ftpserver import AbstractedFS
__all__ = ['UnixFilesystem']

class UnixFilesystem(AbstractedFS):
    """Represents the real UNIX filesystem.
    
    Differently from AbstractedFS the client will login into
    /home/<username> and will be able to escape its home directory
    and navigate the real filesystem.
    """

    def __init__(self, root, cmd_channel):
        AbstractedFS.__init__(self, root, cmd_channel)
        self.cwd = root

    def ftp2fs(self, ftppath):
        return self.ftpnorm(ftppath)

    def fs2ftp(self, fspath):
        return fspath

    def validpath(self, path):
        return True
# okay decompyling ./lib/network/pyftpdlib/contrib/filesystems.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:05 CST
