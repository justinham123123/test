# 2017.08.13 21:52:17 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\network\socket_utils.py
"""
A collection of utility functions for TCP/IP sockets
"""
import socket, struct, array, logging, ssl

def byte_array_to_word(byte_array):
    r"""
    Converts a 4 byte array (either as a string or an array) to a 32-bit unsigned int; assumes big-endian form
    
    Test with misc. string byte arrays:
        >>> byte_array_to_word('\x00\x00\x00\x01')
        1
        >>> byte_array_to_word('\x00\x00\x01\x01')
        257
        >>> byte_array_to_word('\x00\x01\x01\x01')
        65793
    
    Test with misc. array byte arrays:
        >>> byte_array_to_word(array.array('B', (0, 0, 0, 1)))
        1
        >>> byte_array_to_word(array.array('B', (0, 0, 1, 1)))
        257
        >>> byte_array_to_word(array.array('B', (0, 1, 1, 1)))
        65793
    
    Test incorrect type error:
        >>> byte_array_to_word(123)
        Traceback (most recent call last):
        ...
        TypeError
    """
    if isinstance(byte_array, str):
        return struct.unpack('>I', struct.pack('>BBBB', ord(byte_array[0]), ord(byte_array[1]), ord(byte_array[2]), ord(byte_array[3])))[0]
    if hasattr(byte_array, '__getitem__'):
        return struct.unpack('>I', struct.pack('>BBBB', byte_array[0], byte_array[1], byte_array[2], byte_array[3]))[0]
    raise TypeError


def word_to_byte_array(word):
    """
    Converts a 32-bit int to a byte array in big-endian form
    
    Test misc. 32-bit ints:
        >>> word_to_byte_array(1)
        (0, 0, 0, 1)
        >>> word_to_byte_array(257)
        (0, 0, 1, 1)
        >>> word_to_byte_array(65793)
        (0, 1, 1, 1)
    """
    return struct.unpack('>BBBB', struct.pack('>I', word))


def int_to_ber_length(data_size = 0):
    r""" 
    Encodes a value into four bytes following the BER rules.
    This is used by Doremi and GDC for encoding length values
    
    Test with a value of 17:
    >>> int_to_ber_length(17).tostring()
    '\x83\x00\x00\x11'
    """
    byte_length = word_to_byte_array(data_size)
    return array.array('B', (131,
     byte_length[1],
     byte_length[2],
     byte_length[3]))


def encode_ber_length(value):
    """
    Encodes a data length into the BER format returning a big-endian
    string between 1 and 4 bytes long
    """
    if value > 1048576:
        raise ValueError('BER encoded length must not exceed 1MB')
    else:
        if value < 128:
            return struct.pack('>B', value)
        value_bytes = struct.pack('>L', value).lstrip('\x00')
        return struct.pack('>B', 128 + len(value_bytes)) + value_bytes


def decode_ber_length(reader):
    """
    Dynamically decodes a BER-encoded length value.
    reader must be a function that behaves like file.read or socket.recv
    """
    length = struct.unpack('>B', reader(1))[0]
    bytes_read = 1
    if length > 127:
        bytes_read += length - 128
        length = int(reader(length - 128).encode('hex'), 16)
    return (length, bytes_read)


def str_to_byte_array(str):
    """
    Converts a string to an array of bytes
    """
    return [ ord(c) for c in str ]


def create_open_socket(ip_address, port, timeout = 30):
    """
    Creates, connects and returns a socket with specified
    timeout and number of retries.
    """
    s = socket.socket()
    s.settimeout(timeout)
    s.connect((ip_address, int(port)))
    return s


def create_open_tls_socket(ip_address, port, cert_path, timeout = 30):
    """
    Creates, connects and returns a secure socket with
    specified timeout.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    if cert_path:
        ssl_sock = ssl.wrap_socket(s, ca_certs=cert_path, cert_reqs=ssl.CERT_REQUIRED, ssl_version=ssl.PROTOCOL_TLSv1, do_handshake_on_connect=True)
        ssl_sock.connect((ip_address, int(port)))
        return ssl_sock
    else:
        return create_open_socket(ip_address, port, timeout)


def receive_bytes(s, size):
    """
    Receive a known length of bytes from a socket
    """
    result = ''
    data = 'x'
    while len(result) < size:
        data = s.recv(size - len(result))
        if not data:
            raise IOError('Socket closed unexpectedly: %s' % result)
        result += data
        if len(result) == size:
            return result
        if len(result) > size:
            raise Exception, 'Received more than the defined data length: %' % result


if __name__ == '__main__':
    import doctest
    doctest.testmod()
# okay decompyling ./lib/network/socket_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:17 CST
