# 2017.08.13 21:52:01 CST
# Embedded file name: build\bdist.win32\egg\serv\lib\network\ftp_server.py
"""
" Modified FTPServer
" @author: Arthur Vivian
" 20-August-2012
"
" Server has a modified abstract filesystem. Rather than pointing just to directories that
" are below its root, it creates a fake root directory with a list of sub directorys that
" point to various locations within the servers filesystem.
"
"""
import logging
import os
import sys
import socket
import time
import glob
import stat
from tarfile import filemode as _filemode
from getopt import getopt
import json
import ast
from ftplib import FTP
from time import strftime
from serv.lib.network.pyftpdlib import ftpserver
from serv.lib.network.pyftpdlib.ftpserver import BufferedIteratorProducer
ftp_server_logger = logging.getLogger('ftp_server')
if hasattr(os, 'strerror'):
    _strerror = lambda err: os.strerror(err.errno)
else:
    _strerror = lambda err: err.strerror
FAKEDIR = {'uuid1': 'D:\\aam\\serv\\serv',
 'uuid2': 'D:\\aam-node-builds\\LOC',
 'uuid3': 'C:\\dell\\Drivers',
 '23421341-1234123413-df2q4-134c31c-1c43c14141-c414f12v54-25tb45t5vv34-233c5g3gh36h-345v363v5y3-sdgfsdfg': 'D:\\keys'}
_months_map = {1: 'Jan',
 2: 'Feb',
 3: 'Mar',
 4: 'Apr',
 5: 'May',
 6: 'Jun',
 7: 'Jul',
 8: 'Aug',
 9: 'Sep',
 10: 'Oct',
 11: 'Nov',
 12: 'Dec'}
HAS_DIR_REFR = False

class FakeRootDirsAbstractedFS(ftpserver.AbstractedFS):

    def __init__(self, *args, **kwargs):
        super(FakeRootDirsAbstractedFS, self).__init__(*args, **kwargs)

    def validpath(self, path):
        """
        "   Checks if path is either within out root directory or in one of our
        "   directories passed to the abstracted file system
        """
        norm_path = os.path.normcase(os.path.normpath(path))
        if norm_path == os.path.normcase(os.path.normpath(self.root)):
            return True
        for fs_dir in self.get_fs().values():
            norm_fs_dir = os.path.normcase(os.path.normpath(fs_dir))
            if norm_path.startswith(norm_fs_dir):
                return True

        return False

    def get_fs(self):
        global FAKEDIR
        return FAKEDIR

    def rmdir(self, path):
        pass

    def remove(self, path):
        pass

    def chdir(self, path):
        """
        "   Changes the current directory (cd)
        """
        os.chdir(path)
        self._cwd = self.fs2ftp(path)

    def listdir(self, path):
        """
        "   List the current directory (ls/dir)
        """
        if path == self.root:
            return self.get_fs().keys()
        else:
            return os.listdir(path)

    def ftpnorm(self, ftppath):
        """Normalize a "virtual" ftp pathname (tipically the raw string
        coming from client) depending on the current working directory.
        
        Example (having "/foo" as current working directory):
        >>> ftpnorm('bar')
        '/foo/bar'
        
        Note: directory separators are system independent ("/").
        Pathname returned is always absolutized.
        """
        if os.path.isabs(ftppath):
            p = os.path.normcase(os.path.normpath(ftppath))
        else:
            p = os.path.normcase(os.path.normpath(os.path.join(self.cwd, ftppath)))
        p = p.replace('\\', '/')
        while p[:2] == '//':
            p = p[1:]

        if not os.path.isabs(p):
            p = '/'
        return p

    def ftp2fs(self, ftppath):
        """
        "   Translate a "virtual" ftp pathname (typically the raw string
        "   coming from client) into equivalent absolute "real" filesystem
        "   pathname.
        "
        "   Example: We have an entry in our uuid dictionary such as {'uuid1' : 'C:\\userA\\movies' }
        "            then >>>(ftp virtual)  '/uuid1/action/usa'
        "                     >>>(fs real)  'C:\\userA\\movies\x07ction\\usa'
        """
        if ftppath == '/':
            return self.root
        p = self.ftpnorm(ftppath)[1:]
        if not p:
            return self.root
        if p.startswith('/'):
            p = p[1:]
        path_dirs = p.split('/')
        if path_dirs[0] in self.get_fs().keys():
            p = p.replace(path_dirs[0], self.get_fs()[path_dirs[0]])
        return p

    def fs2ftp(self, fspath):
        """
        "   Translates an absolute "real" file system (fs) path name to a "virtual" ftp
        "   path name
        "
        "   Example: We have an entry in our uuid dictionary such as {'uuid1' : 'C:\\userA\\movies' }
        "            then >>>(fs real) 'C:\\userA\\movies\x07ction\\usa'
        "            >>>(ftp virtual)  '/uuid1/action/usa'        
        "            
        "   If for some reason a path is given that is not in our uuid dictionary, we return the root
        "   directory, and the client is send back to the root dir.
        """
        if not os.path.isabs(fspath):
            fspath = os.path.join(self.root, fspath)
        if not self.validpath(fspath):
            return '/'
        norm_fspath = os.path.normcase(os.path.normpath(fspath))
        if norm_fspath == os.path.normcase(os.path.normpath(self.root)):
            return '/'
        ordered_fs = sorted(self.get_fs().items(), key=lambda x: len(x[0]), reverse=True)
        for device_uuid, device_path in ordered_fs:
            norm_device_path = os.path.normcase(os.path.normpath(device_path))
            if norm_fspath.startswith(norm_device_path):
                remainder_path = norm_fspath[len(norm_device_path):]
                if norm_device_path.endswith(os.path.sep):
                    norm_ftp_path = device_uuid + os.path.sep + remainder_path
                elif remainder_path.startswith(os.path.sep) or remainder_path == '':
                    norm_ftp_path = device_uuid + remainder_path
                else:
                    continue
                ftp_path = norm_ftp_path.replace(os.path.sep, '/')
                if not ftp_path.startswith('/'):
                    ftp_path = '/' + ftp_path
                return ftp_path

        return '/'

    def refresh_uuids(self, new_fs):
        """
        "   Update our uuid dictionary with a new uuid dictionary.
        "   Should be passed as a string with a json type format
        """
        global FAKEDIR
        FAKEDIR = dict(ast.literal_eval(new_fs))
        HAS_DIR_REFR = True
        self.chdir(self.root)

    def get_list_dir(self, path):
        """"Return an iterator object that yields a directory listing
        in a form suitable for LIST command.
        """
        if self.isdir(path):
            listing = self.listdir(path)
            listing.sort()
            return self.format_list(path, listing)
        else:
            basedir, filename = os.path.split(path)
            self.lstat(path)
            return self.format_list(basedir, [filename])

    def format_list(self, basedir, listing, ignore_err = True):
        """Return an iterator object that yields the entries of given
        directory emulating the "/bin/ls -lA" UNIX command output.
        
         - (str) basedir: the absolute dirname.
         - (list) listing: the names of the entries in basedir
         - (bool) ignore_err: when False raise exception if os.lstat()
         call fails.
        
        On platforms which do not support the pwd and grp modules (such
        as Windows), ownership is printed as "owner" and "group" as a
        default, and number of hard links is always "1". On UNIX
        systems, the actual owner, group, and number of links are
        printed.
        
        This is how output appears to client:
        
        -rw-rw-rw-   1 owner   group    7045120 Sep 02  3:47 music.mp3
        drwxrwxrwx   1 owner   group          0 Aug 31 18:50 e-books
        -rw-rw-rw-   1 owner   group        380 Sep 02  3:40 module.py
        """
        if self.cmd_channel.use_gmt_times:
            timefunc = time.gmtime
        else:
            timefunc = time.localtime
        now = time.time()
        for basename in listing:
            if basename in FAKEDIR.keys():
                file = FAKEDIR[basename]
            else:
                file = os.path.join(basedir, basename)
            try:
                st = self.lstat(file)
            except OSError:
                if ignore_err:
                    continue
                raise

            perms = _filemode(st.st_mode)
            nlinks = st.st_nlink
            if not nlinks:
                nlinks = 1
            size = st.st_size
            uname = self.get_user_by_uid(st.st_uid)
            gname = self.get_group_by_gid(st.st_gid)
            mtime = timefunc(st.st_mtime)
            if now - st.st_mtime > 15552000:
                fmtstr = '%d  %Y'
            else:
                fmtstr = '%d %H:%M'
            try:
                mtimestr = '%s %s' % (_months_map[mtime.tm_mon], time.strftime(fmtstr, mtime))
            except ValueError:
                mtime = timefunc()
                mtimestr = '%s %s' % (_months_map[mtime.tm_mon], time.strftime('%d %H:%M', mtime))

            if stat.S_ISLNK(st.st_mode) and hasattr(self, 'readlink'):
                basename = basename + ' -> ' + self.readlink(file)
            output = '%s %3s %-8s %-8s %8s %s %s\r\n' % (perms,
             nlinks,
             uname,
             gname,
             size,
             mtimestr,
             basename)
            yield output.encode('utf-8')

    def format_mlsx(self, basedir, listing, perms, facts, ignore_err = True):
        """
        "   This method is copied as is from the parent class pyftpdlib.ftpserver.AbstractedFS
        "   The only modified parts are commented, please refer to the parent class for a
        "   more comprehensive overview of this method
        """
        if self.cmd_channel.use_gmt_times:
            timefunc = time.gmtime
        else:
            timefunc = time.localtime
        permdir = ''.join([ x for x in perms if x not in 'arw' ])
        permfile = ''.join([ x for x in perms if x not in 'celmp' ])
        if 'w' in perms or 'a' in perms or 'f' in perms:
            permdir += 'c'
        if 'd' in perms:
            permdir += 'p'
        for basename in listing:
            if listing == self.get_fs().keys():
                file = os.path.join(self.get_fs()[basename], '')
            else:
                file = os.path.join(basedir, basename)
            retfacts = dict()
            try:
                st = self.stat(file)
            except OSError as ex:
                if ignore_err:
                    continue
                raise

            if stat.S_ISDIR(st.st_mode):
                if 'type' in facts:
                    if basename == '.':
                        retfacts['type'] = 'cdir'
                    elif basename == '..':
                        retfacts['type'] = 'pdir'
                    else:
                        retfacts['type'] = 'dir'
                if 'perm' in facts:
                    retfacts['perm'] = permdir
            else:
                if 'type' in facts:
                    retfacts['type'] = 'file'
                if 'perm' in facts:
                    retfacts['perm'] = permfile
            if 'size' in facts:
                retfacts['size'] = st.st_size
            if 'modify' in facts:
                try:
                    retfacts['modify'] = time.strftime('%Y%m%d%H%M%S', timefunc(st.st_mtime))
                except ValueError:
                    pass

            if 'create' in facts:
                try:
                    retfacts['create'] = time.strftime('%Y%m%d%H%M%S', timefunc(st.st_ctime))
                except ValueError:
                    pass

            if 'unix.mode' in facts:
                retfacts['unix.mode'] = oct(st.st_mode & 511)
            if 'unix.uid' in facts:
                retfacts['unix.uid'] = st.st_uid
            if 'unix.gid' in facts:
                retfacts['unix.gid'] = st.st_gid
            if 'unique' in facts:
                retfacts['unique'] = '%xg%x' % (st.st_dev, st.st_ino)
            factstring = ''.join([ '%s=%s;' % (x, retfacts[x]) for x in sorted(retfacts.keys()) ])
            output = '%s %s\r\n' % (factstring, basename)
            yield output.encode('utf-8')


class FakeDirFTPHandler(ftpserver.FTPHandler):

    def log(self, msg):
        formatted_msg = '[%s]@%s:%s %s' % (self.username,
         self.remote_ip,
         self.remote_port,
         msg)
        ftp_server_logger._log(logging.INFO, formatted_msg, ())

    def logline(self, msg):
        formatted_msg = '%s:%s %s' % (self.remote_ip, self.remote_port, msg)
        ftp_server_logger._log(logging.INFO, formatted_msg, ())

    def logerror(self, msg):
        formatted_msg = '[%s]@%s:%s %s' % (self.username,
         self.remote_ip,
         self.remote_port,
         msg)
        ftp_server_logger._log(logging.ERROR, formatted_msg, ())

    def log_exception(self, instance):
        ftp_server_logger._log(logging.ERROR, 'Unhandled exception in %s' % instance, (), exc_info=True)

    def respond(self, resp):
        """Send a response to the client using the command channel."""
        self._last_response = resp
        self.push(resp.encode('utf-8') + '\r\n')
        try:
            self.logline('==> %s' % resp)
        except Exception:
            self.logline('==> %s' % resp.encode('utf-8'))

    def ftp_NLST(self, path):
        """Return a list of files in the specified directory in a
        compact form to the client.
        """
        try:
            if self.fs.isdir(path):
                listing = self.run_as_current_user(self.fs.listdir, path)
            else:
                self.fs.lstat(path)
                listing = [os.path.basename(path)]
        except OSError as err:
            self.respond('550 %s.' % _strerror(err))
        else:
            data = ''
            if listing:
                listing.sort()
                data = '\r\n'.join(listing) + '\r\n'
            self.push_dtp_data(data.encode('utf-8'), cmd='NLST')

    def ftp_CWD(self, path):
        """Change the current working directory."""
        try:
            self.run_as_current_user(self.fs.chdir, path)
        except OSError as err:
            why = _strerror(err)
            self.respond(u'550 %s.' % why)
        else:
            self.respond('250 "%s" is the current directory.' % self.fs.cwd)

    def ftp_LIST(self, path):
        """Return a list of files in the specified directory to the
        client.
        """
        try:
            iterator = self.run_as_current_user(self.fs.get_list_dir, path)
        except OSError as err:
            why = _strerror(err)
            self.respond('550 %s.' % why)
        else:
            producer = BufferedIteratorProducer(iterator)
            self.push_dtp_data(producer, isproducer=True, cmd='LIST')

    def found_terminator(self):
        """
        "   As is in parent class pyftpdlib.ftpserver.FTPHandler
        "   Only change is added command REFR to update uuid dictionary
        """
        if self._idler is not None and not self._idler.cancelled:
            self._idler.reset()
        line = ''.join(self._in_buffer)
        self._in_buffer = []
        self._in_buffer_len = 0
        cmd = line.split(' ')[0].upper()
        arg = line[len(cmd) + 1:]
        kwargs = {}
        try:
            arg = arg.decode('utf-8')
        except UnicodeDecodeError:
            try:
                arg = arg.decode('ISO-8859-1')
            except UnicodeDecodeError:
                pass

        if cmd == 'REFR' and arg:
            msg = 'FTP Server update with new filesystem.'
            self.fs.refresh_uuids(arg)
            self.respond('200 ' + msg)
            return
        else:
            if cmd == 'SITE' and arg:
                cmd = 'SITE %s' % arg.split(' ')[0].upper()
                arg = line[len(cmd) + 1:]
            time_str = strftime('%Y-%m-%d %H:%M:%S')
            if cmd != 'PASS':
                self.logline('%s <== %s' % (time_str, line))
            else:
                self.logline('%s <== %s %s' % (time_str, line.split(' ')[0], '******'))
            if cmd not in self.proto_cmds:
                if cmd[-4:] in ('ABOR', 'STAT', 'QUIT'):
                    cmd = cmd[-4:]
                else:
                    msg = 'Command "%s" not understood.' % cmd
                    self.respond('500 ' + msg)
                    if cmd:
                        self.log_cmd(cmd, arg, 500, msg)
                    return
            if not arg and self.proto_cmds[cmd]['arg'] == True:
                msg = 'Syntax error: command needs an argument.'
                self.respond('501 ' + msg)
                self.log_cmd(cmd, '', 501, msg)
                return
            if arg and self.proto_cmds[cmd]['arg'] == False:
                msg = 'Syntax error: command does not accept arguments.'
                self.respond('501 ' + msg)
                self.log_cmd(cmd, arg, 501, msg)
                return
            if not self.authenticated:
                if self.proto_cmds[cmd]['auth'] or cmd == 'STAT' and arg:
                    msg = 'Log in with USER and PASS first.'
                    self.respond('530 ' + msg)
                    self.log_cmd(cmd, arg, 530, msg)
                else:
                    self.process_command(cmd, arg)
                    return
            else:
                if cmd == 'STAT' and not arg:
                    self.ftp_STAT('')
                    return
                if self.proto_cmds[cmd]['perm'] and cmd != 'STOU':
                    if cmd in ('CWD', 'XCWD'):
                        arg = self.fs.ftp2fs(arg or '/')
                    elif cmd in ('CDUP', 'XCUP'):
                        arg = self.fs.ftp2fs('..')
                    elif cmd == 'LIST':
                        if arg.lower() in ('-a', '-l', '-al', '-la'):
                            arg = self.fs.ftp2fs(self.fs.cwd)
                        else:
                            arg = self.fs.ftp2fs(arg or self.fs.cwd)
                    elif cmd == 'STAT':
                        if glob.has_magic(arg):
                            msg = 'Globbing not supported.'
                            self.respond('550 ' + msg)
                            self.log_cmd(cmd, arg, 550, msg)
                            return
                        arg = self.fs.ftp2fs(arg or self.fs.cwd)
                    elif cmd == 'SITE CHMOD':
                        if ' ' not in arg:
                            msg = 'Syntax error: command needs two arguments.'
                            self.respond('501 ' + msg)
                            self.log_cmd(cmd, '', 501, msg)
                            return
                        mode, arg = arg.split(' ', 1)
                        arg = self.fs.ftp2fs(arg)
                        kwargs = dict(mode=mode)
                    elif arg == '-a' or arg == '-l':
                        arg = self.fs.ftp2fs(self.fs.cwd)
                    else:
                        arg = self.fs.ftp2fs(arg or self.fs.cwd)
                    if not self.fs.validpath(arg):
                        if HAS_DIR_REFR:
                            msg = "Server's filesystem has been updated. Path no longer exists."
                        else:
                            msg = '"%s" is not a valid path' % self.fs.ftpnorm(arg)
                        self.respond('550 %s.' % msg)
                        self.log_cmd(cmd, arg, 550, msg)
                        return
                perm = self.proto_cmds[cmd]['perm']
                if perm is not None and cmd != 'STOU':
                    if not self.authorizer.has_perm(self.username, perm, arg):
                        msg = 'Not enough privileges.'
                        self.respond('550 ' + msg)
                        self.log_cmd(cmd, arg, 550, msg)
                        return
                self.process_command(cmd, arg, **kwargs)
            return


def refresh_fs(dir, user, password, host = ('localhost', 50007)):
    ftp = FTP()
    ftp.connect(host[0], host[1])
    ftp.login(user, password)
    ftp.sendcmd('REFR ' + json.dumps(dir))


def main():
    HOST = '172.17.140.29'
    PORT = '50007'
    LMS = 'D:\\aam\\'
    USER = 'a'
    PASS = 'a'
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'hs:p:d:u:w:', ['help',
         'host=',
         'port=',
         'LMSIngestFolder=',
         'user=',
         'password='])
    except getopt.GetoptError as err:
        print str(err)

    for o, a in opts:
        if o == '-s':
            HOST = a
        if o == '-p':
            PORT = a
        if o == '-d':
            LMS = a
        if o == '-u':
            USER = a
        if o == '-w':
            PASS = a

    authorizer = ftpserver.DummyAuthorizer()
    authorizer.add_user(USER, password=PASS, homedir=LMS, perm='elradfmw')
    abstracted_fs = FakeRootDirsAbstractedFS
    handler = FakeDirFTPHandler
    handler.authorizer = authorizer
    handler.abstracted_fs = abstracted_fs
    handler.banner = 'Customised FTP Server'
    address = (HOST, PORT)
    try:
        server = ftpserver.FTPServer(address, handler)
        server.max_cons = 256
        server.max_cons_per_ip = 20
        server.serve_forever()
    except socket.error as e:
        print 'socket.error ', e
        print 'FTP Server already running'


if __name__ == '__main__':
    try:
        print 'start'
        main()
    except Exception as ex:
        import traceback
        print 'Exception in running ftp server:' + str(ex) + ':' + traceback.format_exc()
# okay decompyling ./lib/network/ftp_server.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:03 CST
