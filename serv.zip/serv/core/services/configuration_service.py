# 2017.08.13 21:50:03 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\configuration_service.py
"""
Note:
The following acronyms/shortcuts used within this module:
     sa  --> show_attribute
 ex_sam  --> external_show_attribute_map  (third party ids for show attributes)
    pam  --> pack attribute map   (mapping between packs and show attributes)

Unit tests: serv/tests/unit/core/services/
"""
import ctypes
from datetime import datetime, timedelta
from itertools import ifilter
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from uuid import uuid4
import uuid
import cherrypy
from serv.core.devices.base.content import Content
from serv.core.devices.base.monitoring import Monitor
from serv.core.services.base_service import Service
from sqlalchemy.orm import joinedload
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_, or_
from serv import app_dir
from serv.configuration import cfg
from serv.configuration.constants import ACTION_MANAGER_CYCLE, AUTO_PLAYLIST_NAMES, AUTO_PLAYLIST_DATES
from serv.configuration.constants import SYNC_PRESETS
from serv.core.devices.content.logical_drive.logical_drive import LogicalDrive
from serv.core.devices.pos.aam.aam import AAMulator as pos_emulator
from serv.core.devices.sms.aam.aam import AAMulator as sms_emulator
from serv.lib.cherrypy.cherrypy_utils import DeviceMonitor
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.email.email_imap import email_imap
from serv.lib.email.email_pop import email_pop
from serv.lib.flmx import FLMX, get_flmx_filename
from serv.lib.utilities import config
from serv.lib.utilities.action import Action
from serv.lib.utilities.helper_methods import audit_log
from serv.lib.utilities.show_attribute_utils import gen_ex_sam_uuid
from serv.lib.utilities.show_attribute_utils import ShowAttributeUtils
from serv.lib.utilities.show_attribute_tms_utils import TmsShowAttributeUtils
from serv.lib.utilities.utils import async_execute
from serv.storage.database.primary import database as db

class ConfigurationService(Service):

    def show_attribute(self, include_screen = True, include_cpl = True, include_other = True):
        db_show_attributes = db.Session.query(db.ShowAttribute)
        show_attributes = {}
        for db_sa in db_show_attributes:
            if not (include_cpl and db_sa.cpl_attribute):
                show_attributes[db_sa.uuid] = (include_screen and db_sa.screen_attribute or include_other and (db_sa.screen_attribute or not db_sa.cpl_attribute)) and db_sa.to_dict()
                show_attributes[db_sa.uuid]['external_show_attribute_maps'] = {}
                for x in db_sa.external_show_attribute_maps:
                    show_attributes[db_sa.uuid]['external_show_attribute_maps'][x.uuid] = x.to_dict()

        return show_attributes

    def save_show_attribute(self, show_attribute_dict):
        sa_utils = ShowAttributeUtils(db)
        sa = sa_utils.create(show_attribute_dict)
        external_show_attr = show_attribute_dict.get('external_show_attr')
        if external_show_attr:
            ex_sam = sa_utils.lookup_exsam(exsam_uuid=external_show_attr)
            ex_sam.show_attribute_uuid = sa.uuid
            audit_log('Show attribute saved: uuid="%s" ' % sa.uuid, tags=['configuration', 'save'])
            db.Session.commit()
        return {'type': 'success',
         'message': _('Saved: %s') % show_attribute_dict['name']}

    def delete_show_attribute(self, sa_uuid):
        try:
            sa_name = ShowAttributeUtils(db).delete(sa_uuid)
            audit_log('Show attribute deleted: uuid="%s" name="%s" ' % (sa_uuid, sa_name), tags=['configuration', 'delete'])
            return {'type': 'success',
             'message': _('Deleted: %s') % sa_name}
        except NoResultFound:
            return {'type': 'error',
             'message': _('Not found: %s') % uuid}

    def unmatch_show_attribute(self, ex_sam_uuid):
        try:
            ex_sam = db.Session.query(db.ExternalShowAttributeMap).filter(db.ExternalShowAttributeMap.uuid == ex_sam_uuid).one()
            ex_sam.show_attribute_uuid = None
            db.Session.commit()
            audit_log('Show attribute unmatched: uuid="%s" ' % ex_sam.external_id, tags=['configuration'])
            message = {'type': 'success',
             'message': _('Updated: %s') % ex_sam.external_id}
        except NoResultFound:
            return {'type': 'error',
             'message': _('Not found: %s') % ex_sam_uuid}

        return message

    def match_show_attribute(self, ex_sam_dict):
        try:
            sa_utils = ShowAttributeUtils(db)
            ex_sam_uuid = ex_sam_dict['uuid']
            sa = sa_utils.lookup(sa_uuid=ex_sam_dict['show_attr_uuid'])
            ex_sam = sa_utils.lookup_exsam(exsam_uuid=ex_sam_uuid)
            if ex_sam is None:
                raise Exception('Unable to find external show attribute with uuid "{0}"'.format(ex_sam_uuid))
            ex_sam.show_attribute_uuid = sa.uuid
            db.Session.commit()
            audit_log('Show attribute matched: show_attr_uuid="%s" external_show_attr_id="%s" ' % (sa.uuid, ex_sam.external_id), tags=['configuration'])
            message = {'type': 'success',
             'message': _('Saved: %s') % ex_sam.external_id}
        except Exception as ex:
            logging.error('error matching the show attribute', exc_info=True)
            message = {'type': 'error',
             'message': _('Error saving: %s') % str(ex)}

        return message

    def synchronize_show_attributes(self, show_attributes, remove = False):
        """
        Synchronizes show attribute state with circuit core. Show attributes
        and related mappings are made consistent with what is received
        from circuit core. Also show attributes that producer
        doesnt know about are deleted locally.
        
        :param list show_attributes: List of show attributes with associated
                                     mappings to synchronize locally.
        :param bool remove:          Whether local show attributes that
                                     do not occur in `show_attributes`
                                     should be removed (default: `False`).
        """
        for show_attribute in show_attributes:
            self.save_show_attribute(show_attribute)
            exsams = show_attribute.get('matched')
            if exsams:
                self.save_external_show_attribute_maps(exsams)
                exam_uuids = set([ e['uuid'] for e in exsams ])
                db.Session.query(db.ExternalShowAttributeMap).filter(db.ExternalShowAttributeMap.show_attribute_uuid == show_attribute['uuid'], ~db.ExternalShowAttributeMap.uuid.in_(exam_uuids)).update({'show_attribute_uuid': None}, False)
                db.Session.commit()

        if remove:
            sa_uuids = [ sa['uuid'] for sa in show_attributes ]
            obsolete_sas = db.Session.query(db.ShowAttribute.uuid).filter(~db.ShowAttribute.uuid.in_(sa_uuids))
            for sa in obsolete_sas:
                self.delete_show_attribute(sa.uuid)

        return

    def external_show_attribute_maps(self, include_aam = True):
        ex_sams = {}
        db_ex_sams = db.Session.query(db.ExternalShowAttributeMap)
        if not include_aam:
            db_ex_sams = db_ex_sams.filter(db.ExternalShowAttributeMap.source != 'aam')
        for db_ex_sam in db_ex_sams:
            ex_sams[db_ex_sam.uuid] = db_ex_sam.to_dict()

        return ex_sams

    def save_external_show_attribute_maps(self, external_show_attribute_maps, ccpush = True):
        """
        :param bool  ccpush: Switch to enable pushing this ex_sam to
                             circuit core. False by default.
        """
        exsams = {}
        for exsam in ifilter(lambda x: x is not None, external_show_attribute_maps):
            uuid = exsam.get('uuid', gen_ex_sam_uuid(exsam['source'], exsam['external_id']))
            exsams[uuid] = exsam

        ex_sam_utils = TmsShowAttributeUtils(ccpush, exsam_to_cache=exsams.keys())
        for exsam in exsams.itervalues():
            ex_sam_utils.insert_or_update_exam(exsam)

        db.Session.commit()
        return {'type': 'success',
         'message': _('Saved')}

    def screen_last_modified(self):
        screens = db.Session.query(db.Screen)
        return dict(((screen.uuid, screen.last_modified) for screen in screens))

    def screen(self, screen_uuids = []):
        screen_info = {}
        screen_meta = {}
        screens = db.Session.query(db.Screen)
        if len(screen_uuids) > 0:
            screens = screens.filter(db.Screen.uuid.in_(screen_uuids))
        for screen in screens:
            screen_info[screen.uuid] = self._screen_to_dictionary(screen)

        return screen_info

    def save_screen(self, screens):
        screen_data = {}
        messages = []
        cc_dict = {}
        for screen in screens:
            try:
                db_screen = db.Session.query(db.Screen).filter(db.Screen.uuid == screen.get('uuid')).one()
            except NoResultFound:
                db_screen = db.Screen()
                if 'uuid' in screen:
                    db_screen.uuid = screen['uuid']
                db.Session.add(db_screen)

            db_screen.set_modified(screen.get('last_modified', None))
            db_screen.title = screen['title']
            db_screen.identifier = screen['identifier']
            db_screen.capacity = screen.get('capacity')
            db_screen.hi = None
            db_screen.vi = None
            db_screen.cc = None
            db_screen.audio = None
            db_screen.audio_level = None
            i = 1
            for capability in screen['capabilities']:
                if capability['name'] == 'hi':
                    db_screen.hi = i
                elif capability['name'] == 'vi':
                    db_screen.vi = i
                elif capability['name'] == 'cc':
                    db_screen.cc = i
                elif capability['name'] == 'audio':
                    db_screen.audio = i
                    db_screen.audio_level = capability['value']
                i = i + 1

            if screen.get('uuid'):
                db.Session.query(db.ScreenShowAttributeMap).filter(db.ScreenShowAttributeMap.screen_uuid == screen['uuid']).delete()
            db_show_attribs = db.Session.query(db.ShowAttribute).filter(db.ShowAttribute.uuid.in_(screen.get('show_attributes', [])))
            for sa in db_show_attribs:
                db_ssam = db.ScreenShowAttributeMap()
                db_ssam.show_attribute_uuid = sa.uuid
                db_ssam.screen_uuid = db_screen.uuid
                db.Session.add(db_ssam)

            audit_log('Screen saved: uuid="%s" title="%s" identifier="%s" ' % (screen.get('uuid'), screen['title'], screen['identifier']), tags=['configuration', 'screen', 'save'])
            db.Session.commit()
            screen_dict = self._screen_to_dictionary(db_screen)
            cc_dict[screen_dict['uuid']] = screen_dict

        messages.append({'type': 'success',
         'message': _('Saved: %s') % db_screen.identifier})
        screen_data['uuid'] = db_screen.uuid
        self._update_screens()
        cherrypy.engine.publish('ccpush', 'screen_information', {'screens': cc_dict})
        return (screen_data, messages)

    def delete_screen(self, screen_uuids):
        screens = db.Session.query(db.Screen).filter(db.Screen.uuid.in_(screen_uuids))
        screens_o = [ {'uuid': screen.uuid,
         'identifier': screen.identifier} for screen in screens ]
        if db.Session.query(db.PackScreenMap).filter(db.PackScreenMap.screen_uuid.in_(screen_uuids)).count():
            return {'type': 'error',
             'message': _('Cannot delete Screen because it is referenced by a Pack')}
        device_uuids = []
        for screen in screens:
            for device in screen.devices:
                device_uuids.append(device.uuid)

        db.Session.query(db.Schedule).filter(db.Schedule.screen_uuid.in_(screen_uuids)).delete(False)
        if device_uuids:
            self.delete_device(device_uuids)
        db.Session.query(db.ScreenShowAttributeMap).filter(db.ScreenShowAttributeMap.screen_uuid.in_(screen_uuids)).delete(False)
        screens.delete(False)
        db.Session.commit()
        self._update_screens()
        for screen in screens_o:
            audit_log('Screen deleted: {screen:screen}', meta={'screen': screen}, tags=['configuration', 'screen', 'delete'])

        for uuid in screen_uuids:
            cherrypy.engine.publish('ccpush', 'screen_remove', {'uuid': uuid})

        return {'type': 'success',
         'message': _('Deleted: %s') % ', '.join([ screen['identifier'] for screen in screens_o ])}

    def _update_screens(self):
        self.core.screens = self.screen()

    def device_last_modified(self):
        devices = db.Session.query(db.Device)
        last_modified_info = dict(((device.uuid, device.last_modified) for device in devices))
        last_modified_info[cfg.lms_uuid()] = self.core.devices[cfg.lms_uuid()].last_modified
        return last_modified_info

    def device(self, device_ids = []):
        device_info = {}
        devices = db.Session.query(db.Device)
        if device_ids:
            devices = devices.filter(db.Device.uuid.in_(device_ids))
        for device in devices:
            device_info[device.uuid] = self._device_to_dictionary(device)

        return device_info

    def external_device_maps(self, source_type = None, matched_only = False):
        """ Get the external device maps """
        maps = db.Session.query(db.ExternalDeviceMap).filter(and_(or_(db.ExternalDeviceMap.source_type == source_type, not source_type), or_(db.ExternalDeviceMap.device_uuid != None, not matched_only))).all()
        external_device_info = {}
        source = None
        for map in maps:
            if not external_device_info.has_key(map.source_type):
                external_device_info[map.source_type] = {}
            source = map.source
            if not external_device_info[map.source_type].has_key(source):
                external_device_info[map.source_type][source] = {}
            external_device_info[map.source_type][source][map.external_id] = map.device_uuid

        return external_device_info

    def save_external_device_maps(self, device_maps):
        """ Save/update external device maps """
        pos_reconfigured = []
        for source_type in device_maps:
            for device_uuid in device_maps[source_type]:
                if source_type == 'pos':
                    pos_reconfigured.append(device_uuid)
                for ext_id in device_maps[source_type][device_uuid]:
                    self.add_update_external_device_id(ext_id, device_uuid, source_type, device_maps[source_type][device_uuid][ext_id])

        if pos_reconfigured:
            reconfigured_pos_screen_ids = []
            for pos_device_uuid in pos_reconfigured:
                for ext_id in device_maps['pos'][pos_device_uuid]:
                    reconfigured_pos_screen_ids.append(ext_id)

                self.core.pos.service.reset_pos(pos_device_uuid, reconfigured_pos_screen_ids)

        cherrypy.engine.publish('ccpush', 'external_device_maps_save', device_maps)
        time.sleep(3)
        cherrypy.engine.publish('queue_schedule_sync')
        return {'type': 'success',
         'message': _('Saved')}

    def add_update_external_device_id(self, ext_id, source, source_type, device_uuid = None, overwrite = True):
        """
        Update an external device map or create a new one and attempt to match it to a suitable device.
        :returns: The internal device_uuid the external device has been mapped to
        """
        try:
            map = db.Session.query(db.ExternalDeviceMap).filter(and_(db.ExternalDeviceMap.source == source, db.ExternalDeviceMap.external_id == ext_id, db.ExternalDeviceMap.source_type == source_type)).one()
            if overwrite:
                if source:
                    map.device_uuid = device_uuid
                elif device_uuid:
                    db.Session.execute("UPDATE external_device_map SET device_uuid = '%s' where external_id == '%s' and source is NULL" % (device_uuid, ext_id))
                else:
                    db.Session.execute("UPDATE external_device_map SET device_uuid = NULL where external_id == '%s' and source is NULL" % ext_id)
            else:
                device_uuid = map.device_uuid
        except NoResultFound:
            if not device_uuid:
                device_uuid = self._match_external_id_to_device(ext_id)
            db.Session.add(db.ExternalDeviceMap(source=source, source_type=source_type, external_id=ext_id, device_uuid=device_uuid))

        db.Session.commit()
        return device_uuid

    def _match_external_id_to_device(self, external_id):
        screens = self.core.screens
        devices = self.core.devices
        regex = re.findall('\\d+', external_id)
        regex = str(int(regex[0])) if len(regex) > 0 else external_id
        for screen_uuid in screens:
            screen = screens[screen_uuid]
            if screen['identifier'].lower() == external_id.lower() or regex == screen['identifier']:
                for uuid in screen['devices']:
                    if uuid in devices and devices[uuid].device_configuration.get('category') == 'sms':
                        return uuid

    def refresh_external_device_map(self, device_uuid):
        updates = []
        for map in db.Session.query(db.ExternalDeviceMap).all():
            match = self._match_external_id_to_device(map.external_id)
            if match and device_uuid == match:
                updates.append({'device_uuid': device_uuid,
                 'external_id': map.external_id,
                 'source': map.source,
                 'source_type': map.source_type})

        for update in updates:
            self.add_update_external_device_id(update['external_id'], update['source'], update['source_type'], update['device_uuid'])

        if updates:
            cherrypy.engine.publish('queue_schedule_sync')

    def _device_to_dictionary(self, device):
        return {'id': device.uuid,
         'last_modified': device.last_modified,
         'category': device.category,
         'type': device.type,
         'model': device.model,
         'ip': device.ip_address,
         'port': device.port,
         'api_username': device.api_username,
         'api_password': device.api_password,
         'ftp_ip': device.ftp_ip_address,
         'ftp_port': device.ftp_port,
         'ftp_username': device.ftp_username,
         'ftp_password': device.ftp_password,
         'enabled': device.enabled,
         'name': device.name,
         'path': device.path,
         'screen_uuid': device.screen_uuid,
         'cert_path': device.cert_path,
         'screen_identifier': None if device.screen_uuid is None or device.screen is None else device.screen.identifier,
         'custom': device.model in (x['model'] for x in cherrypy.core.custom_device_metadata.get(device.category, {}).get(device.type, []))}

    def _screen_to_dictionary(self, screen):
        capabilities = []
        if screen.hi:
            capabilities.append({'name': 'hi',
             'order': screen.hi})
        if screen.vi:
            capabilities.append({'name': 'vi',
             'order': screen.vi})
        if screen.cc:
            capabilities.append({'name': 'cc',
             'order': screen.cc})
        if screen.audio:
            capabilities.append({'name': 'audio',
             'order': screen.audio,
             'value': screen.audio_level})
        capabilities.sort(key=lambda x: x['order'])
        show_attribute_uuids = []
        if screen and screen.show_attributes:
            show_attribute_uuids = [ sa.uuid for sa in screen.show_attributes ]
        return {'uuid': screen.uuid,
         'identifier': screen.identifier,
         'title': screen.title,
         'capacity': screen.capacity,
         'show_attributes': show_attribute_uuids,
         'capabilities': capabilities,
         'devices': [ device.uuid for device in screen.devices ] if screen.devices else [],
         'last_modified': screen.last_modified}

    def re_assess_and_sync(self, device_uuid):
        time.sleep(self.core.monitor_frequency)
        if not self.core.devices[device_uuid].device_status['confirmed']:
            return (False, _('%s Failed to create device') % self.core.get_pretty_name(device_uuid))
        else:
            return (True, _('%s created') % self.core.get_pretty_name(device_uuid))

    def save_device(self, device):
        messages = []
        core_lms_id = self.core.get_lms_id()
        if device.get('uuid', -1) == core_lms_id:
            cfg.lms_ftp_ip.set(device.get('ftp_ip', ' '))
            cfg.lms_ftp_port.set(device.get('ftp_port', ' '))
            cfg.lms_ftp_username.set(device.get('ftp_username', ' '))
            cfg.lms_ftp_password.set(device.get('ftp_password', ' '))
            config.save()
            db_lms = db.Session.query(db.Device).filter(db.Device.uuid == core_lms_id).one()
            db_lms.ftp_ip_address = device.get('ftp_ip', ' ')
            db_lms.ftp_port = device.get('ftp_port', ' ')
            db_lms.ftp_username = device.get('ftp_username', ' ')
            db_lms.ftp_password = device.get('ftp_password', ' ')
            db.Session.commit()
            device_dictionary = self._device_to_dictionary(db_lms)
            self.core.devices[cfg.lms_uuid()].last_modified = time.time()
            cherrypy.engine.publish('ccpush', 'device_information', {'devices': {self.core.get_lms_id(): device_dictionary}})
            if cfg.lms_custom_ftp_enabled():
                try:
                    if sys.platform == 'win32':
                        ctypes.windll.kernel32.TerminateProcess(int(cherrypy.ftpproc._handle), -1)
                    else:
                        os.kill(cherrypy.ftpproc.pid, 9)
                except Exception:
                    logging.error('Problem terminating FTP subprocess while saving LMS device', exc_info=True)

                with open(os.devnull, 'w') as tempout:
                    ftp_server_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'bin', 'FTPServer.py')
                    cherrypy.ftpproc = subprocess.Popen([sys.executable,
                     ftp_server_path,
                     '-s',
                     str(cfg.lms_ftp_ip()),
                     '-p',
                     str(cfg.lms_ftp_port()),
                     '-d',
                     cfg.lms_library_directory(),
                     '-u',
                     cfg.lms_ftp_username(),
                     '-w',
                     cfg.lms_ftp_password(),
                     '-t',
                     str(cfg.lms_custom_ftp_timeout())], stdin=tempout, stdout=tempout)
                logging.info('FTP Server Restarted.')
                time.sleep(3)
                try:
                    self.core.resync_ftp_server()
                except:
                    msg = "Couldn't update ftp file system."
                    self.core.configuration_service.set_enabled(self.core.get_lms_id(), False)
                    logging.info(msg)

        elif device.get('category') != 'sms' or not self.core.max_servers_reached() or device.get('uuid', None):
            try:
                db_device = db.Session.query(db.Device).filter(db.Device.uuid == device.get('uuid', None)).one()
            except NoResultFound:
                db_device = db.Device()
                if 'uuid' in device:
                    db_device.uuid = device['uuid']
                db.Session.add(db_device)

            db_device.type = device.get('type')
            db_device.name = device.get('name')
            db_device.path = device.get('path')
            db_device.ip_address = device.get('ip')
            db_device.port = device.get('port')
            db_device.api_username = device.get('api_username')
            db_device.api_password = device.get('api_password')
            db_device.ftp_ip_address = device.get('ftp_ip')
            db_device.ftp_port = device.get('ftp_port')
            db_device.ftp_password = device.get('ftp_password')
            db_device.ftp_username = device.get('ftp_username')
            db_device.cert_path = device.get('cert_path')
            db_device.auto_sync = device.get('auto_sync')
            db_device.auto_ingest = device.get('auto_ingest')
            db_device.screen_uuid = device.get('screen_uuid')
            db_device.model = device.get('model')
            if 'enabled' in device:
                db_device.enabled = device['enabled']
            if 'category' in device:
                db_device.category = device['category']
            db_device.set_modified()
            db.Session.commit()
            device_dictionary = self._device_to_dictionary(db_device)
            cherrypy.engine.publish('ccpush', 'device_information', {'devices': {db_device.uuid: device_dictionary}})
        else:
            messages.append({'type': 'error',
             'message': _('Licensed Screen count has been reached. Cannot configure more Screens')})
            return messages
        device_uuid = device_dictionary['id']
        if isinstance(device, LogicalDrive) and cfg.lms_custom_ftp_enabled() and device['path']:
            self.core.resync_ftp_server()
        if device_uuid in self.core.devices:
            new_device = self.core._create_device(device_uuid, device_dictionary)
            if device.get('category') in ('sms',):
                new_device.first_sync = True
            self.core._replace_device(device_uuid, new_device)
        else:
            self.core.devices[device_uuid] = self.core._create_device(device_uuid, device_dictionary)
            if device.get('category') in ('sms',):
                self.core.devices[device_uuid].first_sync = True
            if not cfg.core_log_collection_only():
                device_state_monitor = DeviceMonitor(cherrypy.engine, self.core.device_state_monitor, self.core.monitor_frequency, 'State Manager Device %s' % device_uuid, device_uuid)
                device_state_monitor.subscribe()
                device_state_monitor.start()
                device_acion_monitor = DeviceMonitor(cherrypy.engine, self.core.device_action_queue_handler, ACTION_MANAGER_CYCLE, 'Action Manager Device %s' % device_uuid, device_uuid)
                device_acion_monitor.subscribe()
                device_acion_monitor.start()
        if device_dictionary['enabled'] and device.get('category') != 'pos':
            action = Action(self.re_assess_and_sync, device_uuid)
            self.core.devices[device_uuid].push_action_stack(action)
            message = 'Device saved:'
            if device.get('screen_uuid', None):
                message += device['type'] + ' on'
            audit_log(message + ' {device:device_uuid}', meta={'device': device_uuid}, tags=['configuration', 'device', 'save'])
            messages.append({'type': 'action',
             'action_id': action.action_id,
             'message': _('Saved: %s') % device['type']})
        else:
            messages.append({'type': 'success',
             'message': _('Saved: %s') % device['type']})
        self._update_screens()
        if device.get('category') == 'sms':
            self.refresh_external_device_map(device_uuid)
        return messages

    def set_model(self, device_id, model):
        db.Session.query(db.Device).filter(db.Device.uuid == device_id).update({'model': model})
        db.Session.commit()

    def set_enabled(self, device_id, enabled = True):
        if self.core.get_lms_id() == device_id:
            cfg.lms_enabled.set(enabled)
            config.save()
            self.core.devices[self.core.get_lms_id()].device_configuration['enabled'] = enabled
            output_message = 'LMS'
        else:
            device = db.Session.query(db.Device).filter(db.Device.uuid == device_id).one()
            device.enabled = enabled
            device.set_modified()
            db.Session.commit()
            self.core.devices[device.uuid].device_configuration['enabled'] = enabled
            output_message = device.type
        device = self.core.devices[device_id]
        if enabled and not device.device_status['confirmed']:
            device.device_status['last_assess_time'] = 0
        if isinstance(device, pos_emulator) or isinstance(device, sms_emulator):
            if enabled:
                device.startup()
            else:
                device.shutdown()
        if device.device_configuration['category'] == 'pos':
            self.core.pos_service.update_mapping_overview()
            self.core.pos_service.pos_sync_error = None
        message = 'Device state updated: '
        if 'screen_uuid' in device.device_configuration and device.device_configuration['screen_uuid']:
            message += device.device_configuration['type'] + ' on '
        audit_log(message + '{device:device_uuid} %s' % ('Enabled' if enabled else 'Disabled'), meta={'device': device_id}, tags=['configuration', 'device', 'modified'])
        cherrypy.engine.publish('ccpush', 'device_information_update', {'device_uuid': device_id,
         'device_information': {'enabled': device.device_configuration['enabled']}})
        if enabled:
            return {'type': 'success',
             'message': _('Enabled: %s') % output_message}
        else:
            return {'type': 'success',
             'message': _('Disabled: %s') % output_message}
            return

    def delete_device(self, device_ids):
        messages = []
        devices = db.Session.query(db.Device).filter(db.Device.uuid.in_(device_ids))
        for device in devices:
            device_uuid = device.uuid
            device_type = device.type
            if device.category == 'pos':
                self.core.pos.service.remove_pos_device_sessions(device_uuid, device_type)
            self.remove_device(device_uuid)
            audit_log('Device deleted: uuid="%s" type="%s" ' % (device_uuid, device_type), tags=['configuration', 'device', 'delete'])
            messages.append({'type': 'success',
             'message': _('Deleted: %s') % device_type})

        db_schedules = db.Session.query(db.Schedule).filter(db.Schedule.device_uuid.in_(device_ids))
        for db_schedule in db_schedules.all():
            self.core.schedule_validation.remove_validation(db_schedule)

        db_schedules.delete(False)
        db.Session.query(db.MacroPack).filter(db.MacroPack.device_uuid.in_(device_ids)).delete(False)
        external_dev_maps = db.Session.query(db.ExternalDeviceMap).filter(db.ExternalDeviceMap.device_uuid.in_(device_ids))
        external_dev_maps.update({db.ExternalDeviceMap.device_uuid: None}, synchronize_session='fetch')
        devices.delete(False)
        db.Session.commit()
        for uuid in device_ids:
            cherrypy.engine.publish('ccpush', 'device_remove', {'uuid': uuid})

        self._update_screens()
        return messages

    def remove_device(self, device_uuid):
        if self.core.devices.get(device_uuid):
            self.core.devices[device_uuid].deleting_device = True
        for thread in threading.enumerate():
            if thread.name == 'Action Manager Device %s' % device_uuid:
                if thread is None:
                    cherrypy.engine.log('No thread running for %s.' % thread.name)
                elif thread is not threading.currentThread():
                    self._action(self.core.devices[device_uuid].shutdown)
                break

        if device_uuid in self.core.devices:

            def remove():
                cherrypy.engine.publish('device_remove', self.core.devices[device_uuid])
                self.core.devices[device_uuid].clear_action_queue()
                del self.core.devices[device_uuid]
                self.core.contents.device_removed(device_uuid)
                cherrypy.engine.publish('device_removed', device_uuid)

            async_execute(remove)
        return

    def save_custom_specifications(self, specifications):
        """
        Add custom device specifications to the metadata
        :param specifications: list of specifications to add
        """
        stored_categories = cherrypy.core.custom_device_metadata
        for spec in specifications:
            category = spec['category']
            type = spec['make']
            model = spec['model']
            api_version = spec['api_version']
            screen_device = spec['screen_device']
            complex_device = spec['complex_device']
            if category not in stored_categories:
                stored_categories[category] = {}
            if type not in stored_categories[category]:
                stored_categories[category][type] = []
            found = False
            for m in stored_categories[category][type]:
                if m['model'] == model and m['api_v'] == api_version:
                    found = True
                    m['screen_device'] = screen_device
                    m['complex_device'] = complex_device
                    break

            if not found:
                stored_categories[category][type].append({'model': model,
                 'api_v': api_version,
                 'custom': True,
                 'screen_device': screen_device,
                 'complex_device': complex_device})

        self._store_custom_specifications()

    def delete_custom_specifications(self, specifications):
        """
        Remove custom device specifications from the metadata
        :param list specifications: list of specifications to remove
        """
        stored_categories = cherrypy.core.custom_device_metadata
        for spec in specifications:
            category = spec['category']
            type = spec['make']
            model = spec['model']
            api_version = spec['api_version']
            screen_device = spec['screen_device']
            complex_device = spec['complex_device']
            stored_category = stored_categories.get(category)
            if stored_category:
                stored_type = stored_category.get(type)
                if stored_type:
                    try:
                        stored_type.remove({'model': model,
                         'api_v': api_version,
                         'custom': True,
                         'screen_device': screen_device,
                         'complex_device': complex_device})
                    except ValueError:
                        pass

                    if not len(stored_type):
                        stored_category.pop(type, None)
                if not len(stored_category):
                    stored_categories.pop(category)

        self._store_custom_specifications()
        return

    def _store_custom_specifications(self):
        """
        Writes the custom device metadata json back to disk
        """
        custom_path = os.path.join(app_dir, 'configuration', 'custom_device_metadata.json')
        with open(custom_path, 'w+') as f:
            f.write(json.dumps(cherrypy.core.custom_device_metadata))
        self.load_device_specifications()

    def load_device_specifications(self):
        """
        Load device specification data from disk, and merge in custom specs
        """
        cherrypy.core.screen_device_metadata = json.loads(open(os.path.join(app_dir, 'configuration', 'screen_device_metadata.json'), 'r').read())
        cherrypy.core.complex_device_metadata = json.loads(open(os.path.join(app_dir, 'configuration', 'complex_device_metadata.json'), 'r').read())
        custom_path = os.path.join(app_dir, 'configuration', 'custom_device_metadata.json')
        if os.path.exists(custom_path):
            cherrypy.core.custom_device_metadata = json.loads(open(custom_path).read())
        else:
            cherrypy.core.custom_device_metadata = {}

        def merge_device_metadata(original, updates, include):
            """
            Merge custom device specification metadata into the screen and device
            metadata stored in core, including any models with True for a key 'include'
            This is used to filter out screen and complex devices
            """
            for category in updates:
                if category not in original:
                    original[category] = {}
                for type in updates[category]:
                    if type not in original[category]:
                        original[category][type] = []
                    original[category][type].extend([ {'model': t['model'],
                     'api_v': t['api_v']} for t in updates[category][type] if t.get(include) ])
                    if not len(original[category][type]):
                        del original[category][type]

                if not len(original[category]):
                    del original[category]

        merge_device_metadata(cherrypy.core.screen_device_metadata, cherrypy.core.custom_device_metadata, 'screen_device')
        merge_device_metadata(cherrypy.core.complex_device_metadata, cherrypy.core.custom_device_metadata, 'complex_device')

    def save_kdm_email_configuration(self, user, passw, server, protocol, enabled):
        cfg.email_username.set(user)
        cfg.email_password.set(passw)
        cfg.email_server.set(server)
        cfg.email_protocol.set(protocol)
        cfg.kdm_email_enabled.set(enabled)
        config.save()
        self.core.kdm_email_read_uidls = []
        if enabled:
            SSL = False
            validation = None
            if 'SSL' in protocol:
                SSL = True
            if 'POP' in protocol:
                validation = email_pop(server, user, passw, SSL).validate_connection()
            elif 'IMAP' in protocol:
                validation = email_imap(server, user, passw, SSL).validate_connection()
            if not validation:
                self.core.kdm_email_status = False
                return {'type': 'error',
                 'message': _('Could not connect to email account')}
            else:
                self.core.kdm_email_status = True
                return {'type': 'success',
                 'message': _('Connected to email account')}
        else:
            self.core.kdm_email_status = None
            return {'type': 'success',
             'message': _('Saved')}
        return

    def get_kdm_email_configuration(self):
        config_info = {}
        config_info['enabled'] = cfg.kdm_email_enabled.get()
        config_info['username'] = cfg.email_username.get()
        config_info['password'] = cfg.email_password.get()
        config_info['server'] = cfg.email_server.get()
        config_info['protocol'] = cfg.email_protocol.get()
        return config_info

    def get_chat_email_configuration(self):
        return {'server': cfg.core_chat_email_server(),
         'port': cfg.core_chat_email_port(),
         'to': cfg.core_chat_email_to(),
         'cc': cfg.core_chat_email_cc(),
         'from': cfg.core_chat_email_from()}

    def save_chat_email_configuration(self, server, port, to, cc, from_):
        cfg.core_chat_email_server.set(server)
        cfg.core_chat_email_port.set(port)
        cfg.core_chat_email_to.set(to)
        cfg.core_chat_email_cc.set(cc)
        cfg.core_chat_email_from.set(from_)
        config.save()
        return {'type': 'success',
         'message': _('Saved')}

    def save_complex_settings(self, name, timezone, sub_lang, audio_lang):
        cfg.complex_name.set(name)
        cfg.timezone.set(timezone)
        cfg.audio_language.set(audio_lang)
        cfg.subtitle_language.set(sub_lang)
        config.save()
        cherrypy.engine.publish('edit_complex')
        return {'type': 'success',
         'message': _('Saved')}

    def delete_log_timeframe(self, uuid):
        db.Session.query(db.Timeframe).filter(db.Timeframe.uuid == uuid).delete(False)
        db.Session.commit()
        return {'type': 'success',
         'message': _('Deleted')}

    def save_log_timeframe(self, start, end, uuid = None, screens = [], default = False):
        if default:
            cfg.core_log_start_hour.set(start // 3600)
            cfg.core_log_start_minute.set(start // 60 % 60)
            cfg.core_log_end_hour.set(end // 3600)
            cfg.core_log_end_minute.set(end // 60 % 60)
            config.save()
            return ('default', {'type': 'success',
              'message': _('Saved')})
        if uuid:
            timeframe = db.Session.query(db.Timeframe).get(uuid)
        else:
            uuid = str(uuid4())
            timeframe = db.Timeframe()
            timeframe.uuid = uuid
        timeframe.start_time = start
        timeframe.end_time = end
        db.Session.add(timeframe)
        db.Session.query(db.TimeframeMap).filter(db.TimeframeMap.timeframe_uuid == uuid).delete('fetch')
        for screen in screens:
            tmap = db.TimeframeMap()
            tmap.screen_uuid = screen
            tmap.timeframe_uuid = timeframe.uuid
            db.Session.add(tmap)

        db.Session.commit()
        return (uuid, {'type': 'success',
          'message': _('Saved')})

    def get_log_timeframes(self):
        db_timeframes = db.Session.query(db.Timeframe).options(joinedload('screens')).all()
        timeframes = [{'uuid': 'default',
          'start': cfg.core_log_start_hour.get() * 60 * 60 + cfg.core_log_start_minute.get() * 60,
          'end': cfg.core_log_end_hour.get() * 60 * 60 + cfg.core_log_end_minute.get() * 60,
          'screens': {'default': 'All'}}]
        for t in db_timeframes:
            screens = {}
            for s in t.screens:
                screens[s.uuid] = s.identifier

            timeframes.append({'uuid': t.uuid,
             'start': t.start_time,
             'end': t.end_time,
             'screens': screens})

        return (timeframes, [])

    def save_log_settings(self, start_hours = None, start_minutes = None, end_hours = None, end_minutes = None, store_device_logs = None, retry_days = None, storage_limit = None):
        if start_hours:
            cfg.core_log_start_hour.set(start_hours)
        if start_minutes:
            cfg.core_log_start_minute.set(start_minutes)
        if end_hours:
            cfg.core_log_end_hour.set(end_hours)
        if end_minutes:
            cfg.core_log_end_minute.set(end_minutes)
        if store_device_logs != None:
            cfg.core_store_device_logs.set(store_device_logs)
        if retry_days != None:
            cfg.core_log_retry_days.set(retry_days)
        if storage_limit != None:
            cfg.core_log_storage_limit.set(storage_limit)
        config.save()
        return {'type': 'success',
         'message': _('Saved')}

    def log_settings(self):
        return {'start_hours': cfg.core_log_start_hour.get(),
         'start_minutes': cfg.core_log_start_minute.get(),
         'end_hours': cfg.core_log_end_hour.get(),
         'end_minutes': cfg.core_log_end_minute.get(),
         'store_device_logs': cfg.core_store_device_logs.get(),
         'storage_limit': cfg.core_log_storage_limit.get(),
         'log_day_average': self.core.log_manager.get_avg_day_size(),
         'retry_days': cfg.core_log_retry_days.get(),
         'collection_only': cfg.core_log_collection_only()}

    def save_transfer_settings(self, tonight_hours = None, tonight_minutes = None, auto_transfer_enabled = False, auto_transfer_asap = False):
        logging.info('Tonight: %s:%s:0' % (tonight_hours, tonight_minutes))
        logging.info('Auto transfer enabled: %s' % auto_transfer_enabled)
        logging.info('Auto transfer ASAP: %s' % auto_transfer_asap)
        cfg.core_tonight_hour.set(tonight_hours)
        cfg.core_tonight_minute.set(tonight_minutes)
        cfg.core_auto_transfer_content.set(auto_transfer_enabled)
        cfg.core_auto_transfer_content_asap.set(auto_transfer_asap)
        config.save()
        return {'type': 'success',
         'message': _('Saved')}

    def transfer_settings(self):
        return {'tonight_hours': cfg.core_tonight_hour.get(),
         'tonight_minutes': cfg.core_tonight_minute.get(),
         'auto_transfer_enabled': cfg.core_auto_transfer_content.get(),
         'auto_transfer_asap': cfg.core_auto_transfer_content_asap.get()}

    def trailer_rating_content(self):
        cpls = []
        for cpl in cfg.core_trailer_rating_cpls.get().split(','):
            if cpl != '':
                cpls.append(cpl)

        return {'cpls': cpls}

    def save_trailer_rating_content(self, cpls):
        cfg.core_trailer_rating_cpls.set(','.join(cpls))
        config.save()
        return {'type': 'success',
         'message': _('Saved')}

    def reboot_device(self, device_uuid):
        audit_log('Device reboot attempted: device_uuid="%s" ' % device_uuid, tags=['configuration', 'device', 'reboot'])
        response = self.core.devices[device_uuid].reboot()
        if len(response['error_messages']):
            return {'type': 'error',
             'message': response['error_messages'][0]}
        else:
            return {'type': 'success',
             'message': _('Rebooting')}

    def get_bookend_settings(self):
        bookend_settings = {}
        lms_id = self.core.get_lms_id()
        lms_device = self.core.devices[lms_id]
        bookend_settings['playlists'] = lms_device._device_get_playlist_information([], [])
        start_active = cfg.core_bookend_start_active()
        start_spl_offset = cfg.core_bookend_start_spl_offset()
        start_spl_uuid = cfg.core_bookend_start_spl_uuid()
        bookend_settings['start_of_day'] = {'active': start_active,
         'spl_offset': start_spl_offset,
         'spl_uuid': start_spl_uuid}
        end_active = cfg.core_bookend_end_active()
        end_spl_offset = cfg.core_bookend_end_spl_offset()
        end_spl_uuid = cfg.core_bookend_end_spl_uuid()
        bookend_settings['end_of_day'] = {'active': end_active,
         'spl_offset': end_spl_offset,
         'spl_uuid': end_spl_uuid}
        return bookend_settings

    def save_bookend_settings(self, start_active, start_spl_offset, start_spl_uuid, end_active, end_spl_offset, end_spl_uuid):
        message = None
        try:
            cfg.core_bookend_start_active.set(start_active)
            cfg.core_bookend_start_spl_offset.set(start_spl_offset)
            cfg.core_bookend_start_spl_uuid.set(start_spl_uuid)
            cfg.core_bookend_end_active.set(end_active)
            cfg.core_bookend_end_spl_offset.set(end_spl_offset)
            cfg.core_bookend_end_spl_uuid.set(end_spl_uuid)
            config.save()
            message = {'type': 'success',
             'message': _('Saved')}
        except Exception:
            logging.error('Error in updating bookend settings', exc_info=True)
            message = {'type': 'error',
             'message': _('Unknown error while updating')}

        cherrypy.engine.publish('queue_schedule_sync')
        return message

    def ftp_rescan(self, ftp_device_id):
        ftp_device = self.core.devices[ftp_device_id]
        try:
            action = Action(ftp_device.rescan_content)
            self.core.devices[ftp_device_id].push_action_stack(action)
            return {'type': 'action',
             'action_id': action.action_id,
             'message': _('Scanning has begun')}
        except Exception as ex:
            logging.error('error scanning ftp device', exc_info=True)
            return {'type': 'error',
             'message': str(ex)}

    def test_connection(self, device_uuids):
        device_info = {}
        device_uuids = self._get_devices(device_uuids, Monitor)[0]
        for device_uuid in device_uuids:
            action_id = self._action(self.core.devices[device_uuid].test_management_connection)
            device_info[device_uuid] = {'management': action_id}

        device_uuids = self._get_devices(device_uuids, Content)[0]
        for device_uuid in device_uuids:
            action_id = self._action(self.core.devices[device_uuid].test_content_connection)
            device_info.setdefault(device_uuid, {})['content'] = action_id

        return device_info

    def regenerate_flmx(self):
        try:
            FLMX.generate(self.core, get_flmx_filename(), cfg.wsw_enabled())
        except Exception:
            raise
        else:
            return {'type': 'success'}

    def get_auto_cleanup_settings(self):
        cleanup_settings = {}
        cleanup_settings['core_auto_cleanup_playlists'] = cfg.core_auto_cleanup_playlists()
        cleanup_settings['core_auto_cleanup_playlists_expiry_days'] = cfg.core_auto_cleanup_playlists_expiry_days()
        cleanup_settings['core_auto_cleanup_kdms'] = cfg.core_auto_cleanup_kdms()
        cleanup_settings['core_auto_cleanup_packs'] = cfg.core_auto_cleanup_packs()
        cleanup_settings['core_auto_cleanup_schedules'] = cfg.core_auto_cleanup_schedules()
        cleanup_settings['core_auto_cleanup_pos'] = cfg.core_auto_cleanup_pos()
        cleanup_settings['core_auto_cleanup_titles'] = cfg.core_auto_cleanup_titles()
        cleanup_settings['core_auto_cleanup_transfers'] = cfg.core_auto_cleanup_transfers()
        cleanup_settings['core_auto_cleanup_log_files'] = cfg.core_auto_cleanup_log_files()
        cleanup_settings['core_auto_cleanup_watchfolder'] = cfg.core_auto_cleanup_watchfolder()
        return cleanup_settings

    def get_configuration(self, configs):

        def _get(config_name):
            try:
                return getattr(cfg, config_name).get()
            except AttributeError:
                return None

            return None

        output = {}
        for config_name in configs:
            if config_name.endswith('*'):
                for attribute in dir(cfg):
                    if (config_name == '*' or attribute.startswith(config_name[0:-1])) and not attribute.startswith('_'):
                        output[attribute] = _get(attribute)

            elif _get(config_name):
                output[config_name] = _get(config_name)

        return output

    def set_configuration(self, configs):
        for config_name, config_value in configs.iteritems():
            try:
                getattr(cfg, config_name).set(config_value)
            except AttributeError:
                pass

        config.save()
        return {'type': 'success',
         'message': _('Saved.')}

    def save_auto_cleanup_settings(self, settings):
        if 'core_auto_cleanup_kdms' in settings:
            cfg.core_auto_cleanup_kdms.set(settings['core_auto_cleanup_kdms'])
        if 'core_auto_cleanup_packs' in settings:
            cfg.core_auto_cleanup_packs.set(settings['core_auto_cleanup_packs'])
        if 'core_auto_cleanup_schedules' in settings:
            cfg.core_auto_cleanup_schedules.set(settings['core_auto_cleanup_schedules'])
        if 'core_auto_cleanup_pos' in settings:
            cfg.core_auto_cleanup_pos.set(settings['core_auto_cleanup_pos'])
        if 'core_auto_cleanup_titles' in settings:
            cfg.core_auto_cleanup_titles.set(settings['core_auto_cleanup_titles'])
        if 'core_auto_cleanup_transfers' in settings:
            cfg.core_auto_cleanup_transfers.set(settings['core_auto_cleanup_transfers'])
        if 'core_auto_cleanup_log_files' in settings:
            cfg.core_auto_cleanup_log_files.set(settings['core_auto_cleanup_log_files'])
        if 'core_auto_cleanup_playlists' in settings:
            cfg.core_auto_cleanup_playlists.set(settings['core_auto_cleanup_playlists'])
        if 'core_auto_cleanup_watchfolder' in settings:
            cfg.core_auto_cleanup_watchfolder.set(settings['core_auto_cleanup_watchfolder'])
        if 'core_auto_cleanup_playlists_expiry_days' in settings:
            cfg.core_auto_cleanup_playlists_expiry_days.set(settings['core_auto_cleanup_playlists_expiry_days'])
        config.save()
        return [{'type': 'success',
          'message': _('Saved')}]

    def get_auto_playlist_generation_settings(self):
        config_info = {}
        config_info['core_templated_playlist_name'] = cfg.core_templated_playlist_name.get()
        config_info['name_choices'] = []
        current_name_pattern_found = False
        for nchoice in AUTO_PLAYLIST_NAMES:
            if config_info['core_templated_playlist_name'] == nchoice:
                config_info['name_choices'].append({'title': nchoice,
                 'value': nchoice,
                 'selected': True})
                current_name_pattern_found = True
            else:
                config_info['name_choices'].append({'title': nchoice,
                 'value': nchoice,
                 'selected': False})

        if not current_name_pattern_found:
            config_info['name_choices'].append({'title': config_info['core_templated_playlist_name'],
             'value': config_info['core_templated_playlist_name'],
             'selected': True})
        config_info['core_templated_playlist_date_format'] = cfg.core_templated_playlist_date_format.get()
        now = datetime.now()
        config_info['date_choices'] = []
        current_date_found = False
        for dchoice in AUTO_PLAYLIST_DATES:
            if config_info['core_templated_playlist_date_format'] == dchoice:
                config_info['date_choices'].append({'title': now.strftime(dchoice),
                 'value': dchoice,
                 'selected': True})
                current_date_found = True
            else:
                config_info['date_choices'].append({'title': now.strftime(dchoice),
                 'value': dchoice,
                 'selected': False})

        if not current_date_found:
            config_info['date_choices'].append({'title': now.strftime(config_info['core_templated_playlist_date_format']),
             'value': config_info['core_templated_playlist_date_format'],
             'selected': True})
        return config_info

    def save_auto_playlist_generation_settings(self, settings):
        if 'core_templated_playlist_name' in settings:
            cfg.core_templated_playlist_name.set(settings['core_templated_playlist_name'])
        if 'core_templated_playlist_date_format' in settings:
            cfg.core_templated_playlist_date_format.set(settings['core_templated_playlist_date_format'])
        config.save()
        return {'type': 'success',
         'message': _('Saved')}

    def test_naming_pattern(self, pos_auto_playlist_name_pattern, pos_auto_playlist_date_format):
        test_title = self.core.schedule_synchroniser.create_scheduled_playlist_title_testing(pos_auto_playlist_name_pattern, pos_auto_playlist_date_format)
        return_data = {'passed': False,
         'title': test_title}
        if test_title:
            return_data['passed'] = True
        return return_data

    def get_default_naming_pattern(self):
        return {'pattern': cfg.core_templated_playlist_name.get_default(),
         'date_format': cfg.core_templated_playlist_date_format.get_default()}

    def save_contact(self, name, phone1, email, type, contact_id = None):
        if contact_id:
            contact = db.Session.query(db.Contact).filter(db.Contact.id == contact_id).one()
        else:
            contact = db.Contact()
            db.Session.add(contact)
        contact.name = name
        contact.phone1 = phone1
        contact.type = type
        contact.email = email
        db.Session.commit()
        cherrypy.engine.publish('add_contact')
        return {'type': 'success',
         'message': _('Saved')}

    def get_contacts(self):
        output = {}
        contacts = db.Session.query(db.Contact).all()
        for contact in contacts:
            output[contact.id] = contact.to_dict()

        return output

    def delete_contact(self, contact_id):
        db.Session.query(db.Contact).filter_by(id=contact_id).delete()
        db.Session.commit()
        if db.Session.query(db.Contact).get(contact_id) is None:
            cherrypy.engine.publish('contact_remove')
            return {'type': 'success',
             'message': _('Contact deleted')}
        else:
            return {'type': 'error',
             'message': _('Could not delete contact')}

    def save_address(self, type, addressee, streetaddress, streetaddress2, city, province, postcode, country, address_id = None):
        if address_id:
            address = db.Session.query(db.Address).filter(db.Address.id == address_id).one()
        else:
            address = db.Address()
            db.Session.add(address)
        address.type = type
        address.addressee = addressee
        address.streetaddress = streetaddress
        address.streetaddress2 = streetaddress2
        address.city = city
        address.province = province
        address.postcode = postcode
        address.country = country
        db.Session.commit()
        cherrypy.engine.publish('edit_address')
        return {'type': 'success',
         'message': _('Saved')}

    def get_addresses(self):
        addresses = db.Session.query(db.Address).all()
        output = {}
        for address in addresses:
            output[address.id] = address.to_dict()

        return output

    def delete_address(self, address_id):
        db.Session.query(db.Address).filter_by(id=address_id).delete()
        db.Session.commit()
        if db.Session.query(db.Address).filter_by(id=address_id).first() is None:
            cherrypy.engine.publish('address_remove')
            return {'type': 'success',
             'message': _('Address deleted')}
        else:
            return {'type': 'error',
             'message': _('Could not delete address')}

    def _get_sync_configurations(self):
        """
        Get any config values prepended with the word "sync"
        """
        configs = {}
        for field in dir(cfg):
            if field.startswith('sync_'):
                value = getattr(cfg, field)
                if isinstance(value, config.OptionNum):
                    configs[field] = value

        return configs

    def get_sync_settings(self):
        """
        Get Sync settings
        """
        output = {'configs': [],
         'presets': {'options': SYNC_PRESETS(),
                     'selected': cfg.sync_selected_preset.get()}}
        for config_name, config_val in self._get_sync_configurations().iteritems():
            if config_name == 'sync_auto_sync_ftp_validity' and not cfg.auto_sync_ftp_folders():
                continue
            output['configs'].append({'description': config_val.get_description(show_default=False),
             'value': config_val.get(),
             'max': config_val.maxval,
             'inc': config_val.incval,
             'min': config_val.minval,
             'index': config_val.get_index(),
             'icon': config_val.get_icon(),
             'name': config_name})

        output['configs'].sort(key=lambda x: x['index'])
        return output

    def set_sync_settings(self, settings, preset):
        """
        Set Sync settings
        """
        if preset:
            for config_name, config_val in self._get_sync_configurations().iteritems():
                config_val.preset(preset)

            cfg.sync_selected_preset.set(preset)
        else:
            for member, value in settings.iteritems():
                getattr(cfg, member).set(value)

        config.save()
        return {'type': 'success',
         'message': _('Saved')}
# okay decompyling ./core/services/configuration_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:07 CST
