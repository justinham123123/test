# 2017.08.13 21:50:13 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\macropack_service.py
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities import helper_methods
from serv.lib.utilities.helper_methods import audit_log, sqlite_chunk
from serv.core.devices.base.playback import Playback
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_, or_
import json
import logging
import uuid
import cherrypy

class MacroPackService(Service):

    def save(self, macro_packs):
        messages = []
        pack_placeholder_uuids = [ mp['macro_placeholder_uuid'] for mp in macro_packs ]
        placeholder_uuids = []
        for uuid_chunk in sqlite_chunk(pack_placeholder_uuids):
            placeholder_uuids.extend([ x[0] for x in db.Session.query(db.MacroPlaceholder.uuid).filter(db.MacroPlaceholder.uuid.in_(uuid_chunk)) ])

        for macro_pack in macro_packs:
            if macro_pack['macro_placeholder_uuid'] not in placeholder_uuids:
                messages.append({'type': 'error',
                 'message': _('Macro Pack Placeholder id %s does not exist') % macro_pack['macro_placeholder_uuid']})
                continue
            helper_methods.validate_playlist_events(macro_pack['event_list'])
            if not macro_pack.get('uuid'):
                macro_pack['uuid'] = str(uuid.uuid4())
            try:
                db_macro_pack = db.Session.query(db.MacroPack).filter(and_(db.MacroPack.device_uuid == macro_pack['device_uuid'], db.MacroPack.macro_placeholder_uuid == macro_pack['macro_placeholder_uuid'])).one()
                db_macro_pack.device_uuid = macro_pack['device_uuid']
                db_macro_pack.macro_placeholder_uuid = macro_pack['macro_placeholder_uuid']
                db_macro_pack.event_list = json.dumps(macro_pack['event_list'])
                db_macro_pack.producer_last_modified = macro_pack.get('last_modified')
                db_macro_pack.deleted = False
                db_macro_pack.set_modified(macro_pack.get('last_modified'))
                audit_log('Macro Pack updated: {macro_pack:macro_pack} on {device:device_uuid}', meta={'macro_pack': {'placeholder_name': db_macro_pack.macro_placeholder.name,
                                'uuid': macro_pack['uuid']},
                 'device': db_macro_pack.device_uuid}, tags=['macro_pack', 'modified'])
                messages.append({'type': 'success',
                 'message': _('Macro Pack updated'),
                 'macro_pack_uuid': macro_pack['uuid']})
            except NoResultFound:
                db_macro_pack = db.MacroPack()
                db_macro_pack.uuid = macro_pack['uuid']
                db_macro_pack.device_uuid = macro_pack['device_uuid']
                db_macro_pack.macro_placeholder_uuid = macro_pack['macro_placeholder_uuid']
                db_macro_pack.event_list = json.dumps(macro_pack['event_list'])
                db_macro_pack.producer_last_modified = macro_pack.get('last_modified')
                db_macro_pack.set_modified(macro_pack.get('last_modified'))
                db.Session.add(db_macro_pack)
                audit_log('Macro Pack created: {macro_pack:macro_pack} on {device:device_uuid}', meta={'macro_pack': {'placeholder_name': macro_pack['macro_placeholder_uuid'],
                                'uuid': macro_pack['uuid']},
                 'device': db_macro_pack.device_uuid}, tags=['macro_pack', 'save'])
                messages.append({'type': 'success',
                 'message': _('Macro Pack created'),
                 'macro_pack_uuid': macro_pack['uuid']})

        db.Session.commit()
        for macro_pack in macro_packs:
            if macro_pack.get('from_tms', True):
                cherrypy.engine.publish('ccpush', 'macropack_update', {'macro_pack': macro_pack})

        return messages

    def delete(self, macro_pack_uuids, hard = False):
        macro_packs = db.Session.query(db.MacroPack).filter(db.MacroPack.uuid.in_(macro_pack_uuids))
        for macro_pack in macro_packs:
            audit_log('Macro Pack deleted: {macro_pack:macro_pack} from {device:device_uuid}', meta={'macro_pack': {'placeholder_name': macro_pack.macro_placeholder.name,
                            'uuid': macro_pack.uuid},
             'device': macro_pack.device_uuid}, tags=['macro_pack', 'delete'])
            if macro_pack.macro_placeholder.can_delete or hard:
                db.Session.delete(macro_pack)
            else:
                macro_pack.deleted = True

        db.Session.commit()
        for macro_pack_uuid in macro_pack_uuids:
            cherrypy.engine.publish('ccpush', 'macropack_remove', {'uuid': macro_pack_uuid})

        return {'type': 'success',
         'message': _('Deleted')}

    def macro_packs(self, macro_pack_uuids = [], show_deleted = False):
        macro_pack_details = {}
        macro_packs = db.Session.query(db.MacroPack)
        if not show_deleted:
            macro_packs = macro_packs.filter(db.MacroPack.deleted == False)
        if macro_pack_uuids:
            macro_packs = macro_packs.filter(db.MacroPack.uuid.in_(macro_pack_uuids))
        for macro_pack in macro_packs:
            macro_pack_details[macro_pack.uuid] = {'uuid': macro_pack.uuid,
             'device_uuid': macro_pack.device_uuid,
             'macro_placeholder_uuid': macro_pack.macro_placeholder_uuid,
             'event_list': json.loads(macro_pack.event_list),
             'last_modified': macro_pack.last_modified,
             'producer_last_modified': macro_pack.producer_last_modified,
             'deleted': macro_pack.deleted}

        return macro_pack_details

    def macro_placeholders(self, auto_transition = False):
        macro_placeholder_details = {}
        macro_placeholders = db.Session.query(db.MacroPlaceholder)
        for macro_placeholder in macro_placeholders:
            macro_placeholder_details[macro_placeholder.uuid] = {'uuid': macro_placeholder.uuid,
             'name': macro_placeholder.name,
             'transition': macro_placeholder.transition,
             'can_delete': macro_placeholder.can_delete,
             'has_content': macro_placeholder.has_content}

        if auto_transition:
            auto_transition_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, str('Auto Transition')))
            macro_placeholder_details[auto_transition_id] = {'uuid': auto_transition_id,
             'name': 'Auto Transition',
             'transition': False,
             'can_delete': False,
             'has_content': True,
             'type': 'auto_transition'}
        return macro_placeholder_details

    def save_macro_placeholder(self, macro_placeholder_name, has_content = True):
        db_macro_placeholder = db.Session.query(db.MacroPlaceholder).filter(db.MacroPlaceholder.name == macro_placeholder_name).all()
        if len(db_macro_placeholder) == 0:
            try:
                uuid_name = str(macro_placeholder_name)
            except UnicodeEncodeError:
                uuid_name = macro_placeholder_name.encode('punycode')

            new_macro_placeholder = db.MacroPlaceholder(uuid=str(uuid.uuid5(uuid.NAMESPACE_DNS, uuid_name)), name=macro_placeholder_name, has_content=has_content)
            db.Session.add(new_macro_placeholder)
            db.Session.commit()
            audit_log('Macro Placeholder saved: {macro_placeholder:macro_placeholder}', meta={'macro_placeholder': {'name': macro_placeholder_name,
                                   'uuid': new_macro_placeholder.uuid}}, tags=['macro_pack', 'save'])
            self.core.load_macro_pack_placeholders()
            return {'type': 'success',
             'message': _('Saved: %s') % macro_placeholder_name}
        else:
            return {'type': 'error',
             'message': _('Macro Placeholder name already exists')}

    def delete_macro_placeholders(self, macro_placeholder_uuids = []):
        """
        Attempts to delete the macro-placeholders specified.
        Won't delete a macro-placeholder if it is referenced by a template
        or playlist.
        
        :param macro_placeholder_uuids: a list of macro_placeholder_uuids
        :returns: a list of response dictionaries
        
            e.g.  [ {
                     'type': 'success',
                     'macro_placeholder_uuid: '....',
                     'message': 'Macro Placeholder deleted',
                    }
                    ...
                  }
        
        Deletes the specified macro placeholders and associated macro packs from core;
        """

        def macro_placeholder_used(macro_placeholder_uuid):
            """ Checks if the specified macro_placeholder is referenced by
                a playlist
                :param macro_placeholder_uuid: uuid of macro_placeholder to check for
                :returns:bool, True if the macro_placeholder is referenced in any
                         playlist or template on the LMS, otherwise False.
            """
            for playlist_uuid in lms_playlists[lms_device_id]:
                playlist = lms_playlists[lms_device_id][playlist_uuid]['playlist']
                events = playlist.get('events', [])
                for event in events:
                    if event.get('type') == 'macro_pack' and event.get('uuid') == macro_placeholder_uuid:
                        return True

            for template_uuid in templates:
                template = templates[template_uuid]
                events = template.get('event_list', []) or []
                for event in events:
                    if event.get('type') == 'macro_placeholder' and event.get('uuid') == macro_placeholder_uuid:
                        return True

            return False

        templates = self.core.template_service.template()[0]
        lms_device_id = self.core.get_lms_id()
        lms_playlists = self.core.playlist_service.playlist(device_ids=[lms_device_id])[0]
        messages = []
        deleted_placeholder_uuids = []
        macro_placeholders = db.Session.query(db.MacroPlaceholder).filter(and_(db.MacroPlaceholder.uuid.in_(macro_placeholder_uuids), db.MacroPlaceholder.can_delete == True))
        for macro_placeholder in macro_placeholders:
            name = macro_placeholder.name
            uuid = macro_placeholder.uuid
            if macro_placeholder_used(macro_placeholder.uuid):
                messages.append({'type': 'error',
                 'message': _('Cannot delete Macro Placeholder because it is referenced by a Playlist'),
                 'macro_placeholder_uuid': macro_placeholder.uuid})
            else:
                try:
                    db.Session.query(db.MacroPack).filter(db.MacroPack.macro_placeholder_uuid == macro_placeholder.uuid).delete(False)
                    db.Session.delete(macro_placeholder)
                    db.Session.commit()
                    audit_log('Macro Placeholder deleted: {macro_placeholder:macro_placeholder}', meta={'macro_placeholder': {'name': name,
                                           'uuid': uuid}}, tags=['macro_pack', 'delete'])
                    messages.append({'type': 'success',
                     'message': _('Deleted: %s') % name,
                     'placeholder_uuid': uuid})
                    deleted_placeholder_uuids.append(uuid)
                except Exception:
                    logging.error('Unable to delete macro placeholder %s %s' % (uuid, name), exc_info=True)

        self.core.load_macro_pack_placeholders()
        return messages

    def match_pack(self, macropack_placeholder_uuid, screen):
        """
        Looks for a macropack which matches the supplied macropack_placeholder
        and screen.
        :param macropack_placeholder_uuid: UUID of macropack placeholder type
        :param screen: dictionary containing screen details
        :returns: dictionary containing:
                {
                    'uuid': '<macro_pack_uuid>',
                    'events': {
        
        """
        active_device_id = None
        for device_id in screen['devices']:
            if isinstance(self.core.devices[device_id], Playback):
                active_device_id = device_id
                break

        if not active_device_id:
            return
        else:
            try:
                macro_pack = db.Session.query(db.MacroPack).filter(and_(db.MacroPack.macro_placeholder_uuid == macropack_placeholder_uuid, db.MacroPack.device_uuid == active_device_id, db.MacroPack.deleted == False)).one()
            except NoResultFound:
                return

            return {'uuid': macro_pack.uuid,
             'events': json.loads(macro_pack.event_list) if macro_pack.event_list else None}

    def _get_credit_offset_automation(self, screen):
        active_device_id = None
        for device_id in screen['devices']:
            if isinstance(self.core.devices[device_id], Playback):
                active_device_id = device_id
                break

        if active_device_id == None:
            return
        else:
            try:
                macro_pack = db.Session.query(db.MacroPack).filter(and_(db.MacroPack.macro_placeholder_uuid == '22c33709-268b-5e46-a4c0-8a55f61b95ea', db.MacroPack.device_uuid == active_device_id, db.MacroPack.deleted == False)).one()
            except NoResultFound:
                return

            return json.loads(macro_pack.event_list)[0]['automation']
# okay decompyling ./core/services/macropack_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:14 CST
