# 2017.08.13 21:50:16 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\note_service.py
from datetime import datetime, timedelta, time
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
from serv.lib.utilities.helper_methods import tstamp
from sqlalchemy import or_
import logging

class NoteService(Service):
    """
    Notes for staff to perform actions in their cinema, routine or otherwise (i.e. reminders),
     or to just log things (booth book)
    """

    def __init__(self, core):
        super(NoteService, self).__init__(core)

    def get_all(self, end_time, start_time):
        """
        Returns the list of notes with processed extra useful info.
        """
        if end_time:
            db_notes = db.Session.query(db.Note).filter(or_(db.Note.raised_at != None, db.Note.repeat_type != None)).order_by(db.Note.id.desc())
        else:
            db_notes = db.Session.query(db.Note).order_by(db.Note.id.desc())
        notes = []
        for db_note in db_notes:
            try:
                note = self._get_details(db_note, start_time)
                if 'remind' in note:
                    if end_time is None or note['remind']['next'] is not None and note['remind']['next'] < end_time:
                        notes.append(note)
                else:
                    notes.append(note)
            except Exception:
                logging.error('Invalid note', exc_info=True)

        return notes

    @db.close_session
    def delete(self, ids):
        """
        Deletes a note, or multiple.
        """
        if len(ids) == 0:
            return (False, 0)
        try:
            affected_rows = db.Session.query(db.Note).filter(db.Note.id.in_(ids)).delete(False)
            if affected_rows > 0:
                db.Session.commit()
                return (True, affected_rows)
        except Exception:
            logging.error('Could not delete notes %s', ids, exc_info=True)

        return (False, 0)

    @db.close_session
    def create(self, note):
        """
        Create a new note
        :returns: Two-tuple(
            success_status (bool)
            details (dit)
        )
        """
        db_note = db.Note()
        try:
            self._sanitise(note, db_note)
            db.Session.add(db_note)
            db.Session.commit()
            details = self._get_details(db_note)
            details['id'] = db_note.id
            return (True, {'id': db_note.id,
              'note': details})
        except Exception as e:
            logging.error('Could not create note', exc_info=True)
            return (False, {'error': e})

    @db.close_session
    def edit(self, note):
        """
        Edit an existing note
        """
        if 'id' not in note:
            return (False, _('Must specify an ID'))
        db_note = db.Session.query(db.Note).get(note['id'])
        if not db_note:
            return (False, _('ID was not found'))
        try:
            self._sanitise(note, db_note)
            out_note = self._get_details(db_note)
            db.Session.add(db_note)
            db.Session.commit()
            return (True, out_note)
        except Exception as e:
            logging.error('Could not edit note %s', note['id'], exc_info=True)
            return (False, _('Could not save note: %s' % e))

    def _get_details(self, db_note, start_time = None):
        note = dict(id=db_note.id, created=tstamp(db_note.created), subject=db_note.subject)
        note['detail'] = db_note.detail
        note['icon'] = db_note.icon
        note['group'] = db_note.group
        if not db_note.is_reminder():
            return note
        else:
            remind = {}
            now = datetime.fromtimestamp(start_time) if start_time else datetime.now()
            if db_note.is_repeat():
                repeat = dict(at=db_note.repeat_at, starting=db_note.repeat_from, type=db_note.repeat_type)
                remind['repeat'] = repeat
                repeat_time = self._parse_time(db_note.repeat_at, default=time(12))
                start_dt = datetime.combine(db_note.repeat_from, repeat_time)
                if db_note.is_variable_repeat():
                    repeat['frequency'] = db_note.repeat_frequency
                    repeat['days'] = [ d.day for d in db_note.repeat_days ]
                    remind['next'] = self._get_next_remind_weekly_repeat(start_dt, now, repeat)
                else:
                    remind['next'] = self._get_next_remind_daily_repeat(start_dt, now, repeat_time)
            else:
                note_done = db_note.raised_at and db_note.raised_at < now
                remind['time'] = db_note.raised_at.strftime('%H:%M:%S')
                remind['date'] = db_note.raised_at.strftime('%Y-%m-%d')
                remind['next'] = None if note_done else db_note.raised_at
            if remind['next'] is not None:
                remind['next'] = tstamp(remind['next'])
            note['remind'] = remind
            return note

    def _get_next_remind_daily_repeat(self, start_dt, now, repeat_time):
        if start_dt > now:
            return start_dt
        day_offset = 1 if repeat_time < now.time() else 0
        return datetime.combine(now.date(), repeat_time) + timedelta(days=day_offset)

    def _get_next_remind_weekly_repeat(self, start_dt, now, repeat):
        if len(repeat['days']) == 0:
            return None
        else:
            skip_period = repeat['frequency'] * 7
            diff = now - start_dt - timedelta(days=skip_period * 2)
            if diff.days > 0:
                start_dt += timedelta(days=diff.days // skip_period * skip_period)
            while True:
                weekday = (start_dt.weekday() + 1) % 7
                for i in range(7):
                    curr_day = (weekday + i) % 7
                    if curr_day in repeat['days']:
                        curr_dt = start_dt + timedelta(days=i)
                        if curr_dt > now:
                            return curr_dt

                start_dt += timedelta(days=7 * repeat['frequency'])

            return None

    def _sanitise(self, note, db_note):
        if 'id' in note and db_note.is_variable_repeat():
            db.Session.query(db.RepeatReminderDay).filter_by(note_id=note['id']).delete(False)
        if 'subject' in note:
            db_note.subject = self._parse_str(note['subject'], 80, '')
        if 'detail' in note:
            db_note.detail = self._parse_str(note['detail'], 500)
        if 'icon' in note:
            db_note.icon = self._parse_str(note['icon'], 32)
        if 'group' in note:
            db_note.group = self._parse_str(note['group'], 32)
        if 'confirm' in note:
            db_note.confirm = bool(note['confirm'])
        if 'complete' in note:
            db_note.complete = bool(note['complete'])
        if 'raised_at' in note:
            db_note.raised_at = self._parse_timestamp(note['raised_at'])
        if 'repeat_type' in note:
            db_note.repeat_type = self._parse_repeat_type(note['repeat_type'])
        if 'repeat_at' in note:
            db_note.repeat_at = self._parse_str(note['repeat_at'], 8)
        if 'repeat_from' in note:
            db_note.repeat_from = self._parse_date(note['repeat_from'])
        if 'repeat_days' in note:
            db_note.repeat_days = self._parse_repeat_days(note['repeat_days'])
        if 'repeat_frequency' in note:
            db_note.repeat_frequency = self._parse_int(note['repeat_frequency'])
        if db_note.is_repeat():
            db_note.raised_at = None
            if db_note.repeat_at is None:
                db_note.repeat_at = '12:00'
            if db_note.repeat_from is None:
                db_note.repeat_from = datetime.now().date()
        if db_note.is_variable_repeat():
            if db_note.repeat_frequency is None:
                db_note.repeat_frequency = 1
        return

    def _parse_timestamp(self, stamp):
        try:
            return datetime.fromtimestamp(float(stamp))
        except (ValueError, TypeError):
            logging.warn('Bad timestamp parsed: %s', stamp)
            return None

        return None

    def _parse_time(self, time_str, default = None):
        try:
            return time(*[ int(t) for t in time_str.split(':') ])
        except (ValueError, TypeError, AttributeError):
            logging.warn('Bad time string parsed: %s', time_str)
            return default

    def _parse_date(self, date_str, default = None):
        try:
            return datetime.strptime(date_str, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            logging.warn('Bad date string parsed: %s', date_str)
            return default

    def _parse_str(self, _str, max_len, default = None):
        try:
            return _str[:max_len]
        except Exception:
            logging.warn('Bad string parsed: %s', _str)
            return default

    def _parse_int(self, _int, default = None):
        try:
            return int(_int)
        except (ValueError, TypeError):
            logging.warn('Bad int parsed: %s', _int)
            return default

    def _parse_repeat_type(self, repeat_type):
        try:
            repeat_type = str(repeat_type).lower()
            if repeat_type in ('day', 'week'):
                return repeat_type
            return None
        except Exception:
            logging.warn('Bad repeat type parsed: %s', repeat_type)
            return None

        return None

    def _parse_repeat_days(self, repeat_days):
        try:
            return [ db.RepeatReminderDay(day=int(day)) for day in repeat_days if int(day) < 7 ]
        except (ValueError, TypeError):
            logging.warn('Bad repeat days parsed: %s', repeat_days)
            return []
# okay decompyling ./core/services/note_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:18 CST
