# 2017.08.13 21:50:07 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\content_service.py
from datetime import datetime, timedelta
from serv.lib.utilities import date_utils
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.dcp.writers.package import write_DCP
from serv.lib.dcinema.parsers.parsers import parse_cpl, parse_kdm
from serv.lib.dcinema.dcp.utils import ParsingException
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.core.devices.base.content import Content
from serv.core.devices.base.mount_point import MountPoint
from serv.core.devices.base.playback import Playback
from serv.lib.utilities.helper_methods import audit_log, packaging_log
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
from sqlalchemy.orm.exc import NoResultFound
import cherrypy
import copy
import json
import logging
import os
import shutil
import socket
import time
import uuid

class ContentService(Service):

    def reload_key_from_lms(self, key_uuid, device_uuid):
        logging.info('Reloading key %s from LMS to device %s' % (key_uuid, device_uuid))
        lms_uuid = self.core.get_lms_id()
        lms = self.core.devices[lms_uuid]
        key_xml = lms.get_key_xml(key_uuid)
        return self.add_key(key_xml, device_uuid, add_to_lms=False, source=lms_uuid, force=True)[1]

    def add_key(self, key, device_id = None, add_to_lms = True, source = 'Local', force = False):
        if device_id:
            logging.info('Adding key xml to device %s' % device_id)
        messages = []
        kdm = None
        try:
            kdm = parse_kdm(key, load_from_file=False)
        except Exception as ex:
            logging.error('There was a problem parsing the kdm', exc_info=True)
            messages.append({'type': 'error',
             'message': _('Error analysing KDM %s') % str(ex)})
        else:
            if kdm == {}:
                messages.append({'type': 'error',
                 'message': _('File is not a KDM')})
                logging.info('Parsed content is not a KDM')
            elif kdm.get('dn_qualifier', '?') == '?':
                messages.append({'type': 'error',
                 'message': _('dnQualifier cannot be read')})
                logging.info('dnQualifier cannot be read')
            elif kdm['end_date'] < time.time():
                logging.info('The KDM has expired')
                messages.append({'type': 'error',
                 'message': _('The KDM has expired.')})
            else:
                if device_id is None:
                    for _device_id in self.core.devices.keys():
                        if self.core.devices[_device_id].device_configuration['enabled']:
                            if kdm['dn_qualifier'] in self.core.devices[_device_id].device_information.get('dnqualifiers', ()):
                                device_id = _device_id
                                break

                if add_to_lms:
                    message = self._load_key_to_device(kdm, key, self.core.get_lms_id(), source)
                    messages.append(message)
                if device_id is None and cfg.core_auto_transfer_kdms_to_devices.get():
                    messages.append({'type': 'error',
                     'message': _('The KDM is not valid for any configured screen server')})
                elif device_id and (cfg.core_auto_transfer_kdms_to_devices.get() or force):
                    message = self._load_key_to_device(kdm, key, device_id, source)
                    messages.append(message)

        return (kdm['id'], messages)

    def _load_key_to_device(self, kdm, key, device_id, transfer_source):
        device = self.core.devices[device_id]
        if device.initial_sync_complete:
            if kdm['id'] not in device.key_information or device.key_information[kdm['id']].get('status') != 'ok':
                for transfer in device.transfer_information['queue']:
                    if 'kdm_uuid' in transfer and transfer.get('kdm_uuid') == kdm['id']:
                        logging.debug('KDM %s already queued for uploading to %s' % (kdm['id'], device_id))
                        return {'type': 'success',
                         'message': _('KDM %s is already queued for ingest on %s') % (kdm['text'], self.core.get_pretty_name(device_id))}
                else:
                    device_transfer = self._add_key_transfer(kdm, key, device_id, transfer_source)
                    device.transfer_information['queue'].append(device_transfer)
                    logging.debug('KDM %s queued for uploading to %s' % (kdm['id'], device_id))
                    audit_log('KDM queued for device upload: key_id="%s" on {device:device_uuid}' % kdm['id'], meta={'device': device_id}, tags=['kdm', 'transfer'])
                    return {'type': 'action',
                     'transfer_id': device_transfer['id'],
                     'device_id': device_id,
                     'message': _('KDM queued for transfer on %s') % self.core.get_pretty_name(device_id)}

            else:
                logging.debug('KDM %s already exists on %s' % (kdm['id'], device_id))
                return {'type': 'success',
                 'message': _('KDM %s already exists on %s') % (kdm['text'], self.core.get_pretty_name(device_id))}
        else:
            logging.debug('KDM %s not queued for transfer: %s has not synced' % (kdm['id'], device_id))
            return {'type': 'error',
             'message': _('%s: Waiting to queue KDM %s for transfer') % (self.core.get_pretty_name(device_id), kdm['text'])}

    @db.close_session
    def _add_key_transfer(self, kdm, kdm_xml, device_uuid, transfer_source):
        description = kdm.get('cpl_text')
        db_transfer = db.Transfer(destination_device_uuid=device_uuid, source=transfer_source, description=description, state='queued', type='KDM', core=True, content_uuid=kdm.get('cpl_id'), kdm_xml=kdm_xml, kdm_uuid=kdm.get('id'))
        db.Session.add(db_transfer)
        db.Session.commit()
        device_transfer = {'id': db_transfer.uuid,
         'state': 'queued',
         'description': description,
         'content_id': kdm.get('cpl_id'),
         'source': transfer_source,
         'type': 'KDM',
         'not_before': None,
         'server_transfer_id': None,
         'kdm_uuid': kdm.get('id')}
        return device_transfer

    @db.close_session
    def retry_key_transfer(self, transfer_uuid):
        messages = []
        try:
            transfer_object = db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_uuid).one()
            key = transfer_object.kdm_xml
            if key is None:
                messages.append({'type': 'error',
                 'message': _('KDM cannot be found')})
                return messages
            source = transfer_object.source
            destination = transfer_object.destination_device_uuid
        except NoResultFound:
            logging.error('Error re-transferring KDM, key XML not found in database.')
            messages.append({'type': 'error',
             'message': _('KDM cannot be found')})

        messages = self.add_key(key, destination, True, source, force=True)
        return messages

    def cancel_transfers(self, device_id, transfer_ids = []):
        action_id = None
        messages = []
        for transfer_id in transfer_ids:
            transfer_cancelled = False
            if transfer_id in self.core.devices[device_id].transfer_information['active']:
                action_id = self._action(self.core.devices[device_id].transfer_cancel_helper, transfer_id)
                audit_log('Transfer cancelled: transfer_id="%s" on {device:device_uuid}' % transfer_id, meta={'device': device_id}, tags=['transfer', 'delete'])
                transfer_cancelled = True
            else:
                with self.core.devices[device_id].transfer_information_lock:
                    for transfer in self.core.devices[device_id].transfer_information['queue'][:]:
                        if transfer['id'] == transfer_id:
                            transfer['state'] = 'cancelled'
                            transfer['message'] = _('Transfer cancelled')
                            transfer['message_code'] = 6
                            transfer['end_time'] = int(time.time())
                            transfer['end_time_string'] = helper_methods.format_timestamp(int(time.time()))
                            self.core.devices[device_id].transfer_information['queue'].remove(transfer)
                            transfer_cancelled = True
                            audit_log('Transfer cancelled: transfer_id="%s" on {device:device_uuid}' % transfer_id, meta={'device': device_id}, tags=['transfer', 'delete'])
                            break

                try:
                    transfer_object = db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_id).one()
                    transfer_object.state = 'cancelled'
                    transfer_object.end = int(time.time())
                    transfer_object.message = _('Transfer cancelled')
                    transfer_object.message_code = 6
                    db.Session.commit()
                except NoResultFound:
                    pass

            if transfer_cancelled:
                messages.append({'type': 'success',
                 'message': _('%s: Cancelling Transfer: %s') % (self.core.get_pretty_name(device_id), str(transfer_id))})
            else:
                messages.append({'type': 'error',
                 'message': _('%s: Cannot find transfer request: %s') % (self.core.get_pretty_name(device_id), str(transfer_id))})

        return (action_id, messages)

    def clear_transfer_history(self, device_ids = []):
        cleared_transfers = {}
        messages = []
        device_ids, device_errors = self._get_devices(device_ids, Content)
        for device_id in device_ids:
            if self.core.devices[device_id].device_configuration.has_key('category') and (self.core.devices[device_id].device_configuration['category'] in ('sms', 'lms') or self.core.devices[device_id].device_configuration['type'] in ('usb', 'drive', 'local', 'network')):
                if len(self.core.devices[device_id].get_completed_transfers()):
                    success, message, deleted_transfer_ids = self.core.devices[device_id].content_clear_transfer_history_helper()
                    if success:
                        cleared_transfers[device_id] = deleted_transfer_ids
                        audit_log('Transfer history cleared: {device:device_uuid}', meta={'device': device_id}, tags=['transfer'])
                        messages.append({'type': 'success',
                         'message': _('Transfer history cleared for: %s') % self.core.get_pretty_name(device_id)})
                    else:
                        messages.append({'type': 'error',
                         'message': message})
                else:
                    messages.append({'type': 'success',
                     'message': _('Transfer history cleared for: %s') % self.core.get_pretty_name(device_id)})

        return (cleared_transfers, messages)

    def scan_content(self, content_id, device_id):
        content = None
        message = None
        try:
            content = self.core.devices[device_id].scan_content(content_id)
        except socket.error:
            logging.error('There was a connection error when scanning the CPL [%s]' % content_id, exc_info=True)
            message = _('Error communicating with device')
        except Exception:
            logging.error('There was an error in scanning the CPL [%s]' % content_id, exc_info=True)
            message = _('Unknown error while analysing CPL')

        return (content, message)

    def content(self, device_ids = [], content_ids = []):
        device_ids, device_errors = self._get_devices(device_ids, Content)
        contents = self.core.contents
        content_data = {}
        if not content_ids:
            content_ids = self.core.contents.keys()
        for content_uuid in content_ids:
            if self.core.contents.on_any_device(content_uuid, key_only=True):
                if contents[content_uuid].get('error_messages'):
                    continue
                content = contents[content_uuid].copydict()
                for device_uuid in device_ids:
                    if device_uuid not in content['devices']:
                        content['devices'][device_uuid] = {'error_messages': ['Content is not registered on this device']}

                content_data[content_uuid] = content
            else:
                content_data[content_uuid] = {'error_message': _('CPL %s cannot be found in the complex') % content_uuid}

        return (content_data, device_errors['messages'])

    def get_content_detailed(self, device_uuid = None, content_uuids = [], key_info = False, validate_datetime = None):
        lms_uuid = self.core.get_lms_id()
        if validate_datetime is None:
            time_now = time.time()
        else:
            time_now = date_utils.parse_date(validate_datetime)
        contents = {}
        for content_uuid in content_uuids:
            core_content = self.core.contents.get(content_uuid)
            if not core_content:
                contents[content_uuid] = {'error_messages': ['Not in complex']}
                continue
            else:
                content = contents[content_uuid] = core_content.copydict()
            content['on_lms'] = core_content.valid_on_device(lms_uuid)
            if device_uuid and not core_content.on_device(device_uuid):
                content['devices'][device_uuid] = {'error_messages': ['Not on device']}
            if key_info or validate_datetime is not None:
                if content.get('encrypted'):
                    for _device_uuid in core_content['devices']:
                        valid_now, valid_future, expires_in_24, details = core_content.get_encryption_state(_device_uuid, time_now)
                        content['devices'][_device_uuid]['valid_now'] = valid_now
                        content['devices'][_device_uuid]['valid_in_24'] = valid_future
                        content['devices'][_device_uuid]['expires_in_24'] = expires_in_24
                        content['devices'][_device_uuid]['keys_detailed'] = details

        return contents

    def pattern(self, device_ids):
        return_values = {'data': [],
         'messages': []}
        duration_list = [None,
         5,
         10,
         30,
         60,
         120,
         300]
        if not device_ids:
            devices = self.core.get_devices(required_api=Content)[0]
        else:
            devices = device_ids
        pattern_map = {}
        for device in devices:
            pattern_map[device] = self.core.devices[device].get_supported_patterns()

        pattern_list = []
        for key in pattern_map:
            for patt in pattern_map[key]:
                match = False
                for existing_pattern in pattern_list:
                    if existing_pattern['description'] == patt['description'] and existing_pattern['edit_rate'] == patt['edit_rate'] and existing_pattern['playback_mode'] == patt['playback_mode'] and not match:
                        existing_pattern['devices'].append(key)
                        match = True

                if not match:
                    patt['devices'] = [key]
                    pattern_list.append(patt)

        for pattern in pattern_list:
            for duration in duration_list:
                patt = copy.deepcopy(pattern)
                patt['duration_in_seconds'] = duration
                if duration:
                    patt['duration_in_frames'] = duration * patt['edit_rate'][0] / patt['edit_rate'][1]
                else:
                    patt['duration_in_frames'] = None
                return_values['data'].append(patt)

        return return_values

    def save(self, cpl_metadata):
        content_uuid = cpl_metadata['uuid']
        cpl_dir = os.path.join(cfg.lms_library_directory(), 'CPL', content_uuid)
        if os.path.isdir(cpl_dir):
            metadata_path = os.path.join(cpl_dir, 'metadata.json')
            with open(metadata_path, 'w') as metadata_file:
                metadata = json.dumps(cpl_metadata)
                metadata_file.write(metadata)
                update_info = {}
                update_info = json.loads(metadata)
                self.core.contents.setdefault(content_uuid, {}).update(update_info)
                audit_log('LMS Content metadata updated: {content:cpl_uuid}', meta={'content': content_uuid}, tags=['content', 'modified'])
            message = {'type': 'success',
             'content_id': content_uuid,
             'message': 'Metadata updated for CPL {0}'.format(content_uuid)}
        else:
            message = {'type': 'error',
             'content_id': content_uuid,
             'message': _('CPL %s does not exist on the LMS.') % content_uuid}
        return (content_uuid, message)

    def delete(self, content_ids, device_ids = []):
        messages = []
        device_ids, device_errors = self._get_devices(device_ids, Content)
        messages.extend(device_errors['messages'])
        for content_id in content_ids:
            for device_id in device_ids:
                if not self.core.contents.content_on_device(content_id, device_id):
                    message = _('CPL %s could not be found on %s') % (content_id, self.core.get_pretty_name(device_id))
                    messages.append({'type': 'success',
                     'device_id': device_id,
                     'content_id': content_id,
                     'message': message})
                else:
                    is_ok = True
                    if isinstance(self.core.devices[device_id], Playback):
                        playback_status = self.core.devices[device_id].device_get_playback_information()
                        loaded_spl_uuid = playback_status['spl_uuid']
                        loaded_playlist_info = self.core.devices[device_id]._device_get_playlist_information(playlist_ids=[loaded_spl_uuid], requested_data_items=['playlist'])[loaded_spl_uuid]
                        if 'playlist' in loaded_playlist_info:
                            loaded_cpl_list = [ cpl_item['cpl_id'] for cpl_item in loaded_playlist_info['playlist']['events'] if cpl_item.has_key('cpl_id') ]
                        else:
                            loaded_cpl_list = []
                        if content_id in loaded_cpl_list:
                            message = _('CPL %s is currently loaded for playback on: %s. Cannot delete') % (content_id, self.core.get_pretty_name(device_id))
                            messages.append({'type': 'error',
                             'device_id': device_id,
                             'content_id': content_id,
                             'message': message})
                            is_ok = False
                    if is_ok:
                        content = self.core.contents[content_id]
                        message = _('%s: deleting %s') % (self.core.get_pretty_name(device_id), content['content_title_text'])
                        if self.core.devices[device_id].device_configuration['type'] in ('dolby', 'gdc') and len(content_ids) > 1:
                            action_id = self._action(self.core.devices[device_id].content_delete_helper, content_id, True)
                        else:
                            action_id = self._action(self.core.devices[device_id].content_delete_helper, content_id)
                        audit_log('Content deleted: {content:cpl_uuid} from {device:device_uuid}', meta={'content': content_id,
                         'device': device_id}, tags=['content', 'delete'])
                        messages.append({'type': 'action',
                         'action_id': action_id,
                         'device_id': device_id,
                         'content_id': content_id,
                         'message': message})

        return messages

    def delete_key_check(self, device_id, key_ids):
        content_key_map = {}
        keys_affecting_schedules = {}
        messages = []
        for key_id in key_ids:
            if key_id in self.core.devices[device_id].key_information:
                content_obj = self.core.devices[device_id].key_information[key_id]
                content_id = content_obj['cpl_uuid']
                content_title = content_obj['cpl_title']
                content_key_map.setdefault(content_id, {'cpl_title': content_title,
                 'keys': []})['keys'].append(key_id)

        content_schedules = self.core.scheduling_service.get_content_schedules(content_key_map.keys(), device_uuids=[device_id], ids_only=True)
        messages += content_schedules['messages']
        content_schedules = content_schedules['data']
        for content_id in content_schedules.keys():
            keys_affecting_schedules[content_id] = content_key_map[content_id]

        return {'data': keys_affecting_schedules,
         'messages': messages}

    def delete_key(self, device_id, key_ids):
        logging.info('Deleting keys %s from device %s' % (key_ids, device_id))
        messages = []
        for key_id in key_ids:
            if key_id in self.core.devices[device_id].key_information:
                key = self.core.devices[device_id].key_information[key_id]
                action_id = self._action(self.core.devices[device_id]._delete_key_helper, key_id)
                logging.info('KDM [%s] has been marked for deletion on device [%s]' % (key_id, device_id))
                audit_log('KDM deleted: key_id="%s" from {device:device_uuid}' % key_id, meta={'device': device_id}, tags=['kdm', 'delete'])
                messages.append({'type': 'action',
                 'action_id': action_id,
                 'device_id': device_id,
                 'key_id': key_id,
                 'message': _('Deleting: %s') % key_id})
                cherrypy.core.contents[key['cpl_uuid']].remove_key(device_id, key_id)
            else:
                logging.info('Device %s does not have KDM %s' % (device_id, key_id))
                messages.append({'type': 'error',
                 'device_id': device_id,
                 'key_id': key_id,
                 'message': _('Cannot find KDM %s on %s') % (key_id, self.core.get_pretty_name(device_id))})

        return messages

    def key_xml(self, key_id):
        messages = []
        lms_uuid = self.core.get_lms_id()
        cherrypy.response.headers['Content-Type'] = 'text/xml'
        cherrypy.response.headers['Content-Disposition'] = 'attachment;filename=%s.xml' % key_id
        device_ids, device_errors = self._get_devices(device_ids=None, required_api=Playback)
        device_ids.append(lms_uuid)
        xml_response = None
        for device_id in device_ids:
            if key_id in self.core.devices[device_id].key_information:
                logging.info('Device %s has key %s' % (device_id, key_id))
                xml_response = self.core.devices[device_id].get_key(key_id)
                break

        if not xml_response:
            messages.append({'type': 'error',
             'key_id': key_id,
             'message': _('Cannot find KDM: %s') % key_id})
            return (None, messages)
        elif 'xml' not in xml_response:
            for message in xml_response['error_messages']:
                logging.info('%s' % message)
                messages.append({'type': 'error',
                 'key_id': key_id,
                 'message': message})

            return (None, messages)
        else:
            return (xml_response['xml'], messages)
            return

    def cpl_xml(self, cpl_uuid):
        messages = []
        cpl_xml = None
        cherrypy.response.headers['Content-Type'] = 'text/xml'
        cherrypy.response.headers['Content-Disposition'] = 'attachment;filename=%s.xml' % cpl_uuid
        try:
            path = str(os.path.join(cfg.lms_library_directory(), 'CPL', cpl_uuid, cpl_uuid + '.xml'))
            with open(path) as cpl:
                cpl_xml = cpl.read()
            return (cpl_xml, messages)
        except Exception as ex:
            logging.error('Error retrieving CPL [%s]' % cpl_uuid, exc_info=True)
            messages.append({'type': 'error',
             'key_id': cpl_uuid,
             'message': _('Error retrieving CPL %s') % cpl_uuid})
            return (None, messages)

        return

    def keys(self, device_ids = [], key_ids = [], content_ids = [], hide_expired = True):
        device_keys = {}
        messages = []
        playback_device_ids, playback_device_errors = self._get_devices([], Playback)
        dn_lookup = {}
        for device_id in playback_device_ids:
            device_info = self.core.devices[device_id].device_information
            for dnqualifier in device_info.get('dnqualifiers', ()):
                dn_lookup[dnqualifier] = device_id

        messages.extend(playback_device_errors['messages'])
        device_ids, device_errors = self._get_devices(device_ids, Content)
        for device_id in device_ids:
            device_keys[device_id] = {}
            for key_uuid, key_info in self.core.devices[device_id]._device_get_key_information(key_ids, content_ids, hide_expired).iteritems():
                device_keys[device_id][key_uuid] = helper_methods.copy_by_value(key_info)
                device_keys[device_id][key_uuid]['matched_device_uuid'] = dn_lookup.get(device_keys[device_id][key_uuid]['dnqualifier'], None)

        messages.extend(device_errors['messages'])
        return (device_keys, messages)

    def get_availability(self, content_uuid):
        dns = {}
        devices = {'unknown': {}}
        for device_uuid in self.core.devices:
            devices[device_uuid] = {}
            device = self.core.devices[device_uuid]
            if device.device_information.has('dnqualifiers'):
                for dn in device.device_information.get('dnqualifiers'):
                    dns[dn] = device_uuid

        core_keys = self.keys(content_ids=content_uuid)[0]
        keys = {}
        for device_uuid in core_keys:
            for key_uuid in core_keys[device_uuid]:
                core_key = core_keys[device_uuid][key_uuid]
                if key_uuid not in keys.keys():
                    keys[key_uuid] = core_key
                    keys[key_uuid]['on'] = []
                keys[key_uuid]['on'].append(device_uuid)
                if dns.has_key(keys[key_uuid]['dnqualifier']) and dns[keys[key_uuid]['dnqualifier']] == device_uuid:
                    keys[key_uuid]['status'] = core_key['status']

        for key_uuid in keys.keys():
            key = keys[key_uuid]
            if key['dnqualifier'] in dns:
                device_key = dns[key['dnqualifier']]
            else:
                device_key = 'unknown'
            status = key.get('status', 'ok')
            key_info = {}
            time_now = time.time()
            key_info['valid'] = status == 'ok'
            key_info['status'] = key['status']
            key_info['not_valid_before'] = key['not_valid_before']
            key_info['not_valid_after'] = key['not_valid_after']
            key_info['valid_now'] = status == 'ok' and key['not_valid_before'] < time_now and key['not_valid_after'] > time_now
            key_info['valid_in_24'] = status == 'ok' and key['not_valid_before'] < time_now + 86400 and key['not_valid_after'] > time_now
            key_info['on_target'] = device_key in key['on']
            key_info['on'] = key['on']
            devices[device_key][key_uuid] = key_info

        for device_uuid in devices.keys():
            if devices[device_uuid] == {}:
                del devices[device_uuid]

        return devices

    def lms_assets(self):
        lms_id = self.core.get_lms_id()
        return self.core.devices[lms_id].get_cpls_assets()

    def validate(self, content_id, device_id):
        return {'type': 'action',
         'message': _('Starting CPL validation'),
         'action_id': self._action(self.core.devices[device_id].content_validate, content_id)}

    @db.close_session
    def transfer(self, sending_device_id, receiving_device_ids, content_ids, not_before = None):
        messages = []
        for content_id in content_ids:
            if not content_id:
                continue
            if sending_device_id in self.core.devices or sending_device_id == 'Auto':
                source_list = {}
                if sending_device_id in self.core.devices:
                    source_list = {sending_device_id: self.core.devices[sending_device_id]}
                else:
                    device_ids, device_errors = self._get_devices([], Content)
                    for device_id in device_ids:
                        source_list[device_id] = self.core.devices[device_id]

                    messages.extend(device_errors['messages'])
                if any((cherrypy.core.contents.content_on_device(content_id, device_uuid) for device_uuid in source_list)):
                    for receiving_device_id in receiving_device_ids:
                        messages.append(self.transfer_content(sending_device_id, receiving_device_id, content_id, not_before))
                        if sending_device_id == self.core.get_lms_id():
                            self._transfer_related_keys(content_id, receiving_device_id)

                else:
                    message = _('CPL %s cannot be found in the complex') % content_id if sending_device_id == 'Auto' else _('CPL %s no longer exists on specified source [%s]') % (content_id, sending_device_id)
                    logging.info(message)
                    for receiving_device_id in receiving_device_ids:
                        messages.append({'type': 'error',
                         'device_id': receiving_device_id,
                         'content_id': content_id,
                         'message': message})

            else:
                for receiving_device_id in receiving_device_ids:
                    message = _('CPL source is no longer configured') % sending_device_id
                    logging.info(message)
                    messages.append({'type': 'error',
                     'device_id': receiving_device_id,
                     'content_id': content_id,
                     'message': message})

        return messages

    def _transfer_related_keys(self, content_id, receiving_device_id):
        lms_uuid = self.core.get_lms_id()
        to_device = self.core.devices[receiving_device_id]
        if to_device.device_information.has('dnqualifiers'):
            device_dns = to_device.device_information.get('dnqualifiers')
            lms = self.core.devices[lms_uuid]
            key_uuids = lms.get_key_uuid_list()
            keys = lms.get_key_information(key_uuids['key_uuid_list'])
            for key in keys['key_info_dict']:
                if keys['key_info_dict'][key]['cpl_uuid'] == content_id and keys['key_info_dict'][key]['dnqualifier'] in device_dns:
                    key_xml = lms.get_key_xml(key)
                    self.add_key(key_xml, receiving_device_id, source=lms_uuid, force=True)

    @db.close_session
    def transfer_content(self, sending_device_id, receiving_device_id, content_id, not_before, playlist_uuid = None):
        logging.info('Attempting to transfer content content_id: {0}) from device (id: {1}) to device (id: {2})'.format(content_id, sending_device_id, receiving_device_id))
        if content_id in self.core.contents and self.core.contents[content_id].get_validation_code(receiving_device_id) == 0:
            message = _('CPL already exists and is valid')
            logging.info(message)
            return {'state': 'exists',
             'type': 'success',
             'device_id': receiving_device_id,
             'content_id': content_id,
             'message': message}
        elif content_id not in self.core.contents:
            message = _('CPL cannot be found in the complex')
            logging.info(message)
            return {'state': 'error',
             'type': 'error',
             'device_id': receiving_device_id,
             'content_id': content_id,
             'message': message}
        else:
            if type(not_before) is str or type(not_before) is unicode:
                if str(not_before) == 'ASAP':
                    not_before = None
                    if not self.core.devices[receiving_device_id].device_status['alive']:
                        message = _('Error communicating with device')
                        logging.error(message)
                        return {'state': 'error',
                         'type': 'error',
                         'device_id': receiving_device_id,
                         'content_id': content_id,
                         'message': message}
                elif str(not_before) == 'tonight':
                    now = datetime.now()
                    tonight_hour = cfg.core_tonight_hour()
                    tonight_minute = cfg.core_tonight_minute()
                    minutes_now = now.minute + now.hour * 60
                    minutes_tonight = tonight_hour * 60 + tonight_minute
                    tonight = datetime(now.year, now.month, now.day, tonight_hour, tonight_minute, 0)
                    if minutes_now > minutes_tonight:
                        tonight += timedelta(days=1)
                    tonight_timestamp = time.mktime(tonight.timetuple())
                    not_before = tonight_timestamp
                else:
                    not_before = date_utils.parse_date(not_before)
            transfer_information = self.core.devices[receiving_device_id].transfer_information
            for queued_item in transfer_information['queue'] + transfer_information['active'].values():
                if queued_item['content_id'] == content_id:
                    update = False
                    if queued_item.has_key('not_before'):
                        if not_before is None and queued_item['not_before']:
                            update = True
                        if not_before is not None and queued_item['not_before'] is not None and not_before < queued_item['not_before']:
                            update = True
                    if update is True:
                        queued_item['not_before'] = not_before
                        transfer_item = db.Session.query(db.Transfer).filter(db.Transfer.uuid == queued_item['id']).one()
                        transfer_item.not_before = not_before
                        db.Session.commit()
                        message = _('Transfer time has been updated')
                        logging.info(message)
                        return {'state': 'exists',
                         'type': 'success',
                         'device_id': receiving_device_id,
                         'content_id': content_id,
                         'message': message}
                    else:
                        message = _('CPL is already queued')
                        logging.info(message)
                        return {'state': 'exists',
                         'type': 'success',
                         'device_id': receiving_device_id,
                         'content_id': content_id,
                         'message': message}

            transfer_item = db.Transfer(source=sending_device_id, destination_device_uuid=receiving_device_id, content_uuid=content_id, description=self.core.contents[content_id]['content_title_text'], not_before=not_before, state='queued', type='DCP', core=True, playlist_uuid=playlist_uuid)
            db.Session.add(transfer_item)
            db.Session.commit()
            self.core.devices[receiving_device_id].transfer_information['queue'].append({'id': transfer_item.uuid,
             'source': sending_device_id,
             'content_id': content_id,
             'description': self.core.contents[content_id]['content_title_text'],
             'not_before': not_before,
             'state': 'queued',
             'not_before_string': helper_methods.format_timestamp(not_before),
             'type': 'DCP',
             'server_transfer_id': None})
            message = _('CPL has been queued for transfer on %s') % self.core.get_pretty_name(receiving_device_id)
            logging.debug(message)
            audit_log('Content transfer queued: {content:cpl_uuid} to {device:device_uuid}', meta={'device': receiving_device_id,
             'content': content_id}, tags=['transfer', 'queued'])
            return {'state': 'queued',
             'type': 'success',
             'device_id': receiving_device_id,
             'content_id': content_id,
             'message': message}

    def force_transfers(self, device_id, transfer_ids = []):
        messages = []
        for transfer_id in transfer_ids:
            transfer_found = False
            if self.core.devices[device_id].transfer_information['queue']:
                dest_device = self.core.devices[device_id]
                if not dest_device.device_status['alive']:
                    messages.append({'type': 'error',
                     'message': _('Error communicating with device')})
                    return messages
                for transfer_request in dest_device.transfer_information['queue'][:]:
                    if transfer_request['id'] == transfer_id:
                        transfer_found = True
                        if transfer_request['type'] == 'KDM':
                            dest_device.content_add_key_helper(transfer_request)
                            messages.append({'type': 'success',
                             'message': _('KDM queued for transfer %s') % transfer_request['description']})
                        else:
                            content = self.core.contents[transfer_request['content_id']]
                            self.core._start_transfer(device_id, transfer_request)
                            audit_log('Forcing content transfer: {content:cpl_uuid} to {device:device_uuid}', meta={'content': transfer_request['content_id'],
                             'device': device_id}, tags=['transfer'])
                            messages.append({'type': 'success',
                             'message': _('Forcing transfer for CPL %s on %s') % (content['content_title_text'], self.core.get_pretty_name(device_id))})
                        break

            if not transfer_found:
                messages.append({'type': 'error',
                 'message': _('Cannot find transfer with ID %s on %s') % (transfer_id, self.core.get_pretty_name(device_id))})

        return messages

    def prioritize_transfer(self, transfer_id, device_id):
        messages = []
        transfer_rescheduled = False
        with self.core.devices[device_id].transfer_information_lock:
            if self.core.devices[device_id].transfer_information['queue']:
                top_transfer_request = self.core.devices[device_id].transfer_information['queue'][0]
                if top_transfer_request['not_before'] is not None:
                    not_before = top_transfer_request['not_before'] - 5
                else:
                    not_before = None
                for i, transfer_request in enumerate(self.core.devices[device_id].transfer_information['queue'][1:]):
                    if transfer_request['id'] == transfer_id:
                        self.core.devices[device_id].transfer_information['queue'].pop(i + 1)
                        self.core.devices[device_id].transfer_information['queue'].insert(0, transfer_request)
                        transfer_request['not_before'] = not_before
                        transfer_request['not_before_string'] = helper_methods.format_timestamp(not_before)
                        audit_log('Content transfer re-scheduled: {content:cpl_uuid} on {device:device_uuid}', meta={'content': transfer_request['content_id'],
                         'device': device_id}, tags=['transfer'])
                        messages.append({'type': 'success',
                         'message': _('Transfer %s has been updated on %s') % (transfer_id, self.core.get_pretty_name(device_id))})
                        transfer_rescheduled = True
                        break

        if transfer_rescheduled:
            try:
                transfer = db.Session.query(db.Transfer).filter(db.Transfer.uuid == transfer_id).one()
                transfer.not_before = not_before
                db.Session.commit()
            except NoResultFound:
                pass

        else:
            messages.append({'type': 'error',
             'message': _('Unable to find transfer %s on %s') % (transfer_id, self.core.get_pretty_name(device_id))})
        return messages

    def transfer_status(self, device_ids = [], active_only = True):
        device_transfer_status = {}
        device_ids, device_errors = self._get_devices(device_ids, Content)
        for device_id in device_ids:
            device_transfer_status[device_id] = helper_methods.copy_by_value(self.core.devices[device_id]._device_get_transfer_information(active_only))

        if not active_only:
            for device_id in device_transfer_status:
                index = 0
                for item in device_transfer_status[device_id]['queue']:
                    item['index'] = index
                    index += 1

        return (device_transfer_status, device_errors['messages'])

    def transfer_detail(self, device_uuid, transfer_id):
        device_ids, device_errors = self._get_devices([device_uuid], Content)
        if len(device_ids) > 0:
            transfer_information = helper_methods.copy_by_value(self.core.devices[device_ids[0]]._device_get_transfer_information(False))
            if transfer_information['completed'].has_key(transfer_id):
                return (transfer_information['completed'][transfer_id], [])
            if transfer_information['active'].has_key(transfer_id):
                return (transfer_information['active'][transfer_id], [])
            for item in transfer_information['queue']:
                if item['id'] == transfer_id:
                    return (item, [])

            return ({}, [{'type': 'error',
               'message': _('Unable to find transfer %s on %s') % (transfer_id, self.core.get_pretty_name(device_uuid))}])
        else:
            return ({}, device_errors['messages'])

    def pack_to_composite_CPL(self, pack_uuid, lms_data_path = None, lms_data = None):
        """Combines CPLs in a pack into a new CPL and DCP
        :param pack_uuid: uuid of source pack
        :param lms_data_path: (optional) LMS data store folder. Default: Configured LMS data folder
        :param lms_data: (optional) dictionary of LMS Data. Default: content_service.lms_assets()
        
        Important
        Note: The optional parameters allow for external unit testing scripts.
        Note: Pack clips must all contain audio, or not
        Note: Pack clips must all contain 3D picture, or not
        """
        pack = db.Session.query(db.Pack).get(pack_uuid)
        clips = json.loads(pack.clips) if pack.clips else []
        if not clips:
            raise AssertionError, 'Pack is empty'
            cpl_ids = [ clip['cpl_id'] for clip in clips ]
            screen_ids = []
            if pack.screen_maps:
                for pack_screen_map in pack.screen_maps:
                    screen_ids.append('Screen_' + str(self.core.screens[pack_screen_map.screen_uuid]['identifier']))

            if screen_ids == []:
                screen_ids = ['All_Screens']
            if not lms_data_path:
                lms_data_path = cfg.lms_library_directory()
            logging.debug('lms_data_path: {0}'.format(lms_data_path))
            week_num_str = not pack.playback_date_range_start and not pack.playback_date_range_end and 'All_Weeks'
        elif not pack.playback_date_range_start:
            week_num_str = 'End-%s' % pack.playback_date_range_end
        elif not pack.playback_date_range_end:
            week_num_str = 'Start-%s' % pack.playback_date_range_start
        else:
            week_num_str = 'Start-%s__End-%s' % (pack.playback_date_range_start, pack.playback_date_range_end)
        for screen_id in screen_ids:
            output_path = os.path.join(lms_data_path, 'COMPOSITE', screen_id, week_num_str)
            results = []
            new_cpl_id = None
            try:
                packaging_log('Creating Composite CPL from pack [%s] containing CPLs %s ' % (pack_uuid, str(cpl_ids)))
                new_package, included_cpls, excluded_cpls = self._merge_cpls(cpl_ids, pack.name, lms_data_path, lms_data)
                pack_types = {'advertisement': 'ADV',
                 'trailer': 'TLR'}
                name = pack.name.upper()
                if new_package['type']:
                    name += '_' + pack_types.get(new_package['type'].lower(), new_package['type'].upper())
                if excluded_cpls:
                    name += '_PARTIAL'
                new_package['cpl_name'] = name
                new_cpl_id, results = write_DCP(new_package, output_path, link=True)
                if excluded_cpls:
                    packaging_log('Partial Composite DCP [%s] successfully created from pack [%s]. CPLs included: %s' % (new_cpl_id, pack_uuid, included_cpls))
                else:
                    packaging_log('Composite DCP [%s] successfully created from pack [%s]. CPLs included: %s' % (new_cpl_id, pack_uuid, included_cpls))
            except Exception as ex:
                packaging_log('Error creating Composite DCP from pack [%s]' % pack_uuid, exc_info=True)

        return

    def export_composite_DCPs(self, destination):
        """
        Export Composite DCPs to any available empty USB drive.
        """
        packaging_log('Exporting composite DCPs to [%s]' % destination)
        origin = os.path.join(cfg.lms_library_directory(), 'COMPOSITE')
        try:
            log_file = os.path.join(destination, 'copy_progress.txt')
            log = open(log_file, 'w')
            log.write('Starting File Transfer - ' + helper_methods.format_timestamp(time.time()) + '\n')
            log.write('---\n')
            log.close()
            dcp_count = 0
            for root, dirs, files in os.walk(origin):
                try:
                    for thefile in files:
                        target = root.replace(origin, '')
                        if target[0] in ('/', '\\'):
                            target = target[1:]
                        dcp_root = os.path.join(destination, target).replace(' ', '_')
                        if not os.path.exists(dcp_root):
                            os.makedirs(dcp_root)
                            log = open(log_file, 'a')
                            log.write('Creating: ' + dcp_root + '\n')
                            dcp_count += 1
                        shutil.copy2(os.path.join(root, thefile), dcp_root)

                except Exception as ex:
                    log = open(log_file, 'a')
                    log.write('Error: ' + str(ex) + '\n')

            log = open(log_file, 'a')
            log.write('---\n')
            log.write('File Transfer Complete - ' + helper_methods.format_timestamp(time.time()) + '\n')
            log.write('DCPs transferred: ' + str(dcp_count))
            log.close()
            shutil.copy2(os.path.join(cfg.data_dir(), 'log', 'cinema_services.package_creation.log'), destination)
        except Exception:
            packaging_log('Error exporting Composite DCPs', exc_info=True)

    def _merge_cpls(self, cpl_ids, new_cpl_name = None, lms_data_path = None, lms_data = None):
        """ Combines CPLs into a new CPL and returns this as a dictionary
        :param cpl_ids: a list of uuids of CPLs to be merged
        :parama new_cpl_name: (optional) name of new CPL (default: 1st CPLs name)
        :param lms_data_path: (optional) alternative path to LMS data folder
        :param lms_data: (optional) alternative LMS Assets dictionary
        :returns: package information of merged cpls
        
        Important: specified CPLs must match certain features:
            - all reels should be similarly with or without audio
            - 3d, or not
        
        Optional params: lms_data_path & lms_data are for specifying alternate
        sources of data for testing purposes etc.
        If left blank/none, will use the configured LMS/TMSs data.
        
        Some logic/naming a bit funny  - this has been adapted from Ronans
        stand along repackager script.
        """

        def load_cpl(cpl_id):
            """Loads and returns the parsed CPL metadata for the specified CPL
            """
            try:
                cpl_file = os.path.join(lms_data_path, 'CPL', cpl_id, cpl_id + '.xml')
                return parse_cpl(cpl_file)
            except IOError:
                packaging_log('CPL [%s] not found on LMS.' % cpl_id)
            except ParsingException:
                packaging_log('CPL [%s] could not be parsed on LMS.' % cpl_id)

            return None

        def get_asset(asset_id):
            info = lms_data['assets'][asset_id]
            asset_path = os.path.join(asset_folder, asset_id, info['file_name'])
            return {'exists': os.path.exists(asset_path),
             'hash': info['hash'],
             'fullpath': asset_path,
             'id': asset_id,
             'originalfilename': info['file_name'],
             'path': info['file_name'],
             'size': info['size'],
             'type': info['type']}

        if not lms_data_path:
            lms_data_path = cfg.lms_data_path()
        if not lms_data:
            lms_data = self.lms_assets()
        asset_folder = os.path.join(lms_data_path, 'ASSET')
        partial = False
        included_cpl_ids = []
        present_cpls = []
        for cpl_id in cpl_ids:
            loaded_cpl = load_cpl(cpl_id)
            if loaded_cpl:
                present_cpls.append(loaded_cpl)
                included_cpl_ids.append(cpl_id)
            else:
                partial = True

        if len(included_cpl_ids) == 0:
            raise Exception('None of the specified CPLs were found on the LMS. CPL ids %s' % cpl_ids)
        result = present_cpls[0]
        if new_cpl_name:
            result['text'] = new_cpl_name
        del result['encrypted']
        del result['subtitled']
        del result['playback_mode']
        del result['edit_rate']
        del result['id']
        reel_list = []
        reel_list.extend(result['reels'])
        for index in range(1, len(present_cpls)):
            cpl = present_cpls[index]
            reel_list.extend(cpl['reels'])

        index = 0
        duration = 0
        namespace_dict = {}
        meta_hash = {}
        reel_hash = {}
        final_reel_list = []
        final_reel_uuids = []
        assets = []
        while index < len(reel_list):
            reel_id = reel_list[index]['id']
            has_audio = False
            frame_rate = None
            edit_rate = None
            aspect_ratio = None
            reel_asset_ids = []
            for asset in reel_list[index]['asset_list']:
                for asset_type in asset:
                    reel_asset_ids.append(asset[asset_type]['Id'])
                    for property in asset[asset_type]:
                        if 'xmlns' in property:
                            namespace_dict[str(property.replace('xmlns:', ''))] = str(asset[asset_type][property])

                    if asset_type == 'MainSound':
                        has_audio = True
                    elif asset_type in ('MainPicture', 'MainStereoscopicPicture'):
                        main_picture = asset[asset_type]
                        edit_rate = main_picture.get('EditRate')
                        frame_rate = main_picture.get('FrameRate')
                        aspect_ratio = main_picture.get('ScreenAspectRatio')

            if frame_rate and edit_rate and aspect_ratio:
                audio_key = 'with_audio' if has_audio else 'without_audio'
                if not meta_hash.has_key(audio_key):
                    meta_hash[audio_key] = {}
                if not meta_hash[audio_key].has_key(frame_rate):
                    meta_hash[audio_key][frame_rate] = {}
                if not meta_hash[audio_key][frame_rate].has_key(edit_rate):
                    meta_hash[audio_key][frame_rate][edit_rate] = {}
                if not meta_hash[audio_key][frame_rate][edit_rate].has_key(aspect_ratio):
                    meta_hash[audio_key][frame_rate][edit_rate][aspect_ratio] = []
                meta_hash[audio_key][frame_rate][edit_rate][aspect_ratio].append(reel_id)
                if len(final_reel_uuids) < len(meta_hash[audio_key][frame_rate][edit_rate][aspect_ratio]):
                    final_reel_uuids = meta_hash[audio_key][frame_rate][edit_rate][aspect_ratio]
                reel_hash[reel_id] = {'asset_ids': str(reel_asset_ids),
                 'frame_rate': frame_rate,
                 'edit_rate': edit_rate,
                 'aspect_ratio': aspect_ratio,
                 'has_audio': str(audio_key == 'with_audio')}
            else:
                if not frame_rate:
                    packaging_log("Excluding reel [%s]; can't resolve Frame Rate" % reel_id)
                if not edit_rate:
                    packaging_log("Excluding reel [%s]; can't resolve Edit Rate" % reel_id)
                if not aspect_ratio:
                    packaging_log("Excluding reel [%s]; can't resolve Aspect Ratio" % reel_id)
            index += 1

        for reel_id in reel_hash:
            reel_metadata = reel_hash[reel_id]
            if reel_id in final_reel_uuids:
                packaging_log('Including reel [%s]; Frame Rate [%s], Edit Rate [%s], Aspect Ratio [%s], Has Audio [%s], Asset Ids %s' % (reel_id,
                 reel_metadata['frame_rate'],
                 reel_metadata['edit_rate'],
                 reel_metadata['aspect_ratio'],
                 reel_metadata['has_audio'],
                 reel_metadata['asset_ids']))
            else:
                packaging_log('Excluding reel [%s]; Frame Rate [%s], Edit Rate [%s], Aspect Ratio [%s], Has Audio [%s], Asset Ids %s' % (reel_id,
                 reel_metadata['frame_rate'],
                 reel_metadata['edit_rate'],
                 reel_metadata['aspect_ratio'],
                 reel_metadata['has_audio'],
                 reel_metadata['asset_ids']))

        reel_position = 0
        for reel in reel_list:
            if reel['id'] not in final_reel_uuids:
                continue
            final_reel_list.append(reel)
            for asset in reel['asset_list']:
                for asset_type in asset:
                    if asset_type == 'MainPicture':
                        duration += int(asset['MainPicture']['Duration'])
                    elif asset_type == 'MainStereoscopicPicture':
                        duration += int(asset['MainStereoscopicPicture']['Duration'])
                    try:
                        assets.append(get_asset(asset[asset_type]['Id']))
                    except:
                        packaging_log('Failed to load asset [%s]. Asset will not be added to final CPL.' % asset[asset_type]['Id'], exc_info=True)

            reel['position'] = reel_position
            reel_position += 1

        result['reels'] = final_reel_list
        result['duration'] = duration
        result['issue_date'] = datetime.now()
        result['file_list'] = assets
        result['namespace_dict'] = namespace_dict
        return (result, included_cpl_ids, partial)

    def get_sync_report(self, device_id):
        device_ids, device_errors = self._get_devices([device_id], MountPoint)
        if device_ids:
            device = self.core.devices[device_ids[0]]
            report = device.get_sync_report()
            return (report, [])
        return ({}, ['Device is not a MountPoint. Function is not supported'])
# okay decompyling ./core/services/content_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:12 CST
