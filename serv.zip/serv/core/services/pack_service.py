# 2017.08.13 21:50:18 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\pack_service.py
from datetime import datetime
import json
import logging
from uuid import uuid4
import cherrypy
from serv.core.services.base_service import Service
from serv.lib.utilities import helper_methods
from sqlalchemy import func
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_, or_, desc, asc
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.parsers.parsers import parse_pack_xml
from serv.lib.utilities.show_attribute_utils import gen_ex_sam_uuid
from serv.lib.utilities.helper_methods import sqlite_chunk
from serv.configuration import cfg
from serv.lib.utilities.helper_methods import audit_log
from serv.storage.database.primary import database as db

class PackService(Service):
    """Provides pack related services
    """

    def last_modified(self):
        """Returns a dictionary containing the last modified timestamps for all packs
        """
        packs = db.Session.query(db.Pack)
        return dict(((pack.uuid, pack.last_modified) for pack in packs))

    def add_pack_xml(self, pack):
        messages = []
        try:
            packs = parse_pack_xml(pack)
            messages = self.save(packs)
        except Exception as ex:
            logging.error('There was an error parsing the given pack xml: [%s]' % pack, exc_info=True)
            messages.append({'type': 'error',
             'message': _('There was an error analysing the Pack XML: [%s]') % str(ex)})

        return messages

    @db.close_session
    def save(self, packs):
        """Creates or updates packs from a list of pack dictionaries
        :param packs: a list of dictionaries, each containing pack data
        
        If a entry contains a uuid matching an existing pack, then
        that then that pack is updated - otherwise a new pack is created.
        """
        messages = []
        for chunk in sqlite_chunk(packs):
            messages.extend(self._save(chunk))

        return messages

    def _save(self, packs):
        exsams_to_create = []
        pack_sams_to_create = []
        placeholders = db.Session.query(db.Placeholder).all()
        screen_id_map = {}
        for uuid, screen in self.core.screens.iteritems():
            screen_id_map[screen['identifier'].lower()] = uuid

        def retrieve_placeholder(uuid, name):
            """Retrieves (and creates if necessary) the specified placeholder
            
            Retrieves the placeholder specified by the uuid - if it fails to
            locate, it tries via the specified name - (creating a new
            placeholder if one if not found).
            
            :param uuid: uuid of the placeholder to retrieve
            :param name: name of the placeholder to retrieve
            """
            placeholder = None
            for p in placeholders:
                if uuid and p.uuid == uuid:
                    placeholder = p
                    break
                if name and p.name.lower() == name.lower():
                    placeholder = p
                    break

            if not placeholder:
                placeholder = db.Placeholder(name=name, uuid=uuid or str(uuid4()))
                db.Session.add(placeholder)
            return placeholder

        def update_pack_screen_maps(db_pack, screen_uuids, screen_identifiers):
            """Updates the Pack Screen Map entries for the supplied pack
                - if screen_uuids specified, then uses these
                - otherwise, uses screen_identifiers
            :param db_pack: an instance of db.Pack()
            :param screen_uuids: list of screen uuids
            :param screen_identifiers: list of screen identifiers (max 3 char strings)
            :note: `screen_identiers` only used if screen_uuids is empty/none
            :returns: True on update success, or False on error
            """
            screens_needed = set([])
            if screen_uuids:
                screens_needed = set(screen_uuids)
            elif screen_identifiers:
                screen_identifiers = map(lambda s: s.lower(), screen_identifiers)
                screens_needed = set([ uuid for id, uuid in screen_id_map.iteritems() if id in screen_identifiers ])
                if len(screen_identifiers) > len(screens_needed):
                    logging.error('Unable to locate all the screens specified in pack: ' + db_pack.uuid)
                    messages.append({'type': 'error',
                     'message': _('Could not find specified screens for Pack. Specified Screens: [%s] Screens Found: [%s]') % (', '.join(screen_identifiers), ', '.join([ id for id in screen_id_map.iterkeys() ]))})
                    return False
            screens_existing = set([ x.screen_uuid for x in db_pack.screen_maps ])
            pack_screen_maps_to_add = screens_needed - screens_existing
            pack_screen_maps_to_remove = screens_existing - screens_needed
            for screen_uuid in pack_screen_maps_to_add:
                psm = db.PackScreenMap(pack_uuid=db_pack.uuid, screen_uuid=screen_uuid)
                db.Session.add(psm)

            for screen_uuid in pack_screen_maps_to_remove:
                for psm in db_pack.screen_maps:
                    if psm.screen_uuid == screen_uuid:
                        db.Session.delete(psm)
                        break

            return True

        def basic_validate(pack_dict):
            """
            Checks the supplied pack dictionary contains a valid title_uuid,
            a non-empty name, clips and either a placeholder name or placeholder_uuid
            :returns: True if conditions met, otherwise False
            """
            ok = True
            if not pack_dict.get('name'):
                logging.error('Pack save error - missing required information: "name". {0}'.format(str(pack_dict)))
                messages.append({'type': 'error',
                 'message': 'The pack is missing name field'})
                ok = False
            if 'clips' not in pack_dict:
                logging.error('Pack save error - missing required information: "clips". {0}'.format(str(pack_dict)))
                messages.append({'type': 'error',
                 'message': 'The pack is missing clip information'})
                ok = False
            else:
                for clip in pack_dict['clips']:
                    if not clip.get('edit_rate'):
                        clip['edit_rate'] = ['24', '1']

            if not pack_dict.get('placeholder_uuid') and not pack_dict.get('placeholder_name'):
                logging.error('Pack save error - missing required information. "placeholder_uuid" or "placeholder_name" must be specified. {0}'.format(str(pack_dict)))
                messages.append({'type': 'error',
                 'message': 'missing placeholder information  - placeholder_uuid or placeholder_name'})
                ok = False
            return ok

        messages = []
        dcp_creation_enabled = cfg.auto_generate_dcps.get()
        if dcp_creation_enabled:
            pending_dcps = set()
        pack_uuids = [ pack['uuid'] for pack in packs if 'uuid' in pack ]
        db_packs = None
        if pack_uuids:
            db_packs = db.Session.query(db.Pack).filter(db.Pack.uuid.in_(pack_uuids)).all()
        count = 0
        valid_packs = 0
        title_maps_for_producer = set()
        title_maps_cleanup = set()
        for pack in packs:
            title_uuid = pack.get('title_uuid')
            if not basic_validate(pack):
                continue
            pack_uuid = pack.get('uuid')
            db_pack = None
            if pack_uuid and db_packs:
                for p in db_packs:
                    if p.uuid == pack_uuid:
                        db_pack = p
                        if db_pack.external_title_map_uuid:
                            existing_external_title_map = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.uuid == db_pack.external_title_map_uuid, db.ExternalTitleMap.title_uuid == None)).first()
                            if existing_external_title_map:
                                title_maps_cleanup.add(existing_external_title_map)

            if not db_pack:
                db_pack = db.Pack(uuid=pack_uuid or str(uuid4()))
                db.Session.add(db_pack)
            db_pack.name = pack['name']
            if 'issuer' in pack:
                db_pack.issuer = pack['issuer']
            helper_methods.validate_pack_events(pack['clips'])
            db_pack.clips = json.dumps(pack['clips'])
            db_pack.playback_date_range_start = datetime.strptime(pack['date_from'], '%Y-%m-%d').date() if pack.get('date_from') else None
            db_pack.playback_date_range_end = datetime.strptime(pack['date_to'], '%Y-%m-%d').date() if pack.get('date_to') else None
            db_pack.playback_time_range_start = datetime.strptime(pack['time_from'], '%H:%M:%S').time() if pack.get('time_from') else None
            db_pack.playback_time_range_end = datetime.strptime(pack['time_to'], '%H:%M:%S').time() if pack.get('time_to') else None
            db.Session.query(db.PackRatingMap).filter(db.PackRatingMap.pack_uuid == db_pack.uuid).delete(False)
            source = None
            external_id = None
            name = None
            db_pack.external_title_map_uuid = None
            db_pack.title_external_ids = None
            if 'title_external_ids' in pack:
                db_pack.title_external_ids = json.dumps(pack['title_external_ids']) if pack['title_external_ids'] else None
                if pack['title_external_ids']:
                    source = pack['title_external_ids'][0]['source']
                    external_id = pack['title_external_ids'][0]['external_id']
                    name = pack['title_external_ids'][0]['name'] if pack['title_external_ids'][0].has_key('name') else pack['title_external_ids'][0]['external_id']
            elif pack.get('title_name'):
                source = pack.get('issuer')
                external_id = pack.get('title_name')
                name = external_id
                db_pack.title_external_ids = json.dumps([{'source': source,
                  'external_id': external_id,
                  'name': external_id}])
            elif title_uuid:
                source = 'AAM'
                external_id = title_uuid
            if external_id:
                request_producer_title = False
                try:
                    external_title_map = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.source == source, db.ExternalTitleMap.external_id == external_id)).one()
                    db_pack.external_title_map_uuid = external_title_map.uuid
                    if not external_title_map.title_uuid:
                        request_producer_title = True
                except NoResultFound:
                    ex_title_map_id = str(uuid4())
                    external_title_map = db.ExternalTitleMap(uuid=ex_title_map_id, external_id=external_id, source=source, title_uuid=None, name=name)
                    db.Session.add(external_title_map)
                    db_pack.external_title_map_uuid = ex_title_map_id
                    request_producer_title = True

                if request_producer_title:
                    title_maps_for_producer.add(external_title_map.uuid)
            for rating in pack.get('ratings', []):
                db_rating = db.PackRatingMap()
                db_rating.pack_uuid = db_pack.uuid
                db_rating.region = rating['territory']
                db_rating.rating = rating['rating']
                db.Session.merge(db_rating)

            db_pack.priority = pack.get('priority', 1000)
            db_pack.print_no = pack.get('print_no', None)
            db_placeholder = retrieve_placeholder(pack.get('placeholder_uuid'), pack.get('placeholder_name'))
            db_pack.placeholder = db_placeholder
            db_pack.set_modified()
            if 'screen_external_ids' in pack:
                screen_external_ids = pack['screen_external_ids']
                db_pack.screen_external_ids = json.dumps(screen_external_ids) if screen_external_ids else None
            if not update_pack_screen_maps(db_pack, pack.get('screen_uuids'), pack.get('screen_identifiers')):
                continue
            pack_uuid = db_pack.uuid
            db.Session.query(db.PackAttributeMap).filter(db.PackAttributeMap.pack_uuid == pack_uuid).delete('fetch')
            for exsam in pack.get('external_show_attribute_maps', []):
                exsam_uuid = gen_ex_sam_uuid(exsam['source'], exsam['external_id'])
                exsams_to_create.append(exsam)
                pack_sams_to_create.append((pack_uuid, exsam_uuid))

            messages.append({'type': 'success',
             'message': _('Saved: %s') % pack['name'],
             'uuid': db_pack.uuid})
            audit_log('Pack saved: {pack:pack} [%s]' % db_pack.uuid, meta={'pack': {'uuid': db_pack.uuid,
                      'name': pack['name']}}, tags=['pack', 'save'])
            if dcp_creation_enabled:
                pending_dcps.add(helper_methods.copy_by_value(db_pack.uuid))
            count += 1
            if count > 100:
                db.Session.commit()
                count = 0

        self.core.configuration_service.save_external_show_attribute_maps(exsams_to_create)
        for sam in pack_sams_to_create:
            db_pam = db.PackAttributeMap()
            db_pam.pack_uuid = sam[0]
            db_pam.external_show_attribute_map_uuid = sam[1]
            db.Session.add(db_pam)

        if count != 0:
            db.Session.commit()
        if title_maps_for_producer:
            cherrypy.engine.publish('ccpush', 'title_maps', {'title_maps': self.core.title_service.external_titles(list(title_maps_for_producer))})
        if title_maps_cleanup:
            title_maps_to_delete = self.core.title_service.get_title_maps_to_delete(title_maps_cleanup, 'pack')
            if title_maps_to_delete:
                db.Session.query(db.ExternalTitleMap).filter(db.ExternalTitleMap.uuid.in_(title_maps_to_delete)).delete(False)
                db.Session.commit()
        if dcp_creation_enabled:
            cherrypy.engine.publish('queue_packs_for_dcp_creation', list(pending_dcps))
        return messages

    def delete(self, pack_uuids):
        """Deletes the specified packs
        :param pack_uuids: a list of packs (uuids) to delete
        Note: deletes in chunks of up to 500
        """

        def chunks(some_list, size):
            for i in xrange(0, len(some_list), size):
                yield some_list[i:i + size]

        messages = []
        ext_maps_to_cleanup = set()
        for chunk in chunks(pack_uuids, 500):
            packs = db.Session.query(db.Pack).filter(db.Pack.uuid.in_(chunk))
            db.Session.query(db.PackScreenMap).filter(db.PackScreenMap.pack_uuid.in_(chunk)).delete(False)
            pack_names = []
            for pack in packs:
                pack_names.append(pack.name)
                audit_log('Pack deleted: {pack:pack}', meta={'pack': {'uuid': pack.uuid,
                          'name': pack.name}}, tags=['pack', 'delete'])
                messages.append({'type': 'success',
                 'message': _('Deleted: %s') % pack.name,
                 'pack_uuid': pack.uuid})
                if pack.external_title_map_uuid:
                    ext_maps_to_cleanup.add(pack.external_title_map_uuid)

            packs.delete(False)
            if ext_maps_to_cleanup:
                title_maps = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.uuid.in_(ext_maps_to_cleanup), db.ExternalTitleMap.title_uuid == None)).all()
                title_maps_to_delete = self.core.title_service.get_title_maps_to_delete(title_maps, 'pack')
                if title_maps_to_delete:
                    db.Session.query(db.ExternalTitleMap).filter(db.ExternalTitleMap.uuid.in_(title_maps_to_delete)).delete(False)
            db.Session.commit()

        return messages

    def edit(self, pack_uuids, screen_uuids = None, placeholder_uuid = None):
        """Allows changing the screenmaps and placeholder type for one more PackService
        :param pack_uuids: a list of packs to be updated
        :param screen_uuids: optional, a list of screen uuids that the packs should be associated with
        :param placeholder_uuid: optional,  uuid of placeholder that the packs are for
        """
        if screen_uuids != None:
            db.Session.query(db.PackScreenMap).filter(db.PackScreenMap.pack_uuid.in_(pack_uuids)).delete(False)
            for pack_uuid in pack_uuids:
                for screen_uuid in screen_uuids:
                    db.Session.add(db.PackScreenMap(pack_uuid=pack_uuid, screen_uuid=screen_uuid))

        if placeholder_uuid:
            packs = db.Session.query(db.Pack).filter(db.Pack.uuid.in_(pack_uuids)).all()
            for pack in packs:
                pack.placeholder_uuid = placeholder_uuid

        packs = db.Session.query(db.Pack).filter(db.Pack.uuid.in_(pack_uuids)).all()
        for pack in packs:
            pack.set_modified()

        db.Session.commit()
        audit_log('Packs edited: screen_uuids="%s" placeholder_uuids="%s" count="%s" ' % (str(screen_uuids), str(placeholder_uuid), str(len(packs))), tags=['pack', 'modified'])
        return {'type': 'success',
         'message': _('Saved')}

    def packs(self, pack_uuids = [], datatable_query = False, requested_data_items = []):
        pack_info = {}
        packs = db.Session.query(db.Pack)
        if pack_uuids:
            packs = packs.filter(db.Pack.uuid.in_(pack_uuids))
        if datatable_query:
            for pack in packs:
                pack_info[pack.uuid] = pack.to_datatables_dict()

        else:
            for pack in packs:
                if requested_data_items:
                    pack_dict = {}
                    for item in requested_data_items:
                        if hasattr(pack, item):
                            pack_dict[item] = getattr(pack, item)

                    pack_info[pack.uuid] = pack_dict
                else:
                    pack_info[pack.uuid] = pack.to_dict()

        return pack_info

    def pack_name_exists(self, pack_name):
        """
        Checks to see if a pack with specified name exists
        """
        try:
            if pack_name:
                return bool(db.Session.query(db.Pack).filter(db.Pack.name.ilike(pack_name)).count())
        except Exception:
            logging.error('Exception while validating Pack ', exc_info=True)

        return False

    def match_pack(self, placeholder_uuid, screen_uuid, show_attributes, play_datetime, title_uuid, print_number):
        """
        :param placeholder_uuid: uuid of the placeholder we are matching against
        :param screen_uuid: uuid of the screen we are matching against
        :param show_attributes: list of show_attribute uuids to match against
        :param play_datetime: datetime to match against
        :param title_uuid: uuid of title to match against
        :param print_number: print number of the film to match against
            -(this is a concept rather then physical print, don't question, is studios trying to be 35mm when it is digital)
        :returns: a dictionary containing the matched pack, or None
        Note: Method is Verbose & not the most efficient, but intended for clarity
        Will/May require some re-factoring if we take into account weightings/priorities of different show attributes etc
        """

        def apply_filters(packs):
            """Takes a query set of packs and filters it against:
                - the specified placeholder type,
                - screen uuid (if specified) and packs for  all screens,
                - title (if specified) and packs for all titles
                - show start time
                :param packs: queryset of packs
                :returns:  the input queryset of packs with filters applied
            """
            packs = packs.filter(db.Pack.placeholder_uuid == placeholder_uuid)
            if not packs.count():
                logging.error('No Packs found for specified placeholder: {0}'.format(placeholder_uuid))
                return
            packs = packs.outerjoin(db.PackScreenMap)
            packs = packs.filter(or_(~db.Pack.screen_maps.any(), db.PackScreenMap.screen_uuid == screen_uuid))
            if not packs.count():
                logging.error('No Packs found for specified screen ({0}), and no packs for all screens.'.format(screen_uuid))
                return
            if print_number:
                packs = packs.filter(or_(db.Pack.print_no == None, db.Pack.print_no == print_number))
            else:
                logging.debug('print number not specified - not filtering on print number')
            match_region = cfg.country()
            packs = packs.outerjoin(db.PackRatingMap, and_(db.Pack.uuid == db.PackRatingMap.pack_uuid, db.PackRatingMap.region == match_region))
            if title_uuid:
                logging.debug('Filtering packs for "all titles" or packs for title_uuid = {0}'.format(title_uuid))
                packs = packs.filter(or_(db.Pack.external_title_map_uuid == None, db.ExternalTitleMap.title_uuid == None, db.ExternalTitleMap.title_uuid == title_uuid))
                title_rating = db.Session.query(db.TitleRatingMap.rating).join(db.Title).filter(db.Title.uuid == title_uuid, db.TitleRatingMap.territory == match_region).first()
                if title_rating:
                    packs = packs.filter(or_(db.PackRatingMap.rating == title_rating.rating, db.PackRatingMap.rating == None))
                    logging.debug('Filtering packs based on rating: [%s]', title_rating.rating)
                else:
                    logging.debug('Title specified has no rating for [%s] against which to match', match_region)
            else:
                logging.debug('Title not specified - filtering packs for "all titles"')
                packs = packs.filter(db.Pack.external_title_map_uuid == None)
            if not packs.count():
                return
            packs = packs.filter(and_(or_(db.Pack.playback_date_range_start == None, db.Pack.playback_date_range_start <= play_datetime.date()), or_(db.Pack.playback_date_range_end == None, db.Pack.playback_date_range_end >= play_datetime.date()), or_(db.Pack.playback_time_range_start == None, db.Pack.playback_time_range_start <= play_datetime.time()), or_(db.Pack.playback_time_range_end == None, db.Pack.playback_time_range_end >= play_datetime.time())))
            if packs.count():
                return packs
            else:
                return

        def packs_matching_any_show_attribs(show_attribute_uuids):
            """Returns queryset containing packs that matched one or more of the specified show attributes
            """
            packs = db.Session.query(db.Pack.uuid, db.Pack.name, db.Pack.priority, func.count(db.ShowAttribute.name).label('matches'))
            packs = packs.outerjoin(db.PackAttributeMap).join(db.ExternalShowAttributeMap, db.PackAttributeMap.external_show_attribute_map_uuid == db.ExternalShowAttributeMap.uuid).outerjoin('external_title_map').join(db.ShowAttribute, db.ExternalShowAttributeMap.show_attribute_uuid == db.ShowAttribute.uuid).group_by(db.Pack.name).filter(db.ShowAttribute.uuid.in_(show_attribute_uuids))
            return packs

        def packs_matching():
            """Returns a queryset containing packs that have no show attributes
               or only unmatched show attributes
            """
            packs = db.Session.query(db.Pack.uuid, db.Pack.name, db.Pack.priority, db.Pack.uuid.label('matches')).outerjoin('external_title_map')
            packs = packs.filter(or_(~db.Pack.pack_attribute_maps.any(), db.Pack.pack_attribute_maps.any(db.PackAttributeMap.external_show_attribute_maps.has(db.ExternalShowAttributeMap.show_attribute_uuid == None))))
            return packs

        def apply_ordering(packs):
            """Applies ordering to a queryset of packs.
            Also assigns a default priorty to packs of 1000, if they don't have
            a priorty a
            """
            packs = packs.order_by(asc(db.Pack.priority), desc(db.ExternalTitleMap.title_uuid), desc(db.PackScreenMap.screen_uuid), desc(db.Pack.print_no), desc(db.Pack.playback_date_range_start), desc(db.Pack.playback_date_range_end), desc(db.Pack.playback_time_range_start), desc(db.Pack.playback_time_range_end), desc(db.PackRatingMap.rating), desc(db.Pack.last_modified))
            return packs

        packs = None
        if show_attributes:
            packs = apply_filters(packs_matching_any_show_attribs(show_attributes))
        if not packs or not packs.count():
            packs = apply_filters(packs_matching())
        if not packs or not packs.count():
            return
        packs = apply_ordering(packs)
        match = packs.first()
        if match and match.uuid:
            pack = db.Session.query(db.Pack).get(match.uuid)
        else:
            pack = None
        if pack:
            return pack.to_dict()
        else:
            return

    def find_pack(self, cpl_uuid):
        packs = db.Session.query(db.Pack).filter(db.Pack.clips.like('%' + cpl_uuid + '%'))
        cpl_packs = []
        for pack in packs:
            cpl_packs.append({'uuid': pack.uuid,
             'name': pack.name,
             'placeholder_uuid': pack.placeholder_uuid})

        return cpl_packs

    def sync_history(self):
        sync_history = list(self.core.pack_synchroniser.sync_history)
        sync_history.reverse()
        return sync_history
# okay decompyling ./core/services/pack_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:20 CST
