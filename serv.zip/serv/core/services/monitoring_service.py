# 2017.08.13 21:50:16 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\monitoring_service.py
import json
import math
import time
import logging
from collections import defaultdict
from serv.lib.utilities import helper_methods
from serv.core.devices.base.monitoring import Monitor
from serv.core.devices.base.mount_point import MountPoint
from serv.core.devices.base.playlist import Playlist
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
from sqlalchemy.orm import aliased

class MonitoringService(Service):

    def info(self, device_ids = []):
        device_ids, device_errors = self._get_devices(device_ids, Monitor)
        device_information = dict(((device_id, self.core.devices[device_id].device_information) for device_id in device_ids))
        return (device_information, device_errors['messages'])

    def messages(self, device_ids = [], action_ids = []):
        device_ids, device_errors = self._get_devices(device_ids, Monitor)
        action_messages = {}
        for device_id in device_ids:
            for action_id in action_ids:
                if self.core.devices[device_id].messages.has_key(action_id):
                    action_messages[action_id] = self.core.devices[device_id].messages[action_id]
                    del self.core.devices[device_id].messages[action_id]
                    self.core.devices[device_id].message_list.remove(action_id)

        return (action_messages, device_errors['messages'])

    def type_last_modified(self):
        """
        Returns a list of all title last_modified timestamps stored on this core
        """
        types = db.Session.query(db.MonitoringType)
        return dict(((t.uuid, t.last_modified) for t in types))

    def type_delete(self, uuids = [], delete_default = False):
        try:
            if delete_default:
                default_uuids = db.Session.query(db.MonitoringType.uuid).filter(db.MonitoringType.default == True)
                uuids.extend([ t.uuid for t in default_uuids ])
            if uuids:
                uuids = list(set(uuids))
                mtypes = db.Session.query(db.MonitoringType.name).filter(db.MonitoringType.uuid.in_(uuids))
                for mtype in mtypes:
                    if mtype.name in self.core.monitoring_types:
                        del self.core.monitoring_types[mtype.name]

                db.Session.query(db.MonitoringOid).filter(db.MonitoringOid.monitoring_type_uuid.in_(uuids)).delete('fetch')
                db.Session.query(db.MonitoringType).filter(db.MonitoringType.uuid.in_(uuids)).delete('fetch')
                db.Session.commit()
        except Exception:
            db.Session.rollback()
            logging.error('Could not delete monitoring types: %s', uuids, exc_info=True)
            raise

    def type_save(self, types = []):
        try:
            for t in types:
                self.core.monitoring_types[t['name']] = t['type']
                db_type = db.MonitoringType()
                db_type.from_dict(t)
                db_type.set_modified()
                db.Session.merge(db_type)

            db.Session.commit()
        except Exception as e:
            db.Session.rollback()
            logging.error('Could not save monitoring types: %s', e, exc_info=True)
            raise

    def oid_last_modified(self):
        """
        Returns a list of all title last_modified timestamps stored on this core
        """
        oids = db.Session.query(db.MonitoringOid)
        return dict(((oid.uuid, oid.last_modified) for oid in oids))

    def oid_delete(self, uuids):
        try:
            db.Session.query(db.MonitoringOid).filter(db.MonitoringOid.uuid.in_(uuids)).delete('fetch')
            db.Session.commit()
        except Exception:
            db.Session.rollback()
            logging.error('Could not delete monitoring oids: %s', uuids, exc_info=True)
            raise

    def oid_save(self, oids = []):
        try:
            for oid in oids:
                db_oid = db.MonitoringOid()
                db_oid.from_dict(oid)
                db_oid.set_modified()
                db.Session.merge(db_oid)

            db.Session.commit()
        except Exception as e:
            db.Session.rollback()
            logging.error('Could not save monitoring oids: %s', e, exc_info=True)
            raise

    def oids(self, device_config = None):
        if device_config is None:
            installed_device_types = set([ device.device_configuration['type'] for device in self.core.devices.values() if device.device_configuration['category'] in ('sms', 'projector') ])
            installed_device_models = set([ device.device_configuration['model'] for device in self.core.devices.values() if device.device_configuration['category'] in ('sms', 'projector') and device.device_configuration['model'] != 'default' ])
        else:
            installed_device_types = [device_config['make']]
            installed_device_models = [device_config['model']]
        MonitoringTypeParent = aliased(db.MonitoringType)
        monitoring_oids = db.Session.query(db.MonitoringOid, db.MonitoringType, MonitoringTypeParent.name.label('parent_name')).join(db.MonitoringType, db.MonitoringType.uuid == db.MonitoringOid.monitoring_type_uuid).outerjoin(MonitoringTypeParent, MonitoringTypeParent.uuid == db.MonitoringType.parent_uuid).filter(db.MonitoringOid.type.in_(installed_device_types), db.MonitoringOid.model.in_(installed_device_models)).order_by(db.MonitoringOid.category, db.MonitoringOid.type, db.MonitoringOid.model)
        configs = defaultdict(list)
        for oid, mtype, parent_name in monitoring_oids:
            desc = (oid.category, oid.type, oid.model)
            if mtype.type == 'scalar':
                configs[desc].append({'name': mtype.name,
                 'oid': oid.oid,
                 'freq': oid.frequency,
                 'version': oid.version,
                 'transform': json.loads(oid.transform) if oid.transform else None})

        return [ {'category': setup[0],
         'make': setup[1],
         'models': [setup[2]],
         'values': oids} for setup, oids in configs.iteritems() ]

    def forecast_disk_usage(self, device_ids = [], days_to_forecast = None):
        """
        Predicts how much of the specified devices' disk space will be used (as a percentage)
        for the next specified number of days. The first percentage in the array is the
        current disk usage, and each subsequent number is the predicted disk usage (taking CPLs
        in the transfer queue into account) 24 hours after the previous number.
        If no devices are specified, all devices implementing the Playback API are returned.
        
        :param device_ids: An optional list of device uuids
        :param days_to_forecast: An integer specifying the number of days to forecast.
        Defaults to 7.
        :returns: A JSON string containing the predicted disk usage.
        
        Example HTTP request::
        
            GET /tms/forecast_disk_usage?days_to_forecast=3&device_ids=["a13a3381-5c1e-40c4-aff4-d8fe3546cc78"]
        
        Example HTTP response::
        
            {
                7d343e56-3b8c-4092-9b1d-2cc63b5a48c7: {
                    definite: [
                        75.39612,
                        75.39612,
                        75.39612,
                        75.49038
                    ],
                    last_updated: 1360322047.702
                }
            }
        """

        class DeviceReportingZeroSize(Exception):

            def __str__(self):
                return 'Device is reporting a total disk size of 0B.'

        DAY = 86400
        messages = []
        current_time = time.time()
        disk_use_info = {}
        approx_size = {'feature': 199300000000L,
         'advertisement': 524288000,
         'trailer': 2147000000,
         'unknown': 199300000000L}
        if days_to_forecast != None:
            days_to_forecast = int(days_to_forecast)
        else:
            days_to_forecast = 7
        device_uuids = self.core.get_devices(device_ids=device_ids, required_api=Playlist)[0]
        for device_uuid in device_uuids:
            daily_transfer_size = [0] * (days_to_forecast + 1)
            definite_use = []
            device_info = self.info(device_ids=[device_uuid])[0][device_uuid]
            if 'storage_used' not in device_info:
                definite_use = None
            else:
                try:
                    definite_use.append(device_info['storage_used'])
                    try:
                        total_disk_space = float(device_info['storage_total'])
                    except TypeError:
                        total_disk_space = 0

                    if total_disk_space == 0:
                        definite_use = None
                        raise DeviceReportingZeroSize
                    queued_content = self.core.content_service.transfer_status(device_ids=[device_uuid], active_only=False)[0][device_uuid]['queue']
                    for content in queued_content:
                        day_transferring = 1
                        if content['not_before'] != None:
                            day_transferring = int(math.ceil((content['not_before'] - current_time) / DAY))
                        if day_transferring <= days_to_forecast:
                            content_id = content['content_id']
                            content_info = self.core.content_service.content(content_ids=[content_id])[0][content_id]
                            if 'devices' in content_info:
                                devices_cpl_is_on = content_info['devices']
                                if content['source'] != 'Auto' and content['source'] in devices_cpl_is_on and 'cpl_size' in devices_cpl_is_on[content['source']]:
                                    daily_transfer_size[day_transferring] += int(devices_cpl_is_on[content['source']]['cpl_size'])
                                else:
                                    size_known = False
                                    for k, device_info in devices_cpl_is_on.iteritems():
                                        if 'cpl_size' in device_info and device_info['cpl_size'] is not None:
                                            daily_transfer_size[day_transferring] += int(device_info['cpl_size'])
                                            size_known = True
                                            break

                                    if not size_known:
                                        if 'content_kind' in content_info and content_info['content_kind'] in approx_size:
                                            size = approx_size[content_info['content_kind']]
                                        else:
                                            size = approx_size['unknown']
                                        daily_transfer_size[day_transferring] += size
                            else:
                                logging.error('Error getting device information from content info: %s' % str(content_info))

                    for i in range(1, days_to_forecast + 1):
                        definite_use.append(definite_use[i - 1] + daily_transfer_size[i])
                        definite_use[i - 1] = definite_use[i - 1] / total_disk_space * 100

                    definite_use[days_to_forecast] = definite_use[days_to_forecast] / total_disk_space * 100
                except DeviceReportingZeroSize as e:
                    messages.append({'msg': 'Forecast failed for device {0}: {1}'.format(device_uuid, e),
                     'level': 'ERROR'})

            disk_use_info[device_uuid] = {}
            disk_use_info[device_uuid]['definite'] = definite_use
            disk_use_info[device_uuid]['last_updated'] = current_time

        return (disk_use_info, messages)
# okay decompyling ./core/services/monitoring_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:16 CST
