# 2017.08.13 21:50:54 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\projection_service.py
from serv.core.devices.base.projection import Projection
from serv.core.services.base_service import Service

class ProjectionService(Service):

    def status(self, device_ids = []):
        """
        Returns the projector statuses
        """
        device_ids, device_errors = self._get_devices(device_ids, Projection)
        projection_status = dict(((device_id, self.core.devices[device_id].device_information) for device_id in device_ids))
        return (projection_status, device_errors['messages'])
# okay decompyling ./core/services/projection_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:54 CST
