# 2017.08.13 21:50:41 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\pos_service.py
from collections import deque, defaultdict
from datetime import datetime, timedelta, date
import logging
import os
import time
import uuid as uuid_
from sqlalchemy.orm import subqueryload, joinedload
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_, not_, or_
from serv.lib.utilities import config
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration.constants import AUTO_CLEANUP_POS_VALIDITY
from serv.lib.utilities.show_attribute_utils import gen_sa_uuid
from serv.lib.utilities.show_attribute_tms_utils import TmsShowAttributeUtils
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.lib.utilities.helper_methods import sqlite_chunk
from serv.core.devices.base.playback import Playback
from serv.core.devices.base.pos import POS
from serv.lib.utilities.helper_methods import audit_log
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
import cherrypy

class POS_Service(Service):

    def __init__(self, core):
        super(POS_Service, self).__init__(core)
        self.pos_latest_resync = {}
        self.pos_mapping_summary = {}
        self.pos_sync_history = deque(maxlen=20)
        self.pos_sync_error = None
        self.pos_devices_syncing = {}
        return

    def last_modified(self):
        pos_items = db.Session.query(db.POSItem)
        return dict(((pos_item.uuid, pos_item.last_modified) for pos_item in pos_items))

    def status(self):
        return {'enabled': cfg.pos_enabled.get(),
         'mapping': self.pos_mapping_summary,
         'syncing': self.pos_devices_syncing,
         'latest_resync': self.pos_latest_resync,
         'sync_error': self.pos_sync_error,
         'auto_transfer_time': cfg.pos_auto_transfer_time()}

    def pos(self, week_number = None, hide_unconfigured = False, hide_expired = False, show_disabled = False):
        external_titles = {}
        all_pos_sources = db.Session.query(db.Device.type).filter(db.POSItem.device_uuid == db.Device.uuid).all()
        pos_sources = list(set((source[0] for source in all_pos_sources)))
        pos_sources.append('tms_pos')
        for data in db.Session.query(db.ExternalTitleMap.external_id, db.Title.name, db.Title.uuid).join(db.Title).filter(db.ExternalTitleMap.source.in_(pos_sources)):
            external_titles[data[0]] = (data[1], data[2])

        def __pos_item_dict(pos_item):
            scheduled = False
            schedule_uuid = None
            if len(pos_item.schedule) > 0 and pos_item.schedule[0]:
                schedule = pos_item.schedule[0]
                if not pos_item.playlist_uuid or schedule.device_playlist_uuid and schedule.device_schedule_id:
                    scheduled = True
                    schedule_uuid = schedule.uuid
            if len(str(pos_item.start.minute)) == 2:
                short_start_time = str(pos_item.start.hour) + ':' + str(pos_item.start.minute)
            else:
                short_start_time = str(pos_item.start.hour) + ':' + '0' + str(pos_item.start.minute)
            unmatched_show_attributes = {}
            show_attributes = {}
            deleted_show_attributes = [ (pam.show_attribute.uuid if pam.deleted and pam.show_attribute is not None else None) for pam in pos_item.pos_attribute_maps ]
            for ex_attr in pos_item.ex_show_attributes:
                if ex_attr.show_attribute == None:
                    unmatched_show_attributes[ex_attr.uuid] = ex_attr.external_id
                elif ex_attr.show_attribute.uuid not in deleted_show_attributes:
                    show_attributes[ex_attr.show_attribute.uuid] = ex_attr.show_attribute.name

            title_name, title_uuid = external_titles.get(pos_item.feature_title, (None, None))
            try:
                screen_id = pos_item.external_device_map.device.screen_uuid
            except:
                screen_id = None

            return {'screen_identifier': pos_item.screen_identifier,
             'screen_uuid': screen_id,
             'complex_identifier': pos_item.complex_identifier,
             'source_start': time.mktime(pos_item.source_start.timetuple()),
             'start': time.mktime(pos_item.start.timetuple()),
             'end': time.mktime(pos_item.end.timetuple()),
             'print_number': pos_item.print_number,
             'seats_available': pos_item.seats_available,
             'seats_sold': pos_item.seats_sold,
             'state': pos_item.state,
             'uuid': pos_item.uuid,
             'playlist_id': pos_item.playlist_uuid,
             'placeholder_type': pos_item.placeholder_type,
             'message': pos_item.message,
             'expired': pos_item.start < now,
             'scheduled': scheduled,
             'show_attributes': show_attributes,
             'unmatched_show_attributes': unmatched_show_attributes,
             'title_name': title_name,
             'title_uuid': title_uuid,
             'title': pos_item.feature_title,
             'overall_duration': pos_item.overall_duration,
             'feature_duration': pos_item.feature_duration,
             'schedule_id': schedule_uuid,
             'week_number': pos_item.week_number,
             'short_start_time': short_start_time,
             'device_uuid': pos_item.device_uuid,
             'source': pos_item.device.type,
             'id': pos_item.external_id}

        pos_info = {}
        if not week_number:
            weeks = self.week_number()[0]
            week_number = weeks[0]
        week_number = int(week_number)
        pos_info[week_number] = {}
        now = datetime.now()
        pos_items = db.Session.query(db.POSItem).filter(and_(db.POSItem.week_number == week_number, or_(db.POSItem.device.has(db.Device.enabled == True), show_disabled == True))).options(subqueryload('schedule'), joinedload('ex_show_attributes'), joinedload('device'), joinedload('external_device_map'), joinedload('external_device_map.device'))
        if hide_unconfigured:
            pos_items = pos_items.join(db.ExternalDeviceMap).join(db.Device).filter(db.Device.enabled == True)
        if hide_expired:
            pos_items = pos_items.filter(db.POSItem.start >= now)
        for pos_item in pos_items:
            source_device = pos_item.device_uuid
            if source_device not in pos_info[pos_item.week_number]:
                pos_info[pos_item.week_number][source_device] = {}
            pos_info[pos_item.week_number][source_device][pos_item.external_id] = __pos_item_dict(pos_item)

        return pos_info

    def delete(self, pos_deletion_map):
        message = None
        deleted = 0
        pos_items = db.Session.query(db.POSItem).filter(db.POSItem.uuid.in_(pos_deletion_map.keys()))
        if pos_items.count() != 0:
            for pos_item in pos_items:
                pos_item.state = 'deleted'
                pos_item.message = _('Session was deleted')
                pos_item.set_modified()
                deleted = deleted + 1
                audit_log('POS Session marked as deleted: session_uuid="%s" ' % pos_item.uuid, tags=['pos', 'delete'])
                cherrypy.engine.publish('ccpush', 'pos_delete', {'uuid': pos_item.uuid})

            message = {'type': 'success',
             'message': _('[%s] POS sessions deleted.') % deleted}
        else:
            message = {'type': 'error',
             'message': _('Cannot find specified POS sessions')}
        db.Session.commit()
        cherrypy.engine.publish('queue_schedule_sync')
        return message

    def save_mappings(self, pos_update_map):
        """Applies updates to POS items as per the supplied dictionary: pos_update_map
        :param pos_update_map: a dictionary of playlist assignents etc for pos items
        
        {
            "<POSItem uuid>" : {
                                             "playlist_id": "<uuid of playlist>" or None,
                                             "placeholder_type": ?,
                                             'state': 'assigned'|?
                                          }
          }
        
         E.g:
              {
                  '69073a67-483b-4783-a603-713729bc702f': {
                              'playlist_id': 'auto',
                              'placeholder_type': None,
                              'state': 'assigned
                '}
             }
        """
        updated = 0
        pos_items = db.Session.query(db.POSItem).options(subqueryload('pos_attribute_maps')).filter(db.POSItem.uuid.in_(pos_update_map.keys()))
        if pos_items.count():
            for pos_item in pos_items:
                pos_item.modified = True
                pos_item.placeholder_type = pos_update_map[pos_item.uuid].get('placeholder_type', None)
                pos_item.playlist_uuid = pos_update_map[pos_item.uuid].get('playlist_id', None)
                if pos_item.playlist_uuid == None:
                    pos_item.description = None
                pos_item.template_uuid = pos_update_map[pos_item.uuid].get('template_uuid', None)
                pos_item.transfer_not_before = pos_update_map[pos_item.uuid].get('transfer_not_before', None)
                if 'show_attributes' in pos_update_map[pos_item.uuid]:
                    show_attributes = pos_update_map[pos_item.uuid]['show_attributes']
                    current_uuids = []
                    for map in pos_item.pos_attribute_maps:
                        if map.external_show_attribute.show_attribute != None:
                            current_uuids.append(map.external_show_attribute.show_attribute.uuid)
                            if map.external_show_attribute.show_attribute.uuid not in show_attributes:
                                if not map.manual:
                                    map.deleted = True
                                else:
                                    db.Session.delete(map)
                            elif not map.manual:
                                map.deleted = False

                    to_add = [ uuid for uuid in show_attributes if uuid not in current_uuids ]
                    for uuid in to_add:
                        db_ex_attrs = db.Session.query(db.ExternalShowAttributeMap).join('show_attribute').filter(and_(db.ExternalShowAttributeMap.source == 'aam', db.ShowAttribute.uuid == uuid)).all()
                        for attr in db_ex_attrs:
                            add = db.PosShowAttributeMap()
                            add.external_show_attribute_uuid = attr.uuid
                            add.manual = True
                            add.pos_item_uuid = pos_item.uuid
                            db.Session.add(add)

                if 'reset' in pos_update_map[pos_item.uuid]:
                    pos_item.start = pos_item.source_start
                if pos_item.playlist_uuid or pos_item.placeholder_type:
                    pos_item.message = _('POS Session is marked for updating')
                else:
                    pos_item.message = _('POS Session has not been assigned to a Playlist or Placeholder')
                if pos_item.playlist_uuid == 'auto':
                    pos_item.description = _('Automatic assignment')
                elif pos_item.playlist_uuid in self.core.devices[cfg.lms_uuid()].playlist_information:
                    pos_item.description = self.core.devices[cfg.lms_uuid()].playlist_information[pos_item.playlist_uuid]['playlist']['title']
                pos_item.state = pos_update_map[pos_item.uuid]['state']
                if pos_item.state == 'unassigned':
                    pos_item.start = pos_item.source_start
                    pos_item.playlist_uuid = None
                pos_item.set_modified()
                updated = updated + 1
                audit_log('POS Session updated: session_uuid="%s" playlist_uuid="%s" placeholder_type="%s" ' % (pos_item.uuid, pos_item.playlist_uuid, pos_item.placeholder_type), tags=['pos', 'modified'])
                cherrypy.engine.publish('ccpush', 'pos_save', pos_item.to_dict())

            message = {'type': 'success',
             'message': _('[%s] POS Sessions updated') % updated}
        else:
            message = {'type': 'error',
             'message': _('No matching POS Sessions were found')}
        db.Session.commit()
        cherrypy.engine.publish('queue_schedule_sync')
        return message

    def resync_mappings(self, min_stamp, max_stamp, screens, placeholders, pack_uuids = [], confirmed = False, trigger = None):
        output = {'data': {},
         'messages': []}
        resync_gap = cfg.core_auto_schedule_resync_gap_minutes.get()
        auto_resync = cfg.core_auto_schedule_resync.get()
        min_stamp = datetime.now() + timedelta(minutes=resync_gap) if min_stamp is None or datetime.fromtimestamp(min_stamp) < datetime.now() + timedelta(minutes=resync_gap) else datetime.fromtimestamp(min_stamp)
        max_stamp = datetime.now() + timedelta(weeks=3) if max_stamp is None or datetime.fromtimestamp(max_stamp) < datetime.now() + timedelta(minutes=resync_gap) else datetime.fromtimestamp(max_stamp)
        pos_items = db.Session.query(db.POSItem).filter(db.POSItem.state == 'assigned')
        main_conds = [db.POSItem.start > min_stamp, db.POSItem.start < max_stamp]
        if screens:
            main_conds.append(db.POSItem.external_device_map.has(db.ExternalDeviceMap.device.has(db.Device.screen.has(db.Screen.identifier.in_(screens)))))
        if placeholders:
            main_conds.append(or_(*[ db.POSItem.schedule.any(db.Schedule.templating_issues.like('%' + uid + '%')) for uid in placeholders ]))
        branch_conds = [and_(*main_conds)]
        if pack_uuids:
            minimum_time = datetime.now() + timedelta(minutes=resync_gap)
            maximum_time = datetime.now() + timedelta(weeks=3)
            branch_conds.append(and_(db.POSItem.start > minimum_time, db.POSItem.start < maximum_time, or_(*[ db.POSItem.schedule.any(db.Schedule.templating_issues.like('%' + uid + '%')) for uid in pack_uuids ])))
        pos_items = pos_items.filter(or_(*branch_conds))
        count_pos_sessions = pos_items.count()
        try:
            if auto_resync or confirmed:
                for pos_item in pos_items:
                    if pack_uuids:
                        if pos_item.start > max_stamp:
                            max_stamp = pos_item.start
                        elif pos_item.start < min_stamp:
                            min_stamp = min_stamp
                        if pos_item.screen_identifier not in screens:
                            screens.append(pos_item.screen_identifier)
                    pos_item.modified = True
                    if pos_item.playlist_uuid or pos_item.placeholder_type:
                        pos_item.message = _('POS Session is marked for updating')
                    else:
                        pos_item.message = _('POS Session has not been assigned to a Playlist or Placeholder')
                    if pos_item.playlist_uuid in self.core.devices[cfg.lms_uuid()].playlist_information:
                        pos_item.description = self.core.devices[cfg.lms_uuid()].playlist_information[pos_item.playlist_uuid]['playlist']['title']
                    pos_item.set_modified()

                db.Session.commit()
                logging.info('Resyncing %s POS sessions' % str(count_pos_sessions))
                logging.info('Minimum timestamp: [%s]' % str(helper_methods.format_datetime(min_stamp, short=True)))
                logging.info('Maximum timestamp: [%s]' % str(helper_methods.format_datetime(max_stamp, short=True)))
                logging.info('Screens: [%s]' % str(screens if screens else 'All'))
                audit_log('POS Sessions marked for re-sync: min_stamp="%s" max_stamp="%s" screens="%s" count="%s" ' % (helper_methods.format_datetime(min_stamp, short=True),
                 helper_methods.format_datetime(max_stamp, short=True),
                 screens if screens else 'All',
                 count_pos_sessions), tags=['pos', 'sync'])
            success = True
        except Exception as ex:
            logging.error('There was an error while re-syncing the POS feed.', exc_info=True)
            success = False

        if success:
            if auto_resync or confirmed:
                message = _('POS Schedules have been synced')
            else:
                message = _('POS Schedules must be synced')
        else:
            message = _('POS Schedules failed to sync')
        if count_pos_sessions > 0:
            screens.sort()
            self.core.pos.service._update_pos_sync_history(success=success, message=message, time_string=helper_methods.format_datetime(datetime.now(), short=True), min_stamp=helper_methods.format_datetime(min_stamp, short=True), max_stamp=helper_methods.format_datetime(max_stamp, short=True), screens=screens, placeholders=placeholders, pack_uuids=pack_uuids, confirmed=auto_resync or confirmed, sync_type='session_resync', source=trigger)
            self.update_resync_status()
        if success:
            cherrypy.engine.publish('queue_schedule_sync')
            output['messages'].append({'type': 'success',
             'message': _('[%s] POS Sessions are marked for scheduling.') % str(count_pos_sessions)})
            output['data']['count'] = count_pos_sessions
        else:
            output['messages'].append({'type': 'error',
             'message': _('There was an error while syncing the POS feed [%s]' % message)})
        return output

    def schedule_state(self):
        return self.core.schedule_synchroniser.changes

    def week_number(self):
        today = datetime.today()
        iso_year, iso_week, today_iso_day = today.isocalendar()
        timestamps = {}
        this_week = helper_methods.week_number(today.year, today.month, today.day)
        if this_week == 52:
            weeks = [this_week, 1, 2]
        elif this_week == 51:
            weeks = [this_week, 52, 1]
        else:
            weeks = [this_week, this_week + 1, this_week + 2]
        if today_iso_day >= cfg.pos_first_day_of_week.get():
            days_since_start_of_week = today_iso_day - cfg.pos_first_day_of_week.get()
        else:
            days_since_start_of_week = today_iso_day - cfg.pos_first_day_of_week.get() + 7
        base = today - timedelta(days=days_since_start_of_week)
        timestamps[weeks[0]] = {'min': helper_methods.format_datetime(base, short=True, include_time=False),
         'max': helper_methods.format_datetime(base + timedelta(days=6), short=True, include_time=False)}
        timestamps[weeks[1]] = {'min': helper_methods.format_datetime(base + timedelta(days=7), short=True, include_time=False),
         'max': helper_methods.format_datetime(base + timedelta(days=13), short=True, include_time=False)}
        timestamps[weeks[2]] = {'min': helper_methods.format_datetime(base + timedelta(days=14), short=True, include_time=False),
         'max': helper_methods.format_datetime(base + timedelta(days=20), short=True, include_time=False)}
        return (weeks, timestamps)

    def append_cinema_id(self, cinema_id):
        current = self.get_complex_identifiers()
        if isinstance(cinema_id, str):
            cinema_id = unicode(cinema_id, 'utf8')
        if cinema_id not in current:
            new_value = unicode(cfg.pos_cinema_identifier.get(), 'utf8') + ', ' + cinema_id if len(current) > 0 else cinema_id
            cfg.pos_cinema_identifier.set(new_value)
            config.save()
            message = {'type': 'success',
             'message': _('Added new Complex Identifier [%s]') % cinema_id}
            success = True
            logging.info('Added new complex identifier [%s]' % cinema_id)
            audit_log('New complex id added: complex_id="%s" ' % cinema_id, tags=['pos', 'save'])
        else:
            message = {'type': 'error',
             'message': _('Complex Identifier already exists [%s]') % cinema_id}
            success = False
        return (success, message)

    def set_configuration(self, pos_config):
        pos_just_enabled = False
        pos_session_length_changed = False
        week_settings_changed = False
        if 'pos_cinema_identifier' in pos_config:
            cfg.pos_cinema_identifier.set(pos_config['pos_cinema_identifier'])
        if 'pos_first_day_of_week' in pos_config:
            week_settings_changed = pos_config['pos_first_day_of_week'] != cfg.pos_first_day_of_week.get()
            cfg.pos_first_day_of_week.set(pos_config['pos_first_day_of_week'])
        if 'pos_feed_type' in pos_config:
            cfg.pos_feed_type.set(pos_config['pos_feed_type'])
        if 'pos_auto_transfer_time' in pos_config:
            cfg.pos_auto_transfer_time.set(pos_config['pos_auto_transfer_time'])
        if 'pos_vista_feature_stamp' in pos_config:
            cfg.pos_vista_feature_stamp.set(pos_config['pos_vista_feature_stamp'])
        if 'pos_week_offset' in pos_config:
            if not week_settings_changed:
                week_settings_changed = int(pos_config['pos_week_offset']) != cfg.pos_week_offset.get()
            cfg.pos_week_offset.set(pos_config['pos_week_offset'])
        if 'pos_enabled' in pos_config:
            pos_current_state = cfg.pos_enabled()
            cfg.pos_enabled.set(pos_config['pos_enabled'])
            if int(pos_config['pos_enabled']) and not pos_current_state:
                pos_just_enabled = True
            if not int(pos_config['pos_enabled']):
                self.pos_sync_error = None
        if 'pos_default_session_length' in pos_config:
            if int(pos_config['pos_default_session_length']) != cfg.pos_default_session_length.get():
                new_length = 10 if int(pos_config['pos_default_session_length']) < 10 else int(pos_config['pos_default_session_length'])
                pos_session_length_changed = True
                cfg.pos_default_session_length.set(new_length)
        config.save()
        if pos_session_length_changed:
            logging.info('POS default session length changed. Updating schedules.')
            self._update_unassigned_session_length(cfg.pos_default_session_length.get())
        if pos_just_enabled:
            logging.info('POS has just been enabled. Repulling POS feeds.')
            self.sync()
        if week_settings_changed:
            logging.info('POS settings changed. Updating Sessions.')
            pos_items = db.Session.query(db.POSItem).all()
            for pos_item in pos_items:
                start = pos_item.start
                pos_item.week_number = helper_methods.week_number(start.year, start.month, start.day)
                pos_item.set_modified()

            db.Session.commit()
        cherrypy.engine.publish('queue_schedule_sync')
        audit_log('POS configuration updated: complex_id="%s" pos_week_offset="%s" pos_first_day_of_week="%s" pos_feed_type="%s" pos_enabled="%s" pos_auto_transfer_time="%s" core_templated_playlist_name="%s" core_templated_playlist_date_format="%s" pos_default_session_length="%s" pos_vista_feature_stamp="%s"' % (self.get_complex_identifiers(),
         cfg.pos_week_offset.get(),
         cfg.pos_first_day_of_week.get(),
         cfg.pos_feed_type.get(),
         cfg.pos_enabled.get(),
         cfg.pos_auto_transfer_time.get(),
         cfg.core_templated_playlist_name.get(),
         cfg.core_templated_playlist_date_format.get(),
         cfg.pos_default_session_length.get(),
         cfg.pos_vista_feature_stamp.get()), tags=['pos', 'save'])
        return {'type': 'success',
         'message': _('Configuration updated')}

    def get_configuration(self):
        config_info = {}
        config_info['pos_cinema_identifier'] = cfg.pos_cinema_identifier.get()
        config_info['pos_first_day_of_week'] = cfg.pos_first_day_of_week.get()
        config_info['pos_feed_type'] = cfg.pos_feed_type.get()
        config_info['pos_week_offset'] = cfg.pos_week_offset.get()
        config_info['pos_enabled'] = cfg.pos_enabled.get()
        config_info['pos_auto_transfer_time'] = cfg.pos_auto_transfer_time.get()
        config_info['pos_default_session_length'] = cfg.pos_default_session_length.get()
        config_info['pos_vista_feature_stamp'] = cfg.pos_vista_feature_stamp.get()
        return config_info

    def sync_history(self):
        cfg_ids = self.get_complex_identifiers()
        sync_history = list(self.pos_sync_history)
        for sync in sync_history:
            if sync.get('missing_complex_identifiers'):
                for complex_id in sync['missing_complex_identifiers']:
                    if complex_id in cfg_ids:
                        sync['missing_complex_identifiers'].remove(complex_id)

        sync_history.reverse()
        return sync_history

    def sync(self, device_ids = []):
        try:
            device_ids, errors = self.core.get_devices(device_ids, POS)
            if len(device_ids) == 0:
                message = {'type': 'success',
                 'message': _('There are no POS devices enabled')}
                success = True
                return (success, message)
            for device_id in device_ids:
                self.core.devices[device_id].force_sync = True
                self.core.devices[device_id].pos_timestamp = {'last_updated': None}
                audit_log('POS Device marked for re-pull: {device:device_uuid}', meta={'device': device_id}, tags=['pos', 'sync'])

            success = True
            message = {'type': 'success',
             'message': _('Resyncing POS')}
        except Exception as ex:
            logging.error('There was an error while syncing the POS feed.', exc_info=True)
            success = False
            message = {'type': 'error',
             'message': _('Unknown error while resyncing POS')}

        return (success, message)

    def update_resync_status(self):
        if len(self.pos_sync_history) != 0:
            self.pos_latest_resync = self.pos_sync_history[-1]

    def update_mapping_overview(self):
        if cfg.pos_enabled.get():
            this_week = date.today()
            next_week = this_week + timedelta(weeks=1)
            next_next_week = this_week + timedelta(weeks=2)
            this_week_number = int(helper_methods.week_number(this_week.year, this_week.month, this_week.day))
            next_week_number = int(helper_methods.week_number(next_week.year, next_week.month, next_week.day))
            next_next_week_number = int(helper_methods.week_number(next_next_week.year, next_next_week.month, next_next_week.day))
            week_map = {this_week_number: 'this_week',
             next_week_number: 'next_week',
             next_next_week_number: 'next_next_week'}
            pos_items = db.Session.query(db.POSItem).filter(and_(db.POSItem.week_number.in_(week_map.keys()), db.POSItem.state != 'deleted', db.POSItem.start > datetime.now(), db.POSItem.schedule.any(), or_(db.POSItem.device_uuid == None, db.POSItem.device.has(db.Device.enabled == True)))).options(joinedload('schedule'), joinedload('external_device_map'))
            summary = {'this_week': {'total': 0,
                           'mapped': 0,
                           'week_number': this_week_number,
                           'mapping_errors': 0},
             'next_week': {'total': 0,
                           'mapped': 0,
                           'week_number': next_week_number,
                           'mapping_errors': 0},
             'next_next_week': {'total': 0,
                                'mapped': 0,
                                'week_number': next_next_week_number,
                                'mapping_errors': 0}}
            for pos_item in pos_items:
                if pos_item.external_device_map == None or pos_item.external_device_map.device and pos_item.external_device_map.device.enabled == True:
                    week_num = week_map[pos_item.week_number]
                    summary[week_num]['total'] = summary[week_num]['total'] + 1
                    if pos_item.state == 'error':
                        summary[week_num]['mapping_errors'] += 1
                    if pos_item.schedule:
                        schedule = pos_item.schedule[0]
                        if schedule.device_playlist_uuid != None or schedule.placeholder_type != None:
                            summary[week_num]['mapped'] = summary[week_num]['mapped'] + 1

            self.pos_mapping_summary = summary
        return

    @db.close_session
    def update_pos_items(self, pos_info, allow_empty = False):
        pos_update_status = {'expired': [],
         'added': [],
         'existing': [],
         'updated': [],
         'deleted': [],
         'error': [],
         'total': []}
        success = False
        now = datetime.now()
        schedules_to_delete = []
        session_attributes = {}
        if cfg.pos_enabled.get():
            try:
                self.core.schedule_lock.acquire()
                complex_identifiers = self.get_complex_identifiers()
                missing_complex_identifiers = set()
                if len(pos_info.get('sessions', [])) or allow_empty:
                    sessions = {}
                    for session in pos_info['sessions']:
                        sessions[session['id']] = session

                    pos_device_id = pos_info.get('device')
                    pos_device = self.core.devices.get(pos_device_id)
                    pos_device_type = pos_device.device_configuration['type']
                    db_pos_items = db.Session.query(db.POSItem)
                    db_pos_items = db_pos_items.filter(db.POSItem.device_uuid == pos_device_id)
                    delete_these = []
                    title_maps_for_producer = set()
                    db_pos_items = db_pos_items.options(joinedload('ex_show_attributes'), joinedload('device')).all()
                    complex_id_items = {}
                    for db_pos_item in db_pos_items:
                        delete_this = False
                        session_found = False
                        deletion_info = ''
                        pos_item = sessions.get(db_pos_item.external_id)
                        if pos_item:
                            session_found = True
                            if pos_item.get('complex_identifier') is not None and pos_item.get('complex_identifier') != db_pos_item.complex_identifier:
                                logging.info('Deleting POS Session [%s], Complex has changed from [%s] to [%s]' % (db_pos_item.uuid, db_pos_item.complex_identifier, pos_item.get('complex_identifier')))
                                delete_this = True
                                deletion_info = _('Complex has changed from [%s] to [%s]') % (db_pos_item.complex_identifier, pos_item.get('complex_identifier'))
                            elif pos_item['screen_identifier'] != db_pos_item.screen_identifier:
                                logging.info('Deleting POS Session [%s], Screen has changed from [%s] to [%s]' % (db_pos_item.uuid, db_pos_item.screen_identifier, pos_item.get('screen_identifier')))
                                delete_this = True
                                deletion_info = _('Screen has changed from [%s] to [%s]') % (db_pos_item.screen_identifier, pos_item.get('complex_identifier'))
                            elif pos_item['start'] != db_pos_item.source_start:
                                logging.info('Deleting POS Session [%s], Start Time has changed from [%s] to [%s]' % (db_pos_item.uuid, db_pos_item.source_start, pos_item['start']))
                                delete_this = True
                                deletion_info = _('Start Time has changed from [%s] to [%s]') % (db_pos_item.source_start, pos_item['start'])
                            elif pos_item['feature_title'] != db_pos_item.feature_title:
                                logging.info('Deleting POS Session [%s], Session Title has changed from [%s] to [%s]' % (db_pos_item.uuid, db_pos_item.feature_title, pos_item['feature_title']))
                                delete_this = True
                                deletion_info = _('Session Title has changed from [%s] to [%s]') % (db_pos_item.feature_title, pos_item['feature_title'])
                        if delete_this:
                            delete_these.append(helper_methods.copy_by_value(db_pos_item.uuid))
                            pos_update_status['deleted'].append({'feature_title': helper_methods.copy_by_value(db_pos_item.feature_title),
                             'start': helper_methods.format_datetime(helper_methods.copy_by_value(db_pos_item.start)),
                             'screen': helper_methods.copy_by_value(db_pos_item.screen_identifier),
                             'message': deletion_info})
                        elif not session_found:
                            if db_pos_item.start > datetime.now() or db_pos_item.start < datetime.now() - timedelta(days=AUTO_CLEANUP_POS_VALIDITY):
                                logging.info('Deleting POS Session [%s], Session is no longer being reported by the POS feed.' % db_pos_item.uuid)
                                delete_these.append(helper_methods.copy_by_value(db_pos_item.uuid))
                                pos_update_status['deleted'].append({'feature_title': helper_methods.copy_by_value(db_pos_item.feature_title),
                                 'start': helper_methods.format_datetime(helper_methods.copy_by_value(db_pos_item.start)),
                                 'screen': helper_methods.copy_by_value(db_pos_item.screen_identifier),
                                 'message': _('Session was deleted in the POS feed')})
                        else:
                            complex_id_items.setdefault(pos_item.get('complex_identifier'), {})[pos_item['id']] = db_pos_item

                    if delete_these:
                        schedules_to_delete = self.remove_pos_items(delete_these, pos_device_id)
                    self._update_external_pos_device_map(pos_info['sessions'], pos_device_id, complex_identifiers)
                    pos_session_count = len(pos_info['sessions'])
                    ex_title_maps_uuids = {}
                    ex_title_maps_query = db.Session.query(db.ExternalTitleMap.external_id, db.ExternalTitleMap.uuid).filter(db.ExternalTitleMap.source == pos_device_type).all()
                    for ex_id, uuid in ex_title_maps_query:
                        ex_title_maps_uuids[ex_id] = uuid

                    to_commit = 0
                    for pos_item in pos_info['sessions']:
                        if pos_item.get('complex_identifier') is None or pos_item['complex_identifier'] in complex_identifiers:
                            pos_item['device_uuid'] = pos_info.get('device')
                            if pos_item.get('start') > now:
                                external_title_map_uuid = ex_title_maps_uuids.get(pos_item['feature_title'])
                                if not external_title_map_uuid:
                                    external_title_map_uuid = str(uuid_.uuid4())
                                    etm = db.ExternalTitleMap(uuid=external_title_map_uuid, external_id=pos_item['feature_title'], source=pos_device_type, title_uuid=None, name=pos_item['feature_title'])
                                    ex_title_maps_uuids[pos_item['feature_title']] = external_title_map_uuid
                                    db.Session.add(etm)
                                    title_maps_for_producer.add(external_title_map_uuid)
                                pos_item['external_title_map_uuid'] = external_title_map_uuid
                                db_pos_item = complex_id_items.get(pos_item.get('complex_identifier'), {}).get(pos_item['id'])
                                pos_session = {'feature_title': pos_item['feature_title'],
                                 'start': helper_methods.format_datetime(pos_item['start']),
                                 'screen': pos_item['screen_identifier'],
                                 'message': _('POS Session has not changed')}
                                if db_pos_item:
                                    updated, message = self._update_pos_item(db_pos_item, pos_item)
                                    state = 'updated' if updated else 'existing'
                                else:
                                    db_pos_item = self._add_pos_item(pos_item, pos_device_type)
                                    state = 'added'
                                    message = _('POS Session was added')
                                for pam in db_pos_item.pos_attribute_maps:
                                    if not pam.manual:
                                        if not pam.deleted:
                                            db.Session.delete(pam)

                                if pos_item.get('session_attributes'):
                                    session_attributes[db_pos_item.uuid] = set([ attr.strip() for attr in pos_item['session_attributes'].lower().split(',') if attr.strip() ])
                                pos_session['message'] = message
                                pos_update_status[state].append(pos_session)
                                to_commit += 1
                            else:
                                pos_update_status['expired'].append({'feature_title': pos_item['feature_title'],
                                 'start': helper_methods.format_datetime(pos_item['start']),
                                 'screen': pos_item['screen_identifier'],
                                 'message': _('POS Session has expired')})
                        else:
                            missing_complex_identifiers.add(pos_item.get('complex_identifier'))
                            pos_update_status['error'].append({'feature_title': pos_item['feature_title'],
                             'start': helper_methods.format_datetime(pos_item['start']),
                             'screen': pos_item['screen_identifier'],
                             'message': _('Complex name does not match the configured values: [%s]') % pos_item['complex_identifier']})
                        if to_commit >= 20:
                            db.Session.flush()
                            to_commit = 0

                    db.Session.commit()
                    cherrypy.engine.publish('ccpush', 'title_maps', {'title_maps': self.core.title_service.external_titles(list(title_maps_for_producer))})
                    pos_update_status['total'] = pos_session_count
                    success = True
                    message = _('Updated POS feed')
                else:
                    success = False
                    if not pos_info['success']:
                        message = _('Failed to update POS feed')
                        for msg in pos_info['messages']:
                            if msg['type'] == 'error':
                                if 'device' in pos_info:
                                    logging.error('Error retrieving POS feed from configured device [%s] : [%s]' % (pos_info['device'], msg['message']))
                                else:
                                    logging.error('Error retrieving POS feed : [%s]' % msg['message'])
                                message = msg['message']

                    else:
                        if 'device' in pos_info:
                            logging.error('No sessions found in POS feed from device [%s]' % pos_info['device'])
                        else:
                            logging.error('No sessions found in POS feed')
                        message = _('No sessions found in POS feed.')
                db.Session.commit()
            except Exception:
                logging.error('Error updating POS Sessions.', exc_info=True)
                success = False
                message = _('Failed to update POS feed')
            finally:
                self.core.schedule_lock.release()
                self.update_mapping_overview()

            self._update_pos_sync_history(success=success, message=message, source=pos_info.get('source'), missing_complex_identifiers=list(missing_complex_identifiers), sessions=pos_update_status, time_string=helper_methods.format_datetime(datetime.now(), short=True), sync_type='feed_update')
            if pos_info.get('device'):
                logging.info('POS sync complete for device [%s]' % pos_info.get('device'))
                audit_log('POS feed synced for device {device:device_uuid}', meta={'device': pos_info.get('device')}, tags=['pos', 'sync'])
            else:
                audit_log('POS feed synced from file', tags=['pos', 'sync'])
            logging.info('Added: [%s]' % str(len(pos_update_status['added'])))
            logging.info('Existing: [%s]' % str(len(pos_update_status['existing'])))
            logging.info('Updated: [%s]' % str(len(pos_update_status['updated'])))
            logging.info('Deleted: [%s]' % str(len(pos_update_status['deleted'])))
            logging.info('Error: [%s]' % str(len(pos_update_status['error'])))
            logging.info('Expired: [%s]' % str(len(pos_update_status['expired'])))
        else:
            message = _('POS is disabled')
        if 'device' in pos_info and pos_info['device'] in self.core.devices:
            if success and 'update_pos_items' in self.core.devices[pos_info['device']].device_status['error_messages']:
                del self.core.devices[pos_info['device']].device_status['error_messages']['update_pos_items']
            elif not success:
                self.core.devices[pos_info['device']].device_status['error_messages']['update_pos_items'] = message
        self.pos_sync_error = None
        if not success:
            self.pos_sync_error = message
        self.update_resync_status()
        self.clean_up_schedules(schedules_to_delete)
        if session_attributes:
            self.add_show_attributes(session_attributes, pos_device_type)
        cherrypy.engine.publish('queue_schedule_sync')
        return (success, message, pos_update_status)

    def persist_raw_feed(self, raw_input, source):
        pos_feed_file_dir = os.path.join(cfg.data_dir(), 'pos')
        pos_feed_file_name = 'pos_feed.log'
        try:
            filtered_filenames = []
            for filename in os.listdir(pos_feed_file_dir):
                if pos_feed_file_name in filename:
                    filtered_filenames.append(filename)

            filtered_filenames.sort()
            filtered_filenames.reverse()
            for filename in filtered_filenames:
                if str(cfg.pos_feed_file_count()) in filename:
                    os.remove(os.path.join(pos_feed_file_dir, filename))
                else:
                    try:
                        index = int(filename[-1])
                    except:
                        index = 0

                    os.rename(os.path.join(pos_feed_file_dir, filename), os.path.join(pos_feed_file_dir, filename.strip('.' + str(index)) + '.' + str(index + 1)))

            output = 'SOURCE=' + str(source) + '\n' + raw_input
            with open(os.path.join(pos_feed_file_dir, pos_feed_file_name), 'w') as f:
                f.write('')
                f.write(output)
        except Exception:
            logging.error('Error trying to persist POS feed to file system', exc_info=True)

    def get_title_uuid(self, db_pos_item):
        """
        Retrieves the uuid of the title that the pos_item is matched
        against, or None if no match
        :param db_pos_item: instance of a pos item from database
        :returns: title uuid associated to the POS item, or None if not found.
        """
        all_pos_sources = db.Session.query(db.Device.type).filter(db.POSItem.device_uuid == db.Device.uuid).all()
        pos_sources = list(set((source[0] for source in all_pos_sources)))
        title_map = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.source.in_(pos_sources), db.ExternalTitleMap.external_id == db_pos_item.feature_title)).first()
        if title_map:
            return title_map.title_uuid
        else:
            return None

    def _update_pos_sync_history(self, **kwargs):
        history_object = {}
        for key, value in kwargs.iteritems():
            if key != 'sessions':
                history_object[key] = value
            else:
                for other_key in ['added',
                 'updated',
                 'deleted',
                 'existing',
                 'error',
                 'expired']:
                    history_object[other_key] = {'total': len(value[other_key]),
                     'info': {}}
                    for session in value[other_key]:
                        if session['message'] not in history_object[other_key]['info']:
                            history_object[other_key]['info'][session['message']] = 0
                        history_object[other_key]['info'][session['message']] += 1

        self.pos_sync_history.append(history_object)

    def _update_external_pos_device_map(self, sessions, pos_device_id, complex_identifiers):
        add_external_ids = set()
        for pos_item in sessions:
            if not pos_item.get('complex_identifier') or pos_item['complex_identifier'] in complex_identifiers:
                add_external_ids.add(pos_item['screen_identifier'])

        device_maps = defaultdict(dict)
        for external_id in add_external_ids:
            device_uuid = self.core.configuration_service.add_update_external_device_id(external_id, pos_device_id, 'pos', None, False)
            device_maps[pos_device_id][external_id] = device_uuid

        cherrypy.engine.publish('ccpush', 'external_device_maps_save', {'pos': device_maps})
        return

    @db.close_session
    def _update_unassigned_session_length(self, minutes):
        duration_in_seconds = int(minutes) * 60
        for session in db.Session.query(db.POSItem).filter(and_(db.POSItem.state == 'unassigned', db.POSItem.schedule.any())).all():
            session.overall_duration = duration_in_seconds
            session.feature_duration = duration_in_seconds
            session.end = session.start + timedelta(seconds=duration_in_seconds)
            session.schedule[0].end_timestamp = session.schedule[0].start_timestamp + duration_in_seconds
            session.schedule[0].pos_duration = duration_in_seconds

        db.Session.commit()

    def clean_up_schedules(self, schedule_uuids):
        logging.info('Cleaning up schedules that are no longer in pos feed')
        for uuid_chunk in sqlite_chunk(schedule_uuids):
            self.core.scheduling_service.delete(uuid_chunk)

    def add_show_attributes(self, session_attributes, pos_device_type):
        try:
            attributes = set()
            for pos_uuid, attrs_set in session_attributes.iteritems():
                attributes |= attrs_set

            ex_sam_utils = TmsShowAttributeUtils(True, source=pos_device_type)
            for attribute in list(attributes):
                ex_sam = ex_sam_utils.insert_or_ignore_exam({'external_id': attribute,
                 'source': pos_device_type})
                try:
                    sa = ex_sam_utils.lookup(sa_uuid=gen_sa_uuid(attribute))
                    ex_sam.show_attribute_uuid = sa.uuid
                except NoResultFound:
                    pass

            db.Session.query(db.PosShowAttributeMap).filter(and_(db.PosShowAttributeMap.pos_item_uuid.in_(session_attributes.keys()), db.PosShowAttributeMap.deleted == False, db.PosShowAttributeMap.manual == False)).delete('fetch')
            db.Session.commit()
            db_exsams = db.Session.query(db.ExternalShowAttributeMap.external_id, db.ExternalShowAttributeMap.uuid).filter(db.ExternalShowAttributeMap.source == pos_device_type).all()
            exsams = {}
            for db_exsam in db_exsams:
                exsams[db_exsam[0].lower()] = db_exsam[1]

            for pos_uuid, attrs_set in session_attributes.iteritems():
                for attr in attrs_set:
                    exsam_uuid = exsams.get(attr.lower())
                    if exsam_uuid:
                        if not db.Session.query(db.PosShowAttributeMap).filter(and_(db.PosShowAttributeMap.external_show_attribute_uuid == exsam_uuid, db.PosShowAttributeMap.pos_item_uuid == pos_uuid)).count():
                            pos_attr_map = db.PosShowAttributeMap()
                            pos_attr_map.external_show_attribute_uuid = exsam_uuid
                            pos_attr_map.pos_item_uuid = pos_uuid
                            db.Session.add(pos_attr_map)

            db.Session.commit()
        except Exception:
            logging.error('Error adding/updating POS Session Attributes for device type [%s]' % pos_device_type, exc_info=True)

    def remove_pos_items(self, pos_uuids, pos_device_uuid = None):
        logging.info('Deleting POS Sessions. POS UUID: [%s]' % ', '.join(pos_uuids))
        schedules_to_delete = []
        for id_chunk in sqlite_chunk(pos_uuids):
            for schedule in db.Session.query(db.Schedule).filter(and_(db.Schedule.pos_id.in_(id_chunk), db.Schedule.device_schedule_id != None)).all():
                schedule.pos_id = None
                schedules_to_delete.append(schedule.uuid)

        ext_title_map_uuids = set()
        for id_chunk in sqlite_chunk(pos_uuids):
            pos_items = db.Session.query(db.POSItem).filter(db.POSItem.uuid.in_(id_chunk))
            for pos_item in pos_items:
                if pos_item.external_title_map_uuid:
                    ext_title_map_uuids.add(pos_item.external_title_map_uuid)

            pos_items.delete('fetch')

        screen_ids = set()
        for screen_id in db.Session.query(db.POSItem).values(db.POSItem.screen_identifier):
            screen_ids.add(screen_id.screen_identifier)

        db.Session.query(db.ExternalDeviceMap).filter(and_(db.ExternalDeviceMap.source == pos_device_uuid, not_(db.ExternalDeviceMap.external_id.in_(screen_ids)))).delete(False)
        if ext_title_map_uuids:
            ext_title_maps = db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.uuid.in_(ext_title_map_uuids), db.ExternalTitleMap.title_uuid == None)).all()
            title_maps_to_delete = self.core.title_service.get_title_maps_to_delete(ext_title_maps, 'pos')
            if title_maps_to_delete:
                db.Session.query(db.ExternalTitleMap).filter(db.ExternalTitleMap.uuid.in_(title_maps_to_delete)).delete(False)
                db.Session.commit()
        return schedules_to_delete

    def _add_pos_item(self, pos_dictionary, source):
        pos_item = db.POSItem(uuid=str(uuid_.uuid4()), external_id=pos_dictionary.get('id', None), screen_identifier=pos_dictionary.get('screen_identifier', None), complex_identifier=pos_dictionary.get('complex_identifier', None), start=pos_dictionary.get('start', None), end=pos_dictionary.get('end', None), source_start=pos_dictionary.get('start', None), week_number=helper_methods.week_number(pos_dictionary.get('start', None).year, pos_dictionary.get('start', None).month, pos_dictionary.get('start', None).day), overall_duration=pos_dictionary.get('overall_duration', None), feature_title=pos_dictionary.get('feature_title', None), feature_id=pos_dictionary.get('feature_id', None), feature_duration=pos_dictionary.get('feature_duration', None), seats_available=pos_dictionary.get('seats_available', None), seats_sold=pos_dictionary.get('seats_sold', None), print_number=pos_dictionary.get('print_number', None), rating=pos_dictionary.get('rating', None), external_title_map_uuid=pos_dictionary.get('external_title_map_uuid', None), state='unassigned', message=_('POS Session has not been assigned to a Playlist/Placeholder'), description=pos_dictionary.get('description', None), device_uuid=pos_dictionary.get('device_uuid', None))
        db.Session.add(pos_item)
        pos_item_dict = pos_item.to_dict(source=source)
        cherrypy.engine.publish('ccpush', 'pos_save', pos_item_dict)
        return pos_item

    def _update_pos_item(self, db_pos_item, pos_dictionary):
        updated = False
        updated_fields = []
        resync_necessary = False
        if pos_dictionary.get('session_attributes', None):
            attributes = set([ attr.strip() for attr in pos_dictionary['session_attributes'].lower().split(',') ])
            current = [ attr.external_id for attr in db_pos_item.ex_show_attributes ]
            for attribute in attributes:
                if attribute not in current:
                    updated_fields.append('show_attributes')
                    resync_necessary = True
                    updated = True

        for key in ['print_number',
         'overall_duration',
         'feature_duration',
         'seats_available',
         'seats_sold']:
            if pos_dictionary.get(key, False):
                if getattr(db_pos_item, key) is None or int(getattr(db_pos_item, key)) != int(pos_dictionary[key]):
                    setattr(db_pos_item, key, int(pos_dictionary[key]))
                    updated_fields.append(key)
                    updated = True
                    if key not in ('seats_available', 'seats_sold'):
                        resync_necessary = True

        if resync_necessary and pos_dictionary.get('start') > datetime.now() + timedelta(minutes=cfg.core_auto_schedule_resync_gap_minutes()):
            if db_pos_item.state != 'deleted':
                db_pos_item.modified = True
                db_pos_item.set_modified()
        if db_pos_item.state != 'deleted':
            cherrypy.engine.publish('ccpush', 'pos_save', db_pos_item.to_dict())
        if len(updated_fields) == 0:
            message = _('No Sessions have been updated')
        else:
            message = _('Updated Session Information: ')
            for field in updated_fields:
                message = message + '[' + field + '] '

        return (updated, message)

    def remove_pos_device_sessions(self, pos_device_uuid, pos_device_type):
        pos_items = db.Session.query(db.POSItem).filter(db.POSItem.device_uuid == pos_device_uuid).all()
        pos_items_chunks = [ pos_items[x:x + 999] for x in xrange(0, len(pos_items), 999) ]
        for chunk in pos_items_chunks:
            db.Session.query(db.PosShowAttributeMap).filter(db.PosShowAttributeMap.pos_item_uuid.in_([ p.uuid for p in chunk ])).delete(False)

        for pos_item in pos_items:
            associated_schedules = db.Session.query(db.Schedule).filter(db.Schedule.pos_id == pos_item.uuid).all()
            for schedule in associated_schedules:
                if pos_item.state == 'unassigned':
                    self.core.schedule_validation.remove_validation(schedule)
                    db.Session.delete(schedule)
                else:
                    schedule.pos_duration = None
                    schedule.pos_id = None
                    schedule.type = 'manual'

            db.Session.delete(pos_item)

        external_device_maps = db.Session.query(db.ExternalDeviceMap).filter(db.ExternalDeviceMap.source == pos_device_uuid).all()
        for map in external_device_maps:
            db.Session.delete(map)

        db.Session.query(db.ExternalTitleMap).filter(and_(db.ExternalTitleMap.source == pos_device_type, db.ExternalTitleMap.title_uuid == None)).delete(False)
        db.Session.commit()
        self.pos_sync_error = None
        cherrypy.engine.publish('queue_schedule_sync')
        return

    def reset_pos(self, pos_device_uuid, screen_identifiers = []):
        log_this = 'Resetting POS schedules for POS device [%s] on Screens %s' % (pos_device_uuid, str(screen_identifiers))
        logging.info(log_this)
        audit_log('Resetting POS schedules for POS device {device:device_uuid} on Screens %s ' % str(screen_identifiers), meta={'device': pos_device_uuid}, tags=['pos', 'sync'])
        pos_items = db.Session.query(db.POSItem).filter(and_(db.POSItem.device_uuid == pos_device_uuid, or_(db.POSItem.screen_identifier.in_(screen_identifiers), len(screen_identifiers) == 0))).all()
        actions = {}
        for pos_item in pos_items:
            associated_schedules = db.Session.query(db.Schedule).filter(db.Schedule.pos_id == pos_item.uuid).all()
            for schedule in associated_schedules:
                if pos_item.state == 'unassigned':
                    self.core.schedule_validation.remove_validation(schedule)
                    db.Session.delete(schedule)
                else:
                    action_id = self.core._action(self.core.devices[schedule.device_uuid].scheduling_delete_helper, schedule.uuid)
                    if schedule.device_uuid not in actions:
                        actions[schedule.device_uuid] = []
                    actions[schedule.device_uuid].append(action_id)
                    pos_item.modified = True

        for device_id in actions:
            iterations = 0
            device = self.core.devices[device_id]
            while len(actions[device_id]) > 0 and iterations < 180:
                actions_copy = actions[device_id][:]
                for action in actions_copy:
                    if action in device.messages:
                        actions[device_id].remove(action)

                iterations = iterations + 1

        db.Session.commit()
        cherrypy.engine.publish('queue_schedule_sync')

    def update_screen_config(self):
        self.pos_device_map = {}
        self.pos_screen_map = {}
        self.pos_identifier_map = {}
        screens = db.Session.query(db.Screen).all()
        devices = db.Session.query(db.Device).all()
        for device in devices:
            for screen in screens:
                if device.screen_uuid == screen.uuid and device.uuid in self.core.devices and isinstance(self.core.devices[device.uuid], Playback):
                    screen_identifier = screen.identifier
                    self.pos_device_map[screen_identifier] = {'id': device.uuid,
                     'enabled': device.enabled}
                    self.pos_screen_map[screen_identifier] = screen.uuid
                    self.pos_identifier_map[device.uuid] = screen_identifier

    def acknowledge_pos_resync(self):
        self.pos_latest_resync = {}
        return True

    def get_complex_identifiers(self):
        from_config = [ id.strip().decode('utf8') for id in cfg.pos_cinema_identifier.get().split(',') ]
        for device_uuid, device in self.core.devices.iteritems():
            if isinstance(device, POS):
                from_config.append(device_uuid)

        return from_config
# okay decompyling ./core/services/pos_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:54 CST
