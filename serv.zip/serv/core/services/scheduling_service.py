# 2017.08.13 21:50:54 CST
# Embedded file name: build\bdist.win32\egg\serv\core\services\scheduling_service.py
from datetime import datetime, timedelta
from time import time, sleep
from serv.lib.utilities import date_utils
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.core.devices.base.scheduling import Scheduling
from serv.lib.utilities.helper_methods import audit_log
from serv.core.services.base_service import Service
from serv.storage.database.primary import database as db
from sqlalchemy.orm import subqueryload, joinedload
from sqlalchemy.sql.expression import and_
import cherrypy
import ujson as json
import logging

class SchedulingService(Service):

    @db.close_session
    def delete(self, schedule_uuids, deleted_timestamp = None, sync_schedules = True, remove_database_schedule = True):
        messages = []
        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.deleted == False, db.Schedule.uuid.in_(schedule_uuids)))
        for schedule in schedules:
            if schedule.device_uuid is not None:
                audit_log('Schedule deleted: {schedule:schedule} at {time:timestamp} from {device:device_uuid}', meta={'device': schedule.device_uuid,
                 'schedule': {'uuid': schedule.uuid,
                              'display_name': schedule.display_name},
                 'time': schedule.start_timestamp}, tags=['schedule', 'delete'])
                if schedule.device_uuid in self.core.devices:
                    messages.append({'type': 'action',
                     'message': _('Deleting schedule on %s') % self.core.get_pretty_name(schedule.device_uuid),
                     'action_id': self._action(self.core.devices[schedule.device_uuid].scheduling_delete_helper, schedule.uuid, deleted_timestamp, remove_database_schedule),
                     'device_id': schedule.device_uuid,
                     'schedule_uuid': schedule.uuid})
                else:
                    schedule.mark_deleted(deleted_timestamp)
                    messages.append({'type': 'success',
                     'message': _('Schedule has been removed from %s') % self.core.get_pretty_name(schedule.device_uuid),
                     'device_id': schedule.device_uuid,
                     'schedule_uuid': schedule.uuid})

        try:
            db.Session.commit()
        except Exception as ex:
            logging.error('Error deleting the schedules [%s]' % str(schedule_uuids), exc_info=True)
            for message in messages:
                if message['type'] == 'success':
                    message['type'] = 'error'
                    message['message'] = _('Schedule failed')

        if sync_schedules:
            for message in messages:
                device = self.core.devices[message['device_id']]
                iterations = 0
                while iterations < 6:
                    if device.messages and message['action_id'] in device.messages:
                        break
                    sleep(0.5)
                    iterations = iterations + 1
                else:
                    logging.info('Queueing schedule sync before schedules have deleted')

            cherrypy.engine.publish('queue_schedule_sync')
        return messages

    @db.close_session
    def reschedule(self, start_time = None, end_time = None, screen_uuids = [], schedule_uuids = [], placeholders = [], pack_uuids = [], publish = True):
        output = {'data': {},
         'messages': []}
        reschedule_these = {}
        schedules = db.Session.query(db.Schedule).filter(and_(db.Schedule.is_template == True, db.Schedule.pos_id == None, db.Schedule.start_timestamp > time() + cfg.core_auto_schedule_resync_gap_minutes.get() * 60))
        if schedule_uuids:
            schedules = schedules.filter(db.Schedule.uuid.in_(schedule_uuids))
        else:
            if start_time:
                schedules = schedules.filter(db.Schedule.start_timestamp > start_time)
            if end_time:
                schedules = schedules.filter(db.Schedule.end_timestamp < end_time)
            if screen_uuids:
                schedules = schedules.filter(db.Schedule.screen_uuid.in_(screen_uuids))
        for schedule in schedules:
            if placeholders:
                schedule_dict = schedule.to_dict()
                placeholder_match = False
                if schedule_dict['templating_issues']:
                    for templating_issue in schedule_dict['templating_issues']:
                        if templating_issue['placeholder_uuid'] in placeholders:
                            placeholder_match = True
                            break

                if placeholder_match:
                    reschedule_these[schedule.uuid] = {'title': schedule.display_name,
                     'stamp': schedule.start_timestamp,
                     'device': schedule.device_uuid}
            else:
                reschedule_these[schedule.uuid] = {'title': schedule.display_name,
                 'stamp': schedule.start_timestamp,
                 'device': schedule.device_uuid}

        if pack_uuids:
            for pack_uuid in pack_uuids:
                scheds = db.Session.query(db.Schedule).filter(and_(db.Schedule.is_template == True, db.Schedule.pos_id == None, db.Schedule.start_timestamp > time() + cfg.core_auto_schedule_resync_gap_minutes.get() * 60, db.Schedule.templating_issues.like('%' + pack_uuid + '%')))
                for schedule in scheds:
                    if schedule.uuid not in reschedule_these:
                        reschedule_these[schedule.uuid] = {'title': schedule.display_name,
                         'stamp': schedule.start_timestamp,
                         'device': schedule.device_uuid}

        with self.core.schedule_lock:
            self.core.schedule_synchroniser.manual_reschedule_list = reschedule_these
        if publish:
            cherrypy.engine.publish('queue_schedule_sync')
        logging.info(str(len(reschedule_these)) + ' Manual schedule(s) marked for re-syncing.')
        output['messages'].append({'type': 'success',
         'message': _('%s Schedule(s) marked for re-scheduling') % len(reschedule_these)})
        output['data']['count'] = len(reschedule_these)
        return output

    def schedule(self, start_time = None, end_time = None, device_uuids = [], schedule_uuids = [], full_validation = False, information_requested = [], include_show_end = True, include_deleted = False, ignore_time = False):
        schedule_details = {}
        schedules = db.Session.query(db.Schedule)
        if not ignore_time:
            if not start_time:
                start_time = datetime.now().strftime('%Y-%m-%d %H:%M')
            if not end_time:
                end_time = (datetime.now() + timedelta(365)).strftime('%Y-%m-%d %H:%M')
            start_timestamp = date_utils.parse_date(start_time)
            end_timestamp = date_utils.parse_date(end_time)
            if include_show_end:
                schedules = schedules.filter(and_(db.Schedule.end_timestamp >= start_timestamp, db.Schedule.start_timestamp <= end_timestamp))
            else:
                schedules = schedules.filter(and_(db.Schedule.start_timestamp >= start_timestamp, db.Schedule.start_timestamp <= end_timestamp))
        if not include_deleted:
            schedules = schedules.filter(db.Schedule.deleted == False)
        device_uuids, device_errors = self._get_devices(device_uuids)
        if len(device_uuids) > 0:
            schedules = schedules.filter(db.Schedule.device_uuid.in_(device_uuids))
        if len(schedule_uuids) > 0:
            schedules = schedules.filter(db.Schedule.uuid.in_(schedule_uuids))
        schedules = schedules.options(joinedload('pos'), subqueryload('pos.ex_show_attributes'))
        automations = cherrypy.core.automation_service.get_automation_configuration()
        for schedule in schedules:
            if not schedule_uuids or schedule.uuid in schedule_uuids:
                temp_issues = []
                if schedule.templating_issues:
                    temp_issues = json.loads(schedule.templating_issues)
                schedule_info = {'uuid': schedule.uuid,
                 'display_name': schedule.display_name,
                 'screen_uuid': schedule.screen_uuid,
                 'duration': schedule.end_timestamp - schedule.start_timestamp,
                 'start_timestamp': schedule.start_timestamp,
                 'start_time': datetime.fromtimestamp(schedule.start_timestamp).strftime('%H:%M:%S'),
                 'start_date': datetime.fromtimestamp(schedule.start_timestamp).strftime('%Y-%m-%d'),
                 'end_timestamp': schedule.end_timestamp,
                 'end_date': datetime.fromtimestamp(schedule.end_timestamp).strftime('%Y-%m-%d'),
                 'end_time': datetime.fromtimestamp(schedule.end_timestamp).strftime('%H:%M:%S'),
                 'type': schedule.type,
                 'created': schedule.created,
                 'last_modified': schedule.last_modified,
                 'source_playlist_uuid': schedule.source_playlist_uuid,
                 'content_issue': False,
                 'playlist_issue': False,
                 'kdm_issue': False,
                 'templating_issues': temp_issues,
                 'deleted': schedule.deleted,
                 'published_show_time': schedule.published_show_time}
                if not information_requested or 'device_information' in information_requested:
                    if schedule.device_uuid is not None:
                        schedule_info['device_information'] = {'device_uuid': schedule.device_uuid,
                         'device_schedule_id': schedule.device_schedule_id,
                         'device_playlist_uuid': schedule.device_playlist_uuid,
                         'device_playlist_duration': schedule.device_playlist_duration}
                        validation = self.core.schedule_validation.get_validation(schedule.uuid)
                        if not validation:
                            continue
                        general_issues = validation['general_issues']
                        detailed_issues = validation['detailed_issues']
                        schedule_info['clashes'] = validation['clashes']
                        if schedule.device_playlist_uuid in self.core.devices[schedule.device_uuid].playlist_information:
                            playlist = self.core.devices[schedule.device_uuid].playlist_information[schedule.device_playlist_uuid]['playlist']
                            schedule_info.update(helper_methods.get_event_info(playlist, automations))
                        for error_type, is_error in general_issues.iteritems():
                            if is_error:
                                schedule_info[error_type] = True

                        if full_validation:
                            schedule_info['device_information']['issues'] = detailed_issues
                    else:
                        schedule_info['device_information'] = {'device_uuid': None,
                         'device_schedule_id': None,
                         'device_playlist_uuid': None,
                         'device_playlist_duration': None}
                if not information_requested or 'template_information' in information_requested:
                    schedule_info['template_information'] = {'source_playlist_uuid': schedule.source_playlist_uuid,
                     'print_no': schedule.print_no,
                     'is_template': schedule.is_template}
                if not information_requested or 'pos_information' in information_requested:
                    pos_item = schedule.pos
                    if pos_item:
                        if not pos_item.state == 'error':
                            if pos_item.playlist_uuid is None:
                                unassigned = pos_item.placeholder_type is None
                                show_attributes = {}
                                for attr in pos_item.show_attributes:
                                    if attr is not None:
                                        show_attributes[attr.uuid] = attr.name

                                device = self.core.devices.get(pos_item.device_uuid)
                                pos_device_enabled = None
                                if device:
                                    pos_device_enabled = device.device_configuration['enabled']
                                if unassigned and (pos_device_enabled is False or not cfg.pos_enabled.get()):
                                    continue
                                schedule_info['pos_information'] = {'pos_id': schedule.pos_id,
                                 'pos_duration': schedule.pos_duration,
                                 'pos_unassigned': unassigned,
                                 'show_attributes': show_attributes,
                                 'seats_sold': pos_item.seats_sold,
                                 'seats_available': pos_item.seats_available,
                                 'feature_title': pos_item.feature_title}
                        if not information_requested or 'placeholder_information' in information_requested:
                            schedule_info['placeholder_information'] = {'placeholder_type': schedule.placeholder_type,
                             'placeholder_duration': schedule.placeholder_duration}
                        if not information_requested or 'preshow_duration' in information_requested:
                            device = schedule.device_playlist_uuid is not None and self.core.devices[schedule.device_uuid]
                            playlist = schedule.device_playlist_uuid in device.playlist_information and device.playlist_information[schedule.device_playlist_uuid]
                            schedule_info['preshow_duration'] = playlist['preshow_duration']
                schedule_details[schedule.uuid] = schedule_info

        return (schedule_details, device_errors['messages'])

    def get_content_schedules(self, content_uuids, device_uuids = [], start_time = None, end_time = None, ids_only = False):
        schedule_device_uuids = []
        affected_schedules_by_content_id = {}
        messages = []
        if cfg.core_check_schedules_on_content_delete():
            for device in device_uuids:
                if self.core.devices[device].device_status['confirmed'] == True and isinstance(self.core.devices[device], Scheduling):
                    schedule_device_uuids.append(device)

            playlists, device_errors = self.core.playlist_service.playlist(device_ids=schedule_device_uuids)
            schedules, device_errors2 = self.schedule(start_time=start_time, end_time=end_time, device_uuids=schedule_device_uuids)
            messages += device_errors
            messages += device_errors2
            affected_playlists = {}
            for device_id in playlists:
                for playlist_id in playlists[device_id]:
                    myplaylist = playlists[device_id][playlist_id]['playlist']
                    cpls = [ event['cpl_id'] for event in myplaylist['events'] if 'cpl_id' in event ]
                    for content_id in content_uuids:
                        if content_id in cpls:
                            if content_id not in affected_playlists.setdefault(playlist_id, []):
                                affected_playlists[playlist_id].append(content_id)

            if len(affected_playlists):
                scheduled_playlists = [ schedules[item]['device_information']['device_playlist_uuid'] for item in schedules ]
                for sched_item in schedules:
                    playlist_id = schedules[sched_item]['device_information']['device_playlist_uuid']
                    if playlist_id in affected_playlists:
                        for content_id in affected_playlists[playlist_id]:
                            affected_schedules_by_content_id.setdefault(content_id, []).append(ids_only and sched_item or schedules[sched_item])

        return_values = {'data': affected_schedules_by_content_id,
         'messages': messages}
        return return_values

    def get_playlist_schedules(self, playlist_uuids, device_uuids = [], start_time = None, end_time = None, ids_only = False):
        messages = []
        schedules, device_errors = self.schedule(start_time=start_time, end_time=end_time, device_uuids=device_uuids)
        affected_schedules_by_playlist_id = {}
        for item in schedules:
            playlist_id = schedules[item]['device_information']['device_playlist_uuid']
            if playlist_id in playlist_uuids:
                affected_schedules_by_playlist_id.setdefault(playlist_id, []).append(ids_only and item or schedules[item])

        messages += device_errors
        return_values = {'data': affected_schedules_by_playlist_id,
         'messages': messages}
        return return_values

    def create(self, schedule_dicts, sync_schedules = True):
        messages = []
        for schedule_dict in schedule_dicts:
            playlist_uuid = schedule_dict.get('playlist_id', None)
            if not isinstance(self.core.devices[schedule_dict['device_id']], Scheduling):
                messages.append({'type': 'error',
                 'message': _('Device [%s] cannot accept playlist schedules.') % schedule_dict['device_id'],
                 'device_id': schedule_dict['device_id'],
                 'playlist_uuid': playlist_uuid})
            else:
                schedule_dict['type'] = 'manual'
                if schedule_dict.get('pos_id'):
                    schedule_dict['type'] = 'pos'
                schedule_dict['start_time'] = date_utils.parse_date(schedule_dict['start_time'])
                if playlist_uuid:
                    msg = _('Scheduling %s on %s') % (self.core.devices[schedule_dict['device_id']].get_playlist_display(schedule_dict['playlist_id']), self.core.get_pretty_name(schedule_dict['device_id']))
                else:
                    msg = _('Scheduling playlist on %s') % self.core.get_pretty_name(schedule_dict['device_id'])
                if schedule_dict['playlist_type'] in ('template', 'title'):
                    db_playlist_item = db.GeneratedPlaylist(uuid=playlist_uuid, start_timestamp=schedule_dict['start_time'])
                    db.Session.add(db_playlist_item)
                    schedule_dict['is_template'] = True
                audit_log('Schedule created: {schedule:schedule} on {device:device_uuid} at {time:timestamp}', meta={'device': schedule_dict['device_id'],
                 'schedule': schedule_dict,
                 'time': schedule_dict['start_time']}, tags=['schedule', 'save'])
                messages.append({'type': 'action',
                 'message': msg,
                 'action_id': self._action(self.core.devices[schedule_dict['device_id']].scheduling_add_helper, schedule_dict),
                 'device_id': schedule_dict['device_id'],
                 'playlist_uuid': playlist_uuid})

        if sync_schedules:
            for message in messages:
                device = self.core.devices[message['device_id']]
                iterations = 0
                while iterations < 6:
                    if device.messages and message['action_id'] in device.messages:
                        break
                    sleep(0.5)
                    iterations = iterations + 1
                else:
                    logging.info('Queueing schedule sync before schedules have been added')

            cherrypy.engine.publish('queue_schedule_sync')
        return messages

    def last_modified(self, deleted = False):
        """
        Returns a list of all schedule last_modified timestamps stored on this core
        """
        schedules = db.Session.query(db.Schedule).filter(db.Schedule.deleted == deleted)
        return dict(((schedule.uuid, schedule.last_modified) for schedule in schedules))

    def sync_status(self, short = False):
        """
        Returns the current status of the schedule syncing thread
        """
        if short:
            return self.core.schedule_synchroniser.short_status()
        else:
            return self.core.schedule_synchroniser.status()
# okay decompyling ./core/services/scheduling_service.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:55 CST
