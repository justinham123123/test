# 2017.08.13 21:51:34 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\wsworker.py
import logging
import cherrypy
from serv.configuration import cfg
from serv.core import VERSION_STRING
from serv.storage.database.primary import database as db
from serv.core.websockets.dispatch import Dispatcher
from serv.core.websockets.handler import EventHandler
from serv.core.websockets.events.manager import EventManager
from serv.core.websockets.transport import ConnectionManager, Transport, InvalidEvent
from serv.core.websockets.com.buffer import MessageBuffer
from serv.core.websockets.com.packet import SerializerFactory
CONFIG_SYNCED_EVENT = set(['device_uuid_dict',
 'device_information',
 'screen_uuid_dict',
 'screen_information',
 'external_device_mapping',
 'tms_info',
 'introduce',
 'ssl_hack',
 'flmx_sync'])

class WSWorker(Dispatcher, EventHandler):

    def __init__(self, config):
        super(WSWorker, self).__init__()
        self.config = config
        self.event_manager = None
        self.transports = ConnectionManager()
        self.buffers = MessageBuffer(self._handle_ccpush, {'pos_save': {'size': 500,
                      'interval': 5},
         'content_validation': {'size': 500,
                                'interval': 5},
         'schedule_error_list': {'size': 250,
                                 'interval': 5},
         'automation_update': {'size': 100,
                               'interval': 5},
         'content_update': {'size': 100,
                            'interval': 5},
         'device_information_update': {'size': 50,
                                       'interval': 5},
         'device_monitoring_update': {'size': 50,
                                      'interval': 1},
         'pos_delete': {'size': 25,
                        'interval': 5},
         'schedule_delete': {'size': 25,
                             'interval': 5},
         'kdm_dispatch': {'size': 25,
                          'interval': 5},
         'kdm_deleted': {'size': 25,
                         'interval': 5},
         'kdm_error': {'size': 25,
                       'interval': 5},
         'kdm_update': {'size': 25,
                        'interval': 5},
         'task_done': {'size': 25,
                       'interval': 5},
         'tms_error': {'size': 10,
                       'interval': 60}}, enabled=cfg.wsw_buffering())
        self.create_queue('in', self._handle_in_event)
        self.create_queue('out', self._handle_out_event)
        cherrypy.engine.subscribe('device_load', self.start, 80)
        cherrypy.engine.subscribe('stop', self.stop, 0)
        cherrypy.engine.subscribe('ccpush', self._handle_ccpush)
        cherrypy.engine.subscribe('cclisten', self._handle_cclisten)
        self.on('denied', self._denied)
        self.on('approved', self._approved)
        self.on('continue', self._approved)
        self.on('config_synced', self._config_synced)
        return

    def start(self):
        self.event_manager = EventManager()
        self.event_manager.start_workers()
        self._configure_transports()
        self.transports.start()
        self.buffers.start_flush_timer()

    def stop(self):
        self.buffers.stop_flush_timer()
        self.transports.stop()
        self.event_manager.stop_workers()

    def _configure_transports(self):
        circuit_cores = self.config.get('circuit_cores')
        for circuit_core in circuit_cores:
            url = circuit_core['url']
            features = circuit_core['features']
            self.transports.add(url, Transport(url, features, self))

    def _authenticate(self, url):
        compression = self._determine_compression()
        payload = {'tms_version': VERSION_STRING,
         'compression': compression}
        if cfg.complex_id() != -1:
            payload['complex_id'] = cfg.complex_id()
        continued = self.transports[url].continued()
        event = 'continue' if continued else 'introduce'
        self.transports[url].push(event, payload, bypass=True)
        if compression != SerializerFactory.default:
            self.transports[url].upgrade(compression)

    def _determine_compression(self):
        if SerializerFactory.is_available(cfg.wsw_compression()):
            return cfg.wsw_compression()
        else:
            logging.error('%s-compression not available, falling back to %s', cfg.wsw_compression(), SerializerFactory.default)
            return SerializerFactory.default

    @cherrypy.expose
    @cherrypy.tools.json_out()
    def index(self):
        return {'version': '0.0.1'}

    def connection_opened(self, url):
        if not self.transports[url].continued():
            self.buffers.clear()
        self._authenticate(url)

    def connection_closed(self, url, code, reason):
        pass

    def connection_received_message(self, url, payload):
        payload['url'] = url
        self.dispatch('in', payload)

    def _approved(self, payload):
        url = payload['url']
        token = payload['data']['token']
        self.transports[url].state_approved(token)

    def _denied(self, payload):
        logging.warning('This TMS is not configured on Producer. Closing socket.')
        url = payload['url']
        self.transports[url].state_denied()

    def _config_synced(self, payload):
        """
        Handles `config_synced` event from Circuit Core.
        
        Sent once Circuit Core has all configuration information (devices, screens, etc)
        """
        url = payload['url']
        self.transports[url].state_config_synced()

    def _handle_cclisten(self, event, func):
        self.on(event, func)

    def _handle_ccpush(self, event, data = None, buffered = False, target = None):
        if not buffered and event in self.buffers:
            self.buffers.add(event, data)
        else:
            self.dispatch('out', {'event': event,
             'data': data,
             'target': target})

    @db.close_session
    def _handle_in_event(self, payload):
        """Take job from the in-queue and notify event listeners"""
        event = payload['type']
        data = payload['data']
        logging.debug('Trigger incoming event "%s"', event)
        if self.handles_event(event):
            self.trigger(event, payload)
        if 'task_uuid' in data:
            self.event_manager.dispatch_task(event, task=data)
        if 'request_uuid' in data:
            self.event_manager.trigger(event, data)

    def _handle_out_event(self, job):
        """Take job from the out-queue and send it to circuit core"""
        event = job.get('event')
        data = job.get('data')
        target = job.get('target')
        logging.debug('Push outgoing event "%s"', event)
        try:
            if target:
                self.transports[target].push(event, data)
            else:
                self.transports.push(event, data)
        except InvalidEvent:
            logging.warning('Discarding invalid event "%s"', event)
        except:
            logging.exception('Error during push')
# okay decompyling ./core/websockets/wsworker.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:34 CST
