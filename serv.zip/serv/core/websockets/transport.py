# 2017.08.13 21:51:32 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\transport.py
import socket
import time
import logging
from cherrypy.process.plugins import BackgroundTask
from serv.configuration import cfg
from serv.core.websockets.com.packet import SerializerFactory
from serv.core.websockets.log import LogStorage, LogReader, LogWriter, Log, FlushError, ConflictError
from serv.core.websockets.events.event_feature_configuration import event_feature_sets, product_features
from serv.core.websockets.connection import Connection, ConnectionState
PHASE1_EVENTS = set(['device_uuid_dict',
 'device_information',
 'screen_uuid_dict',
 'screen_information',
 'external_device_mapping',
 'tms_info',
 'introduce',
 'continue',
 'ssl_hack',
 'flmx_sync',
 'heartbeat'])

class InvalidEvent(Exception):
    pass


class FeaturesetFilter(object):
    """
    Holds featureset configuration that defines which events
    are allowed for a specific circuit core connection.
    """

    def __init__(self, features):
        self.feature_set = set()
        self._initialize_feature_configuration(features)

    def _initialize_feature_configuration(self, features):
        for feature in features:
            if feature in product_features:
                [ self.feature_set.update(set(event_feature_sets[f])) for f in product_features[feature] ]
            elif feature in event_feature_sets:
                self.feature_set.update(set(event_feature_sets[feature]))
            else:
                logging.warning('Configured feature {0} is not valid'.format(feature))

    def has(self, feature):
        return feature in self.feature_set


class Logger(LogWriter):
    """
    Writes messages to the log and handles retention limit exception.
    """

    def __init__(self, connection, *args, **kwargs):
        super(Logger, self).__init__(*args, **kwargs)
        self.connection = connection

    def _retention_reached(self):
        logging.warning('Resetting message log, retention limit reached!')
        self.connection.state.reset()
        self.log.flush()


class Pusher(LogReader):
    """
    Reads the log and pushes items read to circuit core.
    """

    def __init__(self, connection, *args, **kwargs):
        super(Pusher, self).__init__(*args, **kwargs)
        self.connection = connection

    def can_flush(self):
        return self.connection.state == ConnectionState.FLUSH

    def flush(self, buffer):
        if not self.can_flush():
            raise FlushError()
        logging.debug('Sending %d messages from log', len(buffer))
        try:
            self.connection.push_all(buffer)
        except (socket.error, RuntimeError):
            logging.exception('Push failed')
            raise FlushError()


class Transport(object):
    """
    Deals with message transport up to circuit core.
    Manages a circuit core connection with a persistent log.
    Decides when to send data directly via the connection
    or when to write to the log for a postponed send.
    """

    def __init__(self, url, features, manager):
        self.manager = manager
        self.filter = FeaturesetFilter(features)
        self.connection = Connection(url, self)
        self.storage = LogStorage('messagelog_%s' % abs(hash(url)), 'fs')
        self.storage.pack()
        self.log = Log(self.storage)
        self.logger = Logger(self.connection, self.storage, cfg.wsw_retention())
        self.pusher = Pusher(self.connection, self.storage, cfg.wsw_retention())
        self.heartbeat_task = BackgroundTask(60, self._send_heartbeat)
        self.maintenance_task = BackgroundTask(60, self._maintenance)
        self.serializer = SerializerFactory.create(SerializerFactory.default)
        self.token = None
        return

    def start(self):
        self.storage.setup()
        self.log.open()
        self.logger.start()
        self.pusher.start()
        self.connection.start()
        self.heartbeat_task.start()
        self.maintenance_task.start()

    def stop(self):
        self.maintenance_task.cancel()
        self.heartbeat_task.cancel()
        self.logger.stop()
        self.pusher.stop()
        self.logger.join()
        self.pusher.join()
        self.log.close()
        self.storage.close()
        self.connection.close()
        self.connection.stop()
        self.connection.join()

    def push(self, event, data, bypass = False):
        """
        Push an event with data up to circuit core.
        Data is serialized using the configured serializer.
        :param str event: Name of event
        :param dict data: Data to serialize and send
        :param bool bypass: Whether to bypass the message log
        """
        if self._event_allowed(event):
            logging.debug('Push event "%s" [%s]', event, self.connection.url)
            message = self._serialize_message(event, data)
            if bypass:
                self._send(message)
            else:
                self._log_or_send(message)
        else:
            logging.warning('Event "%s" not allowed (config_synced=%s, token=%s, filter_has=%s) [%s]', event, self.config_synced, self.token, self.filter.has(event), self.connection.url)
            raise InvalidEvent(event)

    def _event_allowed(self, event):
        """Decides whether event is allowed to be pushed to circuit core."""
        return event in PHASE1_EVENTS or self.config_synced and self.token and self.filter.has(event)

    def _serialize_message(self, event, data):
        """Serialize ready-to-send using configured serializer."""
        return self.serializer.serialize({'token': self.token,
         'type': event,
         'data': data or dict()})[0]

    def _log_or_send(self, message):
        """Decides whether message can be sent or has to be logged."""
        state = self.connection.state
        if state.any(ConnectionState.CONNECTED1, ConnectionState.APPROVED, ConnectionState.PHASE2, ConnectionState.CONTINUED):
            self._send(message)
        elif state.any(ConnectionState.CONTINUE, ConnectionState.CONNECTED2):
            self._log(message)
        elif state == ConnectionState.FLUSH:
            if self._backlog():
                self._log(message)
            else:
                state.flushed()
                self._send(message)
        else:
            logging.info('Not connected, dropping message [%s]', self.connection.url)

    def _backlog(self):
        """Check whether there are backlog items that have not been flushed."""
        try:
            self.log.sync()
            empty = self.log.empty()
            return not empty or self.logger.dirty()
        except ConflictError:
            return True

    def _log(self, message):
        """Writes message to tog."""
        logging.debug('Writing message to log [%s]', self.connection.url)
        self.logger.put(message)

    def _send(self, message):
        """Send message via connection."""
        logging.debug('Sending message via connection [%s]', self.connection.url)
        try:
            self.connection.push(message)
        except socket.error:
            logging.warning('Socket error during push, terminating connection')
            self.connection.terminate()
            self._log(message)

    @property
    def config_synced(self):
        """
        Whether the connection is is phase 2 (received config_synced event).
        """
        return self.connection.state.any(ConnectionState.PHASE2, ConnectionState.CONTINUE, ConnectionState.CONNECTED2, ConnectionState.FLUSH, ConnectionState.CONTINUED)

    def upgrade(self, compression):
        """Upgrades the serializer to a certain compression algorithm."""
        self.serializer = SerializerFactory.create(compression)
        logging.info('Upgraded to %s-compression', compression)

    def reset(self):
        """
        Resets the connection transport on a closed connection.
        It only has to be reset if the connection did not make it to phase 2.
        Since in this case we have to go through phase 1 again, thus reset.
        """
        if self.connection.state.any(ConnectionState.CONNECTED1, ConnectionState.APPROVED):
            self.token = None
        return

    def close(self):
        """Closes the connection to circuit core."""
        self.connection.close()

    def continued(self):
        """
        Returns True if the connection is in state continued.
        This means was connected, went into phase 2, connection dropped,
        then reconnected.
        """
        return self.connection.continued()

    def _send_heartbeat(self):
        try:
            if self.connection.connected():
                logging.debug('Sending heartbeat [%s]', self.connection.url)
                self.push('heartbeat', {'timestamp': time.time()}, bypass=True)
            else:
                logging.debug('Skipping heartbeat, not connected [%s]', self.connection.url)
        except Exception:
            logging.exception('Exception while pushing heartbeat, ignoring')
        except:
            logging.exception('Fatal')
            raise

    def _maintenance(self):
        try:
            logging.info('Running message log DB maintenance [%s]', self.connection.url)
            log = Log(self.storage)
            log.open()
            if log.empty():
                logging.info('Running message log pack [%s]', self.connection.url)
                self.storage.pack()
            log.rollback()
            log.close()
        except Exception:
            logging.exception('Exception during log maintenance')
        except:
            logging.exception('Fatal')
            raise

    def state_approved(self, token):
        """Called when the client has been approved by circuit core."""
        self.token = token
        self.connection.state_approved()

    def state_denied(self):
        """Called when the client has been denied by circuit core."""
        self.connection.state_denied()

    def state_config_synced(self):
        """
        Handler for config synced event coming from circuit core,
        which marks the start of sync phase 2.
        """
        self.connection.state_config_synced()

    def connection_opened(self):
        self.serializer = SerializerFactory.create(SerializerFactory.default)
        self.manager.connection_opened(self.connection.url)

    def connection_closed(self, code, reason):
        self.reset()
        self.manager.connection_closed(self.connection.url, code, reason)

    def connection_ponged(self, pong):
        pass

    def connection_received_message(self, message):
        payload = self.serializer.deserialize(message)[0]
        self.manager.connection_received_message(self.connection.url, payload)


class ConnectionManager(object):
    """
    Manages a collection of transport objects.
    Each transport object is responsible for managing
    how and when data gets pushed up to circuit core.
    """

    def __init__(self):
        self.transports = {}

    def add(self, url, transport):
        raise url not in self.transports or AssertionError
        self.transports[url] = transport

    def start(self):
        for transport in self.transports.itervalues():
            transport.start()

    def stop(self):
        for transport in self.transports.itervalues():
            transport.stop()

    def push(self, event, data):
        """
        Push event with data via all configured transports.
        :param str event: Name of event
        :param dict data: Data to pack and send
        """
        for transport in self.transports.itervalues():
            transport.push(event, data)

    def __getitem__(self, url):
        return self.transports.get(url)
# okay decompyling ./core/websockets/transport.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:34 CST
