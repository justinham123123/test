# 2017.08.13 21:51:21 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\com\packet.py
import zlib
import json
import ujson
import base64
import datetime
from json import JSONEncoder
try:
    import lz4
except ImportError:
    pass

class CompressionNotSupported(Exception):
    pass


class DeserializeError(Exception):
    pass


class ObjectEncoder(JSONEncoder):

    def default(self, obj):
        if isinstance(obj, set):
            return list(obj)
        if isinstance(obj, datetime.datetime) or isinstance(obj, datetime.date) or isinstance(obj, datetime.time):
            return obj.isoformat()
        return JSONEncoder.default(self, obj)


class Serializer(object):
    name = None

    def serialize(self, data):
        return data

    def deserialize(self, message):
        return message


class SerializerZLIB(Serializer):
    """
    Message format: <checksum>;<gzip_compressed_base64_string>
    """
    name = 'zlib'
    module = 'zlib'
    SEP = ';'

    def serialize(self, data_dict):
        data = json.dumps(data_dict, cls=ObjectEncoder)
        size_raw = len(bytes(data))
        checksum = zlib.adler32(data) & 4294967295L
        payload = base64.b64encode(zlib.compress(data))
        size_cpr = len(bytes(payload))
        message = self.SEP.join([str(checksum), payload])
        return (message, size_raw, size_cpr)

    def deserialize(self, message):
        checksum, payload = str(message).split(self.SEP, 1)
        size_cpr = len(bytes(payload))
        data = zlib.decompress(base64.b64decode(payload))
        size_raw = len(bytes(data))
        valid = zlib.adler32(data) & 4294967295L == int(checksum)
        if not valid:
            raise DeserializeError('Adler32 checksum mismatch')
        data = ujson.loads(data)
        return (data, size_raw, size_cpr)


class SerializerLZ4(Serializer):
    """
    Message format: <lz4_compressed_base64_string>
    """
    name = 'lz4'
    module = 'lz4'

    def _compress(self, data):
        return lz4.compress(data)

    def serialize(self, data):
        data_dump = json.dumps(data, cls=ObjectEncoder)
        size_raw = len(bytes(data_dump))
        message = base64.b64encode(self._compress(data_dump))
        size_cpr = len(bytes(message))
        return (message, size_raw, size_cpr)

    def deserialize(self, message):
        size_cpr = len(bytes(message))
        data = lz4.decompress(base64.b64decode(unicode(message)))
        size_raw = len(bytes(data))
        data = ujson.loads(data)
        return (data, size_raw, size_cpr)


class SerializerLZ4HC(SerializerLZ4):
    """
    Message format: <lz4HC_compressed_base64_string>
    """
    name = 'lz4hc'
    module = 'lz4'

    def _compress(self, data):
        return lz4.compressHC(data)


class SerializerFactory(object):
    default = SerializerZLIB.name
    available = {}
    supported = [SerializerZLIB, SerializerLZ4, SerializerLZ4HC]

    @classmethod
    def is_available(cls, name):
        return name in cls.available

    @classmethod
    def check_availability(cls):
        for impl in cls.supported:
            try:
                __import__(impl.module)
            except ImportError:
                pass
            else:
                raise issubclass(impl, Serializer) or AssertionError
                cls.available[impl.name] = impl

    @classmethod
    def create(cls, name = None):
        if not name:
            name = cls.default
            cls.available or cls.check_availability()
        try:
            raise name in cls.available or AssertionError
            handler = cls.available[name]
            return handler()
        except AssertionError:
            raise CompressionNotSupported(name)
# okay decompyling ./core/websockets/com/packet.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:22 CST
