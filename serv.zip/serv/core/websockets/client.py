# 2017.08.13 21:51:21 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\client.py
from ws4py.client.threadedclient import WebSocketClient

class Client(WebSocketClient):
    """
    WS4Py websocket client instance.
    """

    def __init__(self, connection, url, *args, **kwargs):
        super(Client, self).__init__(url, *args, **kwargs)
        self.conn = connection
        self.url = url
        self.connected = False

    def handshake_ok(self):
        self._th.start()
        self._th.join()

    def opened(self):
        self.conn.socket_opened()
        self.connected = True

    def closed(self, code, reason = None):
        self.conn.socket_closed(code, reason)
        self.connected = False

    def ponged(self, pong):
        self.conn.socket_ponged(pong)

    def received_message(self, message):
        self.conn.socket_received_message(message)
# okay decompyling ./core/websockets/client.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:21 CST
