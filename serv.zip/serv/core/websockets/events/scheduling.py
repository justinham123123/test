# 2017.08.13 21:51:27 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\scheduling.py
import cherrypy
from serv.core.websockets.com.protocols import RequestProtocol
from serv.core.websockets.handler import EventHandler
from serv.core.services.scheduling_service import SchedulingService

class SchedulingHandler(EventHandler, RequestProtocol):

    def __init__(self, *args, **kwargs):
        super(SchedulingHandler, self).__init__(*args, **kwargs)
        self.scheduling_service = SchedulingService(cherrypy.core)
        self.on('schedule_request', self.schedule_request)

    def schedule_request(self, request):
        """
        Handles a request for schedules from Circuit Core.
        """
        request_uuid = request['request_uuid']
        start_time = request['data'].get('start_time')
        end_time = request['data'].get('end_time')
        device_uuids = request['data'].get('device_uuids', [])
        schedule_uuids = request['data'].get('schedule_uuids', [])
        full_validation = request['data'].get('full_validation', False)
        schedules, device_errors = self.scheduling_service.schedule(start_time=start_time, end_time=end_time, device_uuids=device_uuids, schedule_uuids=schedule_uuids, full_validation=full_validation)
        self.push_response(request_uuid, {'schedules': schedules,
         'device_errors': device_errors})
# okay decompyling ./core/websockets/events/scheduling.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:27 CST
