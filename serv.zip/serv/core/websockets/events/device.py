# 2017.08.13 21:51:24 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\device.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.services.configuration_service import ConfigurationService

class DeviceHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(DeviceHandler, self).__init__(*args, **kwargs)
        self.configuration_service = ConfigurationService(cherrypy.core)
        self.on('device_specifications_save', self.device_specifications_save)
        self.on('device_specifications_delete', self.device_specifications_delete)

    def device_specifications_save(self, task):
        self.configuration_service.save_custom_specifications(task['task_data'])

    def device_specifications_delete(self, task):
        self.configuration_service.delete_custom_specifications(task['task_data'])
# okay decompyling ./core/websockets/events/device.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:24 CST
