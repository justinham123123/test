# 2017.08.13 21:51:26 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\monitoring.py
import cherrypy
from serv.core.websockets.com.protocols import RequestProtocol
from serv.core.websockets.handler import EventHandler
from serv.core.services.monitoring_service import MonitoringService

class MonitoringHandler(EventHandler, RequestProtocol):

    def __init__(self, *args, **kwargs):
        super(MonitoringHandler, self).__init__(*args, **kwargs)
        self.monitoring_service = MonitoringService(cherrypy.core)
        self.on('config_synced', self.monitoring_oids_save)
        self.on('monitoring_types_save', self.monitoring_types_save)
        self.on('monitoring_oids_save', self.monitoring_oids_save)
        self.on('monitoring_types_delete', self.monitoring_types_delete)
        self.on('monitoring_oids_delete', self.monitoring_oids_delete)
        self.on('monitoring_info_request', self.monitoring_info_request)
        self.on('forecast_disk_usage_request', self.forecast_disk_usage_request)

    def monitoring_types_save(self, task):
        types = task['task_data']['monitoring_types']
        self.monitoring_service.type_save(types)

    def monitoring_oids_save(self, task):
        oids = task['task_data']['monitoring_oids']
        self.monitoring_service.oid_save(oids)
        cherrypy.engine.publish('monitoring_type_update')

    def monitoring_types_delete(self, task):
        if 'monitoring_type_uuids' in task['task_data']:
            uuids = task['task_data']['monitoring_type_uuids']
            self.monitoring_service.type_delete(uuids)
        elif 'delete_default' in task['task_data']:
            delete_default = task['task_data']['delete_default']
            self.monitoring_service.type_delete([], delete_default)

    def monitoring_oids_delete(self, task):
        uuids = task['task_data']['monitoring_oid_uuids']
        self.monitoring_service.oid_delete(uuids)

    def monitoring_info_request(self, request):
        """
        Handles the request for monitoing information on a list of devices
        from Circuit Core.
        
        TODO: this is copy pasted from the api response, we should standardise 
        this so it's the same across both websockets and HTTP API.
        """
        request_uuid = request['request_uuid']
        device_ids = request['data']['device_ids']
        device_information, device_errors = self.monitoring_service.info(device_ids)
        self.push_response(request_uuid, {'data': dict([ (device_uuid, {'id': cache.get('id'),
                   'serial': cache.get('serial'),
                   'model': cache.get('model'),
                   'software_version': cache.get('software_version'),
                   'firmware_version': cache.get('firmware_version'),
                   'disk_usage': {'total_size': cache.get('storage_total'),
                                  'available': cache.get('storage_available'),
                                  'used': cache.get('storage_used')},
                   'raid_status': cache.get('raid_status', []),
                   'dnqualifiers': cache.get('dnqualifiers', []),
                   'product_certificates': cache.get('product_certificates', []),
                   'product_id': cache.get('product_id'),
                   'error_messages': cache.get('error_messages', []),
                   'last_updated': cache.last_updated}) for device_uuid, cache in device_information.iteritems() ]),
         'messages': device_errors})

    def forecast_disk_usage_request(self, request):
        """
        Handles event for Circuit Core for disk space forecasting data.
        """
        request_uuid = request['request_uuid']
        device_ids = request['data']['device_ids']
        days_to_forecast = request['data'].get('days_to_forecast')
        forecast_data, messages = self.monitoring_service.forecast_disk_usage(device_ids, days_to_forecast)
        self.push_response(request_uuid, {'data': forecast_data,
         'messages': messages})
# okay decompyling ./core/websockets/events/monitoring.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:26 CST
