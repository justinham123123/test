# 2017.08.13 21:51:27 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\projection.py
import cherrypy
from serv.core.websockets.com.protocols import RequestProtocol
from serv.core.websockets.handler import EventHandler
from serv.core.services.projection_service import ProjectionService

class ProjectionHandler(EventHandler, RequestProtocol):

    def __init__(self, *args, **kwargs):
        super(ProjectionHandler, self).__init__(*args, **kwargs)
        self.projection_service = ProjectionService(cherrypy.core)
        self.on('projection_status_request', self.projection_status_request)

    def projection_status_request(self, request):
        """
        Handles request from the current projection status of a list of 
        projectors from Circuit Core.
        """
        request_uuid = request['request_uuid']
        device_ids = request['data'].get('device_ids', [])
        projection_status, device_errors = self.projection_service.status(device_ids)
        self.push_response(request_uuid, {'projection_status': dict(((device_uuid, cache.copy()) for device_uuid, cache in projection_status.iteritems())),
         'device_errors': device_errors})
# okay decompyling ./core/websockets/events/projection.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:27 CST
