# 2017.08.13 21:51:26 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\placeholders.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.services.placeholder_service import PlaceholderService

class PlaceholdersHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(PlaceholdersHandler, self).__init__(*args, **kwargs)
        self.placeholder_service = PlaceholderService(cherrypy.core)
        self.on('placeholder_save', self.placeholder_save)
        self.on('placeholder_delete', self.placeholder_delete)

    def placeholder_save(self, task):
        placeholders = task['task_data']['placeholders']
        self.placeholder_service.save(placeholders)

    def placeholder_delete(self, task):
        placeholder_uuids = task['task_data']['placeholder_uuids']
        self.placeholder_service.delete(placeholder_uuids)
# okay decompyling ./core/websockets/events/placeholders.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:26 CST
