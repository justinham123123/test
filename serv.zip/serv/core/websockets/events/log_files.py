# 2017.08.13 21:51:25 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\log_files.py
import cherrypy
from serv.core.websockets.handler import EventHandler

class LogFileHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(LogFileHandler, self).__init__(*args, **kwargs)
        self.configuration_service = cherrypy.core.configuration
        self.log_manager = cherrypy.core.log_manager
        self.on('reparse_smpte_logs', self.reparse_smpte_logs)
        self.on('recollect_smpte_logs', self.recollect_smpte_logs)
        self.on('recollect_smpte_logs_by_uuid', self.recollect_smpte_logs_by_uuid)
        self.on('remerge_smpte_logs', self.remerge_smpte_logs)
        self.on('save_log_settings', self.handle_save_log_settings)

    def reparse_smpte_logs(self, task):
        self.log_manager.reparse_smpte_logs(**task['task_data'])

    def recollect_smpte_logs(self, task):
        self.log_manager.recollect_smpte_logs(**task['task_data'])

    def recollect_smpte_logs_by_uuid(self, task):
        self.log_manager.recollect_smpte_logs_by_uuid(**task['task_data'])

    def remerge_smpte_logs(self, task):
        self.log_manager.remerge_smpte_logs(**task['task_data'])

    def handle_save_log_settings(self, task):
        """
        Handles the `save_log_settings` event from Circuit Core.
        
        Takes the settings passed down from Circuit Core and saves them.
        """
        settings = task['task_data']
        self.configuration_service.save_log_settings(start_hours=settings['start_hours'], start_minutes=settings['start_minutes'], end_hours=settings['end_hours'], end_minutes=settings['end_minutes'], store_device_logs=settings['store_device_logs'], retry_days=settings['retry_days'], storage_limit=settings['storage_limit'])
# okay decompyling ./core/websockets/events/log_files.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:25 CST
