# 2017.08.13 21:51:28 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\events\templates.py
import cherrypy
from serv.core.websockets.handler import EventHandler
from serv.core.services.template_service import TemplateService

class TemplateHandler(EventHandler):

    def __init__(self, *args, **kwargs):
        super(TemplateHandler, self).__init__(*args, **kwargs)
        self.template_service = TemplateService(cherrypy.core)
        self.on('template_save', self.template_save)
        self.on('template_delete', self.template_delete)
        self.on('template_set_active', self.template_set_active)

    def template_save(self, task):
        template = task['task_data']
        self.template_service.save([template])

    def template_delete(self, task):
        template_uuids = task['task_data']['template_uuids']
        self.template_service.delete(template_uuids)

    def template_set_active(self, task):
        template_uuid = task['task_data']['uuid']
        self.template_service.set_active(template_uuid)
# okay decompyling ./core/websockets/events/templates.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:28 CST
