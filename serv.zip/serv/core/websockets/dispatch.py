# 2017.08.13 21:51:23 CST
# Embedded file name: build\bdist.win32\egg\serv\core\websockets\dispatch.py
import time
import Queue
import logging
import threading
import cherrypy

class Worker(threading.Thread):
    """Dispatch queue worker thread"""

    def __init__(self, dispatcher, name, queue, handler, retry):
        super(Worker, self).__init__()
        cherrypy.engine.subscribe('stop', self.stop)
        self.dispatcher = dispatcher
        self.queue_name = name
        self.queue = queue
        self.handler = handler
        self.retry = retry
        self.quit = threading.Event()
        self.name = '{0}:{1}'.format(dispatcher.__class__.__name__, self.queue_name)

    def run(self):
        logging.info('Starting worker for dispatch queue [%s]', self.name)
        while not self.quit.is_set():
            try:
                job = self.queue.get(True, 1.0)
                self.handler(job)
            except Queue.Empty:
                job = None
            except TypeError:
                logging.error('Handler for queue "%s" does not support interface.', self.queue_name, exc_info=True)
            except Exception:
                logging.error('Problem in queue "%s" handle for job: %s', self.queue_name, job, exc_info=True)
                if self.retry:
                    self.queue.put(job)
                    time.sleep(1)
            finally:
                if job is not None:
                    self.queue.task_done()

        del self.dispatcher
        del self.handler
        return

    def stop(self):
        logging.info('Stopping worker for dispatch queue [%s]', self.name)
        self.quit.set()


class Dispatcher(object):
    """A dispatcher that manages sequential dispatch queues 
    that can be used for asynchronous processing of events.
    Each queue has its own worker thread.
    """

    def __init__(self):
        super(Dispatcher, self).__init__()
        cherrypy.engine.subscribe('start', self.start_workers, 100)
        self.queues = {}

    def start_workers(self):
        for name, entry in self.queues.iteritems():
            if not entry['worker']:
                queue = entry['queue']
                handler = entry['handler']
                retry = entry['retry']
                entry['worker'] = Worker(self, name, queue, handler, retry)
                entry['worker'].start()

    def stop_workers(self):
        cherrypy.engine.unsubscribe('start', self.start_workers)
        for entry in self.queues.values():
            worker = entry['worker']
            if worker:
                worker.stop()
                worker.join()

        self.queues.clear()

    def create_queue(self, name, handler, retry = False, autostart = False, maxsize = 500):
        """Creates a new dispatch queue that is handled by its own thread.
        
        :param: retry: Whether to restart failed jobs.
        :param: autostart:  Automatically start the worker thread when the queue 
                            is created. Leave False if threads should be started
                            on cherrypy start event. If the queue is 
                            instantiated after the start event, autostart should
                            be True.
        :param maxsize: Maximum size of the queue. When the queue is full, 
                        dispatch operations will block until slots become available. 
                        If `maxsize` is zero, the queue size is infinite (default).
        """
        self.queues[name] = {'worker': None,
         'queue': Queue.Queue(maxsize),
         'handler': handler,
         'retry': retry}
        if autostart:
            self.start_workers()
        return

    def dispatch(self, queue_name, job):
        """Dispatch a job onto a queue"""
        if queue_name in self.queues:
            self.queues[queue_name]['queue'].put(job)
        else:
            logging.warning('Queue "%s" does not exist', queue_name)
# okay decompyling ./core/websockets/dispatch.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:23 CST
