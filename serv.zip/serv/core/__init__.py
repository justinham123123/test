# 2017.08.13 21:48:00 CST
# Embedded file name: build\bdist.win32\egg\serv\core\__init__.py
"""
The AAM Theatre Core; a remote API for communicating to digital screen servers
Copyright - Arts Alliance Media 2012
"""
import os
import json
VERSION_FILE = os.path.abspath(os.path.join(os.path.dirname(__file__), 'version.txt'))
file_handle = open(VERSION_FILE)
VERSION = json.loads(file_handle.read())
if 'patch' in VERSION:
    VERSION_STRING = '{major}.{minor}.{patch}.{build}'.format(**VERSION)
else:
    VERSION_STRING = '{major}.{minor}.{build}'.format(**VERSION)
file_handle.close()
# okay decompyling ./core/__init__.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:00 CST
