# 2017.08.13 21:49:01 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\merlin\merlin.py
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.parsers.parsers import parse_merlin_pos
from serv.core.devices.base.pos import POS
import datetime
import logging
import urllib2
import uuid
import xml.sax

class Merlin(POS):

    def get_schedule(self, start_date, end_date, complex_ids = []):
        """
        Gets a schedule of films for a cinema theatre
        """
        output = {'sessions': [],
         'success': False,
         'messages': [],
         'raw_input': None}
        try:
            parser = Parser()
            source = urllib2.urlopen(urllib2.Request(self.device_configuration['ip']))
            xml.sax.parse(source, parser)
            output['raw_input'] = ''
            output['sessions'] = parser.sessions
            output['success'] = True
            output['messages'].append({'type': 'success',
             'message': _('POS sync successful')})
        except (urllib2.URLError, IOError):
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed because IP address is incorrect or unreachable')})
            output['raw_input'] = 'POS sync failed, IP address is incorrect or unreachable.'
        except Exception as ex:
            logging.error('There was an error while syncing the POS feed.', exc_info=True)
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed: %s') % str(ex)})
            output['raw_input'] = 'POS sync failed: %s' % str(ex)

        return output

    def test_management_connection(self):
        try:
            urllib2.urlopen(self.device_configuration['ip']).read()
        except (urllib2.URLError, IOError):
            return (False, _('IP address is incorrect or unreachable'))
        except Exception as ex:
            return (False, _('Connection error %s' % str(ex)))

        return (True, _('OK'))


class Parser(xml.sax.ContentHandler):

    def __init__(self):
        xml.sax.ContentHandler.__init__(self)
        self.sessions = []
        self.cinema = {}
        self.film = {}
        self.session = {}

    def startElement(self, name, attrs):
        if name == 'cinema':
            self.cinema['complex_id'] = attrs.getValue('Cinema').replace(' ', '-').replace(',', '')
        elif name == 'film':
            self.film['feature_title'] = attrs.getValue('Title')
            self.film['overall_duration'] = int(attrs.getValue('RunningTime')) * 60
            self.film['feature_duration'] = self.film['overall_duration']
            self.film['film_attributes'] = []
            threed = attrs.getValue('ThreeD')
            if threed == 'true':
                self.film['film_attributes'].append('3D')
        elif name == 'showing':
            show_date = attrs.getValue('ShowDate')
            show_time = attrs.getValue('ShowTime')
            screen_number = attrs.getValue('Screen')
            session_attributes = []
            if attrs.getValue('HearingLoop') == 'true':
                session_attributes.append('HearingLoop')
            if attrs.getValue('Subtitles') == 'true':
                session_attributes.append('Subtitles')
            if attrs.getValue('LuxuryScreen') == 'true':
                session_attributes.append('LuxuryScreen')
            if attrs.getValue('AdultOnly') == 'true':
                session_attributes.append('AdultOnly')
            session_start = datetime.datetime.strptime(show_date + 'T' + show_time, '%d.%m.%YT%H:%M')
            if self.cinema['complex_id']:
                session_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, str((self.cinema['complex_id'] + self.film['feature_title'] + str(session_start)).upper().encode('punycode'))))
            else:
                session_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, str((self.film['feature_title'] + str(session_start)).upper().encode('punycode'))))
            self.session = {'complex_identifier': self.cinema['complex_id'],
             'id': session_id,
             'feature_title': self.film['feature_title'],
             'start': session_start,
             'end': session_start + datetime.timedelta(minutes=int(self.film['overall_duration'])),
             'feature_duration': self.film['feature_duration'],
             'overall_duration': self.film['overall_duration'],
             'screen_identifier': screen_number,
             'session_attributes': str(list(set(session_attributes + self.film['film_attributes']))).replace('[', '').replace(']', '').replace("'", '')}

    def endElement(self, name):
        if name == 'cinema':
            self.cinema = {}
        elif name == 'film':
            self.film = {}
        elif name == 'showing':
            self.sessions.append(self.session)
            self.session = {}
# okay decompyling ./core/devices/pos/merlin/merlin.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:01 CST
