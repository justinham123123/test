# 2017.08.13 21:49:03 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\vista\vista.py
from datetime import datetime
from urlparse import urlparse
import socket
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.network.soap_utils import SOAPClient
from serv.lib.utilities.xml_utils import iterparse_xml
from serv.configuration import cfg
from serv.core.devices.base.pos import POS
from serv.lib.utilities.helper_methods import HTTPGetter
VISTA_ERROR_DICT = {0: 'cmd executed normally',
 1: 'bad message name',
 2: 'TicketHold: asked for seats but no seats left',
 3: 'AllocateSeats: asked for seat numbers but unable to allocate them in Chapter 1 Ticket Purchase Messaging Flow 13 a contiguous block',
 5: 'General Failure: Unexpected result (hardware or logical). Client should attempt to cancel the Transaction.'}
ACCEPTED_STATUSES = ['O',
 'P',
 'M',
 'A',
 'C']

class Vista(POS):

    def __init__(self, id, device_info, core):
        super(Vista, self).__init__(id, device_info, core)
        parsed_url = urlparse(self.device_configuration['ip'])
        if not parsed_url.netloc:
            parsed_url = urlparse('//{0}'.format(self.device_configuration['ip']))
        host = parsed_url.netloc
        self.client = VistaSOAPClient(host)
        self.path = '{0}/WSVistaSalesSrvr/WSVistaSalesSrvr.asmx'.format(parsed_url.path)
        self.namespaces = {'wsv': 'http://vista.co.nz/webservices/wsvistasalessrvr'}
        self.default_params = {'wsv:TransIdTemp': 0,
         'wsv:ReturnData': ''}
        if self.device_configuration['api_username']:
            self.soap_action = 'http://vista.co.nz/webservices/wsvistasalessrvr/ExecuteEx'
            self.method = 'wsv:ExecuteEx'
            self.default_params.update({'wsv:ServerName': self.device_configuration['api_username'].upper(),
             'wsv:ClientID': 0})
        else:
            self.soap_action = 'http://vista.co.nz/webservices/wsvistasalessrvr/Execute'
            self.method = 'wsv:Execute'
            self.default_params.update({'wsv:ClientID': '82.109.92.118'})

    def get_schedule(self, start_date, end_date, complex_ids = []):
        output = {'messages': []}
        start_date = str(start_date).replace('-', '') + '0000'
        end_date = str(end_date).replace('-', '') + '0000'
        seats = self._get_seats(start_date, end_date)
        ratings = self._get_ratings()
        if not seats['success']:
            output['messages'].extend(seats['messages'])
        if not ratings['success']:
            output['messages'].extend(ratings['messages'])
        http_response = self._get_projection_schedule(start_date, end_date, seats, ratings)
        if len(http_response['sessions']) > 0 and http_response['success']:
            return http_response
        else:
            soap_response = self._get_sales_schedule(start_date, end_date, seats, ratings)
            if not soap_response['success'] and http_response.get('success'):
                return http_response
            return soap_response

    def _get_projection_schedule(self, start_date, end_date, seats, ratings):
        """
        Gets a schedule of films for a cinema theatre
        """
        url = '/WSVistaProjection/Service.svc/schedule/{0}/{1}'.format(start_date, end_date)
        try:
            getter = HTTPGetter(self.device_configuration['ip'], url)
            response_xml = getter.get()
            sessions = parse_vista_projection(response_xml, seats, ratings)
            return {'success': True,
             'sessions': sessions,
             'raw_input': response_xml,
             'messages': [{'type': 'success',
                           'message': _('POS sync successful')}]}
        except Exception as e:
            return {'success': False,
             'sessions': [],
             'messages': [{'type': 'error',
                           'message': str(e)}]}

    def _get_sales_schedule(self, start_date, end_date, seats, ratings):
        """
        Gets a schedule of films for a cinema theatre
        """
        feed_type = cfg.pos_feed_type.get()
        use_feature_stamp = cfg.pos_vista_feature_stamp.get()
        try:
            params = {'wsv:CmdName': 'GetSessionDisplayData',
             'wsv:Param1': 'ALL',
             'wsv:Param2': '|DATESTART|%s|DATEEND|%s|' % (start_date, end_date)}
            params.update(self.default_params)
            response_xml = self.client.request(self.path, self.method, self.soap_action, params=params, namespaces=self.namespaces).encode('utf-8')
            sessions = parse_vista_sales(response_xml, seats, ratings, feed_type, use_feature_stamp)
            return {'success': True,
             'sessions': sessions,
             'raw_input': response_xml,
             'messages': []}
        except Exception as e:
            return {'success': False,
             'sessions': [],
             'messages': [{'type': 'error',
                           'message': str(e)}]}

    def _get_seats(self, start_date, end_date):
        """
        Gets a schedule of films for a cinema theatre
        """
        try:
            params = {'wsv:CmdName': 'GetSessionDisplayData',
             'wsv:Param1': 'COUNTS',
             'wsv:Param2': '|DATESTART|%s|DATEEND|%s|' % (start_date, end_date)}
            params.update(self.default_params)
            response_xml = self.client.request(self.path, self.method, self.soap_action, params=params, namespaces=self.namespaces).encode('utf-8')
            sessions = parse_vista_seats(response_xml)
            return {'success': True,
             'sessions': sessions,
             'raw_input': response_xml,
             'messages': []}
        except Exception as e:
            return {'success': False,
             'sessions': [],
             'messages': [{'type': 'error',
                           'message': str(e)}]}

    def _get_ratings(self):
        try:
            params = {'wsv:CmdName': 'GetSellingDataXMLStream',
             'wsv:Param1': '|OutputRequest|%s|' % 'FILMS'}
            params.update(self.default_params)
            response_xml = self.client.request(self.path, self.method, self.soap_action, params=params, namespaces=self.namespaces).encode('utf-8')
            movies = parse_vista_ratings(response_xml)
            return {'success': True,
             'movies': movies,
             'raw_input': response_xml,
             'messages': []}
        except Exception as e:
            return {'success': False,
             'movies': [],
             'messages': [{'type': 'error',
                           'message': str(e)}]}

    def test_management_connection(self):
        soc = None
        try:
            try:
                soc = socket.create_connection((self.device_configuration['ip'], 80))
                soc.shutdown(socket.SHUT_RDWR)
            except socket.timeout:
                return (False, _('Timed out while trying to connect'))
            except (socket.herror, socket.gaierror):
                return (False, _('Unable to find the configured host or address'))
            except socket.error as ex:
                return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
            except Exception as ex:
                return (False, _('Unexpected error %s') % str(ex))

            return (True, _('OK'))
        finally:
            if soc:
                soc.close()

        return


def parse_vista_projection(xml, seats, ratings):

    def loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.endswith('Session'):
                loop_vars['in_session'] = True
                loop_vars['session'] = {}
        elif event == 'end':
            if loop_vars['in_session']:
                session = loop_vars['session']
                if element.tag.endswith('SessionId'):
                    session['id'] = element.text
                    if session['id'] in seats['sessions']:
                        seat_info = seats['sessions'][session['id']]
                        session['seats_available'] = seat_info['seats_available']
                        session['seats_sold'] = seat_info['seats_sold']
                elif element.tag.endswith('FilmName'):
                    session['feature_title'] = element.text
                    if session['feature_title'] in ratings['movies']:
                        session['rating'] = ratings['movies'][session['feature_title']]['rating']
                elif element.tag.endswith('ScreenNumber'):
                    session['screen_identifier'] = element.text
                elif element.tag.endswith('}ScreenId') and 'screen_identifier' not in session:
                    session['screen_identifier'] = element.text
                elif element.tag.endswith('HOFilmId'):
                    session['feature_id'] = element.text
                elif element.tag.endswith('FilmId') and 'feature_id' not in session:
                    session['feature_id'] = element.text
                elif element.tag.endswith('SessionStartString'):
                    session['start'] = datetime.strptime(element.text, '%Y%m%d%H%M%S')
                elif element.tag.endswith('SessionCompleteString'):
                    session['end'] = datetime.strptime(element.text, '%Y%m%d%H%M%S')
                elif element.tag.endswith('FeatureMinutes'):
                    session['feature_duration'] = int(element.text) * 60
                elif element.tag.endswith('PrintId'):
                    session['print_number'] = element.text
                elif element.tag.endswith('CinemaId') and not element.tag.endswith('HOCinemaId'):
                    session['complex_identifier'] = element.text
                elif element.tag.endswith('SessionAttributes'):
                    session['session_attributes'] = element.text
                elif element.tag.endswith('SessionTypeName') and 'session_attributes' not in session:
                    session['session_attributes'] = element.text
                elif element.tag.endswith('Session'):
                    td = session['end'] - session['start']
                    session['overall_duration'] = int(td.seconds) + int(td.days * 24 * 60 * 60)
                    loop_vars['sessions'].append(session)
                    loop_vars['in_session'] = False
            element.clear()
        return loop_vars

    initial_vars = {'sessions': [],
     'in_session': False}
    parsed_response = iterparse_xml(xml, loop_function, initial_vars)
    return parsed_response['sessions']


def parse_vista_seats(xml):

    def loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.rsplit('}', 1)[-1] == 's':
                loop_vars['in_session'] = True
                loop_vars['session'] = {}
        elif event == 'end':
            if loop_vars['in_session']:
                session = loop_vars['session']
                if element.tag.endswith('Session_lngSessionId'):
                    session['id'] = element.text
                elif element.tag.endswith('Session_intSeatsAvail'):
                    session['seats_available'] = int(element.text)
                elif element.tag.endswith('Session_intSeatsSold'):
                    session['seats_sold'] = int(element.text)
                elif element.tag.endswith('Session_intSeatsHouse'):
                    session['seats_house'] = int(element.text)
                elif element.tag.rsplit('}', 1)[-1] == 's':
                    if 'id' in session:
                        loop_vars['sessions'][session['id']] = session
                    loop_vars['in_session'] = False
            element.clear()
        return loop_vars

    initial_vars = {'sessions': {},
     'in_session': False}
    parsed_response = iterparse_xml(xml, loop_function, initial_vars)
    return parsed_response['sessions']


def parse_vista_ratings(xml):

    def loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.endswith('Movie'):
                loop_vars['in_movie'] = True
                loop_vars['movie'] = {}
        elif event == 'end':
            if loop_vars['in_movie']:
                movie = loop_vars['movie']
                if element.tag.endswith('Movie_Name'):
                    movie['film_name'] = element.text
                elif element.tag.endswith('Rating'):
                    movie['rating'] = element.text
                elif element.tag.endswith('Movie_HOCode'):
                    movie['film_id'] = element.text
                elif element.tag.endswith('Movie_ID') and 'film_id' not in movie:
                    movie['film_id'] = element.text
                elif element.tag.endswith('Movie'):
                    if 'film_name' in movie:
                        loop_vars['movies'][movie['film_name']] = movie
                    loop_vars['in_movie'] = False
            element.clear()
        return loop_vars

    initial_vars = {'movies': {},
     'in_movie': False}
    parsed_response = iterparse_xml(xml, loop_function, initial_vars)
    return parsed_response['movies']


def parse_vista_sales(schedule_xml, seats, ratings, feed_type, use_feature_stamp = False):

    def loop_function(event, element, loop_vars, **kwargs):
        if event == 'start':
            if element.tag.rsplit('}', 1)[-1] == 's':
                loop_vars['in_session'] = True
                loop_vars['session'] = {}
        elif event == 'end':
            if loop_vars['in_session']:
                session = loop_vars['session']
                if element.tag.endswith('Session_strStatus'):
                    if element.text in ACCEPTED_STATUSES:
                        session['status'] = element.text
                    else:
                        loop_vars['session'] = {}
                        loop_vars['in_session'] = False
                elif element.tag.endswith('Session_lngSessionId'):
                    session['id'] = element.text
                    if session['id'] in seats['sessions']:
                        seat_info = seats['sessions'][session['id']]
                        session['seats_available'] = seat_info['seats_available']
                        session['seats_sold'] = seat_info['seats_sold']
                elif element.tag.endswith('Film_strTitle'):
                    session['feature_title'] = element.text
                    if session['feature_title'] in ratings['movies']:
                        session['rating'] = ratings['movies'][session['feature_title']]['rating']
                elif element.tag.endswith('Screen_bytNum'):
                    session['screen_identifier'] = element.text
                elif element.tag.endswith('Session_dtmFeature') and use_feature_stamp:
                    session['start'] = parse_vista_time(element.text)
                elif element.tag.endswith('Session_dtmShowing') and not use_feature_stamp:
                    session['start'] = parse_vista_time(element.text)
                elif element.tag.endswith('Session_dtmFinish'):
                    session['end'] = parse_vista_time(element.text)
                elif element.tag.endswith('Session_intPrintID'):
                    session['print_number'] = element.text
                elif element.tag.endswith('Cinema_strBranchNo') and feed_type == 'cinepolis':
                    session['complex_identifier'] = element.text
                elif element.tag.endswith('CinOperator_strCode') and feed_type != 'cinepolis':
                    session['complex_identifier'] = element.text
                elif element.tag.endswith('SType_strDescription') or element.tag.endswith('Session_strAttributes'):
                    if session.get('session_attributes'):
                        session['session_attributes'] += u', {0}'.format(element.text)
                    else:
                        session['session_attributes'] = element.text
                elif element.tag.rsplit('}', 1)[-1] == 's':
                    td = session['end'] - session['start']
                    session['overall_duration'] = int(td.seconds) + int(td.days * 24 * 60 * 60)
                    loop_vars['sessions'].append(session)
                    loop_vars['in_session'] = False
            element.clear()
        return loop_vars

    initial_vars = {'sessions': [],
     'in_session': False}
    parsed_response = iterparse_xml(schedule_xml, loop_function, initial_vars)
    return parsed_response['sessions']


def parse_vista_time(v_time):
    """
    Parses a Vista time, which is in the format YYYYMMDDHHMMSSMMM, e.g. '20101026194000000'
    """
    return datetime.strptime(v_time + '000', '%Y%m%d%H%M%S%f')


class VistaSOAPClient(SOAPClient):

    def __init__(self, *args, **kwargs):
        super(VistaSOAPClient, self).__init__(timeout=800, *args, **kwargs)

    def parse_response(self, response, list_tags = None, method = None, **kwargs):
        result_tag = method.partition(':')[2] + 'Result'

        def loop_function(event, element, loop_vars, **kwargs):
            if event == 'end':
                if element.tag.endswith(result_tag):
                    result_code = int(element.text)
                    if result_code != 0:
                        raise Exception('Error sending command to vista server %s' % VISTA_ERROR_DICT[result_code])
                elif element.tag.endswith('ReturnData'):
                    xml = element.text.split('|')[6]
                    loop_vars['result'] = xml
                element.clear()
            return loop_vars

        parsed_response = iterparse_xml(response, loop_function, {})
        return parsed_response['result']
# okay decompyling ./core/devices/pos/vista/vista.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:04 CST
