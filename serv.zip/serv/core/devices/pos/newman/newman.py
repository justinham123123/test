# 2017.08.13 21:49:01 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\pos\newman\newman.py
import datetime, urllib2, logging
from serv.lib.dcinema.parsers.parsers import parse_newman_pos
from serv.core.devices.base.pos import POS
from serv.lib.cherrypy.i18n_tool import ugettext as _

class Newman(POS):

    def get_schedule(self, start_date, end_date, complex_ids = []):
        """
        Returns the schedule information between the start and end dates at the
        given URL endpoint
        """
        output = {'sessions': [],
         'success': False,
         'messages': [],
         'raw_input': None}
        start_date_str = start_date.strftime('%Y%m%d')
        end_date_str = end_date.strftime('%Y%m%d')
        newman_url = '{url}/getListings?from_date={from_date}&to_date={to_date}'.format(url=self.device_configuration['ip'], from_date=start_date_str, to_date=end_date_str)
        if complex_ids != [] and complex_ids != '':
            newman_url += '&venue_id='.join([''] + complex_ids)
        try:
            response = urllib2.urlopen(newman_url).read()
            output['raw_input'] = response
            output['sessions'] = parse_newman_pos(response)
            output['success'] = True
            output['messages'].append({'type': 'success',
             'message': _('POS sync successful')})
        except (urllib2.URLError, IOError):
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed because IP address is incorrect or unreachable')})
            output['raw_input'] = 'POS sync failed, IP address is incorrect or unreachable.'
        except Exception as ex:
            logging.error('There was an error while syncing the POS feed.', exc_info=True)
            output['success'] = False
            output['messages'].append({'type': 'error',
             'message': _('POS sync failed: %s') % str(ex)})
            output['raw_input'] = 'POS sync failed: %s' % str(ex)

        return output

    def test_management_connection(self):
        try:
            url_path = '/getListings?'
            start_date_str = datetime.date.today().strftime('%Y%m%d')
            end_date_str = (datetime.date.today() + datetime.timedelta(days=21)).strftime('%Y%m%d')
            newman_url = '{url}/getListings?from_date={from_date}&to_date={to_date}'.format(url=self.device_configuration['ip'], from_date=start_date_str, to_date=end_date_str)
            urllib2.urlopen(newman_url).read()
        except (urllib2.URLError, IOError):
            return (False, _('IP address is incorrect or unreachable'))
        except Exception as ex:
            return (False, _('Connection error %s' % str(ex)))

        return (True, _('OK'))
# okay decompyling ./core/devices/pos/newman/newman.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:02 CST
