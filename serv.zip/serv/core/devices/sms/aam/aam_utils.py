# 2017.08.13 21:49:16 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\aam\aam_utils.py
"""
Emulated SMS/Projector utilities
"""
import urllib2
import jsonurl
import json

def decode_list(data):
    rv = []
    for item in data:
        if isinstance(item, unicode):
            item = item.encode('utf-8')
        elif isinstance(item, list):
            item = decode_list(item)
        elif isinstance(item, dict):
            item = decode_dict(item)
        rv.append(item)

    return rv


def decode_dict(data):
    rv = {}
    for key, value in data.iteritems():
        if isinstance(key, unicode):
            key = key.encode('utf-8')
        if isinstance(value, unicode):
            value = value.encode('utf-8')
        elif isinstance(value, list):
            value = decode_list(value)
        elif isinstance(value, dict):
            value = decode_dict(value)
        rv[key] = value

    return rv


def execute(ip, port, api, func = None, params = {}, error_list = False):
    target = 'http://%s:%s/%s' % (ip, port, api)
    if func:
        target += '/%s' % func
    target = target + '?' + jsonurl.query_string(params) if params else target
    output = json.loads(urllib2.urlopen(target).read(), object_hook=decode_dict)
    if error_list:
        output['error_messages'] = []
    return output
# okay decompyling ./core/devices/sms/aam/aam_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:16 CST
