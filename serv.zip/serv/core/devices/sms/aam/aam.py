# 2017.08.13 21:49:15 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\aam\aam.py
"""
Emulated SMS Adaptor
"""
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.base.scheduling import Scheduling
from serv.core.devices.sms.aam.aam_utils import execute
from serv.lib.dcinema.parsers.parsers import parse_kdm, parse_cpl
from serv.lib.dcinema.dcp.file_handlers import FTPHandler
from aamulator import aamulator
import subprocess
import os
import sys
import json
import logging
from uuid import uuid4
from serv.configuration import cfg

class AAMulator(Scheduling):

    def __init__(self, id, device_info):
        super(AAMulator, self).__init__(id, device_info)
        self.process = None
        if self.device_configuration['enabled']:
            self.startup()
        return

    def startup(self):
        """
        Start emulator process
        """
        if not self.process:
            self.process = subprocess.Popen([cfg.python_executable() if cfg.python_executable() else sys.executable, os.path.join(os.path.dirname(aamulator.__file__), 'aamulator.pyc'), json.dumps({'type': 'sms',
              'ip': self.device_configuration['ip'],
              'port': self.device_configuration['port'],
              'root_directory': os.path.join(cfg.data_dir(), 'emulation', str(self.device_configuration['port']))})])
            logging.info('SMS Emulator enabled %s' % str(self.device_configuration['port']))
        else:
            logging.info('SMS Emulator already running %s' % str(self.device_configuration['port']))
        return (True, '')

    def shutdown(self):
        """
        Kill emulator process
        """
        if self.process:
            self.device_configuration['enabled'] = False
            try:
                self.process.terminate()
            except WindowsError:
                pass

            self.process = None
            logging.info('SMS Emulator disabled %s' % str(self.device_configuration['port']))
        return (True, '')

    def _execute(self, api, func = None, params = {}, error_list = False):
        return execute(self.device_configuration['ip'], self.device_configuration['port'], api, func=func, params=params, error_list=error_list)

    def get_device_status(self):
        return self._execute('time', error_list=True)

    def test_management_connection(self):
        self._execute('information')
        return (True, _('OK'))

    def get_device_version_information(self):
        return self._execute('information', error_list=True)

    def get_device_information(self):
        output = self._execute('information', error_list=True)
        output['product_certificates'] = output['certificates']
        output['device_dnqualifier'] = output['dnqualifiers'][0]
        return output

    def reboot(self):
        self._execute('reboot')
        return {'error_messages': []}

    def get_ingest_path(self, uuid):
        raise Exception("Can't transfer from an emulator.")

    def get_content_uuid_list(self):
        return {'content_uuid_list': self._execute('cpl', 'get', {'keys_only': True}),
         'error_messages': []}

    def get_content_information(self, content_uuids):
        output = {'content_info_dict': {},
         'error_messages': []}
        for uuid, cpl in self._execute('cpl', 'get', {'uuids': content_uuids}).iteritems():
            cpl_info = {}
            try:
                temp_cpl = parse_cpl(cpl['xml'], load_from_file=False)
                cpl_info['content_title_text'] = temp_cpl['text']
                cpl_info['content_kind'] = temp_cpl['type']
                cpl_info['edit_rate'] = temp_cpl['edit_rate']
                cpl_info['subtitled'] = temp_cpl['subtitled']
                cpl_info['subtitle_language'] = temp_cpl['subtitle_language']
                cpl_info['playback_mode'] = temp_cpl['playback_mode']
                cpl_info['aspect_ratio'] = temp_cpl['aspect_ratio']
                cpl_info['duration_in_seconds'] = temp_cpl['duration_in_seconds']
                cpl_info['duration_in_frames'] = temp_cpl['duration_in_frames']
                cpl_info['encrypted'] = temp_cpl['encrypted']
                cpl_info['xml'] = cpl['xml']
                cpl_info['parsed_info'] = temp_cpl['parsed_info']
            except UnicodeEncodeError as ex:
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))
            except Exception as ex:
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))

            output['content_info_dict'][uuid] = cpl_info

        return output

    def get_content_validation_information(self, cpl_uuids):
        output = {'content_validation_dict': {},
         'error_messages': []}
        for uuid in self._execute('cpl', 'get', {'keys_only': True}):
            output['content_validation_dict'][uuid] = {'validation_code': 0,
             'ingest_path': None,
             'cpl_size': None}

        return output

    def content_delete(self, content_id):
        self._execute('cpl', 'delete', {'uuids': [content_id]})
        return (True, _('CPL deleted'))

    def get_transfer_ids(self):
        return {'transfers': self._execute('ingester', 'status', {'keys_only': True}),
         'error_messages': []}

    def get_transfer_info(self, transfer_ids):
        status = self._execute('ingester', 'status')
        output = [ ingest for uuid, ingest in status['queue'].iteritems() ] + [ ingest for uuid, ingest in status['complete'].iteritems() ]
        if status['active']:
            output.append(status['active'])
        for ingest in output:
            ingest['server_transfer_id'] = ingest['ingest_uuid']

        return {'transfers': output,
         'error_messages': []}

    def content_clear_transfer_history(self):
        self._execute('ingester', 'clear_history')
        return (True, _('Transfer history cleared.'))

    def content_cancel_transfer(self, ingest_uuid):
        self._execute('ingester', 'cancel', {'ingest_uuid': ingest_uuid})
        return (True, _('Transfer cancelled'))

    def content_transfer(self, connection, description, cpl_uuid):
        handler = FTPHandler(host=connection['ftp_ip'], port=connection['ftp_port'], user=connection['ftp_username'], passwd=connection['ftp_password'], encoding='utf-8')
        dcp_size = 0
        for root, dirs, assets in handler.walk(os.path.dirname(connection['ingest_path'])):
            for asset in assets:
                dcp_size += handler.get_size(os.path.join(root, asset))

        cpl_xml = handler.open(connection['ingest_path']).read()
        ingest_uuid = str(uuid4())
        self._execute('ingester', 'add', {'ingests': [{'cpl_uuid': cpl_uuid,
                      'ingest_uuid': ingest_uuid,
                      'cpl_xml': cpl_xml,
                      'dcp_size': dcp_size,
                      'description': description}]})
        return (True, _('Transfer started'), ingest_uuid)

    def content_add_key(self, key_xml):
        self._execute('kdm', 'add', {'kdms': [{'uuid': parse_kdm(key_xml, load_from_file=False)['id'],
                   'xml': key_xml}]})
        return (True, _('KDM saved'))

    def content_delete_key(self, key_id):
        self._execute('kdm', 'delete', {'uuids': [key_id]})
        return (True, _('KDM deleted'))

    def get_key_uuid_list(self):
        return {'key_uuid_list': self._execute('kdm', 'get', {'keys_only': True}),
         'error_messages': []}

    def get_key_information(self, key_uuids):
        output = {'key_info_dict': {},
         'error_messages': []}
        for uuid, kdm in self._execute('kdm', 'get', {'uuids': key_uuids}).iteritems():
            parsed = parse_kdm(kdm['xml'], load_from_file=False)
            output['key_info_dict'][parsed['id']] = {'cpl_title': parsed['cpl_text'],
             'cpl_uuid': parsed['cpl_id'],
             'not_valid_before': parsed['start_date'],
             'not_valid_after': parsed['end_date'],
             'dnqualifier': parsed['dn_qualifier'],
             'status': 'ok'}

        return output

    def get_key(self, key_uuid):
        return {'xml': self._execute('kdm', 'get', {'uuids': [key_uuid]})['key_uuid'].get('xml'),
         'error_messages': []}

    def get_playlist_uuid_list(self):
        return {'playlist_uuid_list': self._execute('spl', 'get', {'keys_only': True}),
         'error_messages': []}

    def get_playlist_information(self, playlist_uuids):
        output = {'playlist_info_dict': {},
         'error_messages': []}
        for uuid, spl in self._execute('spl', 'get', {'uuids': playlist_uuids}).iteritems():
            playlist = json.loads(spl['json'])
            output['playlist_info_dict'][uuid] = {'playlist': playlist}
            for key in ['title',
             'duration_in_seconds',
             'is_3d',
             'is_hfr',
             'is_4k']:
                output['playlist_info_dict'][uuid][key] = playlist.get(key)

        return output

    def playlist_delete(self, playlist_uuid):
        self._execute('spl', 'delete', {'uuids': [playlist_uuid]})
        return (True, _('Deleted'))

    def playlist_save(self, playlist):
        self._execute('spl', 'add', {'spls': [json.dumps({'uuid': playlist['id'],
                   'json': playlist})]})
        return (True, _('Saved'))

    def validate_playlist(self, playlist_uuid):
        return {'info': {'result': 0,
                  'error_code': 0,
                  'cpl_uuid': '',
                  'description': ''},
         'error_messages': []}

    def get_playback_status(self):
        return self._execute('player', 'status', error_list=True)

    def playback_play(self):
        self._execute('player', 'play')
        return (True, _('Playback started'))

    def playback_pause(self):
        self._execute('player', 'pause')
        return (True, _('Playback paused'))

    def playback_stop(self):
        self._execute('player', 'stop')
        return (True, _('Playback stopped'))

    def playback_eject(self):
        self._execute('player', 'eject')
        return (True, _('Playlist ejected'))

    def playback_load(self, spl_uuid):
        self._execute('player', 'load', {'spl_uuid': spl_uuid})
        return (True, _('Playlist loaded'))

    def playback_set_mode(self, mode):
        if mode == 'schedule_on':
            self._execute('player', 'enable_schedules')
            return (True, _('Schedule mode enabled'))
        if mode == 'schedule_off':
            self._execute('player', 'disable_schedules')
            return (True, _('Schedule mode disabled'))

    def playback_skip_forward(self):
        self._execute('player', 'skip_forward')
        return (True, _('Playback skipped forwards'))

    def playback_skip_backward(self):
        self._execute('player', 'skip_backward')
        return (True, _('Playback skipped backwards'))

    def get_automation_list(self):
        return {'automation_uuid_list': [ id for id, cue in self._execute('cues').iteritems() ],
         'error_messages': []}

    def get_automation_information(self, automation_uuids):
        return {'automation_info_dict': self._execute('cues'),
         'error_messages': []}

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        return (True, _('Automation cue %s fired') % cue_id)

    def get_schedule_id_list(self):
        return {'schedule_id_list': self._execute('schedule', 'get', {'keys_only': True}),
         'error_messages': []}

    def get_schedule_information(self, schedule_ids):
        output = {'schedule_info_dict': {},
         'error_messages': []}
        for uuid, schedule in self._execute('schedule', 'get').iteritems():
            output['schedule_info_dict'][uuid] = {'device_schedule_id': uuid,
             'start_time': schedule['stamp'],
             'device_playlist_uuid': schedule['spl_uuid']}

        return output

    def scheduling_delete(self, schedule_id):
        self._execute('schedule', 'delete', {'uuids': [schedule_id]})
        return (True, _('Schedule deleted'))

    def scheduling_schedule_playlist(self, playlist_id, stamp):
        device_schedule_id = str(uuid4())
        self._execute('schedule', 'add', {'schedules': [{'uuid': device_schedule_id,
                        'spl_uuid': playlist_id,
                        'stamp': stamp}]})
        return (True, _('Schedule created'), {'device_schedule_id': device_schedule_id,
          'spl_uuid': playlist_id,
          'stamp': stamp})

    def get_logs(self, start_datetime):
        raise NotImplementedError('Log fail')

    def is_ready_for_collect(self):
        return False
# okay decompyling ./core/devices/sms/aam/aam.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:16 CST
