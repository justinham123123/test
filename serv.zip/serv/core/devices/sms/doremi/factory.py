# 2017.08.13 21:49:44 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\doremi\factory.py
"""
This file is meant to cover all the tricks and tweaks of autodetecting a Doremi type and instantiating a Device handler class.
"""
import doremi_v1XX, doremi_v2XX, doremi_v24X, doremi_v26X

def assess_device(device_id, device):
    software_information = device.get_device_version_information()
    version_parts = software_information['software_version'].split('.')
    if int(version_parts[0]) == 0:
        return device
    if int(version_parts[0]) == 1:
        return doremi_v1XX.DCP2000_v1XX(device_id, device.device_configuration)
    if int(version_parts[0]) == 2 and int(version_parts[1]) < 4:
        return doremi_v2XX.DCP2000_v2XX(device_id, device.device_configuration)
    if int(version_parts[0]) == 2 and int(version_parts[1]) < 6:
        return doremi_v24X.DCP2000_v24X(device_id, device.device_configuration)
    if int(version_parts[0]) == 2 and int(version_parts[1]) >= 6:
        return doremi_v26X.DCP2000_v26X(device_id, device.device_configuration)
    raise ValueError('Unknown Doremi device version %s' % software_information['software_version'])
# okay decompyling ./core/devices/sms/doremi/factory.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:44 CST
