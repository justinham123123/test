# 2017.08.13 21:49:44 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\doremi\doremi_v2XX.py
"""
A set of functions and classes that implement communication to a Doremi DCP2000 screen server
"""
import datetime, time
from urlparse import urlparse, ParseResult
from xml.dom.minidom import parseString
from serv.lib.utilities.utils import check_response
from serv.lib.dcinema.constants import NULL_UUID
from serv.lib.utilities.date_utils import parse_date
from serv.core.devices.sms.doremi import doremi_v1XX
from serv.core.devices.sms.doremi.doremi_commands import *
from serv.lib.cherrypy.i18n_tool import ugettext as _

class DCP2000_v2XX(doremi_v1XX.DCP2000_v1XX):
    """
    Doremi DCP2000 screen server access and control
    """

    def __init__(self, id, device_info):
        super(DCP2000_v2XX, self).__init__(id, device_info)

    def get_transfer_ids(self):
        """
        This returns all the transfer ids in the syste,
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                            ]
                        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        response = {}
        ingest_response = self._execute_command(INGEST_GET_JOB_LIST)
        if ingest_response['response'] == 0:
            list = []
            response['transfers'] = [ str(j['job_id']) for j in ingest_response['job_list'] ]
            response['error_messages'] = []
        else:
            response['error_messages'] = [_('Error getting transfers: %s') % str(ingest_response)]
        return response

    def get_transfer_info(self, transfer_ids):
        """
        This receives all updates for transfers, this is all historical transfers, once a transfer is recordeed as complete (failure, success or cancel) 
        that transfer should no longer be reported 
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                                state          STRING      - 'initializing', 'queued on server', 'active', 'paused', 'cancelled', 'success', 'failure'
                                description    STRING      - description of the transfer, ie content title
                                type           STRING      - cpl, kdm... 
                                content_id     STRING      - transferring Content
                                source         STRING      - source this can be an ipaddress or a description (ie local disk)
                                progress       INTEGER     - % transfer complete
                                message        STRING      - a message elaborating on the transfer_state ('ingest was paused at 15:00')
                                start_time     STRING      - Start time of the transfer
                                end_time     STRING        - End time of the transfer
                            ]
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'error_messages': [],
         'transfers': []}
        for job in transfer_ids:
            job_properties_response = self._execute_command(INGEST_GET_JOB_PROPERTIES, long(job))
            output_information = {'server_transfer_id': job,
             'state': None,
             'description': None,
             'content_id': None,
             'type': None,
             'source': None,
             'progress': None,
             'message': None,
             'message_code': None,
             'start_time': None,
             'end_time': None}
            properties_xml = parseString(job_properties_response['xml'][:-1])
            if properties_xml.getElementsByTagName('Description')[0].firstChild != None:
                output_information['description'] = properties_xml.getElementsByTagName('Description')[0].firstChild.nodeValue.strip()
                path = properties_xml.getElementsByTagName('FileUri')[0].firstChild.nodeValue
                values = path.split('/')
                cpl_uuid = values[len(values) - 1].replace('.xml', '')
                output_information['content_id'] = cpl_uuid
            if properties_xml.getElementsByTagName('FileType')[0].firstChild != None:
                output_information['type'] = properties_xml.getElementsByTagName('FileType')[0].firstChild.nodeValue.strip()
            if properties_xml.getElementsByTagName('StartedDate')[0].firstChild != None:
                output_information['start_time'] = parse_date(properties_xml.getElementsByTagName('StartedDate')[0].firstChild.nodeValue.strip())
            if properties_xml.getElementsByTagName('FinishedDate')[0].firstChild != None:
                output_information['end_time'] = parse_date(properties_xml.getElementsByTagName('FinishedDate')[0].firstChild.nodeValue.strip())
            if properties_xml.getElementsByTagName('FileUri')[0].firstChild != None:
                file_uri = properties_xml.getElementsByTagName('FileUri')[0].firstChild.nodeValue.strip()
                if file_uri.find(':') == 1:
                    parsed_url = ParseResult('', '', file_uri, '', '', '')
                else:
                    parsed_url = urlparse(file_uri)
                if not parsed_url.scheme or parsed_url.scheme == 'file':
                    output_information['source'] = 'local'
                elif parsed_url.scheme == 'ftp':
                    output_information['source'] = parsed_url.hostname
                elif parsed_url.scheme == 'share':
                    for value in parsed_url.path.split('/'):
                        if value != '':
                            output_information['source'] = value
                            break

            job_status_response = self._execute_command(INGEST_GET_JOB_STATUS, long(job))
            output_information['progress'] = job_status_response['process_progress']
            if job_status_response['status'] in (0, 3, 6):
                if job_status_response['actions'] == 2:
                    output_information['state'] = 'cancelled'
                    output_information['message'] = _('Transfer cancelled')
                    output_information['message_code'] = 6
                else:
                    output_information['state'] = 'queued_on_device'
                    output_information['message'] = _('Transfer queued on the screen server')
                    output_information['message_code'] = 7
            elif job_status_response['status'] in (1,):
                output_information['state'] = 'paused'
                output_information['message'] = _('Transfer is paused')
                output_information['message_code'] = 8
            elif job_status_response['status'] in (2,):
                output_information['state'] = 'active'
                output_information['message'] = _('Transfer in progress')
                output_information['message_code'] = 9
            elif job_status_response['status'] in (4,):
                output_information['state'] = 'success'
                output_information['message'] = _('Transfer successful')
                output_information['message_code'] = 10
            elif job_status_response['status'] == 5 or job_status_response['status'] == 7 and job_status_response['actions'] == 2:
                output_information['state'] = 'cancelled'
                output_information['message'] = _('Transfer cancelled')
                output_information['message_code'] = 6
            elif job_status_response['status'] in (7,):
                output_information['state'] = 'failed'
                log_event_count = self._execute_command(INGEST_GET_LOG_EVENT_COUNT, int(job))
                messages = []
                for event_number in range(log_event_count['event_count']):
                    log_event = self._execute_command(INGEST_GET_LOG_EVENT, (int(job), event_number))
                    if log_event['level'] > 1:
                        messages.append(log_event['message'].decode('utf-8'))

                if messages:
                    output_information['message'] = '\n'.join(messages)
                    output_information['message_code'] = None
                else:
                    output_information['message'] = _('Transfer failed')
                    output_information['message_code'] = 11
            output['transfers'].append(output_information)

        return output

    def content_transfer(self, connection_details, description, cpl_uuid):
        """
        Initiates the INGEST of a specified CPL + assets, via FTP.
        
        There should be an ASSETMAP and PKL in the same directory as the CPL xml
        
        PARAMS: ftp_ip          -- the IP of the FTP server
                ftp_port          -- the port of the FTP server
                ftp_username         -- the ftp login name
                ftp_password      -- the ftp password
                ingest_path      --  the path to the CPL XML file
                source            -- source of the transfer, not used in dolby, used in lms
        RETURNS: {'response': 0/1
                  'transfer_id': string, the id of the transfer
                  'error': Optional String listing error message
                  }
        """
        time_now = (datetime.datetime.utcnow() - datetime.timedelta(days=1)).strftime('%Y-%m-%dT00:00:00Z')
        job_xml = '<?xml version="1.0" encoding="UTF-8"?>\n        <IngestJobList>\n            <JobList>\n                <Job>\n                    <JobId>0</JobId>\n                    <Description>%s</Description>\n                    <Creator>AAM Core2</Creator>\n                    <IpAddress>%s</IpAddress>\n                    <FileUri>%s</FileUri>\n                    <FileType>DCP</FileType>\n                    <IngestOpt></IngestOpt>\n                    <User>%s</User>\n                    <Password>%s</Password>\n                    <CreationDate>%s</CreationDate>\n                    <ScheduledStartDate>%s</ScheduledStartDate>\n                    <StartedDate>%s</StartedDate>\n                    <FinishedDate>%s</FinishedDate>\n                    <PrivateData></PrivateData>\n                    <Priority>1</Priority>\n                    <MultiTask>1</MultiTask>\n                </Job>\n            </JobList>\n        </IngestJobList>' % (description,
         connection_details['ftp_ip'],
         'ftp://%s:%s/%s' % (connection_details['ftp_ip'], connection_details['ftp_port'], connection_details['ingest_path']),
         connection_details['ftp_username'],
         connection_details['ftp_password'],
         time_now,
         time_now,
         time_now,
         time_now)
        response = self._execute_command(INGEST_ADD_JOB, job_xml.encode('utf-8'))
        if check_response(response):
            return (True, _('Transfer started'), str(response['transfer_id']))
        else:
            return (False, _('Error starting transfer: %s') % str(response), None)
            return None

    def content_cancel_transfer(self, transfer_id):
        """
        Cancels the current ingest process
        
        Returns a dictionary containing
                    response - the response code sent by the server
        """
        response = self._execute_command(INGEST_CANCEL_JOB, transfer_id)
        if check_response(response):
            return (True, _('Transfer cancelled'))
        else:
            return (False, _('Error cancelling transfer: %s' % str(response)))

    def _check_load_spl_progress(self, timeout = 10):
        polling_timeout = time.time() + timeout
        while time.time() < polling_timeout:
            load_spl_progess_response = self._execute_command(CHECK_SPL_LOAD_PROGESS)
            if load_spl_progess_response['progess'] == 1:
                return True
            time.sleep(0.2)

        return False

    def playback_play(self):
        if self.playback_information['playback_state'] == 'stop':
            spl_uuid = self.playback_information['spl_uuid']
            response = self._execute_command(EJECT_SPL)
            if not check_response(response) or not self._wait_until_playback_state('spl_uuid', None):
                return (False, _('Error starting playback'))
            response = self._execute_command(LOAD_SPL_BY_UUID, spl_uuid)
            if not check_response(response):
                return (False, _('Error starting playback'))
        if not self._check_load_spl_progress():
            return (False, _('Cannot start playback because the Playlist is loading'))
        else:
            response = self._execute_command(PLAY_SPL)
            if check_response(response):
                self._device_sync_playback_status()
                if self.playback_information['playback_state'] == 'pause':
                    return (False, _('Playlist has ended'))
                return (True, _('Playback started'))
            return (False, _('Error starting playback: %s' % str(response)))
            return


if __name__ == '__main__':
    from serv.storage.database.primary import database as db
    from serv.configuration import cfg
    db.set_up(cfg.db_user(), cfg.db_password(), cfg.db_name(), cfg.db_engine(), cfg.db_port())
    new_device = DCP2000_v2XX('test', {'id': 'test',
     'ftp_port': 21,
     'ftp_username': 'manager',
     'type': 'doremi',
     'live_stream_url': '',
     'enabled': True,
     'number': 2,
     'port': 11730,
     'ftp_ip': '192.168.50.2',
     'ftp_password': 'password',
     'ip': '10.58.4.42'})
    print new_device._execute_command(INGEST_GET_JOB_STATUS, long(17528))
# okay decompyling ./core/devices/sms/doremi/doremi_v2XX.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:44 CST
