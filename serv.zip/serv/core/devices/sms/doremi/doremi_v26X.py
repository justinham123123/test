# 2017.08.13 21:49:42 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\doremi\doremi_v26X.py
from serv.core.devices.sms.doremi import doremi_v24X
import logging
from xml.dom.minidom import Document
from serv.lib.utilities.utils import strip_urn, wrap_urn, check_response
from serv.lib.utilities.xml_utils import iterparse_xml, node_to_dict, create_node
from serv.lib.utilities.helper_methods import copy_by_value
from serv.core.devices.sms.doremi.doremi_commands import *
from uuid import uuid4
import datetime
import copy

class DCP2000_v26X(doremi_v24X.DCP2000_v24X):

    def _parse_playlist_events(self, playlist_id, xml):
        """
        Parses playlist events within a playlist
        """

        def loop_function(event, element, loop_vars, tree = None):
            playlist_dict = node_to_dict(tree, list_tags=['Pack',
             'Event',
             'AutomationCue',
             'ExternalPack'], attributes=True)
            intermission_info = None
            if 'PackList' not in playlist_dict:
                playlist_dict['PackList'] = {'Pack': [{'EventList': playlist_dict['EventList']}]} if playlist_dict['EventList'] else None
            if playlist_dict['PackList']:
                for pack in playlist_dict['PackList']['Pack']:
                    if 'Intermission' in pack:
                        if not intermission_info:
                            intermission_info = playlist_dict['PackList']['ExternalPack'].pop(0)
                        else:
                            intermission_info = None
                            continue
                    for event_info in pack['EventList']['Event']:
                        event = {}
                        content_type = event_info['ElementList']['MainElement'].keys()[0]
                        event['type'] = content_type.lower()
                        event['id'] = strip_urn(event_info['Id'])
                        event['main_id'] = strip_urn(event_info['ElementList']['MainElement'][content_type]['Id'])
                        try:
                            event['edit_rate'] = [ int(i) for i in event_info['ElementList']['MainElement'][content_type]['EditRate'].split(' ') ]
                        except:
                            event['edit_rate'] = None

                        duration_str = event_info['ElementList']['MainElement'][content_type]['Duration' if content_type == 'Pattern' else 'IntrinsicDuration']
                        if content_type == 'Composition':
                            event['text'] = event_info['ElementList']['MainElement']['Composition']['AnnotationText']
                            event['cpl_id'] = strip_urn(event_info['ElementList']['MainElement']['Composition']['CompositionPlaylistId'])
                        elif content_type == 'Pattern':
                            event['text'] = event_info['ElementList']['MainElement']['Pattern']['AnnotationText']
                        if duration_str:
                            event['duration_in_frames'] = float(duration_str)
                            if event['edit_rate'] is not None:
                                event['duration_in_seconds'] = event['duration_in_frames'] / (event['edit_rate'][0] / event['edit_rate'][1])
                                if event['duration_in_seconds'] > 259200.0:
                                    logging.warning('Playlist parsed from doremi with event duration > 3 days!!! Setting duration to 0. Playlist UUID: ' + str(playlist_id))
                                    event['duration_in_seconds'] = 0
                            else:
                                logging.warning('Playlist parsed from doremi with an event with no edit rate!!! Setting duration to 0 and edit rate to ' + '24,1. Playlist UUID: ' + str(playlist_id))
                                event['edit_rate'] = [24, 1]
                                event['duration_in_seconds'] = 0
                        else:
                            logging.warning('Playlist parsed from doremi with an event with no duration!!! Setting duration to 0. Playlist UUID: ' + str(playlist_id))
                            event['duration_in_frames'] = event['duration_in_seconds'] = 0
                        automation = []
                        if intermission_info:
                            next_pack_index = playlist_dict['PackList']['Pack'].index(pack) + 1
                            next_pack_info = playlist_dict['PackList']['Pack'][next_pack_index]['EventList']['Event'][0]['ElementList']
                            event['post_intermission_main_id'] = strip_urn(next_pack_info['MainElement']['Composition']['Id'])
                            intermission_offset_in_frames = int(event_info['ElementList']['MainElement']['Composition']['Duration'])
                            intermission_offset_in_seconds = intermission_offset_in_frames / (event['edit_rate'][0] / event['edit_rate'][1])
                            if 'Duration' in next_pack_info['MainElement']['Composition']:
                                post_intermission_event_duration_in_frames = int(float(next_pack_info['MainElement']['Composition']['Duration']))
                                rewind_in_frames = intermission_offset_in_frames + post_intermission_event_duration_in_frames - int(float(duration_str))
                                rewind_in_seconds = rewind_in_frames / (event['edit_rate'][0] / event['edit_rate'][1])
                            else:
                                post_intermission_event_duration_in_frames = int(float(duration_str))
                                rewind_in_frames = intermission_offset_in_frames
                                rewind_in_seconds = rewind_in_frames / (event['edit_rate'][0] / event['edit_rate'][1])
                            intermission_automation = {'id': strip_urn(intermission_info['Id']),
                             'name': 'Doremi Intermission',
                             'type': 'intermission',
                             'type_specific': {'offset_in_seconds': intermission_offset_in_seconds,
                                               'offset_in_frames': intermission_offset_in_frames,
                                               'rewind_in_seconds': rewind_in_seconds,
                                               'rewind_in_frames': rewind_in_frames,
                                               'spl_uuid': strip_urn(intermission_info['External']),
                                               'offset_from': 'start'}}
                            automation.append(intermission_automation)
                            next_pack_cues = next_pack_info.get('AutomationCue', [])
                            for cue_info in next_pack_cues:
                                cue = self.get_cue_dict(cue_info, event['edit_rate'])
                                if cue['type_specific']['offset_from'] == 'start':
                                    offset_in_seconds = cue['type_specific']['offset_in_seconds']
                                    cue['type_specific']['offset_in_seconds'] = intermission_offset_in_seconds + (offset_in_seconds - rewind_in_seconds)
                                    cue['type_specific']['offset_in_frames'] = cue['type_specific']['offset_in_seconds'] * (event['edit_rate'][0] / event['edit_rate'][1])
                                automation.append(cue)

                        cues = event_info['ElementList'].get('AutomationCue', [])
                        for cue_info in cues:
                            cue = self.get_cue_dict(cue_info, event['edit_rate'])
                            automation.append(cue)

                        event['automation'] = automation
                        loop_vars['events'].append(event)

            return loop_vars

        initial_vars = {'events': []}
        parsed_response = iterparse_xml(xml, loop_function, initial_vars)
        return parsed_response['events']

    def get_cue_dict(self, cue, edit_rate):
        cue_dict = {}
        cue_dict['id'] = strip_urn(cue['Id'])
        cue_dict['name'] = cue['Action']
        cue_dict['type'] = 'cue'
        offset_in_frames = int(float(cue['Offset']))
        if edit_rate is not None:
            offset_in_seconds = offset_in_frames / (edit_rate[0] / edit_rate[1])
        else:
            offset_in_seconds = None
        offset_kind = cue['Offset__Kind']
        cue_dict['type_specific'] = {'offset_from': offset_kind.lower(),
         'offset_in_frames': offset_in_frames,
         'offset_in_seconds': offset_in_seconds,
         'action': cue['Action']}
        return cue_dict

    def _is_intermission_event(self, event):
        is_pre_intermission_event = False
        is_post_intermission_event = False
        if 'remainder_duration_in_frames' in event:
            is_post_intermission_event = True
            return (is_pre_intermission_event, is_post_intermission_event)
        if not is_post_intermission_event and 'automation' in event:
            for automation in event['automation']:
                if automation['type'] == 'intermission':
                    is_pre_intermission_event = True
                    break

        return (is_pre_intermission_event, is_post_intermission_event)

    def _doremi_xml(self, spl_dict):
        """
        Creates an SPL XML suitable for ingestion to Doremi
        The XML is created from the playlist dictionary format generated by the playlist parser.
        """
        root = Document()
        spl_element = create_node(root, root, 'ShowPlaylist')
        create_node(root, spl_element, 'Id', wrap_urn(spl_dict['id']))
        create_node(root, spl_element, 'ShowTitleText', spl_dict['title'])
        create_node(root, spl_element, 'AnnotationText', spl_dict['title'])
        create_node(root, spl_element, 'IssueDate', datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ'))
        create_node(root, spl_element, 'Creator', 'AAM - Theatre Core 2.0')
        playback_env = create_node(root, spl_element, 'PlaybackEnvironment')
        if spl_dict.get('is_3d'):
            env_capability = create_node(root, playback_env, 'EnvironmentCapability')
            create_node(root, env_capability, 'Capability', 'STEREOSCOPIC_CONTENT')
        if spl_dict.get('is_hfr'):
            env_capability = create_node(root, playback_env, 'EnvironmentCapability')
            create_node(root, env_capability, 'Capability', 'HFR_CONTENT')
        if spl_dict.get('is_4k'):
            env_capability = create_node(root, playback_env, 'EnvironmentCapability')
            create_node(root, env_capability, 'Capability', '4K_CONTENT')
        pack_list_element = create_node(root, spl_element, 'PackList')
        global_triggers = []
        if 'automation' in spl_dict:
            for automation in spl_dict['automation']:
                if automation['type'] == 'trigger':
                    global_triggers.append(automation)
                else:
                    logging.warning('Global cues are currently discarded with Doremi')

        trigger_list_element = create_node(root, spl_element, 'TriggerCueList')
        for trigger in global_triggers:
            trigger_element = create_node(root, trigger_list_element, 'TriggerCue')
            create_node(root, trigger_element, 'Id', wrap_urn(str(uuid4())))
            create_node(root, trigger_element, 'TriggerName', trigger['type_specific']['trigger'])
            create_node(root, trigger_element, 'Action', trigger['type_specific']['action'])

        if spl_dict['events']:
            pack_element = create_node(root, pack_list_element, 'Pack')
            create_node(root, pack_element, 'Id', wrap_urn(str(uuid4())))
            event_list_element = create_node(root, pack_element, 'EventList')
            event_triggers = []
            for event in spl_dict['events']:
                is_pre_intermission_event, is_post_intermission_event = self._is_intermission_event(event)
                if is_pre_intermission_event or is_post_intermission_event:
                    if is_post_intermission_event or is_pre_intermission_event and spl_dict['events'].index(event) != 0:
                        pack_element = create_node(root, pack_list_element, 'Pack')
                        create_node(root, pack_element, 'Id', wrap_urn(str(uuid4())))
                        event_list_element = create_node(root, pack_element, 'EventList')
                    create_node(root, pack_element, 'Intermission')
                if event['type'] in ('placeholder', 'title', 'macro_pack'):
                    continue
                event_element = create_node(root, event_list_element, 'Event')
                create_node(root, event_element, 'Id', wrap_urn(event['id']))
                element_list_element = create_node(root, event_element, 'ElementList')
                main_element_element = create_node(root, element_list_element, 'MainElement')
                if event['type'] == 'composition':
                    cpl_element = create_node(root, main_element_element, 'Composition')
                    create_node(root, cpl_element, 'CompositionPlaylistId', event['cpl_id'])
                    create_node(root, cpl_element, 'IntrinsicDuration', str(event['duration_in_frames']) if event['duration_in_frames'] else '')
                    if 'remainder_duration_in_frames' in event:
                        create_node(root, cpl_element, 'Duration', event['remainder_duration_in_frames'])
                        create_node(root, cpl_element, 'EntryPoint', str(event['duration_in_frames'] - event['remainder_duration_in_frames']))
                elif event['type'] == 'pattern':
                    cpl_element = create_node(root, main_element_element, 'Pattern')
                    create_node(root, cpl_element, 'Duration', str(event['duration_in_frames']) if event['duration_in_frames'] else '')
                    if event['text'] == 'Black 3D':
                        create_node(root, cpl_element, 'FrameRate', '48 1')
                    elif event['text'] == 'Black 3D 48':
                        create_node(root, cpl_element, 'FrameRate', '96 1')
                    else:
                        create_node(root, cpl_element, 'FrameRate', '0 1')
                else:
                    logging.warning('Invalid Doremi SPL event type:\n' + str(event))
                    continue
                create_node(root, cpl_element, 'Id', wrap_urn(str(uuid4())))
                create_node(root, cpl_element, 'AnnotationText', event['text'])
                if event['edit_rate'] is None:
                    raise ValueError('Invalid edit rate given for Content (CPL) [%s] in playlist [%s]' % (event.get('cpl_id'), spl_dict['id']))
                create_node(root, cpl_element, 'EditRate', ' '.join(map(str, event['edit_rate'])))
                if 'automation' in event:
                    if is_pre_intermission_event:
                        automation_types = {'cue': 2,
                         'trigger': 1,
                         'intermission': 0}
                        event['automation'] = sorted(event['automation'], key=lambda x: automation_types[x['type']])
                    for automation in event['automation']:
                        if automation['type'] == 'intermission':
                            pre_intermission_event_duration_in_frames = automation['type_specific']['offset_in_frames']
                            create_node(root, cpl_element, 'Duration', pre_intermission_event_duration_in_frames)
                            create_node(root, cpl_element, 'EntryPoint', 0)
                            external_pack_element = create_node(root, pack_list_element, 'ExternalPack')
                            create_node(root, external_pack_element, 'Id', wrap_urn(str(uuid4())))
                            create_node(root, external_pack_element, 'Intermission')
                            external_pack_element = create_node(root, external_pack_element, 'External', wrap_urn(automation['type_specific']['spl_uuid']))
                            external_pack_element.setAttribute('refid', 'ShowPlaylistId')
                            next_event = copy.deepcopy(event)
                            next_event['automation'] = []
                            post_intermission_event_duration_in_frames = event['duration_in_frames'] - automation['type_specific']['offset_in_frames']
                            rewind_in_frames = automation['type_specific']['rewind_in_seconds'] * (event['edit_rate'][0] / event['edit_rate'][1])
                            next_event['remainder_duration_in_frames'] = post_intermission_event_duration_in_frames + rewind_in_frames
                            next_event_index = spl_dict['events'].index(event) + 1
                            spl_dict['events'].insert(next_event_index, next_event)
                        elif automation['type'] == 'cue':
                            automation_to_push = None
                            if is_pre_intermission_event:
                                if automation['type_specific']['offset_from'] == 'start' and automation['type_specific']['offset_in_frames'] > pre_intermission_event_duration_in_frames:
                                    automation_to_push = copy.deepcopy(automation)
                                    automation_to_push['type_specific']['offset_in_frames'] = automation['type_specific']['offset_in_frames'] - pre_intermission_event_duration_in_frames + rewind_in_frames
                                elif automation['type_specific']['offset_from'] == 'end' and automation['type_specific']['offset_in_frames'] < post_intermission_event_duration_in_frames:
                                    automation_to_push = copy.deepcopy(automation)
                            if automation_to_push:
                                next_event['automation'].append(automation_to_push)
                            else:
                                cue_element = create_node(root, element_list_element, 'AutomationCue')
                                create_node(root, cue_element, 'Id', wrap_urn(str(uuid4())))
                                create_node(root, cue_element, 'Action', automation['type_specific']['action'])
                                offset_in_frames_int = str(int(float(automation['type_specific']['offset_in_frames'])))
                                offset_element = create_node(root, cue_element, 'Offset', offset_in_frames_int)
                                offset_element.setAttribute('Kind', automation['type_specific']['offset_from'].capitalize())
                        elif automation['type'] == 'trigger':
                            event_triggers.append((automation['type_specific']['trigger'], automation['type_specific']['action'], event['id']))

                if is_post_intermission_event and spl_dict['events'].index(event) != len(spl_dict['events']) - 1:
                    pack_element = create_node(root, pack_list_element, 'Pack')
                    create_node(root, pack_element, 'Id', wrap_urn(str(uuid4())))
                    event_list_element = create_node(root, pack_element, 'EventList')

            for event_trigger in event_triggers:
                trigger_element = create_node(root, trigger_list_element, 'TriggerCue')
                create_node(root, trigger_element, 'Id', wrap_urn(str(uuid4())))
                create_node(root, trigger_element, 'TriggerName', event_trigger[0])
                create_node(root, trigger_element, 'Action', event_trigger[1])
                create_node(root, trigger_element, 'Scope', wrap_urn(str(event_trigger[2])))

        return root.toxml('utf-8')

    def get_automation_list(self):
        output = {'error_messages': [],
         'automation_uuid_list': []}
        cue_list_response = self._execute_command(GET_MACRO_CUE_LIST)
        trigger_list_response = self._execute_command(GET_TRIGGER_CUE_LIST)
        if trigger_list_response['response'] == 0:
            output['automation_uuid_list'].extend(trigger_list_response['list'])
        else:
            output['error_messages'].append(str(trigger_list_response))
        if cue_list_response['response'] == 0:
            output['automation_uuid_list'].extend(cue_list_response['list'])
            output['automation_uuid_list'].append('intermission')
        else:
            output['error_messages'].append(str(cue_list_response))
        return output

    def get_playlist_playback_information(self, playlist_id):
        """
        This returns a playlist with an events list which includes any intermission playlist
        events and pre and post intermission events for the intermission CPL
        """
        playlist = copy_by_value(self._device_get_playlist_information([playlist_id]))
        if not playlist[playlist_id].get('playlist'):
            return playlist
        playlist_events = playlist[playlist_id]['playlist']['events']
        event_index = 0
        for event in playlist_events:
            for automation in event['automation'][:]:
                if automation['type'] == 'intermission':
                    intermission_spl_uuid = automation['type_specific']['spl_uuid']
                    intermission = automation
                    try:
                        intermission_spl_events = self._device_get_playlist_information([intermission_spl_uuid])[intermission_spl_uuid]['playlist']['events']
                    except KeyError:
                        logging.info('Intermission playlist is not on server')
                        return playlist

                    playlist_events[event_index + 1:event_index + 1] = intermission_spl_events
                    post_intermission_event = copy_by_value(event)
                    post_intermission_event['main_id'] = post_intermission_event['post_intermission_main_id']
                    event['duration_in_frames'] = intermission['type_specific']['offset_in_frames']
                    event['duration_in_seconds'] = intermission['type_specific']['offset_in_seconds']
                    post_intermission_event['duration_in_frames'] = post_intermission_event['duration_in_frames'] - event['duration_in_frames'] + intermission['type_specific']['rewind_in_frames']
                    post_intermission_event['duration_in_seconds'] = post_intermission_event['duration_in_seconds'] - event['duration_in_seconds'] + intermission['type_specific']['rewind_in_seconds']
                    event['automation'].remove(intermission)
                    post_intermission_automations = []
                    pre_intermission_automations = []
                    for auto in event['automation']:
                        if auto['type_specific']['offset_from'] == 'end' and auto['type_specific']['offset_in_frames'] > post_intermission_event['duration_in_frames'] - intermission['type_specific']['rewind_in_frames']:
                            auto['type_specific']['offset_in_frames'] -= post_intermission_event['duration_in_frames'] - intermission['type_specific']['rewind_in_frames']
                            auto['type_specific']['offset_in_seconds'] -= post_intermission_event['duration_in_seconds'] - intermission['type_specific']['rewind_in_seconds']
                            pre_intermission_automations.append(auto)
                        elif auto['type_specific']['offset_from'] == 'start' and auto['type_specific']['offset_in_frames'] > intermission['type_specific']['offset_in_frames']:
                            auto['type_specific']['offset_in_frames'] -= intermission['type_specific']['offset_in_frames'] - intermission['type_specific']['rewind_in_frames']
                            auto['type_specific']['offset_in_seconds'] -= intermission['type_specific']['offset_in_seconds'] - intermission['type_specific']['rewind_in_seconds']
                            post_intermission_automations.append(auto)
                        elif not auto['type_specific']['offset_from'] == 'start':
                            post_intermission_automations.append(auto)
                        else:
                            pre_intermission_automations.append(auto)

                    event['automation'] = pre_intermission_automations
                    post_intermission_event['automation'] = post_intermission_automations
                    post_intermission_event_index = event_index + len(intermission_spl_events) + 1
                    playlist_events[post_intermission_event_index:post_intermission_event_index] = [post_intermission_event]

            event_index += 1

        playlist[playlist_id]['playlist']['events'] = playlist_events
        return playlist
# okay decompyling ./core/devices/sms/doremi/doremi_v26X.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:43 CST
