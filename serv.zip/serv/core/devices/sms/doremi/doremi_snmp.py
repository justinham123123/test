# 2017.08.13 21:49:41 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\doremi\doremi_snmp.py
"""
Doremi end-points for SNMP
"""
import datetime, logging, pdb
from serv.lib.network.snmp import snmp_get, oid_is_child, oid_child_values
RAID_INFORMATION_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 3, 9)
DEGRADED_RAID_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 3, 9, 1, 4)
SOFTWARE_VERSION_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 3, 10, 0)
FIRMWARE_VERSION_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 3, 7, 0)
SYSTEM_DATE_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 3, 8, 0)
SERIAL_NUMBER_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 3, 6, 0)
PROJECTOR_VENDOR_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 6, 1, 3, 4, 0)
PROJECTOR_MODEL_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 6, 1, 3, 5, 0)
CURRENT_KDM_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 4, 1, 1, 4, 1)
CURRENT_KDM_EXPIRY_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 4, 1, 1, 5, 1)
TEMP_INFORMATION_OID = (1, 3, 6, 1, 4, 1, 24391, 1, 3, 1)

def software_version(ip_address):
    """
    Returns the software version
    """
    return str(snmp_get(SOFTWARE_VERSION_OID, ip_address))


def firmware_version(ip_address):
    """
    Returns the firmware version
    """
    return str(snmp_get(FIRMWARE_VERSION_OID, ip_address))


def system_date(ip_address):
    """
    Returns the system time and date
    """
    return str(snmp_get(SYSTEM_DATE_OID, ip_address))


def raid_status(ip_address):
    """
    Returns the RAID status; i.e. is it degraded?
    """
    raid_oids = snmp_get(RAID_INFORMATION_OID, ip_address, next=True)
    values = oid_child_values(DEGRADED_RAID_OID, raid_oids)
    return int(reduce(lambda x, y: x or y, values, 0))


def attached_projector_model(ip_address):
    """
    Returns the attached projector model
    """
    vendor = str(snmp_get(PROJECTOR_VENDOR_OID, ip_address))
    model = str(snmp_get(PROJECTOR_MODEL_OID, ip_address))
    return '%s : %s' % (vendor, model)


def serial_number(ip_address):
    """
    Returns the attached projector model
    """
    return str(snmp_get(SERIAL_NUMBER_OID, ip_address))


def temperature(ip_address):
    """
    Returns the system temperature
    """
    temp_oids = snmp_get(TEMP_INFORMATION_OID, ip_address, next=True)
    names = []
    values = []
    for row in temp_oids:
        oid = row[0][0]
        value = row[0][1]
        if oid[-2] == 2:
            names.append(str(value))
        elif oid[-2] == 3:
            values.append(int(value))

    return dict(zip(names, values))


def current_kdm(ip_address):
    """
    Returns the UUID of the currently active KDM
    """
    kdm = snmp_get(CURRENT_KDM_OID, ip_address)
    if kdm and kdm != '00000000-0000-0000-0000-000000000000':
        return str(kdm)
    else:
        return None
        return None


def current_kdm_expiry(ip_address):
    """
    The number of remaining hours for the currently active KDM
    """
    kdm = snmp_get(CURRENT_KDM_OID, ip_address)
    hours_remaining = snmp_get(CURRENT_KDM_EXPIRY_OID, ip_address)
    if hours_remaining and kdm != '00000000-0000-0000-0000-000000000000':
        return (datetime.datetime.now() + datetime.timedelta(hours=int(hours_remaining))).date()
    else:
        return None
        return None


if __name__ == '__main__':
    ip = '172.31.124.134'
    print 'Software: %s' % software_version(ip)
    print 'Firmware: %s' % firmware_version(ip)
    print 'Serial Number: %s' % serial_number(ip)
    print 'System date: %s' % system_date(ip)
    print 'RAID status: %s' % raid_status(ip)
    # print 'Projector: %s' % attached_projector_model(ip)
    # print 'Temerature: %s' % temperature(ip)
    # print 'Current KDM: %s' % current_kdm(ip)
    # print 'Current KDM expires: %s' % current_kdm_expiry(ip)
# okay decompyling ./core/devices/sms/doremi/doremi_snmp.pyc
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:41 CST
