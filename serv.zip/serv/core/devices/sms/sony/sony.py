# 2017.08.13 21:49:57 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\sony\sony.py
"""
Base Sony device adaptor
"""
import socket
from serv.core.devices.sms.sony.sony_utils import *
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities.date_utils import parse_date
from serv.lib.utilities.xml_utils import iterparse_xml

class SonyDevice(object):
    """
    Base Sony device implementation (the basic socket comm stuff)
    """

    def __init__(self, *args, **kwargs):
        super(SonyDevice, self).__init__(*args, **kwargs)

    def _http_request(self, command, data = None, timeout = 30, elements = None):
        """
        NOTE: data can only be used on calls where an xml message is passed as part of the request
        Inline get parameters should just be appended to the url like: /config/device/attributes?device=SMS
        (Sony seems to dislike the Content-Type and/or Content-Length headers that urllib adds on when you pass something to data)
        """
        url = 'https://{ip}/{cmd}'.format(ip=self.device_configuration['ip'], cmd=command)
        credentials = (self.device_configuration['api_username'], self.device_configuration['api_password'])
        response = request(url, credentials, data, 'application/xml' if data else None, timeout)
        if elements:
            return self.get_elements(response, elements)
        else:
            return parse_response(response)
            return

    def get_elements(self, stream, elements = []):

        def loop_function(event, element, loop_vars, **kwargs):
            if event == 'end':
                if element.tag.endswith('ErrorResponse'):
                    raise element.text
                else:
                    for e in elements:
                        if element.tag.endswith(e):
                            loop_vars.append(element.text)

                element.clear()
            return loop_vars

        loop_vars = []
        re = iterparse_xml(stream, loop_function, loop_vars)
        return re

    def _http_post_multipart(self, command, fields = [], files = [], timeout = 60):
        url = 'https://{ip}:{port}/{cmd}'.format(ip=self.device_configuration['ip'], port=self.device_configuration['port'], cmd=command)
        credentials = (self.device_configuration['api_username'], self.device_configuration['api_password'])
        response = post_multipart(url, fields, files, credentials, timeout)
        return parse_response(response)

    def _get_server_time(self):
        """
        Returns the server's time
        """
        dom = self._http_request('config/smsserver/attributes/list')
        return xml_utils.get_element_value(dom, 'DateTime')

    def get_device_status(self):
        output = {'error_messages': []}
        ret = self._get_server_time()
        output['current_time'] = parse_date(ret)
        return output

    def test_management_connection(self):
        try:
            try:
                self._http_request('config/smsserver/attributes/list')
            except urllib2.URLError as ex:
                if isinstance(ex.reason, socket.error):
                    raise ex.reason
                else:
                    return (False, _('URL error [%s]' % str(ex)))

        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error [%s]') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error [%s]') % str(ex))

        return (True, _('OK'))
# okay decompyling ./core/devices/sms/sony/sony.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:58 CST
