# 2017.08.13 21:50:01 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\sony\sony_utils.py
"""
Sony Utilities
"""
import mimetypes
import base64
import HTMLParser, urllib2
from urllib import unquote_plus
from xml.dom import minidom
from serv.lib.utilities import xml_utils

class SonyError(Exception):

    def __init__(self, severity, code, text):
        self.severity = severity
        self.code = code
        self.text = text

    def __str__(self):
        return 'SonyError("%s", %d, "%s")' % (self.severity, self.code, self.text)

    def __repr__(self):
        return self.text


html_parser = HTMLParser.HTMLParser()

def parse_response(response):
    """
    Parses a urllib2.urlopen response
    Returns either minidom document (if content type header is xml) or raw bytes
    Can also raise a SonyError if the response is a Sony ErrorResponse
    """
    info = response.info()
    data = response.read()
    if info.getsubtype() == 'xml':
        unquoted_data = unquote_plus(data)
        html_entity_replaced_data = html_parser.unescape(unquoted_data.decode('utf-8'))
        html_entity_replaced_data = html_entity_replaced_data.replace('&', ' ')
        if isinstance(html_entity_replaced_data, str):
            dom = minidom.parseString(html_entity_replaced_data)
        else:
            dom = minidom.parseString(html_entity_replaced_data.encode('utf-8'))
        error_response = dom.getElementsByTagName('ErrorResponse')
        if error_response:
            error_el = error_response[0]
            code = int(xml_utils.get_element_value(error_el, 'Code'))
            if code == 100:
                return None
            severity = xml_utils.get_element_value(error_el, 'Severity')
            text = xml_utils.get_element_value(error_el, 'Message')
            raise SonyError(severity, code, text)
        else:
            message_body = dom.getElementsByTagName('MessageBody')
            if message_body:
                return message_body[0]
            else:
                return dom
    else:
        return data
    return None


def request(url, credentials, data = None, content_type = None, timeout = 30):
    req = urllib2.Request(url, data)
    if data and content_type:
        req.add_header('Content-type', content_type)
    _add_auth_header(req, credentials)
    return urllib2.urlopen(req, timeout=timeout)


def post_multipart(url, fields = [], files = [], credentials = None, timeout = 30):
    """
    urllib2 implementation
    """
    content_type, body = _encode_multipart_formdata(fields, files)
    req = urllib2.Request(url, body)
    req.add_header('Content-type', content_type)
    _add_auth_header(req, credentials)
    return urllib2.urlopen(req, timeout=timeout)


def _add_auth_header(req, credentials):
    """
    Adds an Authentication header to a request
    
    The reason I'm not using the standard password manager stuff in
    urllib2 is because of the following:
     
    The Python libraries, per HTTP-Standard, first send an unauthenticated request,
    and then only if it's answered with a 401 retry, are the correct credentials sent.
    If the server doesn't do 'standard authentication' then the libraries won't work.
    
    Looks like the Sony server is guilty of the above
    """
    if credentials:
        base64str = base64.encodestring('%s:%s' % (credentials[0], credentials[1])).replace('\n', '')
        req.add_header('Authorization', 'Basic %s' % base64str)


def _encode_multipart_formdata(fields, files):
    """
    fields is a sequence of (name, value) elements for regular form fields.
    files is a sequence of (name, filename, value) elements for data to be uploaded as files
    Return (content_type, body) ready for use in urllib2 requests
    """
    BOUNDARY = '----------ThIs_Is_tHe_bouNdaRY_$'
    CRLF = '\r\n'
    L = []
    for key, value in fields:
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"' % key)
        L.append('')
        L.append(value)

    for key, filename, value in files:
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
        L.append('Content-Type: %s' % _get_content_type(filename))
        L.append('')
        L.append(value)

    L.append('--' + BOUNDARY + '--')
    L.append('')
    body = CRLF.join(L)
    content_type = 'multipart/form-data; boundary=%s' % BOUNDARY
    return (content_type, body)


def _get_content_type(filename):
    return mimetypes.guess_type(filename)[0] or 'application/octet-stream'
# okay decompyling ./core/devices/sms/sony/sony_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:50:02 CST
