# 2017.08.13 21:49:53 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\qube\qube.py
"""
Qube SMS Adaptor
"""
from datetime import datetime, timedelta
from httplib import HTTPException
import logging
import os
import posixpath
import re
import socket
import time
from qube_utils import QubeSOAPClient
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema import parsers
from serv.lib.dcinema.parsers.certificate_parsers import parse_device_certificates
from serv.lib.dcinema.parsers.parsers import parse_kdm, parse_cpl, parse_content_title_text, construct_smpte_playlist, parse_smpte_playlist
from serv.lib.network.soap_utils import SOAPError
from serv.lib.utilities.xml_utils import write_xml, parse_xml
from serv.core.devices.base.scheduling import Scheduling
from serv.lib.utilities.helper_methods import format_timestamp
import cherrypy
trace_number = 0

def unsupported(method):
    """
    The method decorated by this is unsupported, and should return an error
    response
    """

    def error_response(*args):
        return {'response': 1,
         'error_message': _('Unsupported method'),
         'method': method.__name__}

    return error_response


type_converter = {}

class Qube(Scheduling):
    """
    Qube screen server access and control
    """
    _PLAYBACK_STATE = {'Inactive': 'stop',
     'Stopped': 'stop',
     'Running': 'play',
     'Paused': 'pause',
     'Cued': 'pause'}
    TRANSFER_STATE_DICT = {'PENDING': 'queued_on_device',
     'QUEUED': 'queued_on_device',
     'TRANSFERRING': 'active',
     'TRANSFERRED': 'active',
     'SUSPENDED': 'paused',
     'CANCELLED': 'cancelled',
     'VERIFYING': 'verifying',
     'VERIFICATION_PENDING': 'verifying',
     'VERIFICATION_FAILED': 'failed',
     'VERIFICATION_CANCELLED': 'cancelled',
     'VERIFICATION_SUSPENDED': 'paused',
     'INGESTED': 'success',
     'ERROR': 'failed',
     'INDEXING': 'active',
     'UNKNOWN': 'active'}
    VALIDATION_ERROR_CODES = {'OK': 0,
     'CORRUPT': 2,
     'MISSING_DATA': 2,
     'NOT_PLAYABLE': 2,
     'NOT_FOUND': 2,
     'TRANSFERRING': 3}
    PLAYBACK_MODE_DIC = {'false': '2D',
     'true': '3D'}
    MAMA_ENDPOINTS = {'Usher': '2009-09-29',
     'Catalog': '2010-07-16',
     'Dalapathi': '2009-05-28',
     'Logs': '2009-5-8',
     'Setup': '2009-01-14',
     'Maintenance': '2008-10-15'}
    SMS_ENDPOINTS = {'Transfer': '2010-09-03',
     'Asset': '2010-09-03',
     'Playback': '2009-09-09',
     'Schedule': '2009-04-01',
     'Status': '2010-09-09',
     'Log': '2010-09-11'}
    transfers = set()

    def __init__(self, id, device_info):
        """
        Initialises a new server communications object:
        
            name          -- name for the server; must be unique as it serves as
                             the unique id
            screen_number -- the screen's number
            ip_address    -- the server's IP address
            port          -- the server's port nr.
        """
        super(Qube, self).__init__(id, device_info)
        self._ip_address = self.device_configuration['ip']
        self._port = int(self.device_configuration['port'])
        self.type = 'QUBE'
        self.transfers = set()
        self.supported_modes = {'loop_modes': ['do_not_loop', 'loop'],
         'schedule_modes': ['schedule_on', 'schedule_off']}
        self.mama_client = QubeSOAPClient(self._ip_address, port=80)
        self.sms_client = QubeSOAPClient(self._ip_address, port=8080)

    def execute(self, soap_endpoint, method, **kwargs):
        """
        Execute a command against the Qube.
        
        Parameters:
        :param soap_endpoint: The endpoint to hit.  This will be forwarded on to the correct port (MAMA or SMS)
        :param method: The method to execute on the endpoint
        :param params: Any parameters needed in the request body.  These need to be in a specific format, see
            the 'build_body' method on the SOAPClient for more information.
            *WARNING* The Qube doesn't seem to understand how XML works, as the order of the child tags matters
                when it's parsing a request.  We'd need an ordered dictionary for this which isn't provided in
                Python 2.6.  An easier way to ensure the tags appear in the right order is to pass
                in a list of dictionaries, which will get flattened out as the request is built.
        :param list_tags: A list of tag names which are guaranteed to be lists when parsing the response
        """
        headers = {'Soap_Post_number': '000000',
         'Request_0_Time': str(time.clock())}
        if soap_endpoint in self.MAMA_ENDPOINTS:
            path = '/mama/{0}.asmx'.format(soap_endpoint)
            soap_endpoint_url = 'http://webservices.qubecinema.com/XP/{0}/{1}/'.format(soap_endpoint, self.MAMA_ENDPOINTS[soap_endpoint])
            soap_action = '{0}{1}'.format(soap_endpoint_url, method)
            client = self.mama_client
        elif soap_endpoint in self.SMS_ENDPOINTS:
            path = '/{0}Service'.format(soap_endpoint)
            url_part = soap_endpoint if soap_endpoint != 'Asset' else 'Assets'
            soap_endpoint_url = 'http://services.qubecinema.com/XP/{0}/{1}/'.format(url_part, self.SMS_ENDPOINTS[soap_endpoint])
            soap_action = '{0}I{1}Service/{2}'.format(soap_endpoint_url, soap_endpoint, method)
            client = self.sms_client
        else:
            raise Exception('Qube SOAP endpoint not in MAMA API ({0}) or SMS API ({1}) [{2}]'.format(self.MAMA_ENDPOINTS.keys(), self.SMS_ENDPOINTS.keys(), soap_endpoint))
        namespaces = {'ns0': soap_endpoint_url,
         'ns1': 'http://schemas.microsoft.com/2003/10/Serialization/Arrays'}
        try:
            return client.request(path, method, soap_action, namespaces=namespaces, headers=headers, **kwargs)
        except SOAPError as e:
            logging.error(_(u'Unexpected error: {0}'.format(str(e))))
            raise
        except Exception:
            time.sleep(3)
            raise

    def load_content_types(self):
        if 'title_event_type' not in type_converter:
            title_event_type = self.execute('Catalog', 'GetPlayTitleEventType')['ID']
            type_converter['title_event_type'] = title_event_type
            type_converter[title_event_type] = 'title_event_type'
        if 'cue_event_type' not in type_converter:
            cue_event_type = self.execute('Catalog', 'GetPlaylistCueEventType')['ID']
            type_converter['cue_event_type'] = cue_event_type
            type_converter[cue_event_type] = 'cue_event_type'
        if 'wait_cue_event_type' not in type_converter:
            wait_cue_event_type = self.execute('Catalog', 'GetTriggerCueEventType')['ID']
            type_converter[wait_cue_event_type] = 'wait_cue_event_type'
            type_converter['wait_cue_event_type'] = wait_cue_event_type

    def get_device_status(self):
        output = {'error_messages': []}
        qube_year = self.execute('Dalapathi', 'GetCurrentYear')
        qube_month_day = self.execute('Dalapathi', 'GetCurrentMonthAndDate')
        qube_time = self.execute('Dalapathi', 'GetCurrentTime')
        timestring = '%s %s %s' % (qube_year, qube_month_day, qube_time)
        output['current_time'] = float(time.mktime(datetime.strptime(timestring, '%Y %b %d %I:%M %p').timetuple()))
        return output

    def test_management_connection(self):
        try:
            self.execute('Dalapathi', 'GetCurrentTime')
        except HTTPException as ex:
            return (False, _('HTTP error %s') % str(ex))
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error %s') % str(ex))

        return (True, _('OK'))

    def get_device_version_information(self):
        response = {'error_messages': []}
        player_info = self.execute('Status', 'GetPlayerInfo')
        response['software_version'] = player_info['SoftwareVersion']
        return response

    def get_device_information(self):
        """
        Returns information regarding the device
            response['software_version'] = response['software_version']
            response['serial'] = response['serial']
            response['firmware_version'] = response['firmware_version']
            response['model'] = response['model']
            response['raid_status']
            response['storage_total']
            response['storage_used']
            response['storage_available']
            response['product_certificates']
            response['dnqualifiers']
        """
        response = {'error_messages': []}
        player_info = self.execute('Status', 'GetPlayerInfo')
        response['software_version'] = player_info['SoftwareVersion']
        response['serial'] = response['id'] = player_info['SerialNumber']
        response['firmware_version'] = 'unknown'
        response['model'] = player_info['OEM']['Branding']['Model']
        certificates = self.get_product_certificates()
        response.update(parse_device_certificates(*certificates))
        raid_stat = self.get_raid_status()
        response['raid_status'] = []
        index = 0
        for drive in raid_stat['list']:
            active = drive['active']
            degraded = drive['degraded']
            drive_number = 'md' + str(index)
            if active and not degraded:
                response['raid_status'].append({'message': _('OK'),
                 'status': 'ok',
                 'name': drive_number})
            elif active:
                response['raid_status'].append({'message': _('Degraded'),
                 'status': 'warning',
                 'name': drive_number})
            else:
                response['raid_status'].append({'message': _('Not Active'),
                 'status': 'error',
                 'name': drive_number})
            index += 1

        disk_usage = self.get_disk_usage()
        if disk_usage:
            response['storage_total'] = int(disk_usage['total_size'])
            response['storage_used'] = int(disk_usage['used'])
            response['storage_available'] = int(disk_usage['available'])
        else:
            response['storage_total'] = None
            response['storage_used'] = None
            response['storage_available'] = None
        return response

    def get_product_certificates(self):
        certs = []
        certs.append(self.execute('Catalog', 'GetCertificate', params={'certificateType': 'SHA1'}))
        certs.append(self.execute('Catalog', 'GetCertificate', params={'certificateType': 'SHA256'}))
        return certs

    def get_key_uuid_list(self):
        """
        This recieves the uuids of all the kdms in the system
        
        @param      None
        @return     [key_uuid]      - list of key uuids
        """
        response = {'key_uuid_list': [],
         'error_messages': []}
        result = self.execute('Usher', 'GetAssets', params={'assetType': 'KDM'}, list_tags=['guid'])
        if result and result.get('guid'):
            response['key_uuid_list'] = result['guid']
        return response

    def get_key_information(self, key_uuids):
        """
        This key information for key uuids provided
        
        @param      key_uuids          LIST of key ids
        @return     key dictionary
        """
        response = {'key_info_dict': {},
         'error_messages': []}
        for kdm_id in self.get_key_uuid_list()['key_uuid_list']:
            if kdm_id in key_uuids:
                kdm = self.get_kdm_info(kdm_id)
                response['key_info_dict'][kdm_id] = kdm

        return response

    def get_kdm_info(self, kdm_id):
        """
        Retrieves information regarding the specified KDM
        
                kdm_id  --  ID of the KDM to retrieve
        
        Returns:
            cpl_title             --  The title text of the CPL
            cpl_id                --  CPL ID that the KDM is for
            not_valid_before      --  UTC time that the KDM starts at - , time in seconds since jan01/1970
            not_valid_after       --  UTC time that the KDM ends at,  time in seconds since jan01/1970
            dnqualifier           --  The dnQualifier of this KDM
        """
        response = {'error_messages': []}
        xml = self.execute('Usher', 'GetAssetXML', params=[{'assetId': kdm_id}, {'assetType': 'KDM'}])
        kdm = parse_kdm(xml, load_from_file=False)
        response['cpl_title'] = kdm['cpl_text']
        response['cpl_uuid'] = kdm['cpl_id']
        response['not_valid_before'] = kdm['start_date']
        response['not_valid_after'] = kdm['end_date']
        response['dnqualifier'] = kdm['dn_qualifier']
        response['status'] = 'ok'
        return response

    def get_key(self, key_uuid):
        """
        gets key xml
        
        @return
            dict
                xml        DICT
                    xml    STRING
                error_messages          -LIST of errors
        """
        output = {'error_messages': [],
         'xml': {}}
        try:
            output['xml'] = self.execute('Usher', 'GetAssetXML', params=[{'assetId': key_uuid}, {'assetType': 'KDM'}])
        except Exception as ex:
            logging.info('Error getting KDM %s' % key_uuid, exc_info=True)
            output['error_messages'].append(str(ex))

        return output

    def get_transfer_ids(self):
        output = {'transfers': [],
         'error_messages': []}
        results = self.execute('Transfer', 'GetCurrentTransfers', list_tags=['guid'])
        if results.get('guid'):
            for uuid in results['guid']:
                self.transfers.add(uuid)

        output['transfers'] = self.transfers
        return output

    def get_transfer_info(self, transfer_ids):
        """
        This returns all information for specified transfers
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                                state          STRING      - 'initializing', 'queued on server', 'active', 'paused', 'cancelled', 'success', 'failure'
                                description    STRING      - description of the transfer, ie content title
                                type           STRING      - cpl, kdm...
                                cpl_uuid       STRING      - transferring cpl
                                source         STRING      - source this can be an ipaddress or a description (ie local disk)
                                progress       INTEGER     - % transfer complete
                                message        STRING      - a message elaborating on the transfer_state ('ingest was paused at 15:00')
                            ]
        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'transfers': [],
         'error_messages': []}
        for transfer_id in transfer_ids:
            try:
                transfer = self.execute('Transfer', 'GetTransferDetails', params={'transferUUID': transfer_id})
            except SOAPError as e:
                if e.detail['TransferFault']['StatusCode'] == '-2146233088':
                    logging.info("Qube can't find transfer {id}. It might be just a usual lie or you really requested something that isn't there. Ignoring.".format(id=transfer_id))
                    continue
                else:
                    raise

            output_information = {'server_transfer_id': transfer_id,
             'state': self.TRANSFER_STATE_DICT[transfer['Status']],
             'description': transfer['Message'],
             'content_id': transfer['AssetUUID'],
             'type': transfer['AssetType'],
             'source': None,
             'progress': int(transfer['PercentComplete']),
             'message': transfer['Message']}
            output['transfers'].append(output_information)

        return output

    def content_exists(self, uuid):
        return uuid in self.get_content_uuid_list()['content_uuid_list']

    def get_content_uuid_list(self):
        """
        This recieves the uuids of all the cpls in the system
        
        @param      None
        @return     [content_uuid_list] - list of cpl uuids
        """
        output = {'error_messages': []}
        result = self.execute('Asset', 'GetAssets', params={'assetType': 'CPL'})
        output['content_uuid_list'] = [ asset['AssetUUID'] for asset in result['Asset'] ]
        return output

    def get_content_information(self, content_uuids):
        """
        gets content information of a device
        
        @param      content_uuids   - list of cpl uuids we want information for
        @return {
                    content_info_dict:        DICT
                        {
                            content_uuid: {
                                content_title_text  STRING
                                content_kind        INT
                                edit_rate           [INT, INT]
                                encrypted           BOOL
                                subtitled           BOOL
                                is_3d               BOOL
                                duration            INT in seconds
                                xml                 STRING xml file
                                parsed_info         DICT
                            }
                    error_messages          -LIST of errors
                }
        """
        output = {'error_messages': [],
         'content_info_dict': {}}
        for content_uuid in content_uuids:
            cpl_info = {'content_title_text': content_uuid,
             'content_kind': 'unknown',
             'edit_rate': None,
             'subtitled': None,
             'subtitle_language': None,
             'playback_mode': None,
             'aspect_ratio': None,
             'duration_in_seconds': 0,
             'duration_in_frames': 0,
             'encrypted': None,
             'xml': None,
             'parsed_info': parse_content_title_text(''),
             'video_encoding': 'UNKNOWN'}
            try:
                xml = self.execute('Asset', 'GetAssetXml', params=[{'assetType': 'CPL'}, {'assetUUID': content_uuid}])
                temp_cpl = parse_cpl(xml, load_from_file=False)
                cpl_info['content_title_text'] = temp_cpl['text']
                cpl_info['content_kind'] = temp_cpl['type']
                cpl_info['edit_rate'] = temp_cpl['edit_rate']
                cpl_info['subtitled'] = temp_cpl['subtitled']
                cpl_info['subtitle_language'] = temp_cpl['subtitle_language']
                cpl_info['playback_mode'] = temp_cpl['playback_mode']
                cpl_info['aspect_ratio'] = temp_cpl['aspect_ratio']
                cpl_info['duration_in_seconds'] = temp_cpl['duration_in_seconds']
                cpl_info['duration_in_frames'] = temp_cpl['duration_in_frames']
                cpl_info['encrypted'] = temp_cpl['encrypted']
                cpl_info['xml'] = xml
                cpl_info['parsed_info'] = temp_cpl['parsed_info']
            except UnicodeEncodeError as ex:
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))
            except Exception as ex:
                logging.error(_('Error getting information for CPL %s') % content_uuid)
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(str(ex))

            output['content_info_dict'][content_uuid] = cpl_info

        return output

    def validate_playlist(self, playlist_uuid):
        output = {'error_messages': []}
        response = {'result': 0,
         'error_code': 0,
         'cpl_uuid': '',
         'description': ''}
        spl = self.execute('Catalog', 'GetShowInfo', params={'id': playlist_uuid}, list_tags=['EventInfo'])
        if 'Events' not in spl:
            return {'response': 0,
             'result': 1,
             'error_code': 2,
             'cpl_id': '',
             'error_msgs': _('Playlist does not contain any events')}
        else:
            events = spl['Events']['EventInfo']
            for event in events:
                if 'Title' in event and event['Title'] is not None:
                    is_cpl_verified = self.execute('Usher', 'IsVerified', params={'titleId': event['Title']['ID']}) == 'true'
                    if not is_cpl_verified:
                        unverified_cpl = event['Title']['ID']
                        response['cpl_id'] = unverified_cpl
                        response['error_code'] = 1
                        response['error_msgs'] = _('CPL in the Playlist is corrupt')
                        break

            output['info'] = response
            return output

    def get_content_validation_information(self, cpl_uuids):
        """
        This recieves information for given cpls in the system
        
        @param  cpl_uuids   - list of cpl uuids we want information for
        @return
                cpl_uuid:
                    validation_code - Integer
                        0 No error nor warning
                        1 CPL is partially registered on this server
                        2 CPL is registered on this server but cannot be loaded
                        3 CPL is ingesting
                        4 CPL is queued for ingest
                    ingest_path         STRING relative path to cpl.xml from ftp logon
                    cpl_size            STRING size of cpl in bytes
        """
        response = {}
        validation_dict = {}
        cpl_infos = self.execute('Asset', 'GetAssets', params={'assetType': 'CPL'})
        for cpl_info in cpl_infos['Asset']:
            if cpl_info['AssetUUID'] not in cpl_uuids:
                continue
            cpl_uuid = cpl_info['AssetUUID']
            validation_dict[cpl_uuid] = {}
            validation_dict[cpl_uuid]['validation_code'] = self.VALIDATION_ERROR_CODES[cpl_info['AssetStatus']]
            validation_dict[cpl_uuid]['ingest_path'] = self.get_ingest_path(cpl_uuid)
            validation_dict[cpl_uuid]['cpl_size'] = self.execute('Asset', 'GetAssetSize', params=[{'assetType': 'CPL'}, {'assetUUID': cpl_uuid}])

        response['content_validation_dict'] = validation_dict
        return response

    def content_add_key(self, key):
        """
            Ingest a KDM from its XML
        """
        self.execute('Usher', 'IngestKey', params={'keyEssence': key})
        kdm = parse_kdm(key, load_from_file=False)
        kdm_uuid = kdm['id']
        self._add_key(kdm_uuid, {'cpl_title': kdm['cpl_text'],
         'cpl_uuid': kdm['cpl_id'],
         'not_valid_before': kdm['start_date'],
         'not_valid_after': kdm['end_date'],
         'dnqualifier': kdm['dn_qualifier'],
         'status': 'ok'})
        message = _('KDM saved on %s for CPL %s') % (self.device_configuration['screen_identifier'], kdm['cpl_text'])
        return (True, message)

    def content_cancel_transfer(self, transfer_id):
        self.execute('Transfer', 'CancelTransfer', params={'transferUUID': transfer_id})
        return (True, _('Transfer canceled'))

    def content_clear_transfer_history(self):
        self.execute('Transfer', 'ClearTransferHistory')
        self.transfers.clear()
        completed_transfers = self.get_completed_transfers()
        for transfer_id in completed_transfers:
            try:
                if 'server_transfer_id' in completed_transfers[transfer_id]:
                    self.content_cancel_transfer(completed_transfers[transfer_id]['server_transfer_id'])
            except:
                pass

        return (True, _('Transfer history cleared.'))

    def content_delete(self, content_id):
        try:
            self.execute('Asset', 'DeleteAsset', params=[{'assetType': 'CPL'}, {'assetUUID': content_id}])
        except SOAPError as e:
            return (False, str(e))

        return (True, _('CPL deleted'))

    def content_delete_key(self, key_id):
        self.execute('Asset', 'DeleteAsset', params=[{'assetType': 'KDM'}, {'assetUUID': key_id}])
        return (True, _('KDM deleted'))

    def content_transfer(self, connection, description, cpl_uuid):
        path = connection['ingest_path']
        username = connection['ftp_username']
        password = connection['ftp_password']
        ip = connection['ftp_ip']
        port = connection['ftp_port']
        drive_letter, path = os.path.splitdrive(path)
        folder_path, cpl_file = posixpath.split(path)
        uri = 'ftp://%s:%s@%s:%s/%s' % (username,
         password,
         ip,
         port,
         folder_path)
        transfer_id = None
        transfer_id = self.execute('Transfer', 'TransferAsset', params=[{'assetUUID': cpl_uuid}, {'assetType': 'CPL'}, {'URI': uri}])
        if transfer_id is None:
            return (False, _('Unknown error starting transfer for CPL %s') % cpl_uuid, None)
        else:
            self.transfers.add(transfer_id)
            return (True, _('Transfer started'), transfer_id)

    def get_playlist_uuid_list(self):
        """
        This recieves the uuids of all the playlists in the system
        
        @param      None
        @return     [playlist_uuid_list]      - list of playlist uuids
        """
        output = {'error_messages': []}
        spls = self.execute('Asset', 'GetAssets', params={'assetType': 'SPL'}, list_tags=['Asset'])
        if spls is None:
            output['playlist_uuid_list'] = []
            return output
        else:
            spl_list = []
            if spls and spls.get('Asset'):
                for spl in spls['Asset']:
                    if spl['AssetUUID']:
                        spl_list.append(spl['AssetUUID'])

            output['playlist_uuid_list'] = spl_list
            return output

    def get_playlist_information(self, playlist_uuids):
        """
        This playlist information for playlist uuids provided
        
        @param      playlist_uuids          LIST of playlist ids
        @return     playlist dictionary
        
        Return dict of:
        title, duration, is_3d, is_pack, playlist
        """
        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for playlist_uuid in playlist_uuids:
            try:
                smpte_playlist = self.execute('Asset', 'GetAssetXml', params=[{'assetType': 'SPL'}, {'assetUUID': playlist_uuid}])
                playlist = parse_smpte_playlist(cherrypy.core.contents, smpte_playlist)
                output['playlist_info_dict'][playlist_uuid] = {}
                output['playlist_info_dict'][playlist_uuid]['title'] = playlist['text']
                output['playlist_info_dict'][playlist_uuid]['duration_in_seconds'] = playlist['duration_in_seconds']
                output['playlist_info_dict'][playlist_uuid]['is_3d'] = playlist['is_3d']
                output['playlist_info_dict'][playlist_uuid]['is_hfr'] = playlist['is_hfr']
                output['playlist_info_dict'][playlist_uuid]['is_4k'] = playlist['is_4k']
                output['playlist_info_dict'][playlist_uuid]['playlist'] = playlist
            except Exception as ex:
                logging.error(_('Error getting playlist %s') % playlist_uuid, exc_info=True)
                output['error_messages'].append(_('Error parsing Playlist %s: %s') % (playlist_uuid, str(ex)))

        return output

    def playlist_delete(self, playlist_uuid):
        """
                 Deletes the specified SPL from the D-Cinema server
                 Returns:
                     response    - the response code returned from the server
        """
        result = self.execute('Asset', 'DeleteAsset', params=[{'assetType': 'SPL'}, {'assetUUID': playlist_uuid}])
        if result == 'true':
            logging.info('Deletion Completed %s', result)
            return (True, _('Playlist deleted'))
        else:
            logging.info('Deletion failed %s', result)
            return (False, _('Playlist could not be deleted: %s') % str(result))

    def playlist_save(self, playlist):
        playlist_xml = construct_smpte_playlist(cherrypy.core.contents, playlist)
        response = self.execute('Asset', 'SaveAssetXml', params=[{'assetType': 'SPL'}, {'assetXml': playlist_xml}])
        if not response:
            return (True, _('Saved: %s') % playlist['title'])
        else:
            return (False, 'Something something')

    def get_playback_status(self):
        """
        This recieves the current playback status
        
        @param      None
        @return     {
                        playback_state:         INTEGER     - id telling us which play state we're in e.g. play, pause
                        spl_uuid:               STRING      - loaded_spl id
                        spl_position:           INTEGER     - seconds into playlist
                        spl_duration:           INTEGER     - total seconds of playlist
        
                        element_id:             STRING      - current loaded event
                        element_position:       INTEGER     - seconds into loaded event
                        element_duration        INTEGER     - duration of loaded event
                        element_index           INTEGER     - index of current loaded event
        
                        scheduler_enabled:      BOOLEAN     - is the scheduler enabled
                        modes                   DICT        - containing all available modes and their state
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        response = {'response': 0}
        response['modes'] = {}
        response['error_messages'] = []
        show_info = self.execute('Dalapathi', 'GetCurrentShowInfo', params=[{'isEvents': 'true'}, {'isDurationUpCount': 'false'}, {'isShowEventUpCount': 'false'}], list_tags=['EventInfoLE'])
        response['playback_state'] = self._PLAYBACK_STATE[show_info['State']]
        response['spl_uuid'] = show_info.get('ID')
        response['spl_position'] = int(float(show_info['Position']))
        response['spl_duration'] = int(float(show_info['Duration']))
        response['element_id'] = show_info.get('ShowEvent')
        response['element_position'] = 0
        response['element_duration'] = 0
        response['element_index'] = 0
        response['modes']['playback_mode'] = None
        response['cpl_uuid'] = '00000000-0000-0000-0000-000000000000'
        if show_info.get('Events') and show_info['Events'].get('EventInfoLE'):
            events = show_info['Events']['EventInfoLE']
            for index, event_info in enumerate(events):
                if event_info['ID'] == response['element_id']:
                    response['cpl_uuid'] = event_info['playlistID']
                    response['element_duration'] = int(float(event_info['Duration']))
                    response['element_index'] = index
                    response['modes']['playback_mode'] = self.PLAYBACK_MODE_DIC[event_info['IsStereoscopic']]
                    break

        if response['element_duration'] != 0:
            response['element_position'] = response['element_duration'] - self.__GetInSeconds(show_info['ShowEventPosition'])
        response['modes']['loop_mode'] = 'loop' if show_info['IsLoopplayBack'] == 'true' else 'do_not_loop'
        scheduler_enabled = self.get_scheduler_enable()
        response['modes']['scheduler_enabled'] = scheduler_enabled['enabled']
        return response

    def get_scheduler_enable(self):
        """
            The GetSchedulerEnable command will return a dictionary containing {
                response    -  the response code from the server
                enabled     -  boolean, True if the scheduler is enabled, otherwise False
        """
        schedule = self.execute('Schedule', 'GetScheduleMode')
        return {'enabled': schedule == 'AUTOMATIC'}

    def playback_eject(self):
        state = self._PLAYBACK_STATE[self.execute('Dalapathi', 'GetState')]
        if state != 'stop':
            self.playback_stop()
        try:
            self.execute('Playback', 'EjectPlaylist')
        except:
            return (False, _('Error ejecting playlist'))

        self._device_sync_playback_status()
        return (True, _('Playlist ejected'))

    def playback_load(self, playlist_id):
        """
        Load an SPL by UUID and leave the server in PAUSE state.
        
        If the server is already playing, return the playlist to the beginning automation_info_dict
        leave the server in PAUSE state.
        RETURNS: {'response': 0/1}
        """
        spl = self.execute('Catalog', 'GetShowInfoLE', params={'id': playlist_id}, list_tags=['EventInfoLE', 'AutoEventInfoLE'])
        if spl.get('EventsLE') and spl['EventsLE'].get('EventInfoLE'):
            events = spl['EventsLE']['EventInfoLE']
        else:
            events = []
        is3D = 'false'
        for event in events:
            if event['IsStereoscopic'] == 'true':
                is3D = 'true'
                break

        try:
            self.execute('Dalapathi', 'LoadShow', params=[{'id': playlist_id}, {'isStereoscopic': is3D}])
            self.execute('Catalog', 'GetShowInfoLE', params={'id': playlist_id}, list_tags=['EventInfoLE', 'AutoEventInfoLE'])
        except Exception:
            return (False, _('Error loading playlist'))

        self._device_sync_playback_status()
        return (True, _('Playlist loaded: %s') % self.playlist_information[playlist_id]['title'])

    def playback_pause(self):
        """
        Pauses playback of an SPL
        Returns:
            response -- the response code received from the server
        """
        state = self._PLAYBACK_STATE[self.execute('Dalapathi', 'GetState')]
        if state == 'play':
            try:
                self.execute('Playback', 'SetPlayState', params={'playState': 'PAUSE'})
            except:
                return (False, _('Error pausing playback'))

        self._device_sync_playback_status()
        return (True, _('Playback paused'))

    def playback_play(self):
        """
        Plays whatever is loaded
        
        RETURNS: {'response': 0/1
                 }
        """
        state = self._PLAYBACK_STATE[self.execute('Dalapathi', 'GetState')]
        if state == 'stop' or state == 'pause':
            try:
                self.execute('Playback', 'SetPlayState', params={'playState': 'PLAY'})
            except:
                return (False, _('Error starting playback'))

        self._device_sync_playback_status()
        return (True, _('Playback started'))

    def playback_stop(self):
        """
        Implments EJECT_SPL
        
        Ejects the currently loaded SPL. The server will output black
        
        Returns:
            response -- the response code received from the server
        """
        state = self._PLAYBACK_STATE[self.execute('Dalapathi', 'GetState')]
        if state != 'stop':
            try:
                self.execute('Playback', 'SetPlayState', params={'playState': 'STOP'})
            except:
                return (False, _('Error stopping playback'))

        self._device_sync_playback_status()
        return (True, _('Playback stopped'))

    def playback_skip_forward(self):
        """
        The Skip Forward command will skip to the first frame of the next
        CPL in the currently loaded SPL
        Returns:
            response -- the response code received from the server
        """
        try:
            self.execute('Dalapathi', 'SkipForward')
        except:
            return (False, _('Error skipping playlist forward'))

        self._device_sync_playback_status()
        return (True, _('Playback skipped forward'))

    def playback_skip_backward(self):
        """
        The Skip Backward command will skip to the first frame of the next
        CPL in the currently loaded SPL
        Returns:
            response -- the response code received from the server
        """
        try:
            self.execute('Dalapathi', 'SkipBack')
        except:
            return (False, _('Error skipping playlist backwards'))

        self._device_sync_playback_status()
        return (True, _('Playback skipped backwards'))

    def playback_set_mode(self, mode):
        """
            Enables/Disables Schedule or Playback mode
        """
        response = ''
        if mode in self.supported_modes['loop_modes']:
            if mode == 'loop':
                self.execute('Dalapathi', 'SetLoopPlayBack', params={'isLoopPlayBack': 'true'})
            elif mode == 'do_not_loop':
                self.execute('Dalapathi', 'SetLoopPlayBack', params={'isLoopPlayBack': 'false'})
        elif mode in self.supported_modes['schedule_modes']:
            if mode == 'schedule_on':
                scheduleMode = 'AUTOMATIC'
                response = self.execute('Schedule', 'SetScheduleMode', params={'scheduleMode': scheduleMode})
            elif mode == 'schedule_off':
                scheduleMode = 'MANUAL'
                response = self.execute('Schedule', 'SetScheduleMode', params={'scheduleMode': scheduleMode})
        if response == 'false':
            return (False, _('Error setting playback mode'))
        else:
            return (True, _('Playback mode set to %s') % mode)

    def get_automation_list(self):
        """
        gets automation uuid list of a device
        
        @return
            {
                automation_uuid_list    -LIST of UUIDs
                error_messages          -LIST of errors
            }
        
        """
        output = {'error_messages': [],
         'automation_uuid_list': []}
        cue_list = self.get_automations()
        output['automation_uuid_list'] = [ cue['id'] for cue in cue_list ]
        return output

    def get_automation_information(self, automation_uuids):
        """
        This recieves information for given cue in the system
        
        @param      automation_uuids   - list of cue uuids we want information for
        @return     {
                        automation_information_dict:
                            {
                                automation_uuid:
                                {
                                    duration    - INTEGER seconds
                                    name        - STRING
                                    type        - STRING [cue, trigger, volume, ... ] (theres a few more comign in wtih gdc/qube)
                                }
                            }
                        error_messages - LIST of errors
                    }
        """
        output = {'error_messages': [],
         'automation_info_dict': {}}
        for automation_id in automation_uuids:
            automation = self.get_automation(automation_id)
            if automation:
                output['automation_info_dict'][automation_id] = {}
                output['automation_info_dict'][automation_id]['duration'] = automation['duration']
                output['automation_info_dict'][automation_id]['name'] = automation['name']
                output['automation_info_dict'][automation_id]['type'] = automation['type']
            else:
                output['error_messages'].append(_('Error getting automation information for automation with id %s') % automation_id)

        return output

    def get_automation(self, automation_id):
        cue_info = None
        for cue in self.get_automations():
            if cue['id'] == automation_id:
                cue_info = cue

        return cue_info

    def get_automations(self):
        cues = self.execute('Dalapathi', 'GetCueList', list_tags=['Cue'])
        output = []
        for cue in cues['Cue']:
            output.append({'id': cue['ID'],
             'name': cue['ID'],
             'parameterized': 0,
             'duration': 0,
             'action': cue['ID'],
             'response': 0,
             'type': 'cue'})

        return output

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        raise NotImplementedError

    def get_schedule_id_list(self):
        """
        Returns a list of schedule ids that are on the server
        
        PARAMS: time_begin - string, start date for retrieval in the format strptime(%Y-%m-%d %H:%M)
                time_end - string, end date of retrieval in the format strptime(%Y-%m-%d %H:%M)
        RETURNS: {'response': 0/1
                  'schedule_id_list': [list of string schedule ids]
                 }
        """
        output = {'error_messages': []}
        time_begin_timestamp = time.time() - 1209600
        time_end_timestamp = time.time() + 31536000
        time_begin = str(datetime.fromtimestamp(time_begin_timestamp))
        time_end = str(datetime.fromtimestamp(time_end_timestamp))
        time_begin = time_begin[:19]
        time_end = time_end[:19]
        start_time = datetime.strptime(time_begin, '%Y-%m-%d %H:%M:%S')
        start_time = datetime.strftime(start_time, '%Y-%m-%dT%H:%M:%S')
        end_time = datetime.strptime(time_end, '%Y-%m-%d %H:%M:%S')
        end_time = datetime.strftime(end_time, '%Y-%m-%dT%H:%M:%S')
        schedules = self.execute('Schedule', 'GetSchedules', params=[{'startTime': start_time}, {'endTime': end_time}], list_tags=['guid'])
        output['schedule_id_list'] = schedules.get('guid', []) if schedules is not None else []
        return output

    def get_schedule_information(self, schedule_ids):
        """
        Returns schedule info for a given schedule id
        
        PARAMS:  schedule_id - the id of the schedule to retrieve
        RETURNS: {'response': 0/1, if response ==1 all other keys are optional
                  'error': OPTIONAL error message
                  'spl_id': string, id of the spl which will be shown
                  'time_begin': string, time the schedule will start, in format  YYYY-MM-DD HH:MM
                  'spl_name': string, name of the spl that will play
                  }
        """
        output = {'error_messages': [],
         'schedule_info_dict': {}}
        for schedule_id in schedule_ids:
            try:
                detail = self.execute('Schedule', 'GetScheduleDetails', params={'scheduleUUID': {'ns1:guid': schedule_id}})
                if detail.get('ScheduleDetail'):
                    detail = detail['ScheduleDetail']
                    showtime = datetime.strptime(detail['ShowTime'], '%Y-%m-%dT%H:%M:%S')
                    showtime_posix = time.mktime(showtime.timetuple())
            except Exception:
                output['error_messages'].append(_('Error getting scheduling information for ID: %s') % schedule_id)
            else:
                if detail['SPLUUID'] != '00000000-0000-0000-0000-000000000000':
                    output['schedule_info_dict'][schedule_id] = {}
                    output['schedule_info_dict'][schedule_id]['device_playlist_uuid'] = detail['SPLUUID']
                    output['schedule_info_dict'][schedule_id]['start_time'] = showtime_posix
                    output['schedule_info_dict'][schedule_id]['device_schedule_id'] = schedule_id

        return output

    def scheduling_delete(self, schedule_id):
        """
         The DeleteSchedule command will delete a schedule from the internal scheduler database.
        
        Returns
                    response    -- the response code from server
        """
        result = self.execute('Schedule', 'DeleteSchedule', params={'scheduleUUID': schedule_id})
        if result == 'true':
            return (True, _('Schedule deleted'))
        else:
            return (False, _('Error deleting schedule'))

    def scheduling_schedule_playlist(self, playlist_id, timestamp):
        """
        Schedules a playlist to playback on a device for a list of date times.
        @param playlist_id              STRING - playlist identifier, playlist to be scheduled
        @param timestamp                LIST[FLOAT] - list of datetimes to schedule the playlist in posix timestamp format
        """
        spl_title = self.playlist_information[playlist_id]['title']
        start_time = datetime.fromtimestamp(timestamp)
        start_time = datetime.strftime(start_time, '%Y-%m-%dT%H:%M:%S')
        schedule_id = self.execute('Schedule', 'AddSchedule', params=[{'splUUID': playlist_id}, {'showTime': start_time}])
        if schedule_id is not None:
            return (True, _('Playlist %s has been scheduled for %s') % (spl_title, format_timestamp(timestamp)), {'device_playlist_uuid': playlist_id,
              'start_time': timestamp,
              'device_schedule_id': str(schedule_id)})
        else:
            return (False, _('Unknown error scheduling playlist %s at %s') % (spl_title, format_timestamp(timestamp)), None)

    def get_logs(self, start_datetime):
        output = {'error_messages': [],
         'xml': None}
        end_datetime = start_datetime + timedelta(days=1)
        dt_format = '%Y-%m-%dT%H:%M:%S'
        xml = self.execute('Log', 'GetSecurityLog', params=[{'from': start_datetime.strftime(dt_format)}, {'to': end_datetime.strftime(dt_format)}])
        if len(self.device_information.get('dnqualifiers', [])) > 0:
            root = parse_xml(xml.encode('utf-8'))
            device_id = root.findtext('.//{http://www.smpte-ra.org/schemas/433/2008/dcmlTypes}DeviceIdentifier')
            if device_id not in self.device_information.get('dnqualifiers'):
                elements = root.findall('.//{http://www.smpte-ra.org/schemas/433/2008/dcmlTypes}DeviceIdentifier')
                for element in elements:
                    element.text = self.device_information.get('dnqualifiers')[0]

            xml = write_xml(root)
        else:
            raise Exception('No dnqualifiers')
        output['xml'] = xml
        return output

    def get_disk_usage(self):
        """
        Retrieves disk usage statistics from the server.
        Returns:
                    response    -- the response code from the server
                    total_size    -- the size of the data disk available for storage
                    used        -- the data disk in use
                    available    -- the amount of available space on the data disk
        """
        storage = self.execute('Usher', 'GetStorageInfo')
        response = {}
        total = int(storage['Total']) * 1024 * 1024 * 1024
        free = int(storage['Free']) * 1024 * 1024 * 1024
        used = total - free
        response['total_size'] = str(total)
        response['used'] = str(used)
        response['available'] = str(free)
        return response

    def get_raid_status(self):
        """
        Returns raid status for this screen server
        
        RETURNS: {'response': 0/1,
                  'error': '' OPTIONAL error message
                  'list': [list of infos about the server's raid arrays in the format
                           {'name': 'a name',
                            'active': True/False,
                            'degraded': True/False,
                           }
                          ] OPTIONAL if response == 1
                 }
        """
        raid_status = self.execute('Catalog', 'GetRAIDStatus')['Status']
        active = False
        degraded = False
        if raid_status in ('Degraded', 'Normal'):
            active = True
        if raid_status in ('Unknown', 'Failed', 'Degraded', 'Rebuild', 'Migration', 'Backup', 'RebuildSuspended'):
            degraded = True
        return {'list': [{'name': 'Media Hard drive',
                   'active': active,
                   'degraded': degraded}]}

    def reboot(self):
        """
        restarts qube
        """
        try:
            self.execute('Dalapathi', 'Stop')
        except:
            pass

        self.execute('Maintenance', 'Restart')
        return {'type': 'success',
         'message': _('Rebooting')}

    def get_ingest_path(self, uuid):
        try:
            ingest_path = self.execute('Asset', 'GetAssetUri', params=[{'assetType': 'CPL'}, {'assetUUID': uuid}])
            ingest_path = '/' + re.sub('.*:.*?/', '', ingest_path)
            return ingest_path
        except:
            return None

        return None

    def __GetInHMSMS(self, seconds):
        """
            Convert seconds to timestamp string in the format 00:00:00
        """
        hours = seconds / 3600
        seconds -= 3600 * hours
        minutes = seconds / 60
        seconds -= 60 * minutes
        milliseconds = 0
        return '%02d:%02d:%02d:%03d' % (hours,
         minutes,
         seconds,
         milliseconds)

    def __GetInSeconds(self, HMS_string):
        """
            Convert seconds to timestamp string in the format 00:00:00
        """
        if HMS_string and not HMS_string.startswith('-'):
            t = datetime.strptime(HMS_string, '%H:%M:%S')
            hours = t.hour * 3600
            minutes = t.minute * 60
            seconds = t.second
            return hours + minutes + seconds
        else:
            return 0
# okay decompyling ./core/devices/sms/qube/qube.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:56 CST
