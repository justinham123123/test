# 2017.08.13 21:49:56 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\qube\qube_utils.py
"""
Qube Utilities
"""
from serv.lib.network.soap_utils import SOAPClient
from serv.lib.utilities.xml_utils import iterparse_xml, node_to_dict

class QubeSOAPClient(SOAPClient):

    def __init__(self, *args, **kwargs):
        super(QubeSOAPClient, self).__init__(*args, **kwargs)

    def parse_response(self, response, method = None, list_tags = None):
        result_tag = '{0}{1}'.format(method, 'Result')

        def loop_function(event, element, loop_vars, tree = None):
            if event == 'start':
                if element.tag.endswith(result_tag) and tree:
                    loop_vars['result'] = node_to_dict(tree, list_tags=list_tags)
                elif element.tag.endswith('Fault') and tree:
                    self.fault(tree)
            element.clear()
            return loop_vars

        parsed_response = iterparse_xml(response, loop_function, {})
        if 'fault' in parsed_response:
            return parsed_response
        else:
            return parsed_response.get('result')
# okay decompyling ./core/devices/sms/qube/qube_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:56 CST
