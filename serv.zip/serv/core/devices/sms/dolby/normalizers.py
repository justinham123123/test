# 2017.08.13 21:49:33 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\dolby\normalizers.py
from serv.core.devices.base.normalizer import DefaultNormalizer

class DolbyNormalizer(DefaultNormalizer):

    def __init__(self):
        super(DolbyNormalizer, self).__init__()
        self.add_extension('raid_array_healthy', ['raid'], self.extend_raid_array_healthy)
        self.add_extension('storage_space', ['storage_used', 'storage_total'], self.extend_storage_space)

    def extend_raid_array_healthy(self, raid):
        healthy = [ d.get('healthy') for d in raid ]
        return all(healthy)
# okay decompyling ./core/devices/sms/dolby/normalizers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:33 CST
