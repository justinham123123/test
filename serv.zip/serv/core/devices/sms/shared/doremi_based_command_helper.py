# 2017.08.13 21:49:56 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\shared\doremi_based_command_helper.py
from array import array
from serv.lib.utilities.utils import word_2_byte_array, byte_array_2_word
_id_iterator = 0

def parse_length(length_message):
    """ Parses the byte length from the length portion of a message """
    return byte_array_2_word('\x00' + length_message[1:])


def construct_request(command, data):
    """ Constructs a Doremi server API request """
    message = construct_message_header(command[0])
    if command[2]:
        request_data = command[2](data)
        message_length = len(request_data)
    else:
        request_data = None
        message_length = 0
    message.extend(construct_length(message_length))
    message.extend(construct_request_id())
    if request_data:
        message.extend(request_data)
    return message


def receive_bytes(s, size, server_name = None):
    """
    Receive a known length of bytes from a socket
    """
    result = ''
    while len(result) < size:
        data = s.recv(size - len(result))
        if not data:
            raise IOError('Socket closed unexpectedly')
        result += data
        if len(result) == size:
            return result
        if len(result) > size:
            raise Exception('Received more than the defined data length from the %s server' % server_name)


def construct_message_header(request_byte_header):
    """
    Constructs the message header (what they call the Messages Fixed
    Length Packs Key)
    """
    object_identifier = 6
    label_size = 14
    designator_1 = 43
    designator_2 = 52
    registry_category_designator = 2
    registry_designator = 5
    structure_designator = 1
    version_number = 10
    item_designator = 14
    organisation = 16
    application = 1
    structure_version = 1
    structure_kind = 1
    return array('B', (object_identifier,
     label_size,
     designator_1,
     designator_2,
     registry_category_designator,
     registry_designator,
     structure_designator,
     version_number,
     item_designator,
     organisation,
     application,
     structure_version,
     structure_kind,
     request_byte_header[0],
     request_byte_header[1],
     request_byte_header[2]))


def construct_length(data_size = 0):
    """ Constructs a length portion of a message """
    byte_length = word_2_byte_array(data_size + 4)
    return array('B', (131,
     byte_length[1],
     byte_length[2],
     byte_length[3]))


def construct_request_id():
    """ Constructs a request id """
    global _id_iterator
    _id_iterator = (_id_iterator + 1) % 255
    return word_2_byte_array(_id_iterator)
# okay decompyling ./core/devices/sms/shared/doremi_based_command_helper.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:57 CST
