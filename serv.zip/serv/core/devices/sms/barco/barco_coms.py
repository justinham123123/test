# 2017.08.13 21:49:20 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\barco\barco_coms.py
"""
Barco Utilities
"""
from serv.lib.network.soap_utils import SOAPClient, SOAPError
from serv.lib.utilities.xml_utils import iterparse_xml, node_to_dict
from serv.core.devices.sms.barco.barco_errors import barco_errors

class BarcoSOAPClient(SOAPClient):

    def __init__(self, *args, **kwargs):
        super(BarcoSOAPClient, self).__init__(*args, **kwargs)

    def post_connect_process(self):
        self.request(path='/sms/sms_1', method='Login', soap_action='http://www.barco.com/sms/sms_1/Login', namespaces={'ns0': 'http://www.barco.com/sms/sms_1'}, params={'userName': self.username,
         'password': self.password})

    def parse_response(self, response, method = None, list_tags = None):
        result_tag = '{0}{1}'.format(method, 'Result')

        def loop_function(event, element, loop_vars, tree = None):
            if event == 'start':
                if element.tag.endswith(method + 'Response') and tree:
                    loop_vars = node_to_dict(tree, list_tags=list_tags)
            element.clear()
            return loop_vars

        parsed_response = iterparse_xml(response, loop_function, {})
        if parsed_response[method + 'Result'] != '0':
            error_code = parsed_response[method + 'Result']
            if error_code in barco_errors:
                fault_string = barco_errors[error_code]
            else:
                fault_string = 'Unknown Error occured [{error_code}]'.format(error_code=error_code)
            raise SOAPError({'faultstring': fault_string,
             'faultcode': error_code})
        return parsed_response


if __name__ == '__main__':
    client = BarcoSOAPClient('10.58.5.122', 43758, https=True, keep_alive=True, username='admin', password='Admin1234')
    client.default_namespaces = {'xmlns:soap': 'http://www.w3.org/2003/05/soap-envelope'}
    print client.request(path='/sms/sms_1', method='Login', soap_action='http://www.barco.com/sms/sms_1/Login', namespaces={'ns0': 'http://www.barco.com/sms/sms_1'}, params={'userName': 'admin',
     'password': 'Admin1234'})
    print client.request(path='/sms/sms_1', method='GetStorageStatus', soap_action='http://www.barco.com/sms/sms_1/GetStorageStatus', namespaces={'ns0': 'http://www.barco.com/sms/sms_1'})
# okay decompyling ./core/devices/sms/barco/barco_coms.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:20 CST
