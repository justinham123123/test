# 2017.08.13 21:49:17 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\sms\barco\barco.py
import os
import time
import httplib
import logging
import datetime
import uuid
import urllib
from xml.dom import minidom
from xml.etree.ElementTree import ElementTree, Element, SubElement, tostring, fromstring
from serv.lib.utilities import date_utils
from serv.lib.dcinema.parsers.certificate_parsers import parse_device_certificates
from serv.core.devices.base.scheduling import Scheduling
from serv.lib.dcinema.parsers.parsers import parse_cpl, parse_kdm
from serv.lib.network.soap_utils import SOAPError
from serv.core.devices.sms.barco.barco_coms import BarcoSOAPClient
from serv.core.devices.sms.barco.barco_errors import barco_errors
from serv.core.devices.sms.shared import trans
PLAYER_MODES = {'schedule_off': 0,
 'do_not_loop': 0,
 'schedule_on': 1,
 'loop': 2}
MAX_FAILURES = 3

class Barco(Scheduling):
    supported_modes = {'schedule_modes': ['schedule_on', 'schedule_off'],
     'loop_modes': ['do_not_loop', 'loop']}

    def __init__(self, id, device_info):
        super(Barco, self).__init__(id, device_info)
        self.ip = device_info['ip']
        self.port = device_info['port']
        self.device_info = device_info
        self.client = None
        self.initialize_coms()
        self.failures = 0
        return

    def initialize_coms(self):
        self.client = BarcoSOAPClient(self.ip, self.port, https=True, keep_alive=True, username=self.device_info['api_username'], password=self.device_info['api_password'])
        self.client.default_namespaces = {'xmlns:soap': 'http://www.w3.org/2003/05/soap-envelope'}
        self.stat = self.client.stat

    def execute(self, method, **kwargs):
        soap_action = 'http://www.barco.com/sms/sms_1/{0}'.format(method)
        namespaces = {'ns0': 'http://www.barco.com/sms/sms_1'}
        try:
            response = self.client.request('/sms/sms_1', method, soap_action, namespaces=namespaces, **kwargs)
        except (SOAPError, httplib.HTTPException) as e:
            self.failures += 1
            err = 'SOAP err: %s' % e if type(e) is SOAPError else 'HTTP error: %s - %s' % (e.__class__.__name__, e)
            logging.warn('Resetting Barco comms on [%s] due to [%s] execing [%s]', self.device_configuration['ip'], err, method)
            self.initialize_coms()
            time.sleep(3)
            if self.failures <= MAX_FAILURES:
                return self.execute(method, **kwargs)
            return (False, {'error_messages': [err]}, None)

        self.failures = 0
        return (True, {'error_messages': []}, response)
        return None

    def seconds_to_datetimestring(self, seconds):
        date = datetime.datetime.fromtimestamp(seconds)
        return date.isoformat()

    def get_device_status(self):
        """
        Returns the status of the device
        @return: {
            current_time      -    INT  epoch time stamp
            error_messages    -    LIST of STR errors executing the call
        }
        """
        ok, output, response = self.execute('GetMainStatus')
        if ok:
            output['current_time'] = date_utils.parse_date(response['status']['LocalTime'])
        return output

    def get_device_information(self):
        """
        Returns information regarding the device
        @return: {
            storage_available   -    INT bytes remaining
            storage_total       -    float bytes total
            storage_used        -    float bytes used
            raid_status': [
                {
                    status    -    STR 'error', ' TODO
                    message   -    STR 'Unknown'
                    name      -    STR  'MainStore'
                }, ...
            ]
            dnqualifiers      -    LIST of all dnqualifiers for the certificate chain. #KOEBO: moet gedaan worden max
            serial            -    STR serial number
            error_messages    -    LIST of STR
            model             -    STR model of the Server (i.e dss200, ...)
            device_dnqualifier  -  STR leaf dnqualifier, eg. 'Gio9Szty8daEiFpFUVMv2uiackk=' #KOEBO: moet
            product_certificates-   DICT: {
                STR (TODO) : STR (CERTIFICATE)
            }
            software_version   -    STR software version
            firmware_version   -    STR firmware version
        }
        
        Barco storage structure
        {
            "RebuildProgression": "42",
            "TotalSizeInBytes": "126826287104",
            "State": "Rebuilding",
            "UsedSizeInBytes": "113289015296",
            "Error": "0"
        }
        """
        output = {'error_messages': [],
         'dnqualifiers': [],
         'device_dnqualifier': None,
         'product_certificates': {},
         'storage_total': None,
         'storage_used': None,
         'storage_available': None}
        ok1, output1, sorage_resp = self.execute('GetStorageStatus')
        if ok1:
            storage = sorage_resp['status']
            output['storage_available'] = int(storage['TotalSizeInBytes']) - int(storage['UsedSizeInBytes'])
            output['storage_total'] = float(storage['TotalSizeInBytes'])
            output['storage_used'] = float(storage['UsedSizeInBytes'])
            if storage['State'] == 'Healthy':
                output['raid_status'] = [{'status': 'ok',
                  'message': barco_errors[storage['Error']] if storage['Error'] in barco_errors else trans.RAID_ok(),
                  'name': 'RAID 5 storage'}]
            else:
                output['raid_status'] = [{'status': 'error',
                  'message': barco_errors[storage['Error']] if storage['Error'] in barco_errors else storage['State'],
                  'name': 'RAID 5 storage'}]
        else:
            output['error_messages'].extend(output1['error_messages'])
        ok2, output2, product_resp = self.execute('GetProductInformation')
        if ok2:
            product = product_resp['productInfo']
            output['serial'] = product['SerialNumber']
            output['model'] = product['ProductName']
            output['software_version'] = product['Version']
            output['firmware_version'] = product['Version']
        else:
            output['error_messages'].extend(output2['error_messages'])
        ok3, output3, certificates = self.execute('GetCertificateList', list_tags=['CertificateInformation'])
        if ok3 and certificates['list']:

            def get_certificates():
                for certkind in certificates['list']['CertificateInformation']:
                    if certkind['Kind'] == 'icmp_id':
                        ok4, out4, resp = self.execute('GetCertificate', params={'certificateKind': certkind['Kind']})
                        if not ok4:
                            logging.error('Error getting Barco certs: %s', out4['error_messages'])
                            raise
                        yield resp['certificate']

            try:
                parsed_certificates = parse_device_certificates(get_certificates())
                output['dnqualifiers'] = parsed_certificates.get('dnqualifiers', [])
                output['device_dnqualifier'] = parsed_certificates.get('device_dnqualifier', None)
                output['product_certificates'] = parsed_certificates.get('product_certificates', {})
            except Exception:
                pass

        else:
            output['error_messages'].extend(output3['error_messages'])
        return output

    def reboot(self):
        """
        Reboots the device
        @return: {
            error_messages    -    LIST errors executing the reboot
        }
        """
        ok, output, response = self.execute('Reboot', params={'options': ''})
        return output

    def test_management_connection(self):
        """
        Checks that the communication method used to interact with the device is functioning correctly
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('GetCurrentUser')
        if ok:
            return (True, trans.SOCKET_ok())
        else:
            return (False, output['error_messages'][0])

    def get_key_uuid_list(self):
        """
        Returns key uuid list of a device
        
        @return
        dict
            key_uuid_list - LIST of UUIDs
            error_messages - LIST of errors
        """
        ok, output, response = self.execute('GetKdmList', list_tags=['KdmInformation'])
        if ok:
            output['key_uuid_list'] = [ kdminfo['Id'] for kdminfo in response['list']['KdmInformation'] ] if response['list'] else []
        return output

    def get_key_information(self, key_uuids):
        r"""
        gets key information of a device
        
        @return
            dict
                key_info_dict        DICT
                    <key_uuid>
                        cpl_title           STRING
                        cpl_uuid            STRING (UUID)
                        not_valid_before    FLOAT datetime in posix timestamp format
                        not_valid_after     FLOAT datetime in posix timestamp format
                        dnqualifier         STRING
                error_messages          -LIST of errors
        
        Barco kdm structure
        {
            "Namespace": "http://www.smpte-ra.org/schemas/430-3/2006/ETM",
            "IngestRemainingSizeInBytes": "0",
            "NotValidAfter": "2028-09-19T22:00:00Z",
            "Title": "2K FM Application Constraints 2.1.8 (\u00a7\u00b6\u00f8)",
            "TimeWindow": {
                "NotValidBefore": "2013-09-19T22:00:00Z",
                "NotValidAfter": "2028-09-19T22:00:00Z"
            },
            "NotValidBefore": "2013-09-19T22:00:00Z",
            "IngestDate": "2014-01-20T12:12:50Z",
            "TotalSizeInBytes": "13400",
            "State": "Idle",
            "AnnotationText": "2K FM Application Constraints 2.1.8 (\u00a7\u00b6\u00f8) ~ KDM for XDC.SOLOG3.V5-1.00000001_chain.pem",
            "CplId": "f5094f89-e7e7-42bc-b900-3bb8e91a26e1",
            "Error": "0",
            "IssueDate": "2013-09-20T09:07:10Z",
            "Id": "d823dc56-0127-457e-8f61-c1ac9e47de82"
        }
        """
        ok, output, response = self.execute('GetKdmList', list_tags=['KdmInformation'])
        output['key_info_dict'] = {}
        if ok and response['list']:
            for kdminfo in response['list']['KdmInformation']:
                if kdminfo['Id'] in key_uuids:
                    key_resp = self.get_key(kdminfo['Id'])
                    if not key_resp['xml']:
                        continue
                    kdm = parse_kdm(key_resp['xml'], load_from_file=False)
                    kdmdict = {}
                    kdmdict['cpl_title'] = kdminfo['Title']
                    kdmdict['cpl_uuid'] = kdminfo['CplId']
                    kdmdict['not_valid_before'] = date_utils.parse_date(kdminfo['NotValidBefore'])
                    kdmdict['not_valid_after'] = date_utils.parse_date(kdminfo['NotValidAfter'])
                    kdmdict['status'] = 'ok'
                    kdmdict['dnqualifier'] = kdm['dn_qualifier']
                    kdmdict['device_serial_number'] = kdm['device_serial_number']
                    output['key_info_dict'][kdminfo['Id']] = kdmdict

        return output

    def get_key(self, key_uuid):
        """
        gets key xml
        
        @return
            dict
                xml                    STRING
                error_messages         LIST of errors
        """
        ok, output, key = self.execute('GetKdm', params={'id': key_uuid})
        output['xml'] = key['data'] if ok else {}
        return output

    def get_transfer_ids(self):
        """
        Gets all the transfer ids in the system,
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                <server_transfer_id>   STRING - id of this transfer, used for cancelling transfers
                            ]
                        error_messages:         LIST - list of errors that occurred during getting this information
                    }
        
        Barco IngestJobStatus structure
        {
            "ItemId": "a31ad144-604e-4a20-8fe2-482d77a41a91",
            "StartDate": "2014-03-19T18:24:24Z",
            "EndDate": "2014-03-19T18:24:24Z",
            "ExternalStorageUrl": "local:./externalContent/Kinds",
            "Title": "FEATURE_FTR_F_BE_51_2K_20120712",
            "IngestTotalSizeInBytes": "11232",
            "IngestRemainingSizeInBytes": "0",
            "State": "Completed",
            "Error": "0",
            "Issuer": "admin",
            "IssueDate": "2014-03-19T18:24:23Z",
            "Id": "439e3b12-106a-4652-ad35-ec46a05f6fa6",
            "ItemType": "CPL"
        }
        """
        ok, output, response = self.execute('GetIngestJobList', list_tags=['IngestJobStatus'])
        if ok:
            output['transfers'] = [ ingest_job['Id'] for ingest_job in response['list']['IngestJobStatus'] ] if response['list'] else []
        return output

    def get_transfer_info(self, transfer_ids):
        """
        Gets all information for specified transfers
        
        @return {
            transfers               LIST of DICTs of
                {
                    server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                    state          STRING      - 'initialising', 'queued on server', 'active', 'paused', 'cancelled', 'success', 'failure'
                    description    STRING      - description of the transfer, ie content title
                    type           STRING      - cpl, kdm...
                    content_id       STRING      - transferring cpl
                    source         STRING      - source this can be an ip address or a description (ie local disk)
                    progress       INTEGER     - % transfer complete
                    message        STRING      - a message elaborating on the transfer_state ('ingest was paused at 15:00')
                    *start_time     STRING      - Start time of the transfer
                    *end_time       STRING        - End time of the transfer
                }
            error_messages:         LIST        - list of errors that occurred during getting this information
        }
        
        Barco IngestJobStatus structure
        {
            "ItemId": "a31ad144-604e-4a20-8fe2-482d77a41a91",
            "StartDate": "2014-03-19T18:24:24Z",
            "EndDate": "2014-03-19T18:24:24Z",
            "ExternalStorageUrl": "local:./externalContent/Kinds",
            "Title": "FEATURE_FTR_F_BE_51_2K_20120712",
            "IngestTotalSizeInBytes": "11232",
            "IngestRemainingSizeInBytes": "0",
            "State": "Completed",
            "Error": "0",
            "Issuer": "admin",
            "IssueDate": "2014-03-19T18:24:23Z",
            "Id": "439e3b12-106a-4652-ad35-ec46a05f6fa6",
            "ItemType": "CPL"
        }
        """

        def interpret_state(barco_state):
            if barco_state == 'Pending':
                return 'queued_on_device'
            if barco_state == 'Running':
                return 'active'
            if barco_state == 'Completed':
                return 'success'
            if barco_state == 'Failed':
                return 'failed'
            if barco_state == 'Canceled':
                return 'cancelled'
            if barco_state == 'Blocked':
                return 'paused'
            if barco_state == 'None':
                return 'queued_on_device'

        ok, output, response = self.execute('GetIngestJobList', list_tags=['IngestJobStatus'])
        transfers = []
        if ok and response['list']:
            for job in response['list']['IngestJobStatus']:
                if job['Id'] in transfer_ids:
                    total_size = float(job['IngestTotalSizeInBytes'])
                    completed_size = total_size - float(job['IngestRemainingSizeInBytes'])
                    if total_size > 0:
                        progress = int(completed_size / total_size * 100)
                    else:
                        progress = 100
                    if job['EndDate'] == '0':
                        end_time = 0
                    else:
                        end_time = date_utils.parse_date(job['EndDate'])
                    transfers.append({'server_transfer_id': job['Id'],
                     'state': interpret_state(job['State']),
                     'description': job['Title'],
                     'type': job['ItemType'],
                     'content_id': job['ItemId'],
                     'source': job['ExternalStorageUrl'],
                     'progress': progress,
                     'message': '',
                     'start_time': date_utils.parse_date(job['StartDate']),
                     'end_time': end_time})

        output['transfers'] = transfers
        return output

    def get_content_uuid_list(self):
        """
        gets content uuid list of a device
        
        @return
            {
                content_uuid_list       -LIST of UUIDs
                error_messages          -LIST of errors
            }
        """
        ok, output, response = self.execute('GetCplList', list_tags=['CplInformation'])
        if ok:
            output['content_uuid_list'] = [ cplinfo['Id'] for cplinfo in response['list']['CplInformation'] ] if response['list'] else []
        return output

    def get_content_information(self, content_uuids):
        """
        gets content information of a device
        
        @type content_uuids:LIST
        @param   content_uuids: list of cpl uuids we want information for
        @return {
                    content_info_dict:        DICT
                        {
                            content_uuid: {
                                content_title_text  STRING
                                content_kind        STRING
                                edit_rate           [INT, INT]
                                subtitled           BOOL
                                subtitle_language   STRING
                                aspect_ratio        STRING
                                duration_in_seconds INT
                                duration_in_frames  INT
                                encrypted           BOOL
                                video_encoding      String (UNKNOWN, JPEG2000, MPEG2, PCM)
                                playback_mode       String (2D, 3D)
                                xml                 STRING xml file
                                parsed_info         DICT Parsed from the content title text,
                                       rating        None |STR
                                       package_type  None |STR
                                       narrative_description_language None | STR
                                       content_title None | STR
                                       facility      None | STR
                                       subtitle_language : None | STR
                                       audio_type    LIST of STR
                                       resolution    None | STR
                                       date          None | STR
                                       studio        None | STR
                                       audio_language None | STR
                                       playback_mode None | STR
                                       subtitled     BOOL
                                       aspect_ratio  None | STR
                                       ghostbusting  None | STR
                                       territory     None | STR
                                       content_kind  None | STR
                                       motion_simulator_format None | STR
                            }
                    error_messages          -LIST of errors
                }
        
        Barco cplinfo structure
        {
            "MainSoundLanguage": "en",
            "Title": "JOHN SMITHSD_ADV",
            "Namespace": "http://www.digicine.com/PROTO-ASDCP-CPL-20040511#",
            "State": "Idle",
            "ScreenAspectRatio": "185 100",
            "IngestDate": "2014-03-20T15:47:06Z",
            "MainSubtitleLanguage": null,
            "MainPictureEditRateNumerator": "24",
            "DurationInMilliseconds": "30083",
            "IngestRemainingSizeInBytes": "0",
            "TotalSizeInBytes": "369485585",
            "ContentVersionId": "urn:uri:817ad8a1-02ad-46c9-9790-f0d3ad5702f4_2013-12-12T17:09:14",
            "TimeWindows": null,
            "MainPictureActiveHeight": "1080",
            "MainPictureEncoding": "Jpeg2000",
            "RemoteStorage": "/barco/SmsSimulatorPackage/localContentStorage/CPL/817ad8a1-02ad-46c9-9790-f0d3ad5702f4.xml",
            "MainSoundSamplingFrequencyInHerz": "48000",
            "MainPictureActiveWidth": "1998",
            "IsEncrypted": "true",
            "Error": "0",
            "ContentKind": "Advertisement",
            "IssueDate": "2013-12-12T17:09:14Z",
            "MainSoundConfiguration": "NONE",
            "Creator": "Arts Alliance Media TMS",
            "MainPictureEditRateDenominator": "1",
            "DurationInFrames": "722",
            "MaturityRatings": null,
            "MainCaptionLanguage": null,
            "AnnotationText": "JOHN SMITHSD_ADV",
            "MainSoundChannelCount": "6",
            "Issuer": "Arts Alliance Media",
            "Integrity": "Valid",
            "Id": "817ad8a1-02ad-46c9-9790-f0d3ad5702f4",
            "ContentVersionLabelText": "817ad8a1-02ad-46c9-9790-f0d3ad5702f4_2013-12-12T17:09:14"
        }
        """

        def _parseEncoding(MainPictureEncoding):
            video_encoding = MainPictureEncoding
            playback_mode = '2D'
            if MainPictureEncoding == 'Jpeg2000_Stereoscopic':
                video_encoding = 'Jpeg2000'
                playback_mode = '3D'
            return {'video_encoding': video_encoding.upper(),
             'playback_mode': playback_mode}

        ok, output, response = self.execute('GetCplList', list_tags=['CplInformation'])
        content_info_dict = {}
        if ok and response['list']:
            for cplinfo in response['list']['CplInformation']:
                if cplinfo['Id'] in content_uuids:
                    ok, out, xml = self.execute('GetCpl', params={'id': cplinfo['Id']})
                    if not ok:
                        output['error_messages'].extend(out['error_messages'])
                        continue
                    encoding = _parseEncoding(cplinfo['MainPictureEncoding'])
                    temp_cpl = parse_cpl(xml['data'], load_from_file=False)
                    cplDict = {'content_title_text': cplinfo['Title'],
                     'content_kind': cplinfo['ContentKind'],
                     'edit_rate': [int(cplinfo['MainPictureEditRateNumerator']), int(cplinfo['MainPictureEditRateDenominator'])],
                     'subtitled': bool(cplinfo['MainSubtitleLanguage']) if 'MainSubtitleLanguage' in cplinfo else False,
                     'subtitle_language': cplinfo['MainSubtitleLanguage'] if 'MainSubtitleLanguage' in cplinfo else '',
                     'aspect_ratio': cplinfo['ScreenAspectRatio'],
                     'duration_in_seconds': int(cplinfo['DurationInMilliseconds']) / 1000,
                     'duration_in_frames': int(cplinfo['DurationInFrames']),
                     'encrypted': cplinfo['IsEncrypted'] == 'true',
                     'video_encoding': encoding['video_encoding'],
                     'playback_mode': encoding['playback_mode'],
                     'xml': xml['data'],
                     'parsed_info': temp_cpl['parsed_info']}
                    content_info_dict[cplinfo['Id']] = cplDict

        output['content_info_dict'] = content_info_dict
        return output

    def get_content_validation_information(self, content_uuids):
        """
        Returns device specific content information e.g. validation state, ingest path etc.
        
        @type content_uuids:LIST
        @param   content_uuids: list of cpl uuids we want information for
        @return {
            content_validation_dict   DICT
                <content_uuid>        DICT
                    validation_code   INT (see below)
                    ingest_path       STR (relative to ftp root)
                    cpl_size          INT (bytes)
            error_messages            LIST of STR
        }
        
        Example usage::
        
            device.get_content_validation_information(["870c714f-678c-4069-ba92-7913e286912b"])
        
        Example response::
        
            {
              "content_validation_dict": {
                "870c714f-678c-4069-ba92-7913e286912b": {
                  "validation_code": 0,
                  "ingest_path": "/870c714f-678c-4069-ba92-7913e286912b/870c714f-678c-4069-ba92-7913e286912b.xml",
                  "cpl_size": 77876519
                }
              },
              "error_messages": [ ]
            }
        
        Validation Codes:
        ====  ===================================
        Code  Meaning
        ====  ===================================
        -1    Content doesn't exist on the device
        0     OK
        1     Content is missing assets
        2     Content is corrupt
        3     Content is ingesting
        4     Content is queued for ingest
        ==== ====================================
        """

        def interpret_validation(cplinfo):
            if cplinfo['Integrity'] == 'Valid':
                return 0
            if cplinfo['Integrity'] == 'Incomplete':
                return 1
            if cplinfo['Integrity'] == 'Corrupted':
                return 2
            if cplinfo['State'] == 'BeingIngested':
                return 3
            if cplinfo['Integrity'] == 'NotChecked':
                return 5
            logging.warn('UNKNOWN VALIDATION STATE for content on Barco: %s %s', cplinfo['State'], cplinfo['Integrity'])

        ok, output, response = self.execute('GetCplList', list_tags=['CplInformation'])
        content_validation_dict = {}
        if ok:
            cpllist = response['list']['CplInformation']
            available_ids = [ cplinfo['Id'] for cplinfo in cpllist ]
            if response['list']:
                for cplinfo in cpllist:
                    cplDict = {}
                    if cplinfo['Id'] in content_uuids:
                        cplDict['validation_code'] = interpret_validation(cplinfo)
                        cplDict['ingest_path'] = '/CPL/{id}.xml'.format(id=cplinfo['Id'])
                        cplDict['cpl_size'] = cplinfo['TotalSizeInBytes']
                        content_validation_dict[cplinfo['Id']] = cplDict

            for content_id in content_uuids:
                if content_id not in available_ids:
                    cplDict = {}
                    cplDict['validation_code'] = -1
                    cplDict['ingest_path'] = ''
                    cplDict['cpl_size'] = 0
                    content_validation_dict[content_id] = cplDict

        output['content_validation_dict'] = content_validation_dict
        return output

    def get_ingest_path(self, cpl_uuid):
        return '/CPL/%s.xml' % cpl_uuid

    def content_add_key(self, key):
        """
        Adds a list of keys to a device.
        
        @param key          xml_file      - kdm_xml
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('AddKdm', params={'data': key})
        if ok:
            return (True, trans.KDM_saved())
        else:
            return (False, output['error_messages'][0])

    def content_cancel_transfer(self, transfer_id):
        """
        Cancels a transfer on a device.
        
        @param transfer_id  STRING  - transfer identifier
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('AbortIngestJobs', params={'jobIdList': [{'string': transfer_id}]})
        if ok:
            return (True, trans.TRANSFER_cancelled())
        else:
            return (False, output['error_messages'][0])

    def content_clear_transfer_history(self):
        """
        Clears transfer history from a device.
        
        @param transfer_id  STRING  - transfer identifier
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('ClearIngestJobHistory')
        if ok:
            return (True, trans.TRANSFER_cleared())
        else:
            return (False, output['error_messages'][0])

    def content_delete(self, content_id):
        """
        Deletes the specified content from the device
        @param content_id              UUID - content identifiers
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('DeleteCpl', params={'id': content_id})
        if ok:
            return (True, trans.CPL_delete())
        else:
            return (False, output['error_messages'][0])

    def content_delete_key(self, key_id):
        """
        Deletes a key from a device.
        @param key_id                  UUID   - key identifiers
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('DeleteKdm', params={'id': key_id})
        if ok:
            return (True, trans.KDM_delete())
        else:
            return (False, output['error_messages'][0])

    def content_transfer(self, connection_details, description, cpl_uuid):
        """
        Ingests content onto the device.
        
        @param connection_details      DICT - Must include 'type' key along with type-specific details
                                              e.g. ftp ip, path, user, pass or local path
                                ftp_ip
                                ftp_port
                                ftp_username
                                ftp_password
                                ingest_path
        @param description             STRING - Human readable desc for the transfer i.e. content_title_text
        @param cpl_uuid                STRING - UUID of CPL to be transferred
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                    STR  (screen servers Tansfer ID)
                )
            e.g. return True, 'success', '12'
        """
        job = {}
        connection_details['ingest_path'] = os.path.dirname(connection_details['ingest_path'])
        url = 'ftp://{username}:{password}@{ip}:{port}/{path}'.format(username=connection_details['ftp_username'], password=connection_details['ftp_password'], ip=connection_details['ftp_ip'], port=connection_details['ftp_port'], path=urllib.quote(connection_details['ingest_path']))
        job['Id'] = ''
        job['Title'] = description
        job['ExternalStorageUrl'] = url
        job['ItemId'] = cpl_uuid
        job['ItemType'] = 'CPL'
        ok, output, response = self.execute('AddIngestJob', params={'jobToAdd': job})
        if ok:
            return (True, trans.TRANSFER_started(), response['jobId'])
        else:
            return (False, output['error_messages'][0], None)
            return None

    def content_validate(self, cpl_uuid):
        """
        Starts content validation on the device.
        -only should be for sony, other servers that require active content validation may also need to check this.
        
        @param cpl_uuid                STRING - UUID of CPL to be transferred
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('StartCplCheck', params={'id': cpl_uuid})
        if ok:
            return (True, trans.CPL_validate())
        else:
            return (False, output['error_messages'][0])

    def transfer_methods(self):
        """
        returns the transfer methods available: ftp and/or local. Default is just ftp
        """
        return ['ftp']

    def get_automation_list(self):
        """
        gets automation uuid list of a device
        @return
            {
                automation_uuid_list    -LIST of unique identifiers, sometimes these can just be the automation name
                error_messages          -LIST of errors
            }
        """
        ok, output, response = self.execute('GetCueList', list_tags=['CueInformation'])
        if ok:
            output['automation_uuid_list'] = [ cueinfo['Title'] for cueinfo in response['list']['CueInformation'] ] if response['list'] else []
        return output

    def get_automation_information(self, automation_uuids):
        """
        Get information for given cues in the system
        @param      automation_uuids   - list of cue uuids we want information for
        @return     {
                        automation_info_dict:
                            {
                                automation_uuid:
                                {
                                    duration    - INTEGER seconds
                                    name        - STRING
                                    type        - STRING [cue, trigger, volume, intermission]
                                        there are a few different types depending on the server
                                        sometimes these require specific integration
                                }
                            }
                        error_messages - LIST of errors
                    }
        
        Barco cue structure
        {
            "IconTag": "light000",
            "GroupTitle": "Lights",
            "IsAvailableToUser": "true",
            "IsAvailableToShowPlaylist": "true",
            "Title": "Lights 0%"
        }
        """
        ok, output, response = self.execute('GetCueList', list_tags=['CueInformation'])
        output['automation_info_dict'] = {}
        if ok and response['list']:
            output['automation_uuid_list'] = [ cueinfo['Title'] for cueinfo in response['list']['CueInformation'] ] if response['list'] else []
            for cueinfo in response['list']['CueInformation']:
                if cueinfo['Title'] in automation_uuids:
                    cueDict = {}
                    cueDict['duration'] = 0
                    cueDict['name'] = cueinfo['Title']
                    cueDict['type'] = 'cue'
                    output['automation_info_dict'][cueinfo['Title']] = cueDict

        return output

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        """
        Triggers/fires/activates a cue; throws an error if the cue is not supported
        @param cue_id                  STRING     - identifier for the cue
        @param parameterized           BOOL       - if the cue has a parameterised value
        @param parameterized_value     STRING?    - the parameterised value
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('TriggerCue', params={'id': cue_id})
        if ok:
            return (True, trans.AUTOMATION_trigger_s1() % cue_id)
        else:
            return (False, output['error_messages'][0])

    def has_unencrypted_logs(self):
        """
        Has separate unencrypted logs to collect, by default is false.
        Mainly for dolby log collection
        """
        return False

    def get_logs(self, start_datetime):
        """
        gets logs for a day
        @return
                {
                    xml      -log xml
                    error_messages          -LIST of errors
                }
        
        Barco example export status
        {
            "status": {
                "State": "Completed",
                "EndTime": "2014-03-26T15:48:03Z",
                "DocumentCount": "1",
                "StartTime": "2014-03-25T15:48:03Z",
                "Error": "0"
            },
            "GetSecureLogExportStatusResult": "0"
        }
        """

        def read_log():
            try:
                url = 'ftp://ftpseclog:icmp@%s:43750/smseclogs_0.xml' % self.ip
                ftp_response = urllib.urlopen(url)
                return ftp_response.read()
            except IOError:
                return ''

        start_date = start_datetime.isoformat()
        end_date = (start_datetime + datetime.timedelta(days=1)).isoformat()
        ok, output, response = self.execute('ExportSecureLog', params={'startDate': start_date,
         'endDate': end_date})
        if not ok:
            return output
        wait_limit = 50
        for wait_cycle in xrange(wait_limit):
            ok2, output2, response2 = self.execute('GetSecureLogExportStatus')
            if not ok2:
                output['error_messages'].extend(output2['error_messages'])
                break
            if response2['status']['State'] == 'Completed':
                output['xml'] = read_log()
                break
            time.sleep(3)

        return output

    def get_playback_status(self):
        r"""
        gets playback status of a server
        
        @return
            dict
                playback_state          -STRING (play|pause|stop|error)
                cpl_uuid                -STRING (UUID)
                spl_uuid                -STRING (UUID)
                spl_position            -INT of seconds into current spl
                spl_duration            -INT length of spl
                element_index           -INT index of current element
                element_id              -STRING (UUID)
                element_position        -INT of seconds into current element
                element_duration        -INT length of current element in seconds
                modes                   -DICT  containing all available modes and their state
                intermission            -BOOL
                error_messages          -LIST of errors
        
        Barco structure
        {
            "status": {
                "SelectionTimeWindows": {
                    "TimeWindowInformation": {
                        "NotValidBefore": "2014-04-02T00:00:00Z",
                        "NotValidAfter": "2029-04-03T00:00:00Z"
                    }
                },
                "CurrentClipFrameIndex": "0",
                "CurrentClipIndex": "0",
                "SelectionType": "Show",
                "SelectionHasEncryptedClips": "true",
                "SelectionId": "ed1cdbc7-e7d5-4d8b-9961-41d01d96178e",
                "Title": "Show with 2 encrypted clips AAM",
                "SelectionIntegrity": "Valid",
                "PlayerError": "0",
                "State": "Stopped",
                "CurrentPositionInMilliseconds": "0",
                "Mode": "Manual",
                "StartTime": "1970-01-01T00:00:00Z",
                "NextStepTitle": null,
                "CurrentClipTitle": "128 Reel Composition, "A" Series (Encrypted) 2.1.8 (\u00a7\u00b6\u00f8)",
                "CurrentClipEditRate": "24 1",
                "DurationInMilliseconds": "1280000",
                "NextStepCountdownInMilliseconds": "0",
                "CurrentClipId": "a098198f-00b4-49b6-b96f-abb2764f5b03"
            },
            "GetPlayerStatusResult": "0"
        }
        """

        def interpret_state(barco_state):
            if status['PlayerError'] != '0':
                return 'error'
            elif barco_state == 'Playing':
                return 'play'
            elif barco_state == 'Paused':
                return 'pause'
            else:
                return 'stop'

        ok, output, response = self.execute('GetPlayerStatus')
        if not ok:
            output['playback_state'] = 'error'
            return output
        else:
            status = response['status']
            editrate = status['CurrentClipEditRate'].split()
            element_duration = 0
            if status.get('CurrentClipId'):
                try:
                    ok, out, resp = self.execute('GetCplInformation', params={'id': status['CurrentClipId']})
                    current_cpl = resp['cplInformation']
                    element_duration = int(current_cpl['DurationInMilliseconds']) / 1000
                except Exception as e:
                    logging.warn('Barco err executing GetCplInformation for %s: %s. Setting element duration to 0', status['CurrentClipId'], e)

            output['playback_state'] = interpret_state(status['State'])
            output['cpl_uuid'] = status.get('CurrentClipId')
            output['spl_uuid'] = status['SelectionId']
            output['spl_position'] = int(status['CurrentPositionInMilliseconds']) / 1000
            output['spl_duration'] = int(status['DurationInMilliseconds']) / 1000
            output['element_index'] = int(status['CurrentClipIndex']) if status.get('CurrentClipIndex') else None
            output['element_id'] = status.get('CurrentClipId')
            output['element_position'] = int(status['CurrentClipFrameIndex']) / (int(editrate[0]) / int(editrate[1]))
            output['element_duration'] = element_duration
            output['modes'] = {'scheduler_enabled': status['Mode'] == 'Scheduled',
             'loop_mode': self.supported_modes['loop_modes'][status['Mode'] == 'ManualRepeat']}
            output['intermission'] = False
            output['error_messages'] = [barco_errors[status['PlayerError']]] if status['PlayerError'] in barco_errors else []
            if output['cpl_uuid'] == output['spl_uuid']:
                output.update(spl_uuid=None, spl_position=None, spl_duration=None, element_index=None)
            return output

    def playback_eject(self):
        """
        Ejects a loaded playlist from a device
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('Clear')
        if ok:
            return (True, trans.PLAYBACK_eject())
        else:
            return (False, output['error_messages'][0])

    def playback_load(self, playlist_id):
        """
        Loads a playlist on a device in preparation for playback.
        @param playlist_id            STRING    - playlist identifier
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('Select', params={'selectionType': 1,
         'selectionId': playlist_id})
        if ok:
            return (True, trans.PLAYBACK_load_s1())
        else:
            return (False, output['error_messages'][0])

    def playback_pause(self):
        """
        Pauses the currently playing playlist
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('Pause')
        if ok:
            return (True, trans.PLAYBACK_pause())
        else:
            return (False, output['error_messages'][0])

    def playback_play(self):
        """
        Starts playback of a loaded playlist
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('Play')
        if ok:
            return (True, trans.PLAYBACK_play())
        else:
            return (False, output['error_messages'][0])

    def playback_stop(self):
        """
        Stops playback
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('Stop')
        if ok:
            return (True, trans.PLAYBACK_stop())
        else:
            err = output['error_messages'][0]
            if 'ERROR_10900' in err:
                return (True, trans.PLAYBACK_stop_no_more())
            return (False, output['error_messages'][0])

    def is_stoppable(self):
        playback_state = self.device_get_playback_information()['playback_state']
        return playback_state != 'error'

    def playback_skip_forward(self):
        """
        Skips to the next item in the playlist
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        is_stopped = self.device_get_playback_information()['playback_state'] == 'stop'
        if is_stopped:
            ok, output, response = self.execute('GotoNextClip')
            if ok:
                return (True, trans.PLAYBACK_skip_fwd())
            else:
                return (False, output['error_messages'][0])
        else:
            return (False, trans.PLAYBACK_skip_err_must_stop())

    def playback_skip_backward(self):
        """
        Skips back to the previous item in the playlist
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        is_stopped = self.device_get_playback_information()['playback_state'] == 'stop'
        if is_stopped:
            ok, output, response = self.execute('GotoPreviousClip')
            if ok:
                return (True, trans.PLAYBACK_skip_bwd())
            else:
                return (False, output['error_messages'][0])
        else:
            return (False, trans.PLAYBACK_skip_err_must_stop())

    def playback_set_mode(self, mode):
        """
        Sets a mode on a device; a device might have multiple modes (i.e. scheduled & looping); throws an error if the mode is not supported
        @param mode   STRING    - mode identifier, check supported modes for more details.
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        
        Barco modes
            Manual 0            Manual mode where the user controls the player.
                                Scheduled shows will be ignored.
            Scheduled 1         Scheduled mode where the scheduled controls the player.
                                User commands will be rejected except for the resume command.
            ManualRepeat 2      Repeat mode where the user controls the player with an automatic restart of the show when reaching the end.
                                Scheduled shows will be ignored.
        """
        ok, output, response = self.execute('ChangeMode', params={'newMode': int(PLAYER_MODES[mode])})
        if ok:
            return (True, trans.PLAYBACK_mode_s1() % mode)
        else:
            return (False, output['error_messages'][0])

    def playback_interrupt_intermission(self):
        """
        Interrupts the current intermission on the device
        @param mode                   STRING    - mode identifier, check supported modes for more details.
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
        """
        return (False, trans.NOT_SUPPORTED())

    def validate_playlist(self, playlist_uuid):
        """
        Checks for SPL playback availability for "NOW"
        @param playlist_uuid - STR uuid of the playlist to check
        @return  DICT {
            info{
                result:           - INT
                    - 0 (spl should play)
                    - 1 (spl cannot play)
                error_code        -  INT
                    - 0 no error nor warning
                    - 2 spl is not registered on this server
                    - 3 spl is registered on this server but cannot be loaded
                    - 255 out of memory
                cpl_uuid         - STR cpl uuid of faulty item in the SPL, default ''
                description        STR
            }
            error_messages   - LIST of STR
        
        Barco Show structure
        {
            "IngestRemainingSizeInBytes": "0",
            "Title": "stinger avatar mystic",
            "Integrity": "Valid",
            "FeatureCplId": "00000000-0000-0000-0000-000000000000",
            "Id": "2fb99f5e-80ad-455f-9d17-b49afe390670",
            "IssueDate": "2014-01-28T12:47:52Z",
            "TimeWindows": null,
            "State": "Idle",
            "HasPlaceholderClips": "false",
            "IngestDate": "2014-03-25T11:45:48Z",
            "TotalSizeInBytes": "1132",
            "HasEncryptedClips": "false",
            "DurationInMilliseconds": "339708"
        }
        """
        info = {'result': 0,
         'error_code': 0,
         'description': '',
         'cpl_uuid': ''}
        should_play = False
        ok, output, response = self.execute('GetShowInformation', params={'id': playlist_uuid})
        if ok:
            show = response['showInformation']
            try:
                if show['Integrity'] != 'Incomplete':
                    if show['HasEncryptedClips'] == 'false':
                        should_play = True
                    elif show['TimeWindows'] != None:
                        not_valid_before = show['TimeWindows']['TimeWindowInformation']['NotValidBefore']
                        not_valid_after = show['TimeWindows']['TimeWindowInformation']['NotValidAfter']
                        before_seconds = date_utils.parse_date(not_valid_before)
                        after_seconds = date_utils.parse_date(not_valid_after)
                        if time.time() > before_seconds and time.time() < after_seconds:
                            should_play = True
            except Exception as e:
                if str(e) == 'ERROR_10502 - icmp - invalid command arguments - command rejected':
                    info['error_code'] = 2
                else:
                    raise

            info['result'] = int(not should_play)
        output['info'] = info
        return output

    def get_playlist_uuid_list(self):
        """
        gets playlist uuid list of a device
        
        @return
            dict
                playlist_uuid_list      -LIST of UUIDs
                error_messages          -LIST of errors
        """
        ok, output, response = self.execute('GetShowList', list_tags=['ShowInformation'])
        if ok:
            output['playlist_uuid_list'] = [ showinfo['Id'] for showinfo in response['list']['ShowInformation'] ] if response['list'] else []
        return output

    def get_playlist_information(self, playlist_uuids):
        """
        gets playlist information of a device
        
        @param      playlist_uuids   - list of playlist uuids we want information for
        @return
            dict
                playlist_info_dict        DICT
                    <playlist_uuid>
                        title               STRING
                        duration            INT in seconds
                        is_3d               BOOL
                        playlist            DICT
                            id                  STRING (playlist UUID)
                            title               STRING
                            text                STRING
                            is_3d               BOOL (3D playback mode for Doremi, for others normally means contains 3D CPL)
                            is_hfr              BOOL (HFR playback mode for Doremi, for others normally means contains HFR CPL)
                            is_4k               BOOL (4k playback mode for Doremi, for others normally means contains 4k CPL)
                            duration            FLOAT (total playlist duration in seconds)
                            events              LIST of DICT
                                id                  STRING (UUID of playlist event, may be generated by Core)
                                main_id             STRING (Doremi only, None for others)
                                cpl_id              STRING (UUID of CPL)
                                type                STRING ("composition" | "pattern")
                                text                STRING (content_title_text or similar for convenience)
                                duration_in_frames  INT
                                duration_in_seconds FLOAT
                                edit_rate           TUPLE[INT] e.g. (24, 1)
                                automation          DICT
                                    id                  STRING (ID of automation, might be UUID or name or action)
                                    name                STRING (human readable name, is often also the action)
                                    type                STRING ("cue" | "trigger" | "volume" | "wait_for_input")
                                    type_specific       DICT
                                        action              STRING (used in all; cue action to fire)
                                        offset_from         STRING ("start" | "end") (used in many)
                                        offset_in_frames    INT (used in many; offset in frames or delay in frames for "gdc_start_cue")
                                        offset_in_seconds   FLOAT (used in many; offset in frames or delay in frames for "gdc_start_cue")
                                        parameter           FLOAT (used in "volume"; parameter for parameterized cue)
                                        trigger             STRING (used in "trigger"; the input action required to trigger)
            error_messages                LIST[STRING] (error message strings)
        
            e.g.
            'f2bbd9ab-8521-47f8-a6c6-6561048ffba5': {
                'title': u'testing templating issues_08.19_12:31'
                'duration_in_seconds': 839.58333333333337,
                'is_3d': False,
                'is_4k': False,
                'is_hfr': False,
                'playlist': {'automation': [],
                             'duration_in_seconds': 839.58333333333337,
                             'events': [{'automation': [
                                         {
                                            "type": "cue",
                                            "id": "a3b971fc-ac16-4900-860e-144c1c6d2664",
                                            "type_specific": {
                                                "action": "CP To Format 11",
                                                "offset_in_frames": 0,
                                                "offset_in_seconds": 0,
                                                "offset_from": "start"
                                            },
                                            "name": "CP To Format 11"
                                        }
                                         ],
                                         'cpl_id': u'97e46ee2-c1c4-4daa-9c34-f39f05d8683e',
                                         'duration_in_frames': 20150.0,
                                         'duration_in_seconds': 839.58333333333337,
                                         'edit_rate': [24,
                                                       1],
                                         'id': u'072828c7-570b-381b-bda4-1027bebf997e',
                                         'main_id': u'c857a78d-c76b-4069-9ad2-40b8c4d936a7',
                                         'text': u'2012-10-14_14.30-14.59-On_The_Road-2D-S1 Part 1',
                                         'type': 'composition'}],
                             'id': u'f2bbd9ab-8521-47f8-a6c6-6561048ffba5',
                             'is_3d': False,
                             'is_4k': False,
                             'is_hfr': False,
                             'text': u'testing templating issues_08.19_12:31',
                             'title': u'testing templating issues_08.19_12:31'}
            },
        
        Barco show structure
        {
            "IngestRemainingSizeInBytes": "0",
            "Title": "TestShow",
            "Integrity": "Valid",
            "FeatureCplId": "00000000-0000-0000-0000-000000000000",
            "Id": "85cb0570-d700-443b-a262-643d416c0500",
            "IssueDate": "2014-03-17T03:37:52Z",
            "TimeWindows": null,
            "State": "Idle",
            "HasPlaceholderClips": "false",
            "IngestDate": "2014-03-17T03:37:55Z",
            "TotalSizeInBytes": "1321",
            "HasEncryptedClips": "false",
            "DurationInMilliseconds": "161125"
        },
        """

        def _get_cpl_info_from_id(cpl_id, show_cpl_list):
            for cpl in show_cpl_list:
                if cpl['Id'] == cpl_id:
                    return cpl

        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for playlist_uuid in playlist_uuids:
            ok, out, response = self.execute('GetShowAndCplList', params={'id': playlist_uuid}, list_tags=['CplInformation'])
            if not ok:
                output['error_messages'].extend(out['error_messages'])
                continue
            ok2, out2, response2 = self.execute('GetShowInformation', params={'id': playlist_uuid})
            if not ok2:
                output['error_messages'].extend(out2['error_messages'])
                continue
            show_info = response2['showInformation']
            show_xml = ElementTree(fromstring(response['data']))
            show_cpl_list = response['cplList']['CplInformation'] if 'cplList' in response and response['cplList'] else []
            is3D = False
            is_hfr = False
            is_4K = False
            events = []
            for cpl in show_xml.find('ClipList').findall('Clip'):
                event = {'id': None,
                 'main_id': None,
                 'cpl_id': None,
                 'type': None,
                 'text': None,
                 'duration_in_frames': None,
                 'duration_in_seconds': None,
                 'edit_rate': None,
                 'content_kind': None,
                 'automation': []}
                event_type = cpl.find('Type').text
                fps = 24
                if event_type == 'Placeholder':
                    logging.critical('Placeholder found in SPL. Unexpected. XML: %s', cpl)
                elif event_type == 'CPL':
                    cpl_id = cpl.find('Id').text
                    event['id'] = cpl_id
                    event['cpl_id'] = cpl_id
                    event['type'] = 'composition'
                    cpl_info = _get_cpl_info_from_id(cpl_id, show_cpl_list)
                    if cpl_info:
                        event['text'] = cpl_info['Title']
                        event['content_kind'] = cpl_info['ContentKind']
                        event['duration_in_frames'] = int(cpl_info['DurationInFrames'])
                        event['duration_in_seconds'] = int(cpl_info['DurationInMilliseconds']) / 1000
                        event['edit_rate'] = [int(cpl_info['MainPictureEditRateNumerator']), int(cpl_info['MainPictureEditRateDenominator'])]
                        fps = int(cpl_info['MainPictureEditRateNumerator']) / int(cpl_info['MainPictureEditRateDenominator'])
                        if cpl_info['MainPictureEncoding'] == 'Jpeg2000_Stereoscopic':
                            is3D = True
                        if fps >= 40:
                            is_4K = True
                        if int(cpl_info['MainPictureActiveWidth']) > 3995:
                            is_4K = True
                    else:
                        event['text'] = 'Unknown'
                        event['duration_in_frames'] = 0
                        event['duration_in_seconds'] = 0
                        event['edit_rate'] = [24, 1]
                elif event_type == 'Black':
                    title = cpl.find('ContentTitleText').text
                    duration = cpl.find('DurationInMilliseconds').text
                    event['id'] = title
                    event['duration_in_seconds'] = int(duration) / 1000
                    event['duration_in_frames'] = int(duration) / 1000 * 24
                    event['edit_rate'] = [24, 1]
                    event['text'] = title
                    event['type'] = 'pattern'
                for cue in cpl.find('CueList').findall('Cue'):
                    offset_in_seconds = int(cue.find('OffsetInMilliseconds').text) / 1000
                    name = cue.find('Name').text
                    cue_dict = {}
                    cue_dict['id'] = name
                    cue_dict['name'] = name
                    cue_dict['type'] = 'cue'
                    type_specific = {}
                    type_specific['action'] = name
                    type_specific['offset_in_frames'] = offset_in_seconds * fps
                    type_specific['offset_in_seconds'] = offset_in_seconds
                    type_specific['offset_from'] = 'start'
                    cue_dict['type_specific'] = type_specific
                    event['automation'].append(cue_dict)

                events.append(event)

            show_list = {}
            show_list['title'] = show_info['Title']
            show_list['duration_in_seconds'] = int(show_info['DurationInMilliseconds']) / 1000
            show_list['is_3d'] = is3D
            show_list['is_hfr'] = is_hfr
            show_list['is_4k'] = is_4K
            playlist = {}
            playlist['id'] = show_info['Id']
            playlist['title'] = show_info['Title']
            playlist['text'] = show_info['Title']
            playlist['is_3d'] = is3D
            playlist['is_hfr'] = is_hfr
            playlist['is_4k'] = is_4K
            playlist['duration_in_seconds'] = int(show_info['DurationInMilliseconds']) / 1000
            playlist['automation'] = []
            playlist['events'] = events
            show_list['playlist'] = playlist
            output['playlist_info_dict'][show_info['Id']] = show_list

        return output

    def playlist_delete(self, playlist_uuid):
        """
        Deletes the specified playlists from the devices; if the devices are not specified, then the playlists are deleted from all devices.
        @param playlist_uuid                STRING - playlist identifier to delete
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        ok, output, response = self.execute('DeleteShow', params={'id': playlist_uuid})
        if ok:
            return (True, trans.PLAYLIST_delete())
        else:
            return (False, output['error_messages'][0])

    def playlist_save(self, playlist):
        """
        Saves a playlist on a device.
            @param playlist          json DICT   - json dictinoary of a playlist
                       id            STRING - uuid
                       title         STRING
                       text          STRING
                       is_3d         BOOL
                       duration      INT in seconds
                       events            LIST of DICTS
                           id            STRING - uuid
                           type          STRING
                           cpl_id        STRING
                           duration      INT in frames
                           main_id       STRING - uuid
                           text          STRING
                           edit_rate     LIST/TUPLE
                               edit_rate_0   INT
                               edit_rate_1   INT
                           cues          LIST of DICTS
                               id            STRING - uuid
                               action        STRING
                               offset        DICT
                                   value         STRING
                                   kind          STRING
                       triggers      LIST of DICTS
                           id        STRING - uuid
                           name      STRING
                           action    STRING
        e.g.
        {
            "title": "probably the greatest playlist of all time",
            "is_hfr": false,
            "is_3d": false,
            "is_4k": false,
            "automation": [],
            "duration_in_seconds": 350.91666666660001,
            "id": "27f52af1-bd7c-4276-bb3f-c894dc44ed26"
            "events": [
                {
                    "duration_in_frames": 2266,
                    "cpl_id": "05a33b4f-8db1-6643-bccb-8fd340a4984a",
                    "duration_in_seconds": 94.416666666699996,
                    "playback_mode": "2D",
                    "type": "composition",
                    "content_kind": "advertisement",
                    "id": "e6a429f3-f956-354d-b0bc-e22d4bb1e2fe"
                    "text": "FORD-DESIRE_90s_AD_177_EN-XX_GB-XX_v3",
                    "main_id": null,
                    "edit_rate": [
                        24,
                        1
                    ],
                    "automation": [
                        {
                            "type": "cue",
                            "name": "mfg_toslink",
                            "type_specific": {
                                "action": "mfg_toslink",
                                "offset_in_seconds": 5,
                                "offset_in_frames": 120,
                                "offset_from": "end"
                            }
                        },
                    ],
                },
            ],
        }
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                    STR  (playlist uuid)
                )
            e.g. return True, 'success', '00000000-0000-0000-000000000000'
        """
        if not playlist['events']:
            return (False, trans.PLAYLIST_save_err_not_empty())
        root = Element('ShowPlaylist')
        root.set('version', '1.0')
        SubElement(root, 'Id').text = playlist['id']
        SubElement(root, 'ContentTitleText').text = playlist['title']
        SubElement(root, 'AnnotationText').text = ''
        SubElement(root, 'Issuer').text = 'Arts Alliance Media'
        SubElement(root, 'IssueDate').text = self.seconds_to_datetimestring(time.time())
        SubElement(root, 'Creator').text = 'AAM'
        cpllistXML = SubElement(root, 'ClipList')
        for cpl in playlist['events']:
            if cpl['type'] == 'composition':
                cplXML = SubElement(cpllistXML, 'Clip')
                SubElement(cplXML, 'Type').text = 'CPL'
                SubElement(cplXML, 'Id').text = cpl['cpl_id']
                SubElement(cplXML, 'ContentTitleText').text = cpl['text']
                SubElement(cplXML, 'DurationInMilliseconds').text = str(int(cpl['duration_in_seconds']) * 1000)
                SubElement(cplXML, 'ContentKind').text = cpl['content_kind']
            elif cpl['type'] == 'pattern':
                cplXML = SubElement(cpllistXML, 'Clip')
                SubElement(cplXML, 'Type').text = 'Black'
                SubElement(cplXML, 'ContentTitleText').text = 'Black'
                SubElement(cplXML, 'DurationInMilliseconds').text = str(int(cpl['duration_in_seconds']) * 1000)
            else:
                continue
            cuelistXML = SubElement(cplXML, 'CueList')
            for cue in cpl['automation']:
                if cue['type'] == 'cue':
                    cueXML = SubElement(cuelistXML, 'Cue')
                    if cue['type_specific']['offset_from'] == 'end':
                        total = int(cpl['duration_in_seconds'])
                        sec_off = int(cue['type_specific']['offset_in_seconds'])
                        cue['type_specific']['offset_in_seconds'] = str(total - sec_off)
                    SubElement(cueXML, 'Name').text = cue['name']
                    SubElement(cueXML, 'OffsetInMilliseconds').text = str(int(cue['type_specific']['offset_in_seconds']) * 1000)
                    SubElement(cueXML, 'Icon').text = ''

        ok, output, response = self.execute('DeleteShow', params={'id': playlist['id']})
        if not ok:
            pass
        ok2, output2, response2 = self.execute('AddShow', params={'data': '<?xml version="1.0"?>' + tostring(root)})
        if ok2:
            return (True, trans.PLAYLIST_save_s1() % playlist['title'])
        else:
            return (False, output2['error_messages'][0])

    def get_schedule_id_list(self):
        """
        gets schedule uuid list of a device
        @return
            dict
                schedule_id_list      -LIST of STR (for schedule ids)
                error_messages        -LIST of errors
        """
        start_date = self.seconds_to_datetimestring(0)
        end_date = self.seconds_to_datetimestring(time.time() + 315360000)
        ok, output, response = self.execute('GetSchedule', params={'startDate': start_date,
         'endDate': end_date})
        if ok:
            schedule_xml = minidom.parseString(response['data'])
            showlist = schedule_xml.getElementsByTagName('ScheduledShow')
            schedule_id_list = []
            for show in showlist:
                scheduleId = show.getElementsByTagName('ScheduleId')[0].firstChild.nodeValue
                schedule_id_list.append(scheduleId)

            output['schedule_id_list'] = schedule_id_list
        return output

    def get_schedule_information(self, schedule_ids):
        """
        gets schedule information of a device
        @param      schedule_ids   - list of schedule ids we want information for
        @return
            dict
                schedule_info_dict        DICT
                    <schedule_id>
                        device_playlist_uuid        STRING (UUID)
                        start_time                  INT    posixtiome
                        device_schedule_id          STRING format YYYY-MM-DD HH:MM
                error_messages          -LIST of errors
        
        Barco Schedule XML structure
            <SmsSchedule Version="1.0">
                <CoveredTimeRange>
                    <StartDate>
                        1970-01-01T01:00:00+00:00
                    </StartDate>
                    <EndDate>
                        2024-03-30T13:38:34+00:00
                    </EndDate>
                </CoveredTimeRange>
                <ScheduledShows>
                    <ScheduledShow>
                        <ScheduleId>
                            17df31f9-97ad-4154-b7fa-44524fe45b17
                        </ScheduleId>
                        <ShowId>
                            2fb99f5e-80ad-455f-9d17-b49afe390670
                        </ShowId>
                        <ShowTitle>
                            stinger avatar mystic
                        </ShowTitle>
                        <Description/>
                        <StartDate>
                            2014-03-31T13:25:00+00:00
                        </StartDate>
                        <DurationInSeconds>
                            340
                        </DurationInSeconds>
                        <Error>
                            0
                        </Error>
                    </ScheduledShow>
                </ScheduledShows>
            </SmsSchedule>
        """
        start_date = self.seconds_to_datetimestring(0)
        end_date = self.seconds_to_datetimestring(time.time() + 315360000)
        ok, output, response = self.execute('GetSchedule', params={'startDate': start_date,
         'endDate': end_date})
        output['schedule_info_dict'] = {}
        if not ok:
            return output
        schedule_xml = minidom.parseString(response['data'])
        showlist = schedule_xml.getElementsByTagName('ScheduledShow')
        for show in showlist:
            try:
                schedule_id = show.getElementsByTagName('ScheduleId')[0].firstChild.nodeValue
                if schedule_id in schedule_ids:
                    start_date = show.getElementsByTagName('StartDate')[0].firstChild.nodeValue
                    show_id = show.getElementsByTagName('ShowId')[0].firstChild.nodeValue
                    error = show.getElementsByTagName('Error')[0].firstChild.nodeValue
                    output['error_messages'].append(error)
                    schedule_dict = {}
                    schedule_dict['device_playlist_uuid'] = show_id
                    schedule_dict['start_time'] = date_utils.parse_date(start_date)
                    schedule_dict['device_schedule_id'] = schedule_id
                    output['schedule_info_dict'][schedule_id] = schedule_dict
            except IndexError as e:
                output['error_messages'].append(str(e))

        return output

    def get_schedule_xml(self, start_ts = 0):
        """ For debugging """
        start_date = self.seconds_to_datetimestring(start_ts)
        end_date = self.seconds_to_datetimestring(time.time() + 315360000)
        ok, output, response = self.execute('GetSchedule', params={'startDate': start_date,
         'endDate': end_date})
        return (ok, output, response)

    def arbitrary_schedule_update(self, schedule_xml):
        """ For debugging """
        ok, output, response = self.execute('UpdateSchedule', params={'data': schedule_xml})
        return (ok, output, response)

    def scheduling_delete(self, schedule_id):
        """
        Deletes a list of schedules from a device.
        @param schedule_id              STRING   - schedule identifier
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                )
            e.g. return True, 'success'
        """
        start_date = self.seconds_to_datetimestring(0)
        end_date = self.seconds_to_datetimestring(time.time() + 315360000)
        ok, output, response = self.execute('GetSchedule', params={'startDate': start_date,
         'endDate': end_date})
        if not ok:
            return (False, output['error_messages'][0])
        schedule_xml = minidom.parseString(response['data'])
        showlist = schedule_xml.getElementsByTagName('ScheduledShow')
        showlist_node = schedule_xml.getElementsByTagName('ScheduledShows')[0]
        metadata = schedule_xml.getElementsByTagName('CoveredTimeRange')[0]
        lolbarco = schedule_xml.createElement('UpdatePastShows')
        lolbarco.appendChild(schedule_xml.createTextNode('true'))
        metadata.appendChild(lolbarco)
        schedule_found = False
        for show in reversed(showlist):
            loop_id = show.getElementsByTagName('ScheduleId')[0].firstChild.nodeValue
            if loop_id == schedule_id:
                showlist_node.removeChild(show)
                schedule_found = True
                break

        if not schedule_found:
            return (False, 'No schedule with ID %s was found' % schedule_id)
        ok2, output2, response2 = self.execute('UpdateSchedule', params={'data': str(schedule_xml.toxml())})
        if ok2:
            return (True, trans.SCHEDULING_delete())
        else:
            return (False, output2['error_messages'][0])

    def scheduling_schedule_playlist(self, playlist_id, timestamp):
        """
        Schedules a playlist to playback on a device for a list of date times.
        @param playlist_id              STRING - playlist identifier, playlist to be scheduled
        @param timestamp                FLOAT - unix timestamp at which to schedule the playlist
        @return  TUPLE (
                    BOOL (success or not)
                    STR  (message)
                    STR  (schedule id)
                )
            e.g. return True, 'success', '1337'
        
        Barco Schedule XML structure
            <SmsSchedule Version="1.0">
                <CoveredTimeRange>
                    <StartDate>
                        1970-01-01T01:00:00+00:00
                    </StartDate>
                    <EndDate>
                        2024-03-30T13:38:34+00:00
                    </EndDate>
                </CoveredTimeRange>
                <ScheduledShows>
                    <ScheduledShow>
                        <ScheduleId>
                            17df31f9-97ad-4154-b7fa-44524fe45b17
                        </ScheduleId>
                        <ShowId>
                            2fb99f5e-80ad-455f-9d17-b49afe390670
                        </ShowId>
                        <ShowTitle>
                            stinger avatar mystic
                        </ShowTitle>
                        <Description/>
                        <StartDate>
                            2014-03-31T13:25:00+00:00
                        </StartDate>
                        <DurationInSeconds>
                            340
                        </DurationInSeconds>
                        <Error>
                            0
                        </Error>
                    </ScheduledShow>
                </ScheduledShows>
            </SmsSchedule>
        """
        ok_show, output_show, show_response = self.execute('GetShowInformation', params={'id': playlist_id})
        if not ok_show:
            return (False, output_show['error_messages'][0], {})
        show = show_response['showInformation']
        start_date = self.seconds_to_datetimestring(0)
        end_date = self.seconds_to_datetimestring(time.time() + 315360000)
        ok, output, response = self.execute('GetSchedule', params={'startDate': start_date,
         'endDate': end_date})
        if not ok:
            return (False, output['error_messages'][0], {})
        schedule_xml = ElementTree(fromstring(response['data']))
        show_xml = Element('ScheduledShow')
        schedule_uuid = str(uuid.uuid4())
        SubElement(show_xml, 'ScheduleId').text = schedule_uuid
        SubElement(show_xml, 'ShowId').text = show['Id']
        SubElement(show_xml, 'ShowTitle').text = show['Title']
        SubElement(show_xml, 'Description').text = ''
        time_begin_string = datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%dT%H:%M:%S+00:00')
        SubElement(show_xml, 'StartDate').text = time_begin_string
        SubElement(show_xml, 'DurationInSeconds').text = str(int(show['DurationInMilliseconds']) / 1000)
        SubElement(show_xml, 'Error').text = '0'
        schedule_xml.getroot().find('ScheduledShows').append(show_xml)
        ok2, output2, response2 = self.execute('UpdateSchedule', params={'data': '<?xml version="1.0" ?>' + tostring(schedule_xml.getroot())})
        if ok2:
            return (True, trans.SCHEDULING_save_s2() % (playlist_id, time_begin_string), {'device_playlist_uuid': playlist_id,
              'start_time': timestamp,
              'device_schedule_id': schedule_uuid})
        else:
            return (False, output2['error_messages'][0], {})


if __name__ == '__main__':
    import json
    import xml.dom.minidom

    def _pretty(dictionary_in):
        print json.dumps(dictionary_in, indent=4)


    def _pretty_xml(elem):
        whatever = xml.dom.minidom.parseString(elem)
        return whatever.toprettyxml()


    b = Barco('10.192.8.69', 43758)
    b.initialize_coms()
# okay decompyling ./core/devices/sms/barco/barco.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:19 CST
