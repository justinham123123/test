# 2017.08.13 21:48:36 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\playback.py
import time
import abc
import logging
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.core.devices.base.playlist import Playlist
from serv.core.devices.base.log_collection import Logging
from serv.core.devices.base.automation import Automation
from serv.lib.utilities.action import SyncAction
import cherrypy
from serv.lib.cherrypy.i18n_tool import ugettext as _

class Playback(Playlist, Logging, Automation):
    __metaclass__ = abc.ABCMeta
    supported_modes = {}

    @abc.abstractmethod
    def get_playback_status(self):
        """
        gets playback status of a server
        
        @return
            dict
                playback_state          -STRING (Play|Pause|STOP)
                spl_uuid                -STRING (UUID)
                spl_position            -INT of seconds into current spl
                element_id              -STRING (UUID)
                element_position        -INT of seconds into current element
                modes      -DICT  containing all available modes and their state
                error_messages          -LIST of errors
        
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_eject(self):
        """
        Ejects a loaded playlist from a device
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_load(self, playlist_id):
        """
        Loads a playlist on a device in preparation for playback.
        @param playlist_id            STRING    - playlist identifier
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_pause(self):
        """
        Pauses the currently playing playlist
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_play(self):
        """
        Starts playback of a loaded playlist
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_stop(self):
        """
        Stops playback
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_skip_forward(self):
        """
        Skips to the next item in the playlist
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_skip_backward(self):
        """
        Skips back to the previous item in the playlist
        """
        raise NotImplementedError

    @abc.abstractmethod
    def playback_set_mode(self, mode):
        """
        Sets a mode on a device; a device might have multiple modes (i.e. scheduled & looping); throws an error if the mode is not supported.
        @param mode                   STRING    - mode identifier, check supported modes for more details.
        """
        raise NotImplementedError

    def playback_interrupt_intermission(self):
        """
        Interrupts the current intermission on the device
        @param mode                   STRING    - mode identifier, check supported modes for more details.
        """
        raise NotImplementedError

    def playback_ready_to_load(self):
        """
            Each playback device has different requirements for being "Ready"
            to load a show. this checks against internal storage
        
            @return
                dict
                    ready    boolean
                    message  STRING
        """
        if self.playback_information['playback_state'] == 'play':
            return {'ready': False,
             'message': _('Must stop and eject before loading a Playlist')}
        elif self.playback_information['modes'] is not None and self.playback_information['modes'].get('scheduler_enabled'):
            return {'ready': False,
             'message': _('Cannot load a Playlist while schedule mode is enabled')}
        elif self.eject_required and self.playback_information['spl_uuid'] not in (None, '00000000-0000-0000-0000-000000000000'):
            return {'ready': False,
             'message': _('Must eject before loading a Playlist')}
        else:
            return {'ready': True,
             'message': _('Screen server is ready to load a playlist')}
            return

    def __init__(self, id, device_info):
        super(Playback, self).__init__(id, device_info)
        self.playback_information = {'playback_state': 'playback_unknown',
         'spl_uuid': None,
         'spl_position': None,
         'spl_duration': None,
         'cpl_uuid': None,
         'element_id': None,
         'element_position': None,
         'element_duration': None,
         'element_index': None,
         'modes': None,
         'last_updated': None}
        self.log_me = {'cpl_uuid': None,
         'spl_uuid': None,
         'start': None,
         'state_changes': [],
         'activity_seen': False}
        self.eject_required = True
        return

    def __push_tms_log(self, playback_status):
        time_now = int(time.time())
        clip_change = False
        playback_state_changed = self.playback_information['playback_state'] != playback_status['playback_state']
        for changer in ['spl_uuid', 'cpl_uuid', 'element_index']:
            if changer in self.playback_information and (changer not in playback_status or self.playback_information[changer] != playback_status[changer]):
                if changer == 'element_index' and self.playback_information[changer] == None:
                    continue
                clip_change = True
                break

        if self.log_me['activity_seen'] and (clip_change or cherrypy.engine.shutdown_servers) and self.log_me['cpl_uuid']:
            final_log_entry = self.log_me.copy()
            final_log_entry['end'] = time_now
            final_log_entry['serial'] = self.device_information['serial']
            final_log_entry['dnqualifier'] = self.device_information['device_dnqualifier']
            final_log_entry['screen_identifier'] = self.device_configuration['screen_identifier']
            final_log_entry['device_ip_address'] = self.device_configuration['ip']
            final_log_entry['device_uuid'] = self.device_configuration['id']
            del final_log_entry['activity_seen']
            del final_log_entry['element_position']
            del final_log_entry['element_duration']
            if clip_change:
                final_log_entry['state_changes'].append({'time': time_now,
                 'state': 'clip_unload'})
            cherrypy.engine.publish('log_entry', final_log_entry)
        if clip_change:
            self.log_me['start'] = None
            self.log_me['cpl_uuid'] = playback_status.get('cpl_uuid', None)
            self.log_me['spl_uuid'] = playback_status.get('spl_uuid', None)
            self.log_me['state_changes'] = [{'time': time_now,
              'state': 'clip_load'}]
            self.log_me['element_duration'] = None
            self.log_me['element_position'] = None
        if playback_status['playback_state'] == 'play' and self.log_me['element_position'] < playback_status['element_position']:
            self.log_me['activity_seen'] = True
            if not self.log_me['start']:
                self.log_me['start'] = int(time_now - playback_status.get('element_position', 0))
        if playback_status.get('element_duration') and not self.log_me['element_duration']:
            self.log_me['element_duration'] = int(playback_status['element_duration'])
        if playback_status.get('element_position'):
            self.log_me['element_position'] = int(playback_status['element_position'])
        if playback_state_changed or clip_change:
            self.log_me['state_changes'].append({'time': time_now,
             'state': playback_status['playback_state']})
        return

    def shutdown(self):
        return (True, '')

    def _device_sync_playback_status(self):
        logging.debug('Syncing playback status for device %s' % self.device_configuration['id'])
        success = True
        messages = []
        playback_status = self.get_playback_status()
        if 'playback_state' not in playback_status:
            playback_status['playback_state'] = 'error'
        if cfg.core_store_live_logs.get():
            self.__push_tms_log(playback_status)
        self.playback_information['playback_state'] = playback_status.get('playback_state', 'error')
        self.playback_information['spl_uuid'] = playback_status.get('spl_uuid', None)
        self.playback_information['spl_position'] = playback_status.get('spl_position', None)
        self.playback_information['spl_duration'] = playback_status.get('spl_duration', None)
        self.playback_information['cpl_uuid'] = playback_status.get('cpl_uuid', None)
        self.playback_information['element_id'] = playback_status.get('element_id', None)
        self.playback_information['element_position'] = playback_status.get('element_position', 0)
        self.playback_information['element_duration'] = playback_status.get('element_duration', 0)
        self.playback_information['element_index'] = playback_status.get('element_index', None)
        self.playback_information['intermission'] = playback_status.get('intermission', False)
        self.playback_information['modes'] = playback_status.get('modes', None)
        self.playback_information['last_updated'] = time.time()
        if playback_status['error_messages']:
            success = False
            messages = playback_status['error_messages']
        self.add_playback_device_status()
        return (success, messages)

    def add_playback_device_status(self):
        if self.playback_information['playback_state'] == 'error':
            self.device_status['error_messages']['Playback Status'] = 'Error'
        elif self.device_status['error_messages'].has_key('Playback Status'):
            del self.device_status['error_messages']['Playback Status']

    def device_get_playback_information(self):
        return self.playback_information

    def playback_load_helper(self, playlist_id):
        validation = self.validate_playlist(playlist_id)
        if validation['info']['result'] == 0:
            return self.playback_load(playlist_id)
        else:
            message = _('Playlist cannot be loaded ') + validation['info']['description']
            if validation['info']['cpl_uuid'] != '':
                cpl_description = validation['info']['cpl_uuid']
                playlist_info_response = self.get_playlist_information([playlist_id])
                if playlist_info_response['playlist_info_dict'].has_key(playlist_id):
                    playlist = playlist_info_response['playlist_info_dict'][playlist_id]['playlist']
                    for event in playlist['events']:
                        if event['type'] == 'composition' and event['cpl_id'] == validation['info']['cpl_uuid']:
                            cpl_description = event['text']
                            break

                message = message + ': %s' % cpl_description
            return (False, message)

    def _device_get_supported_modes_information(self):
        return self.supported_modes

    def is_stoppable(self):
        playback_state = self.device_get_playback_information()['playback_state']
        return playback_state == 'play' or playback_state == 'pause'

    def is_ready_for_collect(self):
        """
        Overwrite this function if there are conditions which must be met
        before we can start log collection.
        @return
                bool
        
        """
        return self.playback_information['playback_state'] not in ('error', 'playback_unknown')

    def monitor_device_state(self, *args, **kwargs):
        super(Playback, self).monitor_device_state(*args, **kwargs)
        if helper_methods.info_needs_updating(self.playback_information, cfg.sync_playback_info_validity.get()):
            self._execute_action(SyncAction(self._device_sync_playback_status))
# okay decompyling ./core/devices/base/playback.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:37 CST
