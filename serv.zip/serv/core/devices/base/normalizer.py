# 2017.08.13 21:48:35 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\normalizer.py
import logging
from collections import defaultdict
from serv.core.websockets.shared.reference import WeakMethod

class Normalizer(object):
    """
    Device-specific normalization and extension of monitoring values.
    
    - Provides to add extensions which compute new values based on a list of
      existing ones (e.g. compute 'lamp_life' out of 'lamp_used' and 'lamp_max').
    - Allows modular normalization of monitoring values 
      per device before they get stored in the cache.
    """
    STATUS_UNKNOWN = 'Unknown'

    def __init__(self):
        self.mappers = {}
        self.extensions = defaultdict(list)

    def add_mapping(self, key, mapper):
        """
        Add a mapping to the normalizers. A mapping can either be
        a dictionary that maps SNMP values to normalized values,
        or a callable that does the mapping. Most of the time, simple
        dictionary mappers should be sufficient.
        :param key: The key to add the mapper for, e.g. 'dowser_status'
        :param mapper: The mapper, either function(value, source) or dictionary
        """
        if not (callable(mapper) or isinstance(mapper, dict)):
            raise AssertionError
            if key in self.mappers:
                logging.debug('Overriding normalization mapper for key "%s"', key)
            self.mappers[key] = callable(mapper) and WeakMethod(mapper)
        else:
            self.mappers[key] = mapper

    def remove_mapping(self, key):
        if key in self.mappers:
            logging.debug('Removing mapping for {name}'.format(name=key))
            self.mappers.pop(key)

    def map(self, key, value, source = None):
        """
        Normalize a key-value pair using the mapper
        registered for the key. Source will be passed into
        the mapping handler if its a callable.
        """
        if key in self.mappers:
            mapper = self.mappers[key]
            if callable(mapper):
                try:
                    return mapper(value, source)
                except ReferenceError:
                    logging.warning('Normalizer "%s" with invalid mapping callback, irgnoring.', self.__class__.__name__)
                    return value

            elif isinstance(mapper, dict):
                return mapper.get(value, self.STATUS_UNKNOWN)
        else:
            return value

    def add_extension(self, name, dependencies, callback):
        """Add a monitoring extension. Allows to compute new values 
        based on reported ones.
        
        :param name: 
            The name of the extension (e.g. 'lamp_life'). Name can be `None`,
            in which case the value this extension returns will be discarded.
            This can be used to enhance e.g. tables with fields that depend on other fields.
        :param dependencies: 
            List of names that this extension depends on (e.g. 'lamp_max', 'lamp_used').
            Values of dependencies will be injected into callback
            with the name order as the dependencies.
        :param callback:
            A function that takes the values of the dependencies as arguments.
            Must return the computed value.
        :param blacklist: 
            Whether or not to put the dependencies on the blacklist.
            Blacklisted values are not pushed to circuit core.
        """
        extension = {'name': name,
         'dependencies': dependencies,
         'callback': WeakMethod(callback)}
        for dep in dependencies:
            self.extensions[dep].append(extension)

    def remove_extension(self, callback):
        to_remove = []
        for dep in self.extensions:
            for extension_item in self.extensions[dep]:
                if extension_item['callback'] == callback:
                    logging.debug('Removing extension from {dep} for {name}'.format(dep=dep, name=extension_item['name']))
                    to_remove.append(extension_item)

            for remove_item in to_remove:
                self.extensions[dep].remove(remove_item)

    def extend(self, name, cache):
        """
        Compute extentions for monitoring values and add them to the cache.
        
        :param name: The key to compute extentions for, e.g. 'lamp_life' (corresponds to cache key)
        :param cache: The device information cache-instance of DeviceCache.
        """
        extensions = self.extensions.get(name, [])
        for extension in extensions:
            dependencies = extension.get('dependencies')
            values = [ cache.get(name) for name in dependencies ]
            if None not in values:
                try:
                    ext_name = extension.get('name')
                    callback = extension.get('callback')
                    value = callback(*values)
                    if ext_name:
                        cache.set(ext_name, value)
                    else:
                        logging.debug('Discarding extension value for callback "%s" [%s = %s]', callback.__name__, ext_name, value)
                except ReferenceError:
                    logging.warning('Normalizer "%s" with invalid extension callback, irgnoring.', self.__class__.__name__)

        return


DOWSER_STATUS = {'0': 'Closed',
 '1': 'Open',
 '2': 'Undetermined'}

class DefaultNormalizer(Normalizer):
    """
    Default normalizer used by all devices.
    Implement mappings and extentions here that are equal among all devices.
    
    Naming convention for mappers: 
    - Dict: <KEY_NAME>, e.g. DOWSER_STATUS = {...}
    - Function: map_<key_name>, e.g. map_dowser_status
    
    Naming convention for extentions:
    - extend_<key_name>, e.g. extend_lamp_life
    
    Normalization guideline:
    - Data amount: bytes
    - Data throughput: bytes per second
    - Time: seconds
    - Bool: True or False (not 1, 0)
    """

    def __init__(self):
        super(DefaultNormalizer, self).__init__()

    def map_projector_status(self, value, source):
        """Example of normalizing a scalar value with a function mapping"""
        if ord(value) & 1:
            return 'Power On'
        return 'Power Off'

    def map_raid(self, value, source):
        """Example for normalizing a table value from SNMP with a function mapping.
        You could also aggregate it to a single value of course.
        But in that case you might want to consider an extenstion,
        which computes a new monitoring type instead of replacing one.
        """
        return [ {'a': row.get('x'),
         'b': row.get('y')} for row in value ]

    def extend_lamp_life(self, lamp_life_used, lamp_life_max):
        """Example of an extension that depends on two other values"""
        lamp_life = int(float(lamp_life_used) / float(lamp_life_max) * 100)
        return lamp_life

    def extend_storage_space(self, storage_used, storage_total):
        """
        Returns a percentage of space used on the device.
        """
        return int(float(storage_used) / float(storage_total) * 100)


if __name__ == '__main__':
    n = DefaultNormalizer()
    print n.map('abc', 'valueabc')
    n.add_mapping('dowser_status', DOWSER_STATUS)
    print n.map('dowser_status', '0')
    print n.map('dowser_status', '1')
    print n.map('dowser_status', '2')
    PROJECTOR_STATUS = {'1': 'On',
     '2': 'Off'}
    n.add_mapping('projector_status', PROJECTOR_STATUS)
    print 'projector_status:', n.map('projector_status', '1')
    n.add_mapping('projector_status', lambda v, s: PROJECTOR_STATUS.get(v))
    print 'projector_status:', n.map('projector_status', '1')
# okay decompyling ./core/devices/base/normalizer.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:35 CST
