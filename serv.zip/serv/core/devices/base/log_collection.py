# 2017.08.13 21:48:31 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\log_collection.py
import abc
import time

class Logging(object):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def get_logs(self, start_datetime):
        """
        gets logs for a single day (24hr period from the start_datetime). Many only supported midnight to midnight.
        @param start_datetime (datetime.datetime instance, built according to local/system)
        @return
                dict
                xml      -log xml
                error_messages          -LIST of errors
        """
        raise NotImplementedError

    @abc.abstractmethod
    def is_ready_for_collect(self):
        """
        Overwrite this function if there are conditions which must be met
        before we can start log collection.
        @return
                bool
        
        """
        raise NotImplementedError

    def wake_socket(self):
        """
        In log_collection_only mode, the sockets can die, so they need refreshing before collection
        """
        self.get_playback_status()
        time.sleep(13)

    def has_unencrypted_logs(self):
        """
        Has separate unencrypted logs to collect, by default is false. Mainly for dolby log collection
        """
        return False
# okay decompyling ./core/devices/base/log_collection.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:31 CST
