# 2017.08.13 21:48:30 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\ingest.py
import logging
import time
import threading
import cherrypy
import abc

class Ingest(object):
    __metaclass__ = abc.ABCMeta

    def __init__(self, *args, **kwargs):
        super(Ingest, self).__init__(*args, **kwargs)
        self.current_ingests = {}
        self.current_ingests_lock = threading.Lock()

    def get_ingest_status(self, ingest_uuid):
        percents = []
        error_count = 0
        for asset_uuid, asset in self.current_ingests[ingest_uuid]['assets'].items():
            if asset['percent'] > -1:
                if self.device_configuration['type'] == 'aamlms':
                    if asset['type'] == 'asset':
                        percents.append((asset['percent'], self.content_store['assets'][asset_uuid]['size']))
                    elif asset['type'] == 'cpl':
                        percents.append((asset['percent'], self.content_store['cpls'][asset_uuid]['size']))
                    else:
                        raise ValueError('Unknown asset type [%s]' % asset['type'])
                else:
                    percents.append((asset['percent'], self.current_ingests[ingest_uuid]['assets'][asset_uuid]['size']))
            else:
                error_count += 1

        total = 0
        target = 0
        for percent, size in percents:
            total += size * percent
            target += size

        return {'error_count': error_count,
         'percent': 0 if target == 0 else int(total / target),
         'state': self.current_ingests[ingest_uuid]['state']}

    def transfer_finished(self, ingest_uuid):
        if ingest_uuid in self.current_ingests:
            try:
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid]['end_time'] = time.time()
                    status = self.get_ingest_status(ingest_uuid)
                    self.current_ingests[ingest_uuid]['percent'] = status['percent']
                    if status['state'] != 'cancelled':
                        if self.device_configuration['type'] == 'aamlms':
                            self._sync_cpl_folder(self.current_ingests[ingest_uuid]['cpl_uuid'])
                        if status['error_count'] != 0 or status['percent'] != 100:
                            self.current_ingests[ingest_uuid]['state'] = 'failed'
                        else:
                            self.current_ingests[ingest_uuid]['state'] = 'success'
                    else:
                        self.content_delete(self.current_ingests[ingest_uuid]['cpl_uuid'])
            except Exception:
                logging.error('Problem in transfer_finished [%s]' % ingest_uuid, exc_info=True)

    def update_file_status(self, ingest_uuid, uuid, percent = None, hash_validated = None, info = None):
        """
        Update ingest store / dictionary  with the status of the file copy
        expecting:  uuid, dest, percent (-1 if error)
        file == None indicates we are done with the current ingest
        """
        try:
            if self.current_ingests.has_key(ingest_uuid) and self.current_ingests[ingest_uuid]['assets'].has_key(uuid):
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid]['assets'][uuid]['percent'] = percent
                    self.current_ingests[ingest_uuid]['assets'][uuid]['hash_validated'] = hash_validated
                    self.current_ingests[ingest_uuid]['assets'][uuid]['info'] = info
                    if percent == -1 or percent == 100:
                        self.current_ingests[ingest_uuid]['assets'][uuid]['end_time'] = time.time()
                    status = self.get_ingest_status(ingest_uuid)
                    self.current_ingests[ingest_uuid]['percent'] = status['percent']
                    self.current_ingests[ingest_uuid]['state'] = 'active'
                if self.device_configuration['type'] == 'aamlms':
                    if self.content_store['cpls'].has_key(uuid):
                        with self.content_store_lock:
                            self.content_store['cpls'][uuid]['status'] = percent
                    if self.content_store['assets'].has_key(uuid):
                        with self.content_store_lock:
                            self.content_store['assets'][uuid]['status'] = percent
        except Exception:
            logging.error('Error in file status update [%s] [%s] [%s] [%s] [%s]' % (str(ingest_uuid),
             str(uuid),
             str(percent),
             str(hash_validated),
             str(info)), exc_info=True)

    def cancel_ingest(self, ingest_uuid, cpl_uuid):
        try:
            now = time.time()
            if ingest_uuid in self.current_ingests:
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid]['state'] = 'cancelled'
                    self.current_ingests[ingest_uuid]['end_time'] = now
            logging.info('Ingest cancelled for [%s]' % cpl_uuid)
        except Exception:
            logging.error('There has been a problem cancelling an ingest: [%s] [%s]' % (str(ingest_uuid), str(cpl_uuid)), exc_info=True)

    def is_ingesting(self, cpl_uuid = None):
        """
        Is the device or a particular cpl ingesting???
        """

        def ingest_thread_exists(cpl_uuid):
            for thread in threading.enumerate():
                if hasattr(thread, 'cpl_uuid') and cpl_uuid == thread.cpl_uuid:
                    return True

            return False

        for ingest_uuid, ingest in self.current_ingests.iteritems():
            if ingest['state'] in ('initializing', 'active') and (cpl_uuid is None or ingest['cpl_uuid'] == cpl_uuid and ingest_thread_exists(cpl_uuid)):
                return True

        return False

    def ingest_details(self, cpl_uuid):
        """
        is the given asset / cpl ingesting???
        """
        for ingest_uuid, ingest in self.current_ingests.items():
            if ingest['cpl_uuid'] == cpl_uuid:
                return ingest

        return {}
# okay decompyling ./core/devices/base/ingest.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:31 CST
