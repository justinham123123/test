# 2017.08.13 21:48:23 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\audio_controller.py
from serv.core.devices.base.monitoring import Monitor
import abc

class AudioController(Monitor):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def get_input_options(self):
        """
        Get a list of input values
        """
        raise NotImplementedError

    @abc.abstractmethod
    def set_input(self, mode):
        """
        Sets the input value
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_input(self):
        """
        Gets the current input value
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_volume(self):
        """
        Gets the current volume value
        """
        raise NotImplementedError

    @abc.abstractmethod
    def set_volume(self, volume):
        """
        Sets the volume value
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_mute(self):
        """
        Gets the mute status
        """
        raise NotImplementedError

    @abc.abstractmethod
    def set_mute(self, mute):
        """
        Sets the mute status
        """
        raise NotImplementedError

    def get_audio_status(self):
        return {'input': self.get_input(),
         'mute': self.get_mute(),
         'volume': self.get_volume()}
# okay decompyling ./core/devices/base/audio_controller.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:23 CST
