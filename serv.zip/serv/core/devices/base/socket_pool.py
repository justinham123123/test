# 2017.08.13 21:48:41 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\socket_pool.py
import Queue, socket, sys, abc
from contextlib import contextmanager
from threading import Lock
import logging

class SocketUnavailable(IOError):
    pass


class SocketPool(object):
    __metaclass__ = abc.ABCMeta

    def __init__(self, *args, **kwargs):
        super(SocketPool, self).__init__(*args, **kwargs)
        self.SOCKET_CREATION_LOCK = Lock()
        self.SOCKET_COUNT_LOCK = Lock()
        self.SOCKETS = {'q': Queue.Queue(),
         'num': 0}
        self.MAX_SOCKETS = 3

    @abc.abstractmethod
    def socket_address(self):
        raise NotImplementedError

    def new_socket(self):
        """
        Creates a new or replacement socket
        """
        new_soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        new_soc.settimeout(5)
        new_soc.connect(self.socket_address())
        self.prep_socket(new_soc)
        return new_soc

    def prep_socket(self, soc):
        """
        Perform any required work on the socket to prepare for use by the device
        e.g. authentication
        """
        pass

    @contextmanager
    def get_socket(self, timeout):
        """
        Context manager that yields a socket from the pool.
        This function also deals with creating sockets if they're missing from the pool and
        destroying sockets involved in an exception
        """
        address = self.socket_address()
        if (not self.SOCKETS['num'] or self.SOCKETS['num'] < self.MAX_SOCKETS) and self.SOCKET_CREATION_LOCK.acquire(False):
            try:
                while self.SOCKETS['num'] < self.MAX_SOCKETS:
                    new_soc = self.new_socket()
                    self.SOCKETS['q'].put(new_soc)
                    with self.SOCKET_COUNT_LOCK:
                        self.SOCKETS['num'] += 1

            finally:
                self.SOCKET_CREATION_LOCK.release()

        try:
            soc = self.SOCKETS['q'].get(True, timeout)
        except (Queue.Empty, KeyError):
            raise SocketUnavailable('Pool has no connected sockets')

        try:
            yield soc
        except Exception:
            exc_info = sys.exc_info()
            try:
                soc.shutdown(socket.SHUT_RDWR)
            except:
                pass

            try:
                soc.close()
            except:
                pass

            del soc
            with self.SOCKET_COUNT_LOCK:
                self.SOCKETS['num'] -= 1
            raise exc_info[0], exc_info[1], exc_info[2]
        else:
            self.SOCKETS['q'].put(soc)
        finally:
            try:
                del exc_info
            except UnboundLocalError:
                pass
# okay decompyling ./core/devices/base/socket_pool.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:41 CST
