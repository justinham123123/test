# 2017.08.13 21:48:23 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\cache.py
import gc
import time
import json
import logging
import abc
from pprint import pformat
from threading import RLock
from collections import defaultdict
from itertools import chain
import cherrypy
from serv.core.websockets.com.packet import ObjectEncoder
from serv.core.websockets.shared.reference import WeakMethod
from serv.lib.utilities.make_hash import make_hash
DEFAULT_SOURCE = '@'

class SourceError(Exception):

    def __init__(self, name, value, source):
        self.name = name
        self.value = value
        self.source = source

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return 'Tried to set ["%s" -> %s] for source "%s" not specified in priority list.' % (self.name, self.value, self.source)


class acquire_locks(object):
    """
    Sometimes functions of the DeviceCache that acquire its lock are called from functions of the device status Cache
    object that acquires its lock and vice versa. This could result in locks being acquired in an inconsistent order
    which causes deadlock. To avoid this, in such functions we need to acquire both locks at once by calling this context manager.
    """

    def __init__(self, device):
        self.locks = [device.device_status._lock, device._active_lock]

    def __enter__(self):
        for lock in self.locks:
            lock.acquire()

    def __exit__(self, ty, val, tb):
        for lock in reversed(self.locks):
            lock.release()

        return False


class Cache(object):
    """A cache that keeps track of changed values and handles
    data from different sources (e.g. api and snmp) to not
    overwrite each other."""

    def __init__(self, *args, **kwargs):
        """
        :param priority: The priority of sources. Sources priority
        is used for a best match when source is not specified for a get.
        If `update_handler` is given as kwarg, this method is called every time the cache updates.
        Only a weak reference to the callback is stored.
        """
        self._cache = defaultdict(dict)
        self._lock = RLock()
        self.last_updated = None
        self.priority = list(args) + [DEFAULT_SOURCE]
        update_handler = kwargs.get('update_handler')
        self.update_handler = WeakMethod(update_handler) if update_handler else None
        return

    def invalidate(self, source = None):
        """
        Invalidates all cache entries (but doesnt delete them)
        such that the entry is updated on next update.
        :param source: If given, only the entries of respective source is invalidated.
                       Else, entries of all sources are invalidated.
        """
        with self._lock:
            if source is not None and source in self._cache:
                for entry in self._cache[source].itervalues():
                    entry['hash'] = None

            elif source is None:
                for source_cache in self._cache.itervalues():
                    for entry in source_cache.itervalues():
                        entry['hash'] = None

        return

    def clear(self, source = None):
        """
        Clears the content of the cache by source.
        If no source is given, the whole cache is wiped.
        :param source: Source string defining which data source to wipe
        """
        with self._lock:
            if source and source in self._cache:
                del self._cache[source]
            else:
                self._cache = defaultdict(dict)
        gc.collect()

    def __str__(self):
        return pformat(dict(self._cache))

    def __repr__(self):
        return self.__str__()

    def set(self, name, value, oid = None, source = DEFAULT_SOURCE):
        """Update the cache if value has changed.
        :param name: The key of the value to store.
        :param value: Value to store in the cache. Either scalar or list of values:
            [{u'healthy': True, '_id': 0, u'name': 'raidArray'},
             {u'healthy': True, '_id': 1, u'name': 'raidDrive1'},
             {u'healthy': True, '_id': 2, u'name': 'raidDrive2'}]
        :param oid: An SNMP oid string (optional).
        :param source:
            String describing the origin of the data, e.g. 'snmp' or 'api'.
            Values with equal names from different sources will never
            overwrite each other.
        :returns: `True` if value has changed, else `False`
        """
        if source not in self.priority:
            raise SourceError(name, value, source)
        changed = False
        new_hash = make_hash(value)
        with acquire_locks(self.update_handler.__self__) if self.update_handler else self._lock:
            current_hash = self._get(name, 'hash', source=source)
            if new_hash != current_hash:
                changed = True
                self.last_updated = time.time()
                self._cache[source][name] = {'ts': self.last_updated,
                 'hash': new_hash,
                 'value': value,
                 'oid': oid}
                if self.update_handler:
                    try:
                        self.update_handler(name, value, oid)
                    except ReferenceError:
                        logging.warning('Cache update handler reference invalid, removing handler from cache')
                        self.update_handler = None
                    except:
                        logging.exception('Error in cache update handler')

        return changed

    def __setitem__(self, name, value):
        self.set(name, value)

    def update(self, data_dict, source = None):
        for name, value in data_dict.iteritems():
            self.set(name, value, source)

    def _entry(self, name, source = None):
        """Returns an internal entry from the cache for given name and source.
        Entry format:
        {
            'ts'     : 1245784521,
            'hash'   : 5242574,
            'value'  : 'scalar or list of scalars',
            'oid'    : '1.3.6.1.4.1.6729.2.1.1.4.1.2.3.1.2'
        }
        """
        with self._lock:
            if source:
                entry = self._cache.get(source, {}).get(name, {})
            else:
                entry = next((self._cache[s][name] for s in self.priority if name in self._cache.get(s, {})), {})
        return entry

    def _get(self, name, field, default = None, source = None):
        """Returns a field-value from an entry in the cache for given name and source"""
        return self._entry(name, source).get(field, default)

    def get(self, name, default = None, source = None):
        """Returns a value from the cache. If source is not specified,
        a bets match value will be returned given be the priority order
        defnied when the cache object is created.
        :param default: Value to return if name is not present in cache
        :param source: Value from specific source to return. Uses first match if source is `None`.
        """
        return self._get(name, 'value', default, source)

    def __getitem__(self, name):
        return self.get(name)

    def has(self, name, source = None):
        return self._entry(name, source) != {}

    def __contains__(self, name):
        return self.has(name)

    def last_updated(self, name = None, default = None, source = None):
        """Returns the timestamp of the cache entry for given name"""
        if name:
            return self._get(name, 'ts', default, source)
        else:
            return self.last_updated

    def items(self):
        with self._lock:
            items = [ (name, self.get(name)) for name in self.keys() ]
        return iter(items)

    def __iter__(self):
        return self.items()

    def keys(self):
        """Return a list of keys currently stored in the cache
        among all sources.
        """
        with self._lock:
            internal_keys = [ d.keys() for d in self._cache.values() ]
            keys = list(set(chain(*internal_keys)))
        return keys

    def changed(self, since, source = None):
        """Get all cached items that have changed since a given timestamp"""
        with self._lock:
            entries = [ (name, self._entry(name, source)) for name in self.keys() ]
        for name, entry in entries:
            ts = entry.get('ts')
            value = entry.get('value')
            oid = entry.get('oid')
            if ts >= since:
                yield {'name': name,
                 'value': value,
                 'oid': oid}

    def copy(self):
        """Returns a copy of the cache as python dictionary"""
        return dict(self.items())


class DeviceCache(object):
    __metaclass__ = abc.ABCMeta

    def __init__(self):
        self.device_information = Cache('api', 'snmp')
        self.device_status = Cache(update_handler=self._cache_update)
        self.blacklist = set()
        self._active_lock = RLock()
        self.active = False
        cherrypy.engine.publish('cclisten', 'config_synced', self._config_synced)
        cherrypy.engine.subscribe('monitoring_type_update', self._monitoring_type_update)
        cherrypy.engine.subscribe('device_remove', self._cleanup)

    def _config_synced(self, data):
        self.pushall(data['url'])

    def _monitoring_type_update(self):
        self.device_information.invalidate()
        self.device_status.invalidate()

    def _cleanup(self, device):
        if device == self:
            cherrypy.engine.unsubscribe('monitoring_type_update', self._monitoring_type_update)
            cherrypy.engine.unsubscribe('device_remove', self._cleanup)

    def activate(self, active = True):
        """
        Activates a device for pushing up device cache updates to circuit core.
        """
        with acquire_locks(self):
            self.active = active
            if active:
                self.pushall()

    def pushall(self, target = None):
        """
        Force-send all data in the cache to circuit core.
        :param str target: URL of the circuit core instance to push to.
                           If None, it is pushed to all instances configured.
        """
        self._trigger_ccpush(0, target)

    def blacklist(self, name):
        """Add a name to the blacklist. Blacklisted names will not
        be pushed to circuit core"""
        self.blacklist.add(name)

    def handle_api_update(self, data):
        """Handles updates received from the device API"""
        start_time = time.time()
        for name, value in data.iteritems():
            if None not in (name, value):
                try:
                    json.dumps(value, cls=ObjectEncoder)
                except:
                    logging.warning('Discarding monitoring type "%s" because not JSON-serializable', name)
                    continue

                norm_value = value
                norm_value = self.normalizer.map(name, value, source='api')
                if self.device_information.set(name, norm_value, source='api'):
                    self.normalizer.extend(name, self.device_information)
            else:
                logging.debug('Received None-type API update: %s = %s', name, value)

        self._trigger_ccpush(start_time)
        return

    def handle_snmp_update(self, data):
        """Handles snmp updates received from the SNMPManager.
        Data contains a list of snmp data that has been updated for this device.
        :param data: Can either be a list of scalar values, or a table.

        === Case scalar list ===
        data = [{
            'oid': u'1.3.6.1.4.1.24391.1.3.7.0',
            'name': u'firmware_version',
            'value': '21.3s',
            'ts': 1379421941
        }, ... ]

        === Case table ===
        data = [{'oid': u'1.3.6.1.4.1.6729.2.1.1.3.1.2.2', 'name': u'raid', 'value': [
            {u'healthy': True, '_id': 0, u'name': 'raidArray'},
            {u'healthy': True, '_id': 1, u'name': 'raidDrive1'},
            {u'healthy': True, '_id': 2, u'name': 'raidDrive2'},
            {u'healthy': True, '_id': 3, u'name': 'raidDrive3'},
            {u'healthy': True, '_id': 4, u'name': 'raidDrive4'}
        ], 'ts': 1380035618}]
        """

        def to_dict(value):
            if isinstance(value, list):
                return dict([ (row['name'], row) for row in value ])
            else:
                return value

        start_time = time.time()
        for d in data:
            name = d.get('name')
            value = d.get('value')
            oid = d.get('oid')
            if None not in (name, value):
                try:
                    json.dumps(value, cls=ObjectEncoder)
                except:
                    logging.warning('Discarding monitoring type "%s" because not JSON-serializable', name)
                    continue

                norm_value = self.normalizer.map(name, value, source='snmp')
                if self.device_information.set(name, norm_value, oid, source='snmp'):
                    self.normalizer.extend(name, self.device_information)
            else:
                logging.debug('Received None-type SNMP update: %s = %s', name, value)

        self._trigger_ccpush(start_time)
        return

    def _cache_update(self, name, value, oid):
        with self._active_lock:
            if not self.active:
                return
        if name in cherrypy.core.monitoring_types:
            cherrypy.engine.publish('ccpush', 'device_monitoring_update', {'device_uuid': self.device_id,
             'monitoring_data': [{'name': name,
                                  'value': value,
                                  'oid': oid}]})

    def _trigger_ccpush(self, threshold, target = None):
        with self._active_lock:
            if not self.active:
                return
        changed_monitoring_types = []
        changed_device_info = {}
        monitoring_types = cherrypy.core.monitoring_types
        changed = chain(self.device_information.changed(threshold), self.device_status.changed(threshold))
        for entry in changed:
            name = entry['name']
            value = entry['value']
            if name in monitoring_types:
                if name in self.blacklist:
                    logging.info('Ignoring "%s", blacklisted', name)
                    continue
                try:
                    json.dumps(value, cls=ObjectEncoder)
                except:
                    logging.warning('Discarding monitoring type "%s" because not JSON-serializable', name)
                    continue

                if not isinstance(value, dict):
                    entry['type'] = monitoring_types[name]
                    changed_monitoring_types.append(entry)
            else:
                changed_device_info[name] = value

        if self.device_id:
            if changed_monitoring_types:
                logging.debug('Pushing %s monitoring items to circuit core', len(changed_monitoring_types))
                cherrypy.engine.publish('ccpush', 'device_monitoring_update', {'device_uuid': self.device_id,
                 'monitoring_data': changed_monitoring_types}, target=target)
            if changed_device_info:
                logging.debug('Pushing %s device info items to circuit core', len(changed_device_info.keys()))
                cherrypy.engine.publish('ccpush', 'device_information_update', {'device_uuid': self.device_id,
                 'device_information': changed_device_info}, target=target)
        elif not self.device_id:
            logging.error('Device monitor does not have a device_id!')


# c = __name__ == '__main__' and Cache()
# c = Cache('b', 'a')
# c.set('test', 99, source='a')
# c.set('test', 100, source='b')
# c.set('x', 101, source='b')
# c.set('y', 102, source='a')
# c.set('z', 103)
# print '---------------------- CONTENT -----------------------'
# print 'Internal:', c
# print 'Copy:', c.copy()
# for name, value in c:
#     print '%s -> %s' % (name, value)

# print '--------------------- TEST START ---------------------'
# try:
#     c.set('a', 1, source='invalid')
# except SourceError as e:
#     print 'OK:', e
# else:
#     print 'FAIL: No SourceError raised'

# raise set(c.keys()) == set(['test',
#  'x',
#  'y',
#  'z']) or AssertionError
# raise c.get('test') == 100 or AssertionError
# raise c.get('test', source='a') == 99 or AssertionError
# raise c.get('test', source='b') == 100 or AssertionError
# raise c.get('x') == 101 or AssertionError
# raise c.get('x', source='b') == 101 or AssertionError
# raise c.get('x', source='a') == None or AssertionError
# raise c.get('y') == 102 or AssertionError
# raise c.get('y', source='a') == 102 or AssertionError
# raise c.get('y', source='b') == None or AssertionError
# raise c.get('z') == 103 or AssertionError
# raise c.get('not in') == None or AssertionError
# raise list(c.changed(0)) == [{'oid': None,
#   'name': 'test',
#   'value': 100},
#  {'oid': None,
#   'name': 'y',
#   'value': 102},
#  {'oid': None,
#   'name': 'z',
#   'value': 103},
#  {'oid': None,
#   'name': 'x',
#   'value': 101}] or AssertionError
# raise ('x' in c) == True or AssertionError
# raise c['x'] == 101 or AssertionError
# c['abc'] = 111
# if not c['abc'] == 111:
#     raise AssertionError
#     print '---------------------- TEST END ----------------------'
# okay decompyling ./core/devices/base/cache.pyc
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:26 CST
