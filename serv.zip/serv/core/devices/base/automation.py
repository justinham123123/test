# 2017.08.13 21:48:23 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\automation.py
import time
import threading
import abc
import logging
import cherrypy
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.core.devices.base.monitoring import Monitor
from serv.lib.utilities.action import SyncAction
from serv.lib.cherrypy.i18n_tool import ugettext as _

class Automation(Monitor):
    __metaclass__ = abc.ABCMeta

    def __init__(self, id, device_info):
        super(Automation, self).__init__(id, device_info)
        self.automation_information_lock = threading.Lock()
        self.automation = {'last_updated': None}
        return

    def _device_sync_automation_information(self):
        logging.debug('Syncing automation info for device [%s]' % self.device_configuration['id'])
        success = True
        messages = []
        automation_uuid_response = self.get_automation_list()
        if automation_uuid_response['error_messages'] == []:
            automation_info_to_get = []
            for automation_uuid in automation_uuid_response['automation_uuid_list']:
                if automation_uuid not in self.automation or helper_methods.info_needs_updating(self.automation[automation_uuid], cfg.sync_individual_automation_validity.get()):
                    automation_info_to_get.append(automation_uuid)

            automation_information_response = self.get_automation_information(automation_info_to_get)
            for automation_uuid in automation_information_response['automation_info_dict']:
                self._add_automation(automation_uuid, automation_information_response['automation_info_dict'][automation_uuid])

            for automation_uuid in set(self.automation.keys()) - set(automation_uuid_response['automation_uuid_list']):
                if automation_uuid != 'last_updated':
                    with self.automation_information_lock:
                        del self.automation[automation_uuid]

            with self.automation_information_lock:
                self.automation['last_updated'] = time.time()
        else:
            success = False
            messages.extend(automation_uuid_response['error_messages'])
        return (success, messages)

    def _add_automation(self, automation_uuid, automation_dict):
        with self.automation_information_lock:
            if not self.automation.get(automation_uuid, False):
                self.automation[automation_uuid] = {}
            self.automation[automation_uuid]['name'] = automation_dict['name']
            self.automation[automation_uuid]['type'] = automation_dict['type']
            self.automation[automation_uuid]['duration'] = automation_dict['duration']
            self.automation[automation_uuid]['clean'] = True
            self.automation[automation_uuid]['last_updated'] = time.time()
            cherrypy.engine.publish('ccpush', 'automation_update', {'cue_identifier': automation_uuid,
             'cue_info': self.automation[automation_uuid],
             'device_uuid': self.device_id})

    def get_automation_list(self):
        """
        gets automation uuid list of a device
        
        @return
            {
                automation_uuid_list    -LIST of UUIDs
                error_messages          -LIST of errors
            }
        
        """
        return {'error_messages': [],
         'automation_uuid_list': []}

    def get_automation_information(self, automation_uuids):
        """
        This recieves information for given cue in the system
        
        @param      automation_uuids   - list of cue uuids we want information for
        @return     {
                        automation_information_dict:
                            {
                                automation_uuid:
                                {
                                    duration    - INTEGER seconds
                                    name        - STRING
                                    type        - STRING [cue, trigger, volume, ... ] (theres a few more comign in wtih gdc/qube)
                                }
                            }
                        error_messages - LIST of errors
                    }
        """
        return {'error_messages': [],
         'automation_info_dict': {}}

    def automation_trigger(self, cue_id, parameterized, parameterized_value):
        """
        Triggers/fires/activates a cue on a device; or on all devices that support the API; throws an error if the cue is not supported on a device
        
        @param cue_id                  STRING     - identifer for the cue
        @param parameterized           BOOl       - if the cue has a parameterized value
        @param parameterized_value     STRING?    - the parameterized value
        """
        return (False, _('Cannot trigger an automation on this device'))

    def _device_get_automation_information(self):
        return self.automation

    def monitor_device_state(self, *args, **kwargs):
        super(Automation, self).monitor_device_state(*args, **kwargs)
        if helper_methods.info_needs_updating(self.automation, cfg.sync_automation_info_validity.get()):
            self._execute_action(SyncAction(self._device_sync_automation_information))
# okay decompyling ./core/devices/base/automation.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:23 CST
