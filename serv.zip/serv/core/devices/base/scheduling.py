# 2017.08.13 21:48:39 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\base\scheduling.py
import datetime
import time
import threading
import logging
import json
import abc
import cherrypy
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.utilities import helper_methods
from serv.configuration import cfg
from serv.core.devices.base.playback import Playback
from serv.lib.utilities.action import SyncAction
from serv.storage.database.primary import database as db

class Scheduling(Playback):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def get_schedule_id_list(self):
        """
        gets schedule uuid list of a device
        
        @return
            dict
                schedule_id_list      -LIST of UUIDs
                error_messages          -LIST of errors
        
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_schedule_information(self, schedule_ids):
        """
        gets schedule information of a device
        
        @param      schedule_ids   - list of schedule ids we want information for
        @return
            dict
                schedule_info_dict        DICT
                    <schedule_id>
                        playlist_uuid       STRING (UUID)
                        start_time          STRING format YYYY-MM-DD HH:MM
                error_messages          -LIST of errors
        """
        raise NotImplementedError

    @abc.abstractmethod
    def scheduling_delete(self, schedule_id):
        """
        Deletes a list of schedules from a device.
        @param schedule_id              STRING   - schedule identifier
        """
        raise NotImplementedError

    @abc.abstractmethod
    def scheduling_schedule_playlist(self, playlist_id, timestamp):
        """
        Schedules a playlist to playback on a device for a list of date times.
        @param playlist_id              STRING - playlist identifier, playlist to be scheduled
        @param timestamp                LIST[FLOAT] - list of datetimes to schedule the playlist in posix timestamp format
        """
        raise NotImplementedError

    def __init__(self, id, device_info):
        super(Scheduling, self).__init__(id, device_info)
        self.scheduling_information_lock = threading.Lock()
        self.scheduling_information = {'last_updated': None}
        schedules = db.Session().query(db.Schedule).filter(and_(db.Schedule.device_schedule_id != None, db.Schedule.device_uuid == id, db.Schedule.deleted == False))
        with self.scheduling_information_lock:
            for schedule in schedules:
                self.scheduling_information[schedule.device_schedule_id] = {}
                self.scheduling_information[schedule.device_schedule_id]['device_playlist_uuid'] = schedule.device_playlist_uuid
                self.scheduling_information[schedule.device_schedule_id]['start_time'] = schedule.start_timestamp
                self.scheduling_information[schedule.device_schedule_id]['schedule_uuid'] = schedule.uuid
                self.scheduling_information[schedule.device_schedule_id]['clean'] = True
                self.scheduling_information[schedule.device_schedule_id]['last_updated'] = time.time()

        db.Session().close()
        return

    @db.close_session
    def _device_sync_schedule_information(self):
        logging.debug('Syncing schedule info for device %s' % self.device_configuration['id'])
        success = True
        messages = []
        self._schedules_syncing = True
        self.sync_status['sync_active'] = True
        schedule_id_response = self.get_schedule_id_list()
        if schedule_id_response['error_messages'] == []:
            schedule_info_to_get = []
            for schedule_id in schedule_id_response['schedule_id_list']:
                if schedule_id == 'last_updated':
                    continue
                if schedule_id not in self.scheduling_information or helper_methods.info_needs_updating(self.scheduling_information[schedule_id], cfg.sync_individual_schedule_info_validity.get()):
                    schedule_info_to_get.append(schedule_id)

            schedule_information_response = self.get_schedule_information(schedule_info_to_get)
            try:
                new_schedules = False
                for schedule_id in schedule_information_response['schedule_info_dict']:
                    if not new_schedules and schedule_id not in self.scheduling_information:
                        new_schedules = True
                    self._add_update_schedule_db(schedule_information_response['schedule_info_dict'][schedule_id])

                if new_schedules and cfg.marker_clip_templating() and cfg.auto_run_marker_clip_templating():
                    cherrypy.core.marker_clip_processor.process_marker_clips_schedules()
                for schedule_id in set(self.scheduling_information.keys()) - set(schedule_id_response['schedule_id_list']):
                    if schedule_id == 'last_updated':
                        continue
                    if self.scheduling_information.has_key(schedule_id):
                        if self.scheduling_information[schedule_id].get('schedule_uuid') is not None:
                            final_check = self.get_schedule_information([schedule_id])
                            if final_check.has_key('schedule_info_dict') and final_check['schedule_info_dict'] == {}:
                                self._delete_schedule_db(self.scheduling_information[schedule_id]['schedule_uuid'])
                                msg = 'No message from server.'
                                if len(final_check.get('error_messages', [])) > 0:
                                    msg = final_check['error_messages'][0]
                                stamp = str(datetime.datetime.fromtimestamp(self.scheduling_information[schedule_id]['start_time']))
                                logging.info('Deleting Schedule %s at %s which is no longer being reported - %s ' % (str(schedule_id), stamp, msg))
                        with self.scheduling_information_lock:
                            self.scheduling_information.pop(schedule_id, None)

            except Exception as ex:
                logging.error('Error in updating the schedule db and info hash', exc_info=True)

            with self.scheduling_information_lock:
                self.scheduling_information['last_updated'] = time.time()
        else:
            success = False
            messages.extend(schedule_id_response['error_messages'])
        self._schedules_syncing = False
        if self._sync_complete():
            self.sync_status['sync_active'] = False
        return (success, messages)

    def _delete_schedule_db(self, schedule_uuid, deleted_timestamp = None):
        """
        Deletes a list of schedules from a device and the info if it is there
        @param schedule_ids              LIST   - list of content identifiers
        @param deleted_timestamp         FLOAT  - POSIX timestamp of when to mark the schedule as delete (used by Director's sync)
        caller funciton closes the session
        """
        try:
            db_schedule = db.Session().query(db.Schedule).filter(db.Schedule.uuid == schedule_uuid).one()
        except Exception as e:
            logging.error('Schedule {id} could not be found in DB'.format(id=schedule_uuid))
            return

        if db_schedule.pos_id:
            db.Session.query(db.POSItem).filter(db.POSItem.uuid == db_schedule.pos_id).update({db.POSItem.state: 'deleted',
             db.POSItem.message: _('Session was deleted')})
        for map in db_schedule.show_attribute_maps:
            db.Session.delete(map)

        cherrypy.core.schedule_validation.remove_validation(db_schedule)
        db.Session().delete(db_schedule)
        cherrypy.engine.publish('ccpush', 'schedule_delete', {'uuid': schedule_uuid})
        db.Session().commit()

    def _add_update_schedule_db(self, schedule_dict, schedule_db_uuid = None):
        """
        adds the schedule dictionary to the db and info table if necessary
        ret: schedule_uuid - the database schedule uuid
        """
        db_schedule = None
        new = schedule_dict.get('device_schedule_id', False)
        if new:
            with self.scheduling_information_lock:
                sch_info = self.scheduling_information.setdefault(schedule_dict['device_schedule_id'], {})
                sch_info['last_updated'] = time.time()
                if not sch_info.get('device_playlist_uuid') == schedule_dict['device_playlist_uuid'] or not sch_info.get('start_time') == schedule_dict['start_time'] or not sch_info.get('clean') == True:
                    sch_info['device_playlist_uuid'] = schedule_dict['device_playlist_uuid']
                    sch_info['start_time'] = schedule_dict['start_time']
                    sch_info['clean'] = True
        if schedule_db_uuid != None:
            try:
                db_schedule = db.Session.query(db.Schedule).filter(db.Schedule.uuid == schedule_db_uuid).one()
            except NoResultFound:
                logging.error('Schedule UUID was specified but not found in DB %s' % schedule_db_uuid, exc_info=True)
                raise

        elif schedule_dict.get('pos_id', False):
            try:
                db_schedule = db.Session.query(db.Schedule).filter(db.Schedule.pos_id == schedule_dict['pos_id']).one()
                db_schedule.deleted = False
            except NoResultFound:
                pass

        elif new:
            db_schedules = db.Session.query(db.Schedule).filter(db.Schedule.device_schedule_id == schedule_dict['device_schedule_id'], db.Schedule.device_uuid == self.device_configuration['id'], db.Schedule.start_timestamp == schedule_dict['start_time'])
            try:
                db_schedule = db_schedules.one()
            except NoResultFound:
                db_schedule = db.Schedule(device_uuid=self.device_configuration['id'], screen_uuid=self.device_configuration['screen_uuid'], type=schedule_dict.get('type', 'server'), start_timestamp=schedule_dict['start_time'])
                db.Session.add(db_schedule)

        if db_schedule == None:
            db_schedule = db.Schedule(device_uuid=self.device_configuration['id'], screen_uuid=self.device_configuration['screen_uuid'], type=schedule_dict.get('type', 'server'), start_timestamp=schedule_dict['start_time'])
            db.Session.add(db_schedule)
        duration = 0
        if schedule_dict.get('device_playlist_uuid'):
            playlist_dict = self.playlist_information.get(schedule_dict['device_playlist_uuid'], {})
            schedule_dict['device_playlist_duration'] = playlist_dict.get('duration_in_seconds', 0)
            duration += schedule_dict['device_playlist_duration']
            if playlist_dict.get('title', False):
                schedule_dict['display_name'] = playlist_dict['title']
        if duration == 0 and schedule_dict.get('pos_duration', False):
            duration = schedule_dict['pos_duration']
        elif schedule_dict.get('placeholder_duration', False):
            duration += int(schedule_dict['placeholder_duration'])
            schedule_dict['placeholder_duration'] = int(schedule_dict['placeholder_duration'])
        if not schedule_dict.get('display_name', False):
            if schedule_dict.get('placeholder_type', False) and schedule_dict['placeholder_type'] != '':
                schedule_dict['display_name'] = schedule_dict['placeholder_type']
            else:
                schedule_dict['display_name'] = _('Unknown Playlist')
        end_datetime = datetime.datetime.fromtimestamp(schedule_dict['start_time']) + datetime.timedelta(seconds=int(duration))
        schedule_dict['end_timestamp'] = time.mktime(end_datetime.timetuple())
        if schedule_dict.has_key('placeholder_type'):
            db_schedule.placeholder_type = schedule_dict.get('placeholder_type', None)
            db_schedule.placeholder_duration = schedule_dict.get('placeholder_duration', None)
        if 'templating_issues' in schedule_dict:
            db_schedule.templating_issues = schedule_dict['templating_issues']
        for key in ['is_template',
         'display_name',
         'end_timestamp',
         'pos_id',
         'pos_duration',
         'device_schedule_id',
         'device_playlist_uuid',
         'device_playlist_duration',
         'source_playlist_uuid',
         'print_no']:
            if schedule_dict.get(key, False) and getattr(db_schedule, key) != schedule_dict[key]:
                setattr(db_schedule, key, schedule_dict[key])

        if new:
            db_schedule.device_schedule_id = schedule_dict['device_schedule_id']
        db_schedule.set_modified(schedule_dict.get('last_modified', None))
        db.Session.commit()
        for show_attribute_uuid in schedule_dict.get('show_attributes', []):
            map = db.ScheduleShowAttributeMap()
            map.show_attribute_uuid = show_attribute_uuid
            map.schedule_uuid = db_schedule.uuid
            db.Session.add(map)
            db.Session.commit()

        if new:
            with self.scheduling_information_lock:
                self.scheduling_information[schedule_dict['device_schedule_id']]['schedule_uuid'] = db_schedule.uuid
        if schedule_dict.get('pos_id', None) is not None:
            db_pos_item = db.Session.query(db.POSItem).filter(db.POSItem.uuid == schedule_dict['pos_id']).one()
            db_pos_item.state = 'assigned'
            db_pos_item.message = _('Session has been scheduled')
            db_pos_item.set_modified()
            db.Session.commit()
            cherrypy.engine.publish('ccpush', 'pos_save', db_pos_item.to_dict())
        cherrypy.engine.publish('ccpush', 'schedule_save', {'uuid': db_schedule.uuid,
         'screen_uuid': db_schedule.screen_uuid,
         'display_name': db_schedule.display_name,
         'start_time': datetime.datetime.fromtimestamp(db_schedule.start_timestamp).strftime('%H:%M:%S'),
         'start_date': datetime.datetime.fromtimestamp(db_schedule.start_timestamp).strftime('%Y-%m-%d'),
         'start_timestamp': db_schedule.start_timestamp,
         'end_time': datetime.datetime.fromtimestamp(db_schedule.end_timestamp).strftime('%H:%M:%S'),
         'end_date': datetime.datetime.fromtimestamp(db_schedule.end_timestamp).strftime('%Y-%m-%d'),
         'end_timestamp': db_schedule.end_timestamp,
         'duration': db_schedule.end_timestamp - db_schedule.start_timestamp,
         'type': db_schedule.type,
         'error': db_schedule.error,
         'pos_id': db_schedule.pos_id,
         'device_uuid': db_schedule.device_uuid,
         'device_schedule_id': db_schedule.device_schedule_id,
         'device_playlist_uuid': db_schedule.device_playlist_uuid,
         'device_playlist_duration': db_schedule.device_playlist_duration,
         'source_playlist_uuid': db_schedule.source_playlist_uuid,
         'is_template': db_schedule.is_template,
         'templating_issues': db_schedule.templating_issues,
         'print_no': db_schedule.print_no,
         'placeholder_type': db_schedule.placeholder_type,
         'placeholder_duration': db_schedule.placeholder_duration,
         'preshow_duration': self.playlist_information.get(db_schedule.device_playlist_uuid, {}).get('preshow_duration', None)})
        cherrypy.core.schedule_validation.add_validation(db_schedule.uuid, db_schedule=db_schedule)
        return db_schedule.uuid

    @db.close_session
    def scheduling_delete_helper(self, schedule_id, deleted_timestamp = None, remove_database_schedule = True):
        """
        Deletes a list of schedules from a device and the info if it is there
        @param schedule_ids              LIST   - list of content identifiers
        @param deleted_timestamp         FLOAT  - POSIX timestamp of when to mark the schedule as delete (used by Director's sync)
        """
        success = True
        message = _('Schedule deleted')
        try:
            device_schedule_id = db.Session.query(db.Schedule).filter(db.Schedule.uuid == schedule_id).one().device_schedule_id
        except NoResultFound:
            logging.error('Schedule UUID was specified but not found in DB %s' % schedule_id, exc_info=True)
            return (False, _('Cannot find specified Schedule'))

        if device_schedule_id:
            success, message = self.scheduling_delete(device_schedule_id)
            if success:
                if remove_database_schedule:
                    self._delete_schedule_db(schedule_id, deleted_timestamp)
                with self.scheduling_information_lock:
                    self.scheduling_information.pop(device_schedule_id, None)
            return (success, message)
        else:
            if remove_database_schedule:
                self._delete_schedule_db(schedule_id, deleted_timestamp)
            return (success, message)
            return

    @db.close_session
    def scheduling_add_helper(self, params):
        """
        Add a schedule to a device
        """
        success = True
        schedule_dict = {}
        if params.get('playlist_id'):
            if not self.playlist_information.has_key(params['playlist_id']):
                logging.error('Schedule [%s @ %s] could not be added. playlist id not in the playlist_information hash' % (params['playlist_id'], params['start_time']))
                success = False
                message = _('Cannot find specified Playlist on the screen server')
            else:
                try:
                    success, message, schedule_dict = self.scheduling_schedule_playlist(params['playlist_id'], params['start_time'])
                except Exception as ex:
                    logging.error('There was a problem completing the schedule add transaction', exc_info=True)
                    success = False
                    message = _('Cannot find specified Playlist on the screen server')

        else:
            message = _('Schedule saved')
        if success and (schedule_dict or params.get('placeholder_type')):
            if params.get('show_attributes'):
                schedule_dict['show_attributes'] = params.get('show_attributes', [])
            if params.get('placeholder_type'):
                schedule_dict['placeholder_type'] = params.get('placeholder_type', None)
                schedule_dict['placeholder_duration'] = params.get('placeholder_duration', None)
            if params.get('pos_id'):
                schedule_dict['pos_id'] = params.get('pos_id', None)
                schedule_dict['pos_duration'] = params.get('pos_duration', None)
                schedule_dict['pos_rescheduled'] = params.get('pos_rescheduled', None)
            schedule_dict['type'] = params['type']
            schedule_dict['modified'] = False
            schedule_dict['display_name'] = params.get('display_name')
            schedule_dict['is_template'] = params.get('is_template', False)
            if 'templating_issues' in params and params['templating_issues']:
                schedule_dict['templating_issues'] = json.dumps(params['templating_issues'])
            if params.get('source_spl_id'):
                schedule_dict['source_playlist_uuid'] = params['source_spl_id']
            if not schedule_dict.has_key('device_playlist_uuid') and params.get('playlist_id'):
                schedule_dict['device_playlist_uuid'] = params['playlist_id']
            if not schedule_dict.has_key('start_time'):
                schedule_dict['start_time'] = params['start_time']
            try:
                self._add_update_schedule_db(schedule_dict, params.get('schedule_db_uuid'))
            except Exception as ex:
                message = _('Error saving Schedule %s' % str(ex))
                success = False
                logging.error(message, exc_info=True)

        if params.get('pos_id'):
            pos_item = db.Session.query(db.POSItem).filter(db.POSItem.uuid == params['pos_id']).one()
            commit_this = False
            if not success:
                pos_item.add_error(message)
                pos_item.state = 'error'
                commit_this = True
            if params.get('pos_rescheduled') == True:
                moved_to = datetime.datetime.fromtimestamp(params['start_time'])
                pos_item.start = moved_to
                pos_item.end = datetime.datetime.fromtimestamp(params['start_time'] + pos_item.overall_duration)
                pos_item.moved = True
                pos_item.week_number = helper_methods.week_number(moved_to.year, moved_to.month, moved_to.day)
                commit_this = True
            if commit_this:
                db.Session.commit()
        return (success, message)

    @db.close_session
    def scheduling_add_job_helper(self, params):
        """
        Add POS item, placeholder, or template into the scheduling db for processing
        
        @param params
        {
            type
            start_time
            source_playlist_uuid
        
            pos_id
            pos_duration
        
            placeholder_type
            placeholder_duration
        
            print_no
            last_modified
        }
        """
        success = True
        schedule_dict = {'start_time': params['start_time'],
         'type': params['type']}
        schedule_dict['source_playlist_uuid'] = params.get('source_playlist_uuid', None)
        schedule_dict['placeholder_type'] = params.get('placeholder_type', None)
        schedule_dict['placeholder_duration'] = params.get('placeholder_duration', None)
        schedule_dict['print_no'] = params.get('print_no', None)
        schedule_dict['display_name'] = params.get('title', None)
        schedule_dict['is_template'] = True
        schedule_dict['pos_duration'] = params.get('pos_duration', None)
        schedule_dict['pos_id'] = params.get('pos_id', None)
        schedule_uuid = None
        try:
            schedule_uuid = self._add_update_schedule_db(schedule_dict)
            message = _('Schedule added to job queue')
        except Exception as ex:
            success = False
            message = _('Error saving Schedule %s' % str(ex))
            logging.error(message, exc_info=True)

        return {'success': success,
         'message': message,
         'schedule_uuid': schedule_uuid}

    def _device_get_scheduling_information(self, date_range = [], details = False):
        """
        gets device specific content information
        content details thoroughly ignored
        
        format to go with other formats
        @param date_range                LIST[FLOAT] start and end timestamps for the schedules wanted. Value of None is unlimited
        @param details                   BOOL whether to include playlist details
        """
        output = {self.device_configuration['id']: {}}
        for schedule_id, schedule in self.scheduling_information.items():
            if date_range:
                start_timestamp = schedule['start_time']
                if date_range[0] is not None and date_range[0] > start_timestamp:
                    continue
                if date_range[1] is not None and date_range[1] < start_timestamp:
                    continue
            output[self.device_configuration['id']][schedule_id] = {}
            for data_item, data_value in schedule.items():
                output[self.device_configuration['id']][schedule_id][data_item] = data_value

            if details:
                output[self.device_configuration['id']][schedule_id]['playlist_information'] = self.playlist_information.get(schedule['device_playlist_uuid'], None)

        return output

    def monitor_device_state(self, sync_content = True):
        super(Scheduling, self).monitor_device_state(sync_content)
        if sync_content and helper_methods.info_needs_updating(self.scheduling_information, cfg.sync_schedule_info_validity.get()):
            self._execute_action(SyncAction(self._device_sync_schedule_information))
# okay decompyling ./core/devices/base/scheduling.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:41 CST
