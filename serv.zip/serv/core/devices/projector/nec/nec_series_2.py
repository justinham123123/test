# 2017.08.13 21:49:10 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\nec\nec_series_2.py
"""
Implementation of Core2 projection API for NEC projectors
"""
from serv.core.devices.projector.nec.nec_series_1 import NECSeries1
from serv.core.devices.projector.nec.normalizers import NEC2Normalizer
PROJECTOR_TYPES = ['nc1200',
 'nc2000',
 'nc2000c',
 'nc3200',
 'nc3240',
 'NC Series',
 'Type 2']
PROJECTOR_STATUS = {'1': 'Power Off',
 '2': 'Power On',
 '3': 'Cooling'}
DOWSER_STATUS = {'1': 'Open',
 '2': 'Closed'}

class NECSeries2(NECSeries1):
    """
    An implementation of monitoring for NEC series 2 projectors
    """

    def __init__(self, id, device_info, snmp_manager):
        super(NECSeries2, self).__init__(id, device_info, snmp_manager)
        self.normalizer = NEC2Normalizer()

    def get_projector_status(self):
        """
        Gets the available status values for the projector
        @return 
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        self.response['error_messages'] = []
        return self.response
# okay decompyling ./core/devices/projector/nec/nec_series_2.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:10 CST
