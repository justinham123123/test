# 2017.08.13 21:49:09 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\nec\nec_series_1.py
"""
Implementation of Core2 projection API for NEC projectors
"""
from serv.core.devices.base.projection import Projection
from serv.core.devices.projector.nec.nec_utils import execute_serial_command, CMD_POWER_ON, CMD_POWER_OFF, CMD_LAMP_ON, CMD_LAMP_OFF, CMD_OPEN_SHUTTER, CMD_CLOSE_SHUTTER, CMD_DATE_TIME_REQUEST
import logging
import datetime
import calendar
import socket
from serv.lib.network.snmp import SNMPError, SNMPTimeout
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.projector.nec.normalizers import NECNormalizer
PROJECTOR_TYPES = ['nc800',
 'nc1500',
 'nc1600',
 'nc2500',
 'NC Series',
 'Type 1']
PROJECTOR_STATUS = {'1': 'Power Off',
 '2': 'Power On',
 '3': 'Cooling'}
DOWSER_STATUS = {'1': 'Open',
 '2': 'Closed'}

def check_model_number(model, models):
    match = False
    for model_num in models:
        if None not in (model, model_num) and model_num.lower() in model.lower().replace('-', '').replace('_', ''):
            match = True

    return match


class NECSeries1(Projection):
    """
    An implementation of monitoring for NEC series projectors
    """

    def __init__(self, id, device_info, snmp_manager):
        super(NECSeries1, self).__init__(id, device_info)
        self.snmp_manager = snmp_manager
        self.normalizer = NECNormalizer()
        self.response = {}
        self.response['error_messages'] = []

    def get_device_information(self):
        """
        Returns information regarding the device
        """
        output = {'type': None,
         'error_messages': []}
        software = self._execute_snmp('.1.3.6.1.4.1.119.2.3.123.1.2.2.0', version=1, throw=True)
        model = 'NEC'
        try:
            if int(software[0]) >= 2:
                type_ = 'Type 2'
                model = self._execute_snmp('.1.3.6.1.4.1.119.2.3.123.1.13.0', version=1, throw=False)
                if not model:
                    model = self._execute_snmp('.1.3.6.1.2.1.1.5.0', version=1, throw=False)
            else:
                type_ = 'Type 1'
                model = self._execute_snmp('.1.3.6.1.2.1.1.5.0', version=1, throw=False)
                if not model:
                    model = self._execute_snmp('.1.3.6.1.4.1.119.2.3.123.1.13.0', version=1, throw=False)
            if not model:
                model = type_
            elif model.lower() in ('nc1100l-a', 'nc1100'):
                type_ = 'Type 2'
        except ValueError:
            logging.error('Unexpected NEC software version %s from %s' % (software, self.device_configuration['ip']))
            raise

        output['type'] = type_
        output['model'] = model
        return output

    def get_device_status(self):
        """
        Returns the status of the device
        """
        response = {'error_messages': []}
        projector_time = self._execute_serial_command(CMD_DATE_TIME_REQUEST)
        if projector_time:
            day, month, year_low, year_high, myserious_number, second, minute, hour = projector_time
            projector_datetime = datetime.datetime((year_high << 8) + year_low, month, day, hour, minute, second)
            projector_timestamp = calendar.timegm(projector_datetime.timetuple())
            response['current_time'] = projector_timestamp
        else:
            response['current_time'] = None
        serial = self._execute_snmp('1.3.6.1.4.1.119.2.3.123.1.12.1.0', version=1)
        if serial:
            response['serial'] = serial
        return response

    def test_management_connection(self):
        try:
            self._execute_serial_command(CMD_DATE_TIME_REQUEST)
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error %s') % str(ex))

        try:
            self.snmp_manager.snmpGet('1.3.6.1.4.1.119.2.3.123.1.2.2.0', self.device_configuration['ip'], version=1)
        except SNMPTimeout:
            return (False, _('Timed out while waiting for SNMP response'))
        except SNMPError:
            pass

        return (True, _('OK'))

    def get_projector_status(self):
        """
        Gets the available status values for the projector
        @return 
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        self.response['error_messages'] = []
        return self.response

    def _execute_snmp(self, oid, version = 1, throw = False):
        re = None
        try:
            re = self.snmp_manager.snmpGet(oid, self.device_configuration['ip'], version)
        except (SNMPTimeout, SNMPError) as e:
            if throw:
                raise e
        except Exception as ex:
            self.response['error_messages'].append(_('Error communicating: %s') % str(ex))

        return re

    def _execute_serial_command(self, command):
        re = None
        try:
            re = execute_serial_command(command, self.device_configuration['ip'])
        except socket.error as ex:
            pass
        except Exception as ex:
            self.response['error_messages'].append(_('Error communicating: %s') % str(ex))

        return re

    def lamp_on(self):
        """
        Strike the lamp
        """
        execute_serial_command(CMD_LAMP_ON, self.device_configuration['ip'], self.device_configuration['port'])

    def lamp_off(self):
        """
        Turn the lamp off
        """
        execute_serial_command(CMD_LAMP_OFF, self.device_configuration['ip'], self.device_configuration['port'])

    def open_dowser(self):
        """
        Open the dowser
        """
        execute_serial_command(CMD_OPEN_SHUTTER, self.device_configuration['ip'], self.device_configuration['port'])

    def close_dowser(self):
        """
        Close the dowser
        """
        execute_serial_command(CMD_CLOSE_SHUTTER, self.device_configuration['ip'], self.device_configuration['port'])

    def power_on(self):
        """
        Turn the projector on
        """
        execute_serial_command(CMD_POWER_ON, self.device_configuration['ip'], self.device_configuration['port'])

    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        execute_serial_command(CMD_POWER_OFF, self.device_configuration['ip'], self.device_configuration['port'])
# okay decompyling ./core/devices/projector/nec/nec_series_1.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:10 CST
