# 2017.08.13 21:49:09 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\nec\factory.py
"""
This file is meant to cover all the tricks and tweaks of autodetecting an NEC type and instantiating a Device handler class.
"""
import nec_series_1, nec_series_2, nec_series_2_multiple

def assess_device(device_id, device, snmp_manager):
    device_information = device.get_device_information()
    device.device_configuration['version'] = 'series 1'
    if device_information['type'] == 'Type 2':
        if not nec_series_1.check_model_number(device_information['model'], nec_series_1.PROJECTOR_TYPES):
            device.device_configuration['version'] = 'series 2'
            if nec_series_1.check_model_number(device_information['model'], nec_series_2_multiple.PROJECTOR_TYPES):
                return nec_series_2_multiple.NECSeries2Multiple(device_id, device.device_configuration, snmp_manager)
            else:
                return nec_series_2.NECSeries2(device_id, device.device_configuration, snmp_manager)
    return device
# okay decompyling ./core/devices/projector/nec/factory.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:09 CST
