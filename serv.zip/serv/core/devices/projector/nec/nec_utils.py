# 2017.08.13 21:49:11 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\nec\nec_utils.py
"""
Implements communication with NEC projectors using their RFC2217(ish) serial over Ethernet (TCP) interface.
"""
import socket
from struct import pack, unpack
from serv.lib.cherrypy.i18n_tool import ugettext as _

class CheckSumError(Exception):
    """
    Custom exception type to be raised when there is a checksum error
    """
    pass


class NegativeAcknowledgment(Exception):
    """
    Custom exception type for when an NEC call sets the 8th-bit in the response to 1 to indicate a negative acknowledgement
    """
    pass


ERROR_CODES = {(0, 0): 'Unknown command',
 (0, 1): 'The current model does not support this function.',
 (1, 0): 'Invalid values specified.',
 (1, 1): 'Specified terminal is unavailable or cannot be selected.',
 (1, 2): 'Selected language is not available.',
 (1, 3): 'Specified terminal is not installed.',
 (2, 0): 'Available memory reservation error.',
 (2, 1): 'GPIO control enables. From NC2500/1500 1.20, NC800 1.10, not use.',
 (2, 2): 'Operating memory.',
 (2, 3): 'Setting not possible.',
 (2, 4): 'On Forced on-screen mute mode.',
 (2, 6): 'Displaying a signal other than PC Viewer.',
 (2, 7): 'No signal.',
 (2, 8): 'Displaying a test pattern or PC Card Files screen.',
 (2, 9): 'No PC card is inserted.',
 (2, 10): 'Memory operation failed.',
 (2, 12): 'Displaying the Entry List.',
 (2, 13): 'Power Off inhibited.',
 (2, 14): 'Execution error.',
 (2, 15): 'No operation cinema_services.',
 (3, 0): 'Specified gain number is wrong.',
 (3, 1): 'Selected gain is not available.',
 (3, 2): 'Adjustment failed.',
 (6, 0): 'MMS through command processing failed MMS is not Linked)',
 (6, 1): 'MMS through command processing failed(MMS is not connected)',
 (6, 2): 'MMS through command processing failed(Send error)',
 (6, 3): 'MMS through command processing failed(Recv error(Timeout))',
 (6, 4): 'MMS through command processing failed (Processing is invalid while NC series is standby)'}

def _calculate_checksum(values):
    checksum = reduce(lambda x, y: x + y, values)
    checksum_high_order = checksum >> 8 << 8
    return checksum - checksum_high_order


def _create_command_bytestring(values, chksum = False):
    """
    Creates the bytestring to be sent to the NEC via the serial connection from a list of the hex/int values that make up the command.
    """
    if chksum:
        values += (_calculate_checksum(values),)
    return pack('<{x}B'.format(x=len(values)), *values)


CMD_COMMON_DATA_REQUEST = _create_command_bytestring((0, 192, 0, 0, 0, 192))
CMD_POWER_ON = _create_command_bytestring((2, 0, 0, 0, 0, 2))
CMD_POWER_OFF = _create_command_bytestring((2, 1, 0, 0, 0, 3))
CMD_LAMP_ON = _create_command_bytestring((3, 47, 0, 0, 2, 18, 1), True)
CMD_LAMP_OFF = _create_command_bytestring((3, 47, 0, 0, 2, 18, 2), True)
CMD_LAMP_POWER = _create_command_bytestring((3, 47, 0, 0, 1, 0, 51))
CMD_CLOSE_SHUTTER = _create_command_bytestring((2, 22, 0, 0, 0, 24))
CMD_OPEN_SHUTTER = _create_command_bytestring((2, 23, 0, 0, 0, 25))
CMD_DATE_TIME_REQUEST = _create_command_bytestring((3, 129, 0, 0, 0, 132))

def _process_response_header(response_header):
    """
    Unpack the header of the response frame
    """
    id_1, id_2, projector_id, model_code_and_high_order_data_len, low_order_data_len = unpack('<5B', response_header)
    header_checksum = id_1 + id_2 + projector_id + model_code_and_high_order_data_len + low_order_data_len
    model_code = model_code_and_high_order_data_len >> 4
    high_order_data_len = model_code_and_high_order_data_len - (model_code << 4)
    data_length = (high_order_data_len << 8) + low_order_data_len
    return (id_1,
     id_2,
     projector_id,
     model_code,
     data_length,
     header_checksum)


def execute_serial_command(cmd, ip, port = 7142):
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    soc.connect((ip, port))
    soc.settimeout(5)
    soc.sendall(cmd)
    response_header = soc.recv(5)
    id_1, id_2, projector_id, model_code, data_length, header_checksum = _process_response_header(response_header)
    response_data = soc.recv(data_length + 1)
    soc.close()
    data_and_checksum = unpack('<{x}B'.format(x=data_length + 1), response_data)
    data, response_checksum = data_and_checksum[:-1], data_and_checksum[-1]
    data_checksum = _calculate_checksum([header_checksum] + list(data))
    if data_checksum != response_checksum:
        raise CheckSumError('Checksum [{0}] did not match given [{1}]'.format(data_checksum, response_checksum))
    elif id_1 & 128:
        logging.error('Error communicating with the NEC: %s' % ERROR_CODES.get(data, 'Unknown Error: %s' % s))
        raise NegativeAcknowledgment(_('Error communicating with Projector'))
    return data
# okay decompyling ./core/devices/projector/nec/nec_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:11 CST
