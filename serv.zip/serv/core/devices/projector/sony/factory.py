# 2017.08.13 21:49:12 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\sony\factory.py
"""
This file is meant to cover all the tricks and tweaks of autodetecting an SONY type and instantiating a Device handler class.
"""
import sony_multi

def assess_device(device_id, device):
    device_info = device.get_device_information()
    if sony_multi.supported_model(device_info['model']):
        device = sony_multi.SonyProjectorMulti(device_id, device.device_configuration)
    return device
# okay decompyling ./core/devices/projector/sony/factory.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:12 CST
