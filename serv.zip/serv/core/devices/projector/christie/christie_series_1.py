# 2017.08.13 21:49:07 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\christie\christie_series_1.py
"""
Implementation of Core2 projection API for Christie series 1 projectors
"""
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.network.snmp import SNMPError, SNMPTimeout
from serv.core.devices.base.projection import Projection
from christie_utils import execute_ascii_command, ChristieBadResponse, CMD_POWER, CMD_DOWSER, CMD_TIME_AND_DATE, CMD_LAMP_LIMIT
from normalizers import Christie1Normalizer
import socket
PROJECTOR_STATUS = {'0': 'Unknown',
 '1': 'Warming Up',
 '2': 'Power On',
 '3': 'Cooling',
 '4': 'Power Off',
 '5': 'Lamp On'}
LAMP_STATUS = {'1': 'Lamp On',
 '2': 'Unexpected Off',
 '3': 'Ignition Failure',
 '4': 'Lamp Off'}
DOWSER_STATUS = {'1': 'Open',
 '2': 'Closed'}
PROJECTOR_TYPES = ['CP2000',
 'CP2000-M',
 'CP2000-S',
 'CP2000-ZX',
 'CP2000-SB',
 'CP2000-X',
 'CP2000-XB']

class ChristieSeries1(Projection):
    """
    An implementation of Projection for Christie series 1 projectors
    """

    def __init__(self, id, device_info, snmp_manager):
        super(ChristieSeries1, self).__init__(id, device_info)
        self.snmp_manager = snmp_manager
        self.response = {}
        self.response['projector_type'] = None
        self.response['error_messages'] = []
        self.normalizer = Christie1Normalizer()
        return

    def get_device_status(self):
        """
        Returns the status of the device
        """
        output = {'current_time': None,
         'error_messages': []}
        return output

    def get_device_information(self):
        """
        Returns information regarding the device
        """
        output = {'type': None,
         'error_messages': []}
        projector_type = self._execute_snmp('1.3.6.1.4.1.25766.1.11.1.1.0', version=2, throw=True)
        if projector_type:
            output['type'] = projector_type
            output['model'] = projector_type
        return output

    def test_management_connection(self):
        try:
            self._execute_ascii(CMD_TIME_AND_DATE)
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error [%s]') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unexpected error [%s]') % str(ex))

        try:
            self.snmp_manager.snmpGet('1.3.6.1.4.1.25766.1.11.1.1.0', self.device_configuration['ip'], version=2)
        except SNMPTimeout:
            return (False, _('Timed out while trying to connect'))
        except SNMPError:
            pass

        return (True, _('OK'))

    def get_projector_status(self):
        """
        Gets the available status values for the projector
        @return 
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        self.response['error_messages'] = []
        lamp_maximum = self._execute_ascii(CMD_LAMP_LIMIT)
        if lamp_maximum:
            try:
                int_lamp_maximum = int(lamp_maximum)
                self.response['api_lamp_life_maximum'] = int_lamp_maximum
            except ValueError:
                pass

        return self.response

    def _execute_ascii(self, command):
        re = None
        try:
            re = execute_ascii_command(command, self.device_configuration['ip'], self.device_configuration['port'])
        except (ChristieBadResponse, socket.error):
            pass
        except Exception as ex:
            self.response['error_messages'].append('Error communicating: %s' % str(ex))

        return re

    def _execute_snmp(self, oid, version = 1, throw = False):
        re = None
        try:
            re = self.snmp_manager.snmpGet(oid, self.device_configuration['ip'], version)
        except (SNMPTimeout, SNMPError) as e:
            if throw:
                raise e
        except Exception as ex:
            self.response['error_messages'].append('Error communicating: %s' % str(ex))

        return re

    def open_dowser(self):
        """
        Open the dowser
        """
        execute_ascii_command(CMD_DOWSER, self.device_configuration['ip'], self.device_configuration['port'], arg='0')

    def close_dowser(self):
        """
        Close the dowser
        """
        execute_ascii_command(CMD_DOWSER, self.device_configuration['ip'], self.device_configuration['port'], arg='1')

    def power_on(self):
        """
        Turn the projector on
        """
        execute_ascii_command(CMD_POWER, self.device_configuration['ip'], self.device_configuration['port'], arg='1')

    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        execute_ascii_command(CMD_POWER, self.device_configuration['ip'], self.device_configuration['port'], arg='0')

    def lamp_on(self):
        """
        Strike the lamp
        """
        raise NotImplementedError

    def lamp_off(self):
        """
        Turn the lamp off
        """
        raise NotImplementedError
# okay decompyling ./core/devices/projector/christie/christie_series_1.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:07 CST
