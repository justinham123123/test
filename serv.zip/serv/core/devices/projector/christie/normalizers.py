# 2017.08.13 21:49:08 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\christie\normalizers.py
from serv.core.devices.base.normalizer import DefaultNormalizer
import logging
PROJECTOR_STATUS = {0: 'Unknown',
 1: 'Warming Up',
 2: 'Power On',
 3: 'Cooling',
 4: 'Power Off',
 5: 'Power On'}
LAMP_STATUS = {1: 'Lamp On',
 2: 'Unexpected Off',
 3: 'Ignition Failure',
 4: 'Lamp Off'}
DOWSER_STATUS = {1: 'Open',
 2: 'Closed'}

class Christie1Normalizer(DefaultNormalizer):

    def __init__(self):
        super(Christie1Normalizer, self).__init__()
        self.add_mapping('projector_status', PROJECTOR_STATUS)
        self.add_mapping('lamp_status', LAMP_STATUS)
        self.add_mapping('dowser_status', DOWSER_STATUS)
        self.add_extension(None, ['lamps', 'api_lamp_life_maximum'], self.enhance_lamps)
        return

    def enhance_lamps(self, lamps, api_lamp_life_maximum):
        for lamp in lamps:
            try:
                if 'life_used' in lamp:
                    lamp['life_maximum'] = api_lamp_life_maximum
                    lamp['life_remaining'] = api_lamp_life_maximum - int(lamp['life_used'])
                    lamp['life'] = int(float(lamp['life_used']) / float(lamp['life_maximum']) * 100)
            except Exception as e:
                logging.debug('Exception in %s: %s', self.__class__.__name__, str(e))

        return None
# okay decompyling ./core/devices/projector/christie/normalizers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:08 CST
