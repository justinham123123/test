# 2017.08.13 21:49:07 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\christie\christie_utils.py
"""
Christie Utilities
"""
import re, socket

class ChristieBadResponse(Exception):
    pass


CMD_PING = 'PNG'
CMD_POWER = 'PWR'
CMD_DOWSER = 'SHU'
CMD_TIME_AND_DATE = 'TMD'
CMD_LAMP_LIMIT = 'LPL'
CMD_SYSTEM_STATUS = 'SST?1'
CMD_ICP_CERT = 'TIG+ICPC?'
CMD_LD_CERT = 'TIG+ENGC?'

def _escape_arg(arg):
    arg = arg.encode('utf-8').encode('string_escape')
    arg = arg.replace('(', '\\(').replace(')', '\\)')
    arg = arg.replace('"', '"')
    arg = arg.replace('\\x1b', '\\x')
    arg = arg.replace('\\x01', '\\b').replace('\\x0e', '\\e')
    arg = arg.replace('\\x11', '\\g').replace('\\x13', '\\s')
    return arg


_response_re = re.compile('\\((?P<cmd>\\w+)\\!(?P<value>.+)\\)')

def execute_ascii_command(cmd, ip, port = 5000, arg = None):
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    soc.connect((ip, port))
    soc.settimeout(5)
    if arg is None:
        cmd_string = '({cmd}?)'.format(cmd=cmd)
        soc.send(cmd_string)

        def read_soc(soc):
            msg = ''
            max = 10000
            chunk_size = 100
            while len(msg) < max:
                chunk = soc.recv(chunk_size)
                if len(chunk) < 100:
                    msg = msg + chunk
                    return msg
                msg = msg + chunk

            return msg

        response = read_soc(soc)
        response = response[response.find('!') + 1:len(response) - 1]
        if response is not None:
            return response
        raise ChristieBadResponse('Bad response from Christie projector')
    else:
        _escape_arg(arg)
        cmd_string = '(${cmd} {arg})'.format(cmd=cmd, arg=arg)
        soc.send(cmd_string)
        if soc.recv(256) != '$':
            return
        raise ChristieBadResponse('Bad response from Christie projector')
    soc.close()
    return
# okay decompyling ./core/devices/projector/christie/christie_utils.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:08 CST
