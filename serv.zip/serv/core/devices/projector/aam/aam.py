# 2017.08.13 21:49:05 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\aam\aam.py
"""
Emulated projector adaptor
"""
from serv.core.devices.base.projection import Projection
from serv.core.devices.sms.aam.aam_utils import execute
from serv.lib.cherrypy.i18n_tool import ugettext as _

class AAMulator(Projection):

    def __init__(self, id, device_info):
        super(Projection, self).__init__(id, device_info)

    def _execute(self, api, func = None, params = {}, error_list = False):
        return execute(self.device_configuration['ip'], self.device_configuration['port'], api, func=func, params=params, error_list=error_list)

    def get_device_status(self):
        return {'error_messages': []}

    def test_management_connection(self):
        return (True, _('OK'))

    def get_device_information(self):
        return {'type': None,
         'error_messages': []}

    def get_projector_status(self):
        response = self._execute('player', 'status')
        return {'error_messages': [],
         'lamp_status': 'Lamp On' if response.get('lamp_on') else 'Lamp Off',
         'projector_status': 'Power On',
         'dowser_status': 'Open' if response.get('dowser_open') else 'Closed',
         'lamps': [{'life_used': response.get('lamp_used', None),
                    'life_maximum': response.get('lamp_life', None),
                    'life_remaining': response.get('lamp_life', 0) - response.get('lamp_used', 0)}]}

    def lamp_on(self):
        """
        Strike the lamp
        """
        raise NotImplementedError

    def lamp_off(self):
        """
        Turn the lamp off
        """
        raise NotImplementedError

    def open_dowser(self):
        """
        Open the dowser
        """
        raise NotImplementedError

    def close_dowser(self):
        """
        Close the dowser
        """
        raise NotImplementedError

    def power_on(self):
        """
        Turn the projector on
        """
        raise NotImplementedError

    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        raise NotImplementedError
# okay decompyling ./core/devices/projector/aam/aam.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:05 CST
