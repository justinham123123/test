# 2017.08.13 21:49:05 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\projector\barco\barco_series_1.py
"""
Implementation of Core2 projection API for Barco series 1 projectors
"""
import socket
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.base.projection import Projection
from serv.lib.network.snmp import SNMPError, SNMPTimeout
from serv.core.devices.projector.barco.normalizers import BarcoNormalizer
DOWSER_STATUS = {'0': 'Closed',
 '1': 'Open',
 '2': 'Undetermined'}
PROJECTOR_TYPES = ['DP',
 'SNMP Agent DP',
 'SNMP Agent DP100',
 'DP1200',
 'DP1500',
 'DP2000',
 'DP3000']

class BarcoSeries1(Projection):
    """
    An implementation of Projection for Barco series 1 projectors
    """

    def __init__(self, id, device_info, snmp_manager):
        super(BarcoSeries1, self).__init__(id, device_info)
        self.snmp_manager = snmp_manager
        self.normalizer = BarcoNormalizer()
        self.response = {}
        self.response['error_messages'] = []

    def get_device_status(self):
        """
        Returns the status of the device
        """
        return {'error_messages': []}

    def test_management_connection(self):
        try:
            socket.getaddrinfo(self.device_configuration['ip'], 161)
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))

        try:
            self.snmp_manager.snmpGet('1.3.6.1.2.1.1.1.0', self.device_configuration['ip'], version=1)
        except SNMPTimeout:
            return (False, _('Timed out while trying to connect'))
        except SNMPError:
            pass

        return (True, _('OK'))

    def get_device_information(self):
        """
        Returns information regarding the device
        """
        output = {'type': None,
         'error_messages': []}
        output['type'] = self._execute_snmp('1.3.6.1.2.1.1.1.0', version=2, throw=True)
        output['model'] = output['type']
        return output

    def get_projector_status(self):
        """
        Gets the available status values for the projector
        @return 
                DICT
                    projector_status  -INT
                    lamp      -DICT
                                   status          -BOOL
                                   type            -STRING
                                   max_life        -INT
                                   used_life       -INT
                                   remaining_life  -INT
                                   current         -INT
                    dowser_status     -INT
                    error_messages    -LIST of errors
        """
        self.response['error_messages'] = []
        self.response['type'] = self._execute_snmp('1.3.6.1.2.1.1.1.0', version=2, throw=True)
        self.response['model'] = self.response['type']
        return self.response

    def _execute_snmp(self, oid, version = 1, throw = False):
        re = None
        try:
            re = self.snmp_manager.snmpGet(oid, self.device_configuration['ip'], version)
        except (SNMPTimeout, SNMPError) as e:
            if throw:
                raise e
        except Exception as ex:
            self.response['error_messages'].append(_('Error communicating: %s') % str(ex))

        return re

    def lamp_on(self):
        """
        Strike the lamp
        """
        raise NotImplementedError

    def lamp_off(self):
        """
        Turn the lamp off
        """
        raise NotImplementedError

    def open_dowser(self):
        """
        Open the dowser
        """
        raise NotImplementedError

    def close_dowser(self):
        """
        Close the dowser
        """
        raise NotImplementedError

    def power_on(self):
        """
        Turn the projector on
        """
        raise NotImplementedError

    def power_off(self):
        """
        Turn the projector off / put it into standby mode
        """
        raise NotImplementedError
# okay decompyling ./core/devices/projector/barco/barco_series_1.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:49:05 CST
