# 2017.08.13 21:48:42 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\camera\axis\axis.py
import urllib2, datetime, calendar, socket
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.base.camera import Camera

class AXIS_M1011(Camera):
    """
    Implemntation of the API for the AXIS M1011 Network Camera
    """
    SUPPORTED_RESOLUTIONS = sorted([(640, 480),
     (640, 360),
     (480, 360),
     (384, 288),
     (352, 288),
     (352, 240),
     (320, 240),
     (240, 180),
     (192, 144),
     (176, 144),
     (176, 120),
     (160, 120)])

    def __init__(self, id, device_info):
        super(AXIS_M1011, self).__init__(id, device_info)
        self.device_configuration['active_image_pull'] = device_info.get('active_image_pull', True)

    def _call_camera(self, cmd):
        """
        Makes a call to an Axis camera through its CGI API
        """
        passwd_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
        passwd_mgr.add_password(realm=None, uri='http://{host}:{port}/axis-cgi/'.format(host=self.device_configuration['ip'], port=self.device_configuration['port']), user=self.device_configuration['api_username'], passwd=self.device_configuration['api_password'])
        auth_handler = urllib2.HTTPBasicAuthHandler(passwd_mgr)
        opener = urllib2.build_opener(auth_handler)
        response = opener.open('http://{host}:{port}/axis-cgi/{cmd}'.format(host=self.device_configuration['ip'], port=self.device_configuration['port'], cmd=cmd), timeout=5).read()
        return response

    def get_device_status(self):
        """
        Returns the status of the device
        """
        try:
            camera_date_string = self._call_camera('date.cgi?action=get')
            camera_datetime = datetime.datetime.strptime(camera_date_string, '%b %d, %Y %H:%M:%S')
            camera_timestamp = calendar.timegm(camera_datetime.timetuple())
            return {'current_time': camera_timestamp,
             'error_messages': []}
        except Exception as ex:
            return {'error_messages': [_('Error trying to get system time: %s') % str(ex)]}

    def test_management_connection(self):
        try:
            self._call_camera('date.cgi?action=get')
        except urllib2.URLError as ex:
            return (False, _('URL error [%s]' % str(ex)))
        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error [%s]') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unknown error [%s]') % str(ex))

        return (True, _('OK'))

    def get_properties(self):
        response = self._call_camera('view/param.cgi?action=list&group=Brand,Properties')
        return dict([ x.split('=', 1) for x in response.strip('\n').splitlines() if '=' in x ])

    def get_device_version_information(self):
        """
        Returns version information regarding the device
        """
        info = {'error_messages': []}
        re = self.get_properties()
        info['firmware_version'] = re['root.Properties.Firmware.Version']
        return info

    def get_device_information(self):
        """
        Returns information regarding the device
        """
        info = {'error_messages': []}
        re = self.get_properties()
        info['firmware_version'] = re['root.Properties.Firmware.Version']
        info['serial'] = re['root.Properties.System.SerialNumber']
        info['supported_resolutions'] = re['root.Properties.Image.Resolution'].split(',')
        info['type'] = re['root.Brand.ProdNbr']
        return info

    def get_live_image(self, resolution = (240, 180)):
        """
        Captures an image from the camera
        """
        for supported_resolution in self.SUPPORTED_RESOLUTIONS:
            if supported_resolution[0] >= resolution[0] and supported_resolution[1] >= resolution[1]:
                resolution = supported_resolution
                break

        return self._call_camera('jpg/image.cgi?text=0&date=0&clock=0&resolution=%dx%d' % resolution)


class AXIS_M1113(AXIS_M1011):
    pass


class AXIS_M1014(AXIS_M1011):
    SUPPORTED_RESOLUTIONS = sorted([(640, 480),
     (640, 360),
     (480, 360),
     (384, 288),
     (352, 288),
     (352, 240),
     (320, 240)])

    def get_live_image(self, resolution = (320, 240)):
        """
        The M1014 model doesn't support jpg resolutions less than 320x240,
        so we override this function from the AXIS_M1011 class to make sure
        we only try and get an image at supported resolutions
        """
        return super(AXIS_M1014, self).get_live_image(resolution)
# okay decompyling ./core/devices/camera/axis/axis.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:42 CST
