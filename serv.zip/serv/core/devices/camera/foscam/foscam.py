# 2017.08.13 21:48:42 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\camera\foscam\foscam.py
"""
Foscam integration
"""
import re
import socket
from datetime import datetime
from urllib2 import urlopen
import urllib2
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.core.devices.base.camera import Camera

class Foscam(Camera):
    """
    Wrapper for the Foscam webcam API
    """

    def _get(self, path):
        """
        Wrapper for making a HTTP GET
        """
        import httplib as h
        domain = h.HTTPConnection(self.device_configuration['ip'], port=self.device_configuration['port'], timeout=10)
        domain.connect()
        url = '/%s?user=%s&pwd=%s' % (path, self.device_configuration['api_username'], self.device_configuration['api_password'])
        domain.request('GET', url)
        return domain.getresponse().read()

    def _status(self):
        """
        Gets various status info regarding the camera
        """
        result = {}
        raw_status = self._get('get_status.cgi')
        result['firmware'] = re.compile("sys_ver=\\'([\\d|\\.]+)\\';").search(raw_status).group(1)
        result['software'] = re.compile("app_ver=\\'([\\d|\\.]+)\\';").search(raw_status).group(1)
        result['time'] = datetime.fromtimestamp(int(re.compile('now=(\\d+);').search(raw_status).group(1)))
        return result

    def __init__(self, id, device_info):
        super(Foscam, self).__init__(id, device_info)
        self.device_configuration['active_image_pull'] = device_info.get('active_image_pull', True)

    def get_device_status(self):
        try:
            return {'current_time': self._status()['time'],
             'error_messages': []}
        except Exception as ex:
            return {'error_messages': [_('Error retrieving system time: %s') % str(ex)]}

    def test_management_connection(self):
        try:
            try:
                self._status()
            except urllib2.URLError as ex:
                if isinstance(ex.reason, socket.error):
                    raise ex.reason
                else:
                    return (False, _('URL error %s' % str(ex)))

        except socket.timeout:
            return (False, _('Timed out while trying to connect'))
        except (socket.herror, socket.gaierror):
            return (False, _('Unable to find the configured host or address'))
        except socket.error as ex:
            return (False, _('Network error %s') % (ex.args[1:2] or ex.args[0]))
        except Exception as ex:
            return (False, _('Unknown error %s') % str(ex))

        return (True, _('OK'))

    def get_device_version_information(self):
        """
        Returns version information regarding the device
        """
        try:
            return {'firmware_version': self._status()['time'],
             'error_messages': []}
        except Exception as ex:
            return {'error_messages': [_('Error trying to get device version: %s') % str(ex)]}

    def get_device_information(self):
        """
        Returns information regarding the device
        """
        return self.get_device_version_information()

    def get_live_image(self, resolution = None):
        """
        Captures an image from the camera
        """
        return self._get('snapshot.cgi')
# okay decompyling ./core/devices/camera/foscam/foscam.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:43 CST
