# 2017.08.13 21:48:43 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\content\aamLMS\aamLMS.py
import datetime
import json
import logging
import math
import os
import posixpath
import shutil
import threading
import time
from uuid import uuid4
import cherrypy
from serv.core.devices.base.playlist import Playlist
from serv.configuration import cfg
from serv.core.devices.base.ingest import Ingest
from serv.core.devices.base.pos import POS
from serv.core.devices.content.aamLMS.plugins.copy_plugins import create_dir
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.lib.dcinema.dcp import mxf
from serv.lib.dcinema.dcp.asset import AssetType
from serv.lib.dcinema.dcp.dcp import DCP
from serv.lib.dcinema.dcp.file_handlers import FileHandler, FTPHandler
from serv.lib.dcinema.dcp.helpers import _get_assetmap_pkl_volindex, _folder_is_package, _force_contents, _analyze_cpl
from serv.lib.dcinema.parsers.parsers import parse_kdm, parse_cpl, parse_content_title_text, parse_pos
from serv.lib.utilities.action import Action
from serv.lib.utilities.linking import create_hard_link

class AAMLMS(Ingest, Playlist, POS):
    """
    aamLMS server access and control
    """

    def __init__(self, id, device_info):
        super(AAMLMS, self).__init__(id, device_info)
        self.last_modified = time.time()
        self.device_configuration['ip'] = self.device_configuration['ftp_ip']
        self.auto_sync = False
        self.storage_configuration = {'library_folder': cfg.lms_library_directory(),
         'ingest_folder': os.path.join(cfg.lms_library_directory(), 'INGEST'),
         'cpl_folder': os.path.join(cfg.lms_library_directory(), 'CPL'),
         'kdm_folder': os.path.join(cfg.lms_library_directory(), 'KDM'),
         'asset_folder': os.path.join(cfg.lms_library_directory(), 'ASSET'),
         'playlist_folder': os.path.join(cfg.lms_library_directory(), 'PLAYLIST'),
         'template_folder': os.path.join(cfg.lms_library_directory(), 'TEMPLATE'),
         'composite_folder': os.path.join(cfg.lms_library_directory(), 'COMPOSITE'),
         'pos_folder': os.path.join(cfg.lms_library_directory(), 'POS')}
        for key in self.storage_configuration.keys():
            if not os.path.exists(self.storage_configuration[key]):
                os.mkdir(self.storage_configuration[key])

        tmp_dir = os.path.join(cfg.lms_library_directory(), 'tmp')
        if not os.path.isdir(tmp_dir):
            os.makedirs(tmp_dir)
        self.content_store_lock = threading.RLock()
        self.content_store = {'assets': {},
         'cpls': {},
         'kdms': {},
         'playlists': {},
         'templates': {}}
        self.sync_status['content_scan_active'] = False
        self.sync_status['content_scan_stamp'] = None
        self.sync_status['content_scan_remaining'] = None
        self.sync_status['content_scan_done'] = None
        cherrypy.engine.subscribe('file_copy_progress', self.update_file_status)
        cherrypy.engine.subscribe('file_copy_cancel', self.cancel_ingest)
        cherrypy.engine.subscribe('file_copy_finish', self.transfer_finished)
        self.strip_automation = False
        self.corrupt_content = {'cpls': [],
         'playlists': []}
        return

    def _time_tuple_to_seconds(self, time_tuple):
        """
        (2038,12,31,23,59,00,0,0,0)
        is overflowing.. this roofs time at 2038
        """
        try:
            return math.trunc(time.mktime(time_tuple))
        except OverflowError:
            return 2147483647.0

    def add_pos_file(self, file, filename):
        path = os.path.join(self.storage_configuration['pos_folder'], filename)
        with open(path, 'w') as new_file:
            new_file.write(file)
        self._device_sync_pos_information()

    def get_schedule(self, start_date, end_date, complex_ids):
        """
        Gets a schedule of films for a cinema theatre
        """
        re = {'sessions': [],
         'messages': [],
         'success': False,
         'allow_empty': True}
        dirlist = os.listdir(self.storage_configuration['pos_folder'])
        to_remove = []
        if not dirlist:
            re['success'] = True
            return re
        for filename in dirlist:
            path = os.path.join(self.storage_configuration['pos_folder'], filename)
            try:
                pos_file = open(path).read()
                if not parse_pos(pos_file, self.device_id, filename=filename):
                    sessions = []
                    empty = True
                    for session in sessions:
                        if session['start'].date() >= start_date:
                            empty = False
                        if start_date <= session['start'].date() <= end_date:
                            re['sessions'].append(session)

                    empty and to_remove.append(path)
                re['success'] = True
            except Exception as e:
                message = 'Could not parse pos file: %s' % e
                logging.error(message)
                re['messages'].append({'type': 'error',
                 'message': message})
                to_remove.append(path)

        for remove in to_remove:
            try:
                os.remove(remove)
            except Exception as e:
                logging.error('Failed to remove expired LMS POS file: %s' % e)

        return re

    def content_ready(self):
        return self.sync_status['last_updated'] != None and self.sync_status['content_scan_stamp'] != None and not self.sync_status['content_scan_active']

    def _sync_cpl_folder(self, cpl_uuid, resync_related = True, work = 0):
        try:
            cpls = [cpl_uuid]
            if resync_related:
                for asset in self.content_store['cpls'][cpl_uuid]['assets']:
                    for cpl in self.content_store['assets'][asset]['cpls']:
                        if cpl not in cpls:
                            cpls.append(cpl)

            for cpl in set(cpls):
                self.__sync_cpl(cpl, work)

            if not self.sync_status['content_scan_stamp'] and cfg.auto_generate_dcps.get():
                cherrypy.engine.publish('queue_cpl_for_dcp_creation', cpl_uuid)
        except Exception:
            logging.error('Error syncing CPL folder %s' % str(cpl_uuid), exc_info=True)

    def __sync_cpl(self, cpl_uuid, unit_of_work):
        """
        Syncs the cpl folder with info stored in memory
        """
        cpl = self.content_store['cpls'][cpl_uuid]
        cpl_ingest_folder = os.path.join(self.storage_configuration['ingest_folder'], cpl['uuid'])
        cpl_folder = os.path.join(self.storage_configuration['cpl_folder'], cpl['uuid'])
        if os.path.exists(cpl_ingest_folder):
            shutil.rmtree(os.path.join(cpl_ingest_folder))
        self.make_dir(cpl_ingest_folder)
        json_dict = {}
        for root, dirs, files in os.walk(cpl_folder):
            for file_name in files[:]:
                if file_name.lower() == 'info.json':
                    try:
                        with open(os.path.join(root, file_name), 'rb') as f:
                            json_dict = json.loads(f.read())
                        break
                    except Exception:
                        logging.error('Unable to get contents of INFO.json for %s' % root, exc_info=True)

        if 'hash' not in json_dict and json_dict.get('generated_hash', None):
            logging.warn('CPL missing hash value, defaulting to generated hash: ' + cpl_uuid)
            cpl['hash'] = json_dict['generated_hash']
            cpl['status'] = -1
        missing_font_details = None
        if json_dict.has_key('missing_font_id'):
            missing_font_details = {'missing_font_id': json_dict['missing_font_id'],
             'missing_font_path': json_dict['missing_font_path'],
             'missing_font_size': json_dict['missing_font_size'],
             'missing_font_hash': json_dict['missing_font_hash']}
        assetmap_xml, pkl_xml, volindex_xml = _get_assetmap_pkl_volindex(cpl, self.content_store['assets'], missing_font_details)
        _force_contents(os.path.join(cpl_ingest_folder, 'ASSETMAP'), assetmap_xml.encode('utf-8'))
        _force_contents(os.path.join(cpl_ingest_folder, 'pkl.xml'), pkl_xml.encode('utf-8'))
        _force_contents(os.path.join(cpl_ingest_folder, 'VOLINDEX'), volindex_xml.encode('utf-8'))
        target = os.path.join(cpl_ingest_folder, cpl['file_name'])
        source = os.path.join(cpl_folder, cpl['file_name'])
        if os.path.exists(source):
            self.hard_link(source, target)
            size = json_dict['size'] if 'size' in json_dict else os.path.getsize(source)
            with self.content_store_lock:
                self.content_store['cpls'][cpl_uuid]['actual_size'] = size
                self.content_store['cpls'][cpl_uuid]['total_actual_size'] = size
        for asset_uuid in cpl['assets']:
            asset = self.content_store['assets'][asset_uuid]
            if asset['status'] != None:
                file_name = asset['file_name']
                if asset['parent_folder']:
                    ingest_asset_folder = os.path.join(cpl_ingest_folder, asset['parent_folder'])
                    self.make_dir(ingest_asset_folder)
                    file_name = os.path.join(asset['parent_folder'], file_name)
                source = os.path.join(self.storage_configuration['asset_folder'], asset_uuid, asset['file_name'])
                if os.path.exists(source):
                    self.hard_link(source, os.path.join(cpl_ingest_folder, file_name))
                    size = os.path.getsize(source)
                    with self.content_store_lock:
                        self.content_store['assets'][asset['uuid']]['actual_size'] = size
                        self.content_store['cpls'][cpl_uuid]['total_actual_size'] += size

        self.sync_status['content_scan_done'] += unit_of_work
        return

    def hard_link(self, source, target):
        try:
            create_hard_link(source, target)
        except Exception as ex:
            if not os.path.exists(target):
                logging.error('Problem creating hard link for files %s to %s' % (source, target))
                raise

    def make_dir(self, path):
        if not os.path.exists(path):
            try:
                os.mkdir(path)
            except Exception:
                logging.error('Unable to create directory %s' % path, exc_info=True)
                raise

    def sync_content_store(self):
        with self.content_store_lock:
            self.content_store = {'assets': {},
             'cpls': {},
             'kdms': {},
             'playlists': {},
             'templates': {}}
        action = Action(self.__load_content_store)
        self.push_action_stack(action)
        return action.action_id

    def __directory_size(self, path):
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(path):
            for f in filenames:
                total_size += os.path.getsize(os.path.join(dirpath, f))

        return float(total_size)

    def __calculate_work(self):
        self.sync_status['content_scan_remaining'] = 0
        self.sync_status['content_scan_remaining'] += self.__directory_size(self.storage_configuration['template_folder'])
        self.sync_status['content_scan_remaining'] += self.__directory_size(self.storage_configuration['cpl_folder'])
        self.sync_status['content_scan_remaining'] += self.__directory_size(self.storage_configuration['kdm_folder'])
        self.sync_status['content_scan_remaining'] += self.__directory_size(self.storage_configuration['asset_folder'])
        self.sync_status['content_scan_remaining'] += self.__directory_size(self.storage_configuration['playlist_folder'])
        self.sync_status['content_scan_remaining'] += self.__directory_size(self.storage_configuration['ingest_folder'])
        self.sync_status['content_scan_done'] = 0.0

    def __load_content_store(self):
        self.__calculate_work()
        self.sync_status['content_scan_active'] = True
        self.__synchronize_playlists()
        self.__synchronize_assets()
        self.__synchronize_cpls()
        self.__synchronize_kdms()
        self.__synchronize_templates()
        self.__rebuild_content_store()
        with self.content_information_lock:
            self.content_information['last_updated'] = None
        with self.key_information_lock:
            self.key_information['last_updated'] = None
        with self.playlist_information_lock:
            self.playlist_information['last_updated'] = None
        self.sync_status['content_scan_active'] = False
        self.sync_status['content_scan_stamp'] = time.time()
        if cfg.auto_generate_dcps.get():
            cherrypy.engine.publish('queue_all_packs_for_dcp_creation')
        return (True, _('LMS content has been synced'))

    def __rebuild_content_store(self):
        ingest_directory_count = len(os.listdir(self.storage_configuration['ingest_folder']))
        if ingest_directory_count:
            unit_of_work = int(self.__directory_size(self.storage_configuration['ingest_folder'])) / ingest_directory_count / 2
        else:
            unit_of_work = 0
        core_ftp_path = os.path.normcase(os.path.join(cfg.lms_library_directory(), 'tmp'))
        for thing in os.listdir(self.storage_configuration['ingest_folder']):
            thing_path = os.path.normcase(os.path.abspath(os.path.join(self.storage_configuration['ingest_folder'], thing)))
            if thing_path != core_ftp_path and 'tmp_ingest' not in thing_path:
                path = os.path.join(self.storage_configuration['ingest_folder'], thing)
                self.sync_status['content_scan_done'] += unit_of_work
                if os.path.isfile(path):
                    os.remove(path)
                else:
                    shutil.rmtree(path)

        for cpl in self.content_store['cpls'].keys():
            self._sync_cpl_folder(cpl, resync_related=False, work=unit_of_work)

    def __is_playlist_template(self, playlist):
        is_template = False
        for event in playlist['events']:
            if event['type'] == 'title' or event['type'] == 'placeholder':
                is_template = True
                break

        return is_template

    def __synchronize_templates(self):
        """
        Synchronize the templates from file system to the data store
        """
        for root, dirs, files in os.walk(self.storage_configuration['template_folder']):
            if root == self.storage_configuration['template_folder']:
                continue
            if len(files) != 1:
                logging.error('Should be at most one non-info file in each lms library subfolder, %s has %d' % (root, len(files)))
                continue
            template_info = {}
            for file_name in files:
                file_path = os.path.join(root, file_name)
                self.sync_status['content_scan_done'] += float(os.path.getsize(file_path))
                with open(file_path) as f:
                    template_info = json.loads(f.read())

            if not template_info.has_key('cpl_transitions'):
                template_info['cpl_transitions'] = False
            with self.content_store_lock:
                self.content_store['templates'][template_info['uuid']] = template_info

    def __synchronize_playlists(self):
        """
        Synchronize the playlists from file system to the data store
        """
        self.corrupt_content['playlists'] = []
        for root, dirs, files in os.walk(self.storage_configuration['playlist_folder']):
            if root == self.storage_configuration['playlist_folder']:
                continue
            if len(files) != 1:
                logging.error('Should be at most one non-info file in each lms library subfolder, %s has %d' % (root, len(files)))
                continue
            playlist_info = {}
            for file_name in files:
                file_path = os.path.join(root, file_name)
                self.sync_status['content_scan_done'] += float(os.path.getsize(file_path))
                with open(file_path) as f:
                    try:
                        playlist_info = json.loads(f.read())
                    except Exception:
                        logging.error('Error reading playlist %s ' % file_name, exc_info=True)
                        self.corrupt_content['playlists'].append(os.path.join(root, file_name))

            if playlist_info:
                playlist_info['is_template'] = self.__is_playlist_template(playlist_info)
                with self.content_store_lock:
                    self.content_store['playlists'][playlist_info['id']] = playlist_info

    def __synchronize_assets(self, asset_uuids = []):
        """
        Synchronize the assets
        """

        def traverse(asset_uuid = None):
            if asset_uuid:
                path = os.path.join(self.storage_configuration['asset_folder'], asset_uuid)
            else:
                path = self.storage_configuration['asset_folder']
            for root, dirs, files in os.walk(path):
                if root == self.storage_configuration['asset_folder']:
                    continue
                asset_uuid = os.path.split(root)[-1]
                file_info = {'uuid': asset_uuid}
                for file_name in files[:]:
                    if file_name.lower() == 'info.json':
                        try:
                            with open(os.path.join(root, file_name), 'rb') as f:
                                json_info = f.read()
                            file_info.update(json.loads(json_info))
                        except ValueError as e:
                            logging.error('INFO.json for asset {0} is not valid JSON. {1}'.format(root, str(e)))
                        except Exception:
                            logging.error('Unable to get contents of INFO.json for %s' % root, exc_info=True)

                        files.remove(file_name)
                        break
                else:
                    logging.error('INFO.json was missing for %s' % root)

                if len(files) != 1:
                    logging.error('Should be only one non-info file in each lms library subfolder, %s has %d' % (root, len(files)))
                    continue
                file_name = files[0]
                file_info['actual_size'] = os.path.getsize(os.path.join(root, file_name))
                file_info['file_name'] = file_name
                self.sync_status['content_scan_done'] += float(file_info['actual_size'])
                found_assets[asset_uuid] = file_info

        found_assets = {}
        if len(asset_uuids):
            for asset_uuid in asset_uuids:
                traverse(asset_uuid)

        else:
            traverse()
        asset_updates = {}
        for key in found_assets.keys():
            info = found_assets[key]
            status = 100
            hash_validated = None
            if info.has_key('generated_hash') and info.has_key('hash'):
                if info['generated_hash'] != info['hash']:
                    hash_validated = False
                    status = -1
                else:
                    hash_validated = True
            if not info.has_key('size'):
                info['size'] = info['actual_size']
            elif info['actual_size'] != info['size']:
                status = -1
            asset_updates[key] = {'uuid': info['uuid'],
             'type': info.get('mimetype', None),
             'hash': info.get('hash', None),
             'size': info['size'],
             'actual_size': info['actual_size'],
             'status': status,
             'parent_folder': info.get('parent_folder', None),
             'hash_validated': hash_validated,
             'file_name': info['file_name'],
             'cpls': []}

        with self.content_store_lock:
            self.content_store['assets'].update(asset_updates)
        return

    def __synchronize_cpls(self, cpl_uuids = []):
        """
        Synchronize the CPLs
        """

        def traverse(cpl_uuid = None):
            if cpl_uuid:
                path = os.path.join(u'' + self.storage_configuration['cpl_folder'], cpl_uuid)
            else:
                path = u'' + self.storage_configuration['cpl_folder']
            for root, dirs, files in os.walk(path):
                if root == self.storage_configuration['cpl_folder']:
                    continue
                cpl_uuid = os.path.split(root)[-1]
                file_info = {'uuid': cpl_uuid}
                for file_name in files[:]:
                    if file_name.lower() == 'info.json':
                        try:
                            with open(os.path.join(root, file_name), 'rb') as f:
                                json_info = f.read()
                            file_info.update(json.loads(json_info))
                        except Exception:
                            logging.error('Unable to get contents of INFO.json for %s' % root, exc_info=True)

                        files.remove(file_name)
                    if file_name.lower() == 'metadata.json':
                        files.remove(file_name)

                if len(files) != 1:
                    logging.error('Should be only one non-info file in each lms library subfolder, %s has %d' % (root, len(files)))
                    for file_name in files[:]:
                        logging.info(file_name)

                    continue
                file_name = files[0]
                file_info['actual_size'] = os.path.getsize(os.path.join(root, file_name))
                file_info['file_name'] = file_name
                self.sync_status['content_scan_done'] += float(file_info['actual_size'])
                found_cpls[cpl_uuid] = file_info

        self.corrupt_content['cpls'] = []
        found_cpls = {}
        if len(cpl_uuids):
            for cpl_uuid in cpl_uuids:
                traverse(cpl_uuid)

        else:
            traverse()
        cpl_updates = {}
        for key in found_cpls.keys():
            info = found_cpls[key]
            status = 100
            if not (info.has_key('size') and info['size']):
                size = info['actual_size']
                if info['actual_size'] != size:
                    status = -1
                if info.has_key('generated_hash') and info.has_key('hash') and info['generated_hash'] != info['hash']:
                    status = -1
                if not info.has_key('hash') and info.get('generated_hash', None):
                    logging.warn('CPL missing hash value, defaulting to generated hash: ' + key)
                    info['hash'] = info['generated_hash']
                    status = -1
                full_path = os.path.join(self.storage_configuration['cpl_folder'], key, info['file_name'])
                with open(full_path, 'r') as cpl_file:
                    cpl_xml = cpl_file.read()
                temp_cpl = None
                try:
                    temp_cpl = parse_cpl(cpl_xml, load_from_file=False)
                except Exception as ex:
                    logging.error('Error parsing cpl. path=%s' % str(full_path), exc_info=True)
                    status = -1
                    self.corrupt_content['cpls'].append(full_path)
                    continue

                internal_cpl = {'uuid': key,
                 'content_title_text': temp_cpl['text'] if temp_cpl else 'Unknown',
                 'total_actual_size': info['actual_size'],
                 'total_size': size,
                 'hash': info.has_key('hash') and info['hash'] or None,
                 'size': size,
                 'create_date': info.has_key('create_date') and info['create_date'] or None,
                 'ingest_source_type': info.has_key('ingest_source_type') and info['ingest_source_type'] or None,
                 'status': status,
                 'type': 'text/xml;asdcpKind=CPL',
                 'file_name': info['file_name'],
                 'assets': temp_cpl['assets'] if temp_cpl else []}
                if found_cpls[temp_cpl['id']].has_key('missing_font_id'):
                    temp_cpl['assets'].append(found_cpls[temp_cpl['id']]['missing_font_id'])
                asset_updates = {}
                for asset_uuid in temp_cpl['assets']:
                    if asset_uuid in self.content_store['assets']:
                        asset = self.content_store['assets'][asset_uuid]
                        asset_updates[asset_uuid] = self.content_store['assets'][asset_uuid]
                        asset_updates[asset_uuid]['cpls'].append(info['uuid'])
                        internal_cpl['total_actual_size'] += self.content_store['assets'][asset_uuid]['actual_size']
                        internal_cpl['total_size'] += self.content_store['assets'][asset_uuid]['size']
                        if temp_cpl['subtitled'] and asset['parent_folder']:
                            logging.debug('Finding missing assets for CPL %s' % temp_cpl['id'])
                            for other_asset_uuid, other_asset in self.content_store['assets'].items():
                                if other_asset['parent_folder'] == asset['parent_folder'] and other_asset is not asset:
                                    if other_asset_uuid not in temp_cpl['assets']:
                                        temp_cpl['assets'].append(other_asset_uuid)

                    else:
                        asset_updates[asset_uuid] = {'uuid': asset_uuid,
                         'type': None,
                         'hash': None,
                         'size': 0,
                         'status': None,
                         'parent_folder': None,
                         'hash_validated': None,
                         'actual_size': 0,
                         'file_name': None,
                         'cpls': [info['uuid']]}

                with self.content_store_lock:
                    self.content_store['assets'].update(asset_updates)
                cpl_updates[key] = internal_cpl
                cpl = {'uuid': key,
                 'content_title_text': temp_cpl['text'] if temp_cpl else 'Unknown',
                 'content_kind': temp_cpl['type'] if temp_cpl else 'Unknown',
                 'edit_rate': temp_cpl['edit_rate'] if temp_cpl else None,
                 'subtitled': temp_cpl['subtitled'] if temp_cpl else None,
                 'subtitle_language': temp_cpl['subtitle_language'] if temp_cpl else None,
                 'playback_mode': temp_cpl['playback_mode'] if temp_cpl else None,
                 'aspect_ratio': temp_cpl['aspect_ratio'] if temp_cpl else None,
                 'duration_in_seconds': temp_cpl['duration_in_seconds'] if temp_cpl else None,
                 'duration_in_frames': temp_cpl['duration_in_frames'] if temp_cpl else None,
                 'encrypted': temp_cpl['encrypted'] if temp_cpl else None,
                 'parsed_info': temp_cpl['parsed_info'] if temp_cpl else parse_content_title_text(''),
                 'xml': cpl_xml}
                cpl['video_encoding'] = cfg.core_detect_content_video_encoding() and self.get_content_video_encoding(key)['video_encoding']
            else:
                cpl['video_encoding'] = 'UNKNOWN'
            self._add_content(key, cpl)

        with self.content_store_lock:
            self.content_store['cpls'].update(cpl_updates)
        return

    def __synchronize_kdms(self):
        """
        Synchronize the KDMs
        """
        found_kdms = {}
        for root, dirs, files in os.walk(self.storage_configuration['kdm_folder']):
            if root == self.storage_configuration['kdm_folder']:
                continue
            if len(files) != 1:
                logging.debug('Should be at most one file in each lms library KDM subfolder, %s has %d' % (root, len(files)))
                continue
            file_info = {'storage_folder': root.decode('raw_unicode_escape')}
            file_info['file_name'] = files[0].decode('raw_unicode_escape')
            uuid = os.path.split(root)[-1]
            file_info['uuid'] = uuid
            found_kdms[uuid] = file_info

        for key in found_kdms:
            status = 'ok'
            info = found_kdms[key]
            full_path = os.path.join(self.storage_configuration['kdm_folder'], key, info['file_name'])
            parsed_kdm = parse_kdm(full_path)
            self.sync_status['content_scan_done'] += float(os.path.getsize(full_path))
            if len(parsed_kdm.keys()) == 0:
                parsed_kdm = None
                logging.error('There was a problem parsing %s, does not appear to be a KDM.' % full_path)
                status = 'error'
            kdm = {'uuid': info['uuid'],
             'file_name': info['file_name'],
             'full_path': full_path,
             'start_date': parsed_kdm['start_date'] if parsed_kdm else None,
             'end_date': parsed_kdm['end_date'] if parsed_kdm else None,
             'cpl_uuid': parsed_kdm['cpl_id'] if parsed_kdm else None,
             'dn_qualifier': parsed_kdm['dn_qualifier'] if parsed_kdm else None,
             'device_serial_number': parsed_kdm['device_serial_number'] if parsed_kdm else None,
             'cpl_content_title_text': parsed_kdm['cpl_text'] if parsed_kdm else None,
             'status': status}
            with self.content_store_lock:
                self.content_store['kdms'][key] = kdm

        return

    def get_content_uuid_list(self):
        """
        gets content uuid list of a device
        
        @return
            {
                content_uuid_list       -LIST of UUIDs
                error_messages          -LIST of errors
            }
        
        """
        return {'content_uuid_list': self.content_store['cpls'].keys(),
         'error_messages': []}

    def get_content_information(self, content_uuids):
        """
        gets content information of a device
        
        @type content_uuids:LIST
        @param   content_uuids:list of cpl uuids we want information for
        @rtype DICT
        @return {
                    content_info_dict:        DICT
                        {
                            content_uuid: {
                                content_title_text  STRING
                                content_kind        INT
                                edit_rate           [INT, INT]
                                subtitled           BOOL
                                subtitle_language   STRING
                                aspect_ratio        STRING
                                duration_in_seconds INT
                                duration_in_frames  INT
                                encrypted           BOOL
                                playback_mode       String
                                xml                 STRING xml file
                                parsed_info         DICT
                            }
                    error_messages          -LIST of errors
                }
        """
        output = {'content_info_dict': {},
         'error_messages': []}
        for uuid in content_uuids:
            content_info = self.content_store['cpls'][uuid]
            full_path = os.path.join(self.storage_configuration['cpl_folder'], uuid, content_info['file_name'])
            with open(full_path, 'r') as cpl_file:
                cpl_xml = cpl_file.read()
            temp_cpl = None
            try:
                temp_cpl = parse_cpl(cpl_xml, load_from_file=False)
                cpl_info = {'uuid': uuid,
                 'content_title_text': temp_cpl['text'] if temp_cpl else 'Unknown',
                 'content_kind': temp_cpl['type'] if temp_cpl else 'Unknown',
                 'edit_rate': temp_cpl['edit_rate'] if temp_cpl else None,
                 'subtitled': temp_cpl['subtitled'] if temp_cpl else None,
                 'subtitle_language': temp_cpl['subtitle_language'] if temp_cpl else None,
                 'playback_mode': temp_cpl['playback_mode'] if temp_cpl else None,
                 'aspect_ratio': temp_cpl['aspect_ratio'] if temp_cpl else None,
                 'duration_in_seconds': temp_cpl['duration_in_seconds'] if temp_cpl else None,
                 'duration_in_frames': temp_cpl['duration_in_frames'] if temp_cpl else None,
                 'encrypted': temp_cpl['encrypted'] if temp_cpl else None,
                 'parsed_info': temp_cpl['parsed_info'] if temp_cpl else parse_content_title_text(''),
                 'source': 'unknown',
                 'xml': cpl_xml}
                if cfg.core_detect_content_video_encoding():
                    cpl_info['video_encoding'] = self.get_content_video_encoding(uuid)['video_encoding']
                else:
                    cpl_info['video_encoding'] = 'UNKNOWN'
            except Exception as ex:
                logging.error('Error parsing cpl to get information. path=%s' % str(full_path), exc_info=True)
                cpl_info['content_title_text'] = uuid
                cpl_info['content_kind'] = 'unknown'
                cpl_info['edit_rate'] = [None, None]
                cpl_info['subtitled'] = None
                cpl_info['subtitle_language'] = None
                cpl_info['playback_mode'] = None
                cpl_info['aspect_ratio'] = None
                cpl_info['duration_in_seconds'] = 0
                cpl_info['duration_in_frames'] = 0
                cpl_info['encrypted'] = None
                cpl_info['xml'] = None
                cpl_info['parsed_info'] = parse_content_title_text('')
                cpl_info['video_encoding'] = 'UNKNOWN'
                cpl_info['error_message'] = str(ex)
                output['error_messages'].append(ex)

            output['content_info_dict'][uuid] = cpl_info

        return output

    def get_content_validation_information(self, content_uuids):
        """
        This receives information for given cpls in the system
        
        @param      content_uuids   - list of cpl uuids we want information for
        @return     {
                        content_validation_dict:
                            {
                                cpl_uuid:
                                {
                                    validation_code - Integer
                                        0 No error nor warning
                                        1 CPL is partially registered on this server
                                        2 CPL is registered on this server but cannot be loaded
                                        3 CPL is ingesting
                                        4 CPL is queued for ingest
                                    cpl_size - STRING cpl size in bytes
                                    cpl_actual_size - STRING actual cpl size in bytes
                                    ingest_path   STRING relative path to cpl.xml from ftp logon
                                    ingest_date   STRING YYYY-mm-dd cpl was created on filesystem
                                }
                            }
                        error_messages - LIST of errors
                    }
        """
        output = {'content_validation_dict': {},
         'error_messages': []}
        for uuid in content_uuids:
            cpl_info = {}
            if uuid in self.content_store['cpls']:
                cpl = self.content_store['cpls'][uuid]
                cpl_info['cpl_size'] = cpl['total_size']
                cpl_info['cpl_actual_size'] = cpl['total_actual_size']
                cpl_info['ingest_date'] = datetime.datetime.fromtimestamp(cpl['create_date']).strftime('%Y-%m-%d') if cpl['create_date'] != None else None
                cpl_info['ingest_source_type'] = cpl['ingest_source_type']
                if cfg.lms_custom_ftp_enabled():
                    cpl_info['ingest_path'] = posixpath.join(uuid, cpl['file_name'])
                    cpl_info['ingest_path'] = posixpath.join(self.device_id, cpl_info['ingest_path'])
                    if not cpl_info['ingest_path'].startswith('/'):
                        cpl_info['ingest_path'] = '/' + cpl_info['ingest_path']
                else:
                    cpl_info['ingest_path'] = posixpath.join(uuid, cpl['file_name'])
                cpl_info['validation_code'] = 0
                if self.is_ingesting(uuid):
                    cpl_info['validation_code'] = 3
                elif cpl['status'] == -1:
                    cpl_info['validation_code'] = 2
                else:
                    for asset_uuid in cpl['assets']:
                        asset = self.content_store['assets'][asset_uuid]
                        if asset['status'] == None:
                            cpl_info['validation_code'] = 1
                            break
                        elif asset['status'] == -1:
                            cpl_info['validation_code'] = 2
                            break

                output['content_validation_dict'][uuid] = cpl_info
            else:
                output['error_messages'].append(_('CPL %s does not exist on the LMS') % uuid)

        return output

    def get_ingest_path(self, content_uuid):
        return os.path.join(cfg.lms_library_directory(), 'INGEST', content_uuid, '{0}.xml'.format(content_uuid))

    def get_content_video_encoding(self, content_uuid):
        output = {'video_encoding': 'UNKNOWN',
         'error_messages': []}
        cpl = self.content_store['cpls'][content_uuid]
        picture_assets = []
        for asset_uuid in cpl['assets']:
            asset = self.content_store['assets'][asset_uuid]
            if asset['type'] == 'application/x-smpte-mxf;asdcpKind=Picture' and asset['status'] == 100:
                picture_assets.append(asset)

        for asset in sorted(picture_assets, key=lambda x: x['actual_size']):
            asset_filepath = os.path.join(self.storage_configuration['asset_folder'], asset['uuid'], asset['file_name'])
            with open(asset_filepath, 'rb') as asset_file:
                output['video_encoding'] = mxf.essence_type(asset_file)
            break

        return output

    def scan_content(self, content_uuid):
        """
        This scans the actual folder content and returns detailed information for given cpl in the system
        
        @param      content_uuid   - the content uuid to be scanned
        
        @return     {
        
                        file_name:
                            {
                            status : Error or Valid
                            message: Relative informative message that will make sense to everyone
                            }
                        }
                    }
        """
        cpl_info = self.content_store['cpls'][content_uuid]
        path = os.path.join(self.storage_configuration['ingest_folder'], content_uuid, cpl_info['file_name'])
        analyzed_cpl = _analyze_cpl(FileHandler(), path)
        cpl_filename = cpl_info.get('file_name')
        if cpl_filename and cpl_info['status'] != 100:
            analyzed_cpl_asset = analyzed_cpl.get(cpl_filename)
            if analyzed_cpl_asset and analyzed_cpl_asset['status'] != 'error':
                analyzed_cpl_asset['status'] = 'error'
                analyzed_cpl_asset['message'] = _('CPL XML is corrupt')
        for asset_uuid in cpl_info['assets']:
            asset_info = self.content_store['assets'][asset_uuid]
            asset_filename = asset_info.get('file_name')
            if asset_filename and asset_info['status'] != 100:
                analyzed_asset = analyzed_cpl.get(asset_filename)
                if analyzed_asset and analyzed_asset['status'] != 'error':
                    analyzed_asset['status'] = 'error'
                    analyzed_asset['message'] = _('Asset is corrupt')

        return analyzed_cpl

    def get_cpls_assets(self):
        output = {}
        for content_info, details in self.content_store.items():
            if content_info == 'cpls':
                output['cpls'] = details
            elif content_info == 'assets':
                output['assets'] = details

        return output

    def get_key_uuid_list(self):
        """
        This recieves the uuids of all the playlists in the system
        
        @param      None
        @return     [key_uuid]      - list of key uuids
        """
        return {'key_uuid_list': self.content_store['kdms'].keys(),
         'error_messages': []}

    def get_key_information(self, key_uuids):
        """
        gets key information of a device
        
        @return
            dict
                key_info_dict        DICT
                    <key_uuid>
                        cpl_title
                        cpl_uuid            STRING (UUID)
                        not_valid_before    FLOAT datetime in posix timestamp format
                        not_valid_after     FLOAT datetime in posix timestamp format
                        dnqualifier         STRING
                        full_path           STRING (lms only)
                error_messages          -LIST of errors
        """
        output = {'error_messages': [],
         'key_info_dict': {}}
        for uuid in key_uuids:
            if uuid in self.content_store['kdms']:
                kdm = self.content_store['kdms'][uuid]
                tmp = {}
                tmp['cpl_uuid'] = kdm['cpl_uuid']
                tmp['not_valid_before'] = kdm['start_date']
                tmp['not_valid_after'] = kdm['end_date']
                tmp['cpl_title'] = kdm['cpl_content_title_text']
                tmp['dnqualifier'] = kdm['dn_qualifier']
                tmp['device_serial_number'] = kdm['device_serial_number']
                tmp['status'] = kdm['status']
                tmp['full_path'] = kdm['full_path']
                output['key_info_dict'][uuid] = tmp
            else:
                output['error_messages'].append(_('Error getting KDM information for ID %s') % uuid)

        return output

    def get_key(self, key_uuid):
        """
        gets key xml
        
        @return
            dict
                xml        DICT
                    xml    STRING
                error_messages          -LIST of errors
        """
        output = {'error_messages': [],
         'xml': {}}
        try:
            output['xml'] = self.get_key_xml(key_uuid)
        except Exception as ex:
            logging.info('Error getting KDM information %s' % key_uuid, exc_info=True)
            output['error_messages'].append(_('Error getting KDM: %s') % str(ex))

        return output

    def get_key_xml(self, key_uuid):
        key = self.content_store['kdms'][key_uuid]
        with open(key['full_path'], 'r') as key_file:
            key_xml = key_file.read()
        return key_xml

    def get_transfer_ids(self):
        """
        This returns all the transfer ids in the syste,
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                            ]
        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'error_messages': [],
         'transfers': []}
        output['transfers'] = self.current_ingests.keys()
        return output

    def get_transfer_info(self, transfer_ids):
        """
        This returns all information for specified transfers
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                                state          STRING      - 'initializing', 'queued on server', 'active', 'paused', 'cancelled', 'success', 'failure'
                                description    STRING      - description of the transfer, ie content title
                                type           STRING      - cpl, kdm...
                                cpl_uuid       STRING      - transferring cpl
                                source         STRING      - source this can be an ipaddress or a description (ie local disk)
                                progress       INTEGER     - % transfer complete
                                message        STRING      - a message elaborating on the transfer_state ('ingest was paused at 15:00')
                            ]
        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'error_messages': [],
         'transfers': []}
        for uuid, info in self.current_ingests.items():
            if uuid in transfer_ids:
                status = {}
                message = ''
                message_code = None
                if info['state'] == 'active':
                    for asset in info['assets']:
                        if info['assets'][asset]['percent'] > 0 and info['assets'][asset]['percent'] < 100:
                            message = info['assets'][asset]['info']
                            break

                elif info['state'] == 'failed':
                    failed_files = []
                    for asset in info['assets']:
                        if info['assets'][asset]['percent'] == -1:
                            failed_files.append('%s - %s' % (info['assets'][asset]['file_name'], info['assets'][asset]['info']))

                    message = 'Errors: ' + ', '.join(failed_files)
                elif info['state'] == 'success':
                    message = _('Transfer successful')
                    message_code = 10
                status['server_transfer_id'] = uuid
                status['state'] = info['state']
                status['description'] = info['description']
                status['type'] = 'DCP'
                status['source'] = info['source']
                status['content_id'] = info['cpl_uuid']
                status['progress'] = info['percent']
                status['message'] = message
                status['message_code'] = message_code
                status['start_time'] = info['start_time']
                status['end_time'] = info['end_time']
                output['transfers'].append(status)

        return output

    def content_add_key(self, key):
        """
        Adds a list of keys to a device.
        TODO: could make device optional, if left out try to find the right device.
        
        @param keys            LIST    - containing keys
        """
        success = True
        message = ''
        try:
            kdm = parse_kdm(key, load_from_file=False)
        except Exception as ex:
            logging.error('Error parsing KDM xml', exc_info=True)
            success = False
            message = _('Error analysing KDM XML: %s') % str(ex)
            return (success, message)

        if datetime.datetime.fromtimestamp(kdm['end_date']) >= datetime.datetime.now():
            try:
                file_name = kdm['id'] + '.xml'
                storage_folder = os.path.join(self.storage_configuration['kdm_folder'], kdm['id'])
                full_path = os.path.join(storage_folder, file_name)
                if kdm['id'] not in self.get_key_uuid_list()['key_uuid_list']:
                    if not os.path.exists(full_path) and not os.path.isdir(storage_folder):
                        os.mkdir(storage_folder)
                    with open(full_path, 'wb') as f:
                        f.write(key.encode('utf-8'))
                    store_kdm = {'uuid': kdm['id'],
                     'file_name': file_name,
                     'full_path': full_path,
                     'start_date': kdm['start_date'],
                     'end_date': kdm['end_date'],
                     'cpl_uuid': kdm['cpl_id'],
                     'dn_qualifier': kdm['dn_qualifier'],
                     'device_serial_number': kdm['device_serial_number'],
                     'cpl_content_title_text': kdm['cpl_text'],
                     'status': 'ok'}
                    with self.content_store_lock:
                        self.content_store['kdms'][kdm['id']] = store_kdm
                message = _('KDM saved on %s for CPL %s') % ('LMS', kdm['cpl_text'])
            except Exception as ex:
                logging.error('Error saving KDM %s to the LMS' % kdm['id'], exc_info=True)
                success = False
                message = _('Error saving KDM for CPL %s: %s') % (kdm['cpl_text'], str(ex))

        else:
            success = False
            message = _('Error saving KDM on LMS for CPL %s: The KDM has expired') % kdm['id']
        return (success, message)

    def content_cancel_transfer(self, transfer_id):
        """
        Cancels a transfer on a device.
        
        @param transfer_id  STRING  - transfer identifier
        """
        success = True
        message = ''
        found = False
        for thread in threading.enumerate():
            if hasattr(thread, 'ingest_uuid') and transfer_id == thread.ingest_uuid:
                message = _('Cancelling transfer')
                thread.stop = True
                found = True
                break

        if self.current_ingests.has_key(transfer_id):
            self.cancel_ingest(transfer_id, self.current_ingests[transfer_id]['cpl_uuid'])
        else:
            success = False
            message = _('Could not find specified transfer: %s') % transfer_id
        return (success, message)

    def content_delete(self, content_id):
        """
        Deletes the specified content from the device; if the device is not specified, then the content is deleted from all devices.
        @param content_id            content identifiers
        """
        if not self.content_store['cpls'].has_key(content_id):
            return (False, _('CPL %s does not exist on the LMS') % content_id)
        if self.is_ingesting(content_id):
            return (False, _('CPL %s cannot be deleted because it is being ingested') % content_id)
        cpl = self.content_store['cpls'][content_id]
        cpl_title = cpl['content_title_text']
        delete_me = []
        delete_me.append(os.path.join(self.storage_configuration['ingest_folder'], content_id))
        for asset in cpl['assets']:
            if len(self.content_store['assets'][asset]['cpls']) == 1:
                delete_me.append(os.path.join(self.storage_configuration['asset_folder'], asset))
                with self.content_store_lock:
                    del self.content_store['assets'][asset]
            else:
                with self.content_store_lock:
                    self.content_store['assets'][asset]['cpls'].remove(content_id)

        delete_me.append(os.path.join(self.storage_configuration['cpl_folder'], content_id))
        with self.content_store_lock:
            del self.content_store['cpls'][content_id]
        for directory in delete_me:
            if os.path.exists(directory):
                shutil.rmtree(directory)

        logging.info('Content %s - %s deleted' % (cpl_title, content_id))
        return (True, _('CPL %s deleted') % cpl_title)

    def content_delete_key(self, key_uuid):
        """
        Deletes a set of keys from a device.
        @param key_ids                  LIST   - list of key identifiers
        """
        success = True
        message = ''
        kdm_directory = os.path.join(self.storage_configuration['kdm_folder'], key_uuid)
        if os.path.exists(kdm_directory):
            shutil.rmtree(kdm_directory)
            message = _('KDM deleted: %s') % key_uuid
            logging.info(message)
        else:
            success, message = False, _('Cannot delete KDM because the directory was not found: %s') % kdm_directory
        with self.content_store_lock:
            if key_uuid in self.content_store['kdms']:
                del self.content_store['kdms'][key_uuid]
        return (success, message)

    def transfer_methods(self):
        return ['ftp', 'local']

    def ready_for_transfer(self, source):
        for active_transfer in self.transfer_information['active'].values():
            if active_transfer['source'] == source:
                return False

        return True

    def content_transfer(self, connection, description, cpl_uuid):
        """
        Ingests content onto the device.
        
        @param content_path                  STRING   - path to content to ingest.
        @param ftp_ip                        STRING   - for ftp ingests only - connection details
        @param ftp_port                      STRING   - for ftp ingests only - connection details
        @param ftp_user                      STRING   - for ftp ingests only - connection details
        @param ftp_pass                      STRING   - for ftp ingests only - connection details
        @param description                   STRING   - description of ingest
        @param cpl_uuid                      STRING   - content uuid
        
        
        if ftp info is null, assumes local copy.
        
        The CPL must exist in a DCP like folder.
        
        Synchronized with ingest_thread_exists
            ingest_thread_exists checks if an ingest thread exists for specific cpl/assets
            ingest_cpl makes db entries for cpls and issues a command for the copying to begin
                if inbetween these two stages, ingest_thread_exists is called, the cpl ingest will be temporarily be wrongly marked as failed.
        
        
        @return
            success - bool
            messages          -LIST of errors
            transfer_id - id of transfer if successful kick off
        """
        success = False
        message = None
        ftp_user = None
        ftp_pass = None
        ftp_ip = None
        ftp_port = None
        ingest_uuid = str(uuid4())
        ingest_info = {'state': 'active',
         'source': None,
         'percent': 0,
         'start_time': None,
         'cpl_uuid': cpl_uuid,
         'info': 'Unknown',
         'description': description,
         'end_time': time.time(),
         'assets': []}
        content_path = connection['ingest_path']
        content_path = content_path.replace('\\', '/')
        if connection['type'] == 'local':
            conn = FileHandler()
            logging.info('Starting local ingest for: path=%s' % content_path)
            ingest_info['source'] = content_path
        elif connection['type'] == 'ftp':
            try:
                ftp_user = connection['ftp_username']
                ftp_pass = connection['ftp_password']
                ftp_ip = connection['ftp_ip']
                ftp_port = connection['ftp_port']
                logging.info('Starting ingest for: path=%s ftp=%s port=%s username=%s password=%s source=%s' % (content_path,
                 ftp_ip,
                 str(ftp_port),
                 ftp_user,
                 ftp_pass,
                 description))
                conn = FTPHandler(ftp_ip, ftp_user, ftp_pass, ftp_port)
                ingest_info['source'] = ftp_ip
            except Exception as ex:
                logging.error('Error in connecting to FTP server: %s @ %s' % (ftp_ip, ftp_user), exc_info=True)
                message = _('Error connecting to FTP server: %s @ %s:%s - %s') % (ftp_user,
                 ftp_ip,
                 ftp_port,
                 str(ex))
                return (success, message, ingest_uuid)

        else:
            raise NotImplementedError()
        if not conn.exists(content_path):
            if conn.exists(content_path):
                content_path = content_path
            else:
                logging.error('Error in ingesting content, file not found: %s' % content_path)
                message = _('CPL was not found at the expected path: %s') % content_path
                return (success, message, ingest_uuid)
        folder = content_path
        depth = 5
        count = 0
        while folder and count < depth:
            folder = os.path.split(folder)[0]
            if _folder_is_package(folder, conn):
                break
            count = count + 1
        else:
            logging.error('No assetmap was found in location: %s' % content_path)
            message = _('ASSETMAP was not found in the DCP folder: %s') % content_path
            return (success, message, ingest_uuid)

        dcp = None
        try:
            dcp = DCP(folder, conn)
        except Exception as ex:
            logging.error('Ingest aborted - There was an error in validating the DCP at %s' % folder, exc_info=True)
            message = _('Error analysing the DCP: %s') % str(ex)
            return (success, message, ingest_uuid)

        cpls = [ cpl for cpl in dcp.cpls if cpl.uuid == cpl_uuid ]
        if len(cpls) != 1:
            logging.error('%s CPL(s) found in DCP for CPL path: %s' % (str(len(cpls)), content_path))
            message = _('%s CPLs found in DCP: %s') % (str(len(cpls)), content_path)
            return (success, message, ingest_uuid)
        else:
            cpl = cpls[0]
            ingest_info['assets'] = cpl.assets
            if self.is_ingesting(cpl.uuid):
                ingest_details = self.ingest_details(cpl.uuid)
                logging.error('CPL is currently being ingested: %s' % cpl.uuid)
                message = _('CPL %s is being ingested with status: %s') % (cpl.content_title_text, str(ingest_details.get('status', _('Unknown'))))
                return (success, message, ingest_uuid)
            if not cpl.is_ingestible:
                errors = []
                if cpl.errors:
                    errors.append(_('CPL %s cannot be ingested due to errors: %s') % (cpl.content_title_text, str(cpl.errors)))
                for asset_info in cpl.assets:
                    if asset_info['from_this_dcp'] and asset_info['uuid'] in dcp.assets:
                        asset = dcp.assets[asset_info['uuid']]
                        if asset.errors:
                            errors.append(_('An asset %s for the CPL has the following errors: %s') % (asset.full_path, str(asset.errors)))

                logging.error('CPL %s is not suitable for ingest: %s' % (cpl.full_path, message))
                message = ', '.join(errors)
                return (success, message, ingest_uuid)
            cpl_validation = self.get_content_validation_information([cpl.uuid])
            if cpl_validation['content_validation_dict'].has_key(cpl.uuid) and cpl_validation['content_validation_dict'][cpl.uuid]['validation_code'] == 0:
                ingest_info['state'] = 'success'
                ingest_info['percent'] = 100
                ingest_info['start_time'] = time.time()
                ingest_info['end_time'] = time.time()
                ingest_info['info'] = 'CPL %s already exists on the LMS' % cpl.content_title_text
                ingest_info['description'] = cpl.content_title_text
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid] = ingest_info
                logging.info('%s CPL already exists on the LMS in completed form' % cpl.uuid)
                message = _('CPL %s already exists on the LMS') % cpl.content_title_text
                return (True, message, ingest_uuid)
            try:
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid] = ingest_info
                ingest_source_type = connection['ingest_source_type']
                params = self._add_cpl_to_store(dcp, cpl, content_path, ingest_uuid, ingest_source_type)
                if not ftp_ip:
                    cherrypy.engine.publish('local_copy', params)
                else:
                    cherrypy.engine.publish('ftp_copy', params, ftp_ip, ftp_port, ftp_user, ftp_pass)
            except Exception as ex:
                with self.current_ingests_lock:
                    del self.current_ingests[ingest_uuid]
                if connection['type'] == 'local':
                    message = _('There was an error starting the ingest of CPL %s : %s') % (cpl.content_title_text, str(ex))
                else:
                    message = _('There was an error starting the transfer of CPL %s : %s') % (cpl.content_title_text, str(ex))
                logging.error('There was an error while ingesting the CPL %s : %s' % (cpl.content_title_text, content_path), exc_info=True)
                return (success, message, None)

            if connection['type'] == 'local':
                message = _('Ingest started for CPL %s') % cpl.content_title_text
            else:
                message = _('Transfer started for CPL %s') % cpl.content_title_text
            success = True
            return (success, message, ingest_uuid)

    def _add_cpl_to_store(self, dcp, cpl, content_path, ingest_uuid, ingest_source_type):
        """
        add the cpl to the content store and also the ingest tracker - this is for ingest purposes. Returns the list of files for ingesting.
        """
        params = {}
        params['copy_ids'] = []
        files = {}
        missing_font_id = None
        for asset in cpl.assets:
            if asset['from_this_dcp']:
                actual_asset = dcp.assets[asset['uuid']]
                if not actual_asset.missing:
                    if not self.is_ingesting(asset['uuid']) and (not self.content_store['assets'].has_key(asset['uuid']) or self.content_store['assets'][asset['uuid']]['status'] != 100):
                        asset_filename = actual_asset.filename
                        if actual_asset.type in (AssetType.CPL, AssetType.SUBTITLE):
                            asset_filename = actual_asset.uuid + '.xml'
                        elif actual_asset.type in (AssetType.PICTURE, AssetType.SOUND):
                            asset_filename = actual_asset.uuid + '.mxf'
                        files[actual_asset.uuid] = {'dest': os.path.join(self.storage_configuration['asset_folder'], actual_asset.uuid, asset_filename),
                         'file_name': asset_filename,
                         'hash': actual_asset.hash,
                         'size': actual_asset.fs_size,
                         'mimetype': actual_asset.mime_type,
                         'parent_folder': actual_asset.parent_folder,
                         'source': actual_asset.full_path}
                elif actual_asset.missing and actual_asset.type == 'Font':
                    missing_font_id = actual_asset.uuid
                    missing_font_path = actual_asset.relative_path
                    missing_font_size = actual_asset.pkl_size
                    missing_font_hash = actual_asset.hash

        cpl_filename = cpl.uuid + '.xml'
        if not self.content_store['cpls'].has_key(cpl.uuid) or self.content_store['cpls'][cpl.uuid]['status'] != 100:
            files[cpl.uuid] = {'dest': os.path.join(self.storage_configuration['cpl_folder'], cpl.uuid, cpl_filename),
             'hash': cpl.hash,
             'size': cpl.size,
             'mimetype': cpl.mime_type,
             'source': content_path,
             'file_name': cpl_filename,
             'ingest_source_type': ingest_source_type}
            if missing_font_id:
                files[cpl.uuid]['missing_font_id'] = missing_font_id
                files[cpl.uuid]['missing_font_path'] = missing_font_path
                files[cpl.uuid]['missing_font_size'] = missing_font_size
                files[cpl.uuid]['missing_font_hash'] = missing_font_hash
        params['files'] = files
        params['ingest_uuid'] = ingest_uuid
        params['cpl_uuid'] = cpl.uuid
        with self.current_ingests_lock:
            self.current_ingests[ingest_uuid]['state'] = 'active'
            self.current_ingests[ingest_uuid]['start_time'] = time.time()
            self.current_ingests[ingest_uuid]['description'] = cpl.content_title_text
            self.current_ingests[ingest_uuid]['info'] = 'Ingest started'
            self.current_ingests[ingest_uuid]['assets'] = {}
            self.current_ingests[ingest_uuid]['assets'][cpl.uuid] = files[cpl.uuid] if cpl.uuid in files else {}
            self.current_ingests[ingest_uuid]['assets'][cpl.uuid]['type'] = 'cpl'
            self.current_ingests[ingest_uuid]['assets'][cpl.uuid]['percent'] = 0 if files.has_key(cpl.uuid) else 100
            self.current_ingests[ingest_uuid]['assets'][cpl.uuid]['state'] = 'active' if files.has_key(cpl.uuid) else 'success'
        if not self.content_store['cpls'].has_key(cpl.uuid):
            cpl_info = {'uuid': cpl.uuid,
             'content_title_text': cpl.content_title_text,
             'type': 'text/xml;asdcpKind=CPL',
             'total_actual_size': 0,
             'total_size': cpl.size,
             'actual_size': 0,
             'create_date': time.time(),
             'hash': cpl.hash,
             'size': cpl.size,
             'status': 0,
             'file_name': cpl_filename,
             'assets': [ asset['uuid'] for asset in cpl.assets ],
             'ingest_source_type': ingest_source_type}
            with self.content_store_lock:
                self.content_store['cpls'][cpl.uuid] = cpl_info
        for asset in cpl.assets:
            asset_uuid = asset['uuid']
            if asset_uuid not in self.content_store['assets']:
                asset_info = {'uuid': asset_uuid,
                 'type': None,
                 'hash': None,
                 'size': 0,
                 'actual_size': 0,
                 'status': None,
                 'parent_folder': None,
                 'hash_validated': None,
                 'file_name': None,
                 'cpls': [cpl.uuid]}
                with self.content_store_lock:
                    self.content_store['assets'][asset_uuid] = asset_info
            else:
                with self.content_store_lock:
                    self.content_store['assets'][asset_uuid]['cpls'].append(cpl.uuid)
            if asset_uuid in files:
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid]['assets'][asset_uuid] = files[asset_uuid]
                    self.current_ingests[ingest_uuid]['assets'][asset_uuid]['type'] = 'asset'
                    self.current_ingests[ingest_uuid]['assets'][asset_uuid]['percent'] = 0
                self.content_store['assets'][asset_uuid].update({'type': files[asset_uuid]['mimetype'],
                 'hash': files[asset_uuid].get('hash', None),
                 'size': files[asset_uuid]['size'],
                 'status': 0,
                 'parent_folder': files[asset_uuid].get('parent_folder', None),
                 'file_name': files[asset_uuid]['file_name']})
            if self.content_store['assets'][asset_uuid]['size']:
                with self.content_store_lock:
                    self.content_store['cpls'][cpl.uuid]['total_size'] += self.content_store['assets'][asset_uuid]['size']

        return params

    def get_device_status(self):
        output = {'error_messages': []}
        output['current_time'] = time.time()
        return output

    def test_management_connection(self):
        return (True, _('OK'))

    def content_clear_transfer_history(self):
        """
        Clears the transfer history on the device
        
        Returns a dictionary containing
                    response - the response code sent by the server
        """
        completed_transfers = self.get_completed_transfers()
        for transfer in completed_transfers.values():
            if transfer.has_key('server_transfer_id') and transfer['server_transfer_id'] != None and self.current_ingests.has_key(transfer['server_transfer_id']):
                with self.current_ingests_lock:
                    del self.current_ingests[transfer['server_transfer_id']]

        return (True, _('Transfer history cleared'))

    def get_device_version_information(self):
        output = {'error_messages': [],
         'software_version': '2.0'}
        return output

    def get_device_information(self):
        output = {'error_messages': [],
         'dnqualifiers': [],
         'certificates': []}
        output['software_version'] = '2.0'
        if os.name == 'nt':
            import win32file
            available, disk_size, total_free = win32file.GetDiskFreeSpaceEx(self.storage_configuration['library_folder'])
            output['storage_total'] = disk_size
            output['storage_available'] = available
            output['storage_used'] = disk_size - total_free
        else:
            fs_stats = os.statvfs(self.storage_configuration['library_folder'])
            output['storage_total'] = fs_stats.f_blocks * fs_stats.f_bsize
            output['storage_available'] = fs_stats.f_bavail * fs_stats.f_frsize
            output['storage_used'] = output['storage_total'] - output['storage_available']
        output['raid_status'] = [{'name': 'RAID',
          'message': _('RAID Information Unavailable'),
          'status': 'unknown'}]
        return output

    def get_playlist_uuid_list(self):
        """
        gets playlist uuid list of a device
        
        @return
            dict
                playlist_uuid_list      -LIST of UUIDs
                error_messages          -LIST of errors
        
        """
        return {'playlist_uuid_list': self.content_store['playlists'].keys(),
         'error_messages': []}

    def get_playlist_information(self, playlist_uuids):
        """
        gets playlist information of a device
        
        @param      playlist_uuids   - list of playlist uuids we want information for
        @return
            dict
                playlist_info_dict        DICT
                    <playlist_uuid>
                        title               STRING
                        duration            INT in seconds
                        is_3d               BOOL
                        is_hfr              BOOL
                        is_4k               BOOL
                        playlist            DICT
                            id                  STRING (playlist UUID)
                            title               STRING
                            text                STRING
                            is_3d               BOOL (3D playback mode for Doremi, for others normally means contains 3D CPL)
                            duration            FLOAT (total playlist duration in seconds)
                            events              DICT
                                id                  STRING (UUID of playlist event, may be generated by Core)
                                main_id             STRING (see Doremi, for others may be generated by Core)
                                cpl_id              STRING (UUID of CPL)
                                type                STRING ("composition" | "pattern")
                                text                STRING (content_title_text or similar for convenience)
                                duration_in_frames  INT (Dolby reports an estimated duration in secs so that value is rounded to the nearest frame)
                                raw_duration        FLOAT (actual duration in frames, may be fractional on a Dolby) *required for skip_to_position calculations
                                edit_rate           TUPLE[INT] e.g. (24, 1)
                                automation          DICT
                                    id                  STRING (ID of automation, might be UUID or name or action)
                                    name                STRING (human readable name)
                                    type                STRING ("cue" | "trigger" | "volume" | "gdc_start_cue" | "christie_trigger")
                                    type_specific       DICT
                                        action          STRING (used in all; cue action to fire)
                                        kind            STRING ("Start" | "End") (used in "cue"; means type of offset)
                                        value           INT (used in "cue", "volume" and "gdc_start_cue"; offset in frames or delay in frames for "gdc_start_cue")
                                        parameter       FLOAT (used in "volume"; parameter for parameterized cue)
                                        trigger         STRING (used in "trigger"; the input action required to trigger)
        
            error_messages                LIST[STRING] (error message strings)
        """
        output = {'error_messages': [],
         'playlist_info_dict': {}}
        for uuid in playlist_uuids:
            playlist = self.content_store['playlists'][uuid]
            output['playlist_info_dict'][uuid] = {'uuid': uuid,
             'title': playlist['title'],
             'duration_in_seconds': playlist['duration_in_seconds'],
             'is_template': playlist['is_template'],
             'is_3d': playlist.get('is_3d', False),
             'is_hfr': playlist.get('is_hfr', False),
             'is_4k': playlist.get('is_4k', False),
             'playlist': playlist}

        return output

    def playlist_delete(self, playlist_uuid):
        """
        Deletes the specified playlists from the devices; if the devices are not specified, then the playlists are deleted from all devices.
        @param playlist_uuid                STRING - playlist identifier to delete
        """
        if playlist_uuid in self.content_store['playlists']:
            playlist = self.content_store['playlists'][playlist_uuid]
            playlist_title = playlist['title']
            full_path = os.path.join(self.storage_configuration['playlist_folder'], playlist_uuid)
            with self.content_store_lock:
                del self.content_store['playlists'][playlist_uuid]
            if os.path.exists(full_path):
                shutil.rmtree(full_path)
            logging.info('Deleted playlist %s %s' % (playlist_title, playlist_uuid))
            return (True, _('Playlist %s deleted') % playlist_title)
        else:
            return (False, _('Playlist %s does not exist on the LMS') % playlist_uuid)

    def playlist_save(self, playlist):
        """
        Saves a playlist on a device.
            @param playlist          json DICT   - json dictinoary of a playlist
                       id            STRING - uuid
                       title         STRING
                       text          STRING
                       is_3d         BOOL
                       duration      INT in seconds
                       events            LIST of DICTS
                           id            STRING - uuid
                           type          STRING
                           cpl_id        STRING
                           duration      INT in frames
                           main_id       STRING - uuid
                           text          STRING
                           edit_rate     LIST/TUPLE
                               edit_rate_0   INT
                               edit_rate_1   INT
                           cues          LIST of DICTS
                               id            STRING - uuid
                               action        STRING
                               offset        DICT
                                   value         STRING
                                   kind          STRING
                       triggers      LIST of DICTS
                           id        STRIN - uuid
                           name      STRING
                           action    STRING
        
        """
        playlist['last_modified'] = time.time()
        full_path = os.path.join(self.storage_configuration['playlist_folder'], playlist['id'], playlist['id'] + '.json')
        create_dir(full_path)
        with open(full_path, 'w') as playlist_file:
            playlist_file.write(json.dumps(playlist))
        playlist['is_template'] = self.__is_playlist_template(playlist)
        with self.content_store_lock:
            self.content_store['playlists'][playlist['id']] = playlist
        return (True, _('Saved: %s') % playlist['title'])
# okay decompyling ./core/devices/content/aamLMS/aamLMS.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:49 CST
