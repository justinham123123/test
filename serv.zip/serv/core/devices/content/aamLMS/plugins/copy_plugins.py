# 2017.08.13 21:48:49 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\content\aamLMS\plugins\copy_plugins.py
import traceback
import threading
import json
import os
import cherrypy
import stat
import hashlib
import base64
import ctypes
import time
import pickle
from cherrypy.process.plugins import SimplePlugin
from serv.lib.dcinema.dcp.file_handlers import FTPHandler
import logging as content_copy_log
MIN_BUFFER_SIZE = 524288
MAX_BUFFER_SIZE = 10485760

class IngestCancelledException(Exception):
    pass


class LocalCopyPlugin(SimplePlugin):
    """
    Copies a file from A to B
    """

    def __init__(self, bus):
        bus.subscribe('local_copy', self.local_copy)
        SimplePlugin.__init__(self, bus)
        self.copy_threads = []

    def stop(self):
        """
        Stops all copy threads
        """
        for thread in self.copy_threads:
            if thread is not None:
                ctypes.pythonapi.PyThreadState_SetAsyncExc.argtypes = [ctypes.c_long, ctypes.py_object]
                if ctypes.pythonapi.PyThreadState_SetAsyncExc(thread.ident, ctypes.py_object(SystemExit)) != 1:
                    cherrypy.log('Unable to send an exit signal to the thread')
                thread.join()
                self.bus.log('Stopped thread %r.' % thread.name)

        self.copy_threads = []
        return

    def local_copy(self, params):
        """
        Kicks of file copying in a new thread
        Expects a dictionary of
            params
                cpl: cpl_uuid
                files: {file : destination}
        
        """
        thread = threading.Thread(target=self.__local_copy, kwargs={'files': params['files'],
         'ingest_uuid': params['ingest_uuid'],
         'cpl_uuid': params['cpl_uuid'],
         'check_hash': params.get('check_hash', True),
         'drive_copy': params.get('drive_copy', False)})
        thread.cpl_uuid = params['cpl_uuid']
        thread.ingest_uuid = params['ingest_uuid']
        thread.check_hash = params.get('check_hash', True)
        self.copy_threads.append(thread)
        thread.start()

    def __local_copy(self, files, cpl_uuid, ingest_uuid, check_hash, drive_copy):
        """
        Copies a list of files to a specified destination
        Expects a dictionary of file : {'dest': new file / folder, 'hash': hash if used}
        
        # 10Mb buffer - the larger the buffer, the quicker it is, but takes more memory
        """
        src = None
        dst = None
        current_uuid = None
        try:
            for key in files.keys():
                current_uuid = key
                info = files[current_uuid]
                dest = info['dest']
                hash = info['hash']
                self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, 0, info='Starting transfer for file: %s' % info['file_name'])
                if not drive_copy:
                    dest_folder = os.path.split(dest)[0]
                    if os.path.isdir(dest_folder):
                        for existing_file in os.listdir(dest_folder):
                            if existing_file != 'INFO.json':
                                content_copy_log.info('The file [%s] already exists in the destination folder, going to delete ' % existing_file)
                            if existing_file != 'metadata.json':
                                os.remove(os.path.join(dest_folder, existing_file))

                create_dir(dest)
                if not drive_copy:
                    write_info_file(dest, info, cpl_uuid)
                filesize = os.path.getsize(info['source'])
                try:
                    buffer_size = int(filesize) / 100
                except ValueError:
                    buffer_size = MIN_BUFFER_SIZE

                if buffer_size < MIN_BUFFER_SIZE:
                    buffer_size = MIN_BUFFER_SIZE
                if buffer_size > MAX_BUFFER_SIZE:
                    buffer_size = MAX_BUFFER_SIZE
                src = open(info['source'], 'rb')
                dst = open(dest, 'wb')
                chunk = src.read(buffer_size)
                dst.write(chunk)
                bytes_recv = 0
                if check_hash:
                    hash_object = hashlib.sha1(chunk)
                prev_percentage = 0
                while src:
                    if hasattr(threading.current_thread(), 'stop'):
                        raise IngestCancelledException
                    chunk = src.read(buffer_size)
                    if not chunk:
                        break
                    bytes_recv += len(chunk)
                    dst.write(chunk)
                    progress = int(float(bytes_recv) / float(filesize) * 100)
                    if progress != prev_percentage:
                        prev_percentage = progress
                        if progress < 100:
                            self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, progress, info='Transfering file: %s' % info['file_name'])
                    if check_hash:
                        hash_object.update(chunk)

                src.close()
                dst.close()
                if check_hash:
                    generated_hash = base64.encodestring(hash_object.digest()).strip()
                    info['generated_hash'] = generated_hash
                    if not drive_copy:
                        write_info_file(dest, info, cpl_uuid)
                if hash and check_hash:
                    if generated_hash == hash:
                        self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, 100, hash_validated=True, info='Finished transfering file: %s' % info['file_name'])
                    else:
                        content_copy_log.error('Error in file copy, Hash does not match. Expected [%s] generated: [%s] for file : %s' % (hash, generated_hash, info['source']))
                        self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, -1, info='Error in file copy, Hash does not match. Expected [%s] generated: [%s] for file : %s' % (hash, generated_hash, info['source']))
                else:
                    self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, 100, info='Finished transfering file: %s' % info['file_name'])

        except IOError as ex:
            content_copy_log.error('error in copying the file!: [%s] [%s] [%s]' % (str(IOError), str(ex), traceback.format_exc()))
            self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, -1, info='Error in copying the file: [%s] [%s]' % (str(IOError), str(ex)))
        except IngestCancelledException:
            content_copy_log.info('Ingest has been cancelled! Removing [%s]' % str(ingest_uuid))
            self.bus.publish('file_copy_cancel', ingest_uuid, cpl_uuid)
        except Exception as ex:
            content_copy_log.error('Problem in copy thread [%s] [%s]' % (ex, traceback.format_exc()))
            self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, -1, info='Error in copying the file: [%s]' % str(ex))
        finally:
            try:
                self.copy_threads.remove(threading.current_thread())
                if src:
                    src.close()
                if dst:
                    dst.close()
                self.bus.publish('file_copy_finish', ingest_uuid)
            except Exception as ex:
                content_copy_log.error('Problem in copy thread [%s] [%s]' % (ex, traceback.format_exc()))

        return


class FTPCopyPlugin(SimplePlugin):
    """
    Copies a file from A to B over FTP
    """

    def __init__(self, bus):
        bus.subscribe('ftp_copy', self.ftp_copy)
        SimplePlugin.__init__(self, bus)
        self.copy_threads = []

    def stop(self):
        """
        Stops all copy threads
        """
        for thread in self.copy_threads:
            if thread is not None:
                ctypes.pythonapi.PyThreadState_SetAsyncExc.argtypes = [ctypes.c_long, ctypes.py_object]
                if ctypes.pythonapi.PyThreadState_SetAsyncExc(thread.ident, ctypes.py_object(SystemExit)) != 1:
                    cherrypy.log('Unable to send an exit signal to the thread')
                thread.join()
                self.bus.log('Stopped thread %r.' % thread.name)

        self.copy_threads = []
        return

    def graceful(self):
        self.stop()
        self.start()

    def ftp_copy(self, params, ftp_ip, ftp_port, username, password):
        """
        Kicks of file copying in a new thread
        Expects a dictionary of
        file : destination
        """
        try:
            thread = threading.Thread(target=self.__ftp_copy, kwargs={'files': params['files'],
             'ingest_uuid': params['ingest_uuid'],
             'cpl_uuid': params['cpl_uuid'],
             'ftp_ip': ftp_ip,
             'ftp_port': ftp_port,
             'username': username,
             'password': password,
             'check_hash': params.get('check_hash', True),
             'drive_copy': params.get('drive_copy', False)})
            thread.cpl_uuid = params['cpl_uuid']
            thread.ingest_uuid = params['ingest_uuid']
            thread.check_hash = params.get('check_hash', True)
            self.copy_threads.append(thread)
            thread.start()
        except Exception as ex:
            content_copy_log.error('Problem in copy thread [%s] [%s]' % (ex, traceback.format_exc()))

    def __ftp_copy(self, files, ingest_uuid, cpl_uuid, ftp_ip, ftp_port, username, password, check_hash, drive_copy):
        """
        Copies a list of files to a specified destination
        Expects a dictionary of
            file : destination
        and
            connection : {ip_addr, port, username, password}
        """
        current_uuid = None
        dst = None
        ftp = None
        try:
            ftp = FTPHandler(ftp_ip, username, password, ftp_port)
            for key in files.keys():
                info = files[key]
                current_uuid = key
                dest = info['dest']
                hash = info['hash']
                self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, 0, info='Starting transfer for file: %s' % info['file_name'])
                if not drive_copy:
                    dest_folder = os.path.split(dest)[0]
                    if os.path.isdir(dest_folder):
                        for existing_file in os.listdir(dest_folder):
                            if existing_file != 'INFO.json':
                                content_copy_log.info('The file [%s] already exists in the destination folder, going to delete ' % existing_file)
                            os.remove(os.path.join(dest_folder, existing_file))

                create_dir(dest)
                if not drive_copy:
                    write_info_file(dest, info, cpl_uuid)
                dst = open(dest, 'wb')
                filesize = ftp.get_size(info['source'])
                try:
                    buffer_size = int(filesize) / 100
                except ValueError:
                    buffer_size = MIN_BUFFER_SIZE

                if buffer_size < MIN_BUFFER_SIZE:
                    buffer_size = MIN_BUFFER_SIZE
                if buffer_size > MAX_BUFFER_SIZE:
                    buffer_size = MAX_BUFFER_SIZE
                local = threading.local()
                local.bytes_recv = 0
                if check_hash:
                    local.hash_object = hashlib.sha1('')
                local.prev_progress = 0

                def __write_to_file(bytes):
                    if hasattr(threading.current_thread(), 'stop'):
                        raise IngestCancelledException
                    if check_hash:
                        local.hash_object.update(bytes)
                    dst.write(bytes)
                    local.bytes_recv += len(bytes)
                    progress = int(float(local.bytes_recv) / float(filesize) * 100)
                    if progress != local.prev_progress:
                        local.prev_progress = progress
                        if progress < 100:
                            self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, progress, info='Transfering file: %s' % info['file_name'])

                ftp.retrieve_binary(info['source'], __write_to_file, buffer_size)
                dst.flush()
                dst.close()
                if check_hash:
                    generated_hash = base64.encodestring(local.hash_object.digest()).strip()
                    info['generated_hash'] = generated_hash
                    if not drive_copy:
                        write_info_file(dest, info, cpl_uuid)
                content_copy_log.info('File ingested completely [%s] for uuid [%s]' % (info['source'], current_uuid))
                if hash and check_hash:
                    if generated_hash == hash:
                        self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, 100, hash_validated=True, info='Finished transfering file: %s' % info['file_name'])
                    else:
                        content_copy_log.error('Error in file copy, Hash does not match. Expected [%s] generated: [%s] for file : %s' % (hash, generated_hash, info['source']))
                        self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, -1, info='Error in file copy, Hash does not match. Expected [%s] generated: [%s] for file : %s' % (hash, generated_hash, info['source']))
                else:
                    self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, 100, info='Finished transfering file: %s' % info['file_name'])

        except IOError as ex:
            content_copy_log.error('error in copying the file!: %s [%s]' % (str(ex), str(traceback.format_exc())))
            self.bus.publish('file_copy_progress', ingest_uuid, current_uuid, -1, info='Error in copying the file: [%s] [%s]' % (str(IOError), str(ex)))
        except IngestCancelledException:
            content_copy_log.info('Ingest has been cancelled! Removing [%s]' % str(ingest_uuid))
            self.bus.publish('file_copy_cancel', ingest_uuid, cpl_uuid)
        except Exception as ex:
            content_copy_log.error('Problem in copy thread [%s] [%s]' % (ex, traceback.format_exc()))
            self.bus.publish('file_copy_progress', ingest_uuid, str(current_uuid), -1, info='Error in copying the file: [%s]' % str(ex))
        finally:
            try:
                self.copy_threads.remove(threading.current_thread())
                if ftp:
                    ftp.close_connection()
                if dst:
                    dst.close()
            except Exception as ex:
                content_copy_log.error('Problem in copy thread [%s] [%s]' % (ex, traceback.format_exc()))

        self.bus.publish('file_copy_finish', ingest_uuid)
        return


def create_dir(path):
    if not os.path.exists(path):
        dir = os.path.split(path)[0]
        create_dir(dir)
        if not os.path.isdir(dir):
            os.mkdir(dir)


def get_sha_hash(file):
    """
    Calculates the hash of a file already on the file system by reading it in.
    This is slow for large files.
    """
    file_size = os.stat(file)[stat.ST_SIZE] / 1024
    HASH_BUFFER_SIZE = 52428800
    sha_generator = hashlib.sha1()
    src = open(file, 'rb')
    bytes_done = 0
    while src:
        payload = src.read(HASH_BUFFER_SIZE)
        if not payload:
            break
        sha_generator.update(payload)
        bytes_done += HASH_BUFFER_SIZE

    return base64.b64encode(sha_generator.digest())


def write_info_file(destination_file, info, cpl_uuid):
    info_filename = os.path.split(destination_file)[0] + '/INFO.json'
    ret = {}
    mimetype = info.get('mimetype', None)
    if mimetype == None:
        content_copy_log.error('Mimetype is required to write an INFO file - %s %s' % (destination_file, info))
        return
    else:
        ret['mimetype'] = mimetype
        size = info.get('size', None)
        if size != None:
            ret['size'] = size
        hash = info.get('hash', None)
        if hash != None:
            ret['hash'] = hash
        parent_folder = info.get('parent_folder', None)
        if parent_folder != None:
            ret['parent_folder'] = parent_folder
        generated_hash = info.get('generated_hash', None)
        if generated_hash != None:
            ret['generated_hash'] = generated_hash
        if info.has_key('missing_font_id'):
            ret['missing_font_id'] = info['missing_font_id']
            ret['missing_font_path'] = info['missing_font_path']
            ret['missing_font_size'] = info['missing_font_size']
            ret['missing_font_hash'] = info['missing_font_hash']
        if cpl_uuid:
            ret['cpl_uuid'] = cpl_uuid
        ret['create_date'] = time.time()
        if info.has_key('ingest_source_type'):
            ret['ingest_source_type'] = info['ingest_source_type']
        with open(info_filename, 'w') as info_file:
            to_be_saved = json.dumps(ret)
            try:
                json.loads(to_be_saved)
            except Exception as e:
                logging.error('Inconsistent JSON was produced! for {info}'.format(info=ret))
                logging.error(pickle.dumps(ret))
                logging.info('Retrying')
                to_be_saved = json.dumps(ret)

            if to_be_saved[-2:] == '}}':
                to_be_saved = to_be_saved[0:-1]
            info_file.write(to_be_saved)
        return
# okay decompyling ./core/devices/content/aamLMS/plugins/copy_plugins.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:50 CST
