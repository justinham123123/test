# 2017.08.13 21:48:51 CST
# Embedded file name: build\bdist.win32\egg\serv\core\devices\content\logical_drive\logical_drive.py
import threading
import datetime
import time
import os
import logging
from uuid import uuid4
import shutil
import cherrypy
from serv.lib.dcinema.dcp.file_handlers import FileHandler, FTPHandler
from serv.lib.dcinema.dcp import mxf
from serv.lib.dcinema.dcp.asset import AssetType
from serv.lib.dcinema.dcp.dcp import DCP
from serv.core.devices.base.mount_point import MountPoint
from serv.core.devices.base.ingest import Ingest
from serv.lib.cherrypy.i18n_tool import ugettext as _
from serv.configuration.constants import MOUNT_POINT_SCAN_DEPTH
from serv.configuration import cfg
from serv.lib.dcinema.dcp.helpers import _folder_is_package

class LogicalDrive(Ingest, MountPoint):
    """
    Logical Drive access and control
    """

    def __init__(self, id, device_info):
        super(LogicalDrive, self).__init__(id, device_info)
        self.drive_configuration = {'auto_sync': device_info['auto_sync'] if 'auto_sync' in device_info else False,
         'auto_ingest': device_info['auto_ingest'] if 'auto_ingest' in device_info else False}
        self.device_configuration['ftp_ip'] = cfg.lms_ftp_ip()
        self.device_configuration['ftp_port'] = cfg.lms_ftp_port()
        self.device_configuration['ftp_username'] = cfg.lms_ftp_username()
        self.device_configuration['ftp_password'] = cfg.lms_ftp_password()
        self.auto_delete = False
        self.dcps = {}
        self.kdms = {}
        if self.device_configuration['type'] not in ('watchfolder', 'cd'):
            cherrypy.engine.subscribe('file_copy_progress', self.update_file_status)
            cherrypy.engine.subscribe('file_copy_cancel', self.cancel_ingest)
            cherrypy.engine.subscribe('file_copy_finish', self.transfer_finished)

    def retrieve_all_contents(self):
        handler = FileHandler()
        digital_cinema_content = self._get_all_digital_cinema_content(handler, self.device_configuration['path'], include_error_report=True)
        self.dcps = digital_cinema_content['processed_dcps']
        self.kdms = digital_cinema_content['processed_kdms']
        if self.kdms:
            self.add_keys_to_lms()
        if digital_cinema_content['processed_packs']:
            self.add_packs_to_tms(digital_cinema_content['processed_packs'])
        return digital_cinema_content

    def add_packs_to_tms(self, packs):
        """
            Push the packs that have been found on the drive to TMS.
        """
        watchfolder = self.device_configuration['type'] == 'watchfolder'
        tms_packs = cherrypy.core.pack_service.packs()
        for pack_info in packs:
            if pack_info['pack']['uuid'] not in tms_packs:
                on_tms = False
            else:
                on_tms = True
            if not on_tms:
                pack_date_to = pack_info['pack'].get('date_to')
                pack_time_to = pack_info['pack'].get('time_to')
                if not pack_time_to:
                    pack_time_to = '00:00:00'
                if pack_date_to is None or datetime.datetime.strptime(pack_date_to + ' ' + pack_time_to, '%Y-%m-%d  %H:%M:%S') > datetime.datetime.now():
                    try:
                        response = cherrypy.core.pack_service.save([pack_info['pack']])
                        if response[0]['type'] == 'success':
                            on_tms = True
                            logging.info('Added Pack %s : %s to TMS' % (pack_info['pack']['uuid'], pack_info['pack']['name']))
                            if watchfolder:
                                self._append_to_watch_log('ingest', '%s : %s' % (response[0]['message'], pack_info['pack']['uuid']))
                                self._log_action('ingest', pack_info['pack_path'], pack_info['pack']['uuid'], 'Pack')
                        elif watchfolder:
                            self._append_to_watch_log('noaction', '%s : %s' % (response[0]['message'], pack_info['pack']['uuid']))
                    except:
                        logging.error('Error adding Pack %s to TMS' % pack_info['pack']['uuid'], exc_info=True)

            if on_tms and self.auto_delete:
                try:
                    os.remove(pack_info['pack_path'])
                    if watchfolder:
                        self._append_to_watch_log('delete', _('Ingested Pack %s removed from watchfolder') % pack_info['pack']['name'])
                        self._log_action('delete', pack_info['pack_path'], pack_info['pack']['uuid'], 'Pack')
                except:
                    logging.error('Cannot delete pack from watchfolder %s' % pack_info['pack']['uuid'], exc_info=True)

        return

    def add_keys_to_lms(self):
        """
            Push the keys that have been found on the drive to the LMS, if they are not already there
        """
        lms_id = cherrypy.core.get_lms_id()
        watchfolder = self.device_configuration['type'] == 'watchfolder'
        lms_keys = cherrypy.core.content_service.keys(device_ids=[lms_id])[0]
        on_lms = False
        for kdm in list(self.kdms):
            if lms_keys.has_key(lms_id) and kdm['uuid'] in lms_keys[lms_id]:
                on_lms = True
            else:
                on_lms = False
            if not on_lms:
                try:
                    kdm_uuid, response = cherrypy.core.content_service.add_key(key=kdm['xml'], source=self.device_configuration['path'])
                    if self.auto_delete:
                        for message in response:
                            if message['type'] == 'action' or message['type'] == 'success':
                                if message.has_key('device_id') and message['device_id'] == lms_id:
                                    on_lms = True
                                if watchfolder:
                                    self._append_to_watch_log('ingest', '%s : %s' % (message['message'], kdm['uuid']))
                                    self._log_action('ingest', kdm['path'], kdm['uuid'], 'KDM')
                            elif watchfolder:
                                self._append_to_watch_log('noaction', '%s : %s' % (message['message'], kdm['uuid']))

                except:
                    logging.error('Error adding KDM %s to LMS' % kdm['uuid'], exc_info=True)

            if (kdm['expired'] or on_lms) and self.auto_delete:
                try:
                    os.remove(kdm['path'])
                    if watchfolder:
                        self._append_to_watch_log('delete', _('Ingested KDM removed from watchfolder %s') % kdm['uuid'])
                        self._log_action('delete', kdm['path'], kdm['uuid'], 'KDM')
                except:
                    logging.error('Cannot delete KDM from watchfolder %s' % kdm['uuid'], exc_info=True)

                self.kdms.remove(kdm)
                continue

    def get_thumbprint(self):
        """
        Here we just add up the "last modified" timestamps of all files to a depth of 8 dirs
        """
        thumbprint = 0
        max_depth = MOUNT_POINT_SCAN_DEPTH
        for dirpath, dirnames, filenames in os.walk(self.device_configuration['path']):
            if dirpath.count(os.sep) >= max_depth:
                del dirnames[:]
            for f in filenames:
                if os.path.exists(os.path.join(dirpath, f)):
                    try:
                        thumbprint = thumbprint + long(os.path.getmtime(os.path.join(dirpath, f)))
                    except OSError:
                        logging.error('Error getting filesize to update drive thumbprint', exc_info=True)

        return thumbprint

    def get_device_information(self):
        output = {'error_messages': []}
        try:
            if os.name == 'nt':
                import win32file
                available, disk_size, total_free = win32file.GetDiskFreeSpaceEx(self.device_configuration['path'])
                output['storage_total'] = disk_size
                output['storage_available'] = available
                output['storage_used'] = disk_size - total_free
            else:
                fs_stats = os.statvfs(self.device_configuration['path'])
                output['storage_total'] = fs_stats.f_blocks * fs_stats.f_bsize
                output['storage_available'] = fs_stats.f_bavail * fs_stats.f_frsize
                output['storage_used'] = output['storage_total'] - output['storage_available']
        except Exception as ex:
            output['error_messages'].append(_('Error retrieving disk usage information: %s') % str(ex))

        return output

    def get_device_status(self):
        output = {'error_messages': []}
        return output

    def transfer_methods(self):
        if self.device_configuration['type'] != 'cd' or cfg.lms_custom_ftp_enabled():
            return ['local', 'ftp']
        else:
            return ['local']

    def ready_for_transfer(self, source):
        for active_transfer in self.transfer_information['active'].values():
            if active_transfer['source'] == source:
                return False

        return True

    def content_delete(self, content_id):
        """
        Deletes the specified content from the device;
        @param content_id            content identifier
        """
        if not cherrypy.core.contents.content_on_device(content_id, self.device_id):
            if content_id in self.drive_storage['cpls']:
                validation_code = 3
            else:
                return (False, _('CPL does not exist for ID: %s') % content_id)
        else:
            content_dict = cherrypy.core.contents.get_contents_dict(device_uuid=self.device_id)
            validation_code = content_dict[content_id]['devices'][self.device_id]['validation_code']
        if validation_code == 3:
            try:
                cpl_folder_path = os.path.join(self.device_configuration['path'], content_id)
                if os.path.exists(cpl_folder_path):
                    shutil.rmtree(cpl_folder_path)
                    del self.drive_storage['cpls'][content_id]
            except Exception as ex:
                message = _('Access denied for path %s' % cpl_folder_path)
                logging.error('Error deleting CPL', str(ex))
                return (False, message)

        else:
            ingest_path = self.drive_storage['cpls'][content_id]['ingest_path']
            try:
                if os.path.exists(ingest_path):
                    if not FileHandler().isdir(ingest_path):
                        try:
                            FileHandler().delete_dir(ingest_path)
                            del self.drive_storage['cpls'][content_id]
                        except Exception as ex:
                            print str(ex)

                    else:
                        shutil.rmtree(ingest_path)
                        del self.drive_storage['cpls'][content_id]
            except Exception as ex:
                message = _('Access denied for path %s' % ingest_path)
                logging.error('Error deleting CPL', exc_info=True)
                return (False, message)

        message = _('CPL deleted')
        logging.info(message)
        return (True, message)

    def content_cancel_transfer(self, transfer_id):
        """
        Cancels a transfer on a device.
        
        @param transfer_id  STRING  - transfer identifier
        """
        success = True
        message = ''
        for thread in threading.enumerate():
            if hasattr(thread, 'ingest_uuid') and transfer_id == thread.ingest_uuid:
                message = _('Cancelling transfer')
                thread.stop = True
                break

        if self.current_ingests.has_key(transfer_id):
            self.cancel_ingest(transfer_id, self.current_ingests[transfer_id]['cpl_uuid'])
        else:
            success = False
            message = _('Could not find specified transfer: %s') % transfer_id
        return (success, message)

    def get_content_video_encoding(self, content_uuid):
        output = {'video_encoding': 'UNKNOWN',
         'error_messages': []}
        ingest_path = self.drive_storage['cpls'][content_uuid]['ingest_path']
        folder, cpl_xml_file = os.path.split(ingest_path)
        file_handler = self._default_handler()
        dcp = DCP(folder, file_handler)
        picture_assets = []
        for asset in dcp.assets.values():
            if asset.type == AssetType.PICTURE:
                picture_assets.append(asset)

        for asset in sorted(picture_assets, key=lambda x: x.fs_size):
            asset_filepath = file_handler.join(folder, asset.relative_path)
            asset_file = None
            try:
                asset_file = file_handler.open(asset_filepath, 'rb')
                output['video_encoding'] = mxf.essence_type(asset_file)
            except Exception as ex:
                logging.error('Error trying to determine video encoding', exc_info=True)
            finally:
                if asset_file != None:
                    asset_file.close()

            break

        return output

    def _default_handler(self):
        return FileHandler()

    def content_transfer(self, connection, description, cpl_uuid):
        """
        Ingests content onto the device.
        
        @param content_path                  STRING   - path to content to ingest.
        @param ftp_ip                        STRING   - for ftp ingests only - connection details
        @param ftp_port                      STRING   - for ftp ingests only - connection details
        @param ftp_user                      STRING   - for ftp ingests only - connection details
        @param ftp_pass                      STRING   - for ftp ingests only - connection details
        @param description                   STRING   - description of ingest
        @param cpl_uuid                      STRING   - content uuid
        
        
        if ftp info is null, assumes local copy.
        
        The CPL must exist in a DCP like folder.
        
        Synchronized with ingest_thread_exists
            ingest_thread_exists checks if an ingest thread exists for specific cpl/assets
            ingest_cpl makes db entries for cpls and issues a command for the copying to begin
                if inbetween these two stages, ingest_thread_exists is called, the cpl ingest will be temporarily be wrongly marked as failed.
        
        
        @return
            success - bool
            messages          -LIST of errors
            transfer_id - id of transfer if successful kick off
        """
        success = False
        message = None
        ftp_user = None
        ftp_pass = None
        ftp_ip = None
        ftp_port = None
        ingest_uuid = str(uuid4())
        ingest_info = {'state': 'active',
         'source': None,
         'percent': 0,
         'start_time': None,
         'cpl_uuid': cpl_uuid,
         'info': 'Unknown',
         'description': description,
         'end_time': time.time(),
         'assets': []}
        content_path = connection['ingest_path']
        content_path = content_path.replace('\\', '/')
        logging.info('Starting ingest for: path=%s ftp=%s port=%s username=%s password=%s source=%s' % (content_path,
         ftp_ip,
         str(ftp_port),
         ftp_user,
         ftp_pass,
         description))
        if connection['type'] == 'local':
            conn = FileHandler()
            logging.info('Starting local ingest for: path=%s' % content_path)
            ingest_info['source'] = content_path
        elif connection['type'] == 'ftp':
            try:
                ftp_user = connection['ftp_username']
                ftp_pass = connection['ftp_password']
                ftp_ip = connection['ftp_ip']
                ftp_port = connection['ftp_port']
                logging.info('Starting ingest for: path=%s ftp=%s port=%s username=%s password=%s source=%s' % (content_path,
                 ftp_ip,
                 str(ftp_port),
                 ftp_user,
                 ftp_pass,
                 description))
                conn = FTPHandler(ftp_ip, ftp_user, ftp_pass, ftp_port)
                ingest_info['source'] = ftp_ip
            except Exception as ex:
                logging.error('Error in connecting to FTP server: %s @ %s' % (ftp_ip, ftp_user), exc_info=True)
                message = _('Error connecting to FTP server: %s @ %s:%s - %s') % (ftp_user,
                 ftp_ip,
                 ftp_port,
                 str(ex))
                return (success, message, ingest_uuid)

        else:
            raise NotImplementedError()
        if not conn.exists(content_path):
            if conn.exists(content_path):
                content_path = content_path
            else:
                logging.error('Error in ingesting content, file not found: %s' % content_path)
                message = _('CPL was not found at the expected path: %s') % content_path
                return (success, message, ingest_uuid)
        folder = content_path
        depth = 5
        count = 0
        while folder and count < depth:
            folder = os.path.split(folder)[0]
            if _folder_is_package(folder, conn):
                break
            count = count + 1
        else:
            logging.error('No assetmap was found in location: %s' % content_path)
            message = _('ASSETMAP was not found in the DCP folder: %s') % content_path
            return (success, message, ingest_uuid)

        dcp = None
        try:
            dcp = DCP(folder, conn)
        except Exception as ex:
            logging.error('Ingest aborted - There was an error in validating the DCP at %s' % folder, exc_info=True)
            message = _('Error analysing the DCP at location %s: %s') % (folder, ex)
            return (success, message, ingest_uuid)

        cpls = [ cpl for cpl in dcp.cpls if cpl.uuid == cpl_uuid ]
        if len(cpls) != 1:
            logging.error('%s CPL(s) found in DCP for CPL path: %s' % (str(len(cpls)), content_path))
            message = _('%s CPLs found in DCP: %s') % (str(len(cpls)), content_path)
            return (success, message, ingest_uuid)
        else:
            cpl = cpls[0]
            if self.is_ingesting(cpl.uuid):
                ingest_details = self.ingest_details(cpl.uuid)
                logging.error('CPL is currently being ingested: %s' % cpl.uuid)
                message = _('CPL %s is being ingested with status: %s') % (cpl.content_title_text, str(ingest_details.get('status', _('Unknown'))))
                return (success, message, ingest_uuid)
            if not cpl.is_ingestible:
                errors = []
                if cpl.errors:
                    errors.append(_('CPL %s cannot be ingested due to errors: %s') % (cpl.content_title_text, str(cpl.errors)))
                for asset_info in cpl.assets:
                    if asset_info['from_this_dcp'] and asset_info['uuid'] in dcp.assets:
                        asset = dcp.assets[asset_info['uuid']]
                        if asset.errors:
                            errors.append(_('An asset %s for the CPL has the following errors: %s') % (asset.full_path, str(asset.errors)))

                logging.error('CPL %s is not suitable for ingest: %s' % (cpl.full_path, message))
                message = ', '.join(errors)
                return (success, message, ingest_uuid)
            cpl_validation = self.get_content_validation_information([cpl.uuid])
            if cpl_validation['content_validation_dict'].has_key(cpl.uuid) and cpl_validation['content_validation_dict'][cpl.uuid]['validation_code'] == 0:
                ingest_info['state'] = 'success'
                ingest_info['percent'] = 100
                ingest_info['start_time'] = time.time()
                ingest_info['end_time'] = time.time()
                ingest_info['info'] = 'CPL %s already exists on device' % cpl.content_title_text
                ingest_info['description'] = cpl.content_title_text
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid] = ingest_info
                logging.info('%s CPL already exists on the Logical Drive in completed form' % cpl.uuid)
                message = _('CPL %s already exists on device') % cpl.content_title_text
                return (True, message, ingest_uuid)
            try:
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid] = ingest_info
                params = {}
                files = {}
                asset_filenames = []
                for asset in dcp.assets:
                    actual_asset = dcp.assets[asset]
                    if not actual_asset.missing:
                        asset_filename = actual_asset.filename
                        asset_filenames.append(asset_filename)
                        dest_path = asset_filename
                        if actual_asset.parent_folder:
                            dest_path = os.path.join(actual_asset.parent_folder, asset_filename)
                        files[actual_asset.uuid] = {'dest': os.path.join(self.device_configuration['path'], cpl.uuid, dest_path),
                         'file_name': asset_filename,
                         'hash': actual_asset.hash,
                         'size': actual_asset.fs_size,
                         'mimetype': actual_asset.mime_type,
                         'parent_folder': actual_asset.parent_folder,
                         'source': actual_asset.full_path}

                dcp_folder_path = os.path.split(content_path)[0]
                for root, dir, dir_files in conn.walk(dcp_folder_path):
                    for filename in dir_files:
                        if filename not in asset_filenames:
                            file_source_fullpath = os.path.join(root, filename).replace('\\', '/')
                            files[filename] = {'dest': os.path.join(self.device_configuration['path'], cpl.uuid, filename),
                             'hash': '',
                             'size': conn.get_size(os.path.join(root, filename).replace('\\', '/')),
                             'mimetype': '',
                             'source': file_source_fullpath,
                             'file_name': filename}

                params['files'] = files
                params['ingest_uuid'] = ingest_uuid
                params['cpl_uuid'] = cpl.uuid
                params['drive_copy'] = True
                with self.current_ingests_lock:
                    self.current_ingests[ingest_uuid]['state'] = 'active'
                    self.current_ingests[ingest_uuid]['start_time'] = time.time()
                    self.current_ingests[ingest_uuid]['description'] = cpl.content_title_text
                    self.current_ingests[ingest_uuid]['info'] = 'Ingest started'
                    self.current_ingests[ingest_uuid]['assets'] = {}
                    self.current_ingests[ingest_uuid]['assets'][cpl.uuid] = files[cpl.uuid] if cpl.uuid in files else {}
                    self.current_ingests[ingest_uuid]['assets'][cpl.uuid]['type'] = 'cpl'
                    self.current_ingests[ingest_uuid]['assets'][cpl.uuid]['percent'] = 0 if files.has_key(cpl.uuid) else 100
                    self.current_ingests[ingest_uuid]['assets'][cpl.uuid]['state'] = 'active' if files.has_key(cpl.uuid) else 'success'
                    self.current_ingests[ingest_uuid]['assets'][cpl.uuid]['size'] = files[cpl.uuid]['size'] if files.has_key(cpl.uuid) else 0
                for asset in files:
                    if asset != cpl.uuid:
                        with self.current_ingests_lock:
                            self.current_ingests[ingest_uuid]['assets'][asset] = files[asset]
                            self.current_ingests[ingest_uuid]['assets'][asset]['type'] = 'asset'
                            self.current_ingests[ingest_uuid]['assets'][asset]['percent'] = 0
                            self.current_ingests[ingest_uuid]['assets'][asset]['size'] = files[asset]['size']

                self.drive_storage['cpls'][cpl.uuid] = {}
                self.drive_storage['cpls'][cpl.uuid]['errors'] = cpl.errors
                self.drive_storage['cpls'][cpl.uuid]['ingestible'] = cpl.is_ingestible
                self.drive_storage['cpls'][cpl.uuid]['complete'] = cpl.complete
                self.drive_storage['cpls'][cpl.uuid]['is_empty_dcp'] = False if dcp.cpls else True
                self.drive_storage['cpls'][cpl.uuid]['size'] = cpl.total_asset_size
                self.drive_storage['cpls'][cpl.uuid]['ingest_path'] = os.path.join(self.device_configuration['path'], cpl.uuid, cpl.uuid + '.xml') if dcp.cpls else os.path.join(self.device_configuration['path'], cpl.uuid)
                self.drive_storage['cpls'][cpl.uuid]['xml'] = cpl._xml
                if not ftp_ip:
                    cherrypy.engine.publish('local_copy', params)
                else:
                    cherrypy.engine.publish('ftp_copy', params, ftp_ip, ftp_port, ftp_user, ftp_pass)
            except Exception as ex:
                with self.current_ingests_lock:
                    del self.current_ingests[ingest_uuid]
                if connection['type'] == 'local':
                    message = _('There was an error starting the ingest of CPL %s : %s') % (cpl.content_title_text, str(ex))
                else:
                    message = _('There was an error while starting the transfer of CPL %s : %s') % (cpl.content_title_text, str(ex))
                logging.error('There was an error while ingesting the CPL %s : %s' % (cpl.content_title_text, content_path), exc_info=True)
                return (success, message, None)

            if connection['type'] == 'local':
                message = _('Ingest started for CPL %s') % cpl.content_title_text
            else:
                message = _('Transfer started for CPL %s') % cpl.content_title_text
            success = True
            return (success, message, ingest_uuid)

    def content_clear_transfer_history(self):
        """
        Clears the transfer history on the device
        
        Returns a dictionary containing
                    response - the response code sent by the server
        """
        for transfer in self.get_completed_transfers().values():
            if transfer.has_key('server_transfer_id') and transfer['server_transfer_id'] != None and self.current_ingests.has_key(transfer['server_transfer_id']):
                with self.current_ingests_lock:
                    del self.current_ingests[transfer['server_transfer_id']]

        return (True, _('Transfer history cleared'))

    def get_transfer_ids(self):
        """
        This returns all the transfer ids in the syste,
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                            ]
        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'error_messages': [],
         'transfers': []}
        output['transfers'] = self.current_ingests.keys()
        return output

    def get_transfer_info(self, transfer_ids):
        """
        This returns all information for specified transfers
        
        @param      None
        @return     {
                        transfers               LIST
                            [
                                server_transfer_id           STRING      - id of this transfer, used for cancelling transfers
                                state          STRING      - 'initializing', 'queued on server', 'active', 'paused', 'canceled', 'success', 'failure'
                                description    STRING      - description of the transfer, ie content title
                                type           STRING      - cpl, kdm...
                                cpl_uuid       STRING      - transferring cpl
                                source         STRING      - source this can be an ipaddress or a description (ie local disk)
                                progress       INTEGER     - % transfer complete
                                message        STRING      - a message elaborating on the transfer_state ('ingest was paused at 15:00')
                            ]
        
                        error_messages:         LIST        - list of errors that occured during getting this information
                    }
        """
        output = {'error_messages': [],
         'transfers': []}
        for uuid, info in self.current_ingests.items():
            if uuid in transfer_ids:
                status = {}
                message = ''
                message_code = None
                if info['state'] == 'active':
                    for asset in info['assets']:
                        if info['assets'][asset]['percent'] > 0 and info['assets'][asset]['percent'] < 100:
                            message = info['assets'][asset]['info']
                            break

                elif info['state'] == 'failed':
                    failed_files = []
                    for asset in info['assets']:
                        if info['assets'][asset]['percent'] == -1:
                            failed_files.append('%s - %s' % (info['assets'][asset]['file_name'], info['assets'][asset]['info']))

                    message = 'Errors: ' + ', '.join(failed_files)
                elif info['state'] == 'success':
                    message = _('Transfer successful')
                    message_code = 10
                status['server_transfer_id'] = uuid
                status['state'] = info['state']
                status['description'] = info['description']
                status['type'] = 'DCP'
                status['source'] = info['source']
                status['content_id'] = info['cpl_uuid']
                status['progress'] = info['percent']
                status['message'] = message
                status['message_code'] = message_code
                status['start_time'] = info['start_time']
                status['end_time'] = info['end_time']
                output['transfers'].append(status)

        return output

    def test_content_connection(self):
        try:
            exists = self._default_handler().exists(self.device_configuration['path'])
        except Exception as ex:
            return (False, _('Unexpected error %s') % str(ex))

        if exists:
            if self.device_status['error_messages'].has_key('test_content_connection'):
                del self.device_status['error_messages']['test_content_connection']
            return (True, _('OK'))
        else:
            message = _('Configured path does not exist: %s') % self.device_configuration['path']
            self.device_status['error_messages']['test_content_connection'] = message
            return (False, message)
# okay decompyling ./core/devices/content/logical_drive/logical_drive.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:54 CST
