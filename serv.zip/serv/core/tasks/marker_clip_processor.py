# 2017.08.13 21:51:07 CST
# Embedded file name: build\bdist.win32\egg\serv\core\tasks\marker_clip_processor.py
import time
import uuid
import json
import logging
from copy import copy
from datetime import datetime, timedelta, time as datetime_time
from itertools import ifilter
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql.expression import and_, or_
from serv.lib.utilities.helper_methods import marker_clip_templating_log, tstamp
from serv.storage.database.primary import database as db
from serv.configuration import cfg
from serv.configuration.constants import MARKER_CLIP_TEMPLATING_CYCLE
from serv.core.tasks.schedule_sync import NOT_PLAYABLE
logger = logging.getLogger('marker_clip_templating')

class MarkerClipProcessor:
    """
    Synchronises packs with schedules, ensures schedules contain the most up-to-date pack info
    """

    def __init__(self, core):
        self.core = core
        self.last_run = 0
        self.last_checked_invalid_shows = 0
        self.eps_marker_clips = cfg.marker_clip_eps_uuid().replace(' ', '').split(',')
        self.lps_marker_clips = cfg.marker_clip_lps_uuid().replace(' ', '').split(',')
        self.marker_clips = self.eps_marker_clips + self.lps_marker_clips
        self.lms_id = self.core.get_lms_id()

    def run(self, force):
        if not cfg.marker_clip_templating():
            return 'Marker Clip Templating is not enabled'
        if time.time() - self.last_checked_invalid_shows > cfg.marker_clip_reschedule_invalid_shows_frequency() * 60:
            self.last_checked_invalid_shows = time.time()
            self.reschedule_shows_with_modified_cpl_validity()
        if not force and time.time() - self.last_run < MARKER_CLIP_TEMPLATING_CYCLE:
            return 'Job just run. Pass force=True to run job manually'
        self.last_run = time.time()
        timeframe_start = datetime_time(cfg.marker_clip_job_start_hour(), cfg.marker_clip_job_start_minutes())
        timeframe_end = datetime_time(cfg.marker_clip_job_end_hour(), cfg.marker_clip_job_end_minutes())
        now = datetime.now().time()
        if timeframe_end > timeframe_start:
            within_time = timeframe_start <= now <= timeframe_end
        else:
            within_time = now >= timeframe_start or now <= timeframe_end
        if within_time or force:
            self.process_marker_clips_schedules()
            return 'Done'
        return 'Outside timeframe. Pass force=True to run job manually'

    def _create_placeholders(self):
        """
        If they don't already exist,
        create placeholders using UUID of the marker clips.
        """
        new_placeholders = []
        placeholders_to_make = ['EPS', 'LPS']
        for placeholder_type in placeholders_to_make:
            try:
                db.Session.query(db.Placeholder).filter(db.Placeholder.name == placeholder_type).one()
            except NoResultFound:
                new_placeholders.append({'name': placeholder_type})

        if new_placeholders:
            logger.info('Creating non-extant placeholders: %s', placeholders_to_make)
            self.core.placeholder_service.save(new_placeholders)
        return self.core.placeholder_service.placeholders()

    def _get_placeholder_uuid(self, placeholder_name):
        for placeholder_uuid in self.placeholders:
            if str(self.placeholders[placeholder_uuid]['name']) == str(placeholder_name):
                return placeholder_uuid

        return None

    def _get_device_spl_to_lms_spl_map(self):
        """
        Returns a dict mapping LMS playlists to the device and device playlist uuid to which they correspond
        """
        _map = {}
        existing_lms_playlists = self.core.playlist_service.playlist(device_ids=[self.lms_id], request_data_items=['marker_device_uuid', 'marker_device_playlist_uuid'])[0]
        for uuid in existing_lms_playlists.get(self.lms_id, {}):
            playlist_info = existing_lms_playlists[self.lms_id][uuid]
            if 'marker_device_uuid' in playlist_info:
                _map[playlist_info['marker_device_uuid'], playlist_info['marker_device_playlist_uuid']] = uuid

        return _map

    def _check_playlist_for_markers(self, device_uuid, playlist_uuid):
        """
        Checks if any marker clip exists in the playlist
        """
        if playlist_uuid in self.core.devices[device_uuid].playlist_information:
            playlist = self.core.devices[device_uuid].playlist_information[playlist_uuid]
            for event in playlist['playlist']['events']:
                if event.get('cpl_id') in self.marker_clips:
                    return True

        return False

    def _save_lms_playlist(self, marker_spl_uuid, marker_device_uuid, lms_playlist_uuid, reschedule = False):
        """"
        Saves a playlist to the LMS based on the given marker_spl_uuid which exists on the given marker_device_uuid.
        The saved playlist uuid will be the given lms_playlist_uuid. If reschedule is True, the playlist save will also
        trigger a reschedule of any schedules which have the saved LMS playlist id as its source_playlist_uuid.
        
        """
        playlist = self.core.devices[marker_device_uuid].playlist_information[marker_spl_uuid]['playlist']
        if reschedule:
            marker_clip_templating_log('Master playlist edited: uuid %s, name %s' % (playlist['id'], playlist['title']))
        new_events = []
        new_playlist = copy(playlist)
        for event in new_playlist['events']:
            if event.get('cpl_id') in self.marker_clips:
                new_events.append({'duration_in_frames': None,
                 'uuid': self._get_placeholder_uuid('EPS') if event.get('cpl_id') in self.eps_marker_clips else self._get_placeholder_uuid('LPS'),
                 'cpl_id': None,
                 'edit_rate': None,
                 'text': 'EPS' if event.get('cpl_id') in self.eps_marker_clips else 'LPS',
                 'automation': [],
                 'content_kind': None,
                 'duration_in_seconds': None,
                 'type': 'placeholder'})
            else:
                new_events.append(event)

        if new_playlist.get('content_version_id'):
            del new_playlist['content_version_id']
        new_playlist['events'] = new_events
        new_playlist['marker_device_uuid'] = marker_device_uuid
        new_playlist['marker_device_playlist_uuid'] = marker_spl_uuid
        new_playlist['marker_playlist_content_version_id'] = playlist.get('content_version_id')
        new_playlist['id'] = lms_playlist_uuid
        new_playlist['title'] = new_playlist['title'] + '_' + self.core.devices[marker_device_uuid].device_configuration['screen_identifier']
        marker_clip_templating_log('Saving LMS playlist for device: %s, playlist: %s' % (marker_device_uuid, marker_spl_uuid))
        self.core.playlist_service.save(self.lms_id, new_playlist, reschedule)
        return

    def _make_lms_playlist(self, device_uuid, device_playlist_uuid):
        """
        Save a new lms playlist based on the device playlist,
        replacing the marker clip with its corresponding placeholder.
        Returns the lms playlist uuid for the given device and playlist id pair.
        
        If an lms playlist has been made for this device playlist uuid during
        a previous run of this job, then we need to delete it and re-save it
        based on the current state of the device playlist (in case it's been edited)
        
        If we have already made an lms playlist for this device playlist id during the
        current job, no need to delete or re-save it - just retrieve the playlist id
        from the map.
        """
        lms_playlist_id = str(uuid.uuid4())
        outcome = None
        if (device_uuid, device_playlist_uuid) in self.device_spl_to_lms_spl_map:
            lms_playlist_id = self.device_spl_to_lms_spl_map[device_uuid, device_playlist_uuid]
            if lms_playlist_id in self.new_lms_playlists_ids:
                outcome = 'Already created during this process run for another scheduled markerclip SPL. No action required'
                return lms_playlist_id
            marker_clip_templating_log('Deleting LMS playlist made during previous job : %s' % lms_playlist_id)
            self.core.playlist_service.delete(playlist_ids=[lms_playlist_id], device_ids=[self.lms_id])
            outcome = 'Created on a previous markerclipping run. Recreating in case device SPL has been edited'
        else:
            outcome = 'Created for the first time as this device SPL has not been seen before'
        self._save_lms_playlist(device_playlist_uuid, device_uuid, lms_playlist_id)
        logger.info('Outcome for LMS SPL [%s] mapped to markerclip SPL [%s] scheduled on [%s]: %s', lms_playlist_id, device_playlist_uuid, device_uuid, outcome)
        return lms_playlist_id

    def process_marker_clips_schedules(self):
        """
        Runs through non-template schedules within the configured timeframe
        Calls helper functions to check each schedule playlist for markers and, if present,
        create a corresponding LMS playlist.
        Sets the schedule source playlist uuid to the lms playlist uuid and marks the
        schedule as a template for future pack resyncing.
        """
        marker_clip_templating_log('Starting Marker Clip Templating Job')
        self.placeholders = self._create_placeholders()
        with self.core.schedule_lock:
            self.device_spl_to_lms_spl_map = self._get_device_spl_to_lms_spl_map()
            schedule_cutoff_timestamp = tstamp(datetime.now() + timedelta(hours=cfg.marker_clip_schedule_timeframe()))
            schedules = db.Session.query(db.Schedule).filter(db.Schedule.start_timestamp > time.time(), db.Schedule.start_timestamp < schedule_cutoff_timestamp, db.Schedule.is_template == False)
            modified_schedule_uuids = []
            self.new_lms_playlists_ids = []
            for schedule in schedules:
                marked = self._check_playlist_for_markers(schedule.device_uuid, schedule.device_playlist_uuid)
                if marked:
                    lms_playlist_id = self._make_lms_playlist(schedule.device_uuid, schedule.device_playlist_uuid)
                    if lms_playlist_id not in self.new_lms_playlists_ids:
                        self.new_lms_playlists_ids.append(lms_playlist_id)
                    self.device_spl_to_lms_spl_map[schedule.device_uuid, schedule.device_playlist_uuid] = lms_playlist_id
                    schedule.is_template = True
                    schedule.published_show_time = schedule.start_timestamp
                    schedule.source_playlist_uuid = lms_playlist_id
                    modified_schedule_uuids.append(schedule.uuid)
                else:
                    logger.info('Scheduled playlist [%s] does not contain any marker clips', schedule.uuid)

            db.Session.commit()
        if modified_schedule_uuids:
            marker_clip_templating_log('Rescheduling these schedules: %s' % modified_schedule_uuids)
            self.core.scheduling_service.reschedule(schedule_uuids=modified_schedule_uuids)
        else:
            marker_clip_templating_log('No marker clip schedules found')

    def reschedule_marker_clip_schedules(self, changed_content_version_ids, device_uuid):
        """
        Given a list of tuples, each containing an edited spl content version id and its corresponding new
        playlist uuid, this checks if any of the edited playlists is an original marker clip playlist
        which we have based a LMS templated playlist on. If it is, the old LMS playlist is deleted, and
        a new one created (with the same uuid as the previous one) based on the edited marker clip playlist.
        The LMS playlist re-save will trigger a reschedule of any schedules which have the saved LMS playlist id
        as its source_playlist_uuid.
        """
        with self.core.schedule_lock:
            self.placeholders = self._create_placeholders()
            lms_playlists = self.core.playlist_service.playlist(request_data_items=['marker_playlist_content_version_id', 'marker_device_uuid'])[0][self.lms_id]
            marker_spl_lms_spl_map = {}
            for playlist in lms_playlists:
                if lms_playlists[playlist].get('marker_device_uuid') == device_uuid and lms_playlists[playlist].get('marker_playlist_content_version_id'):
                    marker_spl_lms_spl_map[lms_playlists[playlist]['marker_playlist_content_version_id']] = playlist

            for content_version_id, new_spl_uuid in changed_content_version_ids:
                if content_version_id in marker_spl_lms_spl_map:
                    self.core.playlist_service.delete(playlist_ids=marker_spl_lms_spl_map[content_version_id], device_ids=[self.lms_id])
                    self._save_lms_playlist(new_spl_uuid, device_uuid, marker_spl_lms_spl_map[content_version_id], True)

    def reschedule_shows_with_modified_cpl_validity(self):
        """
        Checks for two things: CPLs that are no longer valid, and those which were trimmed initially but are now valid
        It then takes those SPLs, finds any scheduled instances, and reschedules them so they re-trimmed
        """
        shows_to_reschedule = self.get_shows_with_modified_validity()
        if shows_to_reschedule:
            marker_clip_templating_log('Rescheduling these schedules-with-modified-cpl-validity: %s', shows_to_reschedule)
            self.core.scheduling_service.reschedule(schedule_uuids=shows_to_reschedule)

    def get_shows_with_modified_validity(self):
        soonest_schedule_time = time.time() + cfg.core_auto_schedule_resync_gap_minutes() * 60
        marker_clip_templating_log('Checking schedules from [%s] for CPLs with modified validity', datetime.fromtimestamp(soonest_schedule_time))
        marker_clipper_spls = db.Session.query(db.Schedule.device_playlist_uuid, db.Schedule.device_uuid, db.Schedule.templating_issues).filter(db.Schedule.is_template == True, db.Schedule.pos_id == None, db.Schedule.published_show_time != None, db.Schedule.start_timestamp > soonest_schedule_time).distinct()
        validity_modified_spls = set()
        for spl_id, device_id, templating_issues in marker_clipper_spls:
            if self.core.devices[device_id].get_playlist_missing_or_invalid_cpl_uuids(spl_id):
                validity_modified_spls.add((spl_id, device_id))
            for issue in json.loads(templating_issues):
                for cpl in ifilter(lambda cpl: cpl['reason'] == NOT_PLAYABLE, issue.get('trimmed_cpls', [])):
                    if self.core.contents[cpl['cpl_uuid']].valid_on_device(self.core.get_lms_id()):
                        validity_modified_spls.add((spl_id, device_id))

        if not validity_modified_spls:
            return []
        else:
            invalid_show_ids = db.Session.query(db.Schedule.uuid).filter(or_(*[ and_(db.Schedule.device_playlist_uuid == spl[0], db.Schedule.device_uuid == spl[1]) for spl in validity_modified_spls ]))
            return [ t[0] for t in invalid_show_ids ]
# okay decompyling ./core/tasks/marker_clip_processor.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:08 CST
