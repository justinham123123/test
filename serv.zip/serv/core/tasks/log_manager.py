# 2017.08.13 21:51:02 CST
# Embedded file name: build\bdist.win32\egg\serv\core\tasks\log_manager.py
from Queue import Queue
from collections import namedtuple
import copy
from datetime import datetime, timedelta, time as datetime_time
import json
import logging
import os
from random import shuffle
from threading import Lock, RLock
import time
import zipfile
import cherrypy
from serv.core.devices.base.pos import POS as base_POS
from sqlalchemy.orm import joinedload
from sqlalchemy.sql.expression import and_, or_, not_, between, desc, asc
from serv.configuration import cfg
from serv.configuration.constants import AUTO_CLEANUP_POS_VALIDITY, SCHEDULE_MAPPER_CYCLE
from serv.core.devices.base import log_collection as base_Logging
from serv.core.tasks.reconcile_logs import reconcile_logs, LOOSE_MARGIN, CODE_START_AND_END_OFF
from serv.lib.dcinema.constants import NULL_UUID
from serv.lib.dcinema.logs import smpte
from serv.lib.utilities import helper_methods, config
from serv.lib.utilities.helper_methods import seconds_to_time
from serv.lib.utilities.make_hash import make_hash
from serv.storage.database.audit import database as audit_db
from serv.storage.database.helpers import int_timestamp_default
from serv.storage.database.playback import database as playback_db
from serv.storage.database.primary import database as db

def _log(level, msg, *args, **kwargs):
    logging.getLogger('logmanager').log(level, msg, *args, **kwargs)


SMPTE_SHAVE_FRACTION = 0.9

class Log_Manager(object):
    """
    Deals with SMPTE and Live log collection/parsing/merging
    NB: Device IPs are used in favour of screen IDs since IPs are more stable
    """
    MIGRATION_CHUNK_SIZE = 1 if cfg.core_log_collection_only() else 2
    MIGRATION_METADATA_BACKFILL = 30
    LIVELOG_MERGE_PERIOD = 60 * 60 * 4
    DEFAULT_LIVELOG_MERGE_MARGIN = 600

    def __init__(self, core):
        self.core = core
        self.enabled = cfg.core_log_manager_enabled.get()
        log_folder = helper_methods.multipassify_string('device_store')
        self.log_lock = Lock()
        self.logging_base_path = os.path.join(cfg.lms_library_directory(), log_folder)
        self.pos_sources = None
        self.livelog_lock = Lock()
        dump_folder = helper_methods.multipassify_string('live_dump')
        self.live_dump_dir = os.path.join(cfg.lms_library_directory(), dump_folder)
        self.live_dump_path = os.path.join(cfg.lms_library_directory(), dump_folder, 'live_dump.json')
        self.live_log_queue = Queue()
        self.live_logs = []
        self.live_log_flush_checker = helper_methods.BatchFlushChecker(timeout=30)
        self.audit_log_queue = Queue()
        self.audit_logs = []
        self.audit_log_flush_checker = helper_methods.BatchFlushChecker(timeout=30)
        self._setup_log_dir()
        self._undump_live_logs()
        self.smpte_collector = self._SmpteCollector(self.core, self.logging_base_path)
        self.last_schedule_divergence_run = 0
        self.schedule_map_lock = RLock()
        self.schedule_divergence_data = {}
        cherrypy.engine.publish('cclisten', 'config_synced', self._handle_config_synced)
        return

    def _handle_config_synced(self, payload = None):
        with self.schedule_map_lock:
            if not self.schedule_divergence_data.get('schedule_map'):
                self.get_schedule_divergence()
            else:
                cherrypy.engine.publish('ccpush', 'schedule_map_information', self.schedule_divergence_data, target=payload['url'])

    def shutdown(self):
        """ Ensures pending live/audit logs are flushed to disk rather than lost for ever"""
        shutdown_event = {'shutdown': True}
        self.live_log_queue.put(shutdown_event)
        self.audit_log_queue.put(shutdown_event)

    def _shutting_down(self):
        return cherrypy.engine.shutdown_servers

    def set_logging_level(self, level):
        """Set to 10 for debugging. Default is 20 (info)"""
        logging.getLogger('logmanager').setLevel(level)

    def run(self):
        """
        Monitor thread is subscribed to this. Handles everything needed to be done periodically
        """
        if not self.enabled:
            return
        self.collect_smpte_logs()
        if time.time() - self.last_schedule_divergence_run > SCHEDULE_MAPPER_CYCLE:
            self.get_schedule_divergence()
            self.last_schedule_divergence_run = time.time()
        self._trigger_clean_up()

    def toggle(self):
        self.enabled = not self.enabled
        cfg.core_log_manager_enabled.set(self.enabled)
        config.save()
        _log(logging.WARN, 'Log Manager Enabled state toggled to %s', self.enabled)

    def collect_smpte_logs(self, force = False):
        if not self.log_lock.acquire(False):
            _log(logging.WARN, 'Cannot acquire log lock for SMPTE collection')
            return 'Cannot run collection - log manager is busy. Try again later'
        if self._shutting_down():
            return 'Shutting down'
        try:
            self._migration_parse_n_merge()
            result_message, parsed_dates = self.smpte_collector.run(force)
            if parsed_dates and len(self.live_logs):
                self._flush_live_logs()
                self._parse_live_logs(allow_merge=False)
            self._merge_specific_screens_and_dates(parsed_dates)
        except Exception as ex:
            _log(logging.ERROR, 'SMPTE collection issue', exc_info=True)
            result_message = 'Exception was raised: %s' % ex
        finally:
            self.log_lock.release()

        return result_message

    def _setup_log_dir(self):
        """
        Initial install setup - create log directory
        """
        if not os.path.isdir(self.live_dump_dir):
            os.makedirs(self.live_dump_dir)

    def get_screen_ips(self, screen_ids):
        """
        Gets list of Log-enabled device IPs from a list of screen ids.
        Return all IPs if no screen_ids are supplied
        """
        return [ self.core.devices[device_id].device_configuration['ip'] for device_id in self.core.get_devices(required_api=base_Logging.Logging)[0] if not screen_ids or self.core.devices[device_id].device_configuration['screen_identifier'] in screen_ids ]

    def _is_shutdown_event(self, event):
        return 'shutdown' in event

    class _SmpteCollector(object):
        """
        Collects SMPTE logs from each device and parses the playouts into LogFilePlayouts
        """
        MAX_PLACEHOLDERS = 1
        NUM_OLDEST_LOGS_CHECK_PLAYOUTS = 7

        def __init__(self, core, logging_base_path):
            self.core = core
            try:
                if not os.path.isdir(logging_base_path):
                    os.makedirs(logging_base_path)
                self.loggable = True
            except:
                self.loggable = False

            self.logging_base_path = logging_base_path

        @playback_db.close_session
        def run(self, force = False):
            """
            Collect SMPTE logs from devices - add entries to LogFile table
            """
            self.placeholders_created = False
            ok, reason = self._collection_suitability(force)
            if ok:
                _log(logging.INFO, 'Starting log collection')
            else:
                _log(logging.INFO, 'Not collecting logs - ' + reason)
                return (reason, {})
            self.local_date = datetime.now().date()
            self.parsed_dates = {}
            self.enough_disk_space_historic_collection = self._enough_disk_space_historic_collection()
            default_collection_start = datetime_time(cfg.core_log_start_hour.get(), cfg.core_log_start_minute.get())
            default_collection_end = datetime_time(cfg.core_log_end_hour.get(), cfg.core_log_end_minute.get())
            in_default_timeframe = self._in_timeframe(default_collection_start, default_collection_end)
            timeframes = {}
            db_timeframes = db.Session.query(db.TimeframeMap).options(joinedload('timeframe'))
            for t in db_timeframes:
                si = self.core.screens[t.screen_uuid]['identifier']
                start = seconds_to_time(t.timeframe.start_time)
                end = seconds_to_time(t.timeframe.end_time)
                timeframes[si] = self._in_timeframe(start, end)

            device_ids = self.core.get_devices(required_api=base_Logging.Logging)[0]
            for device_id in device_ids:
                device = self.core.devices[device_id]
                screen_id = device.device_configuration['screen_identifier']
                if not timeframes.get(screen_id, in_default_timeframe):
                    logging.debug('Not in configured timeframe: %s' % screen_id)
                    continue
                if cfg.core_log_collection_only():
                    try:
                        device.wake_socket()
                        device._device_sync_playback_status()
                        device._device_sync_device_information()
                    except Exception as e:
                        _log(logging.WARN, 'Cannot create placeholders for %s - device sync failed: %s', screen_id, e)
                        continue

                if not self.can_create_placeholders(device):
                    _log(logging.WARN, 'Cannot create placeholders for %s - missing crucial device info', screen_id)
                    continue
                self._create_placeholders(device)
                if not device.is_ready_for_collect():
                    _log(logging.INFO, 'Cannot do SMPTE log collection for %s - not ready to collect', screen_id)
                    continue
                if not self._create_zip_directory_if_absent(device):
                    _log(logging.ERROR, 'Error creating log directory on disk', exc_info=True)
                    continue
                try:
                    db_logs_to_collect = self._get_logs_to_collect(device, 'pull_attempted', False)
                    db_logs_to_recollect = self._get_logs_to_collect(device, 'repull_marked', True)
                    all_db_logs_to_collect = db_logs_to_collect + db_logs_to_recollect
                    _log(logging.INFO, 'Attempting to collect %d SMPTE logs for %s (%d new, %d retries)' % (len(all_db_logs_to_collect),
                     screen_id,
                     len(db_logs_to_collect),
                     len(db_logs_to_recollect)))
                    for db_log in all_db_logs_to_collect:
                        if not device.is_ready_for_collect():
                            _log(logging.INFO, 'Device %s not ready to collect', screen_id)
                            break
                        self._collect_and_parse(device, db_log)

                except Exception:
                    _log(logging.ERROR, 'Error in collect-and-parse for %s', screen_id, exc_info=True)

            num_to_repull = self.auto_recollect_smpte_logs()
            total_parsed_succesfully = sum((len(screens) for screens in self.parsed_dates.itervalues()))
            result_message = 'SMPTE collection done with %d collected and successfully parsed. Marked %d failures for recollection.' % (total_parsed_succesfully, num_to_repull['count'])
            _log(logging.INFO, result_message)
            if total_parsed_succesfully or self.placeholders_created:
                self.core.logging_service.log_file_update()
            return (result_message, self.parsed_dates)

        def auto_recollect_smpte_logs(self):
            """
            Decide what needs to be re-pulled (recent probable failures), and mark them in the db as such
            """
            earliest_repull_timestamp = time.mktime((datetime.now() - timedelta(days=cfg.core_log_retry_days.get())).timetuple())
            db_logs_repull = playback_db.Session.query(playback_db.LogFile).filter(and_(playback_db.LogFile.created >= earliest_repull_timestamp, playback_db.LogFile.pull_attempted == True, playback_db.LogFile.repull_marked == False, or_(playback_db.LogFile.no_playouts == True, playback_db.LogFile.parsed == False))).update({'repull_marked': True,
             'last_modified': int_timestamp_default()}, False)
            playback_db.Session.commit()
            return {'count': db_logs_repull}

        def can_create_placeholders(self, device):
            return device.device_information['device_dnqualifier'] and device.device_information['serial']

        def create_placeholder(self, date, device):
            placeholders = []
            db_log_placeholder = {'date': date,
             'screen_identifier': device.device_configuration['screen_identifier'],
             'dnqualifier': device.device_information['device_dnqualifier'],
             'serial': device.device_information['serial'],
             'device_ip_address': device.device_configuration['ip'],
             'unencrypted': False}
            db_log = playback_db.LogFile(**db_log_placeholder)
            db_log.generate_uuid()
            placeholders.append(db_log)
            if device.has_unencrypted_logs():
                db_log_placeholder['unencrypted'] = True
                db_log = playback_db.LogFile(**db_log_placeholder)
                db_log.generate_uuid()
                placeholders.append(db_log)
            return placeholders

        def _in_timeframe(self, start, end):
            now = datetime.now().time()
            if end > start:
                return start <= now <= end
            return now >= start or now <= end

        def _collection_suitability(self, force):
            auto_collection_on = cfg.core_store_device_logs()
            if not self.loggable:
                return (False, 'Disk not writable')
            if not force:
                return auto_collection_on or (False, 'Log collection disabled')
            return (True, '')

        def _enough_disk_space_historic_collection(self):
            total = sum(map(os.path.getsize, helper_methods.all_files(self.logging_base_path)))
            limit = int(cfg.core_log_storage_limit.get()) * 1000000
            return total < limit * SMPTE_SHAVE_FRACTION

        def _create_placeholders(self, device):
            new_placeholder_dates = set()

            def _can_create_more_placeholders():
                return len(new_placeholder_dates) < self.MAX_PLACEHOLDERS

            def _probably_more_historic_logs(oldest_placeholders):
                if len(oldest_placeholders) < self.NUM_OLDEST_LOGS_CHECK_PLAYOUTS:
                    return True
                for old_placeholder in oldest_placeholders:
                    if old_placeholder.no_playouts == False:
                        return True

                return False

            current_dnq = device.device_information['device_dnqualifier']
            device_ip = device.device_configuration['ip']
            current_db_placeholders = playback_db.Session.query(playback_db.LogFile.date).filter_by(device_ip_address=device_ip)
            current_placeholder_dates = set((placeholder.date for placeholder in current_db_placeholders))
            oldest_placeholders_current_device = playback_db.Session.query(playback_db.LogFile).filter(playback_db.LogFile.device_ip_address == device_ip, playback_db.LogFile.dnqualifier == current_dnq).order_by(playback_db.LogFile.date.asc()).limit(self.NUM_OLDEST_LOGS_CHECK_PLAYOUTS).all()
            oldest_date_for_gap_filling = oldest_placeholders_current_device[0].date if oldest_placeholders_current_device else self.local_date
            current_date = self.local_date - timedelta(days=1)
            while _can_create_more_placeholders() and current_date >= oldest_date_for_gap_filling:
                if current_date not in current_placeholder_dates:
                    new_placeholder_dates.add(current_date)
                current_date -= timedelta(days=1)

            if _can_create_more_placeholders() and _probably_more_historic_logs(oldest_placeholders_current_device) and self.enough_disk_space_historic_collection:
                current_date = oldest_date_for_gap_filling - timedelta(days=1)
                while _can_create_more_placeholders() and current_date not in current_placeholder_dates:
                    new_placeholder_dates.add(current_date)
                    current_date -= timedelta(days=1)

            if new_placeholder_dates:
                placeholders = []
                for date in new_placeholder_dates:
                    placeholders.extend(self.create_placeholder(date, device))

                playback_db.Session.add_all(placeholders)
                playback_db.Session.commit()
                self.placeholders_created = True

        def _create_zip_directory_if_absent(self, device):
            device_directory_path = self._get_device_logging_path(device)
            if not os.path.isdir(device_directory_path):
                try:
                    os.makedirs(device_directory_path)
                except OSError:
                    return False

            return True

        def _get_logs_to_collect(self, device, column, condition):
            db_logs_to_collect = playback_db.Session.query(playback_db.LogFile).filter(playback_db.LogFile.device_ip_address == device.device_configuration['ip'], playback_db.LogFile.dnqualifier == device.device_information['device_dnqualifier'], getattr(playback_db.LogFile, column) == condition).all()
            shuffle(db_logs_to_collect)
            return db_logs_to_collect

        def _collect_and_parse(self, device, db_log):
            playback_db.Session.add(db_log)
            xml = self._collect_smpte_log(device, db_log)
            _log(logging.INFO, 'SMPTE Collection %(uncrypt)s %(sf)s for %(date)s on  %(device)s%(error)s' % {'sf': 'successful' if db_log.pulled else 'failed/empty',
             'error': ': ' + db_log.error_message if db_log.error_message else '',
             'uncrypt': '(unencrypted)' if db_log.unencrypted else '',
             'device': device.device_configuration['screen_identifier'],
             'date': db_log.date.strftime('%Y-%m-%d')})
            if xml:
                parser = Log_Manager._SmptePlayoutParser(db_log)
                parse_counts, parse_dates = parser.parse(xml)
                for date in parse_dates:
                    self.parsed_dates.setdefault(date, set()).add(db_log.device_ip_address)

                _log(logging.INFO, 'SMPTE Parsing %s%s' % ('successful %s' % parse_counts if db_log.parsed else 'failed', ': ' + db_log.error_message if db_log.error_message else ''))
            playback_db.Session.commit()

        def _handle_log_response(self, device, db_log, response):
            xml = None
            device_directory_path = self._get_device_logging_path(device)
            file_name = '%(date)s%(uncrypt)s' % {'date': db_log.date.strftime('%Y-%m-%d'),
             'uncrypt': '_Unencrypted' if db_log.unencrypted else ''}
            xml_file_name = os.path.join(device_directory_path, file_name + '.xml')
            zip_file_name = os.path.join(device_directory_path, file_name + '.zip')
            if response is None:
                db_log.error_message = 'Collection ERROR: Empty log response'
            elif len(response['error_messages']) > 0:
                db_log.error_message = 'Collection ERROR: ' + '; '.join(response['error_messages'])
            elif not response['xml']:
                db_log.error_message = 'Collection ERROR: No XML returned'
            else:
                xml = response['xml']
                with open(xml_file_name, 'w') as f:
                    f.write(xml)
                try:
                    myzip = zipfile.ZipFile(zip_file_name, 'w')
                    myzip.write(xml_file_name, file_name + '.xml', zipfile.ZIP_DEFLATED)
                    db_log.absolute_file_path = zip_file_name
                    db_log.pulled = True
                except:
                    db_log.error_message = 'Collection ERROR: Failed to zip'
                finally:
                    if myzip:
                        myzip.close()

                os.remove(xml_file_name)
            return xml

        def _collect_smpte_log(self, device, db_log):
            from_datetime = datetime.combine(db_log.date, datetime_time(0, 0, 0, 0))
            get_logs_response = device.get_unencrypted_logs(from_datetime) if db_log.unencrypted else device.get_logs(from_datetime)
            db_log.pull_attempted = True
            db_log.pulled = False
            db_log.repull_marked = False
            db_log.absolute_file_path = None
            db_log.parsed = False
            db_log.parse_attempted = False
            db_log.signed = None
            db_log.no_playouts = None
            db_log.error_message = None
            db_log.last_modified = int_timestamp_default()
            return self._handle_log_response(device, db_log, get_logs_response)

        def _get_device_logging_path(self, device):
            safe_name = helper_methods.safe_directory_name(device.device_configuration['screen_identifier'])
            return os.path.join(self.logging_base_path, safe_name)

    class _SmptePlayoutParser(object):
        """ Class rather than nested functions makes for easier unit testing """

        def __init__(self, db_log):
            self.db_log = db_log
            self.parse_counts = {'full': 0,
             'partial': 0,
             'resolved_partial': 0}
            self.parse_dates = set()
            self.unexpected_date_count = 0
            self.playback_logs = []

        def parse(self, xml):
            self.db_log.parse_attempted = True
            try:
                self.old_deleted = self._clear_old_get_deleted()
                parsed_log = smpte.SMPTELog(xml)
            except Exception:
                err = 'Parser ERROR: exception raised'
                _log(logging.ERROR, err, exc_info=True)
                self.db_log.error_message = err
            else:
                self.db_log.parsed = True
                self.db_log.signed = parsed_log.is_signed
                self.db_log.no_playouts = len(parsed_log.playouts) == 0
                if self.db_log.no_playouts == False:
                    self.parse_dates.add(self.db_log.date)
                for playout in parsed_log.playouts:
                    self._add_parsed_playout(playout)

                if len(self.playback_logs) > 0:
                    self._resolve_crossover_after(self.playback_logs[0])
                if len(self.playback_logs) > 1:
                    self._resolve_crossover_before(self.playback_logs[-1])
                playback_db.Session.add_all(self.playback_logs)
                if self.unexpected_date_count:
                    parsed_log.warnings.append('some playouts parsed with an unexpected date')
                if parsed_log.warnings:
                    self.db_log.error_message = 'Parser WARNING: ' + '; '.join(parsed_log.warnings)
                if parsed_log.raw_warnings:
                    _log(logging.INFO, 'Raw parsing warnings: ' + '; '.join(parsed_log.raw_warnings))

            return (self.parse_counts, self.parse_dates)

        def _clear_old_get_deleted(self):
            """ Clear any playouts from previous parses and return set of signatures of deleted ones,
            so that new playouts can be marked deleted if need be """
            old_deleted_playouts = playback_db.Session.query(playback_db.LogFilePlayout).filter_by(log_file_uuid=self.db_log.uuid).filter(playback_db.LogFilePlayout.deleted == True)
            deleted = set([ playout.cpl_uuid + str(playout.start_time) + str(playout.end_time) for playout in old_deleted_playouts ])
            old_deleted_playouts = playback_db.Session.query(playback_db.LogFilePlayout).filter_by(log_file_uuid=self.db_log.uuid).delete(False)
            return deleted

        def _add_parsed_playout(self, playout):
            start_dt = datetime.fromtimestamp(playout['start_timestamp']) if 'start_timestamp' in playout else None
            end_dt = datetime.fromtimestamp(playout['end_timestamp']) if 'end_timestamp' in playout else None
            if start_dt and start_dt.date() != self.db_log.date or end_dt and end_dt.date() != self.db_log.date:
                self.unexpected_date_count += 1
                _log(logging.WARN, 'Unexpected playout time %(start)s - %(end)s parsed from screen %(screen)s, should fall on %(date)s. Continuing anyway.' % {'start': start_dt,
                 'end': end_dt,
                 'screen': self.db_log.screen_identifier,
                 'date': self.db_log.date})
            lf_playout = playback_db.LogFilePlayout(log_file_uuid=self.db_log.uuid, start_time=playout.get('start_timestamp'), end_time=playout.get('end_timestamp'), cpl_uuid=playout['cpl_uuid'])
            lf_playout.deleted = lf_playout.cpl_uuid + str(lf_playout.start_time) + str(lf_playout.end_time) in self.old_deleted
            self.playback_logs.append(lf_playout)
            if 'end_timestamp' not in playout or 'start_timestamp' not in playout:
                self.parse_counts['partial'] += 1
            else:
                self.parse_counts['full'] += 1
            return

        def _handle_matched_partial(self, partial):
            partial.deleted = True
            self.parse_dates.add(partial.log_file.date)
            playback_db.Session.add(partial)
            self.parse_counts['resolved_partial'] += 1

        def _previous_log_last_playout(self):
            return playback_db.Session.query(playback_db.LogFilePlayout).join(playback_db.LogFile, playback_db.LogFile.uuid == playback_db.LogFilePlayout.log_file_uuid).filter(playback_db.LogFile.dnqualifier == self.db_log.dnqualifier, playback_db.LogFile.date == self.db_log.date - timedelta(days=1), playback_db.LogFile.unencrypted == self.db_log.unencrypted, playback_db.LogFilePlayout.start_time != None).order_by(desc(playback_db.LogFilePlayout.start_time)).first()

        def _resolve_crossover_after(self, first_playout):
            if first_playout and first_playout.start_time == None and not first_playout.deleted:
                previous_playout = self._previous_log_last_playout()
                if previous_playout and previous_playout.cpl_uuid == first_playout.cpl_uuid and previous_playout.end_time == None:
                    first_playout.start_time = previous_playout.start_time
                    self._handle_matched_partial(previous_playout)
                    _log(logging.DEBUG, 'Handled post-midnight crossover smpte playout using #%s: %s - %s', previous_playout.id, datetime.fromtimestamp(first_playout.start_time), datetime.fromtimestamp(first_playout.end_time))
            return

        def _next_log_first_playout(self):
            return playback_db.Session.query(playback_db.LogFilePlayout).join(playback_db.LogFile, playback_db.LogFile.uuid == playback_db.LogFilePlayout.log_file_uuid).filter(playback_db.LogFile.dnqualifier == self.db_log.dnqualifier, playback_db.LogFile.date == self.db_log.date + timedelta(days=1), playback_db.LogFile.unencrypted == self.db_log.unencrypted, playback_db.LogFilePlayout.end_time != None).order_by(asc(playback_db.LogFilePlayout.end_time)).first()

        def _resolve_crossover_before(self, last_playout):
            if last_playout and last_playout.end_time == None and not last_playout.deleted:
                next_playout = self._next_log_first_playout()
                if next_playout and next_playout.cpl_uuid == last_playout.cpl_uuid and next_playout.start_time == None:
                    last_playout.end_time = next_playout.end_time
                    self._handle_matched_partial(next_playout)
                    _log(logging.DEBUG, 'Handled pre-midnight crossover smpte playout using #%s: %s - %s', next_playout.id, datetime.fromtimestamp(last_playout.start_time), datetime.fromtimestamp(last_playout.end_time))
            return

    @playback_db.close_session
    def reparse_smpte_logs(self, device_ips = [], start_timestamp = None, end_timestamp = None):
        """
        Analyse SMPTE Logs - re-add playouts to LogFilePlayout table
        Currently, parsing is done at the same time as collection to avoid ripping logs out of the filesystem (since the XML is already in memory).
        This is therefore only used by the migration and the API
        """

        def _legacy_clean(xml):
            if xml.count('<?xml') > 1:
                last_xml_start = xml.rfind('<?xml')
                return xml[:last_xml_start]
            return xml

        db_logs_to_reparse = self._get_db_smpte_logs(device_ips, start_timestamp, end_timestamp)
        result = []
        parsed_ips = set()
        for db_log in db_logs_to_reparse:
            log_stats = {'device': db_log.device_ip_address,
             'date': db_log.date.strftime('%Y-%m-%d'),
             'uncrypt': db_log.unencrypted}
            result.append(log_stats)
            if not db_log.pulled:
                result[-1]['error'] = 'db_log exists but is un-pulled: ' + str(db_log.error_message)
                continue
            db_log.parse_attempted = True
            zp = None
            xml = None
            error = win = None
            try:
                zp = zipfile.ZipFile(db_log.absolute_file_path)
                zip_files = zp.namelist()
                if len(zip_files) != 1:
                    error = 'Parser ERROR: Expected one xml file in logzip, not %d.' % len(zip_files)
                else:
                    xml = zp.open(zip_files[0]).read()
                    if not xml:
                        error = 'Parser ERROR: Empty XML'
            except Exception as ex:
                error = 'Parser ERROR: Bad XML: %s' % ex
            finally:
                if zp:
                    zp.close()

            if xml:
                db_log.parsed = False
                db_log.error_message = None
                db_log.last_modified = int_timestamp_default()
                parser = self._SmptePlayoutParser(db_log)
                win = parser.parse(_legacy_clean(xml))[0]
                error = db_log.error_message
                parsed_ips.add(db_log.device_ip_address)
            else:
                db_log.error_message = error
            if error:
                result[-1]['error'] = error
                _log(logging.WARN, log_stats)
            if win:
                result[-1]['result'] = win
                _log(logging.INFO, log_stats)

        playback_db.Session.commit()
        remerge_result = 'Nothing to remerge'
        if parsed_ips:
            remerge_result = self.remerge_smpte_logs(parsed_ips, start_timestamp, end_timestamp)
        return (result, remerge_result)

    def _merge_smpte_logs(self, ips, suppress_update = False):
        """
        Merge SMPTE playouts from LogFilePlayout table into Playback table.
        :param suppress_update: Do not notify producer about updated playback logs (bool).
        """
        playbacks_added = False
        for ip in ips:
            _log(logging.INFO, 'Merging logs for device %s', ip)
            try:
                playbacks_added |= reconcile_logs(ip, self._get_cpl_metadata)
            except Exception:
                _log(logging.ERROR, 'Error during reconciliation', exc_info=True)

        if not suppress_update and playbacks_added:
            _log(logging.DEBUG, 'Informing Producer about new playbacks')
            self.core.logging_service.playback_log_update()
        _log(logging.INFO, 'Merge complete.')

    def remerge_smpte_logs(self, device_ips, start_timestamp = None, end_timestamp = None, suppress_update = False):
        """
        Mark SMPTE Log Files for re-merging into Playback table.
        :param suppress_update: Do not notify producer about updated playback logs (bool).
        """
        end_timestamp = end_timestamp or time.time()
        start_timestamp = start_timestamp or end_timestamp - 86400
        result = self._mark_remergeable(device_ips, start_timestamp, end_timestamp)
        self._merge_smpte_logs(device_ips, suppress_update)
        return 'Pre-remerge result: %s' % result

    def _merge_specific_screens_and_dates(self, screen_dates):
        all_ips = set()
        for date, ips in screen_dates.iteritems():
            all_ips |= set(ips)
            timestamp = time.mktime(datetime.combine(date, datetime_time.min).timetuple())
            self._mark_remergeable(ips, timestamp, timestamp)

        if all_ips:
            self._merge_smpte_logs(all_ips)

    def _mark_remergeable(self, ips, start_timestamp, end_timestamp):
        """
        Mark Playbacks and LogFilePlayouts such that they will be picked up by the merger and thus merged.
        """
        end_dt = datetime.fromtimestamp(end_timestamp)
        if end_dt.time() == datetime_time.min:
            end_timestamp = time.mktime(datetime.combine(end_dt.date(), datetime_time.max).timetuple())
        mappings_deleted, playbacks_updated, playbacks_deleted = self.core.logging_service.reset_playbacks(ips, start_timestamp - LOOSE_MARGIN, end_timestamp + LOOSE_MARGIN)
        result = {'Unmapped': mappings_deleted,
         'Reset': playbacks_updated,
         'Deleted': playbacks_deleted}
        _log(logging.INFO, 'Marked playbacks for remerge on devices %s [%s - %s]. Result: %s', ', '.join(ips), datetime.fromtimestamp(start_timestamp), datetime.fromtimestamp(end_timestamp), result)
        return result

    def _migration_parse_n_merge(self):
        """
        Special case for migration from pre-2.4.1 logfiles:
        Want to reparse every SMPTE log then merge with the migrated TMS/Live PLayback Logs into Playbacks
        There could be lots of logs to reparse, so this fn only does a handful at a time, with
        the expectation that it will be called at the end of every collection run so eventually all will be migrated
        
        :returns: None
        """
        newest_migrated_log = playback_db.Session.query(playback_db.LogFile.date).filter(and_(playback_db.LogFile.pulled == True, playback_db.LogFile.parse_attempted == False)).order_by(playback_db.LogFile.date.desc()).first()
        if not newest_migrated_log:
            return
        newest_migrated_log_date = newest_migrated_log.date
        migrate_end = time.mktime(newest_migrated_log_date.timetuple())
        migrate_start = time.mktime((newest_migrated_log_date - timedelta(days=self.MIGRATION_CHUNK_SIZE)).timetuple())
        if not cfg.core_log_collection_only():
            self.migration_metadata_fill()
        _log(logging.INFO, 'Migrating (parse-n-merge) old logfiles for the %d days up to %s', self.MIGRATION_CHUNK_SIZE, newest_migrated_log_date.strftime('%Y-%m-%d'))
        self.reparse_smpte_logs(start_timestamp=migrate_start, end_timestamp=migrate_end)
        _log(logging.INFO, 'Extra log migration work complete')

    def migration_metadata_fill(self):
        """
        Update playback metadata for the last 30 days of newly-migrated live logs.
        This improves performance of the schedule divergence piece, and is useful for the playback report UI
        """
        unmeta_playbacks = playback_db.Session.query(playback_db.Playback).filter(playback_db.Playback.meta == None, playback_db.Playback.start > time.mktime((datetime.now() - timedelta(days=self.MIGRATION_METADATA_BACKFILL)).timetuple())).all()
        _log(logging.INFO, 'Attempting to backfill metadata for %d metaless recent playbacks migrated from live logs', len(unmeta_playbacks))
        filled = 0
        for playback in unmeta_playbacks:
            cpl_metadata = self._get_cpl_metadata(playback.cpl_uuid)
            playback.content_kind = cpl_metadata.get('content_kind')
            if cpl_metadata:
                playback.meta = json.dumps(cpl_metadata)
                filled += 1

        playback_db.Session.commit()
        _log(logging.INFO, 'Backfilled metadata for %d metaless playbacks', filled)
        return

    def _get_db_smpte_logs(self, device_ips, start_timestamp, end_timestamp):
        start_datetime = self._datetime_from_timestamp(start_timestamp, 1)
        db_logs = playback_db.Session.query(playback_db.LogFile).filter(playback_db.LogFile.date >= start_datetime.date())
        if end_timestamp:
            db_logs = db_logs.filter(playback_db.LogFile.date <= datetime.fromtimestamp(end_timestamp).date())
        if device_ips:
            db_logs = db_logs.filter(playback_db.LogFile.device_ip_address.in_(device_ips))
        return db_logs

    def _datetime_from_timestamp(self, timestamp, default_offset_days = 1):
        if timestamp is not None:
            return datetime.fromtimestamp(timestamp)
        else:
            return datetime.now() - timedelta(days=default_offset_days)

    @playback_db.close_session
    def recollect_smpte_logs(self, device_ips = [], start_timestamp = None, end_timestamp = None):
        """
        Mark SMPTE Log Files for re-collection
        """
        existing_logs = self._get_db_smpte_logs(device_ips, start_timestamp, end_timestamp)
        device_ids = self.core.get_devices(required_api=base_Logging.Logging)[0]
        devices = {}
        for did in device_ids:
            device = self.core.devices[did]
            if not self.smpte_collector.can_create_placeholders(device):
                continue
            device_ip = device.device_configuration['ip']
            if not device_ips or device_ip in device_ips:
                devices[device_ip] = self.core.devices[did]

        dates_to_recollect = dict(((ip, set()) for ip in devices.iterkeys()))
        for log in existing_logs:
            if log.device_ip_address not in dates_to_recollect:
                continue
            dates_to_recollect[log.device_ip_address].add(log.date)
            log.repull_marked = True
            log.last_modified = int_timestamp_default()
            playback_db.Session.add(log)

        dates = set()
        log_dt = self._datetime_from_timestamp(start_timestamp, 1)
        while log_dt <= self._datetime_from_timestamp(end_timestamp, 1):
            dates.add(log_dt.date())
            log_dt += timedelta(days=1)

        new_placeholders = []
        dates_to_newcollect = dict(((ip, set()) for ip in devices.iterkeys()))
        for ip, device in devices.iteritems():
            dates_to_newcollect[ip] = dates - dates_to_recollect[ip]
            for date in dates_to_newcollect[ip]:
                new_placeholders.extend(self.smpte_collector.create_placeholder(date, device))

        playback_db.Session.add_all(new_placeholders)
        playback_db.Session.commit()
        if new_placeholders:
            self.core.logging_service.log_file_update()
        return {'repull': dates_to_recollect,
         'newpull': dates_to_newcollect}

    @playback_db.close_session
    def recollect_smpte_logs_by_uuid(self, uuids = []):
        """
        Mark SMPTE Logs for Recollection by UUID.
        """
        non_existant_uuids = set()
        for uuid_chunk in helper_methods.sqlite_chunk(uuids):
            db_uuids = [ lf.uuid for lf in playback_db.Session.query(playback_db.LogFile.uuid).filter(playback_db.LogFile.uuid.in_(uuid_chunk)) ]
            non_existant_uuids |= set(uuid_chunk) - set(db_uuids)
            playback_db.Session.query(playback_db.LogFile).filter(playback_db.LogFile.uuid.in_(db_uuids)).update({'repull_marked': True,
             'last_modified': int_timestamp_default()}, False)
            playback_db.Session.commit()

        return {'non_existant_uuids': list(non_existant_uuids)}

    def collect_audit_logs(self, user, ip, msg, tags = [], meta = {}):
        """
        Queue Audit log entries for flushing
        """
        self.audit_log_queue.put({'ip': ip,
         'user': user,
         'msg': msg,
         'tags': tags,
         'meta': meta,
         'created': time.time()})

    def force_flush_audit_logs(self):
        """Handy for debugging"""
        self.audit_log_flush_checker.last_flush = datetime.now() - timedelta(days=1)
        self.audit_log_queue.put({})

    def flush_audit_logs(self):
        """
        Flush Audit logs to audit db
        """
        self.audit_log_flush_checker.batch_size = len(self.core.devices) * 10 or 50
        while not self._shutting_down():
            log_entry = self.audit_log_queue.get(True)
            if log_entry and not self._is_shutdown_event(log_entry):
                self.audit_logs.append(log_entry)
            if self.audit_log_flush_checker.should_flush(len(self.audit_logs), self.audit_log_queue.qsize()):
                self._flush_audit_logs()
            self.audit_log_queue.task_done()

        self._flush_audit_logs()

    @audit_db.close_session
    def _flush_audit_logs(self):
        _log(logging.INFO, 'Flushing %d audit logs', len(self.audit_logs))
        audit_logs = copy.copy(self.audit_logs)
        self.audit_logs = []
        for log in audit_logs:
            entry = audit_db.Log(created=log['created'])
            entry.ip = log['ip']
            entry.user = 'system' if entry.ip == '127.0.0.1' and not log['user'] else log['user']
            entry.message = log['msg']
            if len(log['meta']) > 0:
                msg, meta = audit_db.sub_meta(log['msg'], log['meta'])
                entry.meta = json.dumps(meta)
                entry.message = msg
            entry.tags = log['tags']
            audit_db.Session.merge(entry)

        audit_db.Session.commit()

    def collect_live_logs(self, log_entry):
        """
        Queue log entries for flushing
        """
        if not self.enabled:
            return
        self.live_log_queue.put(log_entry)

    def force_flush_live_logs(self):
        """Handy for debugging"""
        self.live_log_flush_checker.last_flush = datetime.now() - timedelta(days=1)
        self.live_log_queue.put({})

    def flush_live_logs(self):
        """
        Flush Live logs to db
        """
        self.live_log_flush_checker.batch_size = len(self.core.devices) * 4 or 10
        while not self._shutting_down():
            log_entry = self.live_log_queue.get(True)
            _log(logging.DEBUG, 'New liveLog arrived, %d awaiting flush', len(self.live_logs))
            valid, reason = self._validate_live_log(log_entry)
            if valid:
                with self.livelog_lock:
                    self.live_logs.append(log_entry)
            elif log_entry.get('cpl_uuid') != NULL_UUID:
                _log(logging.WARN, 'Invalid live log (%s): %s', reason, log_entry)
            if self.live_log_flush_checker.should_flush(len(self.live_logs), self.live_log_queue.qsize(), False):
                if self.log_lock.acquire(False):
                    try:
                        self._flush_live_logs()
                        self._parse_live_logs()
                        self.live_log_flush_checker.update_last_flushed()
                    except Exception:
                        _log(logging.ERROR, 'Error flushparsing live logs', exc_info=True)
                    finally:
                        self.log_lock.release()

                else:
                    _log(logging.WARN, 'Could not acquire lock for livelog flushparsing')
            self.live_log_queue.task_done()

        self._dump_live_logs()

    @playback_db.close_session
    def _flush_live_logs(self):
        """
        Run through our log list, remove duplicates and insert/update the LiveLog table with the info.
        """
        _log(logging.INFO, 'Flushing %d live logs', len(self.live_logs))
        with self.livelog_lock:
            live_logs = copy.copy(self.live_logs)
            self.live_logs = []
        live_logs = self._find_and_merge_live_log_duplicates_in_batch(live_logs)
        _log(logging.DEBUG, '%d remain after batch merge', len(live_logs))
        live_logs = self._find_and_merge_live_log_duplicates_in_database(live_logs)
        inserts = []
        for log_entry in live_logs:
            try:
                log_entry['meta'] = {}
                log_entry = self._update_live_log_metadata(log_entry)
                if 'duration_in_seconds' in log_entry['meta'] and log_entry['end'] - log_entry['start'] > log_entry['meta']['duration_in_seconds'] * 1.5:
                    log_entry['end'] = log_entry['start'] + log_entry['meta']['duration_in_seconds']
                log_entry['state_changes'] = json.dumps(self._validate_state_changes(log_entry['state_changes']))
                log_entry['meta'] = json.dumps(log_entry['meta'])
                _log(logging.DEBUG, 'Inserting live log %s', log_entry)
                new_db_live_log = playback_db.LiveLog()
                for key, value in log_entry.iteritems():
                    setattr(new_db_live_log, str(key), value)

                inserts.append(new_db_live_log)
            except Exception:
                _log(logging.ERROR, 'Problem inserting live log %s', log_entry, exc_info=True)

        if inserts:
            playback_db.Session.add_all(inserts)
            playback_db.Session.commit()
        _log(logging.DEBUG, 'LiveLog flush complete!')

    def _find_and_merge_live_log_duplicates_in_database(self, live_logs):
        """
        Find merge candidates in the database that have been modified within now and the LIVELOG_MERGE_PERIOD
        If merge candidates found, merge with the appropriate JSON log and delete from the database.
        Newer JSON log will take it's place when it get's flushed.
        """
        previous_logs = playback_db.Session.query(playback_db.LiveLog).filter(int(time.time()) - playback_db.LiveLog.last_modified < self.LIVELOG_MERGE_PERIOD)
        deleted = 0
        for live_log in live_logs:
            merge_candidates = previous_logs.filter(and_(playback_db.LiveLog.cpl_uuid == live_log['cpl_uuid'], playback_db.LiveLog.device_ip_address == live_log['device_ip_address'])).all()
            for candidate in merge_candidates:
                json_candidate = candidate.to_dict()
                if self._mergeable_live_logs(live_log, json_candidate):
                    live_log = self._merge_live_logs(json_candidate, live_log)
                    playback_db.Session.query(playback_db.Playback).filter_by(live_log_uuid=candidate.uuid).update({'deleted': True,
                     'last_modified': int_timestamp_default()}, False)
                    playback_db.Session.delete(candidate)
                    deleted += 1

        self.playbacks_deleted = deleted > 0
        _log(logging.DEBUG, '%d db live_logs deleted during db merge (And associated playbacks marked deleted)', deleted)
        playback_db.Session.commit()
        return live_logs

    def _find_and_merge_live_log_duplicates_in_batch(self, live_logs):
        """
        Traverse a list of live logs and merge together what we consider mergeable, return set of merged logs
        """
        final = copy.copy(live_logs)
        merged = []
        outer_index = 0
        for current_log in live_logs:
            inner_index = 0
            for other_log in live_logs:
                if self._mergeable_live_logs(current_log, other_log) and inner_index not in merged and outer_index not in merged:
                    if inner_index != outer_index:
                        final[outer_index] = self._merge_live_logs(current_log, other_log)
                        final[inner_index] = None
                        merged.append(inner_index)
                inner_index += 1

            outer_index += 1

        return [ log for log in final if log ]

    def _mergeable_live_logs(self, log_a, log_b):
        """
        Determine if two logs are mergeable, based on their CPL, screen identifier and start timestamp.
        Start timestamp mergability margin will be the average of the duration in seconds of the two logs, or
        the default minimum margin
        """
        duration = 0
        meta_a = log_a.get('meta', {})
        meta_b = log_b.get('meta', {})
        duration_a = meta_a.get('duration_in_seconds') if type(meta_a) is dict else None
        duration_b = meta_b.get('duration_in_seconds') if type(meta_b) is dict else None
        if type(duration_a) is int and type(duration_b) is int:
            duration = (duration_a + duration_b) / 2
        elif type(duration_a) is int:
            duration = duration_a
        elif type(duration_b) is int:
            duration = duration_b
        merge_margin = self.DEFAULT_LIVELOG_MERGE_MARGIN if self.DEFAULT_LIVELOG_MERGE_MARGIN > duration else duration
        if log_a.get('uuid', 'a') == log_b.get('uuid', 'b'):
            return False
        elif log_a['cpl_uuid'] != log_b['cpl_uuid']:
            return False
        elif log_a.get('device_ip_address', 'a') != log_b.get('device_ip_address', 'b'):
            return False
        elif abs(log_a['start'] - log_b['start']) > merge_margin:
            return False
        else:
            return True

    def _update_live_log_metadata(self, log_entry):
        """
        Insert playback metadata into live log entry
        """
        log_entry['meta']['tms_version'] = self.core.version_string
        cpl_metadata = self._get_cpl_metadata(log_entry['cpl_uuid'])
        log_entry['content_kind'] = cpl_metadata.get('content_kind')
        log_entry['meta'].update(cpl_metadata)
        spl_metadata = self._get_spl_metadata(log_entry['device_uuid'], log_entry['spl_uuid']) if 'spl_uuid' in log_entry else {}
        log_entry['feature_cpl_uuid'] = spl_metadata.get('feature_cpl_uuid')
        log_entry['meta'].update(spl_metadata)
        pack_metadata = self._get_pack_metadata(log_entry['spl_uuid'], log_entry['cpl_uuid']) if 'spl_uuid' in log_entry else {}
        log_entry['meta'].update(pack_metadata)
        del log_entry['device_uuid']
        return log_entry

    def _get_cpl_metadata(self, cpl_uuid):
        """
        Retrieve CPL metadata based on CPL id
        """
        metadata = {}
        if cpl_uuid not in self.core.contents:
            return metadata
        else:
            cpl = self.core.contents[cpl_uuid]
            for key in ['content_title',
             'content_title_text',
             'duration_in_seconds',
             'content_kind']:
                cpl_metadata = cpl.get(key, None)
                if cpl_metadata:
                    metadata[key] = int(cpl_metadata) if key == 'duration_in_seconds' else cpl_metadata

            if metadata.get('content_kind') == 'feature':
                metadata.update(self._get_pos_metadata(cpl_uuid))
            return metadata

    def _get_pos_metadata(self, cpl_uuid):
        """
        Retrieve POS metadata based on CPL id
        """
        metadata = {}
        if not self.pos_sources:
            self._update_pos_sources()
        db_title = db.Session.query(db.POSItem.feature_title).select_from(db.TitleCplMap).distinct().join(db.ExternalTitleMap, and_(db.ExternalTitleMap.title_uuid == db.TitleCplMap.title_uuid, db.ExternalTitleMap.source.in_(self.pos_sources), db.TitleCplMap.cpl_uuid == cpl_uuid)).join(db.POSItem, db.POSItem.feature_title == db.ExternalTitleMap.external_id).first()
        metadata['pos_feature_title'] = db_title[0] if db_title else None
        return metadata

    def _get_spl_metadata(self, device_uuid, spl_uuid):
        """
        Retrieve SPL metadata based on device and SPL ids
        """
        metadata = {}
        player = self.core.devices.get(device_uuid)
        if player:
            spl = player.playlist_information.get(spl_uuid)
            if spl:
                metadata['spl_name'] = spl['playlist']['title']
                feature = spl.get('feature')
                if not feature:
                    for event in reversed(spl['playlist'].get('events', [])):
                        cpl = self.core.contents.get(event.get('cpl_id'), {})
                        if cpl.get('content_kind') == 'feature':
                            feature = {'uuid': event['cpl_id'],
                             'title': cpl['content_title']}
                            break

                    spl['feature'] = feature
                if feature:
                    metadata['feature_cpl_uuid'] = feature['uuid']
                    metadata['feature_title'] = feature['title']
        return metadata

    def _get_pack_metadata(self, spl_uuid, cpl_uuid):
        """
        Retrieve pack metadata based on spl and cpl ids
        """
        metadata = {}
        schedule = db.Session.query(db.Schedule.templating_issues).filter_by(device_playlist_uuid=spl_uuid).first()
        if schedule and schedule[0]:
            pack_info = json.loads(schedule[0])
            for info in pack_info:
                if info.get('placeholder_type') == 'pack' and cpl_uuid in info.get('inserted_ids', []):
                    metadata['pack_uuid'] = info['uuid']

        return metadata

    def _merge_live_logs(self, log_a, log_b):
        """
        Merge a pair of live logs
        """
        keys = list(set(log_a.keys() + log_b.keys()))
        final_log = {}
        for key in keys:
            if log_b.get(key) is None:
                final_log[key] = log_a[key]
            elif log_a.get(key) is None:
                final_log[key] = log_b[key]
            elif str(key) == 'meta':
                final_log[key] = dict(log_a[key].items() + log_b[key].items())
            elif str(key) == 'state_changes':
                final_log[key] = list(log_a[key] + log_b[key])
            elif str(key) in ('start', 'created'):
                final_log[key] = log_a[key] if log_a[key] < log_b[key] else log_b[key]
            elif str(key) in ('end', 'last_modified'):
                final_log[key] = log_a[key] if log_a[key] > log_b[key] else log_b[key]
            else:
                final_log[key] = log_a.get(key)

        return final_log

    @playback_db.close_session
    def _parse_live_logs(self, allow_merge = True):
        """
        Run through last batch of live logs and parse out records for the Playback table
        """
        _log(logging.DEBUG, 'Parsing live logs into playbacks')
        new_playbacks = []
        device_ips = set()
        start_timestamp = time.time()
        end_timestamp = 0
        if self.playbacks_deleted:
            start_timestamp -= self.LIVELOG_MERGE_PERIOD
            end_timestamp = time.time()
        unparsed_live_logs = playback_db.Session.query(playback_db.LiveLog).filter_by(parsed=False)
        for live_log in unparsed_live_logs:
            new_playbacks.append(self._create_playback_from_live_log(live_log))
            live_log.parsed = True
            device_ips.add(live_log.device_ip_address)
            start_timestamp = live_log.start if start_timestamp > live_log.start else start_timestamp
            end_timestamp = live_log.end if end_timestamp < live_log.end else end_timestamp

        if new_playbacks:
            playback_db.Session.add_all(new_playbacks)
            playback_db.Session.commit()
        _log(logging.INFO, 'Parsed %d live logs', len(new_playbacks))
        if allow_merge:
            if datetime.fromtimestamp(start_timestamp) < datetime.combine(datetime.now().date(), datetime_time.min):
                self.remerge_smpte_logs(device_ips, start_timestamp, end_timestamp, suppress_update=True)
            if new_playbacks or self.playbacks_deleted:
                self.core.logging_service.playback_log_update()
        self.playbacks_deleted = False
        _log(logging.DEBUG, 'LiveLog parse complete!')

    def _create_playback_from_live_log(self, live_log):
        """
        Create a Playback entry from a LoveLog entry
        """
        new_playback = {}
        for attribute in ['start',
         'end',
         'cpl_uuid',
         'screen_identifier',
         'dnqualifier',
         'device_ip_address',
         'serial',
         'feature_cpl_uuid',
         'content_kind',
         'meta']:
            new_playback[attribute] = live_log.__getattribute__(attribute)

        new_playback['complex_identifier'] = cfg.complex_name()
        new_playback['live_log_uuid'] = live_log.uuid
        if datetime.fromtimestamp(live_log.start) > datetime.combine(datetime.now().date(), datetime_time.min):
            new_playback['merge_error_code'] = CODE_START_AND_END_OFF
        if live_log.state_changes:
            new_playback.update(self._analyse_state_changes(live_log))
        return playback_db.Playback(**new_playback)

    def _validate_state_changes(self, state_change_list):
        """
        Validate state changes list for a playback; order by stamp and remove redundant data
        """
        state_change_list = sorted(state_change_list, key=lambda state: state['time'])
        validated_state_changes_list = []
        prev_event = {}
        for event in state_change_list:
            if event['state'] != prev_event.get('state') or event['state'] in ('clip_unload', 'clip_load'):
                validated_state_changes_list.append(event)
            prev_event = event

        return validated_state_changes_list

    def _validate_live_log(self, log_entry):
        """
        Verify that we have everything we need in this log entry and that it makes sense before we save it
        """
        ignore_these = [NULL_UUID, '00000001-0000-0000-0000-000000000000', '00000002-0000-0000-0000-000000000000']
        if not log_entry.get('cpl_uuid'):
            return (False, 'missing cpl_uuid')
        if not log_entry.get('end') or not log_entry.get('start'):
            return (False, 'missing start or end')
        if log_entry['end'] < log_entry['start']:
            return (False, 'end earlier then start')
        if not log_entry.get('device_ip_address'):
            return (False, 'no device IP')
        if log_entry['cpl_uuid'] in ignore_these:
            return (False, 'Bad cpl_uuid')
        state_changes = log_entry.get('state_changes')
        if state_changes and state_changes[0]['time'] < log_entry['start']:
            return (False, 'First state change earlier than log start')
        if state_changes and state_changes[-1]['time'] > log_entry['end']:
            return (False, 'Last state change later than log end')
        return (True, 'Ok')

    def _analyse_state_changes(self, log_entry):
        """
        Calculate total playout time (minus pauses) and verify whether we saw an intermission or not during a clip playback.
        We assume there is a max of 1 intermission per clip playback
        """
        output = {'duration': None,
         'intermission_start': None,
         'intermission_end': None}

        def __is_intermission(stoppage_start, stoppage_end, clip_start, clip_end):
            """
            Validate stoppage; check to see if it looks intermission-y
            """
            CLIP_BUFFER = 10
            MIN_DURATION = 240
            clip_buffer = (clip_end - clip_start) / CLIP_BUFFER
            if stoppage_end - stoppage_start > MIN_DURATION:
                if stoppage_start - clip_start > clip_buffer:
                    if clip_end - stoppage_end > clip_buffer:
                        if stoppage_start < stoppage_end:
                            return True
            return False

        state_changes = json.loads(log_entry.state_changes)
        clip_start = int(log_entry.start)
        clip_end = int(log_entry.end)
        total_stoppage_time = 0
        previous_state = {}
        start_of_stoppage = None
        end_of_stoppage = None
        for state_change in state_changes:
            if state_change['state'] in ('stop', 'pause', 'clip_unload') and previous_state.get('state') == 'play':
                start_of_stoppage = state_change['time']
            elif state_change['state'] in ('play', 'clip_unload') and start_of_stoppage:
                end_of_stoppage = state_change['time']
            elif previous_state.get('state') == 'clip_unload' and state_change['state'] == 'clip_load':
                start_of_stoppage = previous_state['time']
                end_of_stoppage = state_change['time']
            previous_state = state_change
            if start_of_stoppage and end_of_stoppage:
                total_stoppage_time += end_of_stoppage - start_of_stoppage
                if log_entry.content_kind in (None, 'feature'):
                    if __is_intermission(start_of_stoppage, end_of_stoppage, clip_start, clip_end):
                        output['intermission_start'] = start_of_stoppage
                        output['intermission_end'] = end_of_stoppage
                start_of_stoppage = None
                end_of_stoppage = None

        output['duration'] = max(clip_end - clip_start - total_stoppage_time, 0)
        return output

    def _undump_live_logs(self):
        """
        Read dumped live log json
        """
        if os.path.exists(self.live_dump_path):
            try:
                with open(self.live_dump_path, 'r') as dump:
                    dumped_logs = dump.read()
                    if dumped_logs:
                        self.live_logs = json.loads(dumped_logs)
                        _log(logging.DEBUG, 'Undumped %d unflushed livelogs', len(self.live_logs))
            except:
                _log(logging.ERROR, 'Error undumping unflushed livelogs', exc_info=True)
            finally:
                os.remove(self.live_dump_path)

    def _dump_live_logs(self):
        """
        Dump live log json
        """
        _log(logging.DEBUG, 'Dumping %d unflushed livelogs', len(self.live_logs))
        with open(self.live_dump_path, 'w') as dump:
            dump.write(json.dumps(self.live_logs))

    def get_avg_day_size(self):
        all_logs = helper_methods.all_files(self.logging_base_path)
        avg = 100000
        count = len(all_logs)
        if count:
            size = sum(map(os.path.getsize, all_logs))
            avg = size / count
        return avg * len(self.core.screens)

    def clean_up(self):
        logging.info('Auto-cleanup is handled by the LogManager internally')

    def _trigger_clean_up(self):
        try:
            with self.log_lock:
                self._run_clean_up()
        except Exception:
            _log(logging.ERROR, 'Problem running cleanup', exc_info=True)

    def _run_clean_up(self):
        """
        Clean out older LogFiles and associated playbacks based on a configurable amount of storage space allocated by user
        Also ensures that the LogFile table is fully in-sync with the file system -
            any zips lacking a db entry are wiped, as are any db entries with a filepath not on disk
        """
        _log(logging.INFO, 'Running log cleanup')
        limit = int(cfg.core_log_storage_limit()) * 1000000
        db_paths = playback_db.Session.query(playback_db.LogFile.absolute_file_path).filter(not_(playback_db.LogFile.absolute_file_path == None)).order_by(playback_db.LogFile.date)
        db_paths = [ path[0] for path in db_paths ]
        orphans = helper_methods.all_files(self.logging_base_path) - set(db_paths)
        if len(orphans):
            _log(logging.WARN, 'Deleting orphaned log files: %s', orphans)
            map(os.unlink, orphans)
        danglers = set()
        log_files_size = 0
        for path in db_paths:
            if os.path.exists(path):
                log_files_size += os.path.getsize(path)
            else:
                danglers.add(path)

        deleted_count = 0
        for path_chunk in helper_methods.sqlite_chunk(list(danglers)):
            _log(logging.WARN, 'Deleting dangling LogFiles (pulled but not on disk) from the db: %s', danglers)
            deleted_count += playback_db.Session.query(playback_db.LogFile).filter(playback_db.LogFile.absolute_file_path.in_(path_chunk)).delete(False)
            playback_db.Session.commit()

        log_db_size = 0
        total = log_files_size + log_db_size
        if total > limit:
            shave = total - limit * SMPTE_SHAVE_FRACTION
            _log(logging.INFO, 'Cleaning up %d B of logfiles from disk' % shave)
            self._shave_logs(db_paths, shave)
        self._clean_old_playbacks()
        _log(logging.INFO, 'Log cleanup complete. Deleted %d orphan files from log store, and %d danglers from db', len(orphans), len(danglers))
        return

    def _clean_old_playbacks(self):
        MAX_PLAYBACKS_TO_DELETE = 500
        producer_last_sync = self.core.logging_service.producer_newest_playback_datetime
        allow_delete_modifed_before = producer_last_sync - timedelta(days=3)
        allow_delete_modifed_before = allow_delete_modifed_before.replace(hour=5)
        allow_delete_modifed_before_stamp = helper_methods.tstamp(allow_delete_modifed_before)
        allow_delete_end_before = allow_delete_modifed_before - timedelta(days=cfg.core_min_storage_days_playbacks())
        allow_delete_end_before_stamp = helper_methods.tstamp(allow_delete_end_before)
        _log(logging.INFO, 'Deleting playbacks etc. modified before [%s] and older than [%s]', allow_delete_modifed_before, allow_delete_end_before)
        playouts_deleted = playback_db.Session.query(playback_db.LogFilePlayout).filter(playback_db.LogFilePlayout.last_modified < allow_delete_modifed_before_stamp, or_(playback_db.LogFilePlayout.start_time < allow_delete_end_before_stamp, playback_db.LogFilePlayout.end_time < allow_delete_end_before_stamp)).delete(False)
        _log(logging.INFO, 'Deleted [%s] expired SMPTE playouts from the db', playouts_deleted)
        playbacks_deletable = playback_db.Session.query(playback_db.Playback.uuid).filter(playback_db.Playback.last_modified < allow_delete_modifed_before_stamp, or_(playback_db.Playback.deleted == True, playback_db.Playback.end < allow_delete_end_before_stamp, playback_db.Playback.start < allow_delete_end_before_stamp)).order_by(playback_db.Playback.deleted.desc(), playback_db.Playback.start)
        playbacks_deletable_count = playbacks_deletable.count()
        playbacks_deleted = playback_db.Session.query(playback_db.Playback).filter(playback_db.Playback.uuid.in_(playbacks_deletable.limit(MAX_PLAYBACKS_TO_DELETE))).delete(False)
        _log(logging.INFO, 'Deleted [%s] of [%s] redundant/expired playbacks from the db', playbacks_deleted, playbacks_deletable_count)
        livelogs_deletable = playback_db.Session.query(playback_db.LiveLog.uuid).filter(playback_db.LiveLog.last_modified < allow_delete_modifed_before_stamp, playback_db.LiveLog.start < allow_delete_end_before_stamp).order_by(playback_db.LiveLog.start)
        livelogs_deletable_count = livelogs_deletable.count()
        livelogs_deleted = playback_db.Session.query(playback_db.LiveLog).filter(playback_db.LiveLog.uuid.in_(livelogs_deletable.limit(MAX_PLAYBACKS_TO_DELETE))).delete(False)
        _log(logging.INFO, 'Deleted [%s] of [%s] expired live logs from the db', livelogs_deleted, livelogs_deletable_count)
        playback_db.Session.commit()

    def _shave_logs(self, paths, shave):
        to_clean = set()
        total = 0
        for path in paths:
            if os.path.exists(path):
                if total >= shave:
                    break
                total += os.path.getsize(path)
                to_clean.add(path)

        for path_chunk in helper_methods.sqlite_chunk(list(to_clean)):
            deleted_count = playback_db.Session.query(playback_db.LogFile).filter(playback_db.LogFile.absolute_file_path.in_(path_chunk)).delete('fetch')
            playback_db.Session.commit()
            _log(logging.INFO, 'Deleted %d old LogFiles from the db' % deleted_count)

        map(os.unlink, to_clean)

    def get_schedule_divergence_data(self):
        with self.schedule_map_lock:
            return self.schedule_divergence_data

    def get_schedule_divergence(self):
        with self.log_lock:
            with self.schedule_map_lock:
                try:
                    self._get_schedule_divergence()
                except Exception:
                    logging.error('Problem computing schedule divergence', exc_info=True)

    def _get_schedule_divergence(self):
        """
        Calculates divergence between POS and Playbacks
        
        Gets all POS sessions in the database older than today and all playbacks for the
        period those POS sessions cover (using AUTO_CLEANUP_POS_VALIDITY), then attempts to map
        playback logs to pos sessions by comparing screen_id, start time and end time (with a configurable
        leeway).
        The map is saved to the schedule_divergence_data variable in self,
        which is wiped every time this runs to avoid duplicate records.
        TODO: compute UUIDs to make this more efficient (would help Producer, too)
        """
        MIN_FEATURE_DURATION = 1800
        pos_tuple = namedtuple('pos', 'uuid start end source feature_title')
        leeway = cfg.core_schedule_mapper_leeway() * 60
        counts = {'matched': 0,
         'playback_only': 0,
         'pos_only': 0}
        matched_stats = {'start': 0,
         'end': 0,
         'title': 0}

        def _is_match(playback_time, pos_time):
            return playback_time and abs(playback_time - pos_time) < leeway

        def _add_map_item(playback, pos, screen_id):
            playback_cpl_pos_title = start_match = end_match = title_match = None
            if playback:
                display_date_source = playback.start if playback.start else playback.end - 7200
                playback_cpl_pos_title = json.loads(playback.meta)['pos_feature_title'] if 'pos_feature_title' in (playback.meta or '') else self._get_pos_metadata(playback.cpl_uuid)['pos_feature_title']
            if pos:
                display_date_source = pos.start
            if playback and pos:
                start_match = _is_match(playback.start, pos.start)
                end_match = _is_match(playback.end, pos.end)
                title_match = playback_cpl_pos_title == pos.feature_title
            mapping_info = {'display_date': datetime.fromtimestamp(display_date_source).strftime('%Y-%m-%d'),
             'screen_identifier': screen_id,
             'playback_uuid': playback.uuid if playback else None,
             'playback_start_timestamp': playback.start if playback else None,
             'playback_end_timestamp': playback.end if playback else None,
             'playback_cpl_uuid': playback.cpl_uuid if playback else None,
             'playback_cpl_pos_title': playback_cpl_pos_title,
             'pos_uuid': pos.uuid if pos else None,
             'pos_feature_start_timestamp': pos.start if pos else None,
             'pos_end_timestamp': pos.end if pos else None,
             'pos_feature_title': pos.feature_title if pos else None,
             'pos_source': pos.source if pos else None,
             'start_match': start_match,
             'end_match': end_match,
             'title_match': title_match}
            self.schedule_divergence_data['schedule_map'].append(mapping_info)
            self.schedule_divergence_data['hashes'].append(make_hash(mapping_info))
            matched_stats['title'] += bool(title_match)
            matched_stats['start'] += bool(start_match)
            matched_stats['end'] += bool(end_match)
            return

        def _map_by_screen(screen):
            screen_id = screen.tms_id
            all_pos_db = db.Session.query(db.POSItem).filter(between(db.POSItem.start, oldest_dt, today_midnight), db.POSItem.screen_identifier == screen.pos_id).options(joinedload('device')).order_by(db.POSItem.start)
            all_pos = [ pos_tuple(pos.uuid, time.mktime(pos.feature_start().timetuple()), time.mktime(pos.end.timetuple()), pos.device_type(), pos.feature_title) for pos in all_pos_db ]
            feature_playbacks = playback_db.Session.query(playback_db.Playback.uuid, playback_db.Playback.start, playback_db.Playback.end, playback_db.Playback.cpl_uuid, playback_db.Playback.meta).filter(playback_db.Playback.screen_identifier == screen.tms_id, or_(playback_db.Playback.start > oldest_timestamp, playback_db.Playback.end > oldest_timestamp), playback_db.Playback.content_kind == 'feature', or_(playback_db.Playback.duration == 0, playback_db.Playback.duration > MIN_FEATURE_DURATION)).order_by(playback_db.Playback.start)
            for playback in feature_playbacks:
                matched_id = None
                for pos in all_pos:
                    if _is_match(playback.start, pos.start) or _is_match(playback.end, pos.end):
                        matched_id = pos.uuid
                        _add_map_item(playback, pos, screen_id)
                        counts['matched'] += 1
                        break

                all_pos[:] = matched_id and [ pos for pos in all_pos if pos.uuid is not matched_id ]
                continue
                _add_map_item(playback, None, screen_id)
                counts['playback_only'] += 1

            for lonely_pos in all_pos:
                _add_map_item(None, lonely_pos, screen_id)

            counts['pos_only'] += len(all_pos)
            return

        _log(logging.INFO, 'Starting POS/playback mapper')
        self._update_pos_sources()
        today_midnight = datetime.combine(datetime.now().date(), datetime.min.time())
        oldest_dt = today_midnight - timedelta(days=AUTO_CLEANUP_POS_VALIDITY)
        oldest_timestamp = time.mktime(oldest_dt.timetuple())
        self.schedule_divergence_data = {'schedule_map': [],
         'from_timestamp': oldest_timestamp,
         'hashes': []}
        if not cfg.core_log_collection_only():
            screens = db.Session.query(db.ExternalDeviceMap.external_id.label('pos_id'), db.Screen.identifier.label('tms_id')).select_from(db.ExternalDeviceMap).join(db.Device, db.ExternalDeviceMap.device_uuid == db.Device.uuid).join(db.Screen, db.Device.screen_uuid == db.Screen.uuid)
            for screen in screens:
                _map_by_screen(screen)

        _log(logging.INFO, 'Finished POS/playback mapper: %s. Matches: %s' % (counts, matched_stats))
        cherrypy.engine.publish('ccpush', 'schedule_map_information', self.schedule_divergence_data)

    def _update_pos_sources(self):
        self.pos_sources = [ device.device_configuration['type'] for device in self.core.devices.itervalues() if isinstance(device, base_POS) ]
# okay decompyling ./core/tasks/log_manager.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:07 CST
