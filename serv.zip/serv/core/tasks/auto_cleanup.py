# 2017.08.13 21:51:00 CST
# Embedded file name: build\bdist.win32\egg\serv\core\tasks\auto_cleanup.py
from datetime import datetime, timedelta, date
import copy
import logging
import os
import shutil
import time
from sqlalchemy.sql.expression import and_
from serv.configuration import cfg
from serv.lib.utilities import helper_methods
from serv.core.devices.base.playlist import Playlist
from serv.configuration.constants import AUTO_CLEANUP_KDM_VALIDITY, AUTO_CLEANUP_PACK_VALIDITY, AUTO_CLEANUP_POS_VALIDITY, AUTO_CLEANUP_SCHEDULE_VALIDITY, AUTO_CLEANUP_TRANSFER_VALIDITY, AUTO_CLEANUP_AUDIT_VALIDITY, AUTO_CLEANUP_WATCHFOLDER_VALIDITY, AUTO_CLEANUP_TITLE_VALIDITY
from serv.storage.database.primary import database as db
from serv.storage.database.audit import database as audit_db

class Auto_Cleanup:

    def __init__(self, core):
        self.core = core
        self.cleaning = False

    def clean(self):
        self.cleaning = True
        try:
            self.core.schedule_lock.acquire()
            logging.info('Running AutoCleanup')
            self.NOW = datetime.now()
            try:
                kdms = self.remove_expired_kdms()
                logging.info('KDMS Deleted: [%s]', kdms)
            except Exception:
                logging.error('KDM cleanup problem', exc_info=True)

            try:
                packs = self.remove_expired_packs()
                logging.info('Packs Deleted: [%s]', packs)
            except Exception:
                logging.error('Pack cleanup problem', exc_info=True)

            try:
                schedules = self.remove_expired_schedules()
                logging.info('Schedules Deleted: [%s]', schedules)
            except Exception:
                logging.error('Schedule cleanup problem', exc_info=True)

            try:
                pos = self.remove_expired_pos_sessions()
                logging.info('POS Sessions Deleted: [%s]', pos)
            except Exception:
                logging.error('POS cleanup problem', exc_info=True)

            try:
                titles = self.remove_expired_titles()
                logging.info('Titles Deleted: [%s]', titles)
            except Exception:
                logging.error('Title cleanup problem', exc_info=True)

            try:
                self.remove_expired_transfers()
            except Exception:
                logging.error('Transfer cleanup problem', exc_info=True)

            try:
                old_auto_generated_playlists = self.remove_old_auto_generated_playlists()
                logging.info('Old auto generated playlists deleted: [%s]', old_auto_generated_playlists)
            except Exception:
                logging.error('Playlist cleanup problem', exc_info=True)

            try:
                old_lms_playlists = self.remove_old_lms_playlists()
                logging.info('Old lms playlists deleted: [%s]', old_lms_playlists)
            except Exception:
                logging.error('Playlist cleanup problem', exc_info=True)

            try:
                content, folders = self.remove_old_watchfolder_content()
                logging.info('Watchfolder Cleaned: %s CPLS/KDMS Deleted, %s Empty Folders Deleted ', content, folders)
            except Exception:
                logging.error('Content cleanup problem', exc_info=True)

            try:
                self.remove_expired_composite_CPLs()
            except Exception:
                logging.error('Composite CPL cleanup problem', exc_info=True)

            try:
                self.remove_old_audit_logs()
            except Exception:
                logging.error('Audit log cleanup problem', exc_info=True)

            logging.info('AutoCleanup Complete')
        except:
            logging.error('Exception while running AutoCleanup', exc_info=True)
        finally:
            self.cleaning = False
            self.core.schedule_lock.release()
            db.Session.remove()

        logging.info('Starting Log Manager Cleanup')
        self.core.log_manager.clean_up()

    def remove_old_audit_logs(self):
        """
        Shave off a batch of the oldest logs depending on the AUTO_CLEANUP_AUDIT_VALIDITY setting
        """
        ordered = audit_db.Session.query(audit_db.Log).order_by(audit_db.Log.created.desc())
        if ordered.count() > AUTO_CLEANUP_AUDIT_VALIDITY:
            audit_db.Session.query(audit_db.Log).filter(audit_db.Log.created <= ordered.all()[AUTO_CLEANUP_AUDIT_VALIDITY].created).delete(False)
            audit_db.Session.commit()
            audit_db.Session.remove()

    def remove_expired_packs(self):
        pack_count = 0
        if cfg.core_auto_cleanup_packs():
            expiration_date = (self.NOW - timedelta(days=AUTO_CLEANUP_PACK_VALIDITY)).date()
            pack_uuids = []
            for result in db.Session.query(db.Pack.uuid).filter(and_(db.Pack.playback_date_range_end != None, db.Pack.playback_date_range_end < expiration_date)):
                uuid = helper_methods.copy_by_value(result[0])
                logging.debug('Auto Deleting Expired Pack with UUID [%s]' % uuid)
                pack_uuids.append(uuid)
                pack_count = pack_count + 1

            if pack_uuids:
                self.core.pack_service.delete(pack_uuids)
        return pack_count

    def remove_expired_kdms(self):
        kdm_count = 0
        if cfg.core_auto_cleanup_kdms():
            if self.core.devices.has_key(self.core.get_lms_id()):
                lms = self.core.devices[self.core.get_lms_id()]
                for kdm_uuid in lms.key_information.keys():
                    if not kdm_uuid == 'last_updated' and lms.key_information[kdm_uuid]['not_valid_after'] < time.mktime((self.NOW - timedelta(days=AUTO_CLEANUP_KDM_VALIDITY)).timetuple()):
                        self.core._action(lms._delete_key_helper, kdm_uuid)
                        logging.debug('Auto Deleting Expired KDM with UUID [%s]' % kdm_uuid)
                        kdm_count = kdm_count + 1

        return kdm_count

    def remove_expired_schedules(self):
        all_schedule_uuids = []
        if cfg.core_auto_cleanup_schedules():
            session = db.Session()
            invalid_timestamp = time.mktime((self.NOW - timedelta(days=AUTO_CLEANUP_POS_VALIDITY * 2)).timetuple())
            session.query(db.Schedule).filter(db.Schedule.end_timestamp < invalid_timestamp).delete('fetch')
            db.Session.commit()
            expiration_timestamp = time.mktime((self.NOW - timedelta(days=AUTO_CLEANUP_SCHEDULE_VALIDITY)).timetuple())
            pos_expiration_timestamp = time.mktime((self.NOW - timedelta(days=AUTO_CLEANUP_POS_VALIDITY)).timetuple())
            expired_schedules = session.query(db.Schedule).filter(db.Schedule.end_timestamp < expiration_timestamp)
            for schedule in expired_schedules.all():
                if schedule.pos_id and schedule.end_timestamp > pos_expiration_timestamp:
                    continue
                uuid = str(helper_methods.copy_by_value(schedule.uuid))
                logging.debug('Auto Deleting Expired Schedule with UUID [%s]' % uuid)
                all_schedule_uuids.append(uuid)

            if all_schedule_uuids:
                for uuid_chunk in helper_methods.sqlite_chunk(all_schedule_uuids):
                    self.core.scheduling_service.delete(uuid_chunk, remove_database_schedule=False)

                for uuid_chunk in helper_methods.sqlite_chunk(all_schedule_uuids):
                    session.query(db.Schedule).filter(db.Schedule.uuid.in_(uuid_chunk)).delete('fetch')
                    session.commit()

        return len(all_schedule_uuids)

    def remove_expired_pos_sessions(self):
        session_count = 0
        if cfg.core_auto_cleanup_pos():
            expiration_date = self.NOW - timedelta(days=AUTO_CLEANUP_POS_VALIDITY)
            expired_uuids = helper_methods.copy_by_value(db.Session.query(db.POSItem.uuid).filter(db.POSItem.end < expiration_date).all())
            to_delete = []
            for uuid in expired_uuids:
                logging.debug('Auto Deleting Expired POS Session with UUID [%s]' % uuid[0])
                to_delete.append(uuid[0])
                session_count = session_count + 1

            schedule_uuids = self.core.pos_service.remove_pos_items(to_delete)
            self.core.pos_service.clean_up_schedules(schedule_uuids)
        return session_count

    def remove_expired_transfers(self):
        if cfg.core_auto_cleanup_transfers():
            ordered = db.Session.query(db.Transfer).order_by(db.Transfer.created.desc())
            if ordered.count() > AUTO_CLEANUP_TRANSFER_VALIDITY:
                db.Session.query(db.Transfer).filter(db.Transfer.created <= ordered.all()[AUTO_CLEANUP_TRANSFER_VALIDITY].created).delete(False)
                db.Session.commit()
                db.Session.remove()

    def remove_expired_titles(self):
        title_count = 0
        if cfg.core_auto_cleanup_titles():
            expiration_timestamp = time.mktime((self.NOW - timedelta(days=AUTO_CLEANUP_TITLE_VALIDITY)).timetuple())
            expired_title_uuids = [ title[0] for title in db.Session.query(db.Title.uuid).filter(db.Title.last_modified < expiration_timestamp).all() ]
            if expired_title_uuids:
                pack_mapped_title_uuids = set([ title[0] for title in db.Session.query(db.ExternalTitleMap.title_uuid).join(db.Pack).filter(and_(db.Pack.external_title_map_uuid == db.ExternalTitleMap.uuid, db.ExternalTitleMap.title_uuid != None)).all() ])
                titles_to_potentially_delete = set(expired_title_uuids).difference(pack_mapped_title_uuids)
                if titles_to_potentially_delete:
                    pos_mapped_title_uuids = set([ title[0] for title in db.Session.query(db.ExternalTitleMap.title_uuid).join(db.POSItem).filter(and_(db.POSItem.external_title_map_uuid == db.ExternalTitleMap.uuid, db.ExternalTitleMap.title_uuid != None)).all() ])
                    titles_to_potentially_delete = titles_to_potentially_delete.difference(pos_mapped_title_uuids)
                    if titles_to_potentially_delete:
                        for chunk in helper_methods.sqlite_chunk(list(titles_to_potentially_delete)):
                            title_cpl_maps = db.Session.query(db.TitleCplMap.title_uuid, db.TitleCplMap.cpl_uuid).filter(db.TitleCplMap.title_uuid.in_(chunk)).all()
                            titles_tied_to_cpls_or_playlists = set()
                            for map in title_cpl_maps:
                                on_any_device = self.core.contents.on_any_device(map.cpl_uuid, key_only=False)
                                in_playlist = self.core.contents.get_playlists(map.cpl_uuid)
                                if on_any_device or in_playlist:
                                    titles_tied_to_cpls_or_playlists.add(map.title_uuid)

                            titles_to_delete = set(chunk).difference(titles_tied_to_cpls_or_playlists)
                            self.core.title_service.delete(list(titles_to_delete))
                            title_count = len(titles_to_delete) + title_count
                            for title in titles_to_delete:
                                logging.debug('Auto Deleting Title with UUID [%s]' % title)

        return title_count

    def remove_old_auto_generated_playlists(self):
        device_ids = []
        existing_playlist_uuids = []
        device_ids, device_errors = self.core.get_devices(device_ids, Playlist)
        for device_id in device_ids:
            existing_playlist_uuids = existing_playlist_uuids + self.core.devices[device_id].playlist_information.keys()

        deleted_playlist_ids = []
        validity_days = cfg.core_auto_cleanup_playlists_expiry_days()
        if cfg.core_auto_cleanup_playlists():
            logging.info('Removing auto generated playlists older than %s days' % str(validity_days))
        playlists = db.Session.query(db.GeneratedPlaylist).all()
        spl_uuids = [ playlist.uuid for playlist in playlists ]
        schedules = self.core.scheduling_service.get_playlist_schedules(playlist_uuids=spl_uuids, start_time=datetime(1991, 7, 4).strftime('%Y-%m-%d %H:%M'))['data']
        expiry_timestamp = time.mktime((datetime.now() - timedelta(days=validity_days)).timetuple())
        right_now = time.time()
        dangling_schedule_uuids = []
        for playlist in playlists:
            if playlist.start_timestamp < expiry_timestamp:
                if playlist.uuid in schedules:
                    if all((sched['end_timestamp'] < right_now for sched in schedules[playlist.uuid])):
                        deleted_playlist_ids.append(playlist.uuid)
                        dangling_schedule_uuids.extend((sched['uuid'] for sched in schedules[playlist.uuid]))
                else:
                    deleted_playlist_ids.append(playlist.uuid)
            if playlist.uuid not in existing_playlist_uuids:
                logging.debug('Removing orphaned generated_playlist reference [%s]', playlist.uuid)
                db.Session.delete(playlist)

        if cfg.core_auto_cleanup_playlists():
            if dangling_schedule_uuids:
                for uuid_chunk in helper_methods.sqlite_chunk(dangling_schedule_uuids):
                    logging.info('Deleting [%s] schedules tied to expired generated SPLs', len(uuid_chunk))
                    self.core.scheduling_service.delete(uuid_chunk)

            for id_chunk in helper_methods.sqlite_chunk(deleted_playlist_ids):
                logging.debug('Deleting playlists from Complex: {ids}'.format(ids=id_chunk))
                self.core.playlist_service.delete(id_chunk)

        db.Session.commit()
        db.Session.query(db.GeneratedPlaylist).filter(db.GeneratedPlaylist.start_timestamp < expiry_timestamp).delete(False)
        db.Session.commit()
        if cfg.core_auto_cleanup_playlists():
            return len(deleted_playlist_ids)
        return 0

    def remove_old_lms_playlists(self):
        deleted_playlist_ids = []
        if cfg.core_auto_cleanup_lms_playlists():
            lms_id = self.core.get_lms_id()
            validity_days = cfg.core_auto_cleanup_lms_playlists_expiry_days()
            logging.info('Removing LMS playlists older than %s days' % str(validity_days))
            playlists = self.core.playlist.playlist(device_ids=[lms_id])['data'][lms_id]
            schedules_source_spls = db.Session.query(db.Schedule.source_playlist_uuid).filter(db.Schedule.end_timestamp > time.time()).all()
            scheduled_playlists_ids = set((schedule[0] for schedule in schedules_source_spls))
            expiry_timestamp = time.mktime((datetime.now() - timedelta(days=validity_days)).timetuple())
            for playlist in playlists:
                if playlists[playlist]['uuid'] not in scheduled_playlists_ids:
                    if 'last_modified' in playlists[playlist]['playlist'] and playlists[playlist]['playlist']['last_modified'] < expiry_timestamp:
                        deleted_playlist_ids.append(playlists[playlist]['uuid'])

            if deleted_playlist_ids:
                logging.info('Deleting playlists from LMS: {ids}'.format(ids=deleted_playlist_ids))
                self.core.playlist_service.delete(playlist_ids=[deleted_playlist_ids], device_ids=[lms_id])
        return len(deleted_playlist_ids)

    def remove_old_watchfolder_content(self):

        def _ready_for_deletion(path):
            return datetime.fromtimestamp(os.path.getmtime(path)) < self.NOW - timedelta(days=AUTO_CLEANUP_WATCHFOLDER_VALIDITY)

        def _remove_empty_subfolders(path):
            if not os.path.isdir(path):
                return
            files = os.listdir(path)
            if len(files):
                for f in files:
                    fullpath = os.path.join(path, f)
                    if os.path.isdir(fullpath):
                        _remove_empty_subfolders(fullpath)

            files = os.listdir(path)
            if len(files) == 0:
                if path != watchfolder_path:
                    if _ready_for_deletion(path):
                        os.rmdir(path)
                        deleted_folder_paths.append(path)
                        logging.debug('Deleted empty folder from watchfolder: {path}'.format(path=path))

        deleted_content_paths = []
        deleted_folder_paths = []
        if cfg.core_auto_cleanup_watchfolder():
            for device in self.core.devices:
                if self.core.devices[device].device_configuration.has_key('type') and self.core.devices[device].device_configuration['type'] == 'watchfolder':
                    watchfolder_path = self.core.devices[device].device_configuration['path']
                    for root, dirs, files in os.walk(u'' + watchfolder_path):
                        for file_name in files[:]:
                            path = os.path.join(root, file_name)
                            if _ready_for_deletion(path):
                                try:
                                    os.remove(path)
                                    deleted_content_paths.append(path)
                                    logging.debug('Deleted old content from watchfolder: {path}'.format(path=path))
                                except Exception as ex:
                                    logging.error('Could not delete watchfolder content during cleanup', exc_info=True)

                    _remove_empty_subfolders(watchfolder_path)

        return (len(deleted_content_paths), len(deleted_folder_paths))

    def _remove_expired_composite_CPLs(self):
        today = date.today()

        def __dir_expired(dcp_dir):
            if 'week' in dcp_dir:
                return True
            elif 'end' not in dcp_dir:
                return False
            else:
                return today > datetime.strptime(dcp_dir.split('end-')[-1], '%Y-%m-%d').date()

        for root, dirs, files in os.walk(os.path.join(cfg.lms_library_directory(), 'COMPOSITE')):
            for dir in dirs:
                if __dir_expired(dir.lower()):
                    shutil.rmtree(os.path.join(root, dir), ignore_errors=True)
# okay decompyling ./core/tasks/auto_cleanup.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:02 CST
