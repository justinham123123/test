# 2017.08.13 21:51:08 CST
# Embedded file name: build\bdist.win32\egg\serv\core\tasks\migration.py
import sys
import json
import re
import uuid
from sqlalchemy import DateTime, Time, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.exc import NoResultFound
from serv.storage.database.primary import database as db
from serv.storage.database.helpers import *
from sqlalchemy.sql.expression import and_
Base = declarative_base()
font_re = re.compile('<LoadFont[^>]*URI="([^"]+)"', re.I)
lms_data = None
placeholders = {}
placeholder_names = []
placeholder_map = {}

def __create_session():
    user = 'postgres'
    pwd = 'dbUs3r'
    db_name = 'tms'
    type = 'postgresql'
    port = 5432
    engine = sqlalchemy.create_engine('postgresql://{user}:{pwd}@localhost:{port}/{db_name}'.format(user=user, pwd=pwd, port=port, db_name=db_name), echo=False)
    Session = sessionmaker(bind=engine)
    return Session()


def full_migration(config_dir):
    """
    Migrate from TMS1:
        servers
        projectors        
        playlists
        pos settings
        showstart/intermission cues
        packs
        watchfolder
        SOD/EOD
        quick cues
        placeholders
    """
    global lms_data
    output = {}
    if 'win' in sys.platform:
        lms_data = 'D:/lms-data/'
    else:
        lms_data = '/lms-data/'
    wait = cherrypy.core.devices[cherrypy.core.get_lms_id()].sync_status['content_scan_active']
    while wait:
        time.sleep(2)
        wait = cherrypy.core.devices[cherrypy.core.get_lms_id()].sync_status['content_scan_active']

    try:
        logging.info('Migrating Placeholders')
        __migrate_placeholders()
        output['placeholders'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating Placeholders: ', exc_info=True)
        output['placeholders'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Migrating Devices')
        __migrate_devices(config_dir)
        output['devices'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating Devices: ', exc_info=True)
        output['devices'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Migrating POS Settings')
        __migrate_pos(config_dir)
        output['pos'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating POS Settings: ', exc_info=True)
        output['pos'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Migrating Cues')
        __migrate_showstart_intermission_cues()
        output['ShowStart'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating Cues: ', exc_info=True)
        output['ShowStart'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Migrating Playlists')
        __migrate_playlists()
        output['playlists'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating Playlists: ', exc_info=True)
        output['playlists'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Fixing Font Files')
        __fix_font()
        output['fonts'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Fixing Fonts: ', exc_info=True)
        output['fonts'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Migrating Quick Cues')
        __migrate_quick_cues()
        output['Quick_Cues'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating Quick Cues: ', exc_info=True)
        output['Quick_Cues'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Migrating Start of Day/End of Day Settings')
        __migrate_startofday_endofday()
        output['Bookends'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating SOD/EOD: ', exc_info=True)
        output['Bookends'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Migrating Packs')
        __migrate_packs()
        output['packs'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Migrating Packs: ', exc_info=True)
        output['packs'] = {'success': False,
         'messages': str(ex)}

    try:
        logging.info('Re Syncing LMS')
        lms = cherrypy.core.devices[cherrypy.core.get_lms_id()]
        lms.sync_content_store()
        output['LMS_RESYNC'] = {'success': True,
         'messages': 'Success'}
    except Exception as ex:
        logging.error('Error Resyncing LMS: ', exc_info=True)
        output['packs'] = {'success': False,
         'messages': str(ex)}

    logging.info('Migration Complete')
    return output


def __migrate_placeholders():
    global placeholders
    global placeholder_map
    global placeholder_names
    original_placeholders = cherrypy.core.placeholder.placeholders()['data']
    uuids = []
    for original_uuid in original_placeholders:
        uuids.append(str(original_uuid))

    cherrypy.core.placeholder.delete(uuids)
    session = __create_session()
    new_placeholders = []
    for placeholder in session.query(PackType).all():
        new_placeholder = {'name': str(placeholder.name),
         'uuid': str(uuid.uuid4())}
        new_placeholders.append(new_placeholder)
        placeholder_map[placeholder.id] = new_placeholder
        placeholder_names.append(str(placeholder.name))

    cherrypy.core.placeholder_service.save(new_placeholders)
    placeholders = cherrypy.core.placeholder.placeholders()['data']


def __migrate_quick_cues():

    def __save_automation(target_list, quick_cue_name = None, parameter = None):
        session = db.Session()
        if quick_cue_name == None:
            for device_uuid, automation_uuid, automation_name in target_list:
                session.query(db.QuickCueMap).filter(and_(db.QuickCueMap.device_uuid == device_uuid, db.QuickCueMap.automation_uuid == automation_uuid)).delete()

        else:
            quick_cue = None
            for device_uuid, automation_uuid, automation_name in target_list:
                quick_cues = session.query(db.QuickCue).filter(db.QuickCue.icon == quick_cue_name).all()
                for quick_cue in quick_cues:
                    session.query(db.QuickCueMap).filter(and_(db.QuickCueMap.device_uuid == device_uuid, db.QuickCueMap.qc_uuid == quick_cue.uuid)).delete()

            index = 0
            for device_uuid, automation_uuid, automation_name in target_list:
                if not quick_cue:
                    quick_cue = db.QuickCue()
                    quick_cue.uuid = str(uuid.uuid4())
                    quick_cue.icon = quick_cue_name
                    quick_cue.index = index
                    session.add(quick_cue)
                    index += 1
                quick_cue_map = db.QuickCueMap()
                quick_cue_map.qc_uuid = quick_cue.uuid
                quick_cue_map.device_uuid = device_uuid
                quick_cue_map.automation_uuid = automation_uuid
                session.add(quick_cue_map)

        session.commit()
        session.close()
        return

    db.Session.query(db.QuickCue).delete('fetch')
    db.Session.query(db.QuickCueMap).delete('fetch')
    hash = {}
    for device in cherrypy.core.screens:
        hash[cherrypy.core.screens[device]['title']] = {}
        for id in cherrypy.core.devices:
            if cherrypy.core.devices[id].device_configuration.has_key('screen_uuid'):
                scr = cherrypy.core.devices[id].device_configuration['screen_uuid']
                if scr == cherrypy.core.screens[device]['uuid']:
                    hash[cherrypy.core.screens[device]['title']] = id

    session = __create_session()
    for cue in session.query(QuickCueMap).all():
        image = session.query(QuickCue).filter(QuickCue.id == cue.quick_cue_id).one().image_path.split('.')[0].split('/')[-1].replace('cue_', '').replace('dowser', 'douser').lower()
        automation_name = cue.cue_name
        device_id = hash[cue.server_id]
        automation_uuid = None
        if cherrypy.core.devices[device_id].device_configuration['category'] == 'sms':
            for id in cherrypy.core.devices[device_id].automation:
                cue = cherrypy.core.devices[device_id].automation[id]
                if type(cue) is dict:
                    if cue['name'] == automation_name:
                        automation_uuid = id
                        break

            if automation_uuid:
                __save_automation([[device_id, automation_uuid, automation_name]], quick_cue_name=image)

    return


def __migrate_startofday_endofday():
    start_active = False
    start_spl_offset = 0
    start_spl_uuid = ''
    end_active = False
    end_spl_offset = 0
    end_spl_uuid = ''
    session = __create_session()
    for playlist in session.query(PlaylistType).all():
        if playlist.type == 'start_of_day':
            start_active = True
            start_spl_offset = playlist.offset
            start_spl_uuid = playlist.playlist_id
        if playlist.type == 'end_of_day':
            end_active = True
            end_spl_offset = playlist.offset
            end_spl_uuid = playlist.playlist_id

    cherrypy.core.configuration.service.save_bookend_settings(start_active, start_spl_offset, start_spl_uuid, end_active, end_spl_offset, end_spl_uuid)


def __migrate_showstart_intermission_cues():
    session = __create_session()

    def __add_cue(automation_name, key, value):
        session = db.Session()
        try:
            db_automation = session.query(db.AutomationConfiguration).filter(db.AutomationConfiguration.automation_name == automation_name).one()
        except NoResultFound:
            db_automation = db.AutomationConfiguration(automation_name=automation_name)
            session.add(db_automation)

        if key == 'intermission':
            db_automation.intermission = value
            db_automation.show_start = False
        elif key == 'show_start':
            db_automation.show_start = value
            db_automation.intermission = False
        session.commit()
        session.close()

    for cue in session.query(Cue).all():
        __add_cue(cue.name, cue.property_name, True)


def __migrate_pos(config_dir):
    conf = os.path.join(config_dir, 'tms.conf')
    logging.info('Parsing TMS Conf file: ', conf)
    pos_server_type = None
    pos_ip = None

    def _strip_conf(line):
        return str(line.split('=')[1].rstrip().lstrip().replace("'", '').replace('"', ''))

    with open(conf) as f:
        file = f.readlines()
    for line in file:
        if 'tms.site_name' in line:
            cfg.complex_name.set(_strip_conf(line))
        if 'pos.cinema_server' in line:
            cfg.pos_cinema_identifier.set(_strip_conf(line))
        if 'pos.iso_week_offset' in line:
            cfg.pos_week_offset.set(_strip_conf(line))
        if 'pos.starting_weekday' in line:
            cfg.pos_first_day_of_week.set(_strip_conf(line))
        if 'pos.iso_week_offset' in line:
            cfg.pos_week_offset.set(_strip_conf(line))
        if 'pos.feed_type' in line:
            cfg.pos_feed_type.set(_strip_conf(line))
        if 'pos.server_type' in line:
            pos_server_type = _strip_conf(line)
        if 'pos.ip_address' in line:
            pos_ip = _strip_conf(line)

    config.save()
    pos_device_configured = False
    for device_uuid in cherrypy.core.devices:
        if cherrypy.core.devices[device_uuid].device_configuration.has_key('category') and cherrypy.core.devices[device_uuid].device_configuration['category'] == 'pos':
            pos_device_configured = True
            break

    if pos_server_type != '0' and not pos_device_configured:
        vista_device = {'type': 'vista',
         'ip': pos_ip,
         'category': 'pos'}
        cherrypy.core.configuration.service.save_device(vista_device)
    return


def __fix_font():
    fonts = {}
    asset_path = os.path.join(lms_data, 'ASSET')
    for root, dirs, files in os.walk(asset_path):
        if root == asset_path:
            continue
        asset_uuid = os.path.split(root)[-1]
        file_info = {'uuid': asset_uuid}
        for file_name in files[:]:
            if file_name.lower() == 'info.json':
                try:
                    with open(os.path.join(root, file_name), 'rb') as f:
                        json_info = f.read()
                    file_info.update(json.loads(json_info))
                except Exception as ex:
                    print 'Unable to get contents of INFO.json for %s' % root, ex

                files.remove(file_name)
                break
        else:
            print 'INFO.json was missing for %s' % root

        if len(files) != 1:
            print 'Should be only one non-info file in each lms library subfolder, %s has %d' % (root, len(files))
            continue
        file_name = files[0]
        file_info['actual_size'] = os.path.getsize(os.path.join(root, file_name))
        file_info['file_name'] = file_name
        if file_name.lower().endswith('.ttf'):
            fonts[file_name, file_info['parent_folder']] = asset_uuid

    for root, dirs, files in os.walk(asset_path):
        if root == asset_path:
            continue
        asset_uuid = os.path.split(root)[-1]
        file_info = {'uuid': asset_uuid}
        for file_name in files[:]:
            if file_name.lower() == 'info.json':
                json_file = file_name
                try:
                    with open(os.path.join(root, file_name), 'rb') as f:
                        json_info = f.read()
                    file_info.update(json.loads(json_info))
                except Exception as ex:
                    print 'Unable to get contents of INFO.json for %s' % root, ex

                files.remove(file_name)
                break
        else:
            print 'INFO.json was missing for %s' % root

        if len(files) != 1:
            print 'Should be only one non-info file in each lms library subfolder, %s has %d' % (root, len(files))
            continue
        file_name = files[0]
        file_info['actual_size'] = os.path.getsize(os.path.join(root, file_name))
        file_info['file_name'] = file_name
        info = file_info
        if not info.get('mimetype') == 'text/xml;asdcpKind=Subtitle':
            if not info['file_name'].endswith('.xml'):
                continue
            with open(os.path.join(root, file_name), 'rb') as f:
                subtitle_xml = f.read(2500)
            match = font_re.search(subtitle_xml)
            if match:
                font_file_name = match.group(1)
                try:
                    font_asset_uuid = fonts[font_file_name, file_info['parent_folder']]
                except KeyError:
                    print 'Unable to find font %s for %s' % (font_file_name, asset_uuid)
                    continue

            else:
                continue
            if not info.has_key('size'):
                info['size'] = info['actual_size']
            print font_asset_uuid in info.get('font_asset_uuids', ()) and '%s already has %s' % (asset_uuid, font_file_name)
            continue
        info['font_asset_uuids'] = [font_asset_uuid]
        with open(os.path.join(root, json_file), 'wb') as f:
            f.write(json.dumps(info))
        print 'Fixed %s with %s' % (asset_uuid, font_file_name)


def __migrate_devices(config_dir):
    conf = os.path.join(config_dir, 'core.conf')
    logging.info('Parsing Core Conf file: ', conf)

    def _strip_conf(line):
        return str(line.split('=')[1].rstrip().lstrip().replace("'", '').replace('"', ''))

    with open(conf) as f:
        file = f.readlines()
    reached_servers_section = False
    screen = None
    screens = []
    for line in file:
        if '[SERVERS]' in line:
            reached_servers_section = True
        if reached_servers_section:
            if '[[' in line:
                if screen:
                    screens.append(screen)
                screen = {}
                screen['id'] = line.lstrip().rstrip().replace('[[', '').replace(']]', '')
            if 'ip' in line and not screen.has_key('ip'):
                screen['ip'] = _strip_conf(line)
            if 'number' in line:
                screen['number'] = _strip_conf(line)
            if 'ftp_password' in line:
                screen['ftp_password'] = _strip_conf(line)
            if 'projector_ip' in line:
                screen['projector_ip'] = _strip_conf(line)
            if 'port' in line and not screen.has_key('port'):
                screen['port'] = _strip_conf(line)
            if 'ftp_port' in line:
                screen['ftp_port'] = _strip_conf(line)
            if 'ftp_username' in line:
                screen['ftp_username'] = _strip_conf(line)
            if 'enabled' in line:
                screen['enabled'] = _strip_conf(line)
            if 'ftp_ip' in line:
                screen['ftp_ip'] = _strip_conf(line)
            if 'type' in line:
                screen['type'] = _strip_conf(line)

    if screen:
        screens.append(screen)
    for screen in screens:
        if screen['type'].lower() != 'aam lms':
            new_screen = {}
            new_screen['uuid'] = str(uuid.uuid4())
            new_screen['identifier'] = str(screen['number'])
            new_screen['title'] = screen['id']
            new_screen['three_d'] = False
            new_screen['screen_type_uuid'] = None
            new_screen['capabilities'] = []
            screen_configured = False
            for screen_uuid in cherrypy.core.screens:
                if cherrypy.core.screens[screen_uuid]['identifier'] == new_screen['identifier']:
                    screen_configured = True
                    break

            if not screen_configured:
                cherrypy.core.configuration.service.save_screen([new_screen])
                try:
                    db.Session.query(db.Screen).filter(db.Screen.uuid == new_screen['uuid']).one()
                    device = {}
                    device['type'] = screen['type'].lower()
                    device['enabled'] = 1
                    device['ip'] = screen['ip']
                    device['port'] = screen['port']
                    device['ftp_ip'] = screen['ftp_ip']
                    device['ftp_port'] = screen['ftp_port']
                    device['ftp_username'] = screen['ftp_username']
                    device['ftp_password'] = screen['ftp_password']
                    device['category'] = 'sms'
                    device['screen_uuid'] = new_screen['uuid']
                    device['uuid'] = str(uuid.uuid4())
                    device['api_username'] = None
                    device['api_password'] = None
                    cherrypy.core.configuration.service.save_device(device)
                except NoResultFound:
                    pass

                proj_ip = screen.get('projector_ip', None)
                if proj_ip:
                    projector_type = get_projector_type(proj_ip)
                    if projector_type == 'Unknown':
                        time.sleep(1)
                        projector_type = get_projector_type(proj_ip)
                        if projector_type == 'Unknown':
                            time.sleep(1)
                            projector_type = get_projector_type(proj_ip)
                    port = None
                    if 'NEC' in projector_type:
                        port = '7142'
                        projector_type = 'nec'
                    if 'Christie' in projector_type:
                        port = '5000'
                        projector_type = 'christie'
                    if 'Barco' in projector_type:
                        port = '5000'
                        projector_type = 'barco'
                    if projector_type != 'Unknown' and port != None:
                        try:
                            db.Session.query(db.Screen).filter(db.Screen.uuid == new_screen['uuid']).one()
                            projector = {'type': projector_type,
                             'ip': proj_ip,
                             'category': 'projector',
                             'screen_uuid': new_screen['uuid'],
                             'port': port}
                            cherrypy.core.configuration.service.save_device(projector)
                        except NoResultFound:
                            pass

    conf = os.path.join(config_dir, 'lms.conf')
    with open(conf) as f:
        file = f.readlines()
    watch_dir = None
    for line in file:
        if 'lms.watchfolder.folder' in line:
            watch_dir = _strip_conf(line)

    watchfolder_configured = False
    for device_uuid in cherrypy.core.devices:
        if cherrypy.core.devices[device_uuid].device_configuration.has_key('category') and cherrypy.core.devices[device_uuid].device_configuration['category'] == 'watchfolder':
            watchfolder_configured = True
            break

    if watch_dir and not watchfolder_configured:
        device = {'type': 'watchfolder',
         'name': 'Watchfolder',
         'path': watch_dir,
         'category': 'directory'}
        cherrypy.core.configuration.service.save_device(device)
    return


def __migrate_packs():
    session = __create_session()
    placeholders = cherrypy.core.placeholder.service.placeholders()
    default_placeholder_uuid = None
    for placeholder_uuid in placeholders:
        if placeholders[placeholder_uuid]['name'] == 'Advertisement':
            default_placeholder_uuid = placeholder_uuid

    for pack in session.query(Pack).all():
        try:
            playlist = session.query(Playlist).filter(Playlist.id == pack.playlist_id).one()
            screen_map = session.query(PackScreenMap).filter(PackScreenMap.pack_id == pack.playlist_id)
            screen_ids = []
            for screen in screen_map.all():
                for uuid in cherrypy.core.screens:
                    if cherrypy.core.screens[uuid]['title'] == screen.screen_id:
                        screen_ids.append(uuid)

            pjson = json.loads(playlist.playlist)
            placeholder_uuid = placeholder_map[pack.pack_type_id]['uuid'] if placeholder_map.has_key(pack.pack_type_id) and placeholder_map[pack.pack_type_id].has_key('uuid') else default_placeholder_uuid
            new_pack = {'uuid': playlist.id,
             'name': playlist.name,
             'playback_attributes': ['two_d', 'three_d'] if pack.three_d else ['two_d'],
             'placeholder_uuid': placeholder_uuid,
             'clips': __convert_playlist(pjson)[0]['events'],
             'date_from': str(pack.not_valid_before_date) if pack.not_valid_before_date else None,
             'date_to': str(pack.not_valid_after_date) if pack.not_valid_after_date else None,
             'time_from': str(pack.not_valid_before_time) if pack.not_valid_before_time else None,
             'time_to': str(pack.not_valid_after_time) if pack.not_valid_after_time else None,
             'screen_uuids': screen_ids}
            cherrypy.core.pack.service.save([new_pack])
        except Exception as ex:
            logging.error('Error saving pack [%s] ' % playlist.id, exc_info=True)

    return


def __convert_playlist(pjson):
    """
    Convert TMS1 playlist to TMS2 playlist
    """
    del pjson['annotation']
    pjson['is_3d'] = pjson['has3Dcontent']
    del pjson['has3Dcontent']
    if pjson.has_key('hasHFRcontent'):
        pjson['is_hfr'] = pjson['hasHFRcontent']
        del pjson['hasHFRcontent']
    else:
        pjson['is_hfr'] = False
    is_pack = False
    if pjson.has_key('sublist'):
        is_pack = pjson['sublist']
        del pjson['sublist']
    event_2 = []
    overall_duration = 0
    if pjson.has_key('events'):
        for event in pjson['events']:
            found = None
            for key in event:
                if key in ('pattern', 'composition'):
                    found = event[key]
                    found['type'] = key
                    found['automation'] = []
                    if not event[key].has_key('annotation'):
                        found['text'] = event[key]['cpl_id']
                    else:
                        found['text'] = event[key]['annotation']
                        del found['annotation']
                    if not found.has_key('cpl_id'):
                        found['cpl_id'] = None
                    if found.has_key('edit_rate'):
                        if found['edit_rate'] == None or len(found['edit_rate']) < 3:
                            found['edit_rate'] = '24 1'
                        edit_rate = []
                        for string in found['edit_rate'].split(' '):
                            edit_rate.append(int(string))

                        found['edit_rate'] = edit_rate
                        if found.has_key('duration') and found['duration'] != None:
                            found['duration_in_frames'] = found['duration']
                            found['duration_in_seconds'] = float(found['duration']) / (float(found['edit_rate'][0]) / float(found['edit_rate'][1]))
                            overall_duration = overall_duration + found['duration_in_seconds']
                            del found['duration']
                elif key == 'pack_type' and str(event['pack_type'].get('name')) in placeholder_names:
                    valid_placeholder = False
                    found = {'type': 'placeholder',
                     'automation': [],
                     'text': event['pack_type']['name'].replace(' Pack', ''),
                     'content_kind': None,
                     'duration_in_seconds': None,
                     'cpl_id': None,
                     'edit_rate': None}
                    for uuid in placeholders:
                        if str(placeholders[uuid]['name']) == str(found['text']):
                            found['uuid'] = uuid
                            valid_placeholder = True
                            break

                    if not valid_placeholder:
                        found = None

            if found != None:
                for key in event:
                    if key in ('cues', 'triggers'):
                        for action in event[key]:
                            auto = {}
                            if key == 'cues':
                                auto['type'] = 'cue'
                                auto['name'] = action['action']
                            else:
                                auto['name'] = action['name']
                            auto['type_specific'] = {'action': action['action']}
                            if action.has_key('offset'):
                                auto['type_specific']['offset_from'] = action['offset']['kind'].lower()
                                auto['type_specific']['offset_in_frames'] = action['offset']['value']
                                auto['type_specific']['offset_in_seconds'] = int(action['offset']['value']) / int(found['edit_rate'][0])
                            if action.has_key('parameterized') and action['parameterized'] != 0 and action['parameterized'] != '0':
                                auto['type'] = 'volume'
                                auto['type_specific']['parameter'] = action['parameterized_value']
                            if key == 'triggers':
                                auto['type'] = 'trigger'
                                auto['type_specific']['trigger'] = action['name']
                            found['automation'].append(auto)

            if found is not None:
                event_2.append(found)

        pjson['events'] = event_2
        pjson['duration_in_seconds'] = overall_duration
    else:
        pjson['events'] = []
    return (pjson, is_pack)


def __migrate_playlists():
    session = __create_session()
    playlist_path = os.path.join(lms_data, 'PLAYLIST')
    for playlist in session.query(Playlist).all():
        pjson, is_pack = __convert_playlist(json.loads(playlist.playlist))
        if is_pack:
            pass
        elif not os.path.exists(os.path.join(playlist_path, playlist.id)):
            full_path = os.path.join(playlist_path, playlist.id, playlist.id + '.json')
            create_dir(full_path)
            pjson['duration_in_seconds'] = playlist.duration
            playlist_file = open(full_path, 'w')
            playlist_file.write(json.dumps(pjson))
            playlist_file.close()


def create_dir(path):
    if not os.path.exists(path):
        dir = os.path.split(path)[0]
        create_dir(dir)
        if not os.path.isdir(dir):
            os.mkdir(dir)


class PackScreenMap(Base):
    __tablename__ = 'tms_pack_screen_server_map'
    id = Column(Integer, nullable=False, primary_key=True)
    pack_id = Column(String(60))
    screen_id = Column(String(60))


class Cue(Base):
    __tablename__ = 'tms_cue_properties'
    id = Column(String(60), nullable=False, primary_key=True)
    name = Column(String(200))
    property_name = Column(String(40000))
    value = Column(Integer, default=1)


class Playlist(Base):
    __tablename__ = 'tms_playlist'
    id = Column(String(60), nullable=False, primary_key=True)
    name = Column(String(200))
    playlist = Column(String(40000))
    duration = Column(Integer, default=0)


class PlaylistType(Base):
    __tablename__ = 'tms_playlist_type'
    id = Column(String(60), nullable=False, primary_key=True)
    playlist_id = Column(String(60), nullable=False)
    type = Column(String(50))
    offset = Column(Integer)


class PackType(Base):
    __tablename__ = 'tms_pack_type'
    id = Column(Integer, nullable=False, primary_key=True)
    name = Column(String(60), nullable=False)


class QuickCue(Base):
    __tablename__ = 'tms_quick_cue'
    id = Column(Integer, nullable=False, primary_key=True)
    image_path = Column(String(50), nullable=False)


class QuickCueMap(Base):
    __tablename__ = 'tms_quick_cue_screen_server_map'
    id = Column(Integer, nullable=False, primary_key=True)
    quick_cue_id = Column(Integer, nullable=False)
    cue_name = Column(String(50))
    server_id = Column(String(50))
    parameterized = Column(Integer, nullable=False)
    parameterized_value = Column(Integer, nullable=False)
    action = Column(String(50))


class Pack(Base):
    __tablename__ = 'tms_pack'
    playlist_id = Column(String(255), nullable=False, primary_key=True)
    issue_date = Column(DateTime, nullable=False, default=datetime_default())
    issuer = Column(String(200))
    pack_type_id = Column(String(100), default='TMS')
    version = Column(String(50))
    not_valid_before_date = Column(Date, nullable=True)
    not_valid_after_date = Column(Date, nullable=True)
    not_valid_before_time = Column(Time, nullable=True)
    not_valid_after_time = Column(Time, nullable=True)
    target_rating_certificate = Column(String(50))
    film_title = Column(String(50))
    audience_group = Column(String(50))
    three_d = Column(Boolean, default=False, nullable=False)


def get_projector_type(ip_address):
    """
    determines projector type
    """
    ok = False
    message = ''
    try:
        message = cherrypy.core.snmp_manager.snmpGet('.1.3.6.1.2.1.1.1.0', ip_address, version=1)
    except:
        pass

    if message == 'NC Series':
        return 'NEC'
    if message == 'Solaria':
        return 'Christie Series 2'
    if message.startswith('DP2K-') or message.startswith('DP4K-'):
        return 'Barco Series 2'
    if message == 'SNMP Agent DP':
        return 'Barco Series 1'
    try:
        message = cherrypy.core.snmp_manager.snmpGet('.1.3.6.1.2.1.1.1.0', ip_address, version=2)
    except:
        pass

    if message == 'CP2000':
        return 'Christie Series 1'
    try:
        message = cherrypy.core.snmp_manager.snmpGet('.1.3.6.1.2.1.1.5.0', ip_address, version=2)
    except:
        pass

    if message == 'CP2000':
        return 'Christie Series 1'
    try:
        message = cherrypy.core.snmp_manager.snmpGet('.1.3.6.1.4.1.25766.1.11.1.1.0', ip_address, version=2)
    except:
        pass

    if message.startswith('CP2000'):
        return 'Christie Series 1'
    return 'Unknown'


class Placeholder(UuidMixin, ModMixin, Base):
    __tablename__ = 'placeholder'
    name = Column(String(255))
# okay decompyling ./core/tasks/migration.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:51:11 CST
