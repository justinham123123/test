# 2017.08.13 21:48:12 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\projection_api.py
from serv.lib.utilities.helper_methods import API
from serv.core.services.projection_service import ProjectionService
import cherrypy
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.cherrypy import cherrypy_utils

class ProjectionAPI(API):
    """
    The projection API
    """

    def __init__(self, core):
        super(ProjectionAPI, self).__init__(core)
        self.service = ProjectionService(core)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def status(self, device_ids = []):
        """
        Returns the projector statuses.
        
        .. http_method_uri:: projection/status
            :category: Projection
        
        :param device_ids: List of device identifiers *(optional)*
        :type device_ids: JSON
        
        :returns: status message
        
        Example Request::
        
           /projection/status?device_ids=["27ba1130-4dfa-4bb3-a667-55681bfacb9e"]
        
        Example Response::
        
            {
                "messages": [],
                "data": {
                    "27ba1130-4dfa-4bb3-a667-55681bfacb9e": {
                        "lamp_status": "Lamp On",
                        "projector_status": "Power On",
                        "last_updated": 1369991976.359,
                        "lamps": [
                            {
                                "life": {
                                    "used": 48,
                                    "maximum": 2400,
                                    "remaining": 2352
                                },
                                "wattage": null,
                                "strike_count": 143,
                                "current": 75,
                                "voltage": null,
                                "type": "DXL-40SN2"
                            }
                        ],
                        "dowser_status": "Open",
                        "lamp_mode": null,
                        "lamp_output_percentage": null,
                        "projector_type": null,
                        "error_messages": [],
                        "lamp_output_wattage": null
                    }
                }
            }
        
        """
        projection_status, device_errors = self.service.status(device_ids)
        return {'data': dict([ (device_uuid, {'projector_type': cache.get('projector_type'),
                   'projector_status': cache.get('projector_status'),
                   'dowser_status': cache.get('dowser_status'),
                   'lamp_status': cache.get('lamp_status'),
                   'lamp_mode': cache.get('lamp_mode'),
                   'lamp_output_wattage': cache.get('lamp_output_wattage'),
                   'lamp_output_percentage': cache.get('lamp_output_percentage'),
                   'lamps': [ {'type': lamp.get('type'),
                             'current': lamp.get('current'),
                             'voltage': lamp.get('voltage'),
                             'wattage': lamp.get('wattage'),
                             'strike_count': lamp.get('strike_count'),
                             'life': {'used': lamp.get('life_used'),
                                      'maximum': lamp.get('life_maximum'),
                                      'remaining': lamp.get('life_remaining')}} for lamp in cache.get('lamps', []) ],
                   'error_messages': cache.get('error_messages', []),
                   'last_updated': cache.last_updated}) for device_uuid, cache in projection_status.iteritems() ]),
         'messages': device_errors}
# okay decompyling ./core/api/projection_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:12 CST
