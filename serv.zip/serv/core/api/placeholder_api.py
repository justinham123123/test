# 2017.08.13 21:48:10 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\placeholder_api.py
import cherrypy
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.placeholder_service import PlaceholderService

class PlaceholderAPI(API):

    def __init__(self, core):
        super(PlaceholderAPI, self).__init__(core)
        self.service = PlaceholderService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.placeholder_information)

    def placeholder_information(self, payload):
        """
        Handles `config_synced` event from Circuit Core.
        
        Sent as part of the start up sync.
        """
        cherrypy.engine.publish('ccpush', 'placeholder_information', {'placeholders': self.last_modified()}, target=payload['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def last_modified(self):
        """
        Returns a list of all placeholder `last_modified` timestamps stored on this core
        
        .. http_method_uri:: placeholder/last_modified
            :category: Placeholder
        
        :returns: A list of timestamps (JSON)
        
        Example Request::
        
            /placeholder/last_modified
        
        Example Response::
        
            {
                "messages": [],
                "data":
                    {
                        "3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0": 1351777369.38719,
                        "12026af2-657b-5c57-8835-fae593a0b2ef": 1351777369.38553,
                        "68487eca-f02e-58d9-bf51-79d48ea54a07": 1351777369.38876,
                        "a260a866-0c96-5728-a91c-796f0bdfa5eb": 1352307748.45211,
                        "f50c0acd-0583-5675-9c90-cff4594a0cf9": 1351777369.38372,
                        "f85dbe52-c665-5828-be4c-2fbadb7554f9": 1352307748.45011
                    }
            }
        """
        return {'data': self.service.last_modified(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['placeholder_uuids', 'titles', 'sorted_list'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def placeholders(self, placeholder_uuids = [], titles = False, sorted_list = False):
        """
        Retrieve the list of configured placeholders in the system
        
        .. http_method_uri:: placeholder/placeholders
            :category: Placeholder
        
        :param placeholder_uuids: List of placeholder identifiers. *(optional)*
        :param titles: Define whether to show Feature placeholder. *(optional)*
        :param sorted_list: If set to True, returns a sorted list instead of a dictionary. *(optional)*
        :type placeholder_uuids: JSON
        :type titles: Boolean
        :type sorted_list: Boolean
        
        :returns: A dictionary of placeholders (or a list, if `sorted_list` is set to True) (JSON)
        
        Example Request::
        
            /placeholder/placeholders?placeholder_uuids=["3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0"]
        
        Example Response::
        
            {
                "messages": [],
                "data":
                    {
                        "3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0":
                            {
                                "type": "content_placeholder",
                                "uuid": "3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0",
                                "name": "National Advertisement"
                            }
                    }
            }
        """
        return {'data': self.service.placeholders(placeholder_uuids, titles, sorted_list),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['placeholders'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save(self, placeholders):
        """
        Save placeholders to core.
        
        .. http_method_uri:: placeholder/save
            :category: Placeholder
        
        :param placeholders: A list of placeholders
        :type placeholders: JSON
        
        :returns: Status message (JSON)
        
        Example Request::
        
            /placeholder/save?placeholders=[{"name":"New Placeholder","uuid":"3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0"}]
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "type": "success",
                            "message": "Saved: [New Placeholder]"
                        }
                    ],
                "data": {}
            }
        """
        output = {'data': {},
         'messages': []}
        output['messages'].append(self.service.save(placeholders))
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['placeholder_uuids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, placeholder_uuids):
        """
        Delete placeholders from core.
        
        .. http_method_uri:: placeholder/delete
            :category: Placeholder
        
        :param placeholder_uuids: A list of placeholder identifiers.
        :type placeholder_uuids: JSON
        
        :returns: Status message (JSON)
        
        Example Request::
        
            /placeholder/delete?placeholder_uuids=["3aa4ec89-0712-5b68-b381-a1f0bc9fa5b0"]
        
        Example Response::
        
            {
                "messages":
                    [
                        {
                            "type": "success",
                            "message": "Deleted"
                        }
                    ],
                "data": {}
            }
        """
        output = {'data': {},
         'messages': []}
        output['messages'].append(self.service.delete(placeholder_uuids))
        return output
# okay decompyling ./core/api/placeholder_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:10 CST
