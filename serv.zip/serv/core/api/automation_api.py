# 2017.08.13 21:48:00 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\automation_api.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.automation_service import AutomationService

class AutomationAPI(API):

    def __init__(self, core):
        super(AutomationAPI, self).__init__(core)
        self.service = AutomationService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.automation_information)

    def automation_information(self, payload):
        automation_info, error = self.service.cues()
        cherrypy.engine.publish('ccpush', 'automation_information', {'automation_information': automation_info}, target=payload['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def cues(self, device_ids = []):
        """
        Returns the list of automations cues for the devices. If `device_ids` is not supplied,
        it returns the cues for all devices that support automation cues.
        
        .. http_method_uri:: automation/cues
            :category: Automation
        
        :param device_ids: List of device ids *(optional)*
        :type device_ids: JSON
        
        :returns: Cues for the specified devices (JSON)
        
        Example Request::
        
            /automation/cues?device_ids=["74f95548-af9a-4516-a18c-93309d60f25d"]
        
        Example Response::
        
            {
                "data":
                    {
                        "74f95548-af9a-4516-a18c-93309d60f25d":
                            {
                                0:
                                    {
                                        "duration": 1,
                                        "last_updated": 1361191188.73,
                                        "type": "sony_function",
                                        "name": "2D DCI FLAT",
                                        "clean": true
                                    }
                            }
                    },
                "messages": []
            }
        """
        device_automation_info, device_errors = self.service.cues(device_ids)
        return {'data': device_automation_info,
         'messages': device_errors}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['parameterized'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def trigger(self, device_id, cue_id, parameterized = False, parameterized_value = 0):
        """
        Triggers a cue on the deviced specified by device_id.
        Throws an error if the cue is not supported on a device.
        
        .. http_method_uri:: automation/trigger
            :category: Automation
        
        :param device_id: Device identifier.
        :param cue_id: Identifer for the cue.
        :param parameterized: Indicates whether this trigger is parameterized. *(optional)*
        :param parameterized_value: Used to specify a value for parameterized cues e.g. Volume *(optional)*
        :type device_id: String
        :type cue_id: String
        :type parameterized: Boolean
        :type parameterized_value: String
        
        :returns: Status message (JSON)
        
        Example Request::
        
                /automation/trigger?device_id=74f95548-af9a-4516-a18c-93309d60f25d&cue_id=1
        
        Example Response::
        
            {
                "data": {},
                "messages":
                    [
                        {
                            "message": "Triggering 1 on 2",
                            "type": "action",
                            "action_id": "c03d9c79-c918-4cac-8ab6-aca0bdfdb2bd"
                        }
                    ]
            }
        """
        output = {'data': {},
         'messages': []}
        message = self.service.trigger(device_id, cue_id, parameterized, parameterized_value)
        output['messages'] = [message]
        return output
# okay decompyling ./core/api/automation_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:00 CST
