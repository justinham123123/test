# 2017.08.13 21:48:01 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\camera_api.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.camera_service import CameraService

class CameraAPI(API):
    """
    The camera API
    """

    def __init__(self, core):
        super(CameraAPI, self).__init__(core)
        self.service = CameraService(core)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.ignore_input()
    @cherrypy.tools.response_headers(headers=[('Content-Type', 'image/jpeg')])
    @cherrypy_peformance_log
    def get_image(self, device_uuid, cache_param = None):
        """
        Gets the current camera image from core for the specified device.
        If there is no image for the specified camera, it will redirect and return a
        static 'no camera' image.
        
        .. http_method_uri:: camera/get_image
            :category: Camera
        
        :param device_uuid: Camera device identifier
        :param cache_param: A string which is unique to each image to prevent browser caching problems, datestamp works well for this *(optional)*
        :type device_uuid: String
        :type cache_param: String
        
        :returns: Current camera image (binary)
        
        Example Request::
        
            /camera/get_image?device_uuid="9c36bf1d-bfef-4d44-bd74-5b9c9be22be8"
        
        """
        image = self.service.get_image(device_uuid)
        if image is None:
            raise cherrypy.HTTPRedirect('/static/img/monitor/no-camera.jpg')
        return image

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_image(self, device_id):
        """
        Saves an image to the DB whose binary data is in the request body.
        
        .. http_method_uri:: camera/save_image
            :category: Camera
        
        :param device_id: Device identifier
        :type device_id: String
        
        :returns: Status message
        
        Example HTTP request::
        
           /camera/save_image?device_id="9c36bf1d-bfef-4d44-bd74-5b9c9be22be8"
        
        Example HTTP response::
        
            {
                "messages":
                    [
                        {
                            'type': 'success',
                            'message': 'Camera image stored'
                        }
                    ],
                "data": {}
            }
        """
        image = cherrypy.request.body.read()
        message = self.service.save_image(device_id, image)
        return {'data': {},
         'messages': [message]}
# okay decompyling ./core/api/camera_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:01 CST
