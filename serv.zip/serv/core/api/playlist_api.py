# 2017.08.13 21:48:11 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\playlist_api.py
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.playlist_service import PlaylistService
import cherrypy

class PlaylistAPI(API):

    def __init__(self, core):
        super(PlaylistAPI, self).__init__(core)
        self.service = PlaylistService(core)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['playlist_ids', 'device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, playlist_ids, device_ids = []):
        """
        Deletes specified playlists from devices
        
        .. http_method_uri:: playlist/delete
            :category: Playlist
        
        :param playlist_ids: List of playlist identifiers.
        :param device_ids: List of device identifiers. *(optional)*
        :type playlist_ids: JSON
        :type device_ids: JSON
        
        :returns: Status message (JSON)
        
        Example Request::
        
           /playlist/delete?playlist_ids=["9c36bf1d-bfef-4d44-bd74-5b9c9be22be8"]&
              device_ids=["aaec87d7-bc77-411d-8987-87023d93c49f"]
        
        Example Response::
        
            {
                "messages": [
                    {
                        "success": true,
                        "playlist_id": "64c2e333-591e-4e07-b641-9e57790601a2",
                        "message": "Deleting playlist",
                        "action_id": "2399e08d-9fb9-438d-b8ba-b36e509ba1c8",
                        "type": "action",
                        "device_id": "51c3bb76-6aa8-4e18-b6a4-1cb8e7c0a073"
                    }
                ],
                "data": {}
            }
        """
        output = {'data': {},
         'messages': []}
        messages = self.service.delete(playlist_ids, device_ids)
        output['messages'] = messages
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['playlist'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save(self, device_id, playlist, lms_playlist_reschedule = False):
        """
        Saves a playlist on a device.
        
        .. http_method_uri:: playlist/save
            :category: Playlist
        
        :param device_id: Device identifier
        :param playlist: A playlist dictionary
        :param lms_playlist_reschedule: reschedule any templated schedules which have this
            playlist uuid as its source lms playlist uuid 
        :type device_id: String
        :type playlist: JSON
        :type lms_playlist_reschedule: Boolean
        
        :returns: Status message (JSON)
        
        Example Request::
        
            {
            "device_id": "4a7599ab-2c1d-4680-ba61-21eaf12bd989",
            "playlist": {
                "duration_in_seconds":1679.1666666666,
                "title":"test_save_playlist",
                "events":[
                    {
                        "type":"composition",
                        "cpl_id":"b7f69851-3d9e-4673-936a-877cf342f211",
                        "duration_in_seconds":839.5833333333,
                        "duration_in_frames":20150,
                        "edit_rate":[24, 1],
                        "text":".REGRESSIONPACK_ADV_W39_20130301_AAM_COMPOSITE",
                        "playback_mode":"2D",
                        "content_kind":"advertisement",
                        "automation":[]
                    },
                    {
                        "type":"composition",
                        "cpl_id":"1597a52b-c734-4901-afc9-996b82b65943",
                        "duration_in_seconds":839.5833333333,
                        "duration_in_frames":20150,
                        "edit_rate":[24, 1],
                        "text":"123441_ADV_W36_20134605_AAM_COMPOSITE",
                        "playback_mode":"2D",
                        "content_kind":"advertisement",
                        "automation":[]
                    }
                ],
                "is_3d":false,
                "is_hfr":false,
                "is_4k":true,
                "automation":[]
            }
            }
        
        Example Response::
        
            {
                "messages": [
                    {
                        "message": "Saving playlist test_save_playlist on 1",
                        "device_id": "4a7599ab-2c1d-4680-ba61-21eaf12bd989",
                        "type": "action",
                        "playlist_uuid": "cd3e471e-2247-47cd-a028-0872ba88d42f",
                        "action_id": "af9efbef-fc6b-4afd-bab3-9ce88e7497aa"
                    }
                ],
                "data": {}
            }
        """
        output = {'data': {},
         'messages': []}
        message = self.service.save(device_id, playlist, lms_playlist_reschedule)
        output['messages'] = [message]
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['playlist_ids',
     'device_ids',
     'request_data_items',
     'validate'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def playlist(self, device_ids = [], playlist_ids = [], request_data_items = [], validate = False, flatten = False):
        """
        Returns specified playlists.
        
        .. http_method_uri:: playlist/playlist
            :category: Playlist
        
        :param device_ids: List of device identifiers. *(optional)*
        :param playlist_ids: List of playlist identifiers. *(optional)*
        :param request_data_items: List of data to be returned, e.g. title, duration, actual playlist etc. *(optional)*
        :param validate: If set to `true` it enables validation based on the current time. You can also provide a timestamp,
                            which will be used for validation instead.
        :param validate: If true, return playlists as a flat object (not grouped by device)
        
        :type device_ids: JSON
        :type playlist_ids: JSON
        :type request_data_items: JSON
        :type validate: Boolean or String
        
        :returns: Playlist data (JSON)
        
        Example Request::
        
           /playlist/playlist?device_ids=["51c3bb76-6aa8-4e18-b6a4-1cb8e7c0a073"]
        
        Example Response::
        
           {
                "messages": [],
                "data":
                    {
                        "2d06cf2e-1049-4e23-bb0c-cdd393326ac2":
                            {
                                "playlist":
                                    {
                                        "is_hfr": false,
                                        "title": "cr_lms_test_playlist",
                                        "is_3d": false,
                                        "is_4k": false,
                                        "automation": [],
                                        "is_template": false,
                                        "duration_in_seconds": 0,
                                        "last_modified": 1399545791.851,
                                        "id": "2d06cf2e-1049-4e23-bb0c-cdd393326ac2",
                                        "events": []
                                    },
                                "uuid": "2d06cf2e-1049-4e23-bb0c-cdd393326ac2",
                                "title": "cr_lms_test_playlist",
                                "content_ids": [],
                                "is_4k": false,
                                "is_hfr": false,
                                "is_template": false,
                                "is_3d": false,
                                "clean": true,
                                "preshow_duration": 0,
                                "duration_in_seconds": 0
                            }
                    }
            }
        """
        output = {'data': {},
         'messages': []}
        device_playlists, messages = self.service.playlist(device_ids, playlist_ids, request_data_items, validate, flatten)
        output['data'] = device_playlists
        output['messages'] = messages
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['receiving_device_ids', 'playlist_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def transfer(self, sending_device_id, receiving_device_ids, playlist_ids, playlists = [], not_before = None):
        """
        Transfers specified playlists from one device to one or more devices.
        
        .. http_method_uri:: playlist/transfer
            :category: Playlist
        
        :param sending_device_id: Device identifier for where the playist is to be copied from.
        :param receiving_device_ids: Device identifiers that the playlist will be copied to.
        :param playlist_ids: List of playlist identifiers.
        :param playlists: A list of raw playlist json dictionaries to transfer. *(optional)*
        :param not_before: Specify a time such that the playlists are not transferred before that time. Can be a String
                            (e.g 'ASAP', 'tonight') or a timestamp.
        :type sending_device_id: String
        :type receiving_device_ids: JSON
        :type playlist_ids: JSON
        :type playlists: JSON
        :type not_before: String or Integer
        
        :returns: Status message (JSON)
        
        Example Request::
        
           playlist/transfer?sending_device_id=4e753196-ff59-479e-b050-42df4141b51e&
           receiving_device_ids=["51c3bb76-6aa8-4e18-b6a4-1cb8e7c0a073"]&
           playlist_ids=["5636e6ab-ab27-46a9-b1d1-964f062e9547"]
        
        Example Response::
        
           {
                "messages": [
                    {
                        "playlist_id": "5636e6ab-ab27-46a9-b1d1-964f062e9547",
                        "message": "Transfer for playlist [5636e6ab-ab27-46a9-b1d1-964f062e9547] has been queued on device [51c3bb76-6aa8-4e18-b6a4-1cb8e7c0a073]",
                        "device_id": "51c3bb76-6aa8-4e18-b6a4-1cb8e7c0a073",
                        "type": "action",
                        "action_id": "3442fc57-455d-459d-9c22-badaac91b3f2"
                    }
                ],
                "data": {}
            }
        """
        output = {'data': {},
         'messages': []}
        messages = self.service.transfer(sending_device_id, receiving_device_ids, playlist_ids, not_before, playlists)
        output['messages'] = messages
        return output
# okay decompyling ./core/api/playlist_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:11 CST
