# 2017.08.13 21:48:11 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\pos_api.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.pos_service import POS_Service

class POS_API(API):

    def __init__(self, core):
        super(POS_API, self).__init__(core)
        self.service = POS_Service(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.pos_information)

    def pos_information(self, payload):
        """
        Handle schedule_sync event from Circuit Core.
        
        Send during start up of Circuit Core or Core.
        """
        weeks = self.service.week_number()[0]
        for week in weeks:
            cherrypy.engine.publish('ccpush', 'pos_information', {'pos_info': self.service.pos(week_number=week),
             'week': week}, target=payload['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def last_modified(self):
        """
        Returns a dictionary of all POS session last_modified timestamps
        
        :returns: dictionary of timestamps
        
        Example HTTP request::
        
            /pos/last_modified
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    58cd81be-921b-44e6-9602-da372738a3ae: 1360855803.71,
                    d32bda1f-5492-4fb3-8062-c016bc7268ac: 1360855803.698,
                    a45b945c-d8c3-4464-896b-9909ee0eaffa: 1360855803.721,
                    294b7183-cb58-4b7b-97e6-bd87e26c97ea: 1360855803.702,
                }
            }
        
        """
        return {'data': self.service.last_modified(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['week_number'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def pos(self, week_number = None, hide_unconfigured = False, hide_expired = False, show_disabled = False):
        """
        Loads POS sessions for given week number
        
        :param week_number: week number (integer)
        :param hide_unconfigured: flag, if true does not return pos items for unconfigured devices
        :param hide_expired: flag, if true does not return pos items that have expired
        :param show_disabled: flag, if true returns pos items for disabled pos devices
        
        :returns: dictionary of POS sessions and their details
        
        Example HTTP request::
        
            /pos/pos?week_number=38
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    38: { - Week number
                    c942cec5-c2fd-4ebc-8924-24b8b5724427: { - POS device (in case you have two pos systems conigured
                        75749: {  - POS ID
                            start_string: "Tuesday, 24 Sep 18:30:00", - POS show time
                            scheduled: true, - Has a playlist been scheduled for this pos session?
                            short_source_start_time: "18:30",
                            source_start_string: "Tuesday, 24 Sep 18:30:00",
                            short_start_time: "18:30",
                            source_start: 1380043800,
                            moved: false, - Has this been manually moved by someone at site?
                            title_uuid: null, - Was this schedule created by scheduling a specific Title, if so the used title uuid is used.
                            unmatched_show_attributes: { }, - Show attributes that came from the POS system but have not been "approved" on the TMS - such as Mums and bubs, 3D etc
                            screen_identifier: "02", - Screen identifier from the POS system
                            short_source_start_date: "Tue 24 Sep",
                            schedule_id: "671bde12-37b7-4079-9fc0-8989b79487d8", - Our schedule UUID
                            playlist_id: "a6ab50f5-99b7-42c0-842d-90f91acfb95b", - Scheduled playlist UUID
                            short_start_date: "Tue 24 Sep",
                            message: "Session has been scheduled.", - Information about the schedule status
                            end_string: "Tuesday, 24 Sep 19:30:00",
                            expired: false, 
                            id: "75749", - POS ID
                            title_name: null, - This would be the AAM TItle if the scheduled session was created using just a title
                            print_number: 1, - Print number specified by the POS system, otherwise null
                            description: "Elysium",
                            overall_duration: Total/actual duration
                            end: 1380047400,
                            uuid: "2eec268d-d486-4ee2-a513-d0b0fcf69a65",
                            start: 1380043800,
                            seats_available: null,
                            placeholder_type: null, - Used if a followed by is associated to this session - ads are digital, but the feature is DVD/blueray/35mm
                            title: "ELYSIUM",
                            --Approved show attributes for the POS session - used in pack and feature CPL matching
                            show_attributes: {
                                04e8c500-3d6c-5616-bce2-8ee439908172: "DBOX",
                                755db849-2913-5f3c-be99-dd6219a6c1f2: "3D"
                            },
                            source: "vista",
                            state: "assigned", - Has a playlist been associated to the POS session
                            complex_identifier: "MH Development LMS x64",
                            seats_sold: 14, - number of seats sold if available via POS system (or null)
                            week_number: 38, - week number of pos
                            feature_duration: 3600 - duration specified by POS system for feature
                            },
                        }
                    }
                }
        
        """
        return {'data': self.service.pos(week_number, hide_unconfigured, hide_expired, show_disabled),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pos_deletion_map'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def delete(self, pos_deletion_map):
        """
        Mark POS sessions as "deleted" in core's database 
        
        :param pos_deletion_map: JSON dict
        
        :returns: status message
        
        Example HTTP request::
        
            /pos/delete?{"pos_deletion_map":{"3f1a2f27-0322-4d9d-bc8a-1cb8eca10040":true}}
        
        Example HTTP response::
        
            {
                messages: [ 
                    {
                        "message":"[1] POS sessions deleted.",
                        "type":"success"
                    }
                ],
                data: {}
            }
        
        
        """
        message = self.service.delete(pos_deletion_map)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pos_update_map'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def save_mappings(self, pos_update_map):
        """
        Save POS-playlist mapping preferences
        
        :param pos_update_map: JSON dictionary
        
        :returns: status message
        
        Example HTTP request::
        
            /pos/save_mappings?pos_update_map="pos_update_map":{
                "14694eea-09e2-443e-8ae1-11788411b39f":{
                    "placeholder_type":null,
                    "playlist_id":"8657fa68-d576-4183-bb19-c6139c6357ab",
                    "state":"assigned"
                }
            }
        
        
        Example HTTP response::
        
            {
                "messages":[
                    {
                        "message":"[1] POS Sessions marked for scheduling.",
                        "type":"success"
                    }
                ],
                "data":{}
            }
        
        """
        message = self.service.save_mappings(pos_update_map)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def resync_mappings(self, min_stamp = None, max_stamp = None, screens = [], placeholders = [], pack_uuids = [], confirmed = False, trigger = None):
        """
        Re-sync POS session mappings - re-create and re-schedule LMS playlists on devices
        
        :param min_stamp: optional UNIX timestamp for range
        :param max_stamp: optional UNIX timestamp for range
        :param screens: optional list of screen identifiers as present in POS feed (integers usually)
        :param placeholders: optional list of placeholder uuids. This limits the rescheduling of LMS playlists to those that contain at least one of these placeholders.
        :param pack_uuids: optional list of pack uuids. All playlists containing these packs (even if they don't match provided time/screen/placeholder criteria) will be rescheduled.
        :param confirmed: optional boolean parameter to force resync
        :param confirmed: optional string parameter informing user of the event that triggered the resync, defaults to None
        
        :returns: status message
        
        Example HTTP request::
        
            /pos/resync_mappings?screens=["2"]
        
        Example HTTP response::
        
            {
                "messages":[
                    {
                        "message":"[1] POS Sessions marked for scheduling.",
                        "type":"success"
                    }
                ],
                "data":{}
            }
        
        """
        return self.service.resync_mappings(min_stamp, max_stamp, screens, placeholders, pack_uuids, confirmed, trigger)

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def schedule_state(self):
        """
        Check whether or not the playlist corresponding to the POS session has been scheduled and return it's state
        
        :returns: JSON dictionary
        
        Example HTTP request::
        
            /pos/schedule_state
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    sessions: {
                        de2ff649-7787-4d89-b29c-ef9768f88088: {
                            scheduled: true,
                            message: "Session has been scheduled."
                        }
                    }
                }
            }
        
        """
        output = {'data': {},
         'messages': []}
        changes = self.service.schedule_state()
        output['data'] = changes
        return output

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def week_number(self):
        """
        Get current week numbers for the next three weeks as well as the min and max dates for these weeks
        
        :returns: json dictionary
        
        Example HTTP request::
        
            /pos/week_number
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    timestamps: {
                        8: {
                            max: "Sun 24 Feb",
                            min: "Mon 18 Feb"
                        },
                        9: {
                            max: "Sun 3 Mar",
                            min: "Mon 25 Feb"
                        },
                        10: {
                            max: "Sun 10 Mar",
                            min: "Mon 4 Mar"
                        }
                    },
                    weeks: [
                        8,
                        9,
                        10
                    ]
                }
            }
        """
        output = {'data': {},
         'messages': []}
        weeks, timestamps = self.service.week_number()
        output['data']['weeks'] = weeks
        output['data']['timestamps'] = timestamps
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['cinema_id'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def append_cinema_id(self, cinema_id):
        """
        Append given cinema Identifier to the current configuration
        
        :param cinema_id: cinema identifier string
        
        :returns: JSON dict
        
        Example HTTP request::
        
            /pos/append_cinema_id?cinema_id="My Cinema ID"
        
        Example HTTP response::
        
            {
                messages: [
                    {
                        message: "Added new Complex Identifier [My Cinema ID]",
                        type: "success"
                    }
                ],
                data: {
                    cinema_id: "My Cinema ID"
                }
            }
        """
        output = {'data': {},
         'messages': []}
        success, message = self.service.append_cinema_id(cinema_id)
        output['data']['cinema_id'] = cinema_id
        output['messages'] = [message]
        return output

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['pos_config'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def set_configuration(self, pos_config):
        """
        Set POS configuration
        
        :param pos_config: JSON dictionary
        
        :returns: status message
        
        Example HTTP request::
        
            /pos/set_configuration?{"pos_config":{
                "pos_feed_type":"",
                "pos_week_offset":"0",
                "pos_first_day_of_week":"1",
                "pos_cinema_identifier":"cph, my_screen_id, VILL, QSGC, My Cinema ID",
                "pos_enabled":"1"}
            }
        
        Example HTTP response::
        
            {
                "messages":[
                    {
                        "message":"Configuration updated succesfully.",
                        "type":"success"
                    }
                ],
                "data":{}
            }
        """
        message = self.service.set_configuration(pos_config)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.json_input()
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_configuration(self):
        """
        Get POS configuration
        
        :returns: JSON dictionary
        
        Example HTTP request::
        
            /pos/get_configuration
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: {
                    pos_feed_type: "default",
                    pos_week_offset: 0,
                    pos_cinema_identifier: "10,VILL,QSGC",
                    pos_first_day_of_week: 3,
                    pos_enabled: true,
                    pos_auto_transfer_time: true
                    pos_vista_feature_stamp: false
                }
            }
        
        """
        return {'data': self.service.get_configuration(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def get_sync_history(self):
        """
        Get POS feed sync history
        
        :returns: JSON dictionary
        
        Example HTTP request::
        
            /pos/get_sync_history
        
        Example HTTP response::
        
            {
                messages: [ ],
                data: [
                    {
                    updated: {
                        info: { },
                        total: 0
                    },
                    added: {
                        info: { },
                        total: 0
                    },
                    success: true,
                    deleted: {
                        info: { },
                        total: 0
                    },
                    missing_complex_identifiers: [ ],
                    existing: {
                        info: {
                        POS Session has not changed: 1410
                    },
                    total: 1410
                    },
                    time_string: "Tue 19 Feb 2013 16:13:32",
                    error: {
                        info: { },
                        total: 0
                    },
                    device: "ee481393-e34b-4e1f-940f-74f0a729fe30",
                    message: "POS sync successful.",
                    total: 1410
                    }, ...
                ]
            }
        
        """
        return {'data': self.service.sync_history(),
         'messages': []}

    @cherrypy.expose
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def sync(self, device_ids = []):
        """
        Re-sync POS feed for given devices
        
        :param device_ids: optional list of device identifiers
        
        :returns: status message
        
        Example HTTP request::
        
            /pos/sync?device_ids=["ee481393-e34b-4e1f-940f-74f0a729fe30"]
        
        Example HTTP response::
        
            {
                messages: [ 
                    {
                        'type' : 'success', 
                        'message' : 'Resyncing POS'
                    }
                ]
                data: {}
            }
        
        """
        success, message = self.service.sync(device_ids)
        return {'data': {},
         'messages': [message]}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_out(handler=json_out_handler)
    def acknowledge_pos_resync(self):
        self.service.acknowledge_pos_resync()
        return {'data': {},
         'messages': [{'type': 'success'}]}
# okay decompyling ./core/api/pos_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:12 CST
