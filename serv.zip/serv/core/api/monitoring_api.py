# 2017.08.13 21:48:05 CST
# Embedded file name: build\bdist.win32\egg\serv\core\api\monitoring_api.py
import cherrypy
from serv.lib.cherrypy import cherrypy_utils
from serv.lib.cherrypy.cherrypy_utils import cherrypy_peformance_log, json_out_handler
from serv.lib.utilities.helper_methods import API
from serv.core.services.monitoring_service import MonitoringService

class MonitoringAPI(API):

    def __init__(self, core):
        super(MonitoringAPI, self).__init__(core)
        self.service = MonitoringService(core)
        cherrypy.engine.publish('cclisten', 'config_synced', self.config_synced)

    def config_synced(self, data):
        """
        Handle `config_synced` event from Circuit Core.
        
        Sent as part of the start up sync. We send all title_uuid with
        last_modified and Circuit Core will send us all missing/updated.
        """
        cherrypy.engine.publish('ccpush', 'monitoring_type_uuid_dict', {'monitoring_type_uuid_dict': self.service.type_last_modified()}, target=data['url'])
        cherrypy.engine.publish('ccpush', 'monitoring_oid_uuid_dict', {'monitoring_oid_uuid_dict': self.service.oid_last_modified()}, target=data['url'])

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def info(self, device_ids = []):
        """
        Returns information about a device. If a device is not specified, then information regarding all devices is returned.
        The information is device-dependent.
        
        :param device_ids: optional list of device identifiers
        
        :returns: devices' information
        
        Example HTTP request::
        
           /monitoring/info?device_ids=["801c2fde-2970-44d0-8766-103d6971a53e"]
        
        Example HTTP response::
            {
                messages: [ ],
                data: {
                    801c2fde-2970-44d0-8766-103d6971a53e: { - device UUID
                        disk_usage: {
                            total_size: 1978736312320,
                            available: 919253471232,
                            used: 1059482841088
                        },
                        last_updated: 1380024842.82938,
                        product_id: "00000000-0000-0000-0000-000000000000",
                        software_version: "2.4.2.0",
                        error_messages: [ ],
                        product_certificates: {
                        O=DC2.SMPTE.DOREMILABS.COM,OU=DC.DOREMILABS.COM,CN=LE SPB MD FM SM.DCP2000-219319.DC.DOLPHIN.DC2.SMPTE,dnQualifier=xbP+W/UGMiq81A0EYlR9NsGPu18=: "-----BEGIN CERTIFICATE----- MIIEpDCCA4ygAwIBAgIETOLi+TANBgkqhkiG9w0BAQsFADCBizEhMB8GA1UEChMY REMyLlNNUFRFLkRPUkVNSUxBQlMuQ09NMRowGAYDVQQLExFEQy5ET1JFTUlMQUJT LkNPTTEjMCEGA1UEAxMaLlVTMS5EQ1MuRE9MUEhJTi5EQzIuU01QVEUxJTAjBgNV BC4THEJuQjBpREpMZ3lxaVdVam4xdXFyT3kyL0RFRT0wHhcNMDcwMTAxMDAwMDAw WhcNMjUxMjAxMDAwMDAwWjCBpDEhMB8GA1UEChMYREMyLlNNUFRFLkRPUkVNSUxB QlMuQ09NMRowGAYDVQQLExFEQy5ET1JFTUlMQUJTLkNPTTE8MDoGA1UEAxMzTEUg U1BCIE1EIEZNIFNNLkRDUDIwMDAtMjE5MzE5LkRDLkRPTFBISU4uREMyLlNNUFRF MSUwIwYDVQQuExx4YlArVy9VR01pcTgxQTBFWWxSOU5zR1B1MTg9MIIBIjANBgkq hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsXESXZZ2wkbdvPfQvJCHi/YRi2tvJqsi TktIeRj4w6QjwudQ0K/wjGZcH7mCCMFEYQT+bsgYEI073ClNXjdK6GRG5SoauujS vW2/MKz38uFXDzEi64rThXGHBb20oBqsfgYdjiXWgqav/S85hOUlWF4IS20U84M2 WEIaemUkuwH1U3tYn+DqLLUvu87LD+x2ovX8IEB20n/VKvFdjaRMgHKBCSh5gFHD KKxhLpvpeX5xxbGex/M7GUJCEOaotpfRVnqn79SIdDtcC28stI7HoPbL5ac2Vj7N QYC3R0vDbcAIrVCzK6+UIZ+xveHoJA0mMavOgN7mljXmSEXEjyYDAwIDAQABo4H0 MIHxMAwGA1UdEwEB/wQCMAAwCwYDVR0PBAQDAgSwMB0GA1UdDgQWBBTFs/5b9QYy KrzUDQRiVH02wY+7XzCBtAYDVR0jBIGsMIGpgBQGcHSIMkuDKqJZSOfW6qs7Lb8M QaGBjaSBijCBhzEhMB8GA1UEChMYREMyLlNNUFRFLkRPUkVNSUxBQlMuQ09NMRow GAYDVQQLExFEQy5ET1JFTUlMQUJTLkNPTTEfMB0GA1UEAxMWLkRDUy5ET0xQSElO LkRDMi5TTVBURTElMCMGA1UELhMcaE43dVhTTFlpL0VLdFQwTVlhRFdlRTVqM01v PYIBAjANBgkqhkiG9w0BAQsFAAOCAQEAR6wJjigGl4KuhxyYwm4+0uXV4xbJEQiw xEHPi9kHQL+ADtRU+Hykdol3PWCjSQjjW+SmBQnE+Z5RexT5Ob2yvk0lj/LKg86t aUA2t5LuZqKZ1M6lXFzpUo94OaDsfAu8j3KeKcgM/5DLXLZPcfw+YcVe8Lk3yBhI Kp/F8PYVebFJ6LZt3f+ejjNZoJGdYIEDAUumvuvMo2iVyuz6oQ2iPpGMP63XCNrc Xbz9x2/2FXyZvne2ilYNuF3nWsMOMOM0gLMmwJTs8cm50FU1seoKKOdViTrAvC40 GKF1PTvGrMlvSvM6RijhDKKq5OcLql90kd0a837G3x5EygqL3olfMw== -----END CERTIFICATE----- ",
                        O=DC2.INTEROP.DOREMILABS.COM,OU=DC.DOREMILABS.COM,CN=LE SPB MD FM SM.DCP2000_MPEG-219319.MXFi.DOLPHIN.DC2.INTEROP,dnQualifier=6rr/qfQQUgcMoJ+XETdjbv9PeRY=: "-----BEGIN CERTIFICATE----- MIIEujCCA6KgAwIBAgIETOLi+TANBgkqhkiG9w0BAQUFADCBkDEjMCEGA1UEChMa REMyLklOVEVST1AuRE9SRU1JTEFCUy5DT00xGjAYBgNVBAsTEURDLkRPUkVNSUxB QlMuQ09NMSYwJAYDVQQDEx0uVVMxLk1YRmkuRE9MUEhJTi5EQzIuSU5URVJPUDEl MCMGA1UELhMcR2tkUXVGZzFydVZRMGZrOFNyTzRmYjZxK3FZPTAeFw0wNzAxMDEw MDAwMDBaFw0yNTEyMDEwMDAwMDBaMIGvMSMwIQYDVQQKExpEQzIuSU5URVJPUC5E T1JFTUlMQUJTLkNPTTEaMBgGA1UECxMRREMuRE9SRU1JTEFCUy5DT00xRTBDBgNV BAMTPExFIFNQQiBNRCBGTSBTTS5EQ1AyMDAwX01QRUctMjE5MzE5Lk1YRmkuRE9M UEhJTi5EQzIuSU5URVJPUDElMCMGA1UELhMcNnJyL3FmUVFVZ2NNb0orWEVUZGpi djlQZVJZPTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMKMyCZ6sdu4 EePK658rSy01Ve+euLZYlqihzEgpnfELW8XEbrqf9KfGl5dq3YXLRMucqELe/NqF 2NYOG/Tgz4SSsOBbE63rJ0bEkj4wMSVhpDG8N3M/TlOsG/NA81DS56j+lOFXHI2J lsQZMJ094HOosEXnUg13384hkIUpsdmC41TnfuJN4QcnLfav2hcftlGyyd4KtO1r MNxONlyvpkPuAFUhln61qUxcjLOGHMp9nHW9DR3+pIPeM4nqt2F4JAGpKC9tCu5O J7ipz3V+xp1RffKKOlHArqMBrZFt2QGXY/8eljU19gIJ8aD/TZC9T+Di81UJhOHv IVITpAw/r2kCAwEAAaOB+jCB9zAMBgNVHRMBAf8EAjAAMAsGA1UdDwQEAwIEsDAd BgNVHQ4EFgQU6rr/qfQQUgcMoJ+XETdjbv9PeRYwgboGA1UdIwSBsjCBr4AUGkdQ uFg1ruVQ0fk8SrO4fb6q+qahgZOkgZAwgY0xIzAhBgNVBAoTGkRDMi5JTlRFUk9Q LkRPUkVNSUxBQlMuQ09NMRowGAYDVQQLExFEQy5ET1JFTUlMQUJTLkNPTTEjMCEG A1UEAxMaLk1YRmlzLkRPTFBISU4uREMyLklOVEVST1AxJTAjBgNVBC4THERMUHVx R0xaaGtpOEFrTnBEWVF1c3JDQVBrQT2CAQIwDQYJKoZIhvcNAQEFBQADggEBAFlx JoWW3kPXBRaUvdoWR8FhjEBBxB9a0dBSOHU7YU5gukqKFt59lFXKdKoPSKxuM166 sEBCbWY458l6s3MTVs8DU9szB4H0Yy8Cel01bLZPTK3CK9eS1/jKzNQkB+YzoPso LoymFueuwpdpL/UR7R5tHMPH6EG6CeSXe2IHAKxxmpYEWoawThZQU0YpFF3oZRRk ZZu+feoGszsqoohVyA8ookHQqvV6LXpe7mWDIDGEHRZrbljjbY1+k51sQ72RmOCc A5CLTHODC6pQVNGKyrJvWow3lTCPFA0WAakh/v5qeVdT+lCYYcEjP+LSFgQp1eAL MqxQkok92nmihUKDyO0= -----END CERTIFICATE----- "
                        },
                        raid_status: [
                        {
                            status: "ok",
                            message: "OK",
                            name: "md0"
                        },
                        {
                            status: "ok",
                            message: "OK",
                            name: "md1"
                        }
                        ],
                        dnqualifiers: [
                            "xbP+W/UGMiq81A0EYlR9NsGPu18=",
                            "6rr/qfQQUgcMoJ+XETdjbv9PeRY="
                        ],
                        model: "DCP2000",
                        serial: "219319",
                        firmware_version: "21.3.115.20"
                        },
                    }
            }
        """
        device_information, device_errors = self.service.info(device_ids)
        return {'data': dict([ (device_uuid, {'id': cache.get('id'),
                   'serial': cache.get('serial'),
                   'model': cache.get('model'),
                   'software_version': cache.get('software_version'),
                   'firmware_version': cache.get('firmware_version'),
                   'disk_usage': {'total_size': cache.get('storage_total'),
                                  'available': cache.get('storage_available'),
                                  'used': cache.get('storage_used')},
                   'raid_status': cache.get('raid_status', []),
                   'dnqualifiers': cache.get('dnqualifiers', []),
                   'product_certificates': cache.get('product_certificates', []),
                   'product_id': cache.get('product_id'),
                   'error_messages': cache.get('error_messages', []),
                   'last_updated': cache.last_updated}) for device_uuid, cache in device_information.iteritems() ]),
         'messages': device_errors}

    @cherrypy.expose
    @cherrypy.tools.authenticate()
    @cherrypy.tools.json_input(json_list=['device_ids', 'action_ids'])
    @cherrypy.tools.json_out(handler=json_out_handler)
    @cherrypy_peformance_log
    def messages(self, device_ids = [], action_ids = []):
        """
        Returns the device's messages data
        
        :param device_ids: optional list of device identifiers
        :param action_ids: optional list of action identifiers
        
        :returns: devices' action/status messages
        
        Example HTTP request::
        
           /monitoring/messages?device_ids=["9c36bf1d-bfef-4d44-bd74-5b9c9be22be8"]
        
        Example HTTP response::
        
            {
                messages: [
                    "type" : "success",
                    "message": "Content deleted"
                ],
                data: { }
            }
        
        """
        action_messages, device_errors = self.service.messages(device_ids, action_ids)
        return {'data': action_messages,
         'messages': device_errors}
# okay decompyling ./core/api/monitoring_api.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:48:05 CST
