AAM icons for the people

As an embassador for united icons, AAM icons was created and placed into the common world with
a mission to bring unity to the world of icons.

