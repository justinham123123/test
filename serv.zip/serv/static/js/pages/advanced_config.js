var advanced_config_page = new AdvancedConfigPage();

function AdvancedConfigPage() {
    var self = this;

    //Templates
    self.automation_store = {};
    self.available_quick_cues = [];
    self.user_details;
    self.marquee_off = false;
    self.sched_sync_data = [];
    self.schema;

    //Introspector variables
    var introspection_counter = 1;
    var previous_commands = [];
    var selected_command = 0;

    var suggest_mode = false;
    var current_filter = '';
    
    var default_pagination_length = 50; //For db tbl pagination
    var default_pagination_length_logs = 250; //For log tbl pagination

    var keywords = ['ABORT', 'ACTION', 'ADD', 'AFTER', 'ALL', 'ALTER', 'ANALYZE', 'AND', 'AS', 'ASC', 'ATTACH',
    'AUTOINCREMENT', 'BEFORE', 'BEGIN', 'BETWEEN', 'BY', 'CASCADE', 'CASE', 'CAST', 'CHECK', 'COLLATE', 'COLUMN',
    'COMMIT', 'CONFLICT', 'CONSTRAINT', 'CREATE', 'CROSS', 'CURRENT_DATE', 'CURRENT_TIME', 'CURRENT_TIMESTAMP',
    'DATABASE', 'DEFAULT', 'DEFERRABLE', 'DEFERRED', 'DELETE', 'DESC', 'DETACH', 'DISTINCT', 'DROP', 'EACH', 'ELSE',
    'END', 'ESCAPE', 'EXCEPT', 'EXCLUSIVE', 'EXISTS', 'EXPLAIN', 'FAIL', 'FOR', 'FOREIGN', 'FROM', 'FULL', 'GLOB',
    'GROUP', 'HAVING', 'IF', 'IGNORE', 'IMMEDIATE', 'IN', 'INDEX', 'INDEXED', 'INITIALLY', 'INNER', 'INSERT',
    'INSTEAD', 'INTERSECT', 'INTO', 'IS', 'ISNULL', 'JOIN', 'KEY', 'LEFT', 'LIKE', 'LIMIT', 'MATCH', 'NATURAL',
    'NO', 'NOT', 'NOTNULL', 'NULL', 'OF', 'OFFSET', 'ON', 'OR', 'ORDER', 'OUTER', 'PLAN', 'PRAGMA', 'PRIMARY',
    'QUERY', 'RAISE', 'REFERENCES', 'REGEXP', 'REINDEX', 'RELEASE', 'RENAME', 'REPLACE', 'RESTRICT', 'RIGHT',
    'ROLLBACK', 'ROW', 'SAVEPOINT', 'SELECT', 'SET', 'TABLE', 'TEMP', 'TEMPORARY', 'THEN', 'TO', 'TRANSACTION',
    'TRIGGER', 'UNION', 'UNIQUE', 'UPDATE', 'USING', 'VACUUM', 'VALUES', 'VIEW', 'VIRTUAL', 'WHEN', 'WHERE'];

    //Methods
    self.open = function() {
        $document.trigger('page_load');
        $document.on('page_load.advanced_config', close_page);

        nav_select('config', 'advanced');

        $('#advanced_config_tmpl').tmpl2({}, '#main_section');
        var no_marquee = self.marquee_off || window.location.hostname === 'aamblr';
        $('#advanced_config_db_tmpl').tmpl2({marquee_be_gone: no_marquee}, '#jq_config_tab_pane');

        add_event_listeners();
        get_uptime();
        get_version();

        // logs stuff
        self.log_errors_only = false;
        self.log_iteration = 0;
        self.eof = false;

        $document.trigger('page_loaded');
        toggle_sidebar_setup();
        
        if(!self.db_filter_history) {
            self.db_filter_history = [];
        }
    };

    function close_page() {
        $(document).off('page_load.advanced_config', close_page);
        clearTimeout(self.sched_sync_timeout);
    }

    function get_uptime(){
        helpers.ajax_call({
            name: 'Get Uptime',
            url: "/core/uptime",
            success_function: function(input){
                $("#summary .uptime").text(moment($.now() - parseInt(input.data.uptime)*1000).format('ddd Do MMM YYYY HH:mm'));
            }
        });
    }

    function get_version(){
        helpers.ajax_call({
            name:'Get Version',
            url: "/core/get_version",
            success_function: function(input){
                $("#summary .version").text(input.data.major.toString() + "." + input.data.minor.toString() + "." + input.data.build.toString());
            }
        });
    }

    function add_event_listeners() {
        $('#log_request_option').click(launch_logmaster);
        $('#db2').click(db_viewer_setup);
        $('#introspector_request_option').click(launch_introspector);
        $('#schedule_sync_request_option').click(function(){
            $('#schedule_sync_init_tmpl').tmpl2(self.sched_sync_data, '#advanced_config_pane');
            schedule_sync_status();
        });
        $('.adv_function').click(function(){
            $(this).addClass("adv_function_selected").siblings().removeClass("adv_function_selected");
        });
        $('#query_stats_option').click(load_query_stats);
    }
    
    function db_viewer_setup() {
        helpers.ajax_call({
            name: 'Get DB Schema',
            notify: false,
            url: '/core/get_db_schema',
            success_function: function(input){
                $('#advanced_config_pane').html($('#advanced_config_dbmaster_tmpl').tmpl2(input.models));
                $('.dbmaster_tablename').click(db_viewer_tbl);
                self.schema = input.schema;
            }
        });
    }
    
    function db_viewer_tbl(){
        $('#dbmaster_contents .showing').removeClass('showing');
        $(this).addClass('showing');
        $('#generic_db_tbl_length select').off('change');
        
        var db_name = $(this).parent().data('db_name');
        var tbl_name = $(this).text().trim();
        var columns = self.schema[db_name][tbl_name];
        var $filter = $();
        
        $('#generic_db_datatable_tmpl').tmpl2({cols: columns}, '#dbmaster_table');

        function server_data(sSource, aoData, fnCallback){
            var tbl_loader = new Loader({
                target: '#advanced_config_pane',
                caption: 'Fetching rows'
            });
            var data = {};
            for (var i in aoData) {
                data[aoData[i].name] = aoData[i].value;
            }
            data.db_name = db_name;
            data.db_model_name = tbl_name;
            data.sSearch = $filter.val();
            $.ajax({
                type: 'POST',
                url: sSource,
                dataType: 'json',
                data: $.toJSON(data),
                processData: false,
                contentType: 'application/json',
                success: function(input){
                    tbl_loader.hide();
                    tbl_loader.kill();
                    if(input.error) {
                        alert(input.error);
                        return;
                    }
                    fnCallback(input);
                }
            });
        }
        function redraw() {
            datatable.fnDraw();
        }
        
        function apply_filter(filter) {
            // Don't apply the filter when the tip menu is showing since this binds to the Return key as well
            var tt = $filter.qtip('api').elements.tooltip;
            if(tt && tt.is(':visible')) return;
            if(filter) {
                self.db_filter_history.push(filter);
                $('#db_filter_history :first-child').after('<option value="'+ filter +'">'+ filter +'</option>');
            }
            redraw();
        }
        
        var cols = [];
        $.each(columns, function(i, field) {
            function null_switch(oData) {
                var val = oData[field];
                if(val === null) return '<span class="null_val">-</span>';
                if(val === true) return '<span class="bool_val yes">Y</span>';
                if(val === false) return '<span class="bool_val no">N</span>';
                if(typeof val === 'number') return '<span class="int_val no">'+ val +'</span>';
                return val.escape();
            }
            function tsamp_pretty(oData) {
                var val = oData[field];
                if(val === null) return '-';
                val = moment(val * 1000).format('YYYY-MM-DD HH:mm:ss');
                return '<span class="dt_val">'+ val +'</span>';
            }
            function uuid_pretty(oData) {
                var val = oData[field];
                if(val === null) return '-';
                return '<span class="uuid_val">'+ val +'</span>';
            }
            function json_clickable(oData) {
                var val = oData[field];
                if(val === null) return '-';
                return '<span class="json_val">'+ val +'</span>';
            }
            var formatter = null_switch;
            var is_datetime_field = (
                $._in('timestamp', field) || $._in('start', field) || $._in('end', field)
             || $._in(field, ['created', 'last_modified', 'issue_date', 'not_before'])
            ) && !$._in('playback_', field);
            if(is_datetime_field) {
                formatter = tsamp_pretty;
            } else if($._in('uuid', field)) {
                formatter = uuid_pretty;
            } else if($._in(field, ['state_changes', 'meta', 'event_list', 'title_external_ids', 'clips', 'templating_issues'])) {
                formatter = json_clickable;
            }
            cols.push({
                mDataProp: formatter,
                bSortable: true,
                bSearchable: false
            });
        });

        var datatable = $('#generic_db_tbl').dataTable({
            sAjaxSource: '/core/paginated/get_datatables_db',
            aoColumns: cols,
            bServerSide: true,
            sScrollY: '97%',
            sScrollX: '100%',
            bDestroy: true,
            bAutoWidth: false,
            aaSorting: [],
            sDom: 'ft<".dataTables_pages" lip>',
            bPaginate: true,
            sPaginationType: 'full_numbers',
            iDisplayLength: default_pagination_length,
            bLengthChange: true,
            aLengthMenu: [25, 50, 100, 250, 500],
            fnServerData: server_data,
            oLanguage: {
                sSearch: 'SQL Filter: '
            },
            fnDrawCallback: function() {
                $('.dataTables_scrollBody').scrollTop(0);
                //Fixes weird horizontal scrolling alignment issues
                $('#generic_db_tbl_wrapper .dataTables_scrollHead').css('width', '99%');
                $('.json_val').click(function() {helpers.pretty_json($(this).text());});
            }
        });
        $filter = $('#generic_db_tbl_filter input');
        
        $('#main_section, #advanced_config_pane').off('resize').resize(function(){
            datatable.fnAdjustColumnSizing(false);
            $('#generic_db_tbl_wrapper .dataTables_scrollHead').css('width', '99%');
        });
        
        //Persist any changes to the pagination length
        $('#generic_db_tbl_length select').change(function() {
           default_pagination_length = $(this).val();
        });
        
        //Filter submission - make it manual since we are doing raw SQL
        $('#generic_db_tbl_filter').append($('#generic_db_datatable_filtering_tmpl').tmpl2({history: self.db_filter_history.reverse()}))
            .find('input').off().keyup(function(e){
                if(e.keyCode === 13) {
                    e.preventDefault();
                    apply_filter($(this).val());
                }
                else if(e.keyCode === 186) {
                    // Colon means use LIKE filter
                    var col = $filter.val();
                    var cursor_pos = col.length + 7;
                    $filter.val(col.replace(':', '') + " LIKE '%%'")[0].setSelectionRange(cursor_pos,cursor_pos);
                }
            });
        $('#db_filter_history').change(function() {
            var filter = $(this).val();
            if(filter) {
                $('#generic_db_tbl_filter').find('input').val(filter);
                redraw();
            }
        });
        
        $('#clear_filter').click(function() {
            $filter.val('');
            redraw();
        });
        
        // Filter tooltip hints
        helpers.attach_suggestion_tip({
            dom: $filter,
            items: columns.map(function(c){return {name: c};}),
            text_field: 'name',
            timeout: 50,
            change: function() {
                $filter.focus();
            },
            search_filter: function(search) {
                return !search.match(/[^a-z_]+/);
            }
        });
    }
    
    function load_query_stats(){
        $('#ac_query_stats_table').tmpl2({}, '#advanced_config_pane');

        function server_data(sSource, aoData, fnCallback){
            var loader = new Loader({
                target: '#advanced_config_pane',
                caption: "Getting query stats"
            });
            loader.show();
            var data = {};
            for (var i in aoData) {
                data[aoData[i].name] = aoData[i].value;
            }
            $.ajax({
                "type": "POST",
                "url": sSource,
                "dataType": "json",
                "data": $.toJSON(data),
                "processData": false,
                "contentType": "application/json",
                "success": function(input){
                    loader.hide();
                    fnCallback(input);
                }
            });
        }

        var cols = [];
        cols.push({
            "mDataProp": function(oData, type) {
                var statement = oData['statement'];
                for(var i in keywords){
                    var keyword = keywords[i];
                    statement = statement.replace(new RegExp(keyword + " ", 'g'), "<span class='keyword'>" + keyword + ' </span>');
                }

                statement += "<div class='tracebacks'>";
                for(var t1 in oData['tracebacks']){
                    statement += "<div class='traceback'>";
                    var traceback = oData['tracebacks'][t1].slice(5);
                    for(var t in traceback){
                        if($._in(traceback[t][2], ['__call__', '_performance_monitor', '__init__', 'pop_executing_stmt', 'wrapped_function', 'respond', 'json_out_handler'])){
                            continue;
                        }
                        if(traceback[t][0].indexOf("serv") != -1 && traceback[t][0].indexOf("core")){
                            statement += "<span>" + traceback[t][2] + "</span>";
                        }
                    }
                    statement += "</div>";
                }
                statement += "</div>";

                return '<div class="statement">' + statement + '</div>';
            },
            "bSortable": false
        });
        cols.push({
            "mDataProp": function(oData, type) {
                return "<div class=''>" + oData['count'] + "</div>";
            },
            "bSortable": true
        });
        cols.push({
            "mDataProp": function(oData, type) {
                return "<div class=''>" + (parseFloat(oData['time']) / parseFloat(oData['count'])).toFixed(4) + "</div>";
            },
            "bSortable": true
        });
        cols.push({
            "mDataProp": function(oData, type) {
                return "<div class=''>" + oData['time'] + "</div>";
            },
            "bSortable": true
        });

        var datatable = $('#db_stat_table').dataTable({
            "sAjaxSource": "/core/query_stats",
            "aoColumns": cols,
            "bServerSide": true,
            "sScrollY": '100%',
            "bDestroy": true,
            "bAutoWidth": false,
            "aaSorting": [[ 1, "desc" ]],
            "sDom": 't',
            "bPaginate": false,
            "fnServerData": server_data
        });

        $("#main_section").resize(function(){
            datatable.fnAdjustColumnSizing(false);
        });
    }

    var screens = {};
    var to_migrate = 0;

    function schedule_sync_status(){
        helpers.ajax_call({
            name: 'Get Schedule Sync Status',
            url: "/core/scheduling/sync_status",
            success_function: function(input){
                var obj = $('#sched_sync');
                if(input.data.messages && obj.length){
                    var to_scroll = (obj.outerHeight() == (obj.get(0).scrollHeight - obj.scrollTop()));
                    $('#schedule_sync_tmpl').tmpl2(input.data.messages).appendTo(obj);
                    if(to_scroll){
                        obj.scrollTop(obj.get(0).scrollHeight);
                    }
                    for(var i=0; i<input.data.messages.length; i++) {
                        self.sched_sync_data.push(input.data.messages[i]);
                    }
                }
                if(input.data.syncing){
                    $("#sched_sync_title").text("Schedule Sync [SYNCING]");
                }else{
                    $("#sched_sync_title").text("Schedule Sync");
                }
                if($('#schedule_sync_request_option').hasClass('adv_function_selected')){
                    clearTimeout(self.sched_sync_timeout);
                    self.sched_sync_timeout = setTimeout(schedule_sync_status,1000);
                }else{
                    $("#sched_sync_title").text("Schedule Sync");
                }
            }
        });
    }

    function toggle_sidebar_setup() {
        var transition_duration = 500;
        $('#timeline_rightpane_toggle').click(function() {
            $(this).toggleClass('icon-arrow-left').toggleClass('icon-arrow-right')
                .toggleClass('toggle_hidden', transition_duration);
            $('#advanced_config_sidebar').toggle('slide', {direction: 'left'}, transition_duration);
            $('#advanced_config_pane').toggleClass('expanded', transition_duration);
        });
    };

    var current_script = "";
    var scripts = null;

    function launch_introspector(){
        $('#advanced_config_introspector_tmpl').tmpl2({}, '#advanced_config_pane');

        var screens = [];
        $.each($device_store.devices, function(uuid, device){
            if(device['category'] == "sms"){
                screens.push({'identifier': device.screen()['identifier'], 'device_uuid': uuid});
            }else if(device['category'] == "lms"){
                screens.push({'identifier': "LMS", 'device_uuid': uuid});
            }else if(device['category'] == "directory"){
                screens.push({'identifier': device.name, 'device_uuid': uuid});
            }else if(device['category'] == "pos"){
                screens.push({'identifier': device.type, 'device_uuid': uuid});
            }
        });
        screens.sort_screens();

        $('#introspector_screen_buttons_tmpl').tmpl2({
            'screens': screens
        }).appendTo('#introspector_screen_selector');

        $('.screen_button').click(function(){
            $('#introspector_command_line input').val("self.devices['"+$(this).attr("data-uuid")+"'].").focus().keyup();
        });

        var ctrl = false;
        $(document).keydown(function(event){
            if(event.which == 17){
                ctrl = true;
            }
        });
        $(document).keyup(function(event){
            if(event.which == 17){
                ctrl = false;
            }
        });
        $('#introspector_command_line input').keyup(function(event){
            //console.log(event.which)
            if(event.which == 32 && ctrl){
            }
            if(event.which == 27){
                hide_suggestions();
            }
            else if(event.which == 13){
                if(suggest_mode){
                    return false;
                }
                event.stopPropagation();
                hide_suggestions();
                var command = $(this).val();
                if(command.length > 0){
                    $(this).val('');
                    previous_commands.push(command);
                    send_introspector_command(command);
                    selected_command = introspection_counter;
                    introspection_counter++;
                }
            }
            else if(event.which == 38){
                if(!suggest_mode){
                    remove_suggestion_listeners();
                    if(selected_command > 0){
                        selected_command += -1;
                        $(this).val(previous_commands[selected_command]);
                    }
                    return false;
                }
            }
            else if(event.which == 40){
                if(!suggest_mode){
                    remove_suggestion_listeners();
                    if(selected_command < previous_commands.length){
                        selected_command += 1;
                        $(this).val(previous_commands[selected_command]);
                    }
                    return false;
                }
            }
            else if(event.which != 39 || !suggest_mode){
                square_spector($(this).val());
            }
        }).focus();
        // make sure any previous qtips are removed as they can cause bugs
        // with the autocomplete
        $('.qtip').remove();
        $('#introspector_command_line').qtip({
            content: {
                text: 'Nothing'
            },
            show: {
                ready: false,
                event: 'onfocus'
            },
            hide: {
                event: 'unfocus',
                fixed: true,
                leave: false
            },
            position: {
                viewport: $("body")
            },
            events: {
                show: function(event, api){
                    $('.introspector_option').click(function(){
                        $('.introspector_option.selected').removeClass("selected");
                        $(this).addClass("selected");
                        select_option();
                    });
                }
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light'
            }
        });

        helpers.ajax_call({
            'url': "/tms/get_scripts",
            'success_function': function(input){
                scripts = input;

                helpers.attach_tip_menu({
                    dom: '#script_list',
                    tmpl: '#script_list_tmpl',
                    tmpl_data: scripts,
                    classes: 'qtip-light',
                    position: {
                        viewport: $("body"),
                        my: "top center",
                        at: "bottom center"
                    },
                    render: function(){
                        $('.script_select').click(function(){
                            var filename = $(this).text();
                            current_script = scripts[filename];
                            api.hide();
                        });
                    }
                });
            }
        });

        //var cookie_script = $.cookie('read', 'script');
        //current_script = cookie_script || "print 'scriptor ready...'";
        $("#edit_button").click(open_scriptor);
        $("#exec_button").click(function(){
            execute_script(current_script);
        });
    }

    function open_scriptor(){
        var buttons = [];
        var data = {'script_text': current_script};
        buttons.push({
            'text': 'Save',
            'action': function(){
                var script = $('#script').val();
                save_script(script);
                dialog.close();
            }
        });
        dialog.open({
            'title': 'Script Editor',
            'buttons': buttons,
            hbtemplate: '#introspector_script_tmpl',
            'data': data
        });
        $('#script').keydown(function(e){
            if(e.which == 9){
                e.preventDefault();
                $("#script").append("\t");
            }
        });
    }

    function save_script(script){
        current_script = script;
        //$.cookie('write', 'script', script, 5000);
    }

    self.execute_script = execute_script;

    function execute_script(script){
        helpers.ajax_call({
            name:'Send Command',
            url:'/core/execute/',
            data:{code:script},
            notify : false,
            success_function: handle_introspector_results,
            complete_variables: {'introspection_counter' : introspection_counter}
        });
    }

    function hide_suggestions(){
        $('#introspector_command_line').qtip('hide');
        remove_suggestion_listeners();
    }

    function select_option(){
        var option = $('.introspector_option.selected').text();
        var input = $('#introspector_command_line input').val();
        var dot_pos = input.lastIndexOf(".");
        input = input.substring(0, dot_pos) + ".";
        var new_val = input + option;
        $('#introspector_command_line input').val(new_val);
        square_spector(new_val);
        $('#introspector_command_line input').focus();
    }

    function add_suggestion_listeners(){
        if(!suggest_mode){
            suggest_mode = true;
            $('#introspector_command_line input').bind('keyup.suggest', function(event){
                var selected_option_index = $('.introspector_option.selected').index();
                var is_first = selected_option_index == 0;
                var is_last = selected_option_index == $('.introspector_option');
                switch(event.which){
                    case 38:
                        if(!is_first){
                            $('.introspector_option.selected').removeClass('selected').prev().addClass('selected');
                            $('.introspector_suggested_option').html($('.introspector_option.selected').html().replace(current_filter, ''));
                        }
                        return false;
                    case 13:
                        event.stopPropagation();
                        select_option();
                        hide_suggestions();
                        return false;
                    case 40:
                        if(!is_last){
                            $('.introspector_option.selected').removeClass('selected').next().addClass('selected');
                            $('.introspector_suggested_option').html($('.introspector_option.selected').html().replace(current_filter, ''));
                        }
                        return false;
                }
            });
        }
    }

    function remove_suggestion_listeners(){
        $('#introspector_command_line input').unbind('.suggest');
        suggest_mode = false;
    }

    function square_spector(str){
        if(str == ''){
            hide_suggestions();
            return false;
        }
        var last_char = str.substring(str.length - 1);
        if(last_char == '.'){
            var command = str.substring(0, str.length-1);
            send_introspector_dir_command(command);
        }
        else{
            var str_list = str.split('.');
            var final_segment = str_list[str_list.length - 1];
            if(self.last_introspector_dir){
                self.last_introspector_filter = filter_introspector(final_segment);
            }
        }
    }

    function send_introspector_dir_command(command){
        helpers.ajax_call({
            name:'Send Command',
            url:'/core/introspect_dir/',
            data:{eval_string:command},
            notify : false,
            success_function: function(input){
                self.last_introspector_dir = input;
                filter_introspector('');
            }
        });
    }

    function filter_introspector(filter){
        current_filter = filter;
        var input = {
            type: (self.last_introspector_dir.data.type || 'error').replace(/[<>]/g, ''),
            'options' : []
        };
        input.filter = filter;
        for(var index in self.last_introspector_dir.data.options){
            var option = self.last_introspector_dir.data.options[index];
            if(option.str.indexOf(filter) == 0){
                input.options.push(option);
            }
        }
        if(input.options.length == 0){
            hide_suggestions();
            return input;
        }
        var width = find_string_length($('#introspector_command_line input').val());
        var input_offset = $('#introspector_command_line input').offset();

        $('#introspector_command_line').qtip('option', 'content.text', $("#introspector_suggest_tmpl").tmpl2(input));
        $('#introspector_command_line').qtip('option', 'position.target', [input_offset.left + parseInt(width) + 10, input_offset.top + 20]);
        $('#introspector_command_line').qtip('show');
        add_suggestion_listeners();
        return input;
    }

    function find_string_length(s){
        var size_div = $('<div></div>').css({
            'font-size' : $('#introspector_command_line input').css('font-size'),
            'position' : 'absolute',
            'left' : -500,
            'top' : -500
        }).html(s).appendTo($('body'));
        var width = size_div.css('width');
        return width;
    }

    function send_introspector_command(command){
        $('.introspector_suggestion').remove();
        helpers.ajax_call({
            name:'Send Command',
            url:'/core/introspect/',
            timeout: 60000 * 10,
            data:{eval_string:command},
            notify : false,
            success_function: handle_introspector_results,
            complete_variables : {'introspection_counter' : introspection_counter}
        });
        $('#introspector_command_line_history').append($('<div>').append(introspection_counter + '>  ').append($('<span>').text(command)));
    }

    function handle_introspector_results(input, complete_variables){
        if(input.messages.length > 0){
            var message = input.messages[0];
            $('#introspector_command_line_output').prepend($('<div>').append(complete_variables.introspection_counter + '>  ').append($('<span>').addClass(message.type).text(message.message)));
        }
    }

    function launch_logmaster(){
        var log_names = ['main', 'logmanager', 'watchfolder', 'markerclip', 'package_creation'];
        var log_levels = ['All', 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'];
        var log_nums = [0, 1, 2, 3, 4, 5, 'All'];
        var columns = ['Time', 'Source', 'Message'];
        
        var log_name = 'main';
        var log_level = null;
        var log_num = null;
        
        $('#advanced_config_pane').html('<div id="dbmaster_table"></div>');
        $('#dbmaster_table').css('left', '2px');
        $('#generic_db_datatable_tmpl').tmpl2({cols: columns}, '#dbmaster_table');
        
        
        function server_data(sSource, aoData, fnCallback){
            var db_loader = new Loader({
                target: '#advanced_config_pane',
                caption: 'Fetching Logs'
            });
            var data = {};
            for (var i in aoData) {
                data[aoData[i].name] = aoData[i].value;
            }
            data.log_name = log_name;
            data.log_level = log_level;
            data.log_rotation_num = log_num;
            $.ajax({
                type: 'POST',
                url: sSource,
                dataType: 'json',
                data: $.toJSON(data),
                processData: false,
                contentType: 'application/json',
                success: function(input){
                    db_loader.hide();
                    db_loader.kill();
                    if(input.error) {
                        alert(input.error);
                        return;
                    }
                    fnCallback(input);
                }
            });
        }
        function redraw() {
            datatable.fnDraw();
        }
        
        var cols = [
            {
                mDataProp: 'datetime',
                bSortable: true,
                bSearchable: false
            },
            {
                mDataProp: 'source',
                bSortable: true,
                bSearchable: false
            },
            {
                mDataProp: function(dat) {
                    if(dat.msg.indexOf('Traceback')) {
                        return '<pre class="traceback">'+ dat.msg +'</pre>';
                    }
                    return dat.msg;
                },
                bSortable: true,
                bSearchable: false
            }
        ];
        var datatable = $('#generic_db_tbl').dataTable({
            sAjaxSource: '/core/paginated/get_datatables_tms_logs',
            aoColumns: cols,
            bServerSide: true,
            sScrollY: '97%',
            bDestroy: true,
            bAutoWidth: false,
            aaSorting: [[ 0, 'desc' ]],
            sDom: 'ft<".dataTables_pages" lip>',
            bPaginate: true,
            sPaginationType: 'full_numbers',
            iDisplayLength: default_pagination_length_logs,
            bLengthChange: true,
            aLengthMenu: [100, 250, 500, 1000],
            fnServerData: server_data,
            fnDrawCallback: function() {
                $('.dataTables_scrollBody').scrollTop(0);
                default_pagination_length_logs = $('#generic_db_tbl_length select').val();
            },
            fnRowCallback: function(row, dat){
                row.classList.add('log_level_'+ dat.level.toLowerCase());
            } 
        });
        datatable.fnSetFilteringDelay(667);
        
        $('#main_section, #advanced_config_pane').off('resize').resize(function(){
            datatable.fnAdjustColumnSizing(false);
        });
        $('#generic_db_tbl_filter').append($('#log_filters_tmpl').tmpl2({
            log_levels: log_levels,
            log_names: log_names,
            log_nums: log_nums
        }));
        $('#log_names').change(function() {
            log_name = $(this).val();
            redraw();
        });
        $('#log_level').change(function() {
            log_level = $(this).val();
            if(log_level === 'All') log_level = null;
            redraw();
        });
        $('#log_num').change(function() {
            log_num = $(this).val();
            if(log_num === '0') log_num = null;
            redraw();
        });
    }

}
