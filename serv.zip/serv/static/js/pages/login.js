$(document).ready(function(){

    var hash = window.location.hash;
    var params = $.get_query_params();
    var redirect = params.redirect || '';

    if (params.login_error){
        $('#invalid_login').show();
    }
    $.when(
        helpers.ajax_load('/tms/theme_login_html', 'theme_login_template_holder')
    ).done(function(){
        $('#main_login_template').tmpl().appendTo('#login_page_wrapper');
    });
    //The below should *always* run, regardless of whether the theme_template was loaded
    //or not. ensures it works with ETMS/Producer/Director as well as TMS
    function submitForm() {
        $("login_form").submit();
    }

    $('#login_btn').click(submitForm);

    $('#login_form input').keydown(function(e){
        if(e.which === 13){ submitForm(); }
    });

    $('#redirect_path').val(redirect + hash);
});