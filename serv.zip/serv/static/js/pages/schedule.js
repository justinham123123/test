/*
    This is the infamous TMS scheduler,
    many have tried to succeed at understanding previous versions

    hopefully this one will be a pleasure to read.
*/

var schedule_page = new SchedulePage();
function SchedulePage() {
    var self = this;

    //we have a dict of Schedule servers which we need for keeping track of unsaved changes
    //and a few other references (such as playlists etc.) which are more for convenience.
    self.schedule_servers = {};
    self.today;
    self.large_view = true;
    self.pos_titles = false;
    self.pixel_offset;
    self.draw_settings = {};
    self.draw_settings.pixel_depth;
    self.draw_settings.width_settings = '150%';
    self.draw_settings.size_ratio;
    self.dark_theme = false;
    self.selected_schedule;
    self.tmp_schedule_id_counter = 0;
    self.start_time_settings = '9';
    self.selected_sub_menu = '#schedule_config_general_overview';
    self.start_time_settings_cookie = 'tms_scheduler_start_time_cookie';
    self.width_settings_cookie = 'tms_scheduler_width_cookie_cookie';
    self.schedule_height_settings_cookie = 'tms_scheduler_height_settings_cookie';
    self.schedule_pos_titles = 'tms_scheduler_pos_titles';
    self.transferTime = undefined;
    self.changed_days = {};
    self.repeat_day_options = {};
    self.deferred_list = [];
    self.pos_update_map = {};
    self.pos_pending_sessions = {};
    self.pos_auto_transfer_time = true;
    self.check_schedule_sync_state = true;
    self.checking_schedule_sync_state = false;
    self.copy_from_date;
    self.preselected_pos_schedule_uuid = undefined;
    self.preselected_timestamp = undefined;
    self.preselected_selected = false;
    self.schedule_calls = {};
    self.todo_list = {
        'schedule_delete': [],
        'day_delete': [],
        'playlist_transfer': [],
        'schedule': []
    };
    self.start_stamp = null;
    self.schedule_sync_stamps = {};
    self.schedule_sync_stage = null;
    self.current_item_list = null;
    self.auto_test_schedules = {};

    self.scheduler_dom = null;

    //Methods
    self.open = function() {
        var doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load.schedule_page', self._close_page);
        nav_select('schedule', 'schedule');

        var dark_theme = $.cookie('read', "schedule_page_colour_scheme");
        if(dark_theme !== undefined){
            self.dark_theme = dark_theme;
        }

        $("#schedule_main_tmpl").tmpl2({
            devices: helpers.get_device_list('schedule'),
            dark: dark_theme
        }, '#main_section');

        self.scheduler_dom = $('#scheduler_display');
        //keep track of which days have been changed wihtout being saved, so we can mark them accordingly on the schedule
        self.changed_days = {};

        // periodically check POS session states to update UI
        self.check_pos_schedule_state = true;

        // grab pos uuid and stamp from url bar if we've come from pos page'
        var hash = window.location.hash.split("#");
        if( hash.length == 4){
            self.preselected_pos_schedule_uuid = hash[2];
            self.preselected_timestamp = parseInt(hash[3]);
        }

        if($.cookie('read', self.start_time_settings_cookie)){
            self.start_time_settings = $.cookie('read', self.start_time_settings_cookie);
        }
        if($.cookie('read', self.width_settings_cookie)){
            self.draw_settings.width_settings = $.cookie('read', self.width_settings_cookie);
        }
        if($.cookie('read', self.schedule_height_settings_cookie)){
            self.large_view = $.cookie('read', self.schedule_height_settings_cookie) == 'true';
            set_view(self.large_view);
        }
        if($.cookie('read', self.schedule_pos_titles)){
            self.pos_titles = $.cookie('read', self.schedule_pos_titles) == 'true';
            toggle_pos_titles(self.pos_titles);
        }

        //add the datepicker
        var day_picker = $('#schedule_date_picker').datepicker({
            showOn: "focus",
            onSelect: function(date_text) {
                select_day(Date.parse(date_text));
                day_picker.datepicker('hide');
            }
        });

        $('#schedule_calendar').click(function(){
            $('#schedule_date_picker').focus();
        })

        //prepare a temporary internal server representation that will make scheduling operations simpler.
        reset_servers();
        var tmp_schedule_device_list = helpers.get_device_list('schedule');
        self.schedule_servers[$device_store.get_lms_uuid()] = new Server({
            'id': $device_store.get_lms_uuid(),
            'number': 'LMS',
            'is_lms': true,
            'type': 'global'
        });

        for(var i =0; i < tmp_schedule_device_list.length; i++){
            self.schedule_servers[tmp_schedule_device_list[i].id] = new Server({
                'id': tmp_schedule_device_list[i].id,
                'number': helpers.get_device_name(tmp_schedule_device_list[i]),
                'is_lms':false,
                'type':tmp_schedule_device_list[i].type,
                'initial_sync_complete': tmp_schedule_device_list[i].initial_sync_complete,
                'status': tmp_schedule_device_list[i].status
            });
        }
        
         // Monitor schedule syncing so we can refresh when necessary
        if( !self.checking_schedule_sync_state ){
            check_schedule_sync();
        }

        //get the user agents time, to figure out what their current day is and choose which day to display.
        if(self.preselected_timestamp != undefined){
            self.today = new Date(self.preselected_timestamp);
        }
        else{
            self.today = helpers.core_now();
        }
        
        if(self.today.getHours() < 4) {
            self.today.setDate(self.today.getDate()-1); //we're in yesterday
        }
        //'clean' the day we've chosen
        self.today = Date.parse(new Date(self.today.getFullYear(), self.today.getMonth(), self.today.getDate(), 0, 0, 0));

        self.copy_from_date = $.datepicker.formatDate('yy-mm-dd', new Date(self.today));
        //figure out the maths behind the timeline, for the selected day where do timestamps need to get drawn.
        determine_pixel_depth();


        //now that we know the layout add appropriate timelines to the page
        insert_time_lines();

        //add the date buttons in.
        create_day_options();

        //make the screen rows droppable
        create_drop_targets();

        var view_bar = new ViewBar({
            parent: "#schedule_section",
            zoom_cookie: "schedule_zoom",
            zoom_values: ['100', '125', '150', '175', '200'],
            zoom_callback: update_draw_settings,
            extra_options:[{
                class: 'large_view',
                title: gettext('Toggle view size'),
                action: change_view
            },{
                class: 'pos_title icon icon-tags',
                title: gettext('Toggle Playlists'), // TODO - use a string that makes sense here
                action: function(){
                    toggle_pos_titles(!self.pos_titles);
                }
            },{
                class: 'colour_mode' + (self.dark_theme == "true" ? '' : ' dark'),
                title: gettext('Set colour scheme'),
                action: toggle_colour_scheme
            }]
        });

        //attach event listeners
        add_general_event_listeners();

        update_draw_settings();
        setInterval(function(){
            each_server("progress_time_line");
        }, 3000);

        // get the info
        var server_ids = [];
        for (var server_id in self.schedule_servers) {
            server_ids.push(server_id);
            if (!self.schedule_servers[server_id].is_lms){
                 get_server_schedules(server_id);
            }
        }

        check_day_select_size();
        $("#main_section").on('resize',check_day_select_size);

        var buttons = [];

        if (helpers.is_allowed('tms_schedule_action')){
            buttons = [
                {text:gettext('Undo'), image:'undo', onClick: undo_changes, _class:'ui-state-disabled jq_enable_on_select'},
                {text:gettext('Save'), image:'save', onClick: prepare_save, _class:'ui-state-disabled jq_enable_on_select'}
            ];
        }

        helpers.set_buttons('#schedule_actions', buttons);

        $(document).trigger('page_loaded');

        $playback_store.on('loaded.schedule_page', function(){
            each_server("update_schedule_mode");
        });

        $device_store.on('loaded.schedule_page',function(){
            var updated_servers = helpers.get_device_list('schedule');
            for(var index in updated_servers){
                var device_id = updated_servers[index].id;
                var schedule_server = self.schedule_servers[device_id];
                if( schedule_server.initial_sync_complete == false ){
                    if( updated_servers[index].initial_sync_complete == true ){
                        schedule_server.initial_sync_complete = true;
                        if($.isEmptyObject(self.changed_days) && !self.changes_made){
                            reload_all();
                        }
                    }
                }
            }
        });

        $('#scheduler_screen_container').on('click','.scheduler_scheduler',
            function() {
                if (!$(this).hasClass('unknown')){
                    var device_id = $(this).parent().attr('server_id');
                    var mode = ($(this).hasClass('disabled'))?'schedule_on':'schedule_off';
                    helpers.ajax_call({
                        url:'/core/playback/set_mode',
                        data: {device_id:device_id, mode:mode}
                    });
                }
            }
        );
        $('#scheduler_display').on('click','.scheduler_clear_day',
            function() {
                var selector = '.jq_schedule_item[server_id='+$(this).parent().attr("server_id")+']';
                $(selector).hide();
                setTimeout( function() {
                    $(selector).each(function(){
                        delete_schedule(sched_obj_from_dom($(this)));
                    });
                }, 20);
            }
        );
        changes_made_function(false);
        $('#scheduler_container').on('click','.delete', function(event){event.stopPropagation(); delete_schedule(sched_obj_from_dom($(this).parent()));});

    };

    function each_server(func, args){
        for (var server_id in self.schedule_servers) {
            if (!self.schedule_servers[server_id].is_lms){
                 self.schedule_servers[server_id][func](args);
            }
        }
    }

    function click_menu(event) {
        $(this).addClass('selected toggle_action');
        $(this).siblings().removeClass('selected toggle_action');
        select_menu($(this).attr('data_open_menu'));
    }

    function select_menu(tab_selector){
        $('#schedule_actions_options').empty();
        var device_select = false;
        switch (tab_selector) {
            case 'playlist':
                device_select = true;
                $(".content_source_sub_heading").text(gettext("Playlists"));
            case 'title':
                $(".content_source_sub_heading").text(gettext("Titles"));
            case 'template':
                $('#playlists_schedule_template').tmpl2({
                    servers: self.schedule_servers,
                    device_select: device_select
                }, '#schedule_actions_options');

                if(self.current_item_list){
                    self.current_item_list.abort();
                }
                self.current_item_list = new ScheduleItemList({
                    item_type: tab_selector
                });

                $(".content_source_sub_heading").text(gettext("Playlist Templates"));
                if(device_select){
                    $('#source_select li').button().click(function(){
                        var device_uuid = $(this).attr('source');
                        $(this).addClass('selected');
                        $(this).siblings().removeClass('selected');
                        select_source(device_uuid, tab_selector);
                    });
                    $('#source_select li:first-child').click();
                }
                else{
                    self.current_item_list.load();
                }
                // dynamically set height of playlist list depending on header height, ie number of servers
                $("#content_source_titles").css("top", $(".content_source_servers").outerHeight());

                if(tab_selector == "title"){
                    $(".content_source_sub_heading").text(gettext("Titles"));
                }
                else if(tab_selector == "playlist"){
                    $(".content_source_sub_heading").text(gettext("Playlists"));
                }
                else if(tab_selector == "template"){
                    $(".content_source_sub_heading").text(gettext("Playlist Templates"));
                }
                break;
            case 'general':
                draw_general_info();
                break;
            case 'placeholders':
                $('#placeholders_template').tmpl2({
                    templates: ['dvdblueray', '35mm', 'event']
                }, '#schedule_actions_options');
                make_draggable($('#schedule_actions_options > .jq_drag_source'), true);
                break;
            case 'repeat':
                $('#repeat_schedule_template').tmpl2({
                    servers: self.schedule_servers,
                    copy_from_date: self.copy_from_date
                }, '#schedule_actions_options');
                initialize_repeat_section();
                $('#repeat_schedule_button').button({icons: {primary:'image icon-loop'}}).on('click',repeat_schedules);
                break;
            case 'swap':
                $('#swap_schedule_template').tmpl2({
                    servers: self.schedule_servers
                }, '#schedule_actions_options');
                $('input[name=swap_partner_1]').on('click',disable_enable_swap_selects);
                $('#schedule_config_swap .screen_selector input').button();
                $('#swap_schedule_button').button().on('click',swap_schedules);
                break;
        }
    }

    function sched_obj_from_dom($dom){
        var tmp_id = $dom.attr('tmp_id');
        var server_id = $dom.attr('server_id');
        //Uses the fact that there is only one source of tmp_ids for scheds and tmp_scheds rather
        var schedule = self.schedule_servers[server_id].tmp_schedules[tmp_id] !== undefined ? self.schedule_servers[server_id].tmp_schedules[tmp_id] : self.schedule_servers[server_id].schedules[tmp_id];
        return schedule;
    }

    function delete_schedule(sched_obj){
        self.clear_conflicts(sched_obj.server_id, sched_obj.tmp_id, !!sched_obj.saved);
        if (sched_obj.saved){
            self._mark_change_days(sched_obj);
            self.schedule_servers[sched_obj.server_id].deleted_ids[sched_obj.tmp_id] = true;
        }
        else {
            delete self.schedule_servers[sched_obj.server_id].tmp_schedules[sched_obj.tmp_id];
            check_changes_made();
        }
        redraw(sched_obj.server_id);
    }

    function check_schedule_sync(){
        if( self.check_schedule_sync_state ){
            self.checking_schedule_sync_state = true;
            if($.isEmptyObject(self.changed_days) && !self.changes_made){
                var schedule_sync_timestamp = $complex_status.sched_sync_stamp*1000;
                if(self.start_stamp == undefined){
                    self.start_stamp = $complex_status.core_time;
                }
                else if( schedule_sync_timestamp > self.start_stamp && self.schedule_sync_stamps[schedule_sync_timestamp.toString()] === undefined){
                    reload_all();
                    self.pos_pending_sessions = {};
                    self.schedule_sync_stamps[schedule_sync_timestamp.toString()] = true;
                }
            }
            self.check_schedule_sync_timeout = setTimeout(check_schedule_sync, 1500);
        }
        else{
            self.checking_schedule_sync_state = false;
        }
    }

    function reload_all(){
        reset_servers();
        var tmp_schedule_device_list = helpers.get_device_list('schedule');
        self.schedule_servers[$device_store.get_lms_uuid()] = new Server({
            'id': $device_store.get_lms_uuid(),
            'number': 'LMS',
            'is_lms': true,
            'type': 'global'
        });
        for (var i =0; i < tmp_schedule_device_list.length; i++) {
            self.schedule_servers[tmp_schedule_device_list[i].id] = new Server({
                'id': tmp_schedule_device_list[i].id,
                'number': helpers.get_device_name(tmp_schedule_device_list[i]),
                'is_lms':false,
                'type':tmp_schedule_device_list[i].type,
                'initial_sync_complete': tmp_schedule_device_list[i].initial_sync_complete,
                'status': tmp_schedule_device_list[i].status
            });
        }

        // We need to update here the playlists because we lost them due to the reinstantiation of the servers. A little hacky but should work fine.
        if(self.current_item_list){
            self.current_item_list.load();
        }

        var server_ids = [];
        for (var server_id in self.schedule_servers) {
            server_ids.push(server_id);
            if (!self.schedule_servers[server_id].is_lms){
                 get_server_schedules(server_id);
            }
        }
    }

    function select_source(device_uuid, type) {
        var row = $('.scheduler_screen_row[server_id='+device_uuid+']');
        if (row.length > 0) {
            document.getElementById('scheduler_display').scrollTop = row[0].offsetTop;
            document.getElementById('scheduler_screen_display').scrollTop = row[0].offsetTop;
        }
        self.current_item_list.select_source(device_uuid);
    }

    function ScheduleItemList(params){
        var device_uuid = null;
        var item_type = params['item_type'];

        var item_display = 0;
        var item_total = 0;
        var enabled = true;

        var items = [];

        var call = null;

        function select_source(uuid){
            device_uuid = uuid;
            load();
        }

        function load(){
            var self = this;
            call = helpers.ajax_call({
                url: "/tms/get_schedule_items_list",
                data:{
                    device_uuid: device_uuid,
                    type: item_type,
                    sSearch: $("#scheduler_playlist_filter").val()
                },
                loader: {target: "#content_source_titles"},
                success_function: function(input){
                    items = input['items'];
                    item_display = input['length'];
                    item_total = input['total'];
                    enabled = input['enabled'];
                    draw(item_type);
                }
            });
        }

        function abort(){
            if(call){
                call.abort();
            }
        }

        function draw(item_type){
            var dom_items = [];
            for(var i in items){
                var item = items[i];
                var container = $('#content_source_titles');
                var dom = $('#schedule_playlist_drag_tmpl').tmpl2({
                    'index': i,
                    'item': item
                });
                dom_items.push(dom);
                attach_content_tip(dom, item.issues);
            }
            $('#content_source_titles').empty().append(dom_items);

            if(item_display == 0){
                var empty_message = item_type === 'title' ? gettext('No Titles were found') : gettext('No Playlists were found');
                $("#scheduler_filter_info").text(empty_message);
            }
            else{
                make_draggable($('#content_source_titles > .jq_drag_source'), true);
                $("#scheduler_filter_info").text(gettext("Showing %display of %total").replace("%display", item_display).replace("%total", item_total));
            }
            $("#schedule_actions_options .disabler").toggle(!enabled);
            $('#scheduler_playlist_filter').searcher(self.current_item_list.load);
        }

        function get_item(index){
            return items[index];
        }

        function attach_content_tip(dom, issues){
            if(issues){
                $(dom.find(".content_problem")).qtip({
                    content: {
                        text: $("#playlist_content_issues_tip_tmpl").tmpl({issues: issues})
                    },
                    position: {
                        my: "bottom right",
                        at: "top left",
                        viewport: $("#main_section")
                    },
                    show: {
                        event: 'click mouseover',
                        ready: false
                    },
                    hide: {
                        delay: 100,
                        event: 'unfocus mouseleave',
                        fixed: true
                    },
                    style: {
                        classes: 'qtip-shadow qtip-rounded qtip-light'
                    }
                });
            }
        }

        this.load = load;
        this.draw = draw;
        this.get_item = get_item;
        this.select_source = select_source;
        this.abort = abort;
    }

    function check_day_select_size() {
        var ds = $('#day_select');
        var width = ds.innerWidth();
        ds.toggleClass('large medium small',false);
        if (width > 950) {
            ds.toggleClass('large',true);
        }else if(width > 800){
            ds.toggleClass('medium',true);
        }else{
            ds.toggleClass('small',true);
        }
    }

    function create_drop_targets() {
        $('.scheduler_row').droppable({
            accept: '.jq_drag_source',
            drop: function(event, ui){
               _item_moved($(this).attr('server_id'), event, ui);
            },
            hoverClass: 'hover',
            tolerance: 'pointer'
        });
    }

    function _get_play_date(tmp_date){
        return tmp_date.getFullYear()+'-'+(tmp_date.getMonth()+1)+'-'+tmp_date.getDate()+'T' + tmp_date.getHours() + ':' + tmp_date.getMinutes() + ':' + tmp_date.getSeconds();
    }

    function _resolve_display_name(display_name){
        if( placeholder_types[display_name] !== undefined){
            return placeholder_types[display_name];
        }
        else{
            return display_name;
        }
    }

    function _item_moved(server_id, event, ui){
        var sched_obj = self.dragging_sched;
        update_schedule(sched_obj, {'server_id': server_id, 'date': sched_obj.tmp_start_time});
        $('#scheduler').removeClass('drag_active');
    }

    function update_schedule(schedule, args){
        //We're going to return a deferred just in case
        var def = $.Deferred();
        var source = schedule['server_id'];
        var server_id = args['server_id'] || source;
        var duration = args['duration'];
        var date = args['date'];

        //Handle exceptions
        if (schedule.server_id != server_id && schedule.pos_id !== undefined){
            notification.error_msg(gettext('Cannot schedule a POS schedule on another server'));
            return;
        }
        //This should really compare against sever time.....
        if(date < self.schedule_servers[server_id].time){
            notification.error_msg(gettext("Schedule start time is invalid"));
            return;
        }

        if(duration == 0){
            notification.error_msg(gettext("Duration cannot be zero"));
            return;
        }

        //Create a duplicate schedule to manipulate
        var tmp_sched = schedule.get_temp();

        var dom = schedule.get_dom();
        dom.hide();

        var loading_dom, loading_interval;
        //Wait until the schedule has handled its move
        $.when(tmp_sched.update({'server_uuid': server_id, 'date': date, 'show_attributes': args['show_attributes'], 'duration': duration}))
        //Add pending schedule dom item
        .progress(function(){
            loading_dom = get_schedule_dom(tmp_sched);
            var spinner = loading_dom.find(".schedule_icons");
            var progress = 0;
            loading_dom.addClass("pending");
            spinner.empty();
            loading_interval = setInterval(function(){
                spinner.removeClass("icon-progress-"+progress);
                progress = progress === 3 ? 0 : progress + 1;
                spinner.addClass("icon-progress-"+progress);
            }, 200);
            $('.scheduler_row[server_id='+server_id+']').append(loading_dom);
        })
        .fail(function(){
            dom.show();
            redraw(server_id);
            def.resolve();
        })
        .done(function(){
            if(loading_dom) {
                clearInterval(loading_interval);
                loading_dom.remove();
            }
            //Remove the old schedule if this schedule was moved on the timeline
            if(source && !tmp_sched.pos_unassigned){
                self.schedule_servers[source].remove_schedule(schedule);
            }
            //We must calculate the display to update end time etc
            tmp_sched.calculate_display();
            self.schedule_servers[server_id].add_tmp_schedule(tmp_sched);
            if(tmp_sched.pos_id){
                self.pos_update_map[tmp_sched.pos_id] = {
                    "playlist_id": tmp_sched.source_spl_id,
                    "placeholder_type": tmp_sched.placeholder_type !== undefined ? tmp_sched.placeholder_type : null,
                    "spl_name": tmp_sched.pos_unassigned? gettext("Update Show Attributes") + ": "+ tmp_sched.spl_name: tmp_sched.spl_name,
                    "show_attributes": Object.keys(args['show_attributes'] || {}),
                    "state": tmp_sched.pos_unassigned ? "unassigned":"assigned"
                };
            }
            // Redraw the target server and the source if its not the same
            if(source !== undefined && source != server_id){
                redraw(schedule.server_id);
            }
            redraw(server_id);
            changes_made_function(true);
            def.resolve();
        });
        return def;
    }

    function select_schedule(dom, shift){
        var sched_obj = sched_obj_from_dom($(dom));
        var tmp = new Date(self.today);
        var time_begin = tmp.getFullYear()+'-'+(tmp.getMonth()+1)+'-'+tmp.getDate()+' 04:00:00';
        tmp.setDate(tmp.getDate()+1); //tomorrow
        var time_end = tmp.getFullYear()+'-'+(tmp.getMonth()+1)+'-'+tmp.getDate()+' 04:00:00';

        $(".schedule_item").removeClass("selected");
        $(dom).addClass("selected").siblings().removeClass("selected");

        if(shift == true && sched_obj.pos_id !== undefined && !sched_obj.pos_unassigned){
            resync_pos_schedule(sched_obj);
        }
        else if((sched_obj.source === 'placeholder' || sched_obj.placeholder_type) && !sched_obj.device_schedule_id){
            open_schedule_dialog(sched_obj, undefined);
        }
        // Unassigned POS item
        else if(sched_obj.pos_unassigned){
            open_schedule_dialog(sched_obj, undefined);
        }
        //Dragged on items
        else if(sched_obj.playlist !== undefined){
            var playlist = new Playlist(sched_obj.playlist['playlist']);
            playlist.calculate_start_times();
            open_schedule_dialog(sched_obj, playlist);
        }
        else if(sched_obj['device_schedule_id'] !== undefined) {
            var schedule_id = sched_obj.schedule_id;
            var playlist_uuid = sched_obj.spl_id;
            if(playlist_uuid !== undefined){
                $.when(
                    helpers.ajax_call({
                        url: '/core/scheduling/schedule',
                        data: {
                            start_time:time_begin,
                            end_time:time_end,
                            device_uuids:[sched_obj.server_id],
                            schedule_uuids:[schedule_id],
                            full_validation:'true'
                        }
                    }),
                    helpers.ajax_call({
                        url: '/tms/get_playlist_detailed',
                        data: {
                            device_uuid: sched_obj.server_id,
                            playlist_uuid: playlist_uuid,
                            validate: true,
                            when: sched_obj.start_time
                        }
                    })
                ).done(function(schedule_response, playlist_response) {
                    var tmp_id = self.schedule_servers[sched_obj.server_id].core_id_to_tmp_id[schedule_id];
                    if(schedule_response[0].data[schedule_id] !== undefined){
                        sched_obj.errors = schedule_response[0].data[schedule_id].device_information.issues;
                    }
                    var playlist = new Playlist(playlist_response[0].data);
                    playlist.calculate_start_times();
                    open_schedule_dialog(sched_obj, playlist);
                });
            }else{
                notification.info_msg(gettext("Schedule must be saved or resynced"));
            }
        }
        else{
            var url;
            var data = {};
            var source_device_uuid = sched_obj['source'];

            url = '/tms/get_playlist_detailed';
            data = {
                device_uuid: source_device_uuid,
                playlist_uuid: sched_obj.spl_id
            };
            $.when(
                helpers.ajax_call({
                    url: url,
                    data: data
                }),
                helpers.ajax_call({
                    url: '/core/scheduling/schedule',
                    data: {
                        start_time:time_begin,
                        end_time:time_end,
                        device_uuids:[sched_obj.server_id],
                        schedule_uuids:[sched_obj.schedule_id],
                        full_validation:'true'
                    }
                })

            ).done(function(playlist_response, schedule_response){
                var tmp_id = self.schedule_servers[sched_obj.server_id].core_id_to_tmp_id[sched_obj.schedule_id];
                var playlist = undefined;
                if (sched_obj.placeholder_duration === undefined){
                    playlist = new Playlist(playlist_response[0].data);
                }
                if(playlist)
                    playlist.calculate_start_times();
                if (sched_obj.saved == true){
                    sched_obj.errors = schedule_response[0].data[sched_obj.schedule_id].device_information.issues;
                }
                open_schedule_dialog(sched_obj, playlist);
            });
        }
    }

    function append_futher_info(schedule){

        var furthers = [];
        var fur_tmpl = $('#schedule_details_further_tmpl');

        if(!schedule.saved){
            furthers.push(fur_tmpl.tmpl2({
                text: gettext('Not saved on the screen server')
            }));
        }
        else if(schedule.device_schedule_id === undefined){
            furthers.push(fur_tmpl.tmpl2({
                text: gettext('Not scheduled on the screen server')
            }));
        }
        else if(schedule.placeholder_duration !== undefined){
            furthers.push(fur_tmpl.tmpl2({
                text: gettext('This is a schedule placeholder'),
                image: {
                    classes: 'icon placeholder_' + schedule.placeholder_type
                }
            }));
        }
        else if(schedule.pos_unassigned !== true){
            var con = gettext("Content");
            furthers.push(fur_tmpl.tmpl2({
                text: con,
                image: {
                    classes: 'image ' + (schedule.content_problem ? "content_problem" : "content_ok"),
                    title: con
                }
            }));
            con = gettext("KDM");
            furthers.push(fur_tmpl.tmpl2({
                text: con,
                image: {
                    classes: 'image ' + (schedule.kdm_problem ? "kdm_content_invalid" : "kdm_content_ok"),
                    title: con
                }
            }));
        }

        if(schedule.seats_sold != null){
            furthers.push(fur_tmpl.tmpl2({
                text: gettext('Seats Sold'),
                image: {
                    text: schedule.seats_sold
                }
            }));
        }

        $('.schedule_info .extra_info').append(furthers);
    }

    function open_schedule_dialog(schedule_details, playlist){
        var show_start = moment(schedule_details.display_show_start);
        schedule_details.show_start = show_start.format('HH:mm:ss');
        schedule_details.show_attr_mod = Boolean(schedule_details.type != "playlist" || schedule_details.schedule_type == "pos");

        // we grab the preselected pos uuid from the url's hash, only want to do this the first time.
        self.preselected_selected = true;

        // save the schedule dialog options before closing it
        function save_schedule_dialog_changes() {
            var schedule_info_carrier = $('#dialog_schedule_details');
            var server_id = schedule_info_carrier.attr('server_id');
            var tmp_id = parseInt(schedule_info_carrier.attr('tmp_id'),10);
            // Get scheduled, if not get temp
            var schedule_object = self.schedule_servers[server_id].schedules[tmp_id] || self.schedule_servers[server_id].tmp_schedules[tmp_id];

            var new_duration = schedule_object.placeholder_type !== undefined ? $('#schedule_detail_duration_hms').hms('retrieve') : undefined;
            // Modify the time component ONLY of start_time of the schedule item
            var new_time = $('#schedule_detail_start_hms').hms('retrieve_datetime');
            schedule_object.start_time.setHours(new_time.getHours());
            schedule_object.start_time.setMinutes(new_time.getMinutes());
            schedule_object.start_time.setSeconds(new_time.getSeconds());
            var show_attributes = attribute_list !== undefined ? attribute_list.get_selected_names() : undefined;

            update_schedule(schedule_object, {'date': schedule_object.start_time, 'show_attributes': show_attributes, 'duration': new_duration});

            dialog.close();
            $(".schedule_item").removeClass("selected");
        }

        function changes_made(){
            $("#at_button_0").button("enable");
        }

        // buttons
        var buttons = [];
        buttons.push({
            'text' : gettext('Apply'),
            'action' : save_schedule_dialog_changes,
            'enabled' : false
        });
        // open dialog
        dialog.open({
            'title': playlist ? playlist.title : schedule_details.display_name,
            'hbtemplate': '#schedule_details_tmpl',
            'data': {
                'schedule': schedule_details,
                'playlist': playlist
            },
            'buttons': buttons,
            'width': 640
        });
        append_futher_info(schedule_details);

        // configure show attribute list
        if(schedule_details.type != "playlist" || schedule_details.schedule_type == "pos"){
            var attribute_list = new ShowAttributeSelector({
                dom: $('#schedule_info_attributes'),
                current: schedule_details.show_attributes || [],
                click: changes_made
            });
        }

        // configure HMS stuff
        $('#schedule_detail_start_hms').hms({
            hours: schedule_details.start_time.getHours(),
            minutes: schedule_details.start_time.getMinutes(),
            seconds: schedule_details.start_time.getSeconds(),
        });
        $('#schedule_detail_duration_hms').hms({
            seconds: schedule_details.display_duration
        });
        // Enable apply button on change
        $('#schedule_detail_start_hms input, #schedule_detail_duration_hms input').on("keyup", function(){
            changes_made();
        });

        // Disable apply button
        $("#at_button_0").button("disable");
        $("#schedule_detail_start_hms").hms(schedule_details.pos_unassigned ? "disable":"enable");

        $('#schedule_detail_hour, #schedule_detail_minute, #schedule_detail_seconds').on('enter.schedule', save_schedule_dialog_changes);
        if($('#schedule_info_templating .template_issue').length == 0){
            $('#schedule_info_templating_tab').hide();
        }
        $('.schedule_info_tab').on('click.schedule', function() {
            $('.schedule_info_tab.selected').removeClass("selected");
            $(this).addClass('selected');
            $('.schedule_info_tab_content.showing').hide();
            $($(this).attr("data-target")).show().addClass("showing");
        });
        //Retransfer content button handler
        $('#schedule_info_problems .retransfer').click(function(event){
            var button = $(event.target);
            var content_uuid = button.attr("data-content_uuid");
            var target = schedule_details.server_id;

            helpers.ajax_call({
                url:'/core/content/transfer',
                'notify' : true,
                data:{
                    sending_device_id: "Auto",
                    receiving_device_ids: [target],
                    content_ids: [content_uuid]
                },
                success_function: function(input) {
                    button.addClass('active');
                    button.qtip({
                        content: {
                            text: $('#schedule_details_transfer_feedback_tmpl').tmpl2({messages: input.messages})
                        },
                        position: {
                            my: "bottom center",
                            at: "top center",
                        },
                        show: {
                            event: 'click',
                            ready: true,
                        },
                        hide: {
                            event: 'unfocus',
                            fixed: true,
                            inactive: 5000
                        },
                        style: {
                            classes: 'qtip-shadow qtip-rounded qtip-light'
                        }
                    });
                }
            });
        });
        //Pos resync button handler
        $("#pos_resync").on("click.schedule",function(){
            resync_pos_schedule(schedule_details);
        });
    }

    function resync_pos_schedule(schedule_details){
        // remap session
        self.pos_update_map[schedule_details.pos_id] = {
            "playlist_id": schedule_details.source_spl_id,
            "placeholder_type": schedule_details.placeholder_type !== undefined ? schedule_details.placeholder_type : null,
            "spl_name": schedule_details.spl_name,
            "state": "assigned"
        };
        self.pos_pending_sessions[schedule_details.pos_id] = true;

        // update schedule dom
        var dom = $("div[schedule_id='" + schedule_details.schedule_id + "']");
        $(dom).removeClass("disabled").addClass("unsaved");
        $(dom).find(".spl_name").html(schedule_details.spl_name);

        // done
        if( dialog !== undefined){
            dialog.close();
        }
        $(".schedule_item").removeClass("selected");
        changes_made_function(true);
    }

    function toggle_colour_scheme(){
        var container = $('#scheduler');
        var dark = container.hasClass('dark');
        set_colour_scheme(!dark);
        $.cookie('write', "schedule_page_colour_scheme", !dark, 5000);
    }

    function toggle_pos_titles(on){
        self.pos_titles = on;
        $('#scheduler').toggleClass('pos_titles', on);
        $.cookie('write', self.schedule_pos_titles, on, 5000);
    }

    function set_colour_scheme(dark){
        var container = $('#scheduler');
        container.toggleClass('dark', dark);
        $('.view_option.colour_mode').toggleClass('dark', !dark);
    }

    function change_view(){
        self.large_view = !self.large_view;
        $.cookie('write', self.schedule_height_settings_cookie, self.large_view);
        set_view(self.large_view);
    }

    function set_view(large_view){
        var target = $('.view_option.large_view, .view_option.small_view');
        if (self.large_view) {
            target.removeClass('small_view');
            target.addClass('large_view');
            $('#scheduler').removeClass('small');
        }
        else {
            target.removeClass('large_view');
            target.addClass('small_view');
            $('#scheduler').addClass('small');
        }
    }

    function add_general_event_listeners() {
        $('#schedule_section').on('click','.jq_schedule_item, .schedule_issue', function(e){select_schedule(this,e.shiftKey);});
        self.scheduler_dom.on('scroll',
            function(event){
                document.getElementById('scheduler_screen_display').scrollTop = event.currentTarget.scrollTop;
                document.getElementById('scheduler_date_line_display').scrollLeft = event.currentTarget.scrollLeft;
            }
        );
        $('.section_toggle_open').on('click', function(){
            toggle_controls_click(this);
        });

        $('#schedule_actions_nav li').on('click',click_menu);
        $('#day_select').on('click','.day_option',function(){
            select_day($(this).attr('date_stamp'));
        });
        $('#previous_day, #next_day').on('click',select_day_by_difference);

        $('#schedule_control_section').on(
            'mouseover',
            'div.schedule_issue',
            function(){
                get_schedule_issue_item( $(this) ).toggleClass('schedule_item_highlighted', true);
            }
        );
        $('#schedule_control_section').on(
            'mouseout',
            'div.schedule_issue',
            function(){
                get_schedule_issue_item( $(this) ).toggleClass('schedule_item_highlighted', false);
            }
        );

        $('#boxAT8').on(
            'click',
            '.at_close',
            function(){
                $(".jq_schedule_item").removeClass("selected");
            }
        );
    }

    function get_schedule_issue_item(schedule_issue_list_item){
        var tmp_id = schedule_issue_list_item.attr("tmp_id");
        var schedule_issue_item= $('.jq_schedule_item[server_id=' + schedule_issue_list_item.attr("server_id") + '][tmp_id=' + schedule_issue_list_item.attr("tmp_id") + ']');
        return schedule_issue_item;
    }

    function toggle_controls_click(target) {
        var open = $('#schedule_section').hasClass('open');
        var selected = $(target).hasClass('selected');
        if(!open) {
            show_controls();
        }
        else if(open && selected) {
            hide_controls();
        }
    }

    function show_controls(){
        $('#schedule_section').css({'right':'310px'}).addClass('open');
        check_day_select_size();
    }

    function hide_controls(){
        $('#schedule_section').css({'right':'35px'}).removeClass('open');
        check_day_select_size();
    }

    function determine_pixel_depth() {
        //use todays reference.
        var tmp = new Date(self.today);

        //get the display range
        var time_begin = new Date(tmp.getFullYear(), tmp.getMonth(), tmp.getDate(), 4,0,0);
        tmp.setDate(tmp.getDate()+1); //tomorrow
        var time_end = new Date(tmp.getFullYear(), tmp.getMonth(), tmp.getDate(), 4,0,0);

        //get the earliest timestamp we need to show
        self.pixel_offset = Date.parse(time_begin);
        //per second, where should the time be placed.
        self.draw_settings.pixel_depth =  100.0/(Date.parse(time_end) - Date.parse(time_begin));
        self.pixel_time_range  =  time_end - time_begin;
    }

    function insert_time_lines() {
        //this function adds the time lines as well as adding the hours to the top
        //we want to check at quarter hourly intervals
        var left, additional_class, tmp_last_child;
        var interval = (100.0) / (24 * 4.0);

        var time_lines = [];
        var time_headers = [];
        var time_tmpl = $('#schedule_time_entry_tmpl');
        var line_tmpl = $('#schedule_timeline_tmpl');
        for(var i = 0; i < 25 * 4; i++){
            left = i * interval;
            additional_class = '';
            if(i % 4 == 0){
                //add the time to the top time entry section line
                var header = time_tmpl.tmpl2({
                    'left': left,
                    'time': (i / 4 + 4),
                    'time_mod': (i / 4 + 4) % 24
                });
                time_headers.push(header);
                tmp_last_child = $(header).find(".time_entry_cheat");
                //shift the time entry slightly to make it centered on the timelines
                tmp_last_child.css('left', -15);
            }
            else if(i % 2 == 0){
                //half hour
                additional_class = 'time_line_half';
            }
            else {
                //quarter hour
                additional_class = 'time_line_quarter';
            }
            //add the time line to the scheudle display.
            var line = line_tmpl.tmpl2({'left': left, 'addtional_class': additional_class});
            time_lines.push(line);
        }
        $('#scheduler_date_line_container').append(time_headers);
        $('.scheduler_row').append(time_lines);
    }

    function create_day_options() {
        var tmp_day_option = $('.day_option[date_stamp='+self.today+']');
        if (tmp_day_option.length > 0) {
            // selected date is on our radar, draw
            $('.day_option').removeClass('selected');
            tmp_day_option.addClass('selected');
            for (var changed_day in self.changed_days) {
                var day_option = $('.day_option[date_stamp='+changed_day+']').addClass('changed');
            }
        }
        else {
            tmp_day_option = $('.day_option:first-child');
            var today_left = true;
            if (tmp_day_option.length >0) {
                if (parseInt(tmp_day_option.attr('date_stamp'),10)<self.today) {
                    today_left = false;
                }
            }
            var date;
            if (today_left) {
                date = new Date(self.today);
            }
            else {
                date = new Date(self.today);
                date.setDate(date.getDate()-6);
            }
            date = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0,0,0);
            var additional_classes, parsed_date;
            $('#day_select').empty();
            for (var i =0; i < 7; i++) {
                //add date
                parsed_date = Date.parse(date);
                additional_classes = [];
                if (date.getDate() == (new Date(self.today)).getDate()) {
                    additional_classes.push('selected');
                }
                if (self.changed_days[parsed_date] == true) {
                    additional_classes.push('changed');
                }
                var large = gettext("%weekday %month %date")
                    .replace("%weekday", days[date.getDay()])
                    .replace("%date", date.getDate())
                    .replace("%month", months[date.getMonth()]);

                $('#schedule_day_option_tmpl').tmpl2({
                    'large': large,
                    'date':date,
                    'parsed_date':parsed_date,
                    'additional_classes':additional_classes
                }).appendTo($('#day_select'));
                date.setDate(date.getDate() + 1); //tomorrow
            }
        }
    }

    function update_draw_settings() {
        var tmp_width_settings = $('#zoom_value').text();
        var tmp_start_time_settings = $('#start_time_select').val();
        if (tmp_start_time_settings !== undefined) {
            self.start_time_settings = tmp_start_time_settings;
        }
        if (tmp_width_settings !== undefined) {
            self.draw_settings.width_settings = tmp_width_settings;
        }
        $('#scheduler_container').css('width',self.draw_settings.width_settings);
        $('#scheduler_date_line_container').css('width',self.draw_settings.width_settings);
        document.getElementById('scheduler_display').scrollLeft = $('.time_entry[time='+self.start_time_settings+']').position().left;
        document.getElementById('scheduler_date_line_display').scrollLeft = document.getElementById('scheduler_display').scrollLeft;
        $.cookie('write', self.start_time_settings_cookie, self.start_time_settings, 7);
        $.cookie('write', self.width_settings_cookie, self.draw_settings.width_settings, 7);
        determine_pixel_depth();
    }

    function get_server_schedules(server_id, dont_redraw) {
        var tmp = new Date(self.today);
        var time_begin = tmp.getFullYear()+'-'+(tmp.getMonth()+1)+'-'+tmp.getDate()+' 04:00:00';
        tmp.setDate(tmp.getDate()+1); //tomorrow
        var time_end = tmp.getFullYear()+'-'+(tmp.getMonth()+1)+'-'+tmp.getDate()+' 04:00:00';

        // Loader fun
        self.schedule_servers[server_id].loader.hide();
        self.schedule_servers[server_id].sync_loader.hide();
        if( self.schedule_servers[server_id].initial_sync_complete == true){
            self.schedule_servers[server_id].loader.show();
        }
        else if (self.schedule_servers[server_id].status != "error"){
            self.schedule_servers[server_id].sync_loader.show();
        }

        //We must check if a call to this server is already currently in progress, if it is we must "abort" it
        if(self.schedule_calls[server_id]){
            self.schedule_calls[server_id].abort();
        }
        self.schedule_calls[server_id] = helpers.ajax_call({
            url: '/core/scheduling/schedule',
            data: {
                device_uuids:[server_id],
                start_time:time_begin,
                end_time:time_end
            },
            complete_variables: {
                server_id : server_id,
                dont_redraw : dont_redraw,
            },
            success_function: function(input, complete_variables){
                // In case user navigates away from page before this is called
                if(self.schedule_servers[server_id]) {
                    self.schedule_servers[server_id].loader.hide();
                    update_schedule_information(input, complete_variables);
                }
                delete self.schedule_calls[server_id];
            }
        });
    }

    function get_tmp_id(server_id, uuid) {
        return self.schedule_servers[server_id].core_id_to_tmp_id[uuid];
    }

    function update_schedule_information(input, complete_variables){
        //this is a bit hacky
        var server_id = complete_variables.server_id;
        var date_parts, calendar_parts, clock_parts, start_time;
        var today_schedules = self.schedule_servers[server_id].get_todays_schedules(true);
        //this list is created to keep track of schedules that might have been removed since the update_scheudle_information has last been called for this day.
        var delete_me = [];
        for (var index in today_schedules.schedules) {
            delete_me.push(today_schedules.schedules[index].tmp_id);
        }
        for (var schedule_uuid in input.data) {
            var tmp_schedule = input.data[schedule_uuid];
            if (tmp_schedule.device_information.device_uuid == null) {
                continue;
            }
            calendar_parts = tmp_schedule.start_date.split('-');
            clock_parts = tmp_schedule.start_time.split(':');
            start_time = new Date(calendar_parts[0],calendar_parts[1]-1,calendar_parts[2],clock_parts[0],clock_parts[1],clock_parts[2]);
            var tmp_id = get_tmp_id(server_id, tmp_schedule.uuid);

            if (tmp_id) {
                if (delete_me.indexOf(tmp_id)!=-1) {
                    delete_me.splice(delete_me.indexOf(tmp_id),1);
                }
            }
            else {
                var source = server_id;

                // POS
                var pos_title = tmp_schedule.pos_information !== undefined ? tmp_schedule.pos_information.feature_title : null;
                var pos_id = tmp_schedule.pos_information !== undefined ? tmp_schedule.pos_information.pos_id : null;
                var pos_duration = tmp_schedule.pos_information !== undefined ? tmp_schedule.pos_information.pos_duration : null;
                var pos_unassigned = tmp_schedule.pos_information !== undefined ? tmp_schedule.pos_information.pos_unassigned : null;
                var pos_pending = (!pos_unassigned) && (tmp_schedule.source_playlist_uuid !== null) && !(new Date() > new Date(tmp_schedule.start_timestamp*1000)) && (pos_id !== undefined) && ((tmp_schedule.device_information.device_schedule_id === undefined) || (self.pos_pending_sessions[pos_id] !== undefined ));
                var show_attributes = tmp_schedule.pos_information !== undefined ? tmp_schedule.pos_information.show_attributes : null;
                var seats_sold = tmp_schedule.pos_information !== undefined ? tmp_schedule.pos_information.seats_sold : null;
                if(pos_pending){
                    self.pos_pending_sessions[pos_id] = true;
                }
                var tmp = new Schedule({
                    'start_time':start_time,
                    'server_id':server_id,

                    'type': 'playlist',
                    'spl_id':tmp_schedule.device_information.device_playlist_uuid,
                    'spl_duration':tmp_schedule.device_information.device_playlist_duration,
                    'spl_name': _resolve_display_name(tmp_schedule.display_name),

                    'placeholder_type':tmp_schedule.placeholder_information.placeholder_type,
                    'placeholder_duration':tmp_schedule.placeholder_information.placeholder_duration,

                    'device_schedule_id': tmp_schedule.device_information.device_schedule_id,

                    'source_spl_id':tmp_schedule.type=="pos" ? tmp_schedule.template_information.source_playlist_uuid : null,
                    'print_no':tmp_schedule.template_information.print_no,

                    'pos_title': pos_title,
                    'pos_id':pos_id,
                    'pos_duration':pos_duration,
                    'pos_unassigned':pos_unassigned,
                    'pos_pending':pos_pending,
                    'show_attributes':show_attributes,
                    'seats_sold': seats_sold,

                    'schedule_type':tmp_schedule.type,

                    'source':source,
                    'saved':true,
                    'schedule_id':tmp_schedule.uuid,
                    'kdm_problem':tmp_schedule.kdm_issue,
                    'content_problem':tmp_schedule.content_issue,
                    'playlist_problem':tmp_schedule.playlist_issue,
                    'schedule_problem':tmp_schedule.schedule_issue,
                    'templating_issues':tmp_schedule.templating_issues,

                    'has_show_start': tmp_schedule.has_show_start || false,
                    'has_intermission': tmp_schedule.has_intermission || false,
                    'show_start_offset': tmp_schedule.show_start_offset || 0,
                });
                schedule_page.schedule_servers[tmp.server_id].core_id_to_tmp_id[tmp.schedule_id] = tmp.tmp_id;
                self.schedule_servers[server_id].add_schedule(tmp);
            }

        }
        for (var i =0; i < delete_me.length; i++) {
            var tmp_id = delete_me[i];
            //clear its conflicts.
            self.clear_conflicts(server_id, tmp_id, true);
            //remove it from active schedules
            delete self.schedule_servers[server_id].schedules[tmp_id];
            //remove it from deleted schedules
            delete self.schedule_servers[server_id].deleted_ids[tmp_id];
            //now its as if it were never there.
        }
        if( complete_variables.dont_redraw != true ){
            draw_schedules(server_id);
            $('.scheduler_row[server_id='+server_id+'] > .loading').remove();
            get_general_info();
            create_pos_drop_targets(server_id);
        }
    }

    function create_pos_drop_targets(server_id){
        // Create POS drop targets
        $('.scheduler_row[server_id="' + server_id + '"] .disabled.pos_schedule').droppable({
            greedy: true,
            accept:'.jq_drag_source',
            drop:function(event, ui){
               _pos_drop($(this).attr('server_id'), event, ui);
            },
            hoverClass:'pos_hover',
        });
    }

    function _pos_drop(server_id, event, ui){
        if(self.dragging_sched.type == 'title'){
            notification.info_msg(gettext('Titles cannot be manually mapped to POS sessions'), gettext('Map Playlists'));
        }
        else if($device_store.get_lms_uuid() == self.dragging_sched.source){
            var pos_id = $(event.target).attr("pos_id");
            var spl_id = self.dragging_sched.spl_id;
            var spl_name = self.dragging_sched.spl_name;

            // update schedule dom
            $(event.target).removeClass("disabled").addClass("unsaved");
            $(event.target).find(".unmapped_overlay").hide();
            $(event.target).find(".spl_name").html(spl_name);

            changes_made_function(true);
            self.pos_update_map[pos_id] = {"playlist_id":spl_id,"placeholder_type":null,"spl_name":spl_name,"state":"assigned"};
        }
        else{
            notification.info_msg(gettext('Only LMS playlists can be mapped to POS sessions'), gettext('Map Playlists'));
        }
    }

    function clear_schedules(server_id){
        if(server_id == 'all'){
            for (var server_id in self.schedule_servers) {
                if (!self.schedule_servers[server_id].is_lms) {
                    $('#scheduler_container .jq_schedule_item[server_id='+server_id+']').remove();
                }
            }
        }else{
            $('#scheduler_container .jq_schedule_item[server_id='+server_id+']').remove();
        }
    }

    function draw_schedules(server_id) {        
        determine_pixel_depth();
        self.draw_settings.size_ratio = (self.scheduler_dom.innerWidth() - 22) / ($('#main_section').outerWidth() + 0.0);
        clear_schedules(server_id);
        var tmp = self.schedule_servers[server_id].get_todays_schedules(true);
        self.schedule_servers[server_id].progress_time_line();
        var to_draw = [];
        for(var i = 0; i < tmp.schedules.length; i++){
            to_draw.push(get_schedule_dom(tmp.schedules[i]));
        }
        for(var i = 0; i < tmp.tmp_schedules.length; i++){
            to_draw.push(get_schedule_dom(tmp.tmp_schedules[i]));
        }
        var scheduler_row = $('.scheduler_row[server_id='+server_id+']');
        // Replace the first rows show start tips with qtips to deal with overflow issues
        if(scheduler_row.is(":first-child")){
            $.each(to_draw, function(index, dom){
                attach_show_start_tip($(dom));
            });
        }
        scheduler_row.append(to_draw);
        var sch_doms = scheduler_row.find('.jq_drag_source');
        make_draggable(sch_doms, false);
        create_pos_drop_targets(server_id);
        if(self.preselected_pos_schedule_uuid !== undefined && self.preselected_selected != true){
            $(".jq_schedule_item[pos_id='" + self.preselected_pos_schedule_uuid + "']").click();
        }
    }

    function attach_show_start_tip(dom){
        var tip_content = dom.find(".show_start_time_tip").children();
        if(tip_content.length){
            dom.qtip({
                content: tip_content,
                position: {
                    my: 'bottom left',
                    at: 'top left',
                    adjust: {
                        y: -7
                    }
                },
                show: {
                    effect: false
                },
                hide: {
                    fixed: true,
                    effect: false
                },
                style: {
                    classes: 'show_start_qtip',
                    tip: false
                }
            })   
        }
    }

    function get_general_info() {
        var date = new Date(self.today);
        var output = {
            'schedules_with_problem':[],
            'content_issues':[],
            'other_issues':[],
            'kdm_issues':[],
            'conflict_issues':[],
            'unsaved':[],
            'current_date' : date.getFullYear()+'-'+$.time_helper(date.getMonth()+1)+'-'+$.time_helper(date.getDate())
        };
        for (var server_id in self.schedule_servers) {
            if (!self.schedule_servers[server_id].is_lms) {
                var todays_schedules = self.schedule_servers[server_id].get_todays_schedules();
                var server_problems = 0;
                for (var i =0; i< todays_schedules.schedules.length; i++) {
                    var tmp = todays_schedules.schedules[i];
                    var schedule_problem = false;
                    if (tmp.kdm_problem) {
                        output.kdm_issues.push(tmp);
                        schedule_problem = true;
                    }
                    if (tmp.content_problem) {
                        output.content_issues.push(tmp);
                        schedule_problem = true;
                    }
                    if (tmp.other_problem) {
                        output.other_issues.push(tmp);
                        schedule_problem = true;
                    }
                    if (!$.is_empty(tmp.conflict) || !$.is_empty(tmp.tmp_conflict)) {
                        output.conflict_issues.push(tmp);
                        schedule_problem = true;
                    }
                    if (tmp.kdm_problem || tmp.content_problem || tmp.other_problem ||!$.is_empty(tmp.conflict) || !$.is_empty(tmp.tmp_conflict)) {
                        server_problems +=1;
                    }
                    if (schedule_problem == true){
                        output.schedules_with_problem.push(tmp);
                    }
                }

                for (var i = 0; i < todays_schedules.tmp_schedules.length; i++) {
                    var tmp = todays_schedules.tmp_schedules[i];
                    output.unsaved.push(tmp);
                    if (!$.is_empty(tmp.conflict) || !$.is_empty(tmp.tmp_conflict)) {
                        output.conflict_issues.push(tmp);
                    }
                    if (!$.is_empty(tmp.conflict) || !$.is_empty(tmp.tmp_conflict)) {
                        server_problems +=1;
                    }
                }
                var server_error_count_div = $('#scheduler_screen_container > .scheduler_screen_row[server_id='+server_id+'] >.scheduler_error_count');
                var server_schedule_container = $('#scheduler_container > .scheduler_row[server_id='+server_id+']');
                server_error_count_div.html(server_problems);
                if (server_problems == 0) {
                    server_error_count_div.hide();
                    server_schedule_container.toggleClass('has_errors',false);
                }
                else {
                    server_error_count_div.show();
                    server_schedule_container.toggleClass('has_errors',true);
                }

            }
        }

        return output;
    }

    self.conflict_check = function(server_id, tmp_id, saved) {
        tmp_id = tmp_id + '';
        var schedule;
        var tmp_schedule = false;
        if (saved === 'true'|| saved === true) {
            schedule = self.schedule_servers[server_id].schedules[tmp_id];
            if (schedule.is_deleted()) {
                return;
            }
        }
        else {
            tmp_schedule = true;
            schedule = self.schedule_servers[server_id].tmp_schedules[tmp_id];
        }

        var start = Date.parse(schedule.start_time);
        var duration = schedule.display_duration;
        var end   = start + duration*1000;

        self.clear_conflicts(server_id, tmp_id, saved);

        //establish new conflicts
        for (var i_id in self.schedule_servers[server_id].schedules) {
            if (!self.schedule_servers[server_id].schedules[i_id].is_deleted() && i_id !== tmp_id) {
                var tmp = self.schedule_servers[server_id].schedules[i_id];
                var tmp_start = Date.parse(tmp.start_time);
                var tmp_duration = tmp.display_duration;
                var tmp_end   = tmp_start + tmp_duration*1000;
                if ((tmp_start <= start && tmp_end >= start)|| (start <= tmp_start && end >= tmp_start)) {
                    if (tmp_schedule) {
                        tmp.tmp_conflict[tmp_id] = true;
                    }
                    else {
                        tmp.conflict[tmp_id] = true;
                    }
                    schedule.conflict[i_id] = true;
                }
            }
        }

        for (var t_id in self.schedule_servers[server_id].tmp_schedules) {
            if (t_id !== tmp_id) {
                var tmp = self.schedule_servers[server_id].tmp_schedules[t_id];
                var tmp_start = Date.parse(tmp.start_time);
                var tmp_end = tmp_start + tmp.display_duration*1000;
                if ((tmp_start <= start && tmp_end >= start)|| (start <= tmp_start && end >= tmp_start)) {
                    if (tmp_schedule) {
                        tmp.tmp_conflict[tmp_id] = true;
                    }
                    else {
                        tmp.conflict[tmp_id] = true;
                    }
                    schedule.tmp_conflict[t_id] = true;
                }
            }
        }
    };

    // I am unhappy with this function
    self.clear_conflicts = function(server_id, tmp_id, saved) {
        var schedule;
        var tmp_schedule = false;
        if (saved === 'true' || saved=== true) {
            schedule = self.schedule_servers[server_id].schedules[tmp_id];
        }
        else {
            tmp_schedule = true;
            schedule = self.schedule_servers[server_id].tmp_schedules[tmp_id];
        }

        //remove_previous conflicts
        for (var t_id in schedule.tmp_conflict) {
            if(!self.schedule_servers[server_id].tmp_schedules[t_id]){
                continue;
            }
            if (tmp_schedule) {
                delete self.schedule_servers[server_id].tmp_schedules[t_id].tmp_conflict[tmp_id];
            }
            else {
                delete self.schedule_servers[server_id].tmp_schedules[t_id].conflict[tmp_id];
            }
        }
        schedule.tmp_conflict = {};
        for (var s_id in schedule.conflict) {
            if(!self.schedule_servers[server_id].schedules[s_id]){
                continue;
            }
            if (tmp_schedule) {
                delete self.schedule_servers[server_id].schedules[s_id].tmp_conflict[tmp_id];
            }
            else {
                delete self.schedule_servers[server_id].schedules[s_id].conflict[tmp_id];
            }
        }
        schedule.conflict = {};
    };

    function get_schedule_dom(schedule) {
        var schedule_obj = $.extend({
                placeholder_type : ""
            },
            schedule,
            self.draw_settings
        );
        schedule_obj.pos_pending = self.pos_pending_sessions[schedule_obj.pos_id] !== undefined ? true : false;
        var schedule_dom = gen_schedule_dom(schedule_obj);
        schedule_obj.setup_show_start(schedule_dom, schedule_obj.start_time);

        schedule_dom.css('left', helpers.date_stamp_to_position(schedule.start_time, self.pixel_offset, self.draw_settings.pixel_depth) + '%');

        return schedule_dom;
    }

    function gen_schedule_dom(schedule){
        var schedule_for_drawing = process_schedule_for_drawing(schedule);
        var schedule_dom = $('#schedule_display_template').tmpl2(schedule_for_drawing);
        return schedule_dom;
    }

    function process_schedule_for_drawing(schedule) {
        var sch = $.extend({'pos_id': schedule.pos_id}, schedule);
        var width  = sch.display_duration*1000*sch.pixel_depth;
        if (sch.start_time !== undefined){
            sch.display_start_time = $.time_helper(sch.start_time.getHours()) + ':' + $.time_helper(sch.start_time.getMinutes());
        }
        else{
            sch.display_start_time = '&nbsp';
        }
        if (sch.display_show_start !== undefined) {
            sch.display_show_start = $.time_helper(sch.display_show_start.getHours()) + ':' + $.time_helper(sch.display_show_start.getMinutes());
        }
        else {
            sch.display_show_start = '&nbsp;';
        }
        if (sch.end_time !== undefined) {
            sch.end_time = $.time_helper(sch.end_time.getHours()) + ':' + $.time_helper(sch.end_time.getMinutes());
        }
        else {
            sch.end_time = '&nbsp;';
        }
        if ((sch.dragging == true) && (sch.pos_id === '' || sch.pos_id === undefined)) {
            width *= parseInt(sch.width_settings.replace(/%/,''),10)/100 * (sch.size_ratio);
        }
        if(sch.show_type === undefined){
            sch.show_type = null;
        }
        sch.width = width;
        sch.placeholder_width = sch.placeholder_duration/sch.display_duration * 100;

        sch.conflicting = !$.is_empty(sch.conflict)||!$.is_empty(sch.tmp_conflict);
        sch.pos_pending = !!sch.pos_pending;
        sch.is_pos = !!sch.pos_id;
        sch.state = sch.state();

        var spl_name = sch.spl_name;
        var time_title = sch.spl_name + ": " + sch.display_start_time + "-" + sch.end_time;

        if(sch.is_pos && sch.state != "disabled"){
            time_title = gettext('Shift + Click to resync');
        }

        if(sch.pos_pending && self.pos_update_map[sch.pos_id] === undefined){
            if(sch.pos_unassigned){
                spl_name = gettext("Pending");
            }
            else{
                spl_name = gettext("Scheduling");
            }
        }
        else if(placeholder_types[sch.spl_name] !== undefined){
            spl_name = placeholder_types[sch.spl_name];
        }
        else if(sch.pos_id !== undefined && self.pos_update_map[sch.pos_id] !== undefined){
            spl_name = self.pos_update_map[sch.pos_id].spl_name;
        }

        sch.spl_name = spl_name;
        sch.time_title = time_title;

        var classes = [];

        if(sch.state == 'disabled' && self.pos_update_map[sch.pos_id]){
            classes.push("unsaved");
        }
        else{
            classes.push(sch.state);
        }

        if(sch.state != 'disabled'){
            classes.push("jq_drag_source");
        }
        if(sch.placeholder_type && sch.device_schedule_id === undefined){
            classes.push("placeholder_" + sch.placeholder_type);
        }
        if(sch.is_pos){
            classes.push("pos_schedule");
        }
        if(sch.conflicting){
            classes.push("conflicting");
        }
        if(sch.dragging){
            classes.push("dragging");
        }
        if(sch.has_show_start){
            classes.push("schedule_show_start");
        }
        if(sch.show_type_colour){
            classes.push("schedule_show_type_color_" + sch.show_type_colour);
        }

        sch.classes = classes;

        sch.placeholder_type = sch.placeholder_type;
        return sch;
    }

    var scroll_interval = null;

    function start_autoscroll(){
        // Determine scheduler bounds
        self.scheduler_bounds = {
            top: self.scheduler_dom.offset().top + 35,
            bottom: self.scheduler_dom.offset().top + self.scheduler_dom.innerHeight() - 35,
            left: self.scheduler_dom.offset().left + 35,
            right: self.scheduler_dom.offset().left + self.scheduler_dom.innerWidth() - 35
        };
        $(document).on('mousemove', function(e){
            overscroll(e.pageX, e.pageY);
        });
    }

    function stop_autoscroll(){
        $(document).off('mousemove');
        clearInterval(scroll_interval);
    }

    function overscroll(x, y){
        clearInterval(scroll_interval);
        var scroll_x = null;
        var scroll_y = null;

        var bounds = self.scheduler_bounds;

        var left = x;
        var top = y;

        // If we are overscrolling to the left
        if(left < bounds.left){
            scroll_x = left - bounds.left;
        }
        // If we are overscrolling to the right
        else if(left > bounds.right){
            scroll_x = left - bounds.right;
        }

        // If we are overscrolling to the bottom
        if(top > bounds.bottom){
            scroll_y = top - bounds.bottom;
        }
        // If we are overscrolling to the top
        else if(top < bounds.top){
            scroll_y = top - bounds.top;
        }

        if(scroll_x || scroll_y){
            autoscroll(scroll_x, scroll_y);
            scroll_interval = setInterval(function(){
                autoscroll(scroll_x, scroll_y);
            }, 50);
        }
    }

    function autoscroll(x, y){
        if(x){
            self.scheduler_dom[0].scrollLeft += parseInt(x, 10);
        }
        if(y){
            self.scheduler_dom[0].scrollTop += parseInt(y, 10);
        }
    }

    function update_moving_schedule(helper){
        var sched_obj = self.dragging_sched;
        var drop_target = $('.scheduler_row.hover');
        if(drop_target.length == 0){
            drop_target = $('.scheduler_row:first-child');
            helper.toggleClass('active', false);
        }
        else{
            helper.toggleClass('active', true);
        }

        var helper_offset = helper.offset();
        var offset = (helper_offset.left + drop_target.scrollLeft() - drop_target.offset().left) * 100 / drop_target.innerWidth();

        var time = new Date(offset/self.draw_settings.pixel_depth + self.pixel_offset);
        time.setSeconds(0); // Most likely desired start seconds
        sched_obj.update_start_time(helper, time);
    }

    function make_draggable(elements, from_top) {
        var auto_scroll_interval = null;
        elements.draggable({
            helper : function() {
                var sch_dom = $(this);
                var template_overule = {};
                var sched_data = sch_dom.data();
                //We give the schedule constructor a fake time as it's going to be updated immediately by update_moving_schedule.
                sched_data.start_time = new Date();
                //the helper is the item that we drag around, we clone so that the item that initiated the drag stays in place, width settings are display only
                //If this is already a schedule item - get it from one of the two stores
                if(sch_dom.hasClass('jq_schedule_item')){
                    self.dragging_sched = sched_obj_from_dom(sch_dom);
                    sch_dom.addClass('getting_moved');
                }
                else if(sch_dom.hasClass('jq_schedule_playlist')){
                    //SCHEDULE ITEM ROUTE
                    var item = self.current_item_list.get_item(sch_dom.attr("data-index"));
                    $.extend(
                        sched_data,
                        {
                            'spl_name' : item.text,
                            'spl_duration' : item.duration,
                            'source_spl_id' : item.uuid,
                            'display_duration' : item.duration,
                            'has_intermission': item.has_intermission,
                            'has_show_start' : item.has_show_start,
                            'show_start_offset' : item.show_start_offset
                        }
                    );
                    self.dragging_sched = new Schedule(sched_data);
                }
                else{
                    //PLACEHOLDER ROUTE
                    self.dragging_sched = new Schedule(sched_data);
                }
                var sched_obj = $.extend({
                        'placeholder_type' : ""
                    },
                    self.dragging_sched,
                    self.draw_settings, {
                        'has_show_start': self.dragging_sched.has_show_start == 'true',
                        'conflicting': false,
                        'dragging': true,
                        'saved': false,
                    }
                );
                sched_obj.pos_pending = self.pos_pending_sessions[sched_obj.pos_id] !== undefined ? true : false;

                start_autoscroll();

                var schedule_dom = gen_schedule_dom(sched_obj);
                return schedule_dom.addClass('schedule_dragging').addClass("schedule_item_" + sched_obj['type']);
            },
            scroll: false,
            axis: 'x',
            appendTo : 'parent',
            containment : 'parent',
            drag: function(event, ui){
                var helper = $(ui.helper[0]);
                update_moving_schedule(helper);
            },
            start: function(event, ui) {
                $('#scheduler').addClass('drag_active');
                var helper = $(ui.helper[0]);
                self.dragging_sched.setup_show_start(helper);
            },
            stop: function(event, ui){
                // asojdfapsojdfpojdf.asdfaspdfkoasdf();
                $('.schedule_item.getting_moved').toggleClass('getting_moved',false);
                $('#scheduler').removeClass('drag_active');
                stop_autoscroll();
            }
        });
        if (from_top) {
            elements.draggable("option", "cursorAt", { left: 0 });
        }
        elements.each(function(index){
            if($(this).attr('pos_id') == '' || $(this).attr('pos_id') === undefined){
                $(this).draggable("option", "axis", false);
                $(this).draggable("option", "appendTo", '#main_section');
            }
        });
    }

    self._mark_change_days = function(schedule)  {
        var date = new Date(schedule.start_time.getTime());
        if (date.getHours() < 4)  {
            date = new Date();
            date.setDate(date.getDate()-1); //we're in yesterday
        }
        var changed_day = Date.parse(new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0,0,0));
        self.__mark_change_days(changed_day);
    };

    self.__mark_change_days = function(changed_day) {
        self.changed_days[changed_day] = true;
        changes_made_function(true);
    };

    function check_changes_made() {
        var server_id, server, changes_made;
        changes_made = false;
        for (server_id in self.schedule_servers) {
            server = self.schedule_servers[server_id];
            if (!$.isEmptyObject(server.tmp_schedules) || !$.isEmptyObject(server.deleted_days) || !$.isEmptyObject(server.deleted_ids)) {
                changes_made = true;
                break;
            }
        }
        if( !changes_made ){
            changes_made = !$.isEmptyObject(self.pos_update_map);
        }
        changes_made_function(changes_made);
    }

    function changes_made_function(value) {
        self.changes_made = value;
        $('.jq_enable_on_select').toggleClass('ui-state-disabled', !self.changes_made);
        $('.day_option.selected').toggleClass('changed', self.changes_made);
        g_prevent_navigation = value;
    }

    function redraw(redraw_me) {
        for (var server_id in self.schedule_servers) {
            if (redraw_me === undefined || server_id == redraw_me) {
                if (! self.schedule_servers[server_id].is_lms) {
                    draw_schedules(server_id);
                }
            }
        }
        create_day_options();
        draw_general_info();
    }

    function draw_general_info(){
        if($('.section_toggle_open.selected').attr('data_open_menu') != "general")
            return;
        $('#general_info_template').tmpl2(get_general_info(), '#schedule_actions_options');
        $('#schedule_config_general_head > .submenu').on('click',select_general_section_menu);
        $('#schedule_config_general_head > .submenu[show='+self.selected_sub_menu+']').click();
        $('.schedule_issue').click(function(){select_schedule(this);});
    }

    function select_day_by_difference() {
        var new_day = new Date(self.today);
        new_day.setDate(new_day.getDate()+parseInt($(this).attr('difference'),10));

        select_day(Date.parse(new_day));
    }

    function select_day(parsed_date) {
        $("#scheduler_container div.jq_schedule_item").remove();
        self.today = parseInt(parsed_date,10);
        self.copy_from_date = $.datepicker.formatDate('yy-mm-dd', new Date(self.today));
        create_day_options();
        clear_schedules();
        for (var server_id in self.schedule_servers) {
            if (!self.schedule_servers[server_id].is_lms) {
                get_server_schedules(server_id);
            }
        }
        var open_tab = $('#schedule_actions_nav li.selected').attr('data_open_menu');
        if($('#schedule_section').hasClass("open") && $.inArray(open_tab, ['swap', 'repeat', 'general']) != -1){
            select_menu(open_tab);
        }
    }

    function disable_enable_swap_selects() {
        var _1 = $('#schedule_config_swap .screen_selector input[name=swap_partner_1]:checked').val();
        var _2 = $('#schedule_config_swap .screen_selector input[name=swap_partner_2]:checked').val();

        $('#schedule_config_swap .screen_selector input').button("enable");

        $('#schedule_config_swap .screen_selector input[name=swap_partner_2][value='+_1+']').attr('checked', false).button('disable').button('refresh');
    }

    function swap_schedules() {
        $('#swap_schedule_button').button("option", "disabled", true);
        var swap_1 = $('input[name=swap_partner_1]:checked').val();
        var swap_2 = $('input[name=swap_partner_2]:checked').val();

        if(swap_1 === undefined || swap_2 === undefined){
            notification.info_msg(gettext('Select two servers to swap their schedules for the current day'), gettext('Swap Schedules'));
            return;
        }

        var swap_servers = [swap_1, swap_2];

        //Show loaders
        for (var i =0; i < swap_servers.length; i++) {
            self.schedule_servers[swap_servers[i]].loader.show();
        }

        var tomorrow = new Date(self.today);
        tomorrow.setHours(tomorrow.getHours() + 28);

        var today_start = new Date(self.today);
        today_start.setHours(today_start.getHours() + 4)

        //gather
        var swap_pos_attempt_flag = false;
        var swap_list = [[],[]];

        // handle saved schedules
        for (var i = 0; i < swap_servers.length; i++) {
            var target = self.schedule_servers[swap_servers[(i+1)%2]];
            for (var tmp_id in self.schedule_servers[swap_servers[i]].schedules) {
                if (self.schedule_servers[swap_servers[i]].deleted_ids[tmp_id]!==true) {
                    var tmp = self.schedule_servers[swap_servers[i]].schedules[tmp_id];
                    if (tmp.start_time >= today_start && tmp.start_time >= target.time && tmp.start_time < tomorrow) {
                        if (tmp.pos_id === undefined) {
                            swap_list[i].push(tmp);
                        } else {
                            swap_pos_attempt_flag = true;
                        }
                    }
                }
            }
        }
        //Handles tmp schedules
        for (var i = 0; i < swap_servers.length; i++) {
            var target = self.schedule_servers[swap_servers[(i+1)%2]];
            for (var tmp_id in self.schedule_servers[swap_servers[i]].tmp_schedules) {
                var tmp = self.schedule_servers[swap_servers[i]].tmp_schedules[tmp_id];
                if (tmp.start_time >= today_start && tmp.start_time >= target.time && tmp.start_time < tomorrow) {
                    if (tmp.pos_id === undefined) {
                        swap_list[i].push(tmp);
                    } else {
                        swap_pos_attempt_flag = true;
                    }
                }
            }
        }

        if (swap_pos_attempt_flag) {
            notification.info_msg(gettext('Cannot schedule a POS schedule on another server'));
        }

        var actions = [];

        //add
        for (var i = 0; i < swap_servers.length; i++) {
            var source = swap_servers[(i+1)%2];
            var server_id = swap_servers[i];
            for (var j = 0; j < swap_list[(i+1)%2].length; j++) {
                var tmp = swap_list[(i+1)%2][j];
                actions.push(update_schedule(tmp, {'server_id': server_id}));
            }
        }

        $.when(actions).done(function(){
            //Hide loaders
            for (var i =0; i < swap_servers.length; i++) {
                self.schedule_servers[swap_servers[i]].loader.hide();
            }
            $('#swap_schedule_button').button("option", "disabled", false);
        });
    }

    function initialize_repeat_section() {
        $('#repeat_day_server_selection input').button();
        self.repeat_day_options = {};

        $('#repeat_day_selection').datepicker({
            onSelect:function(selected_day){
                addOrRemoveDate(self.repeat_day_options, selected_day);
            },
            defaultDate: self.copy_from_date,
            dateFormat:'yy-mm-dd',
            minDate: new Date(),
            beforeShowDay: function(date){
                var date_formatted = $.datepicker.formatDate($(this).datepicker('option', 'dateFormat'), date);
                if (self.copy_from_date == date_formatted) {
                    return [true,"ui-state-from"];
                }
                if (self.repeat_day_options[date_formatted] == true) {
                    return [true,"ui-state-to"];
                }
                return [true, "no_class"];
            }
        });
    }

    function repeat_schedules(){
        $('#repeat_schedule_button').button("option", "disabled", true);
        var dates = [];
        var tmp_date, tmp;
        for (tmp in self.repeat_day_options) {
            if (self.repeat_day_options[tmp]) {
                tmp_date = tmp.split(/-/g);
                dates.push(tmp_date);
                self.__mark_change_days(Date.parse(new Date(tmp_date[0],parseInt(tmp_date[1],10)-1, tmp_date[2], 0,0,0)));
            }
        }

        var date = new Date(self.today);
        date.setHours(date.getHours()+4);
        var tomorrow = new Date(self.today);
        tomorrow.setHours(date.getHours()+28);
        var selected_servers = [];
        $('.repeat_check:checked').each(function(){
            selected_servers.push($(this).val());
        });
        var repeat_pos_attempt_flag = false;
        var actions = [];
        for (var k =0 ; k < selected_servers.length; k++) {
            var server_id = selected_servers[k];
            //Show loaders
            self.schedule_servers[server_id].loader.show();

            if (!self.schedule_servers[server_id].is_lms) {
                //mark day for deletion
                var todays_schedules = self.schedule_servers[server_id].get_todays_schedules();
                for (var j = 0; j < dates.length; j++) {
                    //mark the selected day for deletion on the server
                    var server_delete_date = new Date(date.getTime());

                    server_delete_date.setFullYear(dates[j][0]);
                    server_delete_date.setDate(1);
                    server_delete_date.setMonth(parseInt(dates[j][1],10)-1);
                    server_delete_date.setDate(dates[j][2]);
                    self.schedule_servers[server_id].delete_day(server_delete_date);

                    function prepare_repeats(schedules){
                        for (var i =0; i< schedules.length; i++) {
                            var tmp = schedules[i];
                            if (tmp.pos_id !== undefined) {
                                repeat_pos_attempt_flag = true;
                                continue; //marked as undefined because we do not want to be repeating pos stuff really
                            }
                            //set the correct offset
                            var tmp_date = new Date(tmp.start_time.getTime());
                            tmp_date.setFullYear(dates[j][0]);
                            tmp_date.setDate(1);
                            tmp_date.setMonth(parseInt(dates[j][1],10)-1);
                            tmp_date.setDate(dates[j][2]);
                            //if the day was after midnight, add an extra day
                            if (tmp.start_time.getDate() != date.getDate()) {
                                tmp_date.setDate(tmp_date.getDate()+1);
                            }
                            actions.push(
                                duplicate_schedule(tmp, tmp_date)
                            );
                        }
                    }
                    prepare_repeats(todays_schedules.schedules);
                    prepare_repeats(todays_schedules.tmp_schedules);
                }
            }
        }
        if (repeat_pos_attempt_flag) {
            notification.info_msg(gettext('POS sessions cannot be repeated'));
        }
        $.when.apply(undefined, actions).then(function() {
            for(var i in selected_servers){
                self.schedule_servers[selected_servers[i]].loader.hide();
            }
            var message, id;
            if(dates.length > 0 && selected_servers.length > 0){
                message = gettext('Click Repeat to confirm changes').replace(/%date_length/, dates.length);
                id = "repeat_success";
            }
            else{
                message = gettext('Select days and servers and click Repeat');
                id = "repeat_fail";
            }

            $('#repeate_schedule_confirmation_template').tmpl2({
                'id': id,
                'message': message
            }, '#repeat_schedule_confirmation');
            redraw();
            $('#repeat_schedule_button').button("option", "disabled", false);
        });
    }

    function duplicate_schedule(schedule, date){
        // Create a tmp schedule and add it to the server, then pass it to the update function
        var tmp = schedule.get_temp();
        self.tmp_schedule_id_counter += 1;
        tmp.tmp_id = self.tmp_schedule_id_counter;
        self.schedule_servers[schedule.server_id].tmp_schedules[tmp.tmp_id] = tmp;
        return update_schedule(tmp, {'date': date});
    }

    function addOrRemoveDate(day_options, selected_day) {
        if (selected_day != self.copy_from_date) {
            if (day_options[selected_day] == true){
                day_options[selected_day] = false;
            }
            else {
                day_options[selected_day] = true;
            }
        }
    }

    function select_general_section_menu() {
        var x = $(this);
        x.toggleClass('selected',true);
        x.siblings().toggleClass('selected',false);
        var y = $(x.attr('show'));
        y.siblings().hide();
        y.show();
        self.selected_sub_menu = x.attr('show');
    }

    function undo_changes() {
        self.pos_update_map = {};
        self.pos_pending_sessions = {};
        if ($(this).hasClass('ui-state-disabled')) {
            notification.info_msg(gettext("There are no changes"));
            return;
        }
        for (var server_id in self.schedule_servers) {
            if (!self.schedule_servers[server_id].is_lms) {
                self.schedule_servers[server_id].tmp_schedules = {};
                self.schedule_servers[server_id].deleted_ids = {};
                self.schedule_servers[server_id].deleted_days = {};
                for (var tmp_id in self.schedule_servers[server_id].schedules) {
                    self.schedule_servers[server_id].schedules[tmp_id].conflict = {};
                    self.schedule_servers[server_id].schedules[tmp_id].tmp_conflict = {};
                }
                for (var tmp_id in self.schedule_servers[server_id].schedules) {
                    self.conflict_check(server_id, tmp_id, true);
                }
            }
        }
        self.changed_days = {};
        changes_made_function(false);
        $('.day_option.changed').removeClass('changed');
        redraw();
    }

    function prepare_save() {

        self.transferTime = undefined;
        if ($(this).hasClass('ui-state-disabled')) {
            notification.info_msg(gettext("There are no changes"));
            return;
        }
        self.append_to_delete = {};
        var from, to;
        var prep_ajax_calls = [];
        for(var server_id in self.schedule_servers){
            for(var day in self.schedule_servers[server_id].deleted_days){
                from = self.schedule_servers[server_id].deleted_days[day][0];
                to = self.schedule_servers[server_id].deleted_days[day][1];

                from = from.getFullYear()+'-'+(from.getMonth()+1)+'-'+from.getDate()+' 04:00:00';
                to = to.getFullYear()+'-'+(to.getMonth()+1)+'-'+to.getDate()+' 04:00:00';
                prep_ajax_calls.push(helpers.ajax_call({
                    url: '/core/scheduling/schedule',
                    data: {
                        device_uuids: [server_id],
                        start_time: from,
                        end_time: to,
                        include_show_end: true
                    },
                    complete_variables:{
                        server_id: server_id
                    },
                    success_function: function(input,cv) {
                        var calendar_parts,clock_parts, start_time, schedule_uuid, tmp_schedule;
                        for (schedule_uuid in input.data) {
                            if (schedule_page.append_to_delete[cv.server_id] === undefined) {
                                schedule_page.append_to_delete[cv.server_id] = {};
                            }
                            tmp_schedule = input.data[schedule_uuid];
                            calendar_parts= tmp_schedule.start_date.split('-');
                            clock_parts = tmp_schedule.start_time.split(':');
                            start_time = new Date(calendar_parts[0],calendar_parts[1]-1,calendar_parts[2],clock_parts[0],clock_parts[1],clock_parts[2]);
                            schedule_page.append_to_delete[cv.server_id][schedule_uuid] = {
                                'server_id':cv.server_id,
                                'schedule_id':schedule_uuid,
                                'start_time':start_time
                            };
                        }

                    }
                }));
            }
        }
        $.when.apply(self, prep_ajax_calls).done(function(){
            //blank the save todo
            self.save_todo = {
                'schedule_delete': {
                    'structure': {},
                    'length': 0,
                    'pending': [],
                    'done': 0,
                    'failed': 0,
                    'action_title': gettext("Deleting Schedules")
                },
                'transfer':{
                    'structure': {},
                    'length': 0,
                    'pending': [],
                    'done': 0,
                    'failed': 0,
                    'action_title': gettext("Transferring Playlists")
                },
                'create':{
                    'structure': {},
                    'length': 0,
                    'pending': [],
                    'done': 0,
                    'failed': 0,
                    'action_title': gettext("Creating Schedules")
                },
                'pos':{
                    'pending': {},
                    'length': 0,
                    'done': 0,
                    'failed': 0,
                    'action_title': gettext("POS Mappings")
                }
            };
            //discard information, this is used for transfers mainly, so we dont repeatedly transfer the same playlists...
            var discard = {};
            for (var server_id in self.append_to_delete) {
                if (self.save_todo['schedule_delete'].structure[server_id] === undefined) {
                    self.save_todo['schedule_delete'].structure[server_id] = [];
                }
                for (var schedule_uuid in self.append_to_delete[server_id]) {
                    var tmp_sched = new Schedule({
                        'server_id': server_id,
                        'schedule_id': schedule_uuid,
                        'start_time': self.append_to_delete[server_id][schedule_uuid].start_time,
                        'placeholder_type': self.append_to_delete[server_id][schedule_uuid].placeholder_type
                    });
                    self.save_todo['schedule_delete'].structure[server_id].push(process_schedule_for_drawing(tmp_sched));
                    self.save_todo['schedule_delete'].length += 1;
                }
            }

            for (var server_id in self.schedule_servers) {
                //we dont save delete/schedules on the 'all' server
                if (!self.schedule_servers[server_id].is_lms) {
                    for (var deleted_id in self.schedule_servers[server_id].deleted_ids) {
                        //todo add pos,schedule,placeholder id here.
                        if (self.save_todo['schedule_delete'].structure[server_id] === undefined) {
                            self.save_todo['schedule_delete'].structure[server_id] = [];
                        }

                        if (schedule_page.append_to_delete[server_id] == undefined || schedule_page.append_to_delete[server_id][self.schedule_servers[server_id].schedules[deleted_id].schedule_id]=== undefined) {
                            var tmp_copy = new Schedule($.copy(self.schedule_servers[server_id].schedules[deleted_id]));
                            var mytempsched = process_schedule_for_drawing(tmp_copy);
                            self.save_todo['schedule_delete'].structure[server_id].push(mytempsched);
                            self.save_todo['schedule_delete'].length += 1;
                        }
                    }

                    for (var tmp_id in self.schedule_servers[server_id].tmp_schedules) {
                        var tmp = new Schedule($.copy(self.schedule_servers[server_id].tmp_schedules[tmp_id]));
                        //Don't transfer playlists if they're for templated items, those will be dealt with in the back end
                        if (tmp.source != tmp.server_id && discard[tmp.source+tmp.server_id+tmp.spl_id] === undefined && tmp.spl_id !== undefined) {
                            discard[tmp.source+tmp.server_id+tmp.spl_id]=true;
                            if (self.save_todo['transfer'].structure[tmp.spl_id] === undefined) {
                                self.save_todo['transfer'].structure[tmp.spl_id] = [];
                            }
                            self.save_todo['transfer'].structure[tmp.spl_id].push({
                                'from' : tmp.source,
                                'to' : tmp.server_id,
                                'spl_id' : tmp.spl_id,
                                'schedule' : process_schedule_for_drawing(tmp),
                                'playlist' : tmp.playlist
                            });
                            self.save_todo['transfer'].length += 1;
                        }
                    }

                    for (var tmp_id in self.schedule_servers[server_id].tmp_schedules) {
                        var tmp = new Schedule($.copy(self.schedule_servers[server_id].tmp_schedules[tmp_id]));
                        if (self.save_todo['create'].structure[server_id] === undefined) {
                            self.save_todo['create'].structure[server_id] = {}
                        }
                        var playlist_id = tmp.spl_id;
                        if (playlist_id !== undefined && playlist_id !== '') {
                            if (self.save_todo['create'].structure[server_id][playlist_id] === undefined) {
                                self.save_todo['create'].structure[server_id][playlist_id] = [];
                            }
                            self.save_todo['create'].structure[server_id][playlist_id].push(
                                process_schedule_for_drawing(tmp)
                            );
                            self.save_todo['create'].length += 1;
                        } else if (tmp.placeholder_type !== undefined && tmp.placeholder_type !== ''){
                            if (self.save_todo['create'].structure[server_id][tmp.placeholder_type] === undefined) {
                                self.save_todo['create'].structure[server_id][tmp.placeholder_type] = [];
                            }
                            self.save_todo['create'].structure[server_id][tmp.placeholder_type].push(
                                process_schedule_for_drawing(tmp)
                            );
                            self.save_todo['create'].length += 1;
                        }
                    }
                }
            }
            // POS Mappings
            for( var pos_id in self.pos_update_map ){
                self.save_todo['pos'].length += 1;
                if ( self.save_todo['pos']['pending'][self.pos_update_map[pos_id].spl_name] == undefined ){
                    self.save_todo['pos']['pending'][self.pos_update_map[pos_id].spl_name] = 0;
                }
                self.save_todo['pos']['pending'][self.pos_update_map[pos_id].spl_name] += 1;
            }
            var buttons = [];
            buttons.push({
                'text': gettext('Save'),
                'action': save
            });
            dialog.open({
                'title': gettext('Save'),
                'buttons': buttons,
                'hbtemplate': '#schedule_save_tmpl',
                'data': self.save_todo,
            });
            $('#schedule_save_tabs .save_tab').click(function(){
                $("#schedule_save_tabs .save_tab.selected").removeClass("selected");
                $(this).addClass("selected");
                var target = $(this).attr("data-target");
                $('#schedule_save_details').html($(target).html());
            });
            $('#schedule_save_tabs .save_tab:first-child').click();
            if (self.save_todo.transfer.length > 0) {
                $('#global_transfer_time_select').transferTimePicker();
            }

        })
    }

    function save_action_callback(action_id, success, message) {
        //Update the todo list
        for(var job_name in self.save_todo){
            var job = self.save_todo[job_name];
            var i = $.inArray(action_id, job.pending);
            if(i != -1){
                if(success){
                    job.done++;
                }
                else{
                    job.failed++;
                }
                job.pending.splice(i, 1);
            }
        }

        update_save_dialog();

        //Update error messages
        if (!success) {
            var error_section = $('.jq_save_action[action_id='+action_id+']').siblings('.jq_save_error');
            error_section.text(message);
            error_section.show();

            var error_section = $('.jq_save_action[action_id='+action_id+']').find('.jq_save_error');
            error_section.text(message);
        }
    }

    function update_save_dialog(){
        for(var job_name in self.save_todo){
            var job = self.save_todo[job_name];
            var progress = ((job.done + job.failed) / job.length) * 100;
            var dom = $(".jq_" + job_name + "_progress");
            var progress_bar = dom.find('.progress');
            progress_bar.css("width", progress + "%");
            if(job.failed > 0){
                progress_bar.addClass("failed");
            }
            dom.find('.progress_details').text(job.done + " / " + job.length);
        }
    }

    function save(){
        if (self.save_todo.transfer.length > 0) {
            self.transferTime = $('#global_transfer_time_select').transferTimePicker('getTransferTime');
            if (self.transferTime == undefined) {
                return
            }
        }
        else {
            self.transferTime == undefined;
        }

        //we dont want to trigger a schedule sync multiple times in quick succession
        //e.g. if we are moving a schedule we delete, create and map pos so delay the schedule sync until after the pos map
        if (self.save_todo.pos.length > 0){
            self.schedule_sync_stage = "pos"
        }
        else if (self.save_todo.create.length > 0){
            self.schedule_sync_stage = "create"
        }
        else if(self.save_todo.schedule_delete.length > 0){
            self.schedule_sync_stage = "delete"
        }

        var deletion_ajax_calls = save_stage_1_delete();
        $.when.apply(self,deletion_ajax_calls).done(function(){
            //DELETION AJAX CALLS COMPLETE
            $.when.apply(schedule_page,self.deferred_list).done(function(){
                //DELETION ACTIONS COMPLETE
                var transfer_ajax_calls = save_stage_2_transfer();
                $.when.apply(self,transfer_ajax_calls).done(function(){
                    //TRANSFER AJAX CALLS COMPLETE
                    $.when.apply(schedule_page,self.deferred_list).done(function(){
                        //TRANSFER ACTIONS COMPLETE
                        var creation_ajax_calls = save_stage_3_create();
                        $.when.apply(self,creation_ajax_calls).done(function(){
                            //CREATION ACTIONS COMPLETE
                            $.when.apply(schedule_page,self.deferred_list).done(function(){
                                //CREATION AJAX CALLS COMPLETE
                                var pos_ajax_calls = save_stage_4_pos();
                                $.when.apply(self,pos_ajax_calls).done(function(){
                                    //POS AJAX CALLS COMPLETE
                                    $.when.apply(schedule_page,self.deferred_list).done(function(){
                                        //POS ACTIONS COMPLETE
                                        post_save();
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    }

    function post_save(){

        var server_ids = [];
        for (var server_id in self.schedule_servers) {
            if (!self.schedule_servers[server_id].is_lms) {
                self.schedule_servers[server_id].tmp_schedules = {};
                self.schedule_servers[server_id].deleted_ids = {};
                self.schedule_servers[server_id].deleted_days = {};
                self.schedule_servers[server_id].schedules = {};
                self.schedule_servers[server_id].core_id_to_tmp_id = {};
                server_ids.push(server_id);
            }
        }
        self.changed_days = {};
        changes_made_function(false);

        $('.day_option.changed').removeClass('changed');

        redraw();
        $('.day_option.selected').click();
    }

    function save_stage_1_delete() {
        var new_buttons = [];
        new_buttons.push({
            'text': gettext('Done'),
            'action': function(){ dialog.close(); $(".jq_schedule_item").removeClass("selected"); },
        });
        dialog.update({
            buttons : new_buttons
        });

        self.deferred_list = [];
        var deferred_ajax_list = [];
        //the save function just runs through the tasks, removing tasks that have been completed, or failed from out lists.

        //get next schedule to be deleted.
        var action_item;
        var schedule_uuids = [];
        for (var server_id in self.save_todo.schedule_delete.structure) {
            for (var i=0; i < self.save_todo.schedule_delete.structure[server_id].length; i++){
                action_item = self.save_todo.schedule_delete.structure[server_id][i];
                $('.jq_save_action[action_type=delete_schedule][schedule_uuid='+action_item.schedule_id+']').addClass('pending');
                schedule_uuids.push(action_item.schedule_id);
            }
        }

        //mark processing
        //process
        if (schedule_uuids.length > 0){
            deferred_ajax_list.push(helpers.ajax_call({
                url: '/core/scheduling/delete',
                data: {
                    "schedule_uuids":schedule_uuids,
                    "sync_schedules": self.schedule_sync_stage == "delete"
                },
                notify: false,
                success_function: function(input,cv){
                    var message, tmp_id, dom, tmp_deferred;
                    var progress_section = $('.jq_delete_schedule .job_progress');
                    for (var i =0; i < input['messages'].length; i++) {
                        message = input['messages'][i];
                        dom = $('.jq_save_action[action_type=delete_schedule][schedule_uuid='+message.schedule_uuid+']');
                        if (message['type'] === 'action'){
                            dom.attr('action_id', message['action_id']);
                            tmp_deferred = $.Deferred();
                            schedule_page.deferred_list.push(tmp_deferred);
                            self.save_todo.schedule_delete.pending.push(message['action_id']);
                            $action_store.actions[message['action_id']] = {
                                show_pending: true,
                                success_class:'success',
                                failure_class:'fail',
                                current_class:'pending',
                                callback: save_action_callback,
                                deferred:tmp_deferred
                            };
                        }
                        else if (message['type'] === 'success'){
                            dom.removeClass('pending').addClass('success').attr('title',message['message']);
                            self.save_todo.schedule_delete.done++;
                        }
                        else {
                            dom.removeClass('pending').addClass('fail').attr('title',message['message']);
                            self.save_todo.schedule_delete.failed++;
                        }
                        update_save_dialog();
                    }
                },
                error_function: function(cv) {
                    //mark fail
                    var progress_section = $('.jq_delete_schedule .job_progress');
                    for (var schedule_uuid in cv.delete_map) {
                        $('.jq_save_action[action_type=delete_schedule][schedule_uuid='+schedule_uuid+']').removeClass('pending').addClass('fail');
                        self.save_todo.schedule_delete.failed++;
                    }
                    update_save_dialog();
                }
            }));
        }

        return deferred_ajax_list;
    }

    function save_stage_2_transfer() {
        var action_item;
        var deferred_ajax_list = [];
        self.deferred_list = [];
        for (var spl_id in self.save_todo.transfer.structure) {
            for (var i=0; i < self.save_todo.transfer.structure[spl_id].length; i++) {
                action_item = self.save_todo.transfer.structure[spl_id][i];
                //mark processing
                $('.jq_save_action[action_type=transfer_playlist][from='+action_item.from+'][to='+action_item.to+'][spl_id='+action_item.spl_id+']').addClass('pending');
                //process
                var data = {
                    sending_device_id: action_item.from,
                    receiving_device_ids: [action_item.to],
                    not_before: self.transferTime,
                    playlist_ids :[action_item.playlist.id],
                    playlists: [action_item.playlist]
                };
                deferred_ajax_list.push(helpers.ajax_call({
                    url: '/core/playlist/transfer',
                    data: data,
                    complete_variables: {
                        from:action_item.from,
                        to:action_item.to,
                        spl_id:action_item.spl_id
                    },
                    success_function: function(input, cv){
                        var message, tmp_deferred;
                        var dom = $('.jq_save_action[action_type=transfer_playlist][from='+cv.from+'][to='+cv.to+'][spl_id='+cv.spl_id+']');
                        for (var i =0; i < input['messages'].length; i++) {
                            message = input['messages'][i];
                            var progress_section = $('.jq_transfer .job_progress');
                            if (message['type'] === 'action') {
                                dom.attr('action_id',message['action_id']);
                                dom.attr('device_playlist_id',message['device_playlist_id']);
                                tmp_deferred = $.Deferred();
                                schedule_page.deferred_list.push(tmp_deferred);
                                self.save_todo.transfer.pending.push(message['action_id']);
                                $action_store.actions[message['action_id']] = {
                                    show_pending: true,
                                    success_class:'success',
                                    failure_class:'fail',
                                    current_class:'pending',
                                    callback: save_action_callback,
                                    deferred:tmp_deferred
                                };
                            }
                            //Recheck this
                            else if(message['type'] === 'error') {
                                if (message['receiving_device_ids'] !== undefined) {
                                    for (var j=0; j < message['receiving_device_ids']; j++){
                                        dom.addClass('fail').attr('title',message.message);
                                        var error_section = dom.find('.jq_save_error');
                                        error_section.html(message);
                                        error_section.show();
                                    }
                                }
                                else {
                                    dom.addClass('fail').attr('title',message.message);
                                    var error_section = dom.find('.jq_save_error');
                                    error_section.html(message);
                                    error_section.show();
                                }
                                self.save_todo.transfer.failed++;
                            }
                            else if(message['type'] === 'success') {
                                self.save_todo.transfer.done++;
                                //we're currently not really doing much wiht this, these would tend to be content transfers queued
                            }
                        }
                        update_save_dialog();
                    },
                    error_function: function(cv) {
                        //mark fail
                        var progress_section = $('.jq_transfer .job_progress');
                        $('.jq_save_action[action_type=transfer_playlist][from='+cv.from+'][to='+cv.to+'][spl_id='+cv.spl_id+']').addClass('fail');
                        self.save_todo.transfer.failed++;
                        update_save_dialog();
                    }
                }));

            }
        }

        return deferred_ajax_list;
    }

    function save_stage_3_create() {
        var action_item;
        var deferred_ajax_list = [];
        self.deferred_list = [];

        var schedules = []
        //we populate tmp_ids as we put each schedule into the schedules dict before we pass it to the create function
        //when we are looping through the returned messages, we can then look in this to find the tmp id of each schedule, which we need to update the dom
        var tmp_ids= {}
        for (var server_id in self.save_todo.create.structure) {
            for (var playlist_id in self.save_todo.create.structure[server_id]) {
                for (var i =0; i < self.save_todo.create.structure[server_id][playlist_id].length; i++) {
                    action_item = self.save_todo.create.structure[server_id][playlist_id][i];
                    //mark processing
                    $('.jq_save_action[action_type=create_schedule][server_id='+action_item.server_id+'][tmp_id='+action_item.tmp_id+']').addClass('pending');
                    //process
                    data = {
                        device_id : action_item.server_id,
                        start_time : action_item.get_play_date(),
                        placeholder_type : action_item.placeholder_type,
                        placeholder_duration : action_item.placeholder_duration,
                        pos_id : action_item.pos_id,
                        pos_rescheduled : action_item.pos_rescheduled,
                        pos_duration : action_item.pos_duration,
                        templating_issues : action_item.temp_issues,
                        playlist_type : action_item.type,
                        source_spl_id: action_item.source_spl_id,
                        show_attributes: action_item.show_attributes
                    };

                    data.display_name = _resolve_display_name(action_item.display_name);
                    if( action_item.spl_duration != undefined ){
                        data.spl_duration = action_item.spl_duration;
                    }
                    else{
                        data.spl_duration = action_item.pos_duration;
                    }
                    data.playlist_id = action_item.spl_id;

                    schedules.push(data);
                    tmp_ids[schedules.length-1] = action_item.tmp_id;
                }
            }
        }

        deferred_ajax_list.push(helpers.ajax_call({
            notify: false,
            url:  '/core/scheduling/create',
            data: {
                "schedule_dicts":schedules,
                "sync_schedules": self.schedule_sync_stage == "create"

            },
            success_function: function(input){
                var message;
                for (var i =0; i < input['messages'].length; i++) {
                    var update_item = $('.jq_save_action[action_type=create_schedule][server_id='+input['messages'][i].device_id+'][tmp_id='+tmp_ids[i]+']');

                    message = input['messages'][i];
                    if (message['type'] === 'action') {
                        update_item.attr('action_id', message['action_id']);
                        var tmp_deferred = $.Deferred();
                        schedule_page.deferred_list.push(tmp_deferred);
                        self.save_todo.create.pending.push(message['action_id']);
                        $action_store.actions[message['action_id']] = {
                                show_pending: true,
                                success_class:'success',
                                failure_class:'fail',
                                current_class:'pending',
                                callback: save_action_callback,
                                deferred:tmp_deferred
                        };
                    }
                    else if (message['type'] === 'success'){
                        var progress_section = update_item.closest('.jq_save_dialog_body').prev().find('.job_progress');
                        update_item.addClass('success');
                        self.save_todo.create.done++;
                    }
                    else {
                        var progress_section = $('.jq_schedule .job_progress');
                        update_item.removeClass('pending').addClass('fail');
                        var error_section = update_item.siblings('.jq_save_error');
                        error_section.html(message);
                        error_section.show();
                        self.save_todo.create.failed++;
                    }
                }
                update_save_dialog();
            },
            error_function: function() {
                var progress_section = $('.jq_schedule .job_progress');
                $('.jq_save_action[action_type=create_schedule]').addClass('fail');
                self.save_todo.create.failed = schedules.length;
                update_save_dialog();
            }
        }));

        return deferred_ajax_list;
    }

    function save_stage_4_pos() {

        var deferred_ajax_list = [];
        self.deferred_list = [];

        if( !$.isEmptyObject(self.pos_update_map)){
            // Mark POS sessions as "updating"
            for(var pos_id in self.pos_update_map){
                self.pos_pending_sessions[pos_id] = true;
            }

            deferred_ajax_list.push(helpers.ajax_call({
                notify: false,
                url: '/core/pos/save_mappings',
                data: {
                    "pos_update_map":self.pos_update_map
                },
                success_function: function(input,cv){
                    // If success that means we've succesfully updated all the relevant schedules/sessions in the DB'
                    self.save_todo.pos.done = self.save_todo.pos.length;
                    update_save_dialog();
                    self.pos_update_map = {};
                },
                error_function: function(input, cv){
                    // If error then we haven't properly updated the DB
                    self.save_todo.pos.failed = self.save_todo.pos.length;
                    update_save_dialog();
                    self.pos_update_map = {};
                }
            }));
        }
        return deferred_ajax_list;
    }

    self._close_page = function() {
        $playback_store.off('loaded.schedule_page');
        $device_store.off('loaded.schedule_page');
        $(document).off('page_load.schedule_page');
		
		reset_servers();

        // Collect the garbage javascript!
        self.changed_days = {};
        self.repeat_day_options = {};
        self.deferred_list = [];
        self.pos_update_map = {};
        self.check_pos_schedule_state = false;
        self.checking_schedule_sync_state = false
        self.preselected_pos_schedule_uuid = null;
        self.preselected_timestamp = undefined;

        clearTimeout(self.check_schedule_sync_timeout);
    };

    this.get_error_from_schedule = function(schedule, cpl_uuid){
        var error = $.grep(schedule.errors, function(error){
            return error.content_id == cpl_uuid;
        })[0];
        if(error){
            return error.issue;
        }
        else{
            return "";
        }
    };
    
    // Call when exiting or overwriting the objects to clear possible loaders
    function reset_servers() {
        for(var s in self.schedule_servers) {
			self.schedule_servers[s].loader.kill();
			self.schedule_servers[s].sync_loader.kill();
		}
        self.schedule_servers = {};
    }
}

function Server(parameters){
    this.id = parameters.id;
    this.device = $device_store.devices[this.id];
    //used to track accurate server time.
    this.time = new Date();
    this.time_ref;

    //the one special server
    this.is_lms = parameters.is_lms;

    this.schedules = {};
    this.tmp_schedules = {};
    this.deleted_ids = {};
    this.deleted_days = {};
    this.core_id_to_tmp_id ={};
    this.initial_sync_complete = parameters.initial_sync_complete;
    this.status = parameters.status;

    this.dom = $('.scheduler_row[server_id='+this.id+']');

    this.timeline = this.dom.find(".current_server_time");
    this.timeline_width = 0;

    this.info_dom = $('.scheduler_screen_row[server_id='+this.id+']');
    this.schedule_icon = this.info_dom.find(".scheduler_scheduler");
    this.time_text_dom = this.info_dom.find(".scheduler_screen_time");
    this.time_text = null;

    // Schedules Loading
    this.loader = new Loader({
        'target': "#row_" + this.id
    });
    if( this.initial_sync_complete == false ){
        this.loader.hide();
    }

    // Server Syncing
    this.sync_loader = new Loader({
        'target': "#row_" + this.id,
        'caption': gettext("Syncing with Server")
    });
    if(this.initial_sync_complete == true || this.status == "error"){
        this.sync_loader.hide();
    }

    this.update_schedule_mode = function(){
        var playback = $playback_store.devices[this.id];
        if(playback.modes){
            if(playback.modes.scheduler_enabled) {
                this.schedule_icon.toggleClass('disabled', false);
                this.dom.toggleClass('scheduler_disabled', false);
            }
            else{
                this.schedule_icon.toggleClass('disabled', true);
                this.dom.toggleClass('scheduler_disabled', true);
            }
        }
        else{
            this.schedule_icon.addClass('unknown').removeClass('disabled');
            this.dom.toggleClass('scheduler_disabled', false);
        }
    }

    this.progress_time_line = function(){
        if(this.device !== undefined && this.device.time !== undefined && this.device.category == 'sms'){
            var tmp_date = new Date($complex_status.core_time + Date.parse(new Date()) - $complex_status.browser_time_ref + $complex_status.browser_time_zone_offset + $complex_status.core_time_zone_offset + this.device.time - this.device.time_ref);
            var new_width = Math.round(helpers.date_stamp_to_position(tmp_date, schedule_page.pixel_offset, schedule_page.draw_settings.pixel_depth) * 100) / 100;
            if(this.timeline_width != new_width){
                this.timeline.css("width", new_width + '%');
                this.timeline_width = new_width;
            }

            var time_text = $.time_helper(tmp_date.getHours()) + ':' + $.time_helper(tmp_date.getMinutes())
            if(this.time_text != time_text){
                this.time_text = time_text;
                this.time_text_dom.text(time_text);
            }
            this.time = tmp_date;
        }
    }

    this.delete_day = function(date) {
        var delete_ = [];
        var from = new Date(date);
        var to = new Date(date);
        to.setDate(to.getDate()+1);
        for (var tmp_id in this.tmp_schedules) {
            if (this.tmp_schedules[tmp_id].start_time >= from && this.tmp_schedules[tmp_id].start_time < to) {
                delete_.push(tmp_id);
            }
        }
        for (var i =0; i< delete_.length; i++) {
            schedule_page.clear_conflicts(this.id, parseInt(delete_[i],10), false);
            delete this.tmp_schedules[delete_[i]];
        }
        this.deleted_days[date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate()] = [from,to];
    }

    this.add_tmp_schedule = function(tmp_schedule) {
        this.tmp_schedules[tmp_schedule.tmp_id+''] = tmp_schedule;
        schedule_page._mark_change_days(tmp_schedule);
        schedule_page.conflict_check(this.id, tmp_schedule.tmp_id, false);
    }

    this.add_schedule = function(schedule) {
        this.schedules[schedule.tmp_id+''] = schedule;
        schedule_page.conflict_check(this.id, schedule.tmp_id, true);
    }

    this.remove_schedule = function(schedule){
        if (schedule.saved == true) {
            schedule_page.clear_conflicts(schedule.server_id, schedule.tmp_id, true);
            this.deleted_ids[schedule.tmp_id] = true;
        }
        else {
            schedule_page.clear_conflicts(schedule.server_id, schedule.tmp_id, false);
            delete this.tmp_schedules[schedule.tmp_id];
        }
    }

    this.get_todays_schedules = function(include_enders) {
        var include_enders = $.val_or_default(include_enders,false);
        var output = {'schedules':[], 'tmp_schedules':[]}
        var date = new Date(schedule_page.today)
        date.setHours(date.getHours()+4);
        var tomorrow = new Date(schedule_page.today);
        tomorrow.setHours(date.getHours()+24);
        for (var tmp_id in this.schedules) {
            if (!this.schedules[tmp_id].is_deleted()) {
                var tmp = this.schedules[tmp_id];

                if (!include_enders) {
                    if (tmp.start_time >= date && tmp.start_time < tomorrow) {
                        output.schedules.push(tmp);
                    }
                }
                else {
                    if (tmp.end_time >= date && tmp.start_time < tomorrow) {
                        output.schedules.push(tmp);
                    }
                }
            }
        }
        for (var tmp_id in this.tmp_schedules) {
            var tmp = this.tmp_schedules[tmp_id];
            if (!include_enders) {
                if (tmp.start_time >= date && tmp.start_time < tomorrow) {
                    output.tmp_schedules.push(tmp);
                }
            }
            else {
                if (tmp.end_time >= date && tmp.start_time < tomorrow) {
                    output.tmp_schedules.push(tmp);
                }
            }
        }
        return output;
    }
}

function Schedule(arguments) {
    var self = this;
    schedule_page.tmp_schedule_id_counter++;
    this.tmp_id = schedule_page.tmp_schedule_id_counter;

    this.start_time = arguments.start_time;
    //The server the schedule is currently on
    this.server_id = arguments.server_id;

    // REMOVE? Why reference the playlist object?
    this.type = $.val_or_default(arguments.type, "playlist");

    this.spl_id = $.val_or_undefined(arguments.spl_id);
    this.spl_duration = $.val_or_undefined(arguments.spl_duration);
    this.spl_name = $.val_or_undefined(arguments.spl_name);

    //Where the playlist originally came from
    this.source = arguments.source;

    //TODO HORRIBLE THINK ABOUT THIS!!!!
    this.source_spl_id = arguments.source_spl_id || this.spl_id;
    this.playlist = $.val_or_undefined(arguments.playlist);

    this.placeholder_type = $.val_or_undefined(arguments.placeholder_type);
    this.placeholder_duration = $.val_or_undefined(arguments.placeholder_duration);

    this.pos_title = $.val_or_undefined(arguments.pos_title);
    this.pos_id = $.val_or_undefined(arguments.pos_id);
    this.pos_duration = $.val_or_undefined(arguments.pos_duration);
    this.pos_unassigned = $.val_or_undefined(arguments.pos_unassigned, false);
    this.pos_rescheduled = $.val_or_undefined(arguments.pos_rescheduled, false);
    this.pos_pending = $.val_or_undefined(arguments.pos_pending, false);
    this.show_attributes = $.val_or_undefined(arguments.show_attributes);
    this.seats_sold = $.val_or_default(arguments.seats_sold, null);

    this.schedule_type = $.val_or_default(arguments.schedule_type, "server");

    this.schedule_id = $.val_or_undefined(arguments.schedule_id);
    this.device_schedule_id = $.val_or_default(arguments.device_schedule_id, null);

    this.validated = $.val_or_default(arguments.validated, false);
    this.saved = arguments.saved;

    this.kdm_problem = $.val_or_default(arguments.kdm_problem, false);
    this.content_problem = $.val_or_default(arguments.content_problem,false);
    this.other_problem = $.val_or_default(arguments.playlist_problem,false) || $.val_or_default(arguments.schedule_problem, false);

    this.has_show_start   = $.val_or_default(arguments.has_show_start,false);
    this.has_intermission = $.val_or_default(arguments.has_intermission,false);
    this.show_start_offset = $.val_or_default(arguments.show_start_offset,0);

    this.templating_infos = [];
    this.templating_warnings = [];
    this.templating_errors = [];
    this.temp_issues = [];
    if(arguments.templating_issues != null && arguments.templating_issues.length > 0){
        this.temp_issues = arguments.templating_issues;
    }
    else if(this.playlist != undefined && this.playlist.templating_issues != undefined && this.playlist.templating_issues.length > 0){
        this.temp_issues = this.playlist.templating_issues;
    }

    this.display_show_start = new Date(arguments.start_time.getTime());
    this.display_show_start.setSeconds(this.display_show_start.getSeconds() + this.show_start_offset);

    this.read_only= false;

    this.tmp_conflict = {};
    this.conflict = {};
    this.errors = [];

    if (this.spl_name) {
        this.display_name = this.spl_name;
    }
    else if(this.placeholder_type) {
        this.display_name = _resolve_display_name(this.placeholder_type);
    }

    this.display_duration = 0;

    this.get_dom = function(){
        return $('.jq_schedule_item[server_id="'+this.server_id+'"][tmp_id="'+this.tmp_id+'"]');
    }

    this.setup_show_start = function(dom, time){
        if(this.has_show_start){
            this.show_start_tip = new ShowStartTip(dom);
        }
        if(time){
            this.update_show_start(time);
        }
    }

    this.update_start_time = function(dom, time){
        this.update_show_start(time);
        //strip seconds for display time
        var mom = moment(time);
        dom.find('.start_time').html(mom.format("HH:mm"));
        this.tmp_start_time = mom.toDate();
    }

    this.update_show_start = function(time){
        if(this.show_start_tip){
            this.show_start_tip.update(time, this.show_start_offset);
        }
    }

    function ShowStartTip(dom){
        var dom = dom;
        var text;

        attach(dom);
        function attach(dom){
            var tmpl = $('#schedule_start_time_tip_tmpl').tmpl2();
            text = tmpl.find('.tip_time');
            tmpl.prependTo(dom);
        }

        function update(time, offset){
            var show_start_time = moment(time).add('s', offset);
            text.text(show_start_time.format("HH:mm"));
        }

        this.attach = attach;
        this.update = update;
    }

    this.update = function(args){
        var def = $.Deferred();

        var server_id = args['server_uuid'];
        var date = args['date'];
        var show_attributes = args['show_attributes'];
        var duration = args['duration'];

        this.start_time = date || this.start_time;
        this.placeholder_duration = duration || this.placeholder_duration;
        this.display_duration = this.placeholder_duration || this.display_duration;
        this.show_attributes = show_attributes || this.show_attributes;

        var moved_server = false;
        if(this.server_id != server_id){
            this.server_id = server_id;
            moved_server = true;
        }

        //Don't do anything with pos items or placeholders for now
        this.pos_rescheduled = this.pos_id != undefined;
        if(this.pos_rescheduled || this.placeholder_type){
            return
        }

        //Inform that the date/time/server has been updated
        def.notify();
        // Don't bother reloading standard playlists if we know about it and the schedule hasn't moved server
        if(this.type == "playlist" && (this.playlist != undefined && !moved_server)){
            def.resolve();
        }
        else{
            var self = this;
            //Handle show attribute input first
            $.when(self.show_attributes_dialog())
            .done(function(){
                //Now we know where the playlist is going to be and its attributes we need to re-get it
                $.when(self.load_playlist())
                .fail(function(){
                    def.reject();
                })
                .done(function(){
                    def.resolve();
                });
            });
        }
        return def.promise();
    }

    this.show_attributes_dialog = function(){
        if(this.type == "playlist" || this.show_attributes != undefined){
            return
        }
        var self = this;
        var def = $.Deferred();
        var buttons = [];
        var attribute_list = undefined;
        buttons.push({
            "text":gettext("Apply"),
            "action": function(){
                self.show_attributes = attribute_list.get_selected_names();
                dialog.close();
            }
        });
        dialog.open({
            'title': gettext('Set Show Attributes'),
            'hbtemplate': "#show_attributes_select_tmpl",
            'buttons': buttons,
            'close': def.resolve
        });
        attribute_list = new ShowAttributeSelector({
            dom: $('#show_attribute_list')
        });
        return def.promise();
    }

    this.get_temp = function(){
        var tmp = $.extend(true, {}, this);
        tmp.saved = false;
        return tmp
    }

    this.load_playlist = function(){
        var me = this;
        var def = $.Deferred();
        helpers.ajax_call({
            url: '/tms/generate_schedule_playlist',
            data: {
                playlist_type: me.type,
                item_uuid: me.source_spl_id,
                source_device_uuid: me.source,
                target_device_uuid: me.server_id,
                // Convert start time to local time
                when: this.get_play_date(),
                show_attributes: Object.keys(me.show_attributes || {})
            },
            success_function: function(input){
                if(input['messages'].length > 0){
                    def.reject();
                }
                else{
                    me.update_playlist(input['data']);
                    def.resolve();
                }
            },
            error_function: function(){
                def.reject();
            }
        });
        return def.promise();
    }

    this.get_play_date = function(){
        return this.start_time.getFullYear()+'-'+(this.start_time.getMonth()+1)+'-'+this.start_time.getDate()+'T' + this.start_time.getHours() + ':' + this.start_time.getMinutes() + ':' + this.start_time.getSeconds();
    }

    this.update_playlist = function(playlist){
        this.playlist = playlist;
        this.spl_id = playlist['playlist']['id'];
        this.spl_duration = playlist['playlist']['duration_in_seconds'];
        this.display_duration = playlist['playlist']['duration_in_seconds'];
        this.spl_name = playlist['playlist']['title'];
        this.display_name = playlist['playlist']['title'];

        this.tmp_conflict = {};
        this.conflict = {};
        this.errors = [];

        if(playlist['templating_issues']){
            this.update_issues(playlist['templating_issues'])
        }
    }

    this.update_issues = function(issues){
        this.templating_errors = [];
        this.templating_warnings = [];
        this.templating_infos = [];
        for(var issue_i in issues){
            var issue = issues[issue_i];
            if(issue['level'] == "ERROR"){
                this.templating_errors.push(issue);
            }
            else if(issue['level'] == "WARNING"){
                this.templating_warnings.push(issue);
            }
            else{
                this.templating_infos.push(issue);
            }
        }
    }

    if(this.temp_issues){
        this.update_issues(this.temp_issues);
    }

    self.calculate_display = function(){
        this.display_duration = 0;
        var tmp_date = new Date(this.start_time.getTime());
        var mom = moment(tmp_date);

        if (this.spl_duration || this.placeholder_duration){
            if (this.spl_duration)
                this.display_duration += this.spl_duration;
            if (this.placeholder_duration)
                this.display_duration += this.placeholder_duration;
        }
        else if(this.pos_duration){
            this.display_duration += this.pos_duration;
        }
        this.display_show_start.setTime(tmp_date.getTime() + (parseInt(this.show_start_offset,10)*1000));
        tmp_date.setTime(tmp_date.getTime() + (parseInt(this.display_duration,10)*1000));
        this.end_time = tmp_date;
    }

    this.calculate_display();

    self.is_deleted = function() {
        if (this.saved) {
            if (schedule_page.schedule_servers[this.server_id].deleted_ids[this.tmp_id] ) {
                return true;
            }
            for (var deleted_day in schedule_page.schedule_servers[this.server_id].deleted_days) {
                if (this.start_time >= schedule_page.schedule_servers[this.server_id].deleted_days[deleted_day][0] && this.start_time < schedule_page.schedule_servers[this.server_id].deleted_days[deleted_day][1]) {
                    return true;
                }
            }
        }
        return false;
    }

    self.state = function() {
        if (this.pos_unassigned || ( this.schedule_type == "bookend_start" || this.schedule_type == "bookend_end")){
            return 'disabled';
        }
        if (!this.saved || schedule_page.pos_update_map[this.pos_id] != undefined){
            return 'unsaved';
        }
        if (this.pos_pending){
            return 'creating';
        }
        if (this.kdm_problem) {
            return 'missing_kdm';
        }
        if (this.content_problem) {
            return 'missing_content';
        }
        if (this.errors.length > 0 || this.other_problem || this.templating_errors.length > 0) {
            return 'error';
        }
        if (this.templating_warnings.length > 0){
            return 'templating_issues';
        }
        if (!this.placeholder_uuid && this.spl_id && this.device_schedule_id == undefined){
            return 'unscheduled';
        }
        return 'ok'
    }
}
