var monitor_page = new MonitorPage();
function MonitorPage() {
    var self = this;
    
    self.camera_update_interval;
    self.device_id = null;
    self.device_list = [];
    self.playlists = {};
    self.loader = null;
    self.views = {};
    
    //Templates
    self.small_device_tmpl = '#monitor_small_device_tmpl';
    self.medium_device_tmpl = '#monitor_medium_device_tmpl';
    self.large_device_tmpl = '#monitor_large_device_tmpl';
    self.playback_composition_tmpl = '#monitor_playback_composition_tmpl';
    self.playlist_item_tmpl = '#monitor_playlist_item_tmpl';
    self.size;
	
    //Methods
    self.open = function(size, device_id){
        self.size = size || 'small';
        self.device_list = get_sms_list();
        if(self.device_list.length > 0){
            self.device_id = device_id || self.device_list[0]['id'];
        }

        // If we are trying to load a large view and we are already on the large view, just reload the playlist bit
        if(size === "large" && self.views['large']){
            self.load_large_view(self.device_id);
            return
        }

        kill_views();
        $('#main_section').empty();
		self.loader = new Loader({target: '#main_section', caption: gettext("Loading")});
        self.loader.show();

        var doc = $(document);
        doc.trigger('page_load');
        doc.one('page_load', close); 
             
        load_view();
        
        doc.trigger('page_loaded');
        nav_select('monitor', self.size);
		if(self.size !== 'timeline') {
			_add_monitor_event_handlers();
			_start_camera_updates();
		}
    };
    
    function close(){
        _stop_camera_updates();
        kill_views();
        $('#main_section').off('.monitor');
        $('body').off('.monitor');
        $playback_store.off('.monitor_page');
        $playback_store.$playlist_composition.off('.monitor_page');
        $('.jq_monitor_tip').remove();
    }

    function kill_views(){
        for(var v in self.views){
            self.views[v].kill();
        }
		self.views = {};
    }

    function load_view(){
        $playback_store.off('loaded.monitor_page');
        
        switch(self.size){
            case 'medium': 
                self.load_detailed_view();
                break;
            case 'large':
                self.load_playback_view();
                break;
            case 'timeline':
                self.load_timeline_view();
                break;
            default:
                self.load_overview();
        }
        self.loader.hide();

        $playback_store.on('loaded.monitor_page', update_views);
    }

    function update_views(){
        for(var uuid in self.views){
            self.views[uuid].update();
        }
    }

    function get_sms_list(){
        var device_list = [];
        for(var i in $device_store.devices){
            var device = $device_store.devices[i];
            if(device['category'] === "sms" && $playback_store.devices[device['id']]){
                device_list.push(device);
            }
        }        
        device_list.sort(helpers.categorised_device_sorting_function);        
        return device_list;
    }
	
	function get_tms_time() {
		return ($complex_status.core_time + Date.parse(new Date()) - $complex_status.browser_time_ref) / 1000;
	}
    
    self.load_overview = function(){
        var device_list = self.device_list;
        var wrapper_div = $('<div />').addClass('monitor_device_wrapper');
        for (var i=0; i < device_list.length; i++) {
            var device = device_list[i];
            var view = new SmallView(device['id']);
            view.draw(wrapper_div);
            self.views[device['id']] = view;
        }
        $('#main_section').html(wrapper_div);

        function toggle_countdowns(){
        	$.each(self.views, function(i,v){
        		v.toggle_counts();
        	})
        }

        var view_bar = new ViewBar({
            parent: '#main_section',
            zoom_cookie: "monitor_zoom",
            zoom_values: ['100', '200', '300', '400'],
            zoom_callback: update_draw_settings,
            extra_options:[{
                class: 'countdown_button image icon-countdown',
                title: gettext('Toggle Countdowns'),
                action: toggle_countdowns
            }]
        });
    }
    
    self.load_detailed_view = function(){
        load_automation_information();        
        var device_list = self.device_list;
        var wrapper_div = $('<div />').addClass('monitor_device_wrapper');
        for(i in device_list){
            var device = device_list[i];
            var view = new MediumView(device['id']);
            view.draw(wrapper_div);
            self.views[device['id']] = view;
        }
        $('#main_section').html(wrapper_div);

        $('.jq_tab_headers').on('dblclick.monitor', '.tab', function() {
            var $this = $(this);
            $this.closest('.jq_monitor_device').siblings().find('.jq_tab_headers > li[tab="%tab"]'.replace('%tab', $this.attr('tab'))).click();
        });
        $('.jq_tab_headers > li:first-child').click();
    }

    self.load_playback_view = function(){
        var device_list = self.device_list;

        var wrapper_div = $('#monitor_large_device_tmpl').tmpl();
        var small_devices = wrapper_div.find('.monitor_large_devices');
        for (var i=0; i < device_list.length; i++) {
            var device = device_list[i];
            var view = new SmallView(device['id']);
            view.draw(small_devices);
            self.views[device['id']] = view;
        }
        $('#main_section').html(wrapper_div);

        self.load_large_view(self.device_id);

        if(self.device_id){
            $('.jq_small[device_id="'+self.device_id+'"]').click();
        }
        else{
            $('.jq_monitor_device:first-child').click();
        }
    }
	
	self.load_timeline_view = function() {
		var view = new Timeline(get_sms_list());
		view.draw();
		self.views['timeline'] = view;
	};
	
    self.load_large_view = function(device_uuid){
        // Delete old view and add new view, then draw it
        $('.jq_monitor_device').removeClass('selected');
        $('.jq_monitor_device[device_id="'+device_uuid+'"]').addClass('selected');
        if(self.views['large']) self.views['large'].kill();
        self.views['large'] = new LargeView(device_uuid);
        self.views['large'].draw($('#monitor_large_detail_pane').empty());        
    }
	
    function LargeView(device_uuid){
        var view = this;
        view.device_uuid = device_uuid;
        view.device = $device_store.devices[device_uuid];
        view.playback = $playback_store.devices[device_uuid];
        view.updaters = [];

        function draw(contain){
            view.dom = $('#monitor_large_playback_tmpl').tmpl({'playback': view.playback, 'device': view.device});
            view.playback.events.off(".large");

            view.controls = new ControlView(view.device_uuid);
            view.controls.draw(view.dom.find('#monitor_large_detail_pane_bottom'));

            view.playlist_view = new PlaylistView(view.device_uuid);
            view.playlist_view.draw(view.dom.find('.monitor_large_playlist_section'), $('#monitor_large_playlist_tmpl'));
            
            view.countdown_view = new CountdownView(view.device_uuid);
            view.countdown_view.draw(view.dom.find("#large_countdowns"));

            update_playlist();
            view.playback.events.on("playlist_updated.large", update_playlist);

            attach_quick_cues();

            view.updaters.push(view.playlist_view.update);
            view.dom.appendTo(contain);

            update();
        }

        function update_playlist(){
            var progress_doms = {
                'bar': view.dom.find('.playback_progress'),
                'position': view.dom.find('.jq_playback_position'),
                'duration': view.dom.find('.jq_playback_duration')
            }
            view.dom.find(".jq_playback_spl_title").text(view.playback.spl_title);
            if(view.progress_bar) view.progress_bar.kill();
            view.progress_bar = new PlaylistProgressBar(view.device_uuid);
            view.progress_bar.draw(progress_doms);
            view.countdown_view.update();
        }

        function attach_quick_cues(){
            $('#monitor_quick_cue_anchor_tmpl').tmpl().appendTo(view.dom.find(".device_controls"));
            var dom = view.dom.find("#jq_quick_cues");
            dom.qtip({
                content: {
                    text: $('#monitor_quick_cue_tmpl').tmpl({'quick_cues': get_quick_cues(view.device_uuid)})
                },
                position: {
                    at: 'top middle',
                    my: 'bottom middle'
                },
                show: {
                    event: 'mouseover click',
                    ready: false
                },
                hide: {
                    delay: 100,
                    event: 'mouseleave',
                    fixed: true
                },
                style: {
                    classes: 'qtip-dark qtip-shadow qtip-rounded jq_monitor_tip'
                }
            });
            dom.click(function(event) {
                var h_event = dom.toggleClass('active').hasClass('active') ? "click" : "mouseleave";
                dom.qtip("option", "hide.event", h_event);
            });
            
        }

        function update(){
            view.controls.update();
            for(i in view.updaters){
                view.updaters[i]();
            }
        }

        function kill(){
            view.playback.events.off(".large");
            $("#jq_quick_cues").qtip('destroy');
            view.progress_bar.kill();
            view.playlist_view.kill();
            view.countdown_view.kill();
        }

        this.draw = draw;
        this.update = update;
        this.kill = kill;
    }

    function SmallView(device_uuid){
        var view = this;
        view.device = $device_store.devices[device_uuid];
        view.playback = $playback_store.devices[device_uuid];
        view.device_uuid = device_uuid;
        view.counts_showing = false;

        function draw(contain){
            view.dom = $(self.small_device_tmpl).tmpl({'device_uuid': device_uuid, 'playback': view.playback});
            view.playback_view = new PlaybackView(device_uuid, view);
            view.playback_view.draw(view.dom);
            view.dom.appendTo(contain);
        	view.counts_dom = view.dom.find('.small_countdowns');
            view.countdown_view = new CountdownView(view.device_uuid);
            update();
        	view.counts_showing = $.cookie('read', "small_counts") == "true";
            if(view.counts_showing){
            	show_counts();
            }
        }

        function toggle_counts(){
        	if(view.counts_showing){
        		hide_counts();
        	}
        	else{
        		show_counts();
        	}
        }

        function show_counts(){
        	view.counts_dom.show();              
            view.countdown_view.draw(view.counts_dom);
            view.counts_showing = true;
        	$.cookie('write', "small_counts", true);
        }

        function hide_counts(){
        	view.counts_dom.hide();
        	view.countdown_view.kill();
        	view.counts_showing = false;
        	$.cookie('write', "small_counts", false);
        }

        function update(){
            view.playback_view.update();
        }

        function kill(){
            view.playback_view.kill();
            view.countdown_view.kill();
        }

        this.draw = draw;
        this.update = update;
        this.toggle_counts = toggle_counts;
        this.show_counts = show_counts;
        this.hide_counts = hide_counts;
        this.kill = kill;
    }

    function MediumView(device_uuid){
        var view = this;
        view.device_uuid = device_uuid;
        view.device = $device_store.devices[device_uuid];
        view.camera = view.device.screen().active_camera();
        view.audio = view.device.screen().audio_device();
        view.playback = $playback_store.devices[device_uuid];

        function draw(contain){
            view.dom = $(self.medium_device_tmpl).tmpl({'device': view.device, 'playback': view.playback, 'has_camera': view.camera, 'has_audio': view.audio});
            view.tab_body = view.dom.find('.jq_medium_tab_body');
            view.playback_view = new PlaybackView(view.device_uuid, view);

            view.playback_view.draw(view.dom.find(".monitor_medium_playback"));
            helpers.construct_tabs(view.dom, load_tab);
            view.dom.appendTo(contain);
            update();
        }
    
        function load_tab(tab) {
            view.updaters = [];
            if(view.playlist_view) view.playlist_view.kill();
            if(view.countdown_view) view.countdown_view.kill();
            if(view.audio_controls) view.audio_controls.kill();
            switch(tab.attr('tab')){
                case 'control':
                    var controls = new ControlView(view.device_uuid);
                    controls.draw(view.tab_body.empty());
                    view.updaters.push(controls.update);
                    break;
                case 'camera':
                    $('#monitor_medium_camera').tmpl({'device': view.camera}).appendTo(view.tab_body.empty());
                    break;
            	case 'audio':
            		view.audio_controls = new AudioControlsView(view.audio['id']);
            		view.audio_controls.draw(view.tab_body.empty());
                    break;
                case 'quick_cue':
                    view.tab_body.html($('#monitor_quick_cue_tmpl').tmpl({'quick_cues': get_quick_cues(view.device_uuid)}));
                    break;
                case 'schedule':
                    $('#monitor_medium_schedule').tmpl().appendTo(view.tab_body.empty());
                    view.playlist_view = new PlaylistView(view.device_uuid);
                    view.countdown_view = new CountdownView(view.device_uuid);
                    view.playlist_view.draw(view.dom.find('.monitor_medium_live_playlist_container'), $('#monitor_medium_live_playlist_tmpl'));                    
                    view.countdown_view.draw(view.dom.find('.monitor_medium_timeline'));
                    view.updaters.push(view.playlist_view.update);
            }
        }

        function update(){
            for(i in view.updaters){
                view.updaters[i]();
            }
            view.playback_view.update();
        }

        function kill(){
            view.playlist_view.kill();
            view.playback_view.kill();
            view.countdown_view.kill();
            if(view.audio_controls) view.audio_controls.kill();
        }

        this.draw = draw;
        this.update = update;
        this.kill = kill;
    }

    function AudioControlsView(device_uuid){
    	var view = this;
    	view.tmpl = $('#monitor_medium_audio');
    	view.device_uuid = device_uuid;
    	view.device = $device_store['devices'][device_uuid]
    	view.inputs = view.device['device_information']['inputs'];
    	view.state = $aux_status_store['audio'][view.device_uuid];

    	function draw(contain){
    		view.dom = view.tmpl.tmpl({'state': view.state, 'inputs': view.inputs});
    		view.dom.appendTo(contain);
	        view.state.on("changed", function(e, changes){
	        	update(changes);
	        });
	        view.dom.on('click', '.jq_button.mute_button', function(e){
	            helpers.ajax_call({
	                url:'/core/playback/toggle_mute', 
	                data: {
	                    device_uuid: view.device_uuid,
	                    mute: !($(e.target).hasClass('active'))
	                }
	            });
	        });

            var inputs_dom = $('#monitor_medium_audio_inputs').tmpl({'inputs': view.inputs})

            inputs_dom.on('click', '.jq_button.input_button', function(e){
                helpers.ajax_call({
                    url:'/core/playback/set_input', 
                    data: {
                        device_uuid: view.device_uuid,
                        input: $(e.target).attr("data-value")
                    }
                });
            });

            // Add inputs tip
            view.dom.find('.input_selector').qtip({
                content: {
                    text: inputs_dom
                },
                position: {
                    at: 'top middle',
                    my: 'bottom middle',
                    viewport: $(window)
                },
                show: {
                    event: 'mouseover click',
                    ready: false
                },
                hide: {
                    delay: 100,
                    event: 'mouseout',
                    fixed: true
                },
                style: {
                    classes: 'qtip-dark qtip-shadow qtip-rounded jq_monitor_tip audio_inputs_tip'
                }
            });

            // Set volume marker colours
            view.dom.find('.marker').each(function(){
                e = $(this);
                //hsl range green > red: 120 - 1
                var volume = e.attr('data-value');
                var s = 120 - (120 * (volume * 0.1));
                e.css("background-color", "hsl("+s+", 100%, 65%)");
            });

            set_volume_dom(view.state['volume'] / 10);

            var vol_ctrl = view.dom.find('.volume_control')
            view.dom.on('mousedown', '.volume_control', function(){
                var cur_vol = 0;
                vol_ctrl.on('mousemove', function(e){
                    var vol = get_volume(e, vol_ctrl);
                    if(vol != cur_vol){
                        set_volume_dom(vol);
                        cur_vol = vol;
                    }
                });
            });
            view.dom.on('mouseup', '.volume_control', function(e){
                vol_ctrl.off('mousemove');
                var vol = get_volume(e, vol_ctrl);
                set_volume_dom(vol);
                set_volume(vol);
            });

            view.dom.on('click', '.volume_control', function(e){
            });
    	}

        function get_volume(e, vol_ctrl){
            var x = (vol_ctrl.offset().left) + (vol_ctrl.width() / 2);
            var y = (vol_ctrl.offset().top) + (vol_ctrl.height() / 2);

            var radians = Math.atan2(e.pageY - y, e.pageX - x);
            var degree = (radians * (180 / Math.PI));
            var vol = Math.round((degree / 360) * 10) + 1
            if(vol <= 0){
                vol = 10 + vol;
            }
            return vol;
        }

        function set_volume(volume){
            helpers.ajax_call({
                url:'/core/playback/set_volume',
                data: {
                    device_uuid: view.device_uuid,
                    volume: parseInt(volume) * 10
                }
            });
        }

        function set_volume_dom(volume){
            var rotate = volume * 36 - 36;
            view.dom.find('.wheel').css({
                'transform': 'rotate('+ rotate +'deg)',
                '-ms-transform': 'rotate('+ rotate +'deg)'
            }).attr('title', 'Volume: '+ volume*10 +'%');
            view.dom.find('.marker.active').removeClass('active');
            var rem = volume % 1
            volume = Math.round(volume) || 0;
            view.dom.find('.marker:nth-child(-n+'+volume+')').addClass('active');
            if(rem){
                view.dom.find('.marker:nth-child('+volume+')').css("opacity", rem);
            }
        }

    	function update(changes){
    		for(var changed in changes){
    			if(changed == 'mute'){
    				view.dom.find('.jq_button.mute_button').toggleClass('active');
    			}
    			else if(changed == 'volume'){
                    set_volume_dom(view.state['volume'] / 10);
    			}
    			else if(changed == 'input'){
                    view.dom.find('.input_selector').text(view.state['input']['text'])
    			}
    		}
    	}

    	function kill(){
    		view.state.off("changed");
    	}

    	view.draw = draw;
    	view.kill = kill;
    }

    function CountdownView(device_uuid){
        var view = this;
        view.tmpl =  $('#monitor_medium_countdown');
        view.device_uuid = device_uuid;
        view.device = $device_store.devices[device_uuid];
        view.playback = $playback_store.devices[device_uuid];
        view.triggers = [
            10,
            60,
            600,
        ]
        view.next_show = null;

        function draw(contain){
            contain.empty();
            view.contain = contain;
            view.doms = {};
            update();
            view.inte = setInterval(update, 1000);
            get_next_show()
            view.playback.events.on("playlist_updated.CountdownView", function(){
                get_next_show();
                update();
            });
        }

        function get_next_show(){        	
        	if(view.playback['modes'] && view.playback['modes']['scheduler_enabled'] && view.playback['modes']['scheduler_enabled'] == true){
	            helpers.ajax_call({
	                url:'/tms/get_next_schedule', 
	                data: {
	                    device_uuid: view.device_uuid
	                },
	                success_function: function(input){
	                    var next_show = input['data'][view.device_uuid];
	                    if(!$.isEmptyObject(next_show)){
                            var device_time = new Date($complex_status.core_time + Date.parse(new Date()) - $complex_status.browser_time_ref + $complex_status.browser_time_zone_offset + $complex_status.core_time_zone_offset + $device_store.devices[view.device_uuid].time - $device_store.devices[view.device_uuid].time_ref);
                            next_show['offset'] = (new Date(next_show['start_timestamp']*1000).getTime() - device_time.getTime())/1000;
	                        view.next_show = next_show;
	                    }            
	                },
	                notify: false
	            });
        	}
        }

        function attach_tip(type, title){
            var inte;
            view.doms[type]['tip'] = view.doms[type]['dom'].qtip({
                content: {
                    text: $('#monitor_countdown_tip_tmpl').tmpl({'type': type, 'title': title, 'time': $.seconds_to_duration_string(view.doms[type]['count'])})
                },
                position: {
                    my: 'bottom middle',
                    at: 'top middle'
                },
                show: {
                    ready: false,
                    event: 'mouseover'
                },
                hide: {
                    event: 'mouseout'
                },
                events: {
                    show: function(){
                        var dom = $(this);
                        function update_tip(){
                            var text = view.doms[type]['count'] <= 0 ? gettext("Done") : $.seconds_to_duration_string(view.doms[type]['count']);
                            dom.find(".tip_text").text(text);
                        }
                        update_tip();
                        inte = setInterval(function(){
                            if(view.doms[type]) update_tip();
                            else clearInterval(inte);
                        }, 1000);
                    },
                    render: function(event, api){
                        $('.countdown_tip').click(function(){
                           view.doms[type]['tip'].qtip('hide');
                        });
                    },
                    hide: function(){
                        clearInterval(inte);
                    }
                },
                style: {
                    classes: 'qtip-tms-dark jq_monitor_tip'
                }
            });
        }

        function update_countdown(args){
            var type = args['type'];
            var count = args['count'];
            var title = args['title'];
            var playing = args['playing']
            var countdown = view.doms[type];
            var done = count <= 0;
            var text = "";
            if(!done){
                text = helpers.pretty_duration_string(count);
            }
            if(!countdown){
                view.doms[type] = {'dom': view.tmpl.tmpl({'type': type, 'time': count, 'done': false, 'text': text, 'title':  title}), 'val': text};
                view.doms[type]['dom'].appendTo(view.contain);
                // Sort countdown doms by time attr
                view.contain.children().sort(function(a, b) {
                    return +$(a).data('time') - +$(b).data('time');
                })
                .each(function() {
                    view.contain.append(this);
                });
                attach_tip(type, title);
            }
            else{
                view.doms[type]['dom'].toggleClass('done', done);
                view.doms[type]['dom'].find(".timeline_icon_text").text(text);
            }
            view.doms[type]['count'] = count;
            if(playing && !done && view.triggers.indexOf(count) != -1){
                view.doms[type]['tip'].qtip('show');
                setTimeout(function(){
                    if(view.doms[type]) view.doms[type]['tip'].qtip('hide');
                }, 10000)
            }
        }

        function update(){
            var time_now = get_tms_time();
            var playing = false;
            // Use time now if no last updated time
            var last_sync_diff = time_now - (view.playback.last_updated || time_now);
            var position = 0;
            if (view.playback.playback_state === 'play' && !(view.device['type'] == 'gdc' && view.playback.spl_position==0)) {
                playing = true;
                position = view.playback.spl_position + (last_sync_diff);
            }

            var playlist = view.playback.playlist;
            if(playlist){
                for(i in playlist.countdowns.major){
                    var countdown = playlist.countdowns.major[i];
                    var count = Math.round(countdown['relative_start'] - position);                   
                    update_countdown({
                        'type': countdown['type'],
                        'count': count,
                        'title': countdown['name'],
                        'playing': playing
                    })
                }
            }
            else{
                for(var tag in view.doms){
                    if(tag != "next_show"){
                        view.doms[tag]['dom'].remove();
                        delete view.doms[tag];
                    }
                }
            }
            if(view.next_show){
                var type = "next_show";
                var count_dom = view.doms[type];
                if(!view.next_show['local_offset']){
                    view.next_show['local_offset'] = time_now + view.next_show['offset'];
                }
                var count = view.next_show['local_offset'] - time_now
                if(count <= 0 && view.doms[type]){
                    view.doms[type]['dom'].remove();
                    delete view.doms[type];
                    get_next_show();
                }
                update_countdown({
                    'type': 'next_show',
                    'count': count,
                    'title': "<div class='schedule_title'>"+view.next_show['title'] + "</div><div class='schedule_time'>" + view.next_show['start_time'] + "</div>",
                    'playing': true
                })
            }
        }

        function kill(){
            view.doms = {};
            view.playback.events.off("playlist_updated.CountdownView");
            clearInterval(view.inte);
        }

        this.draw = draw;
        this.update = update;
        this.kill = kill;
    }

    function PlaylistView(device_uuid){
        var view = this;
        view.device_uuid = device_uuid;
        view.device = $device_store.devices[device_uuid];
        view.playback = $playback_store.devices[device_uuid];
        view.position = null;
        view.percent = 0;
        view.drawn = false;

        function draw(contain, tmpl){
            view.tmpl = tmpl;
            view.contain = contain;
            update_playlist();
            view.playback.events.on("playlist_updated.PlaylistView", update_playlist);
        }

        function update(){
            update_index();
        }

        function smooth(){
            if(!view.playback.element_position || view.position == view.playback.element_position){
                return
            }
            var time_now = get_tms_time();
            var position = view.playback.element_position;
            if (view.playback.playback_state === 'play' && !(view.device['type'] == 'gdc' && view.playback.element_position==0)) {
                var last_sync_diff = time_now - view.playback.last_updated;
                position = view.playback.element_position + (last_sync_diff);
            }
            view.position = position;
            update_progress(position, view.playback.element_duration);
        }

        function update_progress(pos, duration){
            var percent = Math.round((pos / duration) * 100);
            if(view.percent != percent){
                view.percent = percent;
                view.progress_dom.css("width", percent + "%");
            }            
        }

        function update_playlist(){
            view.playlist_dom = view.tmpl.tmpl({'playback_info': view.playback});
            view.playlist_dom.appendTo(view.contain.empty());
            view.progress_dom = view.playlist_dom.find('.playlist_element_wrap.active .playlist_element_progress');
            if(view.playback.playlist && view.playback.playlist.events.length > 0){
                view.drawn = true;
                clearInterval(view.inte);
                smooth();
                view.inte = setInterval(smooth, 1000);
            }
        }

        function update_index(){
            if(view.drawn && view.playback_index != view.playback['element_index']){
                view.playback_index = view.playback['element_index'];
                view.playlist_dom.find('.playlist_element_wrap').removeClass('active');
                var active = view.playlist_dom.find('.playlist_element_wrap:nth-child('+(view.playback_index+1)+')');
                view.progress_dom = active.find('.playlist_element_progress');
                if(active.length){
                    // Height of 1 item
                    var oh = active.outerHeight()
                    // Height of all items above this one
                    var index_height = view.playback_index * oh;
                    // Height of the container
                    var con = view.playlist_dom.innerHeight();
                    var scroll = index_height - (con/2 - (oh/2));
                    view.playlist_dom.animate({scrollTop: scroll});
                    active.addClass('active');
                }
            }
        }

        function kill(){
            view.playback.events.off("playlist_updated.PlaylistView");
            clearInterval(view.inte);
        }

        this.draw = draw;
        this.update = update;
        this.kill = kill;
    }

    function ControlView(device_uuid){
        // Maybe some sort of parenting? To inherit view values etc?
        var view = this;
        view.device_uuid = device_uuid;
        view.device = $device_store.devices[device_uuid];
        view.playback = $playback_store.devices[device_uuid];
        view.playback_state = null;
        view.buttons = {};
        view.buttons_playback;
        view.loaded = false;
        view.modes = {};

        function draw(contain){
            view.dom = $('#monitor_medium_control').tmpl({
                'playback': view.playback,
                'device_id': view.device_uuid,
                'device': view.device
            });
            button('back', ".jq_back");
            button('play', ".jq_play");
            button('pause', ".jq_pause");
            button('stop', ".jq_stop");
            button('forward', ".jq_forward");
            button('intermission', ".jq_intermission_button");
            button('schedule_mode', '.jq_schedule_mode');

            view.buttons_playback = view.dom.find('.playback_controls .jq_button');
            view.dom.appendTo(contain);
            view.loaded = true;
            update();
        }

        function button(name, klass, tags){
            var dom = view.dom.find(klass);
            if(dom.length > 0){
                view.buttons[name] = {
                    'dom': view.dom.find(klass),
                    'states': {}
                }
            }
        }

        function update_button(name, value, state){
            if(view.buttons[name] == undefined){
                return
            }
            if(view.buttons[name][value] != state){
                view.buttons[name][value] = state
                view.buttons[name].dom.toggleClass(value, state);
            }
        }

        function update_mode(klass, mode, state){
            if(state == undefined){
                return
            }
            if(view.modes[mode] != state){
                view.modes[mode] = state;
                view.dom.find(klass).removeClass('active');
                view.dom.find(klass+'.'+state).addClass('active');
            }
        }

        function update(){
            if(!view.loaded){
                return null;
            }

            var state = view.playback.playback_state;
            if(state != view.playback_state){
                update_button(view.playback_state, 'active', false);
                update_button(state, 'active', true);
                update_button('pause', 'disabled', state != 'play');
                view.playback_state = state;
            }

            update_button('intermission', 'disabled', !view.playback.intermission);

            var modes = view.playback.modes || {};
            var scheduler_enabled = modes['scheduler_enabled'] || false;

            update_button('schedule_mode', 'active', scheduler_enabled);
            view.dom.toggleClass('schedule_on', scheduler_enabled);

            update_mode('.jq_loop_mode', 'loop_mode', modes['loop_mode']);

            var manual = modes['playback_mode'];
            if(modes['auto_playback_mode'] && modes['auto_playback_mode'] != "MANUAL"){
                manual = "AUTO";
            }
            update_mode('.jq_playback_mode', 'playback_mode', manual);
            update_mode('.jq_auto_playback_mode', 'auto_playback_mode', "AUTO_" + modes['auto_playback_mode']);

            if(view.playback_mode != manual){
                view.playback_mode = manual;
                var text = manual || "?";
                view.dom.find('.jq_playback_mode_display').text(text).addClass(text);
            }
        }

        this.draw = draw;
        this.update = update;
    }

    function PlaybackView(device_uuid, parent){
        var view = this;
        view.parent = parent;
        view.device_uuid = device_uuid;
        view.device = $device_store.devices[device_uuid];
        view.playback = $playback_store.devices[device_uuid];
        view.playback_state = "unknown";
        view.schedule_mode = "unknown";
        view.spl_title = view.playback.spl_title || gettext('Unknown');

        function draw(contain){
            if(view.playback.modes){
                view.schedule_mode = view.playback.modes.scheduler_enabled;
            }
            view.dom = $("#monitor_device_playback_tmpl").tmpl({'device': view.device, 'playback': view.playback, 'schedule_mode': view.schedule_mode});
            view.dom.appendTo(contain);
            view.playlist_title = view.dom.find('.jq_playback_spl_title');
            view.content_kind_dom = view.dom.find('.jq_current_content_type');
            view.progress_doms = {
                'bar': view.dom.find('.playback_progress'),
                'position': view.dom.find('.jq_playback_position'),
                'duration': view.dom.find('.jq_playback_duration')
            }
            view.comp_dom = view.dom.find('.jq_playback_composition_bar');
            update_playlist();
            view.playback.events.off('playlist_updated.PlaybackView');
            view.playback.events.on('playlist_updated.PlaybackView', update_playlist);
        }

        function update_playlist(){
            view.comp_dom.empty();
            if(view.playback.playlist){
                $("#monitor_playback_composition_tmpl").tmpl({'playlist': view.playback.playlist}).appendTo(view.comp_dom);
            }
            if(view.spl_title != view.playback.spl_title){
                view.spl_title = view.playback.spl_title;
                view.playlist_title.html(view.playback.spl_title || gettext('Unknown'));
            }
            if(view.progress_bar) view.progress_bar.kill();
            view.progress_bar = new PlaylistProgressBar(view.device_uuid);
            view.progress_bar.draw(view.progress_doms);
            update();
        }

        function update(){
            update_playback_state();
            update_schedule_state();
            if(view.playback.playlist && view.playback.element_index != undefined && view.playback.playlist.events.length > 0){
                var content_kind = view.playback.playlist.events[view.playback.element_index].content_kind;
                if(view.content_kind != content_kind){
                    view.content_kind = content_kind;
                    view.content_kind_dom.text(content_kind_reference[view.content_kind]);
                }
            }
        }

        function update_playback_state(){
            var state = view.playback.playback_state
            if(view.playback_state != state){
                view.parent.dom.removeClass(view.playback_state);
                view.playback_state = state;
                if(view.playback_state != 'error' && view.device.status == 'error'){
                    state = 'error';
                }
                view.parent.dom.addClass(state);
            }            
        }

        function update_schedule_state(){
            var modes = view.playback.modes;
            if(modes && modes.scheduler_enabled != view.schedule_mode){
                view.dom.removeClass("schedule_" + view.schedule_mode);
                view.schedule_mode = modes.scheduler_enabled;
                view.dom.addClass("schedule_" + view.schedule_mode);
            }
        }

        function kill(){
            if(view.progress_bar) view.progress_bar.kill();
            view.playback.events.off('playlist_updated.PlaybackView');
        }

        this.draw = draw;
        this.update = update;
        this.update_playlist = update_playlist;
        this.kill = kill;
    }

    function PlaylistProgressBar(device_uuid){
        var view = this;
        var device = $device_store.devices[device_uuid];
        var playback = $playback_store.devices[device_uuid];
        view.spl_duration = playback.spl_duration || 0;

        function draw(elems){
            view.bar = elems['bar'];
            view.position = elems['position'];
            view.duration = elems['duration'];
            view.bar_dom = $('#monitor_progress_tmpl').tmpl();
            view.count_dom = $('#monitor_progress_counts_tmpl').tmpl({'playback': playback});
            view.duration.text($.seconds_to_duration_string(view.spl_duration));
            view.bar.empty()
            view.bar_dom.appendTo(view.bar);
            view.count_dom.appendTo(view.bar);
            smooth();
            view.inte = setInterval(smooth, 1000);
        }

        function smooth(){
            //TMS time now - for comparison with the device_info last_updated - this gives us predicted times etc.
            var time_now = get_tms_time();
            var position = playback.spl_position;
            if (playback.playback_state === 'play' && !(device['type'] == 'gdc' && playback.spl_position==0)) {
                //Time since last sync.
                var last_sync_diff = time_now - playback.last_updated;
                position = playback.spl_position + (last_sync_diff);
            }
            update_playback_progress(position);
            update_progress_bar(position);
        }
        
        function update_playback_progress(progress){
            if (view.spl_duration >= 0 && progress > view.spl_duration){
                view.position.text($.seconds_to_duration_string(view.spl_duration));
            } 
            else {
                view.position.text($.seconds_to_duration_string(progress));
            }
        }
        
        function update_progress_bar(progress){
            var tmp;
            if(view.spl_duration >= 0){
                if(view.spl_duration === 0)
                    tmp = 0;
                else{
                    tmp = progress*100/view.spl_duration;
                    if (tmp > 100){
                        tmp = 100;
                    }
                }
                view.bar_dom.css('width', tmp+'%');
            }
        }

        function kill(){
            clearInterval(view.inte);
        }

        this.draw = draw;
        this.kill = kill;
    }

    function get_quick_cues(device_uuid){        
        var list = [];
        if (AUTOMATION_CONFIGURATION['quick_cues'][device_uuid]) {
            for (var i in AUTOMATION_CONFIGURATION['quick_cues'][device_uuid]) {
                var tmp = AUTOMATION_CONFIGURATION['quick_cues'][device_uuid][i];
                list.push({
                    'automation_uuid'   : tmp.automation_uuid,
                    'automation_name'   : tmp.automation_name,
                    'device_uuid'       : device_uuid,
                    'icon'              : tmp.icon,
                    'parameter'         : tmp.parameter
                });
            }
        }
        return list
    }

    function update_draw_settings(zoom_value){
        var zoom_dec = zoom_value/100;
        $('.monitor_small_device').css({
            "width": 25 * zoom_dec - 2 + "%",
            "font-size": zoom_value + "%"
        });
    }
    
    function _set_playlist_options(input, cv) {
        var spl_uuid, playlist_options;
        var playlist_select = $('.jq_monitor_select_playlist[device_id='+cv.device_id+']');
        playlist_options = [];
        for (spl_uuid in input[cv.device_id]) {
            playlist_options.push({
                'value': spl_uuid,
                'text': input[cv.device_id][spl_uuid].title, 
                '_class': (input[cv.device_id][spl_uuid].validation.kdm_issue)?'error':((input[cv.device_id][spl_uuid].validation.content_issue)?'warning':'')
            });
        }
        playlist_select.set_options(playlist_options, $playback_store.devices[cv.device_id].spl_uuid);
    }
    
    function _show_load_spl_dialog(device_id) {
        var buttons = [];
        buttons.push({
            'text': gettext('Load'),
            'action': function(){
                var playlist_id = $('#playlist_table tr.selected').attr('data-playlist_id');
                if(playlist_id){
                    _load_playlist(self.device_id, playlist_id);    
                }                
            }
        });
        dialog.open({
            'title': gettext('Load Playlist'),
            'template': '#monitor_load_playlist_tmpl',
            'buttons': buttons,
            'close': function(){
                $("#monitor_playlist_list").remove();
            }
        });
        initialise_data_table(device_id);
    }

    function initialise_data_table(device_id) {
        self.device_id = device_id;
        var dt_cols = [];
        //Empty first col so that column indexes match that of the playlist page, not ideal but works for now
        dt_cols.push({
            "bVisible": false,
            "mDataProp": function (oObj, type) {
                return '$nbsp;';
            }
        });
        dt_cols.push({
            "bSearchable": false,
            "bSortable": false,
            "mDataProp": function (oObj, type) {
                var tmp = [];
                if(oObj.is_template)
                    tmp.push({name: "template", additional_class:'playlist_table', title: gettext("Playlist Template")});
                if(oObj.is_3d)
                    tmp.push({name: "icon-three-d", additional_class:'playlist_table', title: gettext("3D Playlist")});
                if(oObj.is_hfr)
                    tmp.push({name: "icon-high-framerate", additional_class:'playlist_table', title: gettext("High Frame Rate")});
                if(oObj.validation.kdm_issue)
                    tmp.push({name: "kdm_issue", additional_class:'playlist_table', title: gettext("Issue with KDM")});
                if(oObj.validation.content_issue)
                    tmp.push({name: "content_issue", additional_class:'playlist_table', id:'errors_for_'+oObj.uuid});
                if(oObj.validation.playlist_issue)
                    tmp.push({name: "playlist_issue", additional_class:'playlist_table', id:'errors_for_'+oObj.uuid});
                if(oObj.has_show_start)
                    tmp.push({name: "show_start", additional_class:'playlist_table', title: gettext("Contains Show Start")});
                if(oObj.has_intermission)
                    tmp.push({name: "intermission", additional_class:'playlist_table', title: gettext("Contains intermission")});
                return $('#image_list_tmpl').tmpl({image_items:tmp}).html();
            }
        });
        dt_cols.push({
            "mDataProp": function (oObj, type) {
                return '<div class="global_content_object global_playlist_object">' + oObj.title.escape() + '</div>';
            }
        });
        dt_cols.push({
            "bSearchable": false,
            "bSortable": false,
            "mDataProp": function (oObj, type) {
                var content_items = [];
                for (var i = oObj.features.length - 1; i >= 0; i--){
                    content_items.push({content_title: oObj.features[i], content_kind:"feature"});
                }
                return $('#content_list_tmpl').tmpl2(content_items).html();
            }
        });
        dt_cols.push({
            "bSearchable": false,
            "mDataProp": function (oObj, type) {
                return $.seconds_to_duration_string(oObj.duration_in_seconds);
            }
        });    
        self.table = $('#playlist_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_playlists",
            "aoColumns": dt_cols,
            "bServerSide": true,
            "sScrollY": "100%",
            "bAutoWidth": false,
            "bDestroy": true,
            "aaSorting": [[ 2, "asc" ]],
            "sDom": '<"#playlist_table_filtering" f>t<".dataTables_pages" ip>',
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            oLanguage: DATATABLES_LANG,
            "fnServerData": server_data,
            "fnRowCallback": function(nRow, aData){
                $(nRow).click(function(){
                    $('#playlist_table tr.selected').removeClass("selected");
                    $(nRow).addClass("selected").attr("data-playlist_id", aData.uuid);
                })
            },
            "fnDrawCallback": function() {
                $("#playlist_table .content_issue, #playlist_table .playlist_issue").each(function(){
                    var detailed_issues = self.playlists[$(this).attr("id").replace("errors_for_", "")].validation.detailed_issues;
                    helpers.attach_playlist_validation_tip(this, detailed_issues);
                });
            }
        });
        self.table.fnSetFilteringDelay(800);
        $("#table_controls").append($("#playlist_table_filtering"));
        $('.dataTables_scrollBody').height(
            $('#playlist_table_wrapper').innerHeight() -
            $('#playlist_table_filtering').innerHeight() -
            $('.dataTables_scrollHead').outerHeight() -
            $('.dataTables_pages').outerHeight()
        );
    }

    function server_data(sSource, aoData, fnCallback){
        var data = {};
        for (var i in aoData) {
            data[aoData[i].name] = aoData[i].value;
        }
        data['device_uuid'] = self.device_id;
        var loader = new Loader({target: '.dataTables_scroll', caption: gettext("Loading")});
        loader.show();
        $.ajax({
            "dataType": 'json', 
            "type": "POST", 
            "url": sSource,
            "data": $.toJSON(data),
            "processData": false,
            "contentType": "application/json",
            "success": function(input){
                for(var i = input.aaData.length - 1; i >=0; i--){
                    self.playlists[input.aaData[i].uuid] = input.aaData[i];
                }
                fnCallback(input);
                loader.hide();
            }
        });
    }

    function _load_playlist(device_id, playlist_id) {
        helpers.ajax_call(
            {
                url:'/core/playback/load', 
                data:{
                    'device_id': device_id, 
                    'playlist_id': playlist_id
                },
                success_function: function (input){
                    dialog.close();
                }
            }
        )
    }

    function _add_monitor_event_handlers() {
        $('body').on(
            'click.monitor',
            '.jq_quick_cue', 
            function() {
                $this = $(this);
                helpers.ajax_call({
                    url:'/core/automation/trigger',
                    data: {
                        device_id: $this.attr('device_uuid'),
                        cue_id: $this.attr('automation_uuid'),
                        parameterized: ($this.attr('parameter')!=='')?true:false,
                        parameterized_value: ($this.attr('parameter')!=='')?$this.attr('parameter'):undefined
                    },
                    headers:{'Return-Complete':'true'}
                });
            }
        );


        function enabled(t){
            if ($(t).css("cursor") == "not-allowed"){
                notification.info_msg(gettext("Cannot use controls when schedule mode is enabled"));
                return false
            }
            else{
                return true
            }
        }

        $('#main_section').on(
            'click.monitor',
            '.jq_small',
            function() {
                var device_uuid =  $(this).attr('device_id');
                self.device_id = device_uuid
                window.location.hash = '#monitor_page#large#'+device_uuid;
            }
        );
        
        $('#main_section').on(
            'click.monitor',
            '.jq_monitor_load_spl_button',
            function() {
                if(!enabled(this)) return
                var device_id = $(this).attr('device_id');
                _show_load_spl_dialog(device_id);
            }
        );
        
        $('#main_section').on(
            'click.monitor',
            '.jq_monitor_eject_spl_button',
            function() {
                if(!enabled(this)) return
                var device_id;
                device_id = $(this).attr('device_id');
                helpers.ajax_call({
                    url:'/core/playback/eject', 
                    data:{'device_id': device_id}
                });
            }
        );
        $('#main_section').on(
            'click.monitor',
            '.jq_playback_control.jq_play',
            function() {
                if(!enabled(this)) return
                var device_id;
                device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                helpers.ajax_call({url:'/core/playback/play', data:{'device_id': device_id}});
            }
        );
        $('#main_section').on(
            'click.monitor',
            '.jq_playback_control.jq_pause',
            function() {
                if(!enabled(this)) return
                var device_id;
                if (!$(this).hasClass('jq_disabled')) {
                    device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                    helpers.ajax_call({url:'/core/playback/pause',  data:{'device_id': device_id}});
                }
            }
        );
        $('#main_section').on(
            'click.monitor',
            '.jq_playback_control.jq_stop',
            function() {
                if(!enabled(this)) return
                var device_id;
                device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                helpers.ajax_call({url:'/core/playback/stop',  data:{'device_id': device_id}});
            }
        );
        $('#main_section').on(
            'click.monitor',
            '.jq_playback_control.jq_back',
            function() {
                if(!enabled(this)) return
                var device_id;
                device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                helpers.ajax_call({url:'/core/playback/skip_backward',  data:{'device_id': device_id}});
            }
        );
        $('#main_section').on(
            'click.monitor',
            '.jq_playback_control.jq_forward',
            function() {
                if(!enabled(this)) return
                var device_id;
                device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                helpers.ajax_call({url:'/core/playback/skip_forward',  data:{'device_id': device_id}});
            }
        );
        
        $('#main_section').on(
            'click.monitor',
            '.jq_loop_mode',
            function() {
                var device_id, loop_mode_value;
                device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                loop_mode_value = $(this).attr('loop_mode_value');
                helpers.ajax_call({
                    url:'/core/playback/set_mode',
                    data: {device_id:device_id, mode:loop_mode_value}
                }); 
            }
        );

        $('#main_section').on(
            'click.monitor',
            '.jq_playback_mode, .jq_auto_playback_mode',
            function() {
                var device_id, playback_mode_value;
                device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                playback_mode_value = $(this).attr('playback_mode_value');
                helpers.ajax_call({
                    url:'/core/playback/set_mode',
                    data: {device_id:device_id, mode:playback_mode_value}
                }); 
            }
        );
        $('#main_section').on(
            'click.monitor',
            '.jq_schedule_mode', 
            function() {
                var device_id = $(this).closest('.jq_monitor_device').attr('device_id');
                if($(this).hasClass('active')){
                    var mode = 'schedule_off';
                }
                else{
                    var mode = 'schedule_on';
                }
                helpers.ajax_call({
                    url:'/core/playback/set_mode',
                    data: {device_id: device_id, mode: mode}
                });
            }
        );
        $('#main_section').on(
            'click.monitor',
            '#intermission_interrupt:not(.disabled)',
            function() {
                    var device_uuid = $(this).closest('.jq_monitor_device').attr('device_id');
                    helpers.ajax_call({
                    url: '/core/playback/interrupt_intermission',
                    data: {
                        'device_uuid': device_uuid
                    }
                });
            }
        )
    }

    function _start_camera_updates() {
        self.camera_update_timeout = setTimeout(_update_cameras, 5000);
    }

    function _update_cameras() {
        var timestamp = (new Date().getTime());
        $('.jq_monitor_camera_feed').each(function() {
            var $this = $(this);
            var $new_img = $this.clone();
            var src = '/core/camera/get_image?device_uuid=%device_uuid&_=%time'.replace('%device_uuid', $this.attr('camera_device_uuid')).replace('%time', timestamp);
            $new_img.attr('src', src).css({'display': 'none'});
            $new_img.insertAfter($this);
            $new_img.fadeIn(1000, 'linear', function() {
                $this.remove();
            });
        });

        self.camera_update_timeout = setTimeout(_update_cameras, 5000);
    }

    function _stop_camera_updates() {
        clearTimeout(self.camera_update_timeout);
    }
}
