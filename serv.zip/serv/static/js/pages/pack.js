var pack_page = new PackPage();
function PackPage() {
    var self = this;
    self.initialized = false;

    //Templates
    var main_tmpl = '#pack_main_tmpl';

    var select_all_toggled = false;
    var packs = {};
    var placeholders = {};
    var screens = [];
    var selected_packs = [];
    var table;

    // flag to prevent multiple "load packs" requests being sent
    self.syncing_packs = false;

    //Methods
    self.open = function() {
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.one('page_load', close_page);

        self.syncing_packs = false;

        $('#main_section').html($(main_tmpl).tmpl());

        nav_select('content', 'pack');

        self.placeholder_filter = null;
        self.rating_filter = null;
        self.screen_filter = null;
        self.filter_text = '';
        if (history.state != null){
            self.placeholder_filter = history.state['placeholder_filter_id'];
            self.screen_filter = history.state['screen_filter_id'];
            self.rating_filter = history.state['filter_text'];
            self.filter_text = history.state['filter_text'];
        }

        initialise_data_table();
        add_table_controls();
        attach_event_listeners();

        self.initialized = true;
        load_screens();
        load_placeholders();
        load_ratings();
    };

    function hasShowAttribute(value1, value2, options){
        return (_.isArray(value1) && _.reduce(value1, function(memo, value){
            return value.external_id === value2 || memo;
        }, false)) ? options.fn(this) : '';
    }

    function close_page() {
        table = null;
        $(window).off('.pack');
        $("#main_section").off();
    }

    function attach_event_listeners() {
        $('#pack_toggle_select_all').on('click.pack', function(){
            select_all_toggled = !select_all_toggled;
            $('#pack_toggle_select_all').toggleClass('selected', select_all_toggled);
            $('#pack_table input').attr("checked", select_all_toggled);
            update_checked_count();
        });

        $('#pack_table > tbody').on('click.pack', 'input:checkbox', function(){
            update_checked_count();
        });

        $('#pack_table tbody').on('click.pack', 'td.no_prop', function(event) {
            event.stopPropagation();
        });

        $('#pack_table tbody').on('click.pack', 'tr.pack', function(event) {
            var pack_uuid = $(this).find('input').attr('pack_uuid');
            history.pushState({
                placeholder_filter_id: $('#placeholder_type_filter_dropdown').val(),
                screen_filter_id: $('#screen_number_filter_dropdown').val(),
                rating_filter_id: $('#rating_number_filter_dropdown').val(),
                filter_text: $('#pack_table_filter input').val()
            }, null, '#pack_page');
            history.pushState(null, null, '#pack_edit_page#'+pack_uuid);
            pack_edit_page.open(pack_uuid);
        });

        $("#main_section").on('resize.pack', resize);

        $('#main_section').on(
            'click.pack',
            '#clear_filter_button',
            function(){
                $('#screen_number_filter_dropdown').val("none");
                self.screen_filter = null;
                $("#placeholder_type_filter_dropdown").val("none");
                self.placeholder_filter = null;
                $("#pack_table_filter input").val("");
                self.rating_filter = null;
                $('#rating_filter_dropdown').val("");
                table.fnFilter("");
            }
        );
    }

    function initialise_data_table() {
        var dt_cols, index, data, sorting_col, i;
        dt_cols = [];
        dt_cols.push({
            "bVisible": false,
            "bSortable": false,
            "mDataProp": "uuid"
        });
        dt_cols.push({
            "mDataProp": function(oData, type) {
                return '<input type="checkbox" pack_uuid="'+oData.uuid+'" />';
            },
            "bSortable": false,
            "bSearchable": false,
            "sClass": 'no_prop'
        });
        dt_cols.push({
            mDataProp: function(oData, type) {
                return oData.name.escape();
            },
            "bSortable": true,
            "bSearchable": true
        });
        dt_cols.push({
            "mDataProp": function(oData, type) {
                if(type === 'display') {
                    if (oData.placeholder_uuid){
                        return '<span class="global_content_object global_pack_object">' + oData.placeholder_name.escape() + '</span>';
                    }
                    else{
                        return '';
                    }
                }
                else{
                    return '<span class="global_content_object global_pack_object">' + oData.placeholder_uuid + '</span>';
                }
            },
            "bSortable": true,
            "bSearchable": true,
            "bUseRendered": false
        });
        dt_cols.push({
            "mDataProp": function(oData, type) {
                if(oData.title_name != undefined){
                    return "<span class='pack_title_info'><span class='icon-star'></span>" + oData.title_name + '</span>'
                }else if(oData.ext_title_name != undefined){
                    return "<span class='pack_title_info pack_title_info_unmatched'><span class='icon-star'></span>" + oData.ext_title_name + ' (' + gettext("Unmapped") + ') ' + '</span>'                    
                }else{
                    return '';
                }
            },
            "bSortable": true,
            "bSearchable": true,
            "bUseRendered": false
        });
        dt_cols.push({
            "mDataProp": function(oData, type) {
                var ret = '<div class="pack_screen_bar">';
                if(oData.screens.length == 0)
                    return ret + '<div class="device_name_small">All</div></div>'
                var screens = [];
                $.each(oData.screens, function(i, screen){
                    if($device_store.screens[screen] != undefined){
                        screens.push($device_store.screens[screen].identifier);
                    }
                });
                screens.sort();
                $.each(screens, function(i, screen){
                   ret += '<div class="device_name_small">' + screen + '</div>';
                })
                return ret + '</div>';
            },
            "bSortable": false,
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            mDataProp: function(oData) {return datetime_format(oData.date_from, oData.date_to);},
            "bSortable": true,
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            mDataProp: function(oData) {return datetime_format(oData.time_from, oData.time_to);},
            "bSortable": true,
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            "mDataProp": function(oData) {
                return $('#sa_icon_list_tmpl').tmpl({"show_attributes": oData.show_attributes}).html();
            },
            "bSortable": false,
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            mDataProp: function(dat) {
                return dat.rating;
            }
        });
        dt_cols.push({
            mDataProp: function(oData) {
                return moment(oData.last_modified * 1000).format('DD MMM YYYY HH:mm');
            }
        });

        var column_toggler = new ColumnToggler({
            table: '#pack_table',
            columns: dt_cols
        });

        table = $('#pack_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_packs",
            "bServerSide": true,
            "oSearch": {
                "sSearch": self.filter_text
            },
            "aoColumns": dt_cols,
            "bDestroy": true,
            "aaSorting": [[ 3, "asc" ],[2, "asc"]],
            "bAutoWidth": false,
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            "sDom": 'f<"table_controls jq_pack_table_controls">t<".dataTables_pages" ip>',
            "sScrollY": "500px",
            oLanguage: DATATABLES_LANG,
            "fnServerData": server_data,
            fnInitComplete: function(){
                column_toggler.init(table);
            },
            fnDrawCallback: function(){
                $('#pack_toggle_select_all').removeClass('selected');
                select_all_toggled = false;
            },
            fnRowCallback: function(row){
                $(row).addClass('pack');
            }
        });
        table.fnSetFilteringDelay(800);
        set_table_size();
    }
    
    function datetime_format(from, to) {
        if(!(from || to)) {
            return '&nbsp;';
        }
        if(!from) {
            return gettext('Before %date_end').replace(/%date_end/, to);
        }
        if(!to) {
            return gettext('After %date_from').replace(/%date_from/, from);
        }
        return gettext('%date_from - %date_end').replace(/%date_from/, from).replace(/%date_end/, to);
    }

    function server_data(sSource, aoData, fnCallback){
        if(!self.syncing_packs){
            self.syncing_packs = true;
            var data = {};
            for (var i in aoData) {
                data[aoData[i].name] = aoData[i].value;
            }
            var loader = new Loader({target: '#pack_table_wrapper .dataTables_scroll', caption: gettext("Loading")})
            loader.show(function(){
                data.placeholder_filter = self.placeholder_filter || null;
                data.screen_number_filter = self.screen_filter || null;
                data.rating_filter = self.rating_filter || null;
                $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": sSource,
                    "data": $.toJSON(data),
                    "processData": false,
                    "contentType": "application/json",
                    "success": function(input){

                        if(!self.initialized){
                            return;
                        }

                        var i = input.aaData.length;
                        while(i--){
                            packs[input.aaData[i].uuid] = input.aaData[i];
                        }
                        fnCallback(input);
                        loader.hide();
                        update_checked_count();
                        self.syncing_packs = false;
                    }
                });
            });
        }
    }

    function resize(){
        set_table_size();
        table.fnAdjustColumnSizing(false);
    }

    function set_table_size() {
        /*
            the resize.
            there must be a better way of doing this. this is pretty much waht we do in tms1:
                use the sScrolly feature to add a copy of the table header, and set a height for the body
                then window resize listen to adjsut the dimensions of the scrollbody.

            tried out the datatables fixedheader plugin, but taht duplicates ids etc, making it pretty useless

            other alternative is to do some css layout monstrosity, got into it a little bit, but there are quite a few pitfalls in this
        */
        $('#pack_table_wrapper .dataTables_scrollBody').height(
            $('#pack_table_wrapper').innerHeight() -
            $('#pack_table_wrapper .dataTables_scrollHead').outerHeight() -
            $('.jq_pack_table_controls').outerHeight() -
            $('#pack_table_filter').outerHeight() -
            $('#pack_table_info').outerHeight()
        );
    }

    function add_table_controls() {
        var buttons = [];

        if (helpers.is_allowed('tms_schedule_action')){
            buttons = [
                {text:gettext('New'), image:'new', onClick: new_pack},
                {text:gettext('Delete'), image:'delete', onClick: delete_pack, disabled: true, id:'pack_delete_btn'},
                {text:gettext('Edit'), image:'edit', onClick: edit_packs, disabled: true, id:'pack_edit_btn'},
                {text:gettext('Upload'), image:'upload_pack', onClick: upload_pack},
                {text:gettext('Sync History'), image:'sync', onClick: toggle_sync_history}
            ];
        }

        helpers.set_buttons('.jq_pack_table_controls', buttons);
    }

    function toggle_sync_history(){
        helpers.ajax_call({
            url:'/core/pack/sync_history',
            success_function:function(input){
                dialog.open({
                    'title': gettext('Sync History'),
                    'template': '#pack_sync_tmpl',
                    'data': { 'data' : input.data },
                    'width': 500,
                    'height': 300
                });
            },
            notify: false
        });
    }

    function update_checked_count() {
        var selected = $('input:checkbox:checked', table.fnGetNodes()).length;
        $('#pack_toggle_select_all').html(selected);
        $('#pack_delete_btn').button('option', 'disabled', (selected == 0));
        $('#pack_edit_btn').button('option', 'disabled', (selected == 0));
    }

    function load_placeholders() {
        return helpers.ajax_call({
            url:'/core/placeholder/placeholders',
            data:{sorted_list:true},
            success_function:update_placeholders
        });
    }

    function update_placeholders(input) {
        placeholders = input.data;
        $('#placeholder_type_filter_dropdown').remove();
        $('#clear_filter_button').remove();
        $('#placeholder_type_filter_tmpl').tmpl({placeholders:placeholders}).appendTo($('#pack_table_filter'));
        $('#placeholder_type_filter_dropdown').on('change', filter_packs_by_placeholder);

        $("#placeholder_type_filter_dropdown").val(self.placeholder_filter);
        $("#pack_table_filter input").val(self.filter_text)
    }

    function filter_packs_by_placeholder(){
        self.placeholder_filter = $("#placeholder_type_filter_dropdown").val();
        table.fnFilter(self.placeholder_filter, 2);
    }

    function load_screens() {
        screens = [];
        for(var screen_uuid in $device_store.screens){
            screens.push({"identifier":$device_store.screens[screen_uuid]["identifier"],"uuid":screen_uuid})
        }
        screens.sort_screens();
        $('#screen_number_filter_dropdown').remove();
        $('#screen_number_filter_tmpl').tmpl({screens:screens}).appendTo($('#pack_table_filter'));
        $('#screen_number_filter_dropdown').on('change', filter_packs_by_screen_number);

        $('#screen_number_filter_dropdown').val(self.screen_filter);
    }

    function filter_packs_by_screen_number(){
        self.screen_filter = $("#screen_number_filter_dropdown").val();
        table.fnFilter(self.screen_filter, 4);
    }
    
    function load_ratings() {
        var ratings = $complex_status.territories[$complex_status.country_code].ratings;
        $('#rating_filter_dropdown').remove();
        $('#rating_filter_tmpl').tmpl2(ratings).appendTo($('#pack_table_filter'));
        $('#rating_filter_dropdown').val(self.rating_filter).on('change', function() {
            self.rating_filter = $('#rating_filter_dropdown').val();
            table.fnFilter(self.rating_filter, 9);
        });
    }

    function delete_pack() {
        selected_packs = [];
        $('#pack_table input:checked').each(function(i, checkbox){
            var uuid = $(checkbox).attr('pack_uuid');
            selected_packs.push(packs[uuid]);
        });
        update_delete_dialog();
    }



    function update_delete_dialog(){
        var delete_button = {
            'text': gettext('Delete'),
            'action': function() {
                delete_packs(selected_packs);
            }
        };
        dialog.open({
            'title': gettext('Delete'),
            'template': '#pack_delete_tmpl',
            'buttons': [delete_button],
            'close': function(){
            },
            'data': {
                'packs': selected_packs
            },
            'width': 500,
            'height': 300
        });
    }

    function delete_packs(packs_to_delete) {
        var pack_uuids = [];
        for (var i = 0, packs_to_delete_length = packs_to_delete.length; i < packs_to_delete_length; i++) {
            pack_uuids.push(packs_to_delete[i].uuid);
            $('.jq_delete_entry[data-pack_uuid="%uuid"] .jq_status'.replace('%uuid', packs_to_delete[i].uuid)).addClass('pending');
        };

        helpers.ajax_call({
            data:{pack_uuids:pack_uuids},
            url:'/core/pack/delete',
            notify: false,
            success_function:function(input){
                var ms_offset = 0;
                var message;
                var state;
                var start = new Date().getTime();
                var elems = $('.jq_delete_entry').clone();
                var i = elems.length;
                var m = input['messages'].length;
                var state, message;
                while(i--){
                    var elem = elems.eq(i);
                    var x = m;
                    while(x--){
                        message = input['messages'][x];
                        state = message.type == 'success' ? 'success' : 'failed';
                        if(message.pack_uuid == elem.attr('data-pack_uuid')){
                            elem.find(".jq_status").switchClass('pending', state);
                        }
                    }
                }
                $('#dialog_contents').html(elems);

                update_packs();
                var new_buttons = [];
                new_buttons.push({
                    'text': gettext('Done'),
                    'action': dialog.close
                });
                dialog.update({
                    buttons : new_buttons
                });
            }
        });
    }

    function edit_packs() {
        selected_packs = [];
        $('#pack_table input:checked').each(function(i, checkbox){
            var uuid = $(checkbox).attr('pack_uuid');
            selected_packs.push(packs[uuid]);
        });
        update_edit_dialog();
    }

    function update_edit_dialog(){
        var buttons = [
            {"text":gettext("Save"),"action":save_pack_changes},
            {"text":gettext("Cancel"),"action":dialog.close},
        ]
        dialog.open({
            'title': gettext('Edit'),
            'template': '#edit_packs_dialog',
            'width': 350,
            'buttons':buttons,
            'data': {
                "selected_packs" : selected_packs,
                "placeholders": placeholders,
                "screens": screens,
            }
        });

        // Edit Screen Number checkbox
        $("#edit_pack_screen_number_checkbox").on('change', function(){
             var checked = $("#edit_pack_screen_number_checkbox").attr('checked') != "checked";
             $("#edit_pack_screen_number_select_wrapper").toggleClass("edit_pack_attribute_select_disabled", checked);
             $("#edit_pack_screen_number_select").attr("disabled", checked);
             validate_save_pack_changes_button();
        });

        // Edit Placeholder checkbox
        $("#edit_pack_placeholder_checkbox").on('change', function(){
             var checked = $("#edit_pack_placeholder_checkbox").attr('checked') != "checked";
             $("#edit_pack_placeholder_select_wrapper").toggleClass("edit_pack_attribute_select_disabled", checked);
             $("#edit_pack_placeholder_select").attr("disabled", checked);
             validate_save_pack_changes_button();
        });

        validate_save_pack_changes_button();
    }

    function validate_save_pack_changes_button(){
        if( ($("#edit_pack_screen_number_checkbox").attr('checked') == "checked") || ($("#edit_pack_placeholder_checkbox").attr('checked') == "checked")){
            $('#at_button_0').removeClass('content_tranfer_btn_disabled ui-state-disabled');
            return true;
        }else{
            $('#at_button_0').addClass('content_tranfer_btn_disabled ui-state-disabled');
            return false;
        }
    }

    function save_pack_changes(){

        if( validate_save_pack_changes_button() ){
            var pack_uuids = [];
            var placeholder_uuid;

            for(var pack_index in selected_packs){
                pack_uuids.push(selected_packs[pack_index].uuid);
            }

            // Screen Numbers
            if( $("#edit_pack_screen_number_checkbox").attr('checked') == "checked" ){
                if( $("#edit_pack_screen_number_select").val() == "all"){
                    var screen_uuids = [];
                }else{
                    var screen_uuids = [$("#edit_pack_screen_number_select").val()];
                }
            }else{
                var screen_uuids = null;
            }

            // Placeholder
            if($("#edit_pack_placeholder_checkbox").attr('checked') == "checked"){
                var placeholder_uuid = $("#edit_pack_placeholder_select").val();
            }else{
                var placeholder_uuid = null;
            }

            // Show Loader
            $("#dialog_contents .edit_pack_attribute_wrapper").css("opacity",0.4)
            helpers.show_loader($("#dialog_contents"),null,gettext("Saving"));

            // Send request
            helpers.ajax_call({
                data:{
                    pack_uuids:pack_uuids,
                    placeholder_uuid:placeholder_uuid,
                    screen_uuids:screen_uuids,
                },
                url:'/core/pack/edit',
                success_function: function(){
                    helpers.hide_loader();
                    update_packs();
                    dialog.close();
                }
            });
        }else{
            $('.edit_pack_attribute_checkbox_wrapper').effect('pulsate', {times:2}, 500);
        }
    }

    function update_packs() {
        table.fnDraw();
    }

    function upload_pack() {
        var data, buttons;
        buttons=[];
        buttons.push({
            'text': gettext('Done'), 
            'action': function() {
                dialog.close();
            }
        });

        buttons.push({
            text: gettext("Add files"),
            action: function(){
                $("#file_upload_button").click();
            }
        });

        dialog.open({
            'title': gettext('Upload Pack'),
            hbtemplate: '#upload_file_dialog',
            'buttons': buttons,
            'width': 400,
            'close': on_upload_close, 
            'data':{"api_call":'/tms/upload_pack'}
        });
        $("#at_button_0").button('option', 'disabled', true);

        $('#fileuploader').fileupload({
            dataType: 'json',
            dropZone: $('#file_dropzone'),
            error: function(e, data) {
                if(e.status == 403){
                    notification.error_msg(gettext("Permission denied"),gettext('Upload Pack'));                    
                }else{
                    notification.error_msg(e.statusText,gettext('Upload Pack'));
                }
                dialog.close();
            },
            done: function (e, data) {
                $.each(data.result.messages, function (index, message) {
                    var feedback_class = 'file_upload_success';
                    
                    feedback_info = {};
                    if(message.type == 'error'){
                        feedback_info["status"] = 'error';
                    }
                    else{
                        feedback_info["status"] = 'success';
                    }
                    feedback_info["filename"] = data.result.filename;
                    feedback_info["upload_message"] = message.message;
                    $("#upload_file_feedback").tmpl2(feedback_info).appendTo($("#file_upload_response_wrapper"));
                });
                $("#at_button_0").button('option', 'disabled', false);
            },
            dragover : function(e){
                if (!$('#file_dropzone').hasClass('accept')){
                    $('#file_dropzone').addClass('accept');
                }
                if (self.mouseovertimeout){
                    clearTimeout(self.mouseovertimeout);
                }
                self.mouseovertimeout = setTimeout(function(){$('#file_dropzone').removeClass('accept'); self.mouseovertimeout = null;}, 500);
            }
        });
    }

    function on_upload_close(){
        load_placeholders().done(update_packs);
    }

    function new_pack() {
        history.pushState(null, null, '#pack_edit_page');
        pack_edit_page.open();
    }
}
