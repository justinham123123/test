var report_audit_page = new ReportAuditPage();

function ReportAuditPage() {
    var self = this;

    self.open = function(){
        $document.trigger('page_load');
        $document.one('page_load', self.close);

        $("#report_audit_tmpl").tmpl().appendTo($('#main_section').empty());
        nav_select('report', "audit");

        self.filter_data = {
            content_kind: 'feature',
            filter_system: $.cookie('read', 'audit_filter_system') === 'true'
        };
        $('#filter_system').toggleClass('selected', self.filter_data.filter_system)
            .prop('checked', self.filter_data.filter_system)
            .click(function(){
                $(this).toggleClass('selected');
                filter('filter_system', $('#filter_system').hasClass('selected'));
                $.cookie('write', 'audit_filter_system', self.filter_data.filter_system, 5000);
            });
        
        // Server Selectors   
        self.server_selector = report_playback_page.get_server_selector('everything', init_table, null, true);
        self.server_selector.init();
        
        $("#main_section").resize(function(){
            if(self.datatable) self.datatable.fnAdjustColumnSizing(false);
        });
        report_playback_page.toggle_sidebar(self);
    };

    self.close = function(){
        self.datatable = undefined;
        self.last_device = (self.filter_data || {}).device_uuid;
        self.filter_data = self.filter_defaults;
        $("#main_section").off("resize");
    };
    
    function gen_columns(){
        var cols = [];
        cols.push({
            "mDataProp": function(oData, type) {
                return '<div class="user">' + oData["user"] + '</div>';
            },
            "bSortable": false
        });
        cols.push({
            "mDataProp": function(oData, type) {
                return '<div class="ip">' + oData['ip'] + '</div>';
            },
            "bSortable": false
        });
        cols.push({
            "mDataProp": function(oData, type) {
                var tags = ""
                for(var i in oData['tags']){
                    tags += "<div class='tag image ico " + oData['tags'][i] + "'></div>"
                }
                var html = "<div class='tags'>" + tags + "</div>";
                return html;
            },
            "bSortable": false
        });
        type_classes = {
            'playlist': 'global_content_object global_playlist_object',
            'device_uuid': 'screen_number_generic_small',
            'screen': 'screen_number_generic_small',
            'schedule': 'schedule',
            'timestamp': 'timestamp'
        }
        cols.push({
            "mDataProp": function(oData, type) {
                var message = oData.message;
                // I Handlebarsed this template but it turned out to be super slow
                // compared to native string concatting, so I think handlebarsing datatables => bad idea
                if(!$.isEmptyObject(oData['meta'])){
                    $.each(oData['meta'], function(tag, obj){
                        var classes = tag + (" "+type_classes[obj['type']] || "");
                        var text = (obj.display || obj.uuid).escape();
                        if(obj['type'] == "cpl_uuid"){
                            classes += " content_color_" + obj['other']['content_kind'];
                        }
                        else if(obj['type'] == "title"){
                            text = "<span class=icon-star></span> " + text;
                        }
                        message = message.replace("{"+tag+"}", "<span title='"+obj['uuid']+"' class='"+classes+"'>"+text+"</span>")
                    });
                }
                return '<div class="message">' + message + '</div>'
            },
            "bSortable": false
        });
        cols.push({
            "sClass": "when_col",
            "mDataProp": function(oData, type) {
                var date = moment.unix(oData['timestamp']);
                var html = "<div class='when'>";
                html += "<div class='time'>" + date.format('HH:mm:ss') + "</div>";
                html += "<div class='date'>" + date.format('ddd MMM DD YYYY') + "</div>";
                html += "</div>";
                return html;
            }
        });
        return cols;
    }

    function init_table(){
        var columns = gen_columns();        
        var column_toggler = new ColumnToggler({
            table: '#audit_table',
            columns: columns
        });
        self.datatable = $('#audit_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_audit",
            "aoColumns": columns,
            "bServerSide": true,
            "sScrollY": '100%',
            "bAutoWidth": false,
            "bDestroy": true,
            "aaSorting": [[ 4, "desc" ]],
            "sDom": 't<".dataTables_pages"ip>',
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            oLanguage: DATATABLES_LANG,
            fnServerData: report_playback_page.server_data,
            fnInitComplete: function(){
                column_toggler.init(self.datatable);
            },
            "fnRowCallback": function(row, oData){
            },
            "fnDrawCallback": function() {
                $('#reports_table_wrap .dataTables_scrollBody').scrollTop(0);
                $(".tags .tag").each(function(i, dom){
                    var dom = $(dom);
                    if(dom.css("background-color") != "rgb(170, 170, 170)"){
                        var parent = dom.parent()
                        dom.remove().appendTo(parent)
                    }
                });
            }
        });
        self.datatable.fnSetFilteringDelay(800);

        //add the datepicker
        $('.audit_date_picker').datepicker({
            showAnim: 'slideDown',
            beforeShowDay: function(date){
                if(date.toString() == new Date(self.today).toString()){
                    return [true, 'datepicker_custom_day_select'];
                }
                else{
                    return [true, '']
                }
            },
            onSelect: function(event) {
                $(this).change();
            }
        });
        $('.audit_date_picker').change(function(){
            var input = $(this)
            input.datepicker('hide');
            var field = input.attr("data-field");
            filter(field, Date.parse(input.datepicker("getDate")) / 1000);

        });
        $('#playback_search').searcher(function(search){
            filter("sSearch", search);
        });
        $('#playback_content_kind').change(function(){
            filter('content_kind', $(this).find(":selected").attr("data-value"));
        });
        $('.clear_button').click(function(){
            var dom = $($(this).attr("data-target"));
            dom.val("").change().keyup();
        });
    }

    function filter(field, value){
        self.filter_data[field] = value;
        self.datatable.fnDraw();
    }   
}
