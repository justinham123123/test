var title_edit_page = new TitleEditPage();

function TitleEditPage() {
    var self = this;
    self.contents = {};
    self.contents_count = 0;
    self.title = undefined;
    self.title_uuid;
    //Templates
    self.main_tmpl = '#title_edit_tmpl';
    self.form;
    self.drag_list = undefined;
	self.content_tabs = [
		{value:'feature', translated_title: gettext('New Features')},
		{value:'trailer', translated_title: gettext('New Trailers')},
		{value:'rating', translated_title: gettext('New Ratings')},
		{value:'content', translated_title: gettext('All Content')}
	];
	
    //Methods
    self.content_call_data = {
        iDisplayLength: 50,
        sSearch: null,
        type_filter: null
    };

    self.draggable_defaults = {
        helper: function(){            
            return $(this).clone().css({
                'width': $(this).width(),
                'margin': 0
            });
        },
        cursorAt: {
            top: 2
        },
        containment : '#main_section',
        connectToSortable :'.title_edit_title_container',
        appendTo :'#main_section',
        tolerance :'intersect', 
        drag: function(){

        },
        start: function(){
            $('#title_edit_title_container').addClass("drop_enabled");
        },
        stop: function(){
            $('#title_edit_title_container').removeClass("drop_enabled");
        }
    };

    self.open = function(title_uuid) {
        var doc;
        self.title_uuid = title_uuid;
        
        doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load.title_edit_page', self._close_page);
        
        nav_select('content', 'title');
        
        $(self.main_tmpl).tmpl({content_tabs: self.content_tabs}).appendTo($('#main_section').empty());
        
        helpers.set_buttons('#title_actions', [
            {text:gettext('Save'), image:'save', onClick: self.save, title:gettext('Save'), _class:"jq_save_title_button"}
        ]);

        self.drag_list = new DragList({
            search_dom: ".title_edit_content_body_search",
            search_input: "#title_content_search_input",
            list_dom: ".title_edit_content_body_main",
            device_id: undefined,
            draggable_defaults: self.draggable_defaults
        });

        _load_title();
    
        // listeners
        $('.title_edit_content_tab').click(_select_content_tab);
        $('.title_edit_content_tab:first-child').click();

        $('#main_section').on(
            'click.title_edit_page',
            '#clear_filter_button',
            function(){
                $('#title_content_search_input').val("");
                $("#title_content_search_filter").val("").trigger("change");
            }
        );
        
        $(document).trigger('page_loaded');
        _changes_made(false);
    };

    self._close_page = function() {
        $(document).off('page_load.title_edit_page');
    };
    
    self.save = function() {
        if (self.form.checkForm()) {
            self.title.external_titles = [];

            //external id mappings
            $('.external_title').each(function(i, item){
                var dom = $(item);
                var source = dom.attr("data-source");
                var external_id = dom.attr("data-external_id");
                self.title.external_titles.push({'source': source, 'external_id': external_id});
            });

            //Convert cpls array to keyed object for saving
            var cpl_uuids = [];
            //Save first, in case the save fails
            var original_cpls = self.title.cpls.slice(0);
            for(var i in self.title.cpls){
                cpl_uuids.push(self.title.cpls[i].uuid);
            }
            self.title.cpls = cpl_uuids;

            self.title.name = $('#title_name').val();
            self.title.credits_offset = parseInt($('#credits_offset').val()) || null;
            self.title.year = parseInt($('#year').val()) || null;
            
            helpers.ajax_call({
                url:'/core/title/save',
                data:{
                    'title': self.title
                },
                success_function: function(input){
                    if(input.uuid != undefined){
                        _changes_made(false);
                        history.pushState(null, null, '#title_page');
                        title_page.open();
                    }
                },
                error_function: function() {
                    self.title.cpls = original_cpls;
                },
                headers:{
                    'Return-Complete':'true'
                }
            });
        }
        else {
            notification.info_msg(gettext('Please fill out all required fields'));
            self.form.showErrors();
        }
    };
    
    function _load_title() {
        if(self.title_uuid != undefined){
            helpers.ajax_call({
                url:'/tms/get_title_detailed',
                data:{
                    title_uuid: self.title_uuid
                },
                success_function: function(input){
                    self.title = input['data'];
                    draw_title();
                }
            });
        }
        else{
            self.title = {
                'id': undefined,
                'name': null,
                'credits_offset': null,
                'year': null,
                'external_ids': [],
                'ratings': [],
                'cpls': []
            };
            draw_title();
        }
    }
    
    function add_to_title(cpl_uuid){
        //don't add twice
        var cpl = $.grep(self.title.cpls, function(cpl){
            return cpl.uuid == cpl_uuid;
        })[0];
        if (cpl == undefined){
            //where are we adding?         
            var cpl = $.grep(self.contents, function(item){
                return item.uuid == cpl_uuid;
            })[0];
            self.title.cpls.push(cpl);
            add_to_title_dom(cpl);
            _changes_made();
        }
        else{
            notification.info_msg(gettext('That CPL has already been added'));
        }
    }

    function add_to_title_dom(cpl){
        cpl = parse_cpl(cpl);
        $('#title_edit_cpl_tmpl').tmpl({"cpl": cpl}).appendTo(".title_edit_title_container");
        $('.title_edit_title_cpl .cpl_delete').click(remove_cpl_click);        
    }
    
    function parse_cpl(cpl){
        var translated_playback_mode = false;
        switch(cpl.playback_mode) {
            case '2D': translated_playback_mode = 'icon-two-d'; break;
            case '3D': translated_playback_mode = 'icon-three-d'; break;
        }
        if (translated_playback_mode !== false){
            cpl.playback_mode = translated_playback_mode;
        }
        cpl.subtitled = cpl.subtitled ? cpl.subtitle_language?cpl.subtitle_language:'XSUB' : '';
        return cpl;
    }
    
    function draw_title(){
        $('#title_info_tmpl').tmpl(self.title).appendTo($('#title_edit_info_section').empty());
        $('#title_edit_title_tmpl').tmpl().appendTo($('#title_edit_title_section').empty());
        
        /*
        set up the droppable jquery ui for the title
        this takes care of:
            content being added
        */
        $('.title_edit_title_container').droppable({
            activeClass : 'drop_enabled',
            drop: function(event, ui) {
                add_to_title(ui.helper.attr('cpl_uuid'));
            }
        });
        
        //Event binds
        $('.external_title .delete_button').click(function(){
            var id = $(event.target).attr("data-id");
            $('.external_title[data-id="'+id+'"]').remove();
            _changes_made();
        });
        
        self.set_up_ratings(self.title.ratings, _changes_made);
        
        $('#title_name,#year,#credits_offset').on("keyup, change",_changes_made);
        
        self.form = $('#title_info_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            }
        });
        self.form.checkForm();
        
        show_title_cpls();
    }
    
    /* This functionality is shared by the pack edit page. Be careful! */
    self.set_up_ratings = function(ratings, changes_made_func) {
        $('.title_rating .delete_button').click(delete_rating);
        $('#territory').val($complex_status.country_code).on('change', load_ratings);
        load_ratings();
        $('#rating').change(add_rating);
        
        function delete_rating(event){
            var territory = $(event.target).attr("data-territory");
            $('.title_rating[data-territory="'+territory+'"]').remove();
            for(var i in ratings){
                var r = ratings[i];
                if(r.territory === territory) {
                    ratings.splice(i, 1);
                }
            }        
            changes_made_func();
        }
        
        function load_ratings() {
            var territories = $complex_status.territories[$('#territory').val()];
            if(territories !== undefined){
                $('#rating_select_tmpl').tmpl({ratings: territories.ratings}).appendTo($('#rating').empty());
            }
        }
        
        function add_rating() {
            var rating = $('#rating').val();
            var territory = $('#territory').val();

            if(rating && territory){
                for(var i in ratings){
                    var r = ratings[i];
                    if(r.territory === territory){
                        ratings.splice(i, 1);
                    }            
                }
                ratings.push({rating: rating, territory: territory});
                $('#title_rating_info_tmpl').tmpl({ratings: ratings}).appendTo($('#jq_title_rating_info').empty());
                $('.title_rating .delete_button').click(delete_rating);
                changes_made_func();
            }
        }
    };    
    
    function show_title_cpls(){
        $(this).addClass('selected').siblings().removeClass('selected');
        $('.title_edit_title_container').empty();
        
        for(var i in self.title.cpls){
            add_to_title_dom(self.title.cpls[i]);
        }
    }

    function remove_cpl_click(event){
        var cpl_uuid = $(event.target).attr("data-cpl_uuid");
        $('.title_edit_title_cpl_wrap[data-cpl_uuid="'+cpl_uuid+'"]').remove();
        for(var i in self.title.cpls){
            var cpl = self.title.cpls[i];
            if(cpl['uuid'] == cpl_uuid){
                self.title.cpls.splice(i, 1);
            }
        }
        _changes_made();
    }

    function _select_content_tab(mouse_event) {
        var tab_value = $(this).attr('tab_value');
        $(this).addClass('selected').siblings().removeClass('selected');
        set_filter_values();
        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.draw({
                main_template: '#content_drag_list_item_tmpl',
                search_template: '#title_edit_content_search_tmpl',
                drag_list: drag_list,
                filter_func: update_content_tab,
                double_click_func: double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });    
            $('#title_content_search_filter').change(update_content_tab);
            if (tab_value == 'content'){
                $('#title_content_search_filter').show();
                $('#clear_filter_button').show();                
            } else {              
                $('#title_content_search_filter').hide();
                $('#clear_filter_button').hide();
            }
        });
    }

    function set_filter_values(){
        var tab_value = $('.jq_content_selection.selected').attr("tab_value");
        if (tab_value == 'content'){
            self.content_call_data['type_filter'] = $('#title_content_search_filter').val();
            self.content_call_data['orphaned'] = false;
        }
        else{
            self.content_call_data['type_filter'] = tab_value;
            self.content_call_data['orphaned'] = true;
        }

        self.content_call_data['sSearch'] = $('#title_content_search_input').val();
    }

    function get_contents(callback){
        helpers.ajax_call({
            url:'/core/paginated/get_draglist_content',
            data: self.content_call_data,
            success_function: function(data){
                self.contents = data.aaData;
                self.contents_count = data.iTotalDisplayRecords;
                callback();
            }
        });
    }    

    function update_content_tab(){
        set_filter_values();
        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.update({
                main_template: '#content_drag_list_item_tmpl',
                drag_list: drag_list,
                double_click_func: double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });
        });
    }

    function double_click(){
        add_to_title($(event.target).closest(".list_edit_drag_item_wrap").attr('cpl_uuid'));
    }

    function gen_content_list(){
        var drag_list = [];
        var len = self.contents.length;
        var i = 0;
        while(i < len){
            var cpl = self.contents[i];
            cpl = parse_cpl(cpl);
            drag_list.push(cpl);
            i++;
        }
        return drag_list;
    }

    function load_tab(getter, callback){
        var loader = new Loader({target: $(".title_edit_content_body_main")});
        loader.show(function(){ 
            getter(function(){
                callback();
                loader.hide();
            });
        });  
    }

    function _changes_made(bool){
        bool = typeof bool != 'undefined' ? bool : true;
        g_prevent_navigation = bool;
        $('.jq_save_title_button').button("option","disabled",!bool);
    }    
}
