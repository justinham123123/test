var complex_config_page = new ComplexConfigPage();
function ComplexConfigPage() {
    var self = this;

    var reload_function;
    var reload_uuid;
    var temp_move_index;

    var current_editable = {};
    var show_attributes = {};

    //Templates
    var tmpl_main = '#tmpl_main';
    var tmpl_menu = '#tmpl_menu';
    var tmpl_devices = '#tmpl_devices';
    var tmpl_screens = '#tmpl_screens';
    var tmpl_complex_info = '#tmpl_complex_info';
    var tmpl_screen_details = '#tmpl_screen_details';
    var tmpl_device_busy = '#tmpl_device_busy';

    self.check_pos_devices = null;
    self.syncing_device_info = false;

    //Methods
    self.open = function(content_id) {
        $document.trigger('page_load');
        $document.one('page_load.complex_config', close_page);
        nav_select('config', 'complex');
        if(self.syncing_device_info == false){
            sync_complex_device_status();
        }

        $(tmpl_main).tmpl().appendTo($('#main_section').empty());

        load_menu(content_id);
        load_show_attributes();

        $device_store.on('loaded', update_statuses);
        $document.trigger('page_loaded');

        $('#complex_config_wrap').resize(fix_menu_heights);

        self.check_pos_devices = true;
        self._update_pos_device_statuses();
        //will be set to true after an lms resync is forced
        //needed for updating lms corrupt cpls status
        self.resynced = false;
    };

    function close_page() {
        $document.off('page_load.complex_config', close_page);
        $device_store.off('loaded', reload);
        $device_store.off('loaded', update_statuses);
        self.check_pos_devices = false;
        self.syncing_device_info = false;
        $('#complex_config_wrap').off("resize");
    }

    function sync_complex_device_status(){
        sync_device_infos(false);
        self.syncing_device_info = true;
        setTimeout(function(){
            if( window.location.hash.indexOf("complex_config_page") != -1 ){
                sync_complex_device_status();
            }
        }, 3000);
    }

    function fix_menu_heights(){
        var header_height = $('#complex').outerHeight();
        var menu = $('#buttons');
        menu.css("top", header_height);
        var menu_height = menu.outerHeight();
        var screens = $('#screens_wrapper');
        var devices = $('#devices_wrapper');
        screens.css("height", "auto");
        devices.css("height", "auto");
        var devices_height = devices.outerHeight();
        var screens_height = screens.outerHeight();
        var fifty = menu.outerHeight() / 2;
        if(devices_height + screens_height > menu_height){
            if(devices_height >= fifty && screens_height >= fifty){
                screens.css("height", "50%");
                devices.css("height", "50%");
            }
            else if(devices_height >= fifty){
                var new_height = menu_height - screens_height;
                devices.css("height", new_height);
            }
            else if(screens_height >= fifty){
                var new_height = menu_height - devices_height;
                screens.css("height", new_height);
            }
        }
    }

    function update_lms_corrupt_cpls(){
        helpers.ajax_call({
            url:'/tms/get_lms_corrupt_content',
            success_function: function(input){
                var show = false;
                $.each(input, function(type, items){
                    if(items.length > 0){
                        show = true;
                    }
                });
                self.corrupted_content = input;
                $('.jq_lms_corrupt_cpls').toggle(show);
            }
        });
    }

    function resync_lms(){
        helpers.ajax_call({
            url:'/core/lms_resync',
            notify: true
        });
        self.resynced = true;
    }

    function show_lms_errors(){
        var buttons = [];
        buttons.push({
            'text': gettext('Done'),
            'action': dialog.close
        });
        var corrupt_cpls_dialog = dialog.open({
            'title': gettext('Corrupt content'),
            'template': '#configuration_corrupt_content_tmpl',
            'data': {corrupted_content: self.corrupted_content},
            'width': 250,
            'buttons': buttons
        });
    }

    function rescan_ftp_folder(){
        var device_id = $(this).attr('device_id');
        helpers.ajax_call({
            url:'/core/configuration/ftp_rescan',
            data:{"ftp_device_id":device_id},
        });
    }

    function update_statuses(){
        $(".status.jq_device_status").each(function(){
            var device_id = $(this).attr("device_id");
            var device = $device_store.devices[device_id];
            if(device){
                if(device.status && !$(this).hasClass(device.status)){
                    $(this).attr("class", "status jq_device_status " + device.status);
                }
                if($(this).hasClass('error') || $(this).hasClass('unknown')){
                    attach_device_error_tip($(this));
                }
                if(device.content_scan_active != undefined){
                    if(device.content_scan_active){
                        if( device.content_scan_done != undefined){
                            var progress = parseInt(device.content_scan_done/device.content_scan_remaining*100);
                            _toggle_device(device_id, false, gettext("Syncing content"), progress);
                        }else{
                            _toggle_device(device_id, false, gettext("Syncing content"));
                        }
                    }else{
                        if(self.resynced == true){
                            if( device.category == "lms"){
                                update_lms_corrupt_cpls();
                            }
                            self.resynced = false;
                        }
                        _toggle_device(device_id, true, gettext("Syncing content"));
                    }
                    if( (device.category == "lms" || device.category == "ftp_folder") && device.content_scan_stamp != undefined){
                        _update_sync_stamp(device_id, helpers.small_date_format(new Date(device.content_scan_stamp*1000)));
                    }
                }
            }
        });
        $(".jq_device_enable_status").each(function(){
            if( $(this).attr("device_id") && $device_store.devices[$(this).attr("device_id")] != undefined){
                var enabled = $device_store.devices[$(this).attr("device_id")].enabled;
                if( $device_store.devices[$(this).attr("device_id")].enabled == true){
                    $(this).addClass("enabled").removeClass('disabled');
                }else{
                    $(this).addClass("disabled").removeClass('enabled');
                }
            }
        });

    }

    function _update_sync_stamp(device_uuid, stamp){
        var device = $(".block.device[device_id='" + device_uuid + "']");
        $(device).children(".jq_sync_stamp").html(gettext("Scanned") + ": " + stamp);
    }

    function _toggle_device(device_uuid, available, message, progress){
        var device = $(".block.device[device_id='" + device_uuid + "']");
        var prog_bar = $(device).find(".jq_sync_progress_bar");
        var busy = $(device).find(".jq_device_busy");
        var html_message = progress == undefined ? message : message + ": " + progress.toString() + "%";
        if( !available ){
            if( $(busy).length == 0 ){
                $(tmpl_device_busy).tmpl({
                    "message" : html_message,
                    "progress" : progress,
                    "id" : device_uuid
                }).appendTo($(device));
            }else{
                $(busy).find(".device_busy_message_message").html(html_message);
            }
            if( progress != undefined ){
                $(device).find(".jq_sync_progress_bar").css('width', progress.toString() + "%");
            }
        }else{
            if( prog_bar.length == 1 ){
                $(device).find(".jq_sync_progress_bar").css('width',"99%");
                $(busy).find(".device_busy_message_message").html(message + ": 100%");
                setTimeout(function(){$(busy).remove();},2000);
            }else{
                $(busy).remove();
            }
        }
    }

    self._update_pos_device_statuses = function(){
        if( $complex_status.pos.enabled == true ){
            for(var pos_device_uuid in pos_devices_syncing){
                if($device_store.devices[pos_device_uuid] == undefined || $device_store.devices[pos_device_uuid].category != "lms"){
                    _toggle_device(pos_device_uuid, !pos_devices_syncing[pos_device_uuid], gettext("Syncing POS Feed"));
                }
            }
            self.updating_pos_devices = true;
        }else{
            for(var pos_device_uuid in pos_devices_syncing){
                if($device_store.devices[pos_device_uuid] == undefined || $device_store.devices[pos_device_uuid].category != "lms"){
                    _toggle_device(pos_device_uuid, false, gettext("POS is disabled"));
                }
            }
        }
        if(self.check_pos_devices){
            setTimeout(self._update_pos_device_statuses,2000);
        }
    };

    function load_menu(content_id){
        if (content_id == undefined && $('.jq_tab.selected').length){
            if ($('.jq_tab.selected').attr('screen_uuid') != undefined){
                content_id = $('.jq_tab.selected').attr('screen_uuid');
            }
            else if ($('.jq_tab.selected').hasClass('devices')){
                content_id = 'devices';
            }
            else if ($('.jq_tab.selected').hasClass('screens')){
                content_id = 'screens';
            }
        }

        $(tmpl_complex_info).tmpl().appendTo($('#complex_info').empty());

        $(tmpl_menu).tmpl({
            'screens': get_screens(),
            'devices': get_complex_devices()
        }).appendTo($('#buttons').empty());

        $('#buttons .devices').clickOrEnter(load_devices);
        $('#buttons .devices .add').clickOrEnter(edit_device);
        $('#buttons .screens').clickOrEnter(load_screens);
        $('#buttons .screens .add').clickOrEnter(edit_screen);
        $('#buttons .screen .jq_edit_screen').clickOrEnter(edit_screen);

        $('#buttons .screen').clickOrEnter(function(){
            var screen_uuid = $(this).attr("screen_uuid");
            load_screen_view(screen_uuid);
        });

        // config check
        $('.jq_config_check').on('click', function(event) {
            event.stopPropagation();
            if( $(this).attr("target") == "complex" ){
                open_device_config_check();
            }else{
                open_screen_config_check();
            }
        });
        fix_menu_heights();

        if(content_id == 'devices') {
            load_devices();
        }
        else if(content_id == 'screens') {
            load_screens();
        }
        else if(content_id){
            load_screen_view(content_id);
        }
        else{
            $('#buttons .devices').click();
        }
    }

    function load_screen_view(uuid){

        history.pushState(null, null, '#complex_config_page#'+uuid);

        select_tab($('#screens_wrapper li[screen_uuid='+uuid+']'));

        $(tmpl_screen_details).tmpl({
            'screen': $device_store.screens[uuid]
        }).appendTo($('#content').empty());

        $('#devices').on('click.complex_config', '.jq_delete_device', delete_device);
        $('#devices').on('click.complex_config', '.jq_reboot_device', reboot_device);
        $('#devices').on('click.complex_config', '.jq_server_certificates', server_certificates);
        $('#devices').on('click.complex_config', '.jq_device_enable_status', toggle_device);
        $('#devices').on('click.complex_config', '.jq_edit_device', edit_device);
        $('#devices').on('click.complex_config', '.jq_add_device', edit_device);
        $('#content').on('click.complex_config', '.jq_add_device', edit_device);
        $('#content').off('click.complex_config');

        reload_function = _.bind(load_screen_view, null, uuid);
        reload_uuid = uuid;
        var max = 0;
        $.each($('#devices .device .info'), function(i,v)
        {
            if($(v).height() > max)
                max = $(v).height();
        });
        $('#devices .device .info').height(max);
    }

    function load_show_attributes() {
        return helpers.ajax_call({
            url:'/core/configuration/show_attribute',
            data: {
                'include_screen': true,
                'include_cpl': false,
                'include_other': false},
            success_function:update_show_attributes
        });
    }

    function update_show_attributes(input) {
    	show_attributes = input.data;
    }

    function select_tab(obj){
    	$('.jq_tab').removeClass('selected');
    	$(obj).addClass('selected');
    }

    function get_screens(){
        var screens = helpers.get_screen_list();
        for( var screen_id in screens){
            screens[screen_id]["enabled"] = false;
            for( var device_id in screens[screen_id].devices){
                    if(screens[screen_id].devices[device_id] != undefined && screens[screen_id].devices[device_id].enabled == true){
                    screens[screen_id].enabled = true;
                }
            }
        }
        return screens;
    }

    function load_devices(){
        update_lms_corrupt_cpls();
        history.pushState(null, null, '#complex_config_page#devices');
        $(tmpl_devices).tmpl({
            'devices': get_complex_devices()
        }).appendTo($('#content').empty());
        select_tab($('#devices_wrapper .devices'));

        $('#devices').on('click.complex_config', '.jq_resync_lms', resync_lms);
        $('#devices').on('click.complex_config', '.jq_lms_corrupt_cpls', show_lms_errors);
        $('#devices').on('click.complex_config', '.jq_rescan_ftp', rescan_ftp_folder);
        $('#devices').on('click.complex_config', '.jq_delete_device', delete_device);
        $('#devices').on('click.complex_config', '.jq_edit_device', edit_device);
        $('#devices').on('click.complex_config', '.jq_reboot_device', reboot_device);
        $('#devices').on('click.complex_config', '.jq_server_certificates', server_certificates);
        $('#devices').on('click.complex_config', '.jq_sync_pos_device', sync_pos_device);
        $('#devices').on('click.complex_config', '.jq_device_enable_status', toggle_device);
        $('#content').off('click.complex_config');
        $('#content').on('click.complex_config', '.jq_add_device', edit_device);
        reload_function = load_devices;
        for( var uuid in $device_store.devices ){
            if( $device_store.devices[uuid].category == "pos" && $complex_status.pos.enabled == false){
                _toggle_device(uuid, false, gettext("POS is disabled"));
            }else{
                _toggle_device(uuid, true);
            }
        }
    }

    function load_screens(){

        history.pushState(null, null, '#complex_config_page#screens');
        $(tmpl_screens).tmpl({
            'screens':get_screens(),
            'show_attributes':show_attributes
        }).appendTo($('#content').empty());

        select_tab($('#screens_wrapper .screens'));

        $('#screens').onClickOrEnter('.jq_delete_screen', delete_screen);
        $('#screens').onClickOrEnter('.jq_edit_screen', edit_screen);
        $('#screens').onClickOrEnter('.jq_add_screen', edit_screen);
        $('#screens').onClickOrEnter('.jq_add_device', edit_device);
        $('#screens').onClickOrEnter('.jq_device_top', expand_device);
        $('#screens').onClickOrEnter('.jq_device_switch', toggle_device);
        $('#screens').onClickOrEnter('.jq_delete_device', delete_device);
        $('#screens').onClickOrEnter('.jq_edit_device', edit_device);
        $('#screens').onClickOrEnter('.jq_reboot_device', reboot_device);
        $('#screens').onClickOrEnter('.jq_server_certificates', server_certificates);
        $('#content').off('click.complex_config');

        reload_function = load_screens;
    }

    function attach_device_error_tip(device_dom){
        var device = $device_store.devices[device_dom.attr('device_id')];
        if(!device.status){
            return
        }
        if('object' !== typeof $(device_dom).data('qtip')){
            device_dom.qtip({
                content: {
                    text: $('#tmpl_device_status_tip').tmpl({device: device})
                },
                position: {
                    my: "bottom center",
                    at: "top center",
                    viewport: $(window)
                },
                show: {
                    event: 'click mouseover',
                    solo: true,
                    ready: false
                },
                hide: {
                    delay: 100,
                    event: 'unfocus mouseleave',
                    fixed: true
                },
                style: {
                    classes: 'qtip-shadow qtip-rounded qtip-light'
                }
            });
        }
        else{
            device_dom.qtip('option', 'content.text', $('#tmpl_device_status_tip').tmpl({device: device}))
        }
        var classes = 'qtip-light';
        switch(device.status)
        {
            case 'error' : classes = 'qtip-light'; break;
            case 'unknown' : classes = 'qtip-dark'; break;
        }
        device_dom.qtip('option', 'style.classes', 'qtip-shadow qtip-rounded ' + classes);
    }

    function get_complex_devices(){
        var devices = $device_store.devices;
        var ret = {};
        $.each(devices, function(i,v){
            if(!$._in(v.category, ["sms", "projector", "camera", "external", "audio"]) && !v.screen_uuid){
                ret[i] = v;
            }
        });
        return ret;
    }

    function expand_device(event){
        if(event.target != this)
            return;
        var extra = $(this).siblings('.extra');
        $(this).parents('.devices').find('.showing').animate({"height": 0}, 400, "easeOutQuad", function()
        {
            $(this).removeClass('showing');
        });
        var start = $(extra).height();
        var end = 0;
        if($(extra).height() == 0)
        {
            $(extra).height("auto");
            end = $(extra).height();
        }
        $(extra).height(start);

        $(extra).animate({"height": end}, 400, "easeOutQuad", function()
        {
            $(extra).height(end);
            $(this).addClass("showing");
        });
    }

    function reload(){
        $device_store.one('loaded', function(){
            reload_function();
            load_menu();
        });

        //pos device takes longer to remove so we can't assume it
        //will be gone the next time the device store is loaded
        //only know its done after the change event
        $device_store.one('change', function(){
            reload_function();
            load_menu();
        });
        
        sync_complex_infos();
        sync_complex_status();
    }

    function toggle_device(){
        var dom = $(this);
        if(!dom.attr("disabled") && !dom.hasClass('loading')){
            var spinner = new Spinner({'dom': dom});
            dom.removeClass('icon-switch');
            spinner.spin();
            dom.closest(".jq_device_top").stop();
            dom.addClass("loading");
            helpers.ajax_call({
                url:'/core/configuration/set_enabled',
                data:{
                    'device_id': dom.attr('device_id'),
                    'enabled': dom.hasClass('disabled')
                },
                success_function: function(){
                    spinner.stop();
                    reload();
                }
            });
        }
    }

    function save_screen() {
        current_editable.identifier = $.val_or_undefined($('#config_edit_identifier').val());
        current_editable.title = $.val_or_undefined($('#config_edit_title').val());
        current_editable.capacity = $.val_or_undefined($('#config_edit_capacity').val());
        if( current_editable.capacity < 0 ){
            current_editable.capacity = null;
        }
        helpers.ajax_call({
            url:'/core/configuration/save_screen',
            data:{'screens':[current_editable.return_saveable()]},
            success_function:reload
        });
    }

    function delete_screen(){
        if(!confirm(gettext("Are you sure you want to delete this screen?")))
            return;
        var screen_uuid = $(this).attr('screen_uuid');
        helpers.ajax_call({
            url:'/core/configuration/delete_screen',
            data:{'screen_uuids': [screen_uuid]},
            success_function:reload
        });
    }

    function delete_device(){
        var device_id = $(this).attr('device_id');
        if( !$(this).attr("disabled") ){
            if(!confirm(gettext("Are you sure you want to delete this device?")))
                return;
            helpers.ajax_call({
                url:'/core/configuration/delete_device',
                data:{'device_ids': [device_id]},
                success_function:reload
            });
        }
    }

    function save_device() {
        
        var config_table = $(".device_config_table").filter(":visible");
        current_editable.ip = $.val_or_undefined($(config_table).find('#config_edit_ip:visible').val());
        current_editable.port = $.val_or_undefined($(config_table).find('#config_edit_port:visible').val());
        current_editable.api_username = $.val_or_undefined($(config_table).find('#config_edit_api_username:visible').val());
        current_editable.api_password = $.val_or_undefined($(config_table).find('#config_edit_api_password:visible').val());
        current_editable.ftp_ip = $.val_or_undefined($(config_table).find('#config_edit_ftp_ip:visible').val());
        current_editable.ftp_port = $.val_or_undefined($(config_table).find('#config_edit_ftp_port:visible').val());
        current_editable.ftp_username = $.val_or_undefined($(config_table).find('#config_edit_ftp_username:visible').val());
        current_editable.ftp_password = $.val_or_undefined($(config_table).find('#config_edit_ftp_password:visible').val());
        current_editable.name = $.val_or_undefined($(config_table).find('#config_edit_name:visible').val());
        current_editable.path = $.val_or_undefined($(config_table).find('#config_edit_path:visible').val());
        current_editable.model = $(config_table).find('#config_edit_model:visible').val();
        current_editable.auto_sync = $('#config_edit_auto_sync:visible').val();
        current_editable.auto_ingest = $('#config_edit_auto_ingest:visible').val();
        current_editable.cert_path = $('#config_edit_cert_path:visible').val();
        helpers.ajax_call({
            url:'/core/configuration/save_device',
            data: {
                'device': current_editable.return_saveable()
            },
            success_function: reload
        });
    }

    function edit_screen(){
    	var screen_uuid = $(this).attr('screen_uuid');
    	var title, edit_mode, form, current_screen_number;

    	//set the current editable object
    	if(screen_uuid == undefined){
        	current_editable = new Screen();
        	title = gettext("Add new Screen");
        	edit_mode = false;
    	}
        else{
    		current_editable = $device_store.screens[screen_uuid];
    		title = gettext("Edit Screen");
    		edit_mode = true;
    	}

        // "are you sure?" dialog box
        var buttons = [];
        var _save = function(event){
            if(!$(event.currentTarget).hasClass('disabled')){
                $(event.currentTarget).addClass('disabled');
                var screen_exists = false;
                for( screen_uuid in $device_store.screens ){
                    if( $device_store.screens[screen_uuid].identifier == $('#config_edit_identifier').val() ){
                        if( current_screen_number != $device_store.screens[screen_uuid].identifier ){
                            screen_exists = true;
                            break;
                        }
                    }
                }
                if( !screen_exists ){
                    if($('#complex_config_edit_screen_form').valid()){
                        $('#config_screen_id_exists').hide();
                        save_screen();
                        dialog.close();
                    }
                }else{
                    $('#config_screen_id_exists').show();
                }
                $(event.currentTarget).removeClass('disabled');
            }
        };
        buttons.push({
            'text': gettext('Save'),
            'action': _save
        });

        var transfer_dialog = dialog.open({
            'title': title,
            'template': '#complex_config_edit_screen_tmpl',
            'data':{'screen':current_editable, 'show_attributes':show_attributes},
            'width':"auto",
            'buttons':buttons
        });

        _add_d_tab_handlers();

        $('#complex_config_edit_screen_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            },
            highlight: function(element){
                $(element).addClass("error");
            },
            unhighlight: function(element){
                $(element).removeClass("error");
            }
        });

        $('#config_edit_identifier, #config_edit_title').keypress(function(event){
            if( event.keyCode == 13){
                event.preventDefault();
                _save(event);
            }
        });

        current_screen_number = $('#config_edit_identifier').val();

        //need to get names for the show attr ids
        current= {};
        for (var position in current_editable.show_attributes){
            current[current_editable.show_attributes[position]] = show_attributes[current_editable.show_attributes[position]]['name']
        }

        var attribute_list = new ShowAttributeSelector({
            dom: $('#show_attributes').empty(),
            show_attributes: show_attributes,
            current: current,
            show_screen: true,
            click: function(target, attribute){
                current_editable.show_attributes = $('.show_attribute.selected').map(function(){return $(this).attr('data-uuid')}).get();
            }
        });
    }

    function edit_device(){
    	var device_id = $(this).attr('device_id');
    	var title = "";

    	if( !$(this).attr("disabled") ){
        	//set the current editable object
        	if(device_id == undefined){
        		current_editable = new Device();
            	//if it is new and coming from a screen - will have screen id otherwise this will be undefined
            	if ($(this).attr('screen_uuid')){
    	    		current_editable.screen_uuid = $(this).attr('screen_uuid');
    	    		var screen = $device_store.screens[$(this).attr('screen_uuid')];
    	    		title = gettext("Add New Device") + " - " + screen.identifier + ". " + screen.title;
        		}else{
        			title = gettext("Add New Device");
        		}
        	}else{
    	    	current_editable = $device_store.devices[device_id];
            	if (current_editable.screen_uuid){
    	    		var screen = $device_store.screens[current_editable.screen_uuid];
    	    		title = gettext("Edit") + " " + current_editable.type + " " + gettext("on") + " " + screen.identifier + ". " + screen.title;
        		}else{
        			title = gettext("Edit") + ": " + current_editable.type
        		}
        	}

            // "are you sure?" dialog box
            var buttons = [];
            var _save = function() {
                if ($('#complex_config_edit_device_form').valid()){
                    save_device();
                    dialog.close();
                }
            };
            buttons.push({
                'text': gettext('Save'),
                'action': _save
            });
            var metadata = current_editable.screen_uuid == null ? complex_device_metadata : screen_device_metadata ;
            
            dialog.open({
                'title': title,
                'template': '#complex_config_edit_device',
                'data':{'device':current_editable,'metadata':metadata},
                'buttons':buttons
            });

            $('#device_details').keypress(function(event){
                if( event.keyCode == 13){
                    event.preventDefault();
                    _save(event);
                }
            });
            
            // Add dialog handlers
            _add_d_tab_handlers();
            
            $(".device_sub_type").on("click.complex_config", function(){
                var device_config_table = $(this).siblings(".device_config_table");
                var subtype = $(this).attr("subtype");
                var type = $(this).attr("type");
                if(!$(this).hasClass("selected")){
                    $(this).addClass("selected").siblings(".device_sub_type").removeClass("selected").slideUp(200);
                    show_relevant_fields(device_config_table, subtype, type, device_id);
                    $(device_config_table).slideDown(200);
                }else{
                    $(this).removeClass("selected").siblings(".device_sub_type").slideDown(200);
                    $(device_config_table).slideUp(200);
                }
                current_editable.category = type;
                current_editable.type = subtype;
            });
            
            function show_existing_device_data(){
                if (current_editable.category!='lms'){
                    $('.d_tabs .d_tab[data-target='+current_editable.category+'_device_tab]').click();
                    $('.tab_content #'+current_editable.category+'_device_tab .device_sub_type[subtype='+current_editable.type+']').click();
                }
            }
            
            if (device_id){
                try{
                    show_existing_device_data();
                }catch(e){
                    if(console != undefined && console.log != undefined){
                        console.log(e);
                    }
                }
            }
        	$('#complex_config_edit_device_form').validate({errorPlacement: $.noop});
        }
	}

    function show_relevant_fields(table, subtype, type, existing_device_id){
        
        existing_device = (existing_device_id != undefined)?$device_store.devices[existing_device_id]: false;
        // Grab device defaults
        if(device_defaults[type] != undefined){
            var defaults = device_defaults[type][subtype];
        } else{
            var defaults = null;
        }
        
        // Show relevant fields
        $(table).find("tr").each(function(){
            var field_type = $(this).attr("type");
            var input = $(this).find("input");
            var field_id = $(input).attr("id");
            if( field_id != undefined){
                var field_name = field_id.split("config_edit_")[1]; // a bit shit    
            }
            $(this).toggle(field_type == undefined || field_type == subtype);
            if( field_name != undefined && defaults != undefined && defaults[field_name] != undefined && !existing_device){
                $(input).val(defaults[field_name]);
            }else if(existing_device && existing_device[field_name] != undefined){
                $(input).val(existing_device[field_name]);
            }else{
                if( $(input).attr("type") != "select"){
                    $(input).val("");
                }
            }
        });
        
        // Populate the model number list
        if( screen_device_metadata[type] != undefined){
            var select = $(table).find("#config_edit_model");
            $(select).empty();
            for( index in screen_device_metadata[type][subtype]){
                var model_string = screen_device_metadata[type][subtype][index].model;
                if( model_string != "default"){
                    $(select).append("<option value='" + model_string + "'>" + model_string.toUpperCase() + "</option>");
                }else{
                    $(select).append("<option value='" + model_string + "'>" + gettext("Automatically Detect")+ "</option>");
                }
            }
            if(existing_device && existing_device.model != undefined){
                $(select).val(existing_device.model);
            }
        }
        else if( complex_device_metadata[type] != undefined){
            var select = $(table).find("#config_edit_model");
            $(select).empty();
            for( index in complex_device_metadata[type][subtype]){
                var model_string = complex_device_metadata[type][subtype][index].model;
                if( model_string != "default"){
                    $(select).append("<option value='" + model_string + "'>" + model_string.toUpperCase() + "</option>");
                }else{
                    $(select).append("<option value='" + model_string + "'>" + gettext("Automatically Detect")+ "</option>");
                }
            }
            if(existing_device && existing_device.model != undefined){
                $(select).val(existing_device.model);
            }
        }
    }

	function reboot_device() {
	    if (confirm(gettext('Are you sure you want to reboot the device?'))) {
	        helpers.ajax_call({
	            url: '/core/configuration/reboot_device',
	            data: {device_uuid: $(this).attr('device_id')}
	        });
	    }
	}

    function server_certificates(){
        var device = $device_store.devices[$(this).attr('device_id')];
        var device_certs = null;
        var device_dnqualifiers = null;

        if(device.device_information.hasOwnProperty('product_certificates')){
            device_certs = device.device_information['product_certificates'];
            for (ix in device_certs){
                //Pre-processing line-breaks before they get replaced with spaces by the rendering engine. So we insert here the HTML line-breakd manually.
                device_certs[ix] = device_certs[ix].replace( /\n/g, "<br>" );
            }
        }
        if(device.device_information.hasOwnProperty('dnqualifiers')){
            device_dnqualifiers = device.device_information['dnqualifiers'];
        }

        dialog.open({
            'title': gettext('Server Certificates'),
            'template': '#complex_config_server_certs',
            'data': {'certs':device_certs, 'dnqualifiers': device_dnqualifiers}
        });

        // Add dialog handlers
        _add_d_tab_handlers();
    }

    function sync_pos_device() {
        var device_id = $(this).attr("device_id");
        if($device_store.devices[device_id].enabled == true){
            helpers.ajax_call({
                url:'/core/pos/sync',
                data:{"device_ids": [$(this).attr("device_id")]}
            });
        }else{
            notification.info_msg(gettext("This POS device is disabled. Enable it before trying to sync."));
        }
    }
    
    function draw_screen_capabilities(){
        /*after adding list of avaiable capabilities - set up draggable*/
        $('.screen_edit_drag_item_wrap').draggable({
            helper : function(){return $(this).clone().css({'width': $(this).width()})},
            containment : '#dialog',
            connectToSortable :'#screen_edit_selected_capabilities',
            appendTo :'#screen_edit_selected_capabilities',
            tolerance :'intersect',
            start :function(event, ui){
                var type = ui.helper.attr('type');
                if ($('#screen_edit_selected_capabilities').children('[type="%type"]'.replace('%type', type)).length > 1) {
                    return false;
                }
                $('#screen_edit_selected_capabilities').addClass("drop_enabled");
            },
            stop :function(){$('#screen_edit_selected_capabilities').removeClass("drop_enabled");}
        });
    	$('#complex_config_edit_screen_selected_list_tmpl').tmpl({'selected_list': current_editable.capabilities}).appendTo($('#screen_edit_selected_capabilities').empty());
		$('.audio_level_selection_wrapper').change(select_audio_level);
		$('.jq_capability_delete').click(delete_capability);

		/*
        set up the sortable jquery ui for the selected capabilities of the screen
        this takes care of:
            capabilities fields being added
            The capabilities being sortable
	    */
	    $('#screen_edit_selected_capabilities').sortable({
	        start: function(event,ui) {
	            //set temp_move_index so we know where we are moving from
	            temp_move_index = $('#screen_edit_selected_capabilities > div').index(ui.item);
	        },
	        update: function(event, ui) {
	            var moved_event, target_position;
	            if (temp_move_index == -2) {
	                return;
	            }
	            target_position = $('#screen_edit_selected_capabilities > *').index(ui.item);

                var moved_capability;
                if (temp_move_index !== -1) {
	                moved_capability = current_editable.capabilities.splice(temp_move_index,1)[0];
	            }else {
	            	moved_capability = new ScreenCapability({'name':ui.item.attr('type')});
	            }

	            if(!current_editable.has_capability(moved_capability.name)){
	            	current_editable.capabilities.splice(target_position, 0, moved_capability);
	            }

	        },
	        receive: function(event, ui) {
	            temp_move_index = -1;
	        },
	        stop: function(event, ui) {
	            draw_screen_capabilities();
	        },
	        helper:'clone',
	        appendTo:'#screen_edit_selected_capabilities',
	        containment:'#screen_edit_selected_capabilities',
	        tolerance:'pointer'
	    });
    }

    function select_audio_level(){
        var selected = $(this).find(":selected").attr("audio_level");
    	//update the audio level
        for (var id in current_editable.capabilities) {
        	if(current_editable.capabilities[id].name == 'audio'){
        		current_editable.capabilities[id].value = selected;
        		break;
        	}
        }
    }

    function delete_capability(){
    	var type = $(this).parent().attr('type');
    	//remove from screen
	    for (var i =0; i < current_editable.capabilities.length; i++) {
	    	if(type == current_editable.capabilities[i].name){
	    		current_editable.capabilities.splice(i,1);
	    		break;
	    	}
	    }
    	$(this).parent().remove();
    }

    function open_device_config_check() {
        var buttons = [];
        buttons.push({
            'text': gettext('Test'),
            'action': run_config_check
        });
        dialog.open({
            'title': gettext('Configuration Check'),
            'template': '#complex_config_check_template',
            'data': {devices_: get_complex_devices()},
            'width': 400,
            'buttons':buttons
        });
        run_config_check();
    }

    function open_screen_config_check() {
        var buttons = [];

        // Add buttons
        buttons.push({
            'text': gettext('Test'),
            'action': run_config_check
        });

        // Open dialog
        dialog.open({
            'title': gettext('Configuration Check'),
            'template': '#complex_config_check_template',
            'data': {screens_: get_screens()},
            'width': 400,
            'buttons':buttons
        });
        run_config_check();
    }

    function run_config_check() {
        var device_uuids = [],
            device_uuid;

        //Disable button
        $('#at_button_0').button("option", "disabled", true);

        //Clear status
        $('#complex_config_check_table tr td[data-status]').removeAttr("data-status");

        $('#complex_config_check_table > tbody > tr[data-device_uuid]').each(function() {
            device_uuid = $(this).data('device_uuid');
            device_uuids.push(device_uuid);
            if ($device_store.devices[device_uuid].enabled) {
                if ($device_store.devices[device_uuid].ip && ($device_store.devices[device_uuid].ip == $device_store.devices[device_uuid].ftp_ip)) {
                    $(this).children('td.jq_other_result').text(gettext('Management and content are using the same network'));
                }
            }
            else {
                $(this).children('td:not(:first-child)').attr("data-status", "disabled");
            }

        });

        helpers.ajax_call({
            url: '/core/configuration/test_connection',
            data: {
                device_uuids: device_uuids
            }
        }).then(function(input) {
            var pending_actions = 0;
            var device_uuid, mgmt_action_id, content_action_id, td,
                result_function = function(td, spinner) {
                    return function(action_id, success, message) {

                        //Enable button if all pending actions are done
                        pending_actions--;
                        if(pending_actions == 0){
                            $('#at_button_0').button("option", "disabled", false);
                        }
                        if(!success){
                            td.find(".message").text(message);
                        }
                        var status = success ? "success" : "error";
                        spinner.stop();
                        td.find('.loader_spinner').remove();
                        td.attr("data-status", status);
                    }
                };

            for (device_uuid in input.data) {
                mgmt_action_id = input.data[device_uuid].management;
                td = $('#complex_config_check_table tr[data-device_uuid="%device_uuid"] > td.jq_management_result'.replace('%device_uuid', device_uuid));
                if (mgmt_action_id) {
                    var spinner = new Spinner({'dom': td})
                    td.attr("data-status", "pending");
                    spinner.spin();
                    pending_actions++;
                    $action_store.actions[mgmt_action_id] = {
                        callback: result_function(td, spinner)
                    };
                }
                else {
                    td.attr("data-status", "na");
                }
                content_action_id = input.data[device_uuid].content;
                td = $('#complex_config_check_table tr[data-device_uuid="%device_uuid"] > td.jq_content_result'.replace('%device_uuid', device_uuid));
                if (content_action_id) {   
                    var spinner = new Spinner({'dom': td})             
                    td.attr("data-status", "pending");
                    spinner.spin();
                    pending_actions++;
                    $action_store.actions[content_action_id] = {
                        callback: result_function(td, spinner)
                    };
                }
                else {
                    if ($._in($device_store.devices[device_uuid].type, server_support.content)) {
                        td.find(".message").text(gettext('Not tested'));
                    }
                    else {
                        td.attr("data-status", "na");
                    }
                }
            }
        });
    }
    
    function _add_d_tab_handlers(){
        $('.d_tabs .d_tab').click(function(){
            var target = $(this).attr("data-target");
            $('.d_tabs .d_tab.selected').removeClass("selected");
            $(this).addClass("selected");
            $('.tab_contents').hide();
            $('#'+target).show();
        });
        $('.d_tabs .d_tab:first-child').click();
        
        $('.d_tabs .d_tab[data-target="screen_capabilities_tab"]').click(function(){
            $('#complex_config_edit_screen_drag_list_tmpl').tmpl({'drag_list': screen_capabilities}).appendTo($('#screen_edit_capabilities').empty());
            draw_screen_capabilities();
        });
    }

}
