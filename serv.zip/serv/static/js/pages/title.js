var title_page = new TitlePage();

    function RatingMissing(source){
        $(source).addClass("missing");
        source.src = "/static/img/textures/awsum.png";
        source.onerror = "";
        return true;
    }

function TitlePage() {
    var self = this;
    self.titles = {};
    
    //Templates
    self.main_tmpl = '#title_main_tmpl';
    self.match_dialog_new_tmpl = "#title_match_dialog_new_tmpl";
    self.merge_dialog_tmpl = "#title_merge_dialog_tmpl";
    self.available_title_tmpl = "#title_match_available_title_tmpl";
    self.no_available_title_tmpl = "#title_match_no_available_title_tmpl";
    self.no_unmatched_title_tmpl = "#title_match_no_unmatched_title_tmpl";
    self.unmatched_title_tmpl = "#title_match_unmatched_title_tmpl";
    self.info_placeholder_tmpl = "#title_info_placeholder_tmpl";
    self.external_title_mapping_tmpl = "#external_title_mapping_tmpl";

    // Other stuff    
    self.select_all_toggled = false;
    self.titles_table = null;
    self.unmatched_titles = null;
    self.selected_title = null;
    self.show_ext_mappings = false;
    
    self.open = function() {
        var doc = $(document);
        doc.trigger('page_load');
        doc.bind('page_load.title_page', self._close_page);
        
        nav_select('content', 'title');

        $(self.main_tmpl).tmpl().appendTo($('#main_section').empty());
        
        load_titles_table();

        var buttons = [];

        if(helpers.is_allowed('tms_templating_action')){
            buttons = [
                {text:gettext('New'), image:'new', onClick: new_title, id:"titles_action_new"},
                {text:gettext('Delete'), image:'delete', disabled: true, onClick: delete_click, _class:'disabled jq_enable_on_select', id:"titles_action_delete"},
                {text:gettext('Match Titles'), image:'icon-wand', disabled: true, onClick: match_click_new, _class:'jq_match_titles', id:"titles_action_match_new"},
                //{text:gettext('Mappings'), image:'icon-list', onClick: show_mappings_dialog, title:gettext('Show current mappings'), _class:'titles_mappings', id:'titles_mappings'},
                {text:gettext('Hide Unavailable'), image:'icon-cross', type:'toggle', onClick: filter_unavailable_titles, title:gettext("Hide titles which contain only CPLs that do not exist in the complex"), _class:'titles_filter_unavailable', id:'titles_filter_unavailable'}
            ];
        }

        helpers.set_buttons('#titles_table_controls', buttons);

        if($.cookie('read', 'titles_filter_unavailable') == "true"){
            $('#titles_filter_unavailable').attr("checked", "checked").button("refresh");
        }

        load_unmatched_titles();

        var to;
        $("#titles_datatable_wrapper").on('resize', function(){
            clearTimeout(to);
            to = setTimeout(function(){
                resize();
            }, 200);
        });
        resize();
        add_handlers();
        $(document).trigger('page_loaded');
    };
    
    self._close_page = function() { 
        $(document).off('page_load.title_page');
        $('#boxAT8_wrapper').off('click.titles');
        self.titles_table = null;
        self.unmatched_titles = null;
        self.titles = {};
    }
    
    function add_handlers(){
        // Click handlers        
        $('#boxAT8_wrapper').on(
            'click.titles',
            '#title_merge_available_titles > div.jq_available_title',
            function(){
                $(this).toggleClass("available_title_selected jq_available_title_selected").siblings().removeClass("available_title_selected jq_available_title_selected");
                if( $(this).hasClass("available_title_selected")){
                    $(self.available_title_tmpl).tmpl({"uuid":$(this).attr("title_uuid"),"title":$(this).attr("title"),"selected":true}).appendTo($("#title_match_dialog_wrapper .title_match_right_footer").empty());
                    $("#at_button_1").button("enable");
                }else{
                    $(self.available_title_tmpl).tmpl({"title":gettext("Select Title"),"uuid":null,"selected":false}).appendTo($("#title_match_dialog_wrapper .title_match_right_footer").empty());
                    $("#at_button_1").button("disable");
                }
            }
        );
        $("#titles_datatable, #titles_select_all").on("click.titles",enable_on_selected);
    }
    
    function resize() {
        $('#titles_datatable_wrapper .dataTables_scrollBody').height(
            $('#titles_datatable_wrapper').innerHeight()-
            $('#titles_datatable_wrapper .dataTables_scrollHead').outerHeight() -
            $('#titles_table_controls').outerHeight() -
            $('#titles_datatable_filter').outerHeight() -
            $('#titles_datatable_wrapper .dataTables_pages').outerHeight()
        );

        if(self.titles_table){
            self.titles_table.fnAdjustColumnSizing(false);
        }
    }

    function gen_cols(){
        var dt_cols = [];

        dt_cols.push({
            "bVisible": true,
            "bSortable": false,
            "mDataProp": function(oData, type){
                return '<input type="checkbox" id="' + oData['uuid'] + '" class="title_selector" />'
            }
        });
        dt_cols.push({
            "sClass": 'type-selection',     
            "mDataProp": function(oData, type) {
                return '<span class="title_icon image icon-star"></span><span class="title_name">' + oData.name.escape() + '</span>';
            },
            "bSortable": true,
            "bSearchable": false,
            "bUseRendered": false
        });

        dt_cols.push({
            "sClass": 'type-selection',     
            "mDataProp": function(oData, type) {
                return oData['year'];
            },
            "bSortable": true,
            "bSearchable": false,
            "bUseRendered": false
        });
        
        dt_cols.push({
            "sClass": 'type-selection',     
            "mDataProp": function(oData, type) {
                return oData['credits_offset'];
            },
            "bSortable": true,
            "bSearchable": false,
            "bUseRendered": false
        });
        
        dt_cols.push({
            "sClass": 'type-selection title_last_mod',     
            "mDataProp": function(oData, type) {
                return oData['last_modified'];
            },
            "bSortable": true,
            "bSearchable": false,
            "bUseRendered": false
        });

        return dt_cols;
    }

    function load_unmatched_titles(){
        helpers.ajax_call({
            url:'/core/title/unmatched_titles',
            success_function: function(input){
                self.unmatched_titles = input.data;
                var match_button = $(".jq_match_titles");
                var total = 0;
                for(var source in input.data){
                    for(var title in input.data[source]){
                        total++;
                    }
                }
                if( total > 0){
                    $(match_button).button("enable");
                    $(match_button).button('option', 'label', gettext("Match Titles") + " (" + total.toString() + ")");
                }else{
                    $(match_button).button('option', 'label', gettext("Match Titles"));
                    $(match_button).button("disable");
                }
            }
        });
    }
                    
    function load_titles_table(){
        var columns = gen_cols();        
        var column_toggler = new ColumnToggler({
            table: '#titles_datatable',
            columns: columns
        });
        self.titles_table = $('#titles_datatable').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_titles",
            "aoColumns": columns,
            "bServerSide": true,
            "sScrollY": '100%',
            "bAutoWidth": false,
            "bDestroy": true,
            "aaSorting": [[ 1, "asc" ]],
            "sDom": 'f<"#titles_table_controls">t<".dataTables_pages"ip>',
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            oLanguage: DATATABLES_LANG,
            "fnServerData": serve_titles,
            "fnInitComplete": function(){
                column_toggler.init(self.titles_table);
            },
            "fnRowCallback": function(row, aData){
                self.titles[aData['uuid']] = aData;
                var row = $(row);
                row.attr("data-uuid", aData['uuid']);
                row.click(function(event){
                    $('tr.selected').removeClass("selected");
                    row.addClass("selected");
                    load_title_info(aData['uuid']);
                    self.selected_title = {"uuid":aData['uuid'],"name":aData['name']};
                    // Stop the event propagating. This prevents looping when we click to select the first row on table load
                    if( $(event.target).attr("type") != "checkbox" ){
                        event.stopPropagation();
                    }
                });
            },
            "fnDrawCallback": enable_on_selected
        });
        self.titles_table.fnSetFilteringDelay(800);
        $('#titles_select_all').click(select_all_click);
        $('#titles_datatable_filter input').attr("placeholder", gettext("search"));
    }
    
    function _update_titles_table(){
        self.titles_table.fnDraw();
    }
    
    function filter_unavailable_titles(){
        var ison = $('#titles_filter_unavailable').attr("checked") == "checked";
        $.cookie('write', 'titles_filter_unavailable', ison);
        _update_titles_table();
    }
    
    function enable_on_selected(){
        var disabled = $('.title_selector:checked').length > 0 ? false : true ;
        $('.jq_enable_on_select').button("option", "disabled", disabled);
        var first = $('#titles_datatable tbody tr:first-child');
        if( $(first).attr("data-uuid") != undefined ) {
            $(first).click();
        }else{
            $('#titles_info_pane .title_info').empty();
            $(self.info_placeholder_tmpl).tmpl().appendTo("#titles_info_pane .title_info");
        }
    } 
    
    function load_title_info(title_uuid){
        helpers.ajax_call({
            url:'/tms/get_title_detailed',
            loader: {'target': '#titles_info_pane'},
            data:{
                title_uuid: title_uuid
            },
            success_function: function(input){
                update_title_info(input['data']);
            }
        });
    }

    function update_title_info(title){
        $('#titles_info_pane .title_info').empty();
        $('#title_info_pane_tmpl').tmpl(title).appendTo("#titles_info_pane .title_info");
        var buttons = [];
        if(helpers.is_allowed('tms_templating_action')){
            buttons = [
                {
                        text:gettext('Edit'), 
                        image:'edit',
                        id:"title_action_edit", 
                        onClick: edit_click
                },
                {
                        text:gettext('Merge'),
                        image:'icon-merge',
                        id:"title_action_merge", 
                        onClick: merge_click
                }
                ];
        }
        helpers.set_buttons('#selected_title_controls', buttons);
    }
    
    function serve_titles(sSource, aoData, fnCallback){
        var loader = new Loader({target: '#titles_datatable_wrapper .dataTables_scroll', caption: gettext("Loading Titles")})
        loader.show()
        var data = {};
        for (var i in aoData) {
            data[aoData[i].name] = aoData[i].value;
        }
        data.hide_unavailable = $.cookie('read', 'titles_filter_unavailable') == "true"
        $.ajax({
            "dataType": 'json', 
            "type": "POST", 
            "url": sSource, 
            "data": $.toJSON(data),
            "processData": false,
            "contentType": "application/json",
            "success": function(input){
                fnCallback(input);
                loader.hide();
            }
        });
    }

    function new_title(){
        window.location.hash = '#title_edit_page';
    }
    
    function  edit_click(){
        window.location.hash = '#title_edit_page#' + self.selected_title.uuid;        
    }
    
    function filter_titles(inputfield, list_selector){
        var sstring = $(inputfield).val();
        if(sstring != ''){
            $.when($(list_selector).children().hide()).then($(list_selector).find('>:icontains("'+$(inputfield).val()+'")').show());
        }else{
            $(list_selector).children().show();
        }
    }
    
    self.merge_dialog_storage = {
            'searchtimer': null,
    };
    
    function merge_click(){
        var buttons = [];
        buttons.push({
            "text":gettext("Close"),
            "action":function(){
                dialog.close();
            }
        });
        buttons.push({
            "text":gettext("Merge"),
            "action":_merge_titles,
        });
        dialog.open({
            'title': gettext('Merge Titles'),
            'template': self.merge_dialog_tmpl,
            'width':500,
            'height':320,
            'buttons':buttons,
            'data':{"selected":self.selected_title},
        });

        // List dom, seach dom, search callback
        draw_titles_list({
            'dom': $("#title_merge_available_titles"),
            'search_dom': $('#merge_available_search input'),
            'search_cb': function(){
                $("#at_button_1").button("disable");
            },
            'exclude': [self.selected_title['uuid']]
        });
        
        $("#at_button_1").button("disable");
    }
    
    self.match_dialog_storage = {
            'searchtimer': null,
    };
    
    function match_click_new(){
        var jqitem, order;
        var buttons = [];
        
        buttons.push({
            "text":gettext("Match"),
            "action":_do_match_titles,
        });
        buttons.push({
            "text":gettext("Next"),
            "action":_match_titles_next_step,
        });
        
        buttons.push({
            "text":gettext("Cancel"),
            "action":function(){
                dialog.close();
            }
        });
        
        var pos_sources = ['tms_pos', 'file_upload'];
        for (var device in $device_store.devices){
            if($device_store.devices[device]['category'] == "pos"){
                pos_sources.push($device_store.devices[device]['type']);
            }
        }

        dialog.open({
            'title': gettext('Match Titles'),
            'template': self.match_dialog_new_tmpl,
            'width':600,
            'buttons':buttons,
            'data':{"unmatched":self.unmatched_titles, "pos_sources": pos_sources},
        });
        
        $('.d_tabs .d_tab').click(function(){
            jqitem = $(this);
            if (jqitem.hasClass('disabled')) return;
            var target = jqitem.attr("data-target");
            $('.d_tabs .d_tab.selected').removeClass("selected");
            jqitem.addClass("selected");
            $('.tab_contents').hide();
            $('#'+target).show();
            _update_match_dialog_state();
        });
        
        $('.d_tabs .d_tab:first-child').click();
        
        $('.title_match_unmatched_list').on('click', '.unmatched_title', function(event){
            jqitem = $(this);
            order = parseInt(jqitem.attr('order'));
            jqitem.slideUp(100,function(){
                insert_title_into_ordered_list(".title_match_unmatched_selected_list", ".unmatched_title", jqitem, order);
                _update_match_dialog_state();
                jqitem.slideDown(300);
            });
        });
        
        $('.title_match_unmatched_selected_list').on('click', '.unmatched_title', function(event){
            jqitem = $(this);
            order = parseInt(jqitem.attr('order'));
            jqitem.slideUp(100,function(){
                insert_title_into_ordered_list(".title_match_unmatched_list", ".unmatched_title",jqitem, order);
                _update_match_dialog_state();
                var sstring = $('#unmatched_search.title_match_search_box input').val();
                if(sstring=='' || sstring==undefined || jqitem.find('>:icontains("'+sstring+'")').length!=0){
                    jqitem.slideDown(300);
                }
            });
        });
        
        $('#match_available_tab').on('click', '.jq_available_title', function(event){
            jqitem = $(this);
            $(".jq_available_title").removeClass('available_title_selected');
            jqitem.toggleClass('available_title_selected');
            _update_match_dialog_state();
            if( $(this).attr("title_uuid") == undefined){
                $("#at_button_0").button('option', 'label', gettext('Create'));
            }else{
                $("#at_button_0").button('option', 'label', gettext('Match'));
            }
        });
        // List dom, seach dom, search callback

        draw_titles_list({
            'dom': $("#match_available_tab .title_match_available_list"),
            'search_dom': $('#available_search.title_match_search_box input'),
            'search_cb': _update_match_dialog_state,
        });
        
        $('#unmatched_search.title_match_search_box input').on('keydown',function(event){
            var inputfield = this
            try{
                clearTimeout(self.match_dialog_storage['searchtimer']);
            }catch(e){}
            self.match_dialog_storage['searchtimer'] = setTimeout(function(){filter_titles(inputfield, '.title_match_unmatched_list');}, 300);
        });
        
        _update_match_dialog_state();
    }

    function draw_titles_list(args){
        var dom = args['dom'];
        var search_dom = args['search_dom'];
        var search_cb = args['search_cb'];
        var exclude = args['exclude']
        var search = ""
        function load(callback){
            helpers.ajax_call({
                url:'/core/paginated/get_datatables_titles',
                data: {
                    'iDisplayLength': 100,
                    'iSortingCols': 1,
                    'iSortCol_0': 1,
                    'sSortDir_0': 'asc',
                    'sSearch': search,
                    'exclude': exclude
                },
                loader: {
                    'target': dom,
                    'caption': gettext("Loading Titles")
                },
                success_function: function(input){
                    dom.empty();
                    if(input['aaData'].length > 0){
                        $("#title_match_available_titles_tmpl").tmpl({'titles': input['aaData'], 'showing': input['aaData'].length, 'total': input['iTotalRecords']}).appendTo(dom);
                    }
                    else{
                        $(self.no_available_title_tmpl).tmpl().appendTo(dom);
                    }
                    if(callback) callback();
                }
            });
        }
        load();
        if(search_dom){
            search_dom.searcher(function(input){
                search = input;
                load(search_cb);
            });   
        }
    }
    
    function insert_title_into_ordered_list(list_selector, item_selector, item, order){
        var order_array = $(list_selector+' '+item_selector).map(function() {
            var temp_order = parseInt($(this).attr('order'));
            return (temp_order > order)?temp_order:null;
        });
        if((order_array.length) && (order_array.length != 0)){
            $(list_selector+' '+item_selector+'[order='+order_array[0]+']').before(item);
        }else{
            $(list_selector).append(item);
        }
    }
    
    function _disable_tab(tab,value){
        if (value){
            $(tab).addClass('disabled');
        }else{
            $(tab).removeClass('disabled');
        }
    }
    
    function _update_match_dialog_state(){
        var d_tab_selection = $('.d_tabs .d_tab.selected').attr('data-target');
        var match_button = $('.at_buttons>:contains("Match")');
        var next_button = $('.at_buttons>:contains("Next")');
        var unmatched_selected = ($('.title_match_unmatched_selected_list').children().length!=0);
        var available_selected = ($('#match_available_tab .available_title_selected').length!=0);
        if (d_tab_selection == 'match_external_tab'){
            match_button.button('disable');
            if(unmatched_selected){
                next_button.button('enable');
                _disable_tab('.d_tabs .d_tab[data-target=match_available_tab]',false);
            }else{
                next_button.button('disable');
                _disable_tab('.d_tabs .d_tab[data-target=match_available_tab]',true);
            }
        }else if (d_tab_selection == 'match_available_tab'){
            next_button.button('disable');
            if(unmatched_selected && available_selected){
                match_button.button('enable');
            }else{
                match_button.button('disable');
            }
        }
        $('.title_match_external_final_list').empty().append($('.title_match_unmatched_selected_list').children().clone());
    }
    
    function _match_titles_next_step(){
        var d_tab_selection = $('.d_tabs .d_tab.selected').attr('data-target');
        if (d_tab_selection == 'match_external_tab'){
            $('.d_tabs .d_tab[data-target=match_available_tab]').click();
        }
    }
    
    function _do_match_titles(){
        var external_titles = [];
        $('.title_match_unmatched_selected_list').children().each(function(){
            var external = {"external_id": $(this).attr('external_id'),
                    "source": $(this).attr('source'),
                };
            if( $(this).attr('rating') != ''){
                external['rating'] = $(this).attr('rating');
                external['territory'] = $(this).attr('territory');                
            }
            external_titles.push(external);
        });
        var available_uuid = $('.title_match_available_list .available_title_selected').attr('title_uuid');
        
        helpers.ajax_call({
            url:'/core/title/match_external_titles',
            data:{
                "external_titles" : external_titles,
                "title_uuid" : available_uuid,
            },
            success_function: function(data){
                dialog.close();
                self.titles_table.fnDraw();
                load_unmatched_titles();
            }
        });
    }
    
    function _merge_titles(){
        var destination = $("#title_merge_available_titles .jq_available_title_selected").attr("title_uuid");
        var source = self.selected_title.uuid;
        helpers.ajax_call({
            url:'/core/title/merge',
            data:{
                "source_title_uuid" : source,
                "destination_title_uuid" : destination,
            },
            success_function: function(input){
                self.titles_table.fnDraw();
                dialog.close();
                $('#titles_info_pane .title_info').empty();
                $(self.info_placeholder_tmpl).tmpl().appendTo("#titles_info_pane .title_info");
            }
        });
    }

    function delete_click(){
        var title_uuids = [];
        var names = [];
        $('.title_selector:checked').each(function(i, dom){
            var uuid = $(dom).attr("id");
            title_uuids.push(uuid);
            names.push(self.titles[uuid]['name']);
        });
        if(title_uuids.length > 0 ){            
            var buttons = [];
            buttons.push({
                'text': gettext('Confirm'),
                'action': function(){
                    delete_titles(title_uuids);
                    dialog.close();
                }
            });
            dialog.open({
                'title': gettext('Delete'),
                'buttons': buttons,
                'template': '#title_delete_tmpl',
                'data': {
                    'names': names
                }
            });
        }
    }

    function delete_titles(title_uuids){
        helpers.ajax_call({
            url: "/core/title/delete",
            data:{
                title_uuids: title_uuids
            },
            success_function: function(input){
                self.titles_table.fnDraw();
                load_unmatched_titles();
            }
        });
    }

    function select_all_click(){
        $('.title_selector').attr("checked", $(this).is(":checked"));
    }

    function show_mappings_dialog(){
        var buttons = [];
        buttons.push({
            "text":gettext("Close"),
            "action":function(){
                dialog.close();
            }
        });
        dialog.open({
            'title': gettext('Third Party Mappings'),
            'template': "#title_mappings_dialog_tmpl",
            'height':320,
            'buttons':buttons,
            'stretchcontent': true,
            'wrapper_class': 'mappings_dialog_wrapper'
        });
        helpers.ajax_call({
            url:'/core/title/external_titles',
            loader: {
                'target': "#title_mappings_dialog"
            },
            success_function: function(input){
                _toggle_ext_mappings_callback(input);
            }
        });
        self.show_ext_mappings  = !self.show_ext_mappings;
    }

    function _toggle_ext_mappings_callback(input){
        data = {}
        var empty = $.isEmptyObject(input.data);
        for(var source in input.data){
            if( source != "AAM" ){
                if( data[source] == undefined){
                    data[source] = [];
                }
                for(var ext_id in input.data[source]){
                    data[source].push({
                        ext: ext_id,
                        title: input.data[source][ext_id]["title_name"],
                        uuid: input.data[source][ext_id]["title_uuid"],
                    });
                }
                data[source].sort(function(a,b){return a.ext > b.ext});
            }
        }
        $("#title_mappings_dialog").empty().html($(external_title_mapping_tmpl).tmpl({map:data,empty:empty}));

        $('.d_tab').click(function(){
            $('.d_tab.selected').removeClass("selected");
            $(this).addClass("selected");
            var target = $(this).attr("data-target");
            $('.tab_content').html($(target).html());
            $('.tab_content').on('click', '.jq_delete_ext_map', delete_external_mapping);
        });
        $('.d_tab:first-child').click();
    }
    
    function delete_external_mapping(){
        var trash_can = $(this);
        helpers.ajax_call({
            url:'/core/title/unmatch_external_title',
            data:{
                source:$(trash_can).attr("source"),
                external_id:$(trash_can).attr("external_id"),
                title_uuid:$(trash_can).attr("title_uuid"),
            },
            success_function: function(input){
                $(trash_can).parent().remove();
                load_unmatched_titles();
            }
        });
    }
}
