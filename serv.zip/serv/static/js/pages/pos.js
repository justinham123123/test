var pos_page = new POSPage();
function POSPage() {
    var self = this;

    //Templates
    self.main_tmpl = '#pos_main_tmpl';
    self.group_tmpl = '#pos_items_tmpl';
    self.title_tmpl = '#pos_title_tmpl';
    self.title_week_tmpl = '#pos_title_week_tmpl';
    self.pos_items_title_tmpl = '#pos_items_title_tmpl';
    self.week_selector_tmpl = '#pos_week_selector_tmpl';
    self.upload_dialog_tmpl = '#pos_upload_dialog_tmpl';
    self.table_row_tmpl = '#pos_table_row_tmpl';
    self.playlist_tmpl = '#pos_playlist_list_tmpl';
    self.group_header_tmpl = '#pos_group_header_tmpl';
    self.sync_report_tmpl = '#pos_sync_report_tmpl';
    self.resync_tmpl = '#pos_resync_tmpl';
    self.empty_week_tmpl = '#pos_empty_week_tmpl';
    self.no_lms_tmpl = '#pos_no_lms_tmpl';
    self.pos_assign_attribute_tmpl = '#pos_assign_attribute_tmpl'
    self.checklist_tmpl = '#pos_checklist_tmpl'

    // POS
    self.pos_items_by_uuid = {};
    self.pos_items_by_title = {};
    self.sorted_pos_titles = {};
    self.original_pos_items_by_uuid = {};
    self.pos_update_map = {};
    self.pos_deletion_map = {};

    // Playlist
    self.playlist_list = [];
    self.template_list = [];
    self.placeholder_list = [];
    self.playlist_dictionary = {};
    self.current_playlist_id = null;
    self.current_placeholder_type = null;

    // Other Stuff
    self.weeks = [];
    self.timestamps = {};
    self.current_week = null;
    self.current_title = null;
    self.fade_colours = {'scheduled' : '#85DD35' , 'notscheduled' : '#E73030' , 'pending' : '#EF9016', 'deleted' : '#666666' , 'assigned' : '#EF9016', 'unassigned' : '#999' };
    self.last_selected_pos_uuid = null;
    self.shift = false;
    self.selecting_multiple = false;
    self.show_report = false;
    self.saving = false;
    self.schedule_move_hash = {};
    self.show_attributes = {};
    self.external_device_map = {};
    self.external_titles = {};
    self.hide_unconfigured = false;
    self.hide_expired = false;
    self.init_stamp = 0;

    // Sync
    self.sync_playlists = false;
    self.sync_schedule_states = false;
    self.syncing_schedule_states = false;
    self.sync_device_states = false;
    self.syncing_device_states = false;
    self.pos_schedule_check_uuids = {};
    self.playlist_sync_frequency = 30000; // how often we re-grab the playlists
    self.waiting_for_sync = false;    
    
    //Methods
    self.open = function(preselected_week_number, open_sync_history) {

        // DOM stuff
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.bind('page_load', _close_page);
        nav_select('schedule', 'pos');
        $(self.main_tmpl).tmpl({enable_templates: CONFIG.pos.pos_enable_templates}).appendTo( $('#main_section').empty() );
        $(document).trigger('page_loaded');
        self.sync_schedule_states = true;
        self.sync_device_states = true;
        self.sync_playlists = true;
        self.pos_update_map = {};
        self.pos_deletion_map = {};
        self.schedule_move_hash = {};
        self.has_template = false;
        self.sync_report_data = {}
        self.external_device_map = {};
        self.show_report = false;
        self.external_titles = {};

        // buttons
        var buttons = [];
        if(helpers.is_allowed('tms_pos_action')){
            buttons = [
                {text:gettext('Save'), image:'save', onClick: self.prepare_save, _class:'jq_save_all_changes'},
                {text:gettext('Revert All'), image:'delete', onClick: self.revert_changes, _class:'jq_revert_all_changes'},
                {text:gettext('Upload File'), image:'upload_file', onClick: self.open_pos_upload_dialog},
                {text:gettext('Update POS Feed'), image:'sync', onClick: self.resync_feed, _class:'jq_resync_pos_feed'},
                {text:gettext('Resync Sessions'), image:'sync', onClick: self.open_resync_dialog, _class:'jq_resync_pos_sessions'}
            ];
        }
        helpers.set_buttons('#pos_action_buttons', buttons);
        
        var inner_buttons = [
            {text:gettext('Delete'), id: 'poslol1', image:'delete', _class:'pos_group_control_panel_delete jq_pos_group_control_panel_delete'},
            {text:gettext('Unassign'), id: 'poslol2', image:'undo', _class:'pos_group_control_panel_unassign jq_pos_group_control_panel_unassign'}
        ];
        if(screenwriter_plus && $complex_status.allow_auto) {
            inner_buttons.push({text:gettext('Automatic Assignment'), id: 'poslol3', image:'sync', _class:'pos_group_control_panel_auto jq_pos_group_control_panel_auto'});
        }
        inner_buttons.push({text:gettext('Assign Attribute'), id: 'poslol4', image:'list', _class:'pos_group_control_panel_attr jq_pos_group_control_panel_assign_attribute'});
        helpers.set_buttons('.pos_group_control_panel_selectors', inner_buttons);

        var load_message;
        if( preselected_week_number != undefined){
            self.current_week = preselected_week_number.toString();
        }
        if($device_store.devices[$device_store.get_lms_uuid()].enabled == true){
            _sync_with_core();
            _sync_playlists();
            if(screenwriter_plus){
                $.when(sync_device_states(), _get_weeks(),_get_pos_device_map(), _check_for_template()).done(self.get_pos_titles_for_week);}
            else{
                $.when(sync_device_states(), _get_weeks(), _get_pos_device_map()).done(self.get_pos_titles_for_week);
            }
        }
        else{
            $(self.no_lms_tmpl).tmpl().appendTo( $('#pos_main') );
            $('#pos_no_lms_link').on("click",function(){complex_config_page.open();});
        }

        // pos js functions
        _add_pos_event_handlers();

        // global js functions
        update_mapping_status();
        update_overall_mapping_status();

        // open up the sync history if user was re-directed
        if( open_sync_history == true ){
             setTimeout(self._show_last_sync, 1000);
        }

        if(!self.syncing_schedule_states){
            _sync_pos_schedule_states({});
        }
    };

    function _close_page() {
        if(window.location.hash != "#pos_page"){
           self.sync_schedule_states = false;
           self.sync_device_states = false;
           self.sync_playlists = false;
           self.current_title = null;
           self.current_week = null;
           self.pos_schedule_check_uuids = {};
           self.external_device_map = {};
           self.resync = null;
           self.schedule_move_hash = null;
           self.show_report = false;
           self.external_titles = {};
        }

        $(document).unbind('page_load', _close_page);
        $('#main_section').off('click.pos');
        $(window).off('resize.pos');
        $('#boxAT8_wrapper').off('click.pos');
        //clear out variables
        self.pos_items_by_title = {};
        self.pos_items_by_uuid = {};
    }

    function _add_pos_event_handlers(){

        self.group_sessions = $.cookie('read', 'pos_group_sessions') == "true";
        $('#jq_pos_group_filter').toggleClass("selected", self.group_sessions).click(function(){
            $(this).toggleClass('selected');
            self.group_sessions = $('#jq_pos_group_filter').hasClass("selected");
            $.cookie('write', 'pos_group_sessions', self.group_sessions, 5000);
            self.get_pos_titles_for_week();
        });

        self.hide_unconfigured = $.cookie('read', 'pos_hide_unconfigured') == "true";
        $('#jq_pos_configured_filter').toggleClass("selected", self.hide_unconfigured).click(function(){
            $(this).toggleClass('selected');
            self.hide_unconfigured = $('#jq_pos_configured_filter').hasClass("selected");
            $.cookie('write', 'pos_hide_unconfigured', self.hide_unconfigured, 5000);
            self.get_pos_titles_for_week();
        });

        self.hide_expired = $.cookie('read', 'pos_hide_expired') == "true";
        $('#jq_pos_expired_filter').toggleClass("selected", self.hide_expired).click(function(){
            $(this).toggleClass('selected');
            self.hide_expired = $('#jq_pos_expired_filter').hasClass("selected");
            $.cookie('write', 'pos_hide_expired', self.hide_expired, 5000);
            self.get_pos_titles_for_week();
        });

        $('#main_section').on(
            'click.pos',
            '.jq_pos_subgroup_select_all',
            self.select_subgroup
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_subgroup_resync_all',
            self.resync_subgroup
        );
        $('#main_section').on(
            'click.pos',
            '.jq_collapse_pos_sessions',
            self.collapse_subgroup
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_subgroup_unselect_all',
            self.unselect_subgroup
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_followed_by',
            self.toggle_followed_by
        );
        $('#main_section').on(
            'click.pos',
            '.jq_playlist_list_item',
            self.update_pos_items
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_group_control_panel_delete',
            self.delete_pos_items
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_group_control_panel_unassign',
            self.unassign_pos_items
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_group_control_panel_auto',
            self.auto_assign_pos_items
        );        
        $('#main_section').on(
            'click.pos',
            '.jq_pos_group_control_panel_assign_attribute',
            self.assign_show_attribute
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_item_checkbox',
            self.select_pos_item
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_week_selector',
            self.get_pos_titles_for_week
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_playlist_tab',
            self.draw_playlists
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_title_wrapper',
            self.get_pos_items_for_title
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_table_row',
            self.select_table_row
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_item_time_moved',
            self.reset_scheduling
        );
        $('#main_section').on(
            'click.pos',
            '.jq_pos_retry_scheduling',
            self.resync_scheduling
        );        
        $("#main_section").on(
            'click.pos', 
            '.delete_show_attr', 
            delete_show_attribute
        );        
        $('#main_section').on(
            'click.pos',
            '.jq_pos_undelete',
            self.undelete_session
        );
        $('#main_section').on(
            'click.pos',
            '#pos_sync_report_title',
            self.toggle_sync_report
        );
        $('#main_section').on(
            'click.pos',
            '.jq_cinema_id',
            self.append_cinema_id
        );
        $('#main_section').on(
            'click.pos',
            '#pos_playlist_list_toggle',
            self._toggle_playlist_list
        );
        $('#main_section').on(
            'click.pos',
            '.jq_schedule_link',
            self._schedule_link
        );
        $('#main_section').on(
            'keyup.pos',
            '#jq_pos_playlist_filter',
            self._filter_playlists
        );
        $('#main_section').on(
            'keyup.pos',
            '#jq_pos_title_filter',
            self._filter_titles
        );
        $(window).on(
            'resize.pos',
            self.resize_pos_table
        );
        $('#main_section').on('click','span.jq_pos_preview',function(event){
            var selected_uuid = $(this).parent().parent('tr').attr('id');
            self.show_playlist_preview(selected_uuid);
            event.stopPropagation();
        });
        $('#main_section').on(
            'click.pos',
            '.jq_delete_title_mapping',
            self.delete_title_mapping
        );
        $('#main_section').on('mouseover','.jq_pos_title_title_title',function(event){
            $(this).children('.delete_title_mapping').css('opacity', '1')
        });
        $('#main_section').on('mouseout','.jq_pos_title_title_title',function(event){
            $(this).children('.delete_title_mapping').css('opacity', '0')
        });
        $('#main_section').on('mouseout','.jq_pos_show_attr',function(){
            $('.delete_show_attr').css('display', 'none')
        });
        $('#main_section').on('click','.jq_pack_push_resync',function(event){
            //the time that packs were pushed is used to identify the sync item in the sync history list
            var push_time = $(this).attr("stamp");
            for(var sync in self.sync_report_data){
                if(push_time.trim() == self.sync_report_data[sync]['time_string'].trim()){
                    var resync_info = self.sync_report_data[sync];
                    self.sync_report_data[sync]['confirmed'] = true;
                    $(this).remove();
                }
            }
            helpers.ajax_call({
                url:'/tms/confirm_pos_schedule_resync',
                data:{resync_info:resync_info, push_time:push_time.trim()},
            });
        });
    }

    function _sync_pos_schedule_states(pos_uuids){
        self.syncing_schedule_states = true;
        helpers.ajax_call({url:'/core/pos/schedule_state', success_function:_sync_pos_schedule_states_callback });
    }

    function _disable_buttons(disable){
        $('#button_2').button('option', 'disabled', disable);
        $('#button_3').button('option', 'disabled', disable);
        $('#button_4').button('option', 'disabled', disable);
        $('.jq_pos_group_control_panel_delete').button('option', 'disabled', disable);
        $('.jq_pos_group_control_panel_unassign').button('option', 'disabled', disable);
        $('.jq_pos_group_control_panel_assign_attribute').button('option', 'disabled', disable);
        $('.jq_pos_group_control_panel_auto').button('option', 'disabled', !self.has_template ? true: disable);
        if(disable){
            $('.jq_pos_subgroup_resync_all').addClass("pos_retry_scheduling_disabled");
            $('.jq_pos_retry_scheduling').addClass("pos_retry_scheduling_disabled");
            $('.jq_pos_item_time_moved').addClass("pos_reset_scheduling_disabled");
            $('.jq_pos_undelete').addClass("pos_undelete_disabled");
        }else{
            if (!self.has_template){
                $('.jq_pos_table_row_header[playlist_id="auto"] .jq_pos_subgroup_resync_all').addClass('pos_retry_scheduling_disabled');
                $('.jq_pos_table_row[playlist_id="auto"] .jq_pos_retry_scheduling').addClass('pos_retry_scheduling_disabled');
            }
            else{
                $('.jq_pos_table_row_header[playlist_id="auto"] .jq_pos_subgroup_resync_all').removeClass("pos_retry_scheduling_disabled");
                $('.jq_pos_table_row[playlist_id="auto"] .jq_pos_retry_scheduling').removeClass("pos_retry_scheduling_disabled");
            }
            $('.jq_pos_table_row_header[playlist_id!="auto"] .jq_pos_subgroup_resync_all').removeClass("pos_retry_scheduling_disabled");
            $('.jq_pos_table_row[playlist_id!="auto"] .jq_pos_retry_scheduling').removeClass("pos_retry_scheduling_disabled");
            $('.jq_pos_item_time_moved').removeClass("pos_reset_scheduling_disabled");
            $('.jq_pos_undelete').removeClass("pos_undelete_disabled");
        }
    }

    function _sync_thread_status(){
        helpers.ajax_call({url:'/core/scheduling/sync_status', data:{"short":true}, success_function:_sync_thread_status_callback });
    }

    function _sync_thread_status_callback(input){
        if(!self.saving){
            input.data.progress = 0;
        }
        self.saving = input.data.syncing || self.waiting_for_sync || input.data.waiting;
        _update_thread_status(input.data.message, self.saving, input.data.progress, input.data.checklist);
        _disable_buttons(input.data.syncing);
    }

    function _sync_pos_items(){
        helpers.ajax_call({
            url:'/core/pos/pos',
            loader: {
                target: "#main_section",
                caption: gettext("Loading Week %s").replace("%s", self.current_week.toString())
            },
            data:{
                week_number: parseInt(self.current_week),
                hide_unconfigured: self.hide_unconfigured,
                hide_expired: self.hide_expired
            },
            success_function: _sync_pos_items_callback
        });
    }

    self._show_last_sync = function(){
        if( self.show_report == true ){
            $("#pos_sync_report .pos_sync_report_item").first().effect("pulsate",{times : 2}, 400);
        }else{
            self.toggle_sync_report(),setTimeout(function(){$("#pos_sync_report .pos_sync_report_item").first().effect("pulsate",{times : 2}, 400)},500);
        }
    }

    function _sync_with_core(){
        helpers.ajax_call({
            url:'/core/get_time',
            success_function:function(input){self.init_stamp = input.data.time;}
        });
    }

    function _sync_playlists(){
        return helpers.ajax_call({
            url:'/core/playlist/playlist',
            loader: {
                target: '#playlist_sublist_wrapper'
            },
            data:{
                device_ids : [ $device_store.get_lms_uuid() ],
                request_data_items : ["title","content_ids","is_template"]
            },
            success_function:_sync_playlists_callback
        });
    }

    function _sync_pos_schedule_states_callback(input){
        if( self.init_stamp < input.data.stamp ){
            // Update the dom for each changed pos session
            for(var session_uuid in input.data.changes){
                _update_scheduling_field(session_uuid, input.data.changes[session_uuid]["scheduled"], input.data.changes[session_uuid]["message"], input.data.changes[session_uuid]["state"]);
            }

            // Update init stamp so we ignore these changes after updating
            self.init_stamp = input.data.stamp;
        }

        // Check schedule syn thread state and update display
        _sync_thread_status();

        // Recursively check schedule state until page closes
        if(self.sync_schedule_states){
            if( !self.saving ){
                setTimeout(_sync_pos_schedule_states, 3500);
                update_mapping_status();
            }else{
                setTimeout(_sync_pos_schedule_states, 2000);
            }
        }else{
            self.syncing_schedule_states = false;
        }
    }

    function _get_weeks(){
        return helpers.ajax_call({
            url:'/core/pos/week_number', 
            loader: {
                target: "#main_section",
                caption: gettext("Loading POS")
            },         
            success_function: _get_weeks_callback
        });
    }
    
    function _get_pos_device_map(){
        return helpers.ajax_call({
            url:'/core/configuration/external_device_maps', 
            data: {source_type:"pos"},
            success_function:function(input){
                for(var pos_device_uuid in input.data.pos){
                    for(var external_id in input.data.pos[pos_device_uuid]){
                        if( input.data.pos[pos_device_uuid][external_id] != undefined){
                            if( self.external_device_map[external_id.toString()] == undefined ){
                                self.external_device_map[external_id.toString()] = {};
                            }
							var pos_device = $device_store.devices[input.data.pos[pos_device_uuid][external_id]];
                            if(pos_device && pos_device.enabled){
                                self.external_device_map[external_id.toString()][pos_device_uuid] = $device_store.devices[input.data.pos[pos_device_uuid][external_id]].screen().identifier;
                            }
                        }
                    }
                }
            }
        });
    }
    
    function _check_for_template(){
        return helpers.ajax_call({ url:'/core/template/template', success_function:function(input){
            if(!$.isEmptyObject(input.data)){
                self.has_template = true;
            }
        }})
    }

    function _get_weeks_callback(input){
        self.weeks = input["data"]["weeks"];
        self.timestamps = input["data"]["timestamps"];
        if( self.current_week == undefined){
            self.current_week = self.weeks[0].toString();
        }
        $(self.week_selector_tmpl).tmpl({"weeks":self.weeks}).appendTo( $('#pos_week_selector').empty() );
    }

    function _toggle_sync_report_callback(input){
        self.sync_report_data = input["data"];
        var count=0;
        for(var sync in self.sync_report_data){
            self.sync_report_data[sync].zebra = count%2 == 0 ? true : false;
            count++;
        }
        helpers.hide_loader();
        
        // Need to do this becaseu jquery templates tend to be retarded
        $(self.sync_report_tmpl).tmpl({"data":self.sync_report_data}).appendTo($("#pos_sync_report_body").empty());
    }

    function _append_cinema_id_callback(input){
        if(input["messages"][0]["type"] == "success"){
            $(".jq_cinema_id[cinema_id='" + input["data"]["cinema_id"]+ "']").removeClass("missing").addClass("added");
            _resync_tooltip();
        }
    }

    function _sync_playlists_callback(input){
        var screen_number, week_number, playlist;

        self.playlist_list = [];
        self.template_list = [];
        self.placeholder_list = [
            {"title": gettext("Event"), "id": "event", "type": "placeholder"},
            {"title": gettext("35mm"), "id": "35mm", "type": "placeholder"},
            {"title": gettext('DVD / Blu-Ray'), "id": "dvdblueray", "type": "placeholder"}
        ];

        // maintain playlist id dictionary for playlist titles and playlist list for templating
        for(var device_id in input.data){
            for(var playlist_id in input.data[device_id]){
                var is_template = input.data[device_id][playlist_id]["is_template"];
                var type = is_template == true ? "template" : "playlist";
                playlist = {
                    "id":playlist_id,
                    "title":input.data[device_id][playlist_id]["title"],
                    "type": type
                }
                self.playlist_dictionary[playlist_id] = {
                    "title" : input.data[device_id][playlist_id]["title"] ,
                    "content_ids" : input.data[device_id][playlist_id]["content_ids"],
                    "template" : is_template
                };
                if(is_template == true){
                    self.template_list.push(playlist);
                }else{
                    self.playlist_list.push(playlist);
                }
            }
        }

        // order the playlists alphabetically
        self.playlist_list.sort(function(a,b){ return (a.title.toUpperCase() > b.title.toUpperCase()) ? 1 : -1; });
        self.template_list.sort(function(a,b){ return (a.title.toUpperCase() > b.title.toUpperCase()) ? 1 : -1; });

        // select first tab
        $(".jq_pos_playlist_tab").first().click();
    }

    function _sync_pos_items_callback(input){

        // reload the sync history if the div is visible
        if( self.show_report ){
            helpers.ajax_call({url:'/core/pos/get_sync_history', success_function:_toggle_sync_report_callback});
        }

        var week_number, min_timestamp, max_timestamp, title;
        self.pos_items_by_title = {};
        self.pos_items_by_uuid = {};
        self.sorted_pos_titles = {};
        for(var week_number_index in self.weeks){
            week_number = self.weeks[week_number_index];
            if( input.data[week_number] !== undefined){
                min_timestamp = null;
                max_timestamp = null;
                for(var source_device in input.data[week_number]){
                    for(var pos_item_id in input.data[week_number][source_device]){
                        var pos_item = input.data[week_number][source_device][pos_item_id];
                        title = pos_item["title"];
                        if(pos_item.title_uuid){
                            self.external_titles[title] = {'title_uuid': pos_item.title_uuid, 'title_name': pos_item.title_name}
                        }
                        self.sorted_pos_titles[week_number] = self.sorted_pos_titles[week_number] == undefined ? {} : self.sorted_pos_titles[week_number];
                        self.sorted_pos_titles[week_number][title] = self.sorted_pos_titles[week_number][title] == undefined ? {} : self.sorted_pos_titles[week_number][title];
                        self.sorted_pos_titles[week_number][title]["screens"] = self.sorted_pos_titles[week_number][title]["screens"] == undefined ? {} : self.sorted_pos_titles[week_number][title]["screens"];
                        self.pos_items_by_title[title] = self.pos_items_by_title[title] == undefined ? {} : self.pos_items_by_title[title];
                        self.pos_items_by_title[title][week_number.toString()] = self.pos_items_by_title[title][week_number.toString()] == undefined ? [] : self.pos_items_by_title[title][week_number.toString()];
                        self.sorted_pos_titles[week_number][title]["screens"][pos_item["screen_identifier"]] = source_device;
                        self.sorted_pos_titles[week_number][title]["week"] = week_number;
                        self.sorted_pos_titles[week_number][title]["title"] = title;
                        
                        // POS item UUIDs grouped by title
                        self.pos_items_by_title[title][week_number.toString()].push(pos_item["uuid"]);
    
                        // rescheduled POS items
                        if(pos_item["state"] == "rescheduled"){
                            self.pos_schedule_check_uuids[pos_item["uuid"]] = true;
                        }
                        // dom object states: scheduled, notscheduled, scheduling, unassigned, deleted, expired
                        if( pos_item["dom_state"] == undefined || pos_item["scheduled_string"]){
                            var schedule_state_object = _pos_schedule_state(pos_item["state"], pos_item["scheduled"])
                            pos_item["dom_state"] = schedule_state_object["state"];
                            pos_item["scheduled_string"] = schedule_state_object["string"];
                        }

                        // tooltip
                        pos_item["tooltip"] = null;
    
                        // unconfigured device?
                        if( self.external_device_map[pos_item["screen_identifier"]] != undefined && self.external_device_map[pos_item["screen_identifier"]][source_device] != undefined ){
                            pos_item["unconfigured"] = false;
                            pos_item["matched_screen_identifier"] = self.external_device_map[pos_item["screen_identifier"]][source_device];
                        }else{
                            pos_item["unconfigured"] = true;
                            pos_item["matched_screen_identifier"] = null;
                        }
    
                        // store a copy of the original POS feed if user needs to revert changes
                        pos_item.date = moment(pos_item.source_start * 1000).format('ddd DD MMM');
                        self.original_pos_items_by_uuid[pos_item["uuid"]] = $.extend(true, {}, pos_item);
                        self.pos_items_by_uuid[pos_item["uuid"]] = $.extend(true, {}, pos_item);
                    }
                }            
            }
        }
        $('#pos_center_panel').removeClass('loading');
        draw_pos_titles_for_week();
        update_mapping_status();
    }

    function _update_scheduling_field(uuid, scheduled, message, state){
        var pos_item = self.pos_items_by_uuid[uuid];
        var pos_state = state || pos_item["state"];
        if( pos_item != undefined ){
            pos_item["message"] = message;
            _update_cached_pos_item(uuid, {'state': pos_state, 'scheduled': scheduled, 'playlist_id': pos_item["playlist_id"], 'placeholder_type': pos_item["placeholder_type"]}, true);
            _update_pos_row(uuid, pos_item);
        }
    }

    function _pos_schedule_state(state, scheduled){
        output = {"state":null, "string":null,"tooltip":null};
        if(state == "assigned" || state == "warning"){
            // TODO - sessions marked as warning are hidden for the moment as it freaks people out
            if(scheduled == null){
                output["state"] = "assigned";
                output["string"] =  gettext("Pending");
                output["tooltip"] =  gettext("Ready to be scheduled");
            }else if(scheduled == false){
                output["state"] = "notscheduled";
                output["string"] =  gettext("No");
            }else{
                output["state"] = "scheduled";
                output["string"] =  gettext("Yes");
            }
        }else if(state == "error"){
            output["state"] = "notscheduled";
            output["string"] =  gettext("No");
        }else if(state == "deleted"){
            output["tooltip"] = gettext("Session is marked for deletion");
            output["state"] = state;
        }else if(state == "unassigned"){
            output["tooltip"] = gettext("Ready to be scheduled");
            output["state"] = state;
        }else{
            output["state"] = state;
        }
        return output;
    }

    self.draw_playlists = function(){
        $(this).addClass("pos_playlist_tab_selected").siblings().removeClass("pos_playlist_tab_selected");
        var data;
        if($(this).attr("target") == "playlists"){
            data = self.playlist_list;
        }else if($(this).attr("target") == "templates"){
            data = self.template_list;
        }else{
            data = self.placeholder_list;
        }
        $(self.playlist_tmpl).tmpl({"data" : data}).appendTo( $('#playlist_sublist_wrapper').empty() );
        self._filter_playlists();
    }

    self.get_pos_titles_for_week = function(){        
        if( self.current_week != $(this).attr("week_number") || $(this).attr("week_number") == undefined){
            if( $(this).attr("week_number") != undefined){
                self.current_week = $(this).attr("week_number");
            }
            $("#pos_tab_week_" + self.current_week).addClass("pos_week_selector_selected").siblings().removeClass("pos_week_selector_selected");
            $('#pos_center_panel').addClass('loading');
            _sync_pos_items();
        }
    }

    function sync_device_states(){
        var def = $.Deferred();

        var count = 0;
        var done = [];
        var devices = [];
        for(var device_uuid in $complex_status.pos.syncing){
            count++;
            var device = $.extend({}, $device_store.devices[device_uuid]);
            device['syncing'] = $complex_status.pos.syncing[device_uuid];
            devices.push(device);
            if(device['syncing'] == false){
                done.push(device_uuid);
            }
        }

        if(done.length == count){
            def.resolve();
        }
        else{
            $('#pos_device_sync_tmpl').tmpl({'devices': devices}).appendTo('#pos_main');
            var c = 0;
            var inte = setInterval(function(){
                c++;
                for(var index in devices){
                    var device = devices[index];
                    if(done.indexOf(device['id']) != -1) continue;
                    if(device['spinner'] == undefined){
                        device['spinner_dom'] = $('#pos_device_sync .pos_device[data-uuid="'+device['id']+'"] .pos_device_loader');
                        device['spinner'] = new Spinner({
                            'dom': device['spinner_dom']
                        });
                        device['spinner'].spin();
                    }
                    if(!$complex_status.pos.syncing[device['id']]){
                        done.push(device['id']);
                        device['spinner'].stop();
                        device['spinner_dom'].html("<span class='image icon-checkmark'></span>");
                    }
                }
                if(done.length == count){
                    clearInterval(inte);
                    def.resolve();
                    $('#pos_device_sync').fadeOut(function(){$(this).remove()})
                }
            }, 200);
        }
        return def.promise();
    }

    function draw_titles(){        
        var sorted_template_data = [];
        var screen_list = [];
        var screen_ids = [];
        var screen_identifier;
        var source_device_uuid;
        var matched_screen;
        var matched;
        var group_matched;
        var source;
        var device;
        for(var title in self.sorted_pos_titles[self.current_week]){
            group_matched = false;
            source_device_uuid = self.sorted_pos_titles[self.current_week][title].screens[Object.keys(self.sorted_pos_titles[self.current_week][title].screens)[0]]
            device = $device_store.devices[source_device_uuid];
            if (device == undefined && source_device_uuid != "file_upload"){
                source = gettext("Unknown");
            }else{
                source = source_device_uuid == "file_upload" ? gettext("From File") : $.capitalise(device.type) + " - " + device.ip ;                
            }
            screen_list = [];
            screen_ids = [];
            for( screen_identifier in self.sorted_pos_titles[self.current_week][title].screens ){
                matched_screen = null;
                screen_ids.push(screen_identifier);
                if(self.external_device_map[screen_identifier] && self.external_device_map[screen_identifier][source_device_uuid]){
                    matched_screen = self.external_device_map[screen_identifier][source_device_uuid];
                }
                matched = (matched_screen !== null);
                var screen_sort_id = matched ? matched_screen : 'zzz'+ screen_identifier;
                if( matched ){
                    group_matched = true;
                }
                if ( !self.group_sessions ){
                    sorted_template_data.push({
                        "title" : title,
                        "week" : self.sorted_pos_titles[self.current_week][title].week,
                        "source" : source,
                        "screens": [{
                            "screen_identifier" : screen_identifier,
                            "matched" : matched,
                            "matched_screen" : matched_screen
                        }],
                        "screen_ids": [screen_identifier],
                        group_matched: matched,
                        screen_sort_id: screen_sort_id
                    });
                }else{
                    screen_list.push({
                        "screen_identifier" : screen_identifier,
                        sort_id: matched ? matched_screen : 'zzz'+ screen_identifier,
                        "matched" : matched,
                        "matched_screen" : matched_screen
                    });
                }
            }
            if ( self.group_sessions ){
                screen_list.sort_screens('sort_id');
                screen_ids.sort();
                sorted_template_data.push({
                    "title" : title,
                    "week" : self.sorted_pos_titles[self.current_week][title].week,
                    "source" : source,
                    "screens": screen_list,
                    "screen_ids": screen_ids,
                    "group_matched": group_matched
                });
            }
        }

        // Display all matched titles first, inorder of screen match id then title
        // if we are grouped, order by title alphabetically
        sorted_template_data.sort(function(a,b){
            if(a.group_matched === b.group_matched){
                if(self.group_sessions){
                    return a.title.localeCompare(b.title);
                } else {
                    return (a.screen_sort_id === b.screen_sort_id) ?
                        a.title.localeCompare(b.title) : helpers.screen_compare(a, b, 'screen_sort_id');
                }
            } else if(!a.group_matched){
                return 1; // Move unmatched to the bottom
            } else {
                return -1;
            }
        });
        $(self.title_tmpl).tmpl({"this_week" : sorted_template_data}).appendTo( $('#pos_item_title_wrapper').empty() );
        $("#pos_item_title_wrapper").children(".pos_title_wrapper").first().click();
    }

    function draw_pos_titles_for_week(){

        // reset
        revert_pending_updates();

        var empty_week = $.isEmptyObject(self.sorted_pos_titles[self.current_week]) ? true : false;

        if(!empty_week){
            $("#pos_main_wrapper").show();
            $("#pos_empty_week").remove();
            $(self.title_week_tmpl).tmpl().appendTo( $('#pos_item_title_wrapper_wrapper') );
            draw_titles();
        }
        else{
            helpers.ajax_call({
                url:'/core/pos/get_sync_history',
                success_function:function(input){
                    $("#pos_empty_week").remove();

                    var complex_ids = [];
                    for(var sync_num in input["data"]){
                        if(input["data"][sync_num]["missing_complex_identifiers"] != undefined && input["data"][sync_num]["missing_complex_identifiers"].length > 0){
                            var ids = input["data"][sync_num]["missing_complex_identifiers"];
                            for(var index in ids){
                                if( complex_ids.indexOf(ids[index]) == -1){
                                    complex_ids.push(ids[index]);
                                }
                            }
                        }
                    }

                    var last_sync = null;
                    if( input["data"] != undefined && input["data"].length > 0 && input["data"][0]["success"] == false){
                        last_sync = input["data"][0]["message"];
                    }

                    var syncing = false;
                    for(var device_uuid in $complex_status.pos.syncing){
                        if( $complex_status.pos.syncing[device_uuid] === true){
                            syncing = true;
                            break;
                        }
                    }

                    $(self.empty_week_tmpl).tmpl({
                        "week_number":self.current_week,
                        "complex_ids":complex_ids,
                        "last_sync": last_sync,
                        "syncing": syncing,
                    }).appendTo( $('#pos_center_panel') );
                    $('#pos_item_title_wrapper').empty();
                }
            });
            revert_pending_updates();
        }
    }

    self.get_pos_items_for_title = function(){
        var screens = $(this).attr("screens").trim().split(";");
        var source = $(this).attr("source");
        var targets = [];
        $(this).find(".jq_pos_title_screen_number").each(function(){
            targets.push({
                "id": $(this).text().trim(),
                "matched": !$(this).hasClass("jq_pos_title_screen_number_unmatched")
            });
        });

        // title/week, reset stuff
        var title = $(this).attr("pos_title");
        var week = $(this).attr("week_number");
        self.last_selected_pos_uuid = null;
        self.shift = false;
        self.current_title = title;
        $(this).addClass("pos_title_wrapper_selected").siblings().removeClass("pos_title_wrapper_selected");

        // do the templating
        $(self.group_tmpl).tmpl({"pos":self.pos_items_by_title[title][week], "screens": screens}).appendTo( $('#pos_item_list_wrapper').empty() );
        for(var pos_uuid_index in self.pos_items_by_title[title][week]){
            var pos_uuid = self.pos_items_by_title[title][week][pos_uuid_index];
            if(self.pos_deletion_map[pos_uuid] != undefined || self.pos_update_map[pos_uuid] != undefined){
                $('#' + pos_uuid).addClass("pos_item_pending");
            }
        }

        var title_map = self.external_titles[title]
        $(self.pos_items_title_tmpl).tmpl({
            "screens": targets,
            "title": title,
            "min": self.timestamps[self.current_week].min,
            "max": self.timestamps[self.current_week].max,
            "source": source,
            'internal_title_uuid': title_map != undefined ? title_map["title_uuid"] : null, 
            'internal_title_name': title_map != undefined ? title_map["title_name"] : null,
        }).appendTo( $('#pos_title_text_wrapper').empty() );

        // fix everything
        _group_table();
        _clean_subgroups();
        self.resize_pos_table();
        _disable_buttons(false)
    }

    self.resync_feed = function(){
        if(confirm(gettext("Are you sure you want to update the POS feed?"))){
            helpers.ajax_call({
                url:'/core/pos/sync'
            });
        }
    }

    self.open_resync_dialog = function(){
        var data;
        var buttons = [];
        buttons.push({
            'text': gettext('Confirm'),
            'action': function() {
                // close dialog
                dialog.close();

                // go through the selected pos uuids and set the sessions for resync
                for(var i = 0; i < self.resync.selected.length; i++){
                    if(self.pos_items_by_uuid[self.resync.selected[i]] != undefined){
                        if(self.pos_items_by_uuid[self.resync.selected[i]].playlist_id != undefined || self.pos_items_by_uuid[self.resync.selected[i]].placeholder_type != undefined){
                            if( self.pos_items_by_uuid[self.resync.selected[i]].expired == false ){
                                _assign_pos_item(self.resync.selected[i], self.pos_items_by_uuid[self.resync.selected[i]].playlist_id, self.pos_items_by_uuid[self.resync.selected[i]].placeholder_type);
                            }
                        }
                    }
                }
                // update the display
                _update_pending_changes();

                // apply
                self.save_changes();
            }
        });

        // total sessions assigned
        var total_affected_schedules = 0;
        for(var week in $complex_status.pos.mapping){
            total_affected_schedules = total_affected_schedules + $complex_status.pos.mapping[week].mapped + $complex_status.pos.mapping[week].mapping_errors;
        }

        if(total_affected_schedules > 0){

            self.resync = {};
            self.resync.servers = {};
            self.resync.titles = {};
            self.resync.days = {};
            self.resync.all = {"all":[]};
            self.resync.selected =[];
            var date_hash = {};
            var session;
            var count = 0;
            for(var pos_uuid in self.pos_items_by_uuid ){
                session = self.pos_items_by_uuid[pos_uuid];
                if((session.dom_state != 'unassigned') && (session.dom_state != 'deleted') && (!session.expired)){
                    count++;
                    if(self.resync.titles[session.title] == undefined){
                        self.resync.titles[session.title] = [];
                    }
                    if(self.resync.servers[session.screen_identifier] == undefined){
                        self.resync.servers[session.screen_identifier] = [];
                    }
                    if(self.resync.days[session.date] == undefined){
                        self.resync.days[session.date] = [];
                    }
                    
                    self.resync.titles[session.title].push(pos_uuid)
                    self.resync.servers[session.screen_identifier].push(pos_uuid);
                    self.resync.days[session.date].push(pos_uuid);
                    self.resync.all["all"].push(pos_uuid);
                    date_hash[session.date] = session.start;
                }
            }

            // Order Titles
            var ordered_titles = [];
            for(var title in self.resync.titles ){
                ordered_titles.push({"title":title,"sessions":self.resync.titles[title]});
            }
            ordered_titles.sort(function(a,b){ if( a.title < b.title){ return -1; }else{ return 1; }});

            // Order Servers
            var ordered_servers = [];
            for(var server in self.resync.servers ){
                ordered_servers.push({"server":server,"sessions":self.resync.servers[server]});
            }
            ordered_servers.sort_screens('server');

            // Order Days
            var ordered_days = [];
            for(var day in self.resync.days ){
                ordered_days.push({"day":day,"sessions":self.resync.days[day]});
            }
            ordered_days.sort(function(a,b){
                return date_hash[a.day] - date_hash[b.day]
            });

            dialog.open({
                'title': gettext('Resync Sessions for Week ') + self.current_week,
                'template': self.resync_tmpl,
                'buttons':buttons,
                'data': {
                        'titles' : ordered_titles,
                        'servers': ordered_servers,
                        'days':    ordered_days,
                        'total': count,
                },
                'width': '600px'
            });

            // Criteria
            $(".pos_resync_criteria").on("click",function(){
                $(this).siblings().removeClass("selected"); $(this).addClass("selected");
                $(".pos_resync_options").hide();
                $($(this).attr("target")).show();
                $("#pos_resync_total span").first().text("0");
                $(".pos_resync_option").removeClass("selected");
                self.resync.selected = [];
            });
            $(".pos_resync_criteria").first().click();

            // Selection
            $(".pos_resync_option").on("click",function(){
                $(this).toggleClass("selected");
                var count = parseInt($(this).attr("count"));
                if( $(this).hasClass("selected")){
                    var updated_count = parseInt($("#pos_resync_total span").first().text()) + count;
                    var val = $(this).attr("value");
                    if( self.resync.days[val] != undefined){
                        self.resync.selected = self.resync.selected.concat(self.resync.days[val]);
                    }else if(self.resync.servers[val] != undefined){
                        self.resync.selected = self.resync.selected.concat(self.resync.servers[val]);
                    }else if(self.resync.titles[val] != undefined){
                        self.resync.selected = self.resync.selected.concat(self.resync.titles[val]);
                    }else if(val == "all"){
                        self.resync.selected = self.resync.selected.concat(self.resync.all[val]);
                    }
                }else{
                    var updated_count = parseInt($("#pos_resync_total span").first().text()) - count;
                    var val = $(this).attr("value");
                    var diff = [];
                    if( self.resync.days[val] != undefined){
                        diff = self.resync.days[val];
                    }else if(self.resync.servers[val] != undefined){
                        diff = self.resync.servers[val];
                    }else if(self.resync.titles[val] != undefined){
                        diff = self.resync.titles[val];
                    }
                    var temp = [];
                    for( var i in self.resync.selected ){
                        if( diff.indexOf(self.resync.selected[i]) == -1 ){
                            temp.push(self.resync.selected[i]);
                        }
                    }
                    self.resync.selected = temp;
                }
                $("#pos_resync_total span").first().text(updated_count);
            });
        }else{
            notification.info_msg(gettext("There are no POS sessions scheduled"), gettext("POS Resync"));
        }
    }

    self.toggle_sync_info = function(){
        $(this).next().toggle();
        if( $(this).hasClass("sync_session_info_open") ){
            $(this).removeClass("sync_session_info_open").addClass("sync_session_info_closed");
        }else{
            $(this).removeClass("sync_session_info_closed").addClass("sync_session_info_open");
        }
    }

    self.toggle_sync_report = function(){

        function __animate(call){
            $("#pos_sync_report_title").toggleClass("show");
            $("#pos_sync_report").toggleClass("open");
            $("#pos_sync_report_title .carrot").toggleClass('icon-arrow-up').toggleClass('icon-arrow-down');
            if( call != undefined){
                call();
            }
        }
        if( self.show_report ){
            __animate();
        }
        else{
            __animate(function(){
                    helpers.show_loader(
                        $("#pos_sync_report"),
                        function(){
                            helpers.ajax_call({ url:'/core/pos/get_sync_history', success_function:_toggle_sync_report_callback})
                        },
                        gettext("Loading History")
                    );
                }
            );
        }
        self.show_report = !self.show_report;
    }

    self.append_cinema_id = function(){
        helpers.ajax_call({url:'/core/pos/append_cinema_id', data:{"cinema_id" : $(this).attr("cinema_id")}, success_function:_append_cinema_id_callback});
    }
    
    self.delete_title_mapping = function(){
        var external_title = $(this).attr("external_title");
        var title_uuid = $(this).attr("title_uuid");
        pos_id = $('.jq_pos_table_row').first().attr('id');
        source = self.pos_items_by_uuid[pos_id]['source'];

        if(confirm(gettext("Are you sure you want to delete this Title mapping?"))){
            helpers.ajax_call({
                url:'/core/title/unmatch_external_title', 
                data: {
                    source:source,
                    external_id:external_title,
                    title_uuid:title_uuid,
                },
                success_function : function(){
                    $(".jq_pos_title_title_title").remove();
                    $(".jq_pos_title_match[ext_title='" + external_title + "'][title_uuid='" + title_uuid + "']").removeClass("matched").addClass("unmatched").attr("title",gettext('This POS feature has not been matched to a Title'));
                    delete(self.external_titles[external_title]);
                }
            });
        }
    }
    
    self.resize_pos_table = function(){
        $('#pos_item_table_wrapper').height($("#pos_main_wrapper").height() - 95);
    }

    self.remove_spaces = function(group_title){
        // get rid of spaces and colons, jquery hates those
        return group_title.split(' ').join('').split(':').join('');
    }

    self.select_subgroup = function(){
        if( !self.saving ){
            $(this).removeClass("jq_pos_subgroup_select_all").addClass("jq_pos_subgroup_unselect_all").addClass("selected");

            self.selecting_multiple = true;
            var subgroup_header = $(this).closest("tr.jq_pos_table_row_header");
            var next = $(subgroup_header).next();

            if($(next).hasClass("jq_pos_table_row_selected") == false){
                $(next).click();
            }

            while($(next).length != 0){
                next = $(next).next();
                if($(next).length > 0 && $(next).hasClass("jq_pos_table_row_header")){
                    break;
                }else{
                    if($(next).hasClass("jq_pos_table_row_selected") == false){
                        $(next).click();
                    }
                }
            }
            self.selecting_multiple = false;
        }
    }

    self.collapse_subgroup = function(){
        $(this).toggleClass("collapsed");
        nextrow = $(this).parent().parent().next();
        while(nextrow.length > 0 && !$(nextrow).hasClass("jq_pos_table_row_header") ){
            $(nextrow).toggle();
            nextrow = $(nextrow).next();
        }
    }

    self.resync_subgroup = function(){
        if( !$(this).hasClass("pos_retry_scheduling_disabled")){
            var subgroup_header = $(this).closest("tr.jq_pos_table_row_header");
            var next = $(subgroup_header);
            var rows = [];
            while($(next).length != 0){
                next = $(next).next();
                if($(next).length > 0 && $(next).hasClass("jq_pos_table_row_header")){
                    break;
                }else{
                    rows.push(next);
                }
            }
            for(var index in rows){
                $(rows[index]).find(".jq_pos_retry_scheduling").click();
            }
        }
    }

    self.unselect_subgroup = function(){
        $(this).removeClass("jq_pos_subgroup_unselect_all").addClass("jq_pos_subgroup_select_all").removeClass("selected");
        self.selecting_multiple = true;
        var subgroup_header = $(this).closest("tr.jq_pos_table_row_header");
        var next = $(subgroup_header).next();
        if($(next).hasClass("jq_pos_table_row_selected") == true){
            $(next).click();
        }
        while($(next).length != 0){
            next = $(next).next();
            if($(next).length > 0 && $(next).hasClass("jq_pos_table_row_header")){
                break;
            }else{
                if($(next).hasClass("jq_pos_table_row_selected") == true){
                    $(next).click();
                }
            }
        }
        self.selecting_multiple = false;
    }

    self.select_table_row = function(event){
        if( !self.saving ){
            if( event.shiftKey && self.last_selected_pos_uuid != undefined && self.shift == false){
                self.shift_select($(this).attr("id"));
            }else{
                if( $(this).hasClass("jq_expired_pos_item") == false && $(this).hasClass("jq_unconfigured_pos_item") == false){
                    var uuid = $(this).attr("id");
                    var checkbox = $('#' + uuid).find("input[type=checkbox]");
                    self.last_selected_pos_uuid = uuid;
                    if($(checkbox).attr("checked") == "checked"){
                        $(checkbox).attr("checked",false);
                        $("#" + uuid).removeClass("pos_table_row_selected jq_pos_table_row_selected");
                    }else{
                        $(checkbox).attr("checked",true);
                        $("#" + uuid).stop().removeAttr("style");// this isn't great, need to remove the animation color. urgh
                        $("#" + uuid).addClass("pos_table_row_selected jq_pos_table_row_selected");
                    }
                }
            }
        }
    }

    self.resync_scheduling = function(event){
        event.stopPropagation();
        if( !$(this).hasClass("pos_retry_scheduling_disabled") ){
            var placeholder_type = $(this).attr("placeholder_type") != "" ? $(this).attr("placeholder_type") : undefined;
            var playlist_id = $(this).attr("playlist_id") != "" ? $(this).attr("playlist_id") : undefined;
            _assign_pos_item($(this).attr("pos_uuid"), playlist_id, placeholder_type)
            _update_pending_changes();
        }
    }

    self.reset_scheduling = function(event){
        event.stopPropagation();
        if( !$(this).hasClass("pos_reset_scheduling_disabled") ){
            var session = self.pos_items_by_uuid[$(this).parent().siblings(".pos_checkbox_column").children("input.pos_item_checkbox").attr("pos_uuid")];
            session.start = session.source_start;
            session.time = moment(session.source_start * 1000).format('HH:mm');
            session.date = moment(session.source_start * 1000).format('ddd DD MMM');
            self.schedule_move_hash[session.uuid] = {
                "start" : session.start,
                "time" : moment(session.start * 1000).format('HH:mm'),
                "date" : moment(session.start * 1000).format('ddd DD MMM')
            }
            $(this).parent().siblings().find("span.jq_pos_retry_scheduling").click();
        }
    }

    self.undelete_session = function(event){
        event.stopPropagation();
        if( !$(this).hasClass("pos_undelete_disabled") ){
            var uuid = $(this).attr("pos_uuid");
            var playlist_id = self.original_pos_items_by_uuid[uuid]["playlist_id"];
            var placeholder_type = self.original_pos_items_by_uuid[uuid]["placeholder_type"];
            _assign_pos_item(uuid, playlist_id, placeholder_type);
            _update_pending_changes();
            _create_pos_subgroup(playlist_id, placeholder_type);
            _clean_subgroups();
        }
    }

    self.select_pos_item = function(event){
        if( !self.saving ){
            event.stopPropagation();
            if( event.shiftKey && self.last_selected_pos_uuid != undefined && self.shift == false){
                self.shift_select($(this).attr("pos_uuid"));
            }else{
                var uuid = $(this).attr("pos_uuid");
                self.last_selected_pos_uuid = uuid;
                if($(this).attr("checked") == "checked"){
                    $("#" + uuid).stop().removeAttr("style");// this isn't great, need to remove the animation color. urgh
                    $("#" + uuid).addClass("pos_table_row_selected jq_pos_table_row_selected");
                }else{
                    $("#" + uuid).removeClass("pos_table_row_selected jq_pos_table_row_selected");
                }
            }
        }else{
            event.preventDefault();
        }
    }

    self.show_playlist_preview = function(uuid){
        var pending_updates = self.pos_update_map[uuid];

        var type = 'normal'; 
        if( self.pos_update_map[uuid]["playlist_id"] == "auto"){
            type = 'title';
        }
        else if ( self.pos_update_map[uuid]["playlist_id"] != undefined && self.playlist_dictionary[self.pos_update_map[uuid]["playlist_id"]]["template"] == true){
            type = 'template';
        }
        
        function process_preview_data(input){
            var playlist = new Playlist(input['data']['playlist']);
            playlist.calculate_start_times();
            
            $('#schedule_details_playlist_details_tmpl').tmpl2({
                playlist: playlist,
            }, '#pos_playlist_preview_playlist_tab');

            //What to do with the messages :/
            //messages: data.messages,

            $('#pos_playlist_preview_templating_tmpl').tmpl2({
                templating_issues: input['data']['templating_issues']
            }, '#pos_playlist_preview_templating_tab');
        }
            
        
        dialog.open({
            'title': gettext('Preview Playlist'),
            'hbtemplate': '#pos_playlist_preview_tmpl',
            'width': 600,
            'data': {
                type: type
            },
        });
        $('.d_tabs .d_tab').click(function(){
            jqitem = $(this);
            if (jqitem.hasClass('disabled')) return;
            var target = jqitem.attr("data-target");
            $('.d_tabs .d_tab.selected').removeClass("selected");
            jqitem.addClass("selected");
            $('.tab_contents').hide();
            $('#'+target).show();
        });
        $('.d_tabs .d_tab:first-child').click();
        
        var target_screen = $device_store.screens[self.pos_items_by_uuid[uuid].screen_uuid];
        var target_device;
        for (var device in target_screen.devices){
            if (target_screen.devices[device]['category'] == "sms"){
                target_device = target_screen.devices[device]['id'];
                break;
            }
        }
        helpers.ajax_call({      
            url:'/tms/generate_schedule_playlist',
            loader: {
                target: $("#pos_playlist_preview_playlist_tab"),
                caption: gettext("Loading Preview")
            },
            data: {
                playlist_type: type, 
                item_uuid: pending_updates['playlist_id'],
                pos_uuid: uuid,
                source_device_uuid: $device_store.get_lms_uuid(),
                target_device_uuid: target_device,
                when: moment(self.pos_items_by_uuid[uuid].start*1000).format("YYYY-M-DD[T]HH:mm:ss"),
                show_attributes: Object.keys(pending_updates['show_attributes'] || {})
            },
            success_function: process_preview_data
        });
    }


    self.shift_select = function(pos_uuid){
        self.shift = true;
        var current = pos_uuid;
        var last_selected = self.last_selected_pos_uuid;
        var select_this = false;
        $("#jq_pos_item_table tr.jq_pos_table_row").each(function(){
            if($(this).attr("id") == last_selected){
                select_this = !select_this;
            }else if($(this).attr("id") == current){
                select_this = !select_this;
                if($(this).hasClass("jq_pos_table_row_selected") == false){
                    $(this).click();
                }
            }else if(select_this == true){
                if($(this).hasClass("jq_pos_table_row_selected") == false){
                    $(this).click();
                }
            }
        });
        self.shift = false;
    }

    function _update_tooltip(){
        var dom;
        if( (!$.isEmptyObject(self.pos_update_map) && !$.isEmptyObject(self.pos_deletion_map) ) || !$.isEmptyObject(self.pos_update_map) ){
            dom = $(".jq_pos_pending_updates_wrapper");
        }else if(!$.isEmptyObject(self.pos_deletion_map)){
            dom = $(".jq_pos_pending_deletions_wrapper");
        }
        dom.qtip({
            content: {
                text: $("#pos_tooltip_tmpl").tmpl()
            },
            position: {
                my: "right center",
                at: "left center",
                viewport: $(window),
            },
            show: {
                event: 'click mouseover',
                ready: true,
            },
            hide: {
                delay: 100,
                event: 'unfocus mouseleave',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light'
            },
        });
    }

    function _resync_tooltip(){
        var dom = $(".jq_resync_pos_feed");
        dom.qtip({
            content: {
                text: $("#pos_resync_tooltip_tmpl").tmpl()
            },
            position: {
                my: "top center",
                at: "bottom center",
                viewport: $(window),
            },
            show: {
                event: 'click mouseover',
                ready: true,
            },
            hide: {
                delay: 100,
                event: 'unfocus mouseleave',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light'
            },
        });
    }

    function _create_pos_subgroup(playlist_id, placeholder_type){
        if(playlist_id == undefined && placeholder_type == undefined){
            _group_unassigned_items();
        }else{
            var pos_items, pos_item, group;
            group = [];
            pos_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row");
            $(pos_items).each(function(){
                pos_item = self.pos_items_by_uuid[$(this).attr("id")];
                if($(this).hasClass("jq_expired_pos_item") == false && $(this).hasClass("jq_deleted_pos_item") == false && $(this).hasClass("jq_unconfigured_pos_item") == false){
                    if( ( $(this).attr("playlist_id") == "" && playlist_id == undefined || $(this).attr("playlist_id") == playlist_id ) && ( $(this).attr("placeholder_type") == "" && placeholder_type == undefined || $(this).attr("placeholder_type") == placeholder_type ) ){
                        group.push(this);
                    }
                }
            });
            if( group.length > 0){
                _group_items(playlist_id, placeholder_type, $(group));
            }
        }
    }

    function validate_group_checkbox(header, rows){
        if( rows != undefined ){
            var selected = false;
            var select_all = $(header).find(".jq_pos_subgroup_select_all");
            var unselect_all = $(header).find(".jq_pos_subgroup_unselect_all");

            if(select_all.length > 0 || unselect_all.length > 0){

                if(rows.hasClass("jq_pos_table_row_selected")){
                    selected = true;
                }

                if(select_all.length){
                    if(selected == true){
                        select_all.switchClass("jq_pos_subgroup_select_all","jq_pos_subgroup_unselect_all").removeClass("selected");
                    }
                    return true;
                }

                if(unselect_all.length){
                    if(selected == false){
                        unselect_all.switchClass("jq_pos_subgroup_unselect_all","jq_pos_subgroup_select_all").addClass("selected");
                    }
                    return true;
                }
            }
        }
    }

    function _clean_subgroups(){

        var pos_items, deleted_header, expired_header, unconfigured_header, remove_this, scr_num;
        var unassigned_headers = [];
        var headers = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header");
        $(headers).each(function(){
            remove_this = false;
            pos_items = null;
            if($(this).attr("deleted") == "true"){
                pos_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_deleted_pos_item");
                if( deleted_header == true){
                    remove_this = true;
                }else{
                    deleted_header = true;
                }
            }else if($(this).attr("expired") == "true"){
                pos_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_expired_pos_item");
                if( expired_header == true){
                    remove_this = true;
                }else{
                    expired_header = true;
                }
            }else if($(this).attr("unconfigured") == "true"){
                pos_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_unconfigured_pos_item");
                if( unconfigured_header == true){
                    remove_this = true;
                }else{
                    unconfigured_header = true;
                }
            }else if($(this).attr("unassigned") == "true"){
                scr_num = $(this).attr("screen");
                pos_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_unassigned_pos_item[screen='" + scr_num + "']");
                if( unassigned_headers.indexOf(scr_num) != -1){
                    remove_this = true;
                }else{
                    unassigned_headers.push(scr_num);
                }
            }else{
                remove_this = true;
                $('#jq_pos_item_table').find("tr.jq_pos_table_row[placeholder_type=" + $(this).attr("placeholder_type") + "][playlist_id=" + $(this).attr("playlist_id") + "]").each(function(){
                    if( !$(this).hasClass("jq_unassigned_pos_item") && !$(this).hasClass("jq_unconfigured_pos_item") && !$(this).hasClass("jq_deleted_pos_item") && !$(this).hasClass("jq_expired_pos_item")){
                        remove_this = false;
                        return false;
                    }
                });
            }
            if( (pos_items != undefined && pos_items.length == 0 ) || remove_this == true){
                $(this).remove();
            }else{
                validate_group_checkbox($('#jq_pos_item_table .pos_table_row_header'), pos_items);
            }
        });
    }

    function _group_items(playlist_id, placeholder_type, pos_items){
        if( playlist_id != undefined || placeholder_type != undefined){
            var playlist_id = playlist_id == undefined ? "" : playlist_id;
            var placeholder_type = placeholder_type == undefined ? "" : placeholder_type;
            var header = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header[placeholder_type=" + placeholder_type + "][playlist_id=" + playlist_id + "]");
            var top_header = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header").first();
            if( header.length == 0){
                header = $(self.group_header_tmpl).tmpl({
                    "description": self.pos_items_by_uuid[$(pos_items).first().attr("id")].title,
                    "playlist_id": playlist_id,
                    "placeholder_type": placeholder_type,
                    "expired": false,
                    "deleted": false,
                    "unconfigured": false,
                    "unassigned":false
                });
                if( top_header.length > 0){
                    $(header).insertBefore($(top_header));
                }else{
                    $('#jq_pos_item_table').append($(header));
                }
            }
            _order_subgroup($(header), $(pos_items));
        }
    }

    function _group_expired_items(){
        var expired_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_expired_pos_item");
        if(expired_items.length > 0){
            var expired_header = $(self.group_header_tmpl).tmpl({"expired":true, "deleted":false, "unconfigured":false, "unassigned":false});
            $('#jq_pos_item_table').append($(expired_header));
        }
        _order_subgroup($(expired_header), $(expired_items));
    }

    function _group_unassigned_items(){
        var unassigned_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_unassigned_pos_item");
        if(unassigned_items.length > 0){
            var unassigned_screen_dict = {};
            var scr_keys, scr, unassigned_header, i, screen_number, unassigned_headers, assigned_headers, header_inserted;
            for( i = 0 ; i < unassigned_items.length ; i++){
                scr = $(unassigned_items.get(i)).attr("screen");
                if( unassigned_screen_dict[scr] == undefined){
                    unassigned_screen_dict[scr] = [unassigned_items.get(i)];
                }else{
                    unassigned_screen_dict[scr].push(unassigned_items.get(i));
                }
            }
            scr_keys = Object.keys(unassigned_screen_dict).sort_screens(null);
            for(var key_index in scr_keys){
                var scr_num = scr_keys[key_index];
                unassigned_header = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header[unassigned=true][screen='" + scr_num + "']");
                if(unassigned_header.length == 0){
                    unassigned_header = $(self.group_header_tmpl).tmpl({"expired":false, "deleted":false, "unconfigured":false, "unassigned":true, "screen_number":scr_num});
                    unassigned_headers = $(".jq_pos_table_row_header[unassigned=true]");
                    if( unassigned_headers.length == 0 ){
                        assigned_headers = $(".jq_pos_table_row_header[unassigned=false][deleted=false][unconfigured=false][expired=false]");
                        if(assigned_headers.length > 0 && $(assigned_headers).last().nextAll(".jq_pos_table_row_header").first().length != 0){
                            $(unassigned_header).insertBefore($(assigned_headers).last().nextAll(".jq_pos_table_row_header").first());
                        }else{
                            $(unassigned_header).insertBefore($('#jq_pos_item_table tbody').children().first());
                        }
                    }else{
                        header_inserted = false;
                        for( i = 0 ; i < unassigned_headers.length ; i++){
                            if( $(unassigned_header).attr("screen") < $(unassigned_headers.get(i)).attr("screen") ){
                                $(unassigned_header).insertBefore($(unassigned_headers.get(i)));
                                header_inserted = true;
                                break;
                            }
                        }
                        if(!header_inserted){
                            if( $(unassigned_headers).last().nextAll(".jq_pos_table_row_header").first().length > 0){
                                $(unassigned_header).insertBefore($(unassigned_headers).last().nextAll(".jq_pos_table_row_header").first());
                            }else{
                                $('#jq_pos_item_table').append($(unassigned_header));
                            }
                        }
                    }
                }
                _order_subgroup($(unassigned_header), $(unassigned_screen_dict[scr_num]));
            }
        }
    }

    function _group_unconfigured_items(){
        var unconfigured_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_unconfigured_pos_item");
        var expired_header = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header[expired=true]");
        if(unconfigured_items.length > 0){
            var unconfigured_header = $(self.group_header_tmpl).tmpl({"expired":false, "deleted":false, "unconfigured":true, "unassigned":false});
            if(expired_header.length != 0){
                $(unconfigured_header).insertBefore($(expired_header));
            }else{
                $('#jq_pos_item_table').append($(unconfigured_header));
            }
        }
        _order_subgroup($(unconfigured_header), $(unconfigured_items));
    }

    function _group_deleted_items(){
        var deleted_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row.jq_deleted_pos_item");
        var deleted_header = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header[deleted=true]");
        var expired_header = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header[expired=true]");
        var unconfigured_header = $('#jq_pos_item_table').find("tr.jq_pos_table_row_header[unconfigured=true]");
        if(deleted_items.length > 0){
            if(deleted_header.length == 0){
                deleted_header = $(self.group_header_tmpl).tmpl({"expired":false, "deleted":true, "unconfigured":false, "unassigned":false});
                if(expired_header.length == 0 && unconfigured_header.length == 0){
                    $('#jq_pos_item_table').append($(deleted_header));
                }else if(unconfigured_header.length != 0){
                    $(deleted_header).insertBefore($(unconfigured_header));
                }else{
                    $(deleted_header).insertBefore($(expired_header));
                }
            }
        }
        _order_subgroup($(deleted_header), $(deleted_items));
    }

    function _order_subgroup(subgroup_header, pos_items){
        if(subgroup_header != undefined){
            $(pos_items).sort(function(a,b){
                return $(a).attr("timestamp") > $(b).attr("timestamp") ? 1 : -1;
            }).insertAfter($(subgroup_header));
        }else{
            $('#jq_pos_item_table').prepend($(pos_items).sort(function(a,b){
                return $(a).attr("timestamp") > $(b).attr("timestamp") ? 1 : -1;
            }));
        }
    }

    function _group_table(){
        var group_dict = {};
        var key = "";
        var pos_items = $('#jq_pos_item_table').find("tr.jq_pos_table_row");
        _group_expired_items();
        _group_deleted_items();
        _group_unconfigured_items();
        _group_unassigned_items();
        $(pos_items).each(function(){
            if($(this).hasClass("jq_pos_table_row_header")){
                return false;
            }else{
                if($(this).hasClass("jq_expired_pos_item") == false && $(this).hasClass("jq_deleted_pos_item") == false && ($(this).attr("playlist_id") != "" || $(this).attr("placeholder_type") != "")){
                    key = $(this).attr("playlist_id") + ":" + $(this).attr("placeholder_type");
                    if( group_dict[key] == undefined){
                        group_dict[key] = {};
                        group_dict[key]["pos"] = [];
                        group_dict[key]["playlist_id"] = $(this).attr("playlist_id") == "" ? undefined : $(this).attr("playlist_id");
                        group_dict[key]["placeholder_type"] = $(this).attr("placeholder_type") == "" ? undefined : $(this).attr("placeholder_type");
                    }
                    group_dict[key]["pos"].push(this);
                }
            }
        });
        for(var index in group_dict){
            _group_items(group_dict[index]["playlist_id"], group_dict[index]["placeholder_type"], $(group_dict[index]["pos"]));
        }
    }

    self._toggle_playlist_list = function(){
        $('#pos_playlist_list').toggle(500);
        $("#pos_center_panel").toggleClass('expanded');
        $("#pos_playlist_list_toggle").toggleClass('showing');
    };

    self._schedule_link = function(event){
        event.stopPropagation();
        var stamp = ((parseInt($(this).attr("stamp"))*1000)-18000000).toString(); // add 5 hours to deal with the 4am to 4am thing
        var uuid = $(this).attr("uuid");
        var url = window.location.protocol + '//' + window.location.host + "/tms/#schedule_page";
        window.open(url + "#" + uuid + "#" + stamp, '_blank').focus();
    }

    function __playlist_filter(dom, string){
        var uuid = $(dom).attr("playlist_id").toLowerCase();
        var title = $(dom).text().toLowerCase();
        if( uuid.indexOf(string) != -1 ){
            return true;
        }else{
            var split = string.split(" ")
            var match = true;
            for(var i in split){
                if(title.indexOf(split[i]) == -1){
                    match = false;
                    break;
                }
            }
            if( match ){
                return true;
            }
        }
        return false;
    }

    function __title_filter(dom, string){
        var title = $(dom).attr("pos_title").toLowerCase();
        var scr_nums = [];
        $(dom).find(".jq_pos_title_screen_number").each(function(){
            scr_nums.push($(this).text());
        });
        if(scr_nums.indexOf(string) != -1){
            return true;
        }
        var split = string.split(" ");
        for(var i in split){
            if(title.indexOf(split[i]) == -1){
                return false;
            }
        }
        return true;
    }

    self._filter_playlists = function(){
        var filter = $("#jq_pos_playlist_filter").val().toLowerCase();
        if(filter.length > 1){
            $(".jq_playlist_list_item").each(function(){
                $(this).toggle(__playlist_filter($(this), filter));
            });
            $(".jq_playlist_sublist").each(function(){
                var category = $(this).attr("cat");
                if( $(".jq_playlist_list_item:visible[cat=" + category + "]").length == 0 ){
                    $(this).hide();
                }else{
                    $(this).show();
                }
            });
        }else{
            $(".jq_playlist_sublist").show();
            $(".jq_playlist_list_item").show();
        }
        $(".jq_playlist_sublist").each(function(){
            var category = $(this).attr("cat");
            if( $(this).is(":visible") && !$(this).hasClass("jq_accordion_open") ){
                $(".jq_playlist_list_item:visible[cat=" + category + "]").hide();
            }
        });
    }

    self._filter_titles = function(){
        var filter = $("#jq_pos_title_filter").val().toLowerCase();
        if(filter.length > 0){
            $(".jq_pos_title_wrapper").each(function(){$(this).toggle(__title_filter($(this),filter))});
        }else{
            $(".jq_pos_title_wrapper").show();
        }
        if( $(".jq_pos_title_wrapper:visible").length > 0){
            $("#pos_control_panel_wrapper").show();
            $("#pos_item_list_wrapper").show();
            $(".jq_pos_title_wrapper:visible").first().click();
        }else{
            $("#pos_title_text .title").text(gettext("No matching Titles were found"));
            $("#pos_title_text .pos_title_text_week").empty();
            $("#pos_control_panel_wrapper").hide();
            $("#pos_item_list_wrapper").hide();
        }
    }

    self.auto_assign_pos_items = function(){
        /* Assigns the specified pos items' playlists as: auto
         */
        var pos_uuid = null;
        var changes = false;
        var placeholder_type, playlist_id, pos_update, scheduled, message, pos_items, pos_items_changed;
        var pos_items = $('#jq_pos_item_table').find("input[type=checkbox]:checked:visible");
        var pos_items_changed = false;
        if( pos_items.length > 0){
            $(pos_items).each(function(){
                if($(this).attr("checked") == "checked"){
                        _assign_pos_item($(this).attr("pos_uuid"), 'auto', null);
                        pos_items_changed = true;
                  }
              });
             _create_pos_subgroup("auto", null);
             _clean_subgroups();             
            _update_pending_changes();
        }else{
            var message = gettext("There are no items selected");
            var title = gettext("Assign POS Playlists");
            notification.info_msg(message, title);
        }
    }
    
    self.assign_show_attribute = function(){
        var selected_pos_sessions = $('#jq_pos_item_table').find("input[type=checkbox]:checked:visible");
        var attribute_list;

        if(selected_pos_sessions.length > 0){
            var buttons = []
            buttons.push({
                'text': gettext('Add'),
                'action': function() {                        
                        var adding = {};

                        $.each(attribute_list.get_selected(), function(uuid, attr){
                            adding[uuid] = attr['name'];
                        });

                        $('.pos_table_row_selected').each(function(){
                            var pos_item_id = $(this).attr("id")
                            var playlist_id = $(this).attr("playlist_id") != "" ? $(this).attr("playlist_id") : undefined;
                            var placeholder_type = $(this).attr("placeholder_type") != "" ? $(this).attr("placeholder_type") : undefined;
                            var pos_item = self.pos_items_by_uuid[pos_item_id];

                            $.extend(pos_item.show_attributes, adding);
                            _assign_pos_item(pos_item_id, playlist_id, placeholder_type, pos_item.show_attributes);
                            _update_pending_changes();
                        })
                        dialog.close();
                    }
            });
            dialog.open({
                'title': gettext('Assign Show Attribute'),
                'template': self.pos_assign_attribute_tmpl,
                'buttons':buttons
            });
            attribute_list = new ShowAttributeSelector({
                dom: $('#pos_assign_attribute_list_wrapper')
            });
        }
        else{
            var message = gettext("There are no items selected");
            var title = gettext("Assign POS Playlists");
            notification.info_msg(message, title);
        }
    }
    
    function delete_show_attribute(event){
        event.stopPropagation();
        var dom = $(this);
        var pos_row = dom.parents('.jq_pos_table_row');
        var pos_id = pos_row.attr('id');
        var playlist_id = pos_row.attr("playlist_id") != "" ? pos_row.attr("playlist_id") : undefined;
        var placeholder_type = pos_row.attr("placeholder_type") != "" ? pos_row.attr("placeholder_type") : undefined;
        var show_attr_name = dom.parent().attr("show_attr");
        var pos_item = self.pos_items_by_uuid[pos_id];
        var attr_uuid = dom.parent().attr("data-uuid");
        
        //are we deleting a matched or unmatched attribute
        var matched_attribute = false;
        if(dom.parent().hasClass('pos_matched_show_attribute')){
            matched_attribute = true;
        }
        
        //take the deleted attr out of the show_attributes/unmatched_show_attributes list
        if(matched_attribute){
            delete pos_item.show_attributes[attr_uuid];
        }
        else{
            // Currently not handeling deleting of unmatched attributes
            return
        }
        
        _assign_pos_item(pos_id, playlist_id, placeholder_type, pos_item.feed_show_attributes);
        _update_pending_changes();
    }


    function _assign_pos_item(pos_uuid, playlist_id, placeholder_type, show_attributes){

        // get updates for pos item
        var pos_update = {};
        var state;
        var pos_item = self.pos_items_by_uuid[pos_uuid];
        pos_update["placeholder_type"] = placeholder_type;
        pos_update["playlist_id"] = playlist_id;
        // Maintain show attributes
        pos_update['show_attributes'] = pos_item['show_attributes']
        if(show_attributes != undefined){
            pos_update["show_attributes"] = show_attributes
        }
        // check update to assign state
        if(pos_update["placeholder_type"] == null && pos_update["playlist_id"] == null){
            pos_update["state"] = "unassigned";
            state = "unassigned"

        }
        else if(pos_update["placeholder_type"] != null || pos_update["playlist_id"] != null){
            pos_update["state"] = "assigned";
            state = "assigned"
        }
        self.pos_update_map[pos_uuid] = pos_update;
        delete self.pos_deletion_map[pos_uuid];
        _update_cached_pos_item(pos_uuid, {'state': state, 'playlist_id': playlist_id, 'placeholder_type': placeholder_type}, false);
        _update_pos_row(pos_uuid, pos_item, false, true);

    }

    self.update_pos_items = function(){
        var placeholder_type, playlist_id, pos_update, scheduled, message, pos_items, pos_items_changed;
        var pos_items = $('#jq_pos_item_table').find("input[type=checkbox]:checked:visible");
        var pos_items_changed = false;
        if( pos_items.length > 0){
            playlist_id = $(this).attr("playlist_id");
            placeholder_type = $(this).attr("placeholder_id");

            if(self.playlist_dictionary[playlist_id] != undefined || (playlist_id == null && placeholder_type != null)){
                $(pos_items).each(function(){
                    if($(this).attr("checked") == "checked"){
                        if( self.pos_items_by_uuid[$(this).attr("pos_uuid")]["playlist_id"] != playlist_id || self.pos_items_by_uuid[$(this).attr("pos_uuid")]["placeholder_type"] != placeholder_type || self.pos_items_by_uuid[$(this).attr("pos_uuid")]["state"] == "deleted"){
                            _assign_pos_item($(this).attr("pos_uuid"), playlist_id, placeholder_type);
                            pos_items_changed = true;
                        }
                    }
                });
                _update_pending_changes();
            }
        }else{
            var message = gettext("There are no items selected");
            var title = gettext("Assign Playlists");
            notification.info_msg(message, title);
        }
        if( pos_items_changed == true){
            _create_pos_subgroup(playlist_id, placeholder_type);
            _clean_subgroups();
        }
    }

    self.delete_pos_items = function(){
        var message, pos_items;
        pos_items = $("#jq_pos_item_table").find("input[type=checkbox]:checked:visible");
        if( pos_items.length > 0){
            $(pos_items).each(function(){
                if($(this).attr("checked") == "checked" && self.pos_items_by_uuid[$(this).attr("pos_uuid")]["dom_state"] != "deleted"){
                    var pos_uuid = $(this).attr("pos_uuid");
                    self.pos_deletion_map[pos_uuid] = true;
                    delete self.pos_update_map[pos_uuid];
                    _update_cached_pos_item(pos_uuid, {'state': "deleted"}, false);
                    _update_pos_row(pos_uuid, self.pos_items_by_uuid[pos_uuid], false, true);
                }
            });
            _update_pending_changes();
        }else{
            message = gettext("There are no items selected");
            title = gettext("Delete POS Sessions");
            notification.info_msg(message, title);
        }
        _group_deleted_items();
        _clean_subgroups();
    }

    self.unassign_pos_items = function(){
        var message, pos_items, pos_items_changed;
        var pos_items = $('#jq_pos_item_table').find("input[type=checkbox]:checked:visible");
        var pos_items_changed = false;
        if( pos_items.length > 0){
            $(pos_items).each(function(){
                if($(this).attr("checked") == "checked"){
                    if( self.pos_items_by_uuid[$(this).attr("pos_uuid")]["playlist_id"] != null || self.pos_items_by_uuid[$(this).attr("pos_uuid")]["placeholder_type"] != null || self.pos_items_by_uuid[$(this).attr("pos_uuid")]["state"] == "deleted"){
                        _assign_pos_item($(this).attr("pos_uuid"), null, null);
                        pos_items_changed = true;
                    }
                }
            });
            _update_pending_changes();
        }else{
            var message = gettext("There are no items selected");
            var title = gettext("Unassign Playlists");
            notification.info_msg(message, title);
        }
        if( pos_items_changed == true){
            _create_pos_subgroup(null, null);
            _clean_subgroups();
        }
    }

    self.toggle_followed_by = function(){
        // toggle the followed by icons
        if($(this).hasClass("jq_followed_by_selected")){
            $(this).removeClass("followed_by_selected jq_followed_by_selected");
            self.current_placeholder_type = null;
        }else{
            $(this).addClass("followed_by_selected jq_followed_by_selected");
            $(this).siblings().removeClass("followed_by_selected jq_followed_by_selected");
            self.current_placeholder_type = $(this).attr("followed_by");
        }
    }

    self.open_pos_upload_dialog = function(){
        var buttons = [{
            text: gettext("Add files"),
            action: function(){
                $("#file_upload_button").click();
            }
        }];

        dialog.open({
            title: gettext('Upload POS'),
            hbtemplate: '#upload_file_dialog',
            buttons: buttons,
            wrapper_class: "pos_file_upload_dialog",
            close: function(event, ui){
                if(!self.saving){
                    _sync_pos_items();
                }
                else{
                    var sync_pos_interval = setInterval(function(){
                        if(!self.saving){
                            _sync_pos_items();
                            clearInterval(sync_pos_interval);
                        }
                    }, 1000)
                }                             
            },
            data: {
                api_call: '/tms/upload_pos'
            }
        });

        var loader = new Loader({
            target: '#file_upload_response_wrapper'
        })  

        $('#fileuploader').fileupload({
            dataType: 'json',
            dropZone: $('#file_dropzone'),
            submit: function(e, data){    
                loader.show();
                $('#file_upload_response_wrapper').css("min-height", "40px");
            },
            done: function(e, data){                
                loader.hide();
                $('#pos_sync_result_tmpl').tmpl2(data['result'], "#file_upload_response_wrapper")
            },
            dragover: function(e){
                $('#file_dropzone').addClass('accept');
                if(self.mouseovertimeout){
                    clearTimeout(self.mouseovertimeout);
                }
                self.mouseovertimeout = setTimeout(function(){
                    $('#file_dropzone').removeClass('accept'); 
                    self.mouseovertimeout = null;
                }, 500);
            }
        });
    }

    self.revert_changes = function(dont_redraw){

        restore_moved_schedules();

        // determine if there are pending updates and/or deletions
        var pending_updates = false;
        var pending_deletions = false;
        for(var deletion in self.pos_deletion_map){ pending_deletions = true; break; }
        for(var update in self.pos_update_map){ pending_updates = true; break;}

        // if no pending changes show the user a message
        if(pending_deletions == false && pending_updates == false){
            notification.info_msg(gettext("There are no changes"), gettext("Revert"));
        }

        // revert pending deletions
        for(var pos_uuid in self.pos_deletion_map){
            var original_pos_item = $.extend(true, {}, self.original_pos_items_by_uuid[pos_uuid]);
            _update_cached_pos_item(pos_uuid, original_pos_item, false);
            _update_pos_row(pos_uuid, self.pos_items_by_uuid[pos_uuid]);
        }

        // revert pending updates
        for(var pos_uuid in self.pos_update_map){
            var original_pos_item = $.extend(true, {}, self.original_pos_items_by_uuid[pos_uuid]);
            _update_cached_pos_item(pos_uuid, original_pos_item, false);
            _update_pos_row(pos_uuid, self.pos_items_by_uuid[pos_uuid]);
        }

        revert_pending_updates();

        if( dont_redraw != undefined){
            _group_table();
            _clean_subgroups();
        }
    }

    function restore_moved_schedules(session_uuid){
        if( session_uuid == undefined){
            for(var uuid in self.schedule_move_hash){
                self.pos_items_by_uuid[uuid].start = self.schedule_move_hash[uuid].start;
                self.pos_items_by_uuid[uuid].time = self.schedule_move_hash[uuid].time;
                self.pos_items_by_uuid[uuid].date = self.schedule_move_hash[uuid].date;
            }
            self.schedule_move_hash = {};
        }else{
            self.pos_items_by_uuid[session_uuid].start = self.schedule_move_hash[session_uuid].start;
            self.pos_items_by_uuid[session_uuid].date = self.schedule_move_hash[session_uuid].date;
            self.pos_items_by_uuid[session_uuid].time = self.schedule_move_hash[session_uuid].time;
            delete self.schedule_move_hash[session_uuid];
        }
    }

    function revert_pending_updates(){
        delete self.pos_update_map;
        delete self.pos_deletion_map;
        self.pos_update_map = {};
        self.pos_deletion_map = {};
        _update_pending_changes();
    }

    self.prepare_save = function(){
        var pending_updates = $.isEmptyObject(self.pos_update_map) ? false : true;
        //Only show the dialog if there are assignments in the update map 
        var pending_assignments = false;
        if (pending_updates){
            for (var pos_id in self.pos_update_map){
                if(self.pos_update_map[pos_id].state == 'assigned'){
                    pending_assignments=true;
                }
            }
        }
        if(pending_assignments && !$complex_status.pos['auto_transfer_time']){
            function save_action(){
                var transfer_time = $('#global_transfer_time_select').transferTimePicker('getTransferTime');
                if (!transfer_time){
                    return;
                }
                dialog.close();
                self.save_changes(transfer_time);
            }
            var buttons = [];
            buttons.push({
                'text': gettext('Save'),
                'action': save_action
            });
            dialog.open({
                'title': gettext('Save POS Mappings'),
                'buttons': buttons,
                'template': '#pos_prepare_save_tmpl',
            });
            
            $('#global_transfer_time_select').transferTimePicker();
            
        }else{
            self.save_changes();
        }
    }

    self.save_changes = function(manual_transfer_time){

        // determine if there are pending updates and/or deletions
        var pending_updates = $.isEmptyObject(self.pos_update_map) ? false : true;
        var pending_deletions = $.isEmptyObject(self.pos_deletion_map) ? false : true;
        
        if( !pending_deletions && !pending_updates){
            self.waiting_for_sync = false;
            g_prevent_navigation = false;
            notification.info_msg(gettext("There are no changes"), gettext("Save"));
            return;
        }

        // do deletions
        if(pending_deletions){
            helpers.ajax_call({url:'/core/pos/delete', notify:false, data:{pos_deletion_map:self.pos_deletion_map} });
            for(var pos_item_uuid in self.pos_deletion_map){
                $("#" + pos_item_uuid).removeClass("pos_item_pending");
                _update_cached_pos_item(pos_item_uuid, {'state': "deleted"}, true);
                self.pos_items_by_uuid[pos_item_uuid].tooltip = null;
                self.pos_items_by_uuid[pos_item_uuid].message = gettext("Session was deleted");
                _update_pos_row(pos_item_uuid, self.pos_items_by_uuid[pos_item_uuid]);
            }
        }

        // do updates
        if(pending_updates){
            if(manual_transfer_time != undefined){
                for (var pos_item_uuid in self.pos_update_map){
                    self.pos_update_map[pos_item_uuid].transfer_not_before = manual_transfer_time;
                }
            }
            // pass flag to indicate that a manually re-schedule session is being reset
            for(var session_uuid in self.schedule_move_hash){
                if( self.pos_update_map[session_uuid] != undefined){
                    self.pos_update_map[session_uuid]["reset"] = true;
                }
            }
            self.schedule_move_hash = {};
            helpers.ajax_call({url:'/core/pos/save_mappings', notify:false, data:{pos_update_map:self.pos_update_map}});

            // query db for schedule states
            for(var pos_item_uuid in self.pos_update_map){
                if( self.pos_update_map[pos_item_uuid] != undefined){
                    var data = {
                        'playlist_id': self.pos_update_map[pos_item_uuid]["playlist_id"], 
                        'placeholder_type': self.pos_update_map[pos_item_uuid]["placeholder_type"]
                    }
                    if(self.pos_update_map[pos_item_uuid]["placeholder_type"] != undefined || self.pos_update_map[pos_item_uuid]["playlist_id"] != undefined){
                        self.pos_schedule_check_uuids[pos_item_uuid] = true;
                        data['state'] = 'assigned';
                        _update_cached_pos_item(pos_item_uuid, data, true);
                        _update_pos_row(pos_item_uuid, self.pos_items_by_uuid[pos_item_uuid], true)
                    }
                    else{
                        data['state'] = 'unassigned';
                        _update_cached_pos_item(pos_item_uuid, data, true);
                        self.pos_items_by_uuid[pos_item_uuid].tooltip = null;
                        self.pos_items_by_uuid[pos_item_uuid].message = gettext("Session has not been assigned to a Playlist or Placeholder");
                        _update_pos_row(pos_item_uuid, self.pos_items_by_uuid[pos_item_uuid])
                    }
                }
            }
        }
        revert_pending_updates();
        update_mapping_status();
    }

    self.format_pos_date = function(date){
        var hours, minutes, month, day, date_object;
        date_object = {};
        date = new Date(date);
        date_object["hours"] = date.getHours().toString().length == 2 ? date.getHours().toString() : "0" + date.getHours().toString();
        date_object["minutes"] = date.getMinutes().toString().length == 2 ? date.getMinutes().toString() : "0" + date.getMinutes().toString();
        date_object["day"] = days[date.getDay()] + " " + date.getDate() + " " + months[date.getMonth()];
        return date_object;
    }

    function _update_pending_changes(){
        var updates, deletions;
        updates = Object.keys(pos_page.pos_update_map).length
        deletions = Object.keys(pos_page.pos_deletion_map).length
        if( updates > 0){
            $(".jq_pos_pending_updates_wrapper").addClass("pending_not_zero");
            updates = updates + "*";
            _update_tooltip();
        }else{
            $(".jq_pos_pending_updates_wrapper").removeClass("pending_not_zero").qtip('destroy');
        }
        if( deletions > 0){
            $(".jq_pos_pending_deletions_wrapper").addClass("pending_not_zero");
            deletions = deletions + "*";
            _update_tooltip();
        }else{
            $(".jq_pos_pending_deletions_wrapper").removeClass("pending_not_zero").qtip('destroy');
        }
        $("#pos_pending_updates").html(updates);
        $("#pos_pending_deletions").html(deletions);

        if( deletions == 0 && updates == 0){
            _toggle_action_buttons(true);
            g_prevent_navigation = false;
        }else{
            g_prevent_navigation = true;
            _toggle_action_buttons(false);
        }

    }

    function _toggle_action_buttons(disabled){
        $(".jq_revert_all_changes").button("option","disabled",disabled);
        $(".jq_save_all_changes").button("option","disabled",disabled);
    }

    function _update_cached_pos_item(uuid, data, persisted){
        
        var state = data['state'] || null;
        var scheduled = data['scheduled'] || null;
        var playlist_id = data['playlist_id'] || null;
        var placeholder_type = data['placeholder_type'] || null;
        var show_attributes = data['show_attributes'] || null;

        if(self.pos_items_by_uuid[uuid] != undefined){
            var schedule_state_object = _pos_schedule_state(state, scheduled);
            self.pos_items_by_uuid[uuid]["state"] = state;
            self.pos_items_by_uuid[uuid]["scheduled"] = scheduled;
            self.pos_items_by_uuid[uuid]["playlist_id"] = playlist_id;
            if(show_attributes) self.pos_items_by_uuid[uuid]["show_attributes"] = show_attributes;
            if (self.pos_items_by_uuid[uuid]["playlist_id"] == null){
                self.pos_items_by_uuid[uuid]["description"] = null;
            }
            self.pos_items_by_uuid[uuid]["placeholder_type"] = placeholder_type;
            self.pos_items_by_uuid[uuid]["scheduled_string"] = schedule_state_object["string"];
            self.pos_items_by_uuid[uuid]["dom_state"] = schedule_state_object["state"];
            if( schedule_state_object["tooltip"] != undefined){
                self.pos_items_by_uuid[uuid]["tooltip"] = schedule_state_object["tooltip"];
            }else{
                self.pos_items_by_uuid[uuid]["tooltip"] = null;
            }
            if(placeholder_type != undefined){
                self.pos_items_by_uuid[uuid]["followed_by_title"] = placeholder_types[placeholder_type];
            }else{
                self.pos_items_by_uuid[uuid]["followed_by_title"] = null;
            }
            if( playlist_id != undefined && self.playlist_dictionary[playlist_id] != undefined){
                self.pos_items_by_uuid[uuid]["playlist_title"] = self.playlist_dictionary[playlist_id]["title"];
            }else{
                self.pos_items_by_uuid[uuid]["playlist_title"] = null;
            }
            if( persisted == true){
                // update the original object here, can't be reverted once it's persisted, the user has to explicitly undo what they've done after they've saved
                self.original_pos_items_by_uuid[uuid] = jQuery.extend(true, {}, self.pos_items_by_uuid[uuid]);
            }
        }
    }

    function update_overall_mapping_status(){
        var week_number, dom, total, mapped;
        for(var week in $complex_status.pos.mapping){
            week_number = $complex_status.pos.mapping[week].week_number;
            total = $complex_status.pos.mapping[week].total;
            mapped = $complex_status.pos.mapping[week].mapped;
            dom = $("#pos_mappings_week_" + week_number.toString());
            $(dom).html(mapped + "/" + total);
            if( total == mapped && (total == "0" || total == "-")){
                $(dom).addClass("pos_empty_mapping").removeClass("pos_incomplete_mapping").removeClass("pos_complete_mapping");
            }else if(total == mapped){
                $(dom).addClass("pos_complete_mapping").removeClass("pos_incomplete_mapping").removeClass("pos_empty_mapping");
            }else{
                $(dom).addClass("pos_incomplete_mapping").removeClass("pos_complete_mapping").removeClass("pos_empty_mapping");
            }
        }
        if($("#pos_week_selector").length > 0){
            setTimeout(update_overall_mapping_status, 1000);
        }
    }

    function update_mapping_status(){
        var title_doms, title_dom, title_mapping_dom, title, week_number, session, scheduled, total, uuid, screen;
        title_doms = $(".jq_pos_title_wrapper");
        for( var i = 0 ; i < title_doms.length ; i++){
            scheduled = total = 0;
            title_dom = title_doms[i];
            week_number = $(title_dom).attr("week_number");
            title = $(title_dom).attr("pos_title");
            screens = $(title_dom).attr("screens").trim().split(";");
            if( self.pos_items_by_title[title] != undefined && self.pos_items_by_title[title][week_number] != undefined){
                for(var j = 0 ; j < self.pos_items_by_title[title][week_number].length ; j++){
                    uuid = self.pos_items_by_title[title][week_number][j];
                    session = self.pos_items_by_uuid[uuid];
                    if(screens.indexOf(session['screen_identifier']) == -1){
                        continue;
                    }
                    if( session.state != "deleted" && session.expired != true ){
                        total++;
                        if( session.scheduled == true && session.state != "unassigned"){
                            scheduled++;
                        }
                    }
                    title_mapping_dom = $(title_dom).find(".pos_title_mappings_overview");
                    $(title_mapping_dom).html(scheduled + "/" + total);
                    if(total == scheduled && (total == "0" || total == "-")){
                        $(title_mapping_dom).addClass("pos_empty_mapping").removeClass("pos_incomplete_mapping").removeClass("pos_complete_mapping");
                        $(title_dom).addClass("pos_title_empty_mapping").removeClass("pos_title_incomplete_mapping").removeClass("pos_title_complete_mapping");
                    }else if(total == scheduled){
                        $(title_mapping_dom).addClass("pos_complete_mapping").removeClass("pos_incomplete_mapping").removeClass("pos_empty_mapping");
                        $(title_dom).addClass("pos_title_complete_mapping").removeClass("pos_title_incomplete_mapping").removeClass("pos_title_empty_mapping");
                    }else{
                        $(title_mapping_dom).addClass("pos_incomplete_mapping").removeClass("pos_complete_mapping").removeClass("pos_empty_mapping");
                        $(title_dom).addClass("pos_title_incomplete_mapping").removeClass("pos_title_complete_mapping").removeClass("pos_title_empty_mapping");
                    }
                }
            }
        }
    }

    function _update_thread_status(status, visible, progress, checklist){

        $(".jq_pos_syncing_status .jq_pos_syncing_status_remaining").text(status);
        if( visible ){
            $("#pos_sync_checklist").fadeIn();
            $("#pos_playlist_list_overlay").fadeIn();
            if( checklist != undefined ){
                $("#pos_sync_checklist").html($(self.checklist_tmpl).tmpl({"checklist" : checklist}));
            }
            $(".jq_pos_pending_updates_wrapper").hide();
            $(".jq_pos_pending_deletions_wrapper").hide();                        
            if(100>progress>0){
                self.waiting_for_sync = false;
            }
            $(".jq_pos_syncing_status").show();
            $("#pos_sync_icon").stop().effect("pulsate",{times:20},1000);
        }else{
            if( $(".jq_pos_syncing_status").css("display") == "block" && !self.waiting_for_sync){
                $("#pos_sync_icon").stop().effect("pulsate",{times:20},1000);
                $(".pos_checklist_item").addClass("done").removeClass("pending");
                setTimeout(function(){
                    $(".jq_pos_syncing_status").hide();
                    $(".jq_pos_pending_updates_wrapper").show();
                    $(".jq_pos_pending_deletions_wrapper").show();
                    $("#pos_sync_icon").stop().clearQueue();
                    $("#pos_sync_checklist").fadeOut();
                    $("#pos_sync_checklist").empty();
                    $("#pos_playlist_list_overlay").fadeOut();
                },1500);
            }
        }
    }

    function _update_pos_row(uuid, pos_item, currently_scheduling, pending){
        if( $("#" + uuid).length > 0){
            if( currently_scheduling == true){
                self.pos_items_by_uuid[uuid]["scheduled_string"] = gettext("Scheduling");
                self.pos_items_by_uuid[uuid]["dom_state"] = "currently_scheduling";
                self.pos_items_by_uuid[uuid]["tooltip"] = gettext("Session is being scheduled");
            }            
            // re draw row
            var row_dom = $(self.table_row_tmpl).tmpl(pos_item);
            $("#" + uuid).replaceWith(row_dom[0]);
            // animate table row
            if(pending == true){
                $(row_dom).addClass("pos_item_pending");
                if(pos_item.dom_state == "assigned" && pos_item.playlist_id != undefined){
                    $(row_dom).find(".jq_pos_preview").show();
                    $(row_dom).find(".jq_pos_test").hide();
                }
            }else{
                $(row_dom).css("color",self.fade_colours[pos_item["dom_state"]]);
                $(row_dom).find(".jq_pos_preview").hide();
                $(row_dom).find(".jq_pos_test").show();
            }
        }
    }
}
