var template_page = new TemplatePage();

function TemplatePage() {

    var self = this;
    var select_all_toggled = false;
    var templates = {};
    var selected_templates = [];
    var current_template_uuid = null;
    var table;
    var active_template_uuid = null;
    
    // flag to prevent multiple "load templates" requests being sent
    self.syncing_templates = false;
    self.initialized = false;
        
    //Methods
    self.open = function() {
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.one('page_load', close_page);
        self.syncing_templates = false;
        $('#main_section').html($("#template_main_tmpl").tmpl());
        nav_select('config', 'template');
        initialise_data_table();
        add_table_controls();
        attach_event_listeners();
        self.initialized = true;
    };
    
    function close_page() {
        table = null;
        $(window).off('.template');
        $("#main_section").off();
    }
    
    function attach_event_listeners() {
        $('#template_toggle_select_all').on('click.template', function(){
            select_all_toggled = !select_all_toggled;
            $('#template_toggle_select_all').toggleClass('selected', select_all_toggled);
            $('#template_table input').attr("checked", select_all_toggled);
            update_checked_count();
        });
        
        $('#template_table > tbody').on('click.template', 'input:checkbox', function(){
            update_checked_count();
        });
                
        $('#template_table tbody').on('click.template', 'td.no_prop', function(event) {
            event.stopPropagation();
        });
        
        $('#template_table tbody').on('click.template', 'tr', function(event) {
            $(this).addClass("template_table_row_selected").siblings().removeClass('template_table_row_selected');
            preview_template($(this).find('input').attr('template_uuid'));
        });
        
        $('#template_table tbody').on('click.template', '.jq_activate_template', function(event) {
            event.stopPropagation();
            helpers.ajax_call({
                data:{template_uuid:$(this).attr("template_uuid")}, 
                url:'/core/template/set_active'
            });
            $(".jq_activate_template").removeClass("active_template").addClass("inactive_template").attr("title",gettext("Currently Inactive"));
            $(this).addClass("active_template").attr("title",gettext("Currently Active"));
        });
        
        $("#main_section").on('resize.template', resize);
    }
    
    function preview_template(template_uuid){
        if(template_uuid != undefined){// undefined if you click on the datatable placeholder
            current_template_uuid = template_uuid;
            helpers.ajax_call({
                url:'/core/template/template', 
                data:{
                    'template_ids' : [template_uuid]
                }, 
                success_function:function(input){
                    for (var uuid in input.data){break;} // Get the object, either this or we use a loop in the templating URGHHH
                    $('#template_preview_pane_wrapper').html($("#template_preview_tmpl").tmpl({"tmpl":input.data[uuid]}));

                    var buttons = [];
                    if (helpers.is_allowed('tms_templating_action')){
                        buttons = [{text:gettext('Edit'), image:'edit', onClick: edit_template}];
                    }
                    helpers.set_buttons('.jq_template_preview_pane_controls',buttons);                
                }
            });
        }        
    }
    
    function edit_template(){
        history.pushState(null, null, '#template_edit_page#'+current_template_uuid);          
        template_edit_page.open(current_template_uuid);        
    }
    
    function initialise_data_table() {
        var dt_cols, index, data, sorting_col, i;
        dt_cols = [];
        dt_cols.push({
            "bVisible": false,
            "bSortable": false,
            "mDataProp": "uuid"
        });
        dt_cols.push({
            "mDataProp": function(oData, type) {
                return '<input type="checkbox" template_uuid="'+oData.uuid+'" />';
            },
            "bSortable": false,
            "bSearchable": false,
            "sClass": 'no_prop'
        });
        dt_cols.push({
            mDataProp: function(oData, type) {
                return oData.name.escape();
            },
            "bSortable": true,
            "bSearchable": true
        });
        dt_cols.push({
            "mDataProp": function(oData, type) {
                if(oData.active){
                    return '<span template_uuid="'+oData.uuid+'" title="' + gettext("Currently Active") + '" class="icon-checkmark active_template jq_activate_template"></span>'; 
                }else{
                    return '<span template_uuid="'+oData.uuid+'" title="' + gettext("Currently Inactive") + '" class="icon-checkmark inactive_template jq_activate_template"></span>';
                }
            },
            "bSortable": false,
            "bSearchable": false
        });

        table = $('#template_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_templates",
            "bServerSide": true,
            "aoColumns": dt_cols,
            "bDestroy": true,
            "aaSorting": [[2, "asc"]],
            "bAutoWidth": false,
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            "sDom": 'f<"table_controls jq_template_table_controls">t<".dataTables_pages" ip>',
            "sScrollY": "500px",
            oLanguage: DATATABLES_LANG,
            "fnServerData": server_data,
            "fnDrawCallback": function(){
                $('#template_toggle_select_all').removeClass('selected');
                select_all_toggled = false;
                // Select the first table row
                var row = $('#template_table tbody tr:first-child').click();
                if(!self.templates){
                    $('#template_empty_tmpl').tmpl().appendTo($('#template_preview_pane').empty());
                }
            }
        });        
        table.fnSetFilteringDelay(800);
        set_table_size();
    }

    function server_data(sSource, aoData, fnCallback){
        if(!self.syncing_templates){
            self.syncing_templates = true;
            var data = {};
            for (var i in aoData) {
                data[aoData[i].name] = aoData[i].value;
            }
            var loader = new Loader({target: '#template_table_wrapper .dataTables_scroll', caption: gettext("Loading Templates")})
            loader.show(function(){
                data.placeholder_filter = $("#placeholder_type_filter_dropdown").val();
                data.screen_number_filter = $("#screen_number_filter_dropdown").val();
                $.ajax({
                    "dataType": 'json', 
                    "type": "POST", 
                    "url": sSource, 
                    "data": $.toJSON(data),
                    "processData": false,
                    "contentType": "application/json",
                    "success": function(input){
                        
                        if(!self.initialized){
                            return;
                        }
                        
                        var i = input.aaData.length;
                        while(i--){
                            templates[input.aaData[i].uuid] = input.aaData[i];
                        }
                        fnCallback(input);
                        loader.hide();
                        update_checked_count();
                        self.syncing_templates = false;
                    }
                });
            });
        }
    }

    function resize(){
        set_table_size();
        table.fnAdjustColumnSizing(false);
    }
    
    function set_table_size() {
        $('#template_table_wrapper .dataTables_scrollBody').height(
            $('#template_table_wrapper').innerHeight() -
            $('#template_table_wrapper .dataTables_scrollHead').outerHeight() -
            $('.jq_template_table_controls').outerHeight() -
            $('#template_table_filter').outerHeight() -
            $('#template_table_info').outerHeight()
        );
    }
    
    function add_table_controls() {
        var buttons = [];
        if (helpers.is_allowed('tms_templating_action')){
            buttons = [
                {text:gettext('New'), image:'new', onClick: new_template, id:'template_new_btn'},
                {text:gettext('Delete'), image:'delete', onClick: delete_template, disabled: true, id:'template_delete_btn'}
            ];
        }
        helpers.set_buttons('.jq_template_table_controls', buttons);
    }
    
    function update_checked_count() {
        var selected = $('input:checkbox:checked', table.fnGetNodes()).length;
        $('#template_toggle_select_all').html(selected);
        $('#template_delete_btn').button('option', 'disabled', (selected == 0));
    }
    
    function delete_template() {
        selected_templates = [];
        $('#template_table input:checked').each(function(i, checkbox){            
            var uuid = $(checkbox).attr('template_uuid');
            selected_templates.push(templates[uuid]);
        });
        update_delete_dialog();
    }

    function update_delete_dialog(){
        var delete_button = {
            'text': gettext('Delete'),
            'action': function() {
                delete_templates(selected_templates);
            }
        };
        dialog.open({
            'title': gettext('Delete'), 
            'template': '#template_delete_tmpl',
            'buttons': [delete_button],
            'close': function(){
            },
            'data': {
                'templates': selected_templates
            },
            'width': 500,
            'height': 300
        });
    }

    function delete_templates(templates_to_delete) {
        var template_uuids = [];
        for (var i = 0, templates_to_delete_length = templates_to_delete.length; i < templates_to_delete_length; i++) {
            template_uuids.push(templates_to_delete[i].uuid);
            $('.jq_delete_entry[data-template_uuid="%uuid"] .jq_status'.replace('%uuid', templates_to_delete[i].uuid)).addClass('pending');
        };
        
        helpers.ajax_call({
            data:{template_ids:template_uuids}, 
            url:'/core/template/delete',
            notify: false,
            success_function:function(input){
                var ms_offset = 0;
                var message;
                var state;
                var start = new Date().getTime();
                var elems = $('.jq_delete_entry').clone();
                var i = elems.length;
                var m = input['messages'].length;
                var state, message;
                while(i--){
                    var elem = elems.eq(i);
                    var x = m;
                    while(x--){
                        message = input['messages'][x];
                        state = message.type == 'success' ? 'success' : 'failed';
                        if(message.template_uuid == elem.attr('data-template_uuid')){
                            elem.find(".jq_status").switchClass('pending', state);
                        }
                    }
                }
                $('#dialog_contents').html(elems);

                update_templates();
                var new_buttons = [];
                new_buttons.push({
                    'text': gettext('Done'),
                    'action': dialog.close
                });
                dialog.update({
                    buttons : new_buttons
                });
            }
        });
    }
    
    function update_templates() {
        table.fnDraw();
    }    
    
    function new_template() {
        history.pushState(null, null, '#template_edit_page');
        template_edit_page.open();
    }
}