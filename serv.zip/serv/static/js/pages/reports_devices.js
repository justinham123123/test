var report_devices_page = new ReportDevicesPage();

function ReportDevicesPage() {
    var self = this;
    
    self.main_tmpl = '#reports_devices_main_tmpl';
    self.reports_devices_device_info_tmpl = '#reports_devices_device_info_tmpl';
    self.reports_devices_screen_info_tmpl =  '#reports_devices_screen_info_tmpl';

    self.all_screens_details = {};


    self.open = function(report){
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load', close_page);
        $(self.main_tmpl).tmpl2().appendTo( $('#main_section').empty());
        $(document).trigger('page_loaded');

        if (report == undefined) report = 'devices';
        nav_select('report', report);
        
        self.loader = new Loader({target: '#main_section', caption: gettext("Loading")});
        self.loader.show();

        var sorted_screens = [];
        for (var screen in $device_store.screens){
            sorted_screens.push($device_store.screens[screen]);
        }
        sorted_screens.sort_screens();

        self.all_screens_details['lms'] = {};
        self.all_screens_details['lms']['identifier']= 'LMS';
        self.all_screens_details['lms']['title']= 'LMS';
        self.all_screens_details['lms']['devices'] = {};

        for(var index in sorted_screens){
            var screen_id = sorted_screens[index]['uuid'];
            self.all_screens_details[screen_id] = {};
            self.all_screens_details[screen_id]['identifier'] = $device_store.screens[screen_id]['identifier'];
            self.all_screens_details[screen_id]['title'] = $device_store.screens[screen_id]['title'];
            self.all_screens_details[screen_id]['devices'] = {};
        }

        load_device_data();

        $.when(
            proj_details_load, 
            device_details_load
        ).done(sort_screen_devices, devices_tab);
    }


    
    function load_device_data(){
        proj_details_load = helpers.ajax_call({url:'/core/projection/status/', success_function:update_projector_details})
        device_details_load = helpers.ajax_call({url:'/core/monitoring/info', success_function:update_server_details})
    }
    
    function update_projector_details(input){
        var projectors = input.data;
        for (var projector in projectors){
            var proj_device = helpers.get_device(projector);
            var screen_name = helpers.get_device_name(projector);
            if(proj_device.enabled){
                projectors[projector].id = projector;
                projectors[projector].type = proj_device.type;
                projectors[projector].category = proj_device.category;
                projectors[projector].version = proj_device.version;
                projectors[projector].screen_uuid = proj_device.screen_uuid;
                projectors[projector].screen_name = screen_name;
                //if we have a projector with multiple lamps, find the lamp number with the least hours remaining
                if(projectors[projector].lamps){
                    if(projectors[projector].lamps.length > 1){
                        var least_hours;
                        var least_hours_lamp;
                        var lamp;
                        for(var i in projectors[projector].lamps){
                            lamp = projectors[projector].lamps[i];
                            if(lamp.life){
                                if (least_hours == undefined){
                                    least_hours = lamp.life['remaining'];
                                    least_hours_lamp = i
                                }
                                else if(lamp.life['remaining'] && lamp.life['remaining'] < least_hours){
                                    least_hours = lamp.life['remaining'];
                                    least_hours_lamp = i
                                }
                            }
                        }
                        if(least_hours_lamp != undefined){
                            projectors[projector].lamps[least_hours_lamp]['least_hours_lamp_number'] = true;
                        }
                    }
                    else if(projectors[projector].lamps.length == 1){
                        projectors[projector].lamps[0]['least_hours_lamp_number'] = true; 
                    }
                }
                self.all_screens_details[proj_device.screen_uuid]['devices'][projector] = projectors[projector];
            }
        }
    }
    
    function update_server_details(input){
        var devices = input.data;
        for (var device in devices){
            var server_obj = helpers.get_device(device);
            if ((server_obj.category == 'sms' || server_obj.category == 'lms') && server_obj.enabled){
                var screen_name = helpers.get_device_name(device);
                var server_device_obj = $device_store.devices[device];
                devices[device].id = device;
                devices[device].ip = server_device_obj.ip;
                devices[device].type = server_device_obj.type;
                devices[device].category = server_device_obj.category;
                devices[device].ftp_ip = server_device_obj.ftp_ip;
                devices[device].screen_uuid = server_device_obj.screen_uuid;
                devices[device].screen_name = screen_name;
                if (server_obj.screen_uuid){
                    self.all_screens_details[server_obj.screen_uuid]['devices'][device] = devices[device];
                }
                else{
                    self.all_screens_details['lms']['devices'][device] = devices[device];
                }
            }
        }
    }

    function sort_screen_devices(){
        for (var screen in self.all_screens_details){
            var screen_servers = [];
            var screen_projectors = [];

            for (var device in self.all_screens_details[screen]['devices']){
                if (self.all_screens_details[screen]['devices'][device]['category'] == "sms" || self.all_screens_details[screen]['devices'][device]['category'] == "lms"){
                    screen_servers.push(self.all_screens_details[screen]['devices'][device]);
                }
                else if (self.all_screens_details[screen]['devices'][device]['category'] == "projector"){
                    screen_projectors.push(self.all_screens_details[screen]['devices'][device]);
                }
            }
            var screen_devices = screen_servers.concat(screen_projectors);
            self.all_screens_details[screen]['devices'] = {};
            for (var device in screen_devices){
                self.all_screens_details[screen]['devices'][screen_devices[device]['id']] = screen_devices[device];
            }
        }
    }

    function devices_tab(){
        self.loader.hide();
        $(self.reports_devices_device_info_tmpl).tmpl2({'screens': self.all_screens_details}).appendTo($("#jq_report_devices_screen_boxes").empty());

        $('.jq_device_raid').each(function(){
            var device_id = $(this).closest(".jq_device_info").attr("device_uuid");
            var screen_id = $(this).closest(".jq_screen_block").attr("screen_id");

            $('#reports_devices_device_raid_status_tmpl').tmpl2({'raid_status' : self.all_screens_details[screen_id]['devices'][device_id]["raid_status"]}).appendTo($(this).empty());
            $(this).qtip({
                content: {
                    text: $('#reports_devices_device_raid_hover_tmpl').tmpl2({'raid_status' : self.all_screens_details[screen_id]['devices'][device_id].raid_status.length ? self.all_screens_details[screen_id]['devices'][device_id]["raid_status"] : [gettext("Unknown")]})
                },
                position: {
                },
                style: {
                    classes: 'qtip-shadow qtip-rounded qtip-yellow'
                }
            });
        });

        $('.jq_screen_block').on('click.report_devices_page', function(){
            $(this).addClass('reports_devices_screen_block_selected').siblings().removeClass('reports_devices_screen_block_selected');
            var selected_screen_id = $(this).attr("screen_id");
            $(self.reports_devices_screen_info_tmpl).tmpl({'screen': self.all_screens_details[selected_screen_id]}).appendTo($(".jq_screen_info_section").empty());
            var selected_screen = $device_store.screens[selected_screen_id];
            for(var device in self.all_screens_details[selected_screen_id].devices){
                if (self.all_screens_details[selected_screen_id].devices[device].category == "sms" || self.all_screens_details[selected_screen_id].devices[device].category == "lms"){
                    make_disk_forecast_graph(self.all_screens_details[selected_screen_id].devices[device]);
                }
            }

            $('.jq_disk_usage_forecast_info').each(function(){
                $(this).qtip(
                    {
                        content: {
                            text: $('#reports_devices_disk_usage_info_hover_tmpl').tmpl2()
                        },
                        position: {
                            my: "right center",
                            at: "left center"
                        },
                        style: {
                            classes: 'qtip-shadow qtip-rounded'
                        }
                    }

                )

            })

            if(!$.trim($('.jq_reports_screen_server_details').html())){
                $('.jq_empty_server_side_pane_section').show();
            }
            if(!$.trim($('.jq_reports_screen_projector_details').html())){
                $('.jq_empty_projector_side_pane_section').show();
            }
        });

        $('.jq_screen_block:first').click();
    }
    
    function make_disk_forecast_graph(selected_device){
        var dates = [];
        //make an array of dates for ticker...next 7 days
        var current_date = new Date();
        for(var i=1; i<8; i++){
            var future_date = new Date(current_date.getTime() + ((24*i) * 60 * 60 * 1000));
            var graph_date = (future_date.getMonth()+1) +'/' + future_date.getDate();
            dates.push(graph_date);
            
        }

        helpers.ajax_call({
            url:'/tms/forecast_disk_usage', 
            data: {'device_ids':[selected_device.id]},
            success_function:function(input){
                var forecast_array = input['data'][selected_device.id]['definite'];
                var exceeds_capacity = false;
                for(day in forecast_array){
                    if (forecast_array[day] > 100){
                        //we just want to represent that its more than 100%, so limit it to 110 for nicer display
                        forecast_array[day] = 110;
                        if (!exceeds_capacity){
                            exceeds_capacity = true;
                        }
                    }
                }

                if(forecast_array){
                    var max = exceeds_capacity ? 110:100;
                    $.plot($(".jq_disk_usage_forecast_graph[device_id='"+selected_device.id+"']"), 
                        [
                            {
                             data: [ [0, forecast_array[1]], [1, forecast_array[2]], [2, forecast_array[3]], [3, forecast_array[4]], [4, forecast_array[5]], [5, forecast_array[6]], [6, forecast_array[7]] ],
                             lines: {show: true},
                             points: {show: true}
                            }
                        ],
                        {
                            xaxis: {
                                ticks: [
                                   [0,dates[0]],
                                   [1,dates[1]],
                                   [2,dates[2]],
                                   [3,dates[3]],
                                   [4,dates[4]],
                                   [5,dates[5]],
                                   [6,dates[6]]

                                ],
                                color: "#ccc"
                            },
                            yaxis: {
                                ticks: [
                                   [0,0],
                                   [25,'25%'],
                                   [50,'50%'],
                                   [75,'75%'],
                                   [100,'100%']
                                ],
                                color: "#ccc", 
                                max: max
                            },
                            grid: {
                                markings: [{
                                    yaxis: {
                                        from: 101,
                                        to: 110
                                    },
                                    color: '#EB4141'
                                }]
                            }   
                        }
                    )

                }
                else{
                    $(".jq_disk_usage_forecast_graph[device_id='"+selected_device.id+"']").hide();
                    $('.jq_disk_usage_forecast_unavailable').show();
                }

            }

        });
    }
     
    function close_page(){
        $(window).off('click.report_devices_page');
        $(document).off('page_load', close_page);
    }
    
}
