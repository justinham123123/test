var macro_pack_page = new MacroPackPage();
function MacroPackPage() {
    var self = this;

    //Templates
    self.main_tmpl = '#macro_pack_main_tmpl';
    self.new_tmpl = '#macro_pack_new_macro_type_tmpl';
    self.delete_pack_tmpl = '#macro_pack_delete_tmpl';
    self.duplicate_pack_tmpl = '#macro_pack_duplicate_tmpl';
    self.duplicate_pack_feedback_tmpl = '#macro_pack_duplicate_feedback_tmpl';
    self.delete_placeholder_tmpl = '#macro_placeholder_delete_tmpl';

    //Other
    self.select_all_toggled = false;
    self.macro_packs = {};
    self.macro_placeholders = {};
    self.table;
    self.selected = [];

    self.open = function() {
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load.macro_pack', close_page);
        $(self.main_tmpl).tmpl2({}, '#main_section');
        nav_select('config', 'macro_pack');

        var buttons = [];

        if (helpers.is_allowed('tms_schedule_action')){
            buttons = [
                {text:gettext('New'), image:'new', onClick: new_macro_pack},
                {text:gettext('Delete'), image:'delete', onClick: delete_macro_placeholder, disabled: false}
            ];
        }
        helpers.set_buttons('#macro_pack_action_buttons', buttons);

        load_macro_placeholders();
    };

    function close_page() {
        $(window).off('.macro_pack');
    }

    function reload(){
        load_macro_placeholders();
    }

    function load_macro_placeholders() {
        helpers.ajax_call({
            url: '/tms/get_macro_placeholders_display',
            loader: {
                target: $('#macro_placeholders')
            },
            success_function: function(input){
                for(var index in input){
                    var placeholder = input[index];
                    placeholder.screen_servers.sort_screens('screen_identifier');
                    self.macro_placeholders[placeholder.uuid] = placeholder;
                }
                draw_macro_placeholders(input);
            }
        });
    }

    function draw_macro_placeholders(placeholders){
        $('#macro_placeholder_list_tmpl').tmpl2({macro_placeholders: placeholders}, '#macro_placeholders');
        var widest = 0;
        $('.placeholder_name').each(function(){
            var left = $(this).offset().left + $(this).outerWidth();
            if(left > widest){
                widest = left;
            }
        });
        $('.placeholder_name').css("min-width", widest);
        $('.macro_pack_selector').click(function(){
            $('.macro_pack_selector.selected').removeClass("selected");
            $(this).addClass("selected");
            var placeholder_uuid = $(this).attr("data-placeholder_uuid");
            var device_uuid = $(this).attr("data-device_uuid");
            load_macro_pack_details(placeholder_uuid, device_uuid);
        });
        $('.macro_pack_selector').first().click();
    }

    function load_macro_pack_details(placeholder_uuid, device_uuid){
        var placeholder = self.macro_placeholders[placeholder_uuid];
        var macro_pack_uuid = null;
        for(var i in placeholder.screen_servers){
            var screen_server = placeholder.screen_servers[i];
            if(screen_server.device_uuid === device_uuid){
                placeholder.screen_identifier = screen_server.screen_identifier;
                macro_pack_uuid = screen_server.macro_pack_uuid;
            }
        }
        helpers.ajax_call({
            url: '/tms/get_macro_pack_detailed',
            data: {
                placeholder_uuid: placeholder_uuid,
                device_uuid: device_uuid
            },
            loader: {
                target: "#macro_pack_info"
            },
            success_function: function (input){
                $('#macro_pack_edit_info_tmpl').tmpl2(placeholder, '#macro_pack_info');
                var is_empty = $.isEmptyObject(input.data);
                if( is_empty ){
                    var edit_button = {
                        id: 'marco_pack_edit_button',
                        text: gettext('Create'),
                        image: 'new',
                        onClick: function(){
                            edit_macro_pack(device_uuid, placeholder_uuid, macro_pack_uuid);
                        }
                    };
                }else{
                    var edit_button = {
                        id: 'marco_pack_edit_button',
                        text: gettext('Edit'),
                        image: 'edit',
                        onClick: function(){
                            edit_macro_pack(device_uuid, placeholder_uuid, macro_pack_uuid);
                        }
                    };
                }
                var duplicate_button = {
                    id: 'marco_pack_duplicate_button',
                    disabled: is_empty,
                    text: gettext('Duplicate'),
                    image: 'icon-copy',
                    onClick: function(){
                        duplicate_macro_pack(device_uuid, placeholder_uuid, macro_pack_uuid);
                    }
                };
                var delete_button = {
                    id: 'marco_pack_delete_button',
                    disabled: is_empty,
                    text: gettext('Delete'),
                    image: 'icon-remove',
                    onClick: function(){
                        delete_macro_pack(device_uuid, placeholder_uuid, macro_pack_uuid);
                    }
                };
                if(!is_empty){
                    $('#macro_pack_edit_event_list').tmpl2({event_list: input.data.event_list}, '#macro_pack_events');
                }
                var buttons = [];
                if (helpers.is_allowed('tms_schedule_action')){
                    buttons = [edit_button, duplicate_button, delete_button];
                }
                helpers.set_buttons('#macro_pack_actions', buttons);
            }
        });
    }

    function edit_macro_pack(device_uuid, placeholder_uuid, macro_pack_uuid){
        var new_hash = '#macro_pack_edit_page#'+ device_uuid +'#'+ placeholder_uuid;
        if(macro_pack_uuid){
            new_hash += '#'+macro_pack_uuid;
        }
        window.location.hash = new_hash;
    }

    function new_macro_pack() {
        var buttons = [];
        var data;
        buttons.push({
            text: gettext('Save'),
            action: save_new_macro_pack
        });
        dialog.open({
            title: gettext('New Macro Pack'),
            buttons: buttons,
            hbtemplate: self.new_tmpl,
            data: data
        });

        $('#macro_pack_new_macro_type_title').keypress(function(event){
            if(event.keyCode === 13) {
                save_new_macro_pack();
                event.preventDefault();
                return false;
            }
        }).focus();

        $('#new_macro_pack_form').validate();
    }

    function save_new_macro_pack() {
        if( $('#new_macro_pack_form').valid()){
            helpers.ajax_call({
                url: '/core/macro_pack/save_macro_placeholder',
                data: {
                    'macro_placeholder_name': $('#macro_pack_new_macro_type_title').val(),
                    'has_content':$('#macro_pack_new_macro_type_has_content').is(':checked')
                },
                success_function: dialog.close,
                complete_function: reload
            });
        }
    }

    function delete_macro_pack(device_uuid, macro_placeholder_uuid, macro_pack_uuid) {
        var buttons = [];
        var data = {
            screen: $device_store.devices[device_uuid].screen().identifier,
            name: self.macro_placeholders[macro_placeholder_uuid].name
        };
        buttons.push({
            text: gettext('Delete'),
            action: function() { do_delete_macro_pack(macro_pack_uuid);}
        });
        dialog.open({
            title: gettext('Delete Macro Pack'),
            buttons: buttons,
            hbtemplate: self.delete_pack_tmpl,
            data: data
        });
    }

    function do_delete_macro_pack(macro_pack_uuid) {
        helpers.ajax_call({
            url: '/core/macro_pack/delete',
            data: {macro_pack_uuids: [macro_pack_uuid]},
            success_function: dialog.close,
            complete_function: reload
        });
    }

    function do_duplicate_macro_pack(device_uuid, macro_placeholder_uuid, macro_pack_uuid) {
        $(".macro_pack_dialog").css("opacity",0.3);
        helpers.show_loader($("#dialog_contents"), null, gettext("Duplicating"));
        helpers.ajax_call({
            url: '/tms/duplicate_macro_pack',
            data: {
                device_uuid: device_uuid,
                macro_placeholder_uuid: macro_placeholder_uuid,
                macro_pack_uuid: macro_pack_uuid
            },
            success_function: duplicate_macro_feedback,
            complete_function: function(){
                reload();
                helpers.hide_loader();
            }
        });
    }

    function duplicate_macro_feedback(input){
        var devices = [];
        $("#at_button_0").remove();
        for( var device_uuid in input.data){
            devices.push({
                screen_number: $device_store.devices[device_uuid].screen().identifier,
                duplicated: input.data[device_uuid]
            });
        }
        devices.sort(function(a,b){return a.screen_number - b.screen_number;});
        for(var device in devices){
            $(self.duplicate_pack_feedback_tmpl).tmpl2(devices[device]).appendTo($('.jq_macro_pack_duplicate_feedback'));
        }
        $(".macro_pack_dialog").hide();
        $(".jq_macro_pack_duplicate_feedback").show();
    }

    function duplicate_macro_pack(device_uuid, macro_placeholder_uuid, macro_pack_uuid) {
        var buttons = [];
        var data = {
            screen: $device_store.devices[device_uuid].screen().identifier,
            name: self.macro_placeholders[macro_placeholder_uuid].name
        };
        buttons.push({
            text: gettext('Confirm'),
            action: function() {
                do_duplicate_macro_pack(device_uuid, macro_placeholder_uuid, macro_pack_uuid);
            }
        });
        dialog.open({
            title: gettext('Duplicate'),
            buttons: buttons,
            hbtemplate: self.duplicate_pack_tmpl,
            data: data
        });
    }

    function delete_macro_placeholder() {
        var placeholders = {};
        var placeholder_uuids = [];
        $('.placeholder_selector:checked').each(function(){
            var placeholder_uuid = $(this).attr("data-placeholder_uuid");
            placeholders[placeholder_uuid] = self.macro_placeholders[placeholder_uuid];
            placeholder_uuids.push(placeholder_uuid);
        });
        if(!$.isEmptyObject(placeholders)){
            dialog.open({
                title: gettext('Delete'),
                buttons: [{
                    text: gettext('Delete'),
                    action: function(){
                        do_delete_macro_placeholder(placeholder_uuids);
                    }
                }],
                hbtemplate: self.delete_placeholder_tmpl,
                data: {
                    macro_placeholders: placeholders
                }
            });
        }
        else{
            notification.info_msg(gettext("Nothing selected"), gettext("Delete"));
        }
    }

    function do_delete_macro_placeholder(placeholder_uuids) {
        helpers.ajax_call({
            url: '/core/macro_pack/delete_macro_placeholders',
            data: {"macro_placeholder_uuids": placeholder_uuids},
            success_function: dialog.close,
            complete_function: reload
        });
    }
}
