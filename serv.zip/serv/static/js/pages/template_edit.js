var template_edit_page = new TemplateEditPage();

function TemplateEditPage() {
    var self = this;

    //Templates
    self.main_tmpl = '#template_edit_main_tmpl';
    
    // Template
    self.template_uuid = undefined;
    self.template;
    self.form;
    
    // Placeholders
    self.content_placeholders;
    self.macro_placeholders;
    
    self.drag_list = null;
    
    self.mouse_x = 0;
    self.mouse_y = 0;
    self.changes_made = false;
    
    var duplicatable = ['macro_placeholder', 'auto_transition'];

    //Methods
    self.open = function(template_uuid) {
        // Doc stuff
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load', _close_page);
        nav_select('config', 'template');
        $(self.main_tmpl).tmpl().appendTo( $('#main_section').empty() );
        
        // Current teomplate UUID
        self.template_uuid = template_uuid;
        
        // Buttons
        helpers.set_buttons('#template_edit_action_buttons', [
            {text:gettext('Save'), image:'save', _class:"jq_save_template_button", onClick: self.save_template},
            {text:gettext('Insert Transitions'), image:'icon-wand', _class:"jq_auto_determine_transitions", onClick: add_auto_transitions},
            {text:gettext('Remove Transitions'), image:'icon-cross', _class:"jq_remove_auto_transitions", onClick: remove_auto_transitions}
        ]);
        
        // Tabs
        var template_tabs = [
            {'tab_value':'content_placeholder', 'tab_translated_title':gettext('Content Placeholders')},
            {'tab_value':'macro_placeholder', 'tab_translated_title':gettext('Macro Placeholders')},
        ];
        
        // Edit section
        $('#template_edit_content_section').html($('#template_edit_content_section_tmpl').tmpl({
            'template_tabs': template_tabs
        }));        
        
        // Text Filter
        $('.template_edit_content_body_search').html($('#template_edit_content_search_tmpl').tmpl()); 
        
        // Load core stuff
        var loading_funcs = [_load_content_placeholders(), _load_macro_placeholders()];
        if (self.template_uuid === undefined) {
            self.template = new TemplateObject();
        }
        else {
            loading_funcs.push(self._load_template());
        }
        
        // Show Loader
        var loader = new Loader({target: "#main_section"})
        loader.show();
        
        // Draw template when core stuff loads
        $.when.apply(undefined, loading_funcs).done(function(){
            self.draw_template();
            loader.hide();
            $('.template_edit_content_tab:first').click();
            _load_templates();
        });
        
        // Disable Save button
        $("#button_0").addClass("disabled");
        _changes_made(false);
    };

    self._load_template = function() {
        return helpers.ajax_call({ 
            url:'/core/template/template', 
            data: {
                template_ids: [self.template_uuid]
            },
            success_function:function(input){
                for(var uuid in input.data){break;} // Get first
                self.template = new TemplateObject(input.data[uuid]);
                self.draw_template();
            }
        });
    }

    function drag_function(event, ui){
        self.mouse_x = event.pageX;
        self.mouse_y = event.pageY;        
    }

    function start_function(event, ui){        
        $('#template_edit_playlist_section').addClass("drop_enabled");
        self.dragging = true;
        self.scroll_listener();
    }

    function stop_function(event, ui){
        $('#template_edit_playlist_section').removeClass("drop_enabled");
        self.dragging = false;
    }

    function draggable_helper(){
        return $(this).clone().css({
            'width': $(this).width(),
            'margin': 0
        });
    }

    var draggable_defaults = {
        helper: draggable_helper,
        cursorAt: {
            top: 2
        },
        containment : '#main_section',
        appendTo :'#main_section',
        tolerance :'intersect', 
        drag: drag_function,
        start: start_function,
        stop: stop_function
    }
    
    self.scroll_listener = function(){ 
        if (self.dragging) {
            var pes = $('#template_edit_template_section');
            var pes_scroll_top = pes.scrollTop();
            var pes_offset = pes.offset();
            var pes_height = pes.height();
            var move = false;
            if (self.mouse_x > pes_offset.left) {
                if (self.mouse_y -75 < pes_offset.top) {
                    pes_scroll_top -= 15;
                    move = true;
                }
                else if (self.mouse_y + 75 > pes_offset.top + pes_height) {
                    pes_scroll_top += 15;
                    move = true;
                }
                if (move) {
                    pes.scrollTop(pes_scroll_top);
                }
            }
            setTimeout(self.scroll_listener,1000/30);
        }
    }
       
    function _load_content_placeholders() {
        return helpers.ajax_call({
            url:'/core/placeholder/placeholders', 
            data:{titles:true, sorted_list:true}, 
            success_function:_update_content_placeholders
        });
    }

    function _update_content_placeholders(input) {
        self.content_placeholders = input.data;
    }
    
    //Auto transitions set to false. A present we do not want them to be able to add their own
    function _load_macro_placeholders() {
        return helpers.ajax_call({url:'/core/macro_pack/macro_placeholders', data:{auto_transition:false}, success_function:_update_macro_placeholders});
    }

    function _update_macro_placeholders(input) {
        self.macro_placeholders = input.data;
    }
    
    function _load_templates() {
        return helpers.ajax_call({url:'/core/template/template', success_function:_update_templates});
    }

    function _update_templates(input) {
        self.templates = input.data;
    }    
    
    self.save_template = function(){
        if ($("#button_0").button("option","disabled")){
            notification.info_msg(gettext('There are no changes'),gettext("Save Template"));
            return;
        }
        _save_template(self.template.return_saveable());
    };

    function _save_template(template){
        if (self.form.checkForm()) {
            if( _template_name_valid() ){
                helpers.ajax_call({
                    url: '/core/template/save',
                    data:{
                        'templates':[template]
                    },
                    success_function: function(input){
                        _changes_made(false);
                        history.pushState(null, null, '#template_page');
                        template_page.open();
                    }
                });
            }else{
                notification.error_msg(gettext('A Template with that name already exists'), gettext("Save Template"));
            }
        }
        else {
            notification.error_msg(gettext('Complete all required fields'), gettext("Save Template"));
            self.form.showErrors();
        }
    }
    
    function _template_name_valid(){
        var valid = true;
        for(var template_uuid in self.templates){
            if( template_uuid != self.template.uuid ){
                if(self.templates[template_uuid].name.toLowerCase() == self.template.name.toLowerCase()){
                    valid = false;
                    break;
                }
            }
        }
        return valid;
    }
    
    self.draw_template = function() {
        $('#template_edit_info_section').html($('#template_info_tmpl').tmpl({
            'template' : self.template,
        }));

        $('#template_edit_template_section').html($('#template_edit_template_tmpl').tmpl({
            'template':self.template
        }));
        
        $('#template_info_form').keydown(function(event){
            if(event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });

        $('.template_edit_template_container').sortable({
            items: ".template_edit_template_element_wrap:not(.immovable)",
            start: function(event,ui) {
                //set temp_move_index so we know where we are moving from
                self.temp_move_index = $('.template_edit_template_container > div').index(ui.item);
            },
            update: function(event, ui) {
                self.changes_made = true;
                self.feature_add_special_case = false;
                var moved_event, target_position;
                if (self.temp_move_index === -2) {
                    return;
                }
                target_position = $('.template_edit_template_container > *').index(ui.item);
                if (self.temp_move_index !== -1) {
                    moved_event = self.template.event_list.splice(self.temp_move_index,1)[0];
                    self.template.event_list.splice(target_position, 0, moved_event);
                }
                else {
                    //Dragging from content list. Prevent duplication of content placeholders
                    var existing_uuids = [];
                    for (var event in self.template.event_list){
                        if(!$._in(self.template.event_list[event].type, duplicatable)){
                            existing_uuids.push(self.template.event_list[event].uuid);
                        } 
                    }

                    if(!$._in(ui.item.attr('uuid'), existing_uuids)){                        
                        var evnt = {
                            credit_offset: false,
                            uuid: ui.item.attr('uuid'),
                            text: ui.item.attr('text'),
                            type: ui.item.attr('type'),
                            transition: ui.item.attr('transition') !== 'true' ? '' : true
                        };
                        self.template.add_event(evnt, target_position);
                        self.feature_add_special_case = (evnt.type === 'title_placeholder');
                    }
                    else{
                        self.changes_made = false;
                    }
                }
                // Redetermine autotransitions if they exist
                check_add_auto_transitions();
            },
            receive: function(event, ui) {
                self.temp_move_index = -1;
            },
            helper:'clone',
            appendTo:'.template_edit_template_container',
            containment:'.template_edit_template_container',
            tolerance:'pointer'
        });
        
        //Let credit offset MP be dropped on to a feature/title placeholder
        $('.template_edit_template_container').find('[type="title_placeholder"]').parent().droppable({
            activeClass : 'drop_enabled',
            hoverClass : 'drop_hover',
            tolerance : 'intersect',
            accept : function($draggable) {
                return $draggable.attr('text') === 'Credit Offset';
            },
            drop:function(event, ui){
                var index = $(this).index();
                self.template.event_list[index].credit_offset = true;
                _changes_made();
                self.draw_template();
            }
        });
        
        $('.image.delete.content_attributes').click(_remove_from_template);
        $('#template_edit_template_section .delete_title_credit_offset').click(_remove_credit_offset);
        
        self.form = $('#template_info_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            },
            highlight: function(element){
                $(element).addClass("error");
            },
            unhighlight: function(element){
                $(element).removeClass("error");
            }
        });

        $('.template_edit_content_tab').click(_select_content_tab);        
        
        $('#template_content_search_input').keyup(function(e){
            var filter = $("#template_content_search_input").val().toLowerCase();
            if( filter.length > 1){
                $(".jq_list_edit_drag_item_wrap").each(function(){
                    var target = $(this).find(".title").text().toLowerCase();
                    var split = target.split(" ");
                    var show = false;
                    if( target.indexOf(filter) != -1){
                        show = true;
                    }else{
                        for(var word in split){
                            if( split[word].indexOf(filter) != -1 ){
                                show = true;
                                break;
                            }
                        }
                    }
                    $(this).toggle(show);
                });
            }else{
               $(".jq_list_edit_drag_item_wrap").show();
            }
         });
        
        $('#template_info_form').on('change keyup', function(){
            self.template.name = $.val_or_undefined($('#template_edit_title').val());
            self.template.cpl_transitions = $('#cpl_transition').is(':checked')
            _changes_made();
        });

        helpers.hide_loader();
    }
    
    function _select_content_tab(mouse_event) {
        var drag_list = [];
        var draggable;
        var tab_value = $(this).attr('tab_value');
        
        $(this).addClass('selected').siblings().removeClass('selected');

        $.each(_get_items(tab_value), function(index, item){
            draggable = {
                id : item.uuid,
                name : item.name,
                type : item.type==null?'macro_placeholder':item.type,
                transition: item.transition,
                image: _get_image(item.type==null?'macro_placeholder':item.type)
            }
            drag_list.push(draggable);
        });
        
        //Mega credit offset hack, pull out credit offset from list
         var i = drag_list.length;
         var credit_offset = null;
         while(i){
            i--;
            if(drag_list[i].name === "Credit Offset"){
                var credit_offset = drag_list.splice(i, 1)[0];
            }
        }

        $(".template_edit_content_body_main").html(
            $("#template_edit_generic_drag_list_tmpl").tmpl({"drag_list":drag_list})
        );
        
        $('.template_edit_content_body_main > div').draggable({
            helper : function(){return $(this).clone().css({'width': $(this).width()})},
            containment : '#main_section',
            connectToSortable :'.template_edit_template_container',
            appendTo :'#main_section',
            tolerance :'intersect',
            start :function(){
                $('#template_edit_pack_section').addClass("drop_enabled");
                self.dragging = true;
                self.scroll_listener();
            },
            stop :function(){
                $('#template_edit_pack_section').removeClass("drop_enabled");
                self.dragging = false;
            }, 
            drag: function(event, ui) {
                self.mouse_x = event.pageX;
                self.mouse_y = event.pageY;
            }
        });
        
        //Re-add the credit offset draggable
        if(credit_offset){
            $('#template_edit_generic_drag_list_tmpl').tmpl({'drag_list': [credit_offset], 'type': 'macro_placeholder'}).appendTo('.template_edit_content_body_main');
            $('.jq_list_edit_drag_item_wrap[uuid="'+credit_offset.id+'"]').draggable({
                helper : function(){return $(this).clone().css({'width': $(this).width(),'margin':0}).addClass('automation')},
                appendTo:'#main_section',
                tolerance:'intersect',
                refreshPositions: true,
                drag: drag_function,
                start: function(){
                    self.dragging = true;
                    self.scroll_listener();
                },
                stop: stop_function
            });
        }
        
        $("#template_content_search_input").val("");
    }
    
    function check_add_auto_transitions() {
        var any_transitions_exist = false;
        for(var i in self.template.event_list) {
            if(self.template.event_list[i].type === 'auto_transition') {
                any_transitions_exist = true;
                break;
            }
        }
        if(any_transitions_exist) {
            add_auto_transitions(null, true); //Re-add them
        } else {
             _changes_made();
             self.draw_template();
        }
    }

    function remove_auto_transitions(e, no_redraw){
        self.template.event_list = self.template.event_list.filter(function(event) {
            return event.type !== 'auto_transition';
        });
        for(var i in self.template.event_list) {
            //Remove credit offset from feature
            if(self.template.event_list[i].type === 'title_placeholder') {
                self.template.event_list[i].credit_offset = false;
            }
        }
        if(!no_redraw) {
            self.draw_template();
            _changes_made();
        }
    }

    function add_auto_transitions(e, only_existing){
        if(only_existing) {
            //Save state before deleting auto_transitions
            var start_trans, feature_trans, end_trans, credits_set;
            //Only add back the ones that were there initially
            for(var i in self.template.event_list) {
                //Remove credit offset from feature
                if(self.template.event_list[i].type === 'auto_transition') {
                    switch(self.template.event_list[i].transition) {
                        case('show_start'): start_trans = true; break;
                        case('show_end'): end_trans = true; break;
                        case('feature_start'): feature_trans = true; break;
                        default: //Deal with migrations (transition property used to be an empty string)
                            start_trans = true;
                            end_trans = true;
                            feature_trans = true;
                    }
                }
                else if(self.template.event_list[i].type === 'title_placeholder') {
                    credits_set = self.template.event_list[i].credit_offset;
                }
            }
            //Make sure we add in feature start transition if existing content has auto transitions
            if((start_trans || end_trans) && self.feature_add_special_case) {
                feature_trans = true;
                credits_set = true;
            }
        }
        remove_auto_transitions(null, true);
        //Create default auto_transition event
        var def = {
            type: 'auto_transition',
            text: 'Auto Transition',
            credit_offset: false,
            transition: ''
        };

        //Add show start and end
        if(self.template.event_list.length > 0){ //non-auto-transition events exist
            if(start_trans || !only_existing) {
                var event = $.extend({}, def);
                event.text = 'Show Start Transition';
                event.transition = 'show_start';
                self.template.add_event(event, 0);
            }
            if(end_trans || !only_existing) {
                var event = $.extend({}, def);
                event.text = 'Show End Transition';
                event.transition = 'show_end';
                self.template.add_event(event, self.template.event_list.length);
            }
            //Feature and credit offset
            for(var i in self.template.event_list) {
                if(self.template.event_list[i].type === 'title_placeholder') {
                    self.template.event_list[i].credit_offset = (credits_set || !only_existing);
                    if(feature_trans || !only_existing) {
                        var event = $.extend({}, def);
                        event.text = 'Feature Start Transition';
                        event.transition = 'feature_start';
                        self.template.add_event(event, i);
                    }
                    break;
                }
            }
        }
         self.draw_template();
        _changes_made();
    }
    
    function _get_items(type){
        switch(type){
            case 'content_placeholder' : return self.content_placeholders;
            case 'macro_placeholder' : return self.macro_placeholders;
        }
    }
    
    function _get_image(type){
        switch(type){
            case 'content_placeholder' : return "placeholder";
            case 'macro_placeholder' : return "macro_placeholder";
            case 'title_placeholder' : return "title_placeholder";
            case 'auto_transition': return "auto_transition";
        }
    }    
    
    function _sort_by_name(a, b){
        if (a.name < b.name){
            return -1;
        }
        return 1;
    }    
    
    function _changes_made(bool){
        bool = typeof bool != 'undefined' ? bool : true;
        self.changes_made = bool;
        g_prevent_navigation = bool;
        $('.jq_save_template_button').button("option","disabled",!bool);
    }
    
    function _remove_from_template() {
        self.template.event_list.splice($(this).closest('.template_edit_template_element_wrap').index(), 1);
        check_add_auto_transitions();
    }
    function _remove_credit_offset() {
        self.template.event_list[$(this).closest('.template_edit_template_element_wrap').index()].credit_offset = false;
        _changes_made();
        self.draw_template();
    }
    
    function _close_page() {
        $(document).off('page_load');
    }
}
