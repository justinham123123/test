 var transfer_page = new TransferPage();
function TransferPage() {
    var self = this;

    //Templates
    self.main_tmpl = '#transfer_main_tmpl';
    self.transfer_item_tmpl = '#transfer_item_tmpl';

    // Constants
    self.update_display_frequency = 5000;
    self.transfer_sync_frequency = 1500;
    self.dom_batch_size = 10;
    self.dom_visible_count = 50;
    self.dom_deferred_draw = 80;
    self.dom_draw_increment = 10;
    self.transfer_fade_speed = 180;

    // Other stuff
    self.transfers = {};
    self.transfer_doms = {};
    var sync_timeout;
    self.state_filter;
    self.type_filters;
    self.transfer_transitions = {};
    self.server_selector;
    self.count_map = {};
    self.selected_device;
    self.overlay = false;
    self.select_device_uuid = undefined;
    self.load_index = 0;
    self.load_amount = 30;
    self.source_toggled = false;
    self.load_transfers_pending = false;

    //Filtering info
    self.state_filters = [];
    self.type_filters = [];
    self.search_filter = "";

    // Columns
    self.queue_col;
    self.active_col;
    self.completed_col;

    // Visible Transfer count
    self.queued_visible;
    self.active_visible;
    self.completed_visible;

    //Methods
    self.open = function() {

        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load.transfer', self._close_page);
        nav_select('content', 'transfers');

        // initialise templates
        $(self.main_tmpl).tmpl().appendTo( $('#main_section').empty());
        self.server_selector = new DeviceSelector({
            'append_to':$('#screen_selector').empty(),
            'include_all':true,
            'on_click': select_device,
            'supported_function':'transfer',
            'initial_selected' : "All"
        });

        self.selected_device = {"id":"All"};
        self.server_selector.init();

        // events
        _add_transfer_event_handlers();

        // page loaded
        $(document).trigger('page_loaded');

        // Columns
        self.queue_col = document.getElementById("transfer_queued_col");
        self.active_col = document.getElementById("transfer_active_col");
        self.completed_col = document.getElementById("transfer_completed_col");
    };

    self._close_page = function(){
        clearTimeout(sync_timeout);
        self.transfers = {};
        self.transfer_doms = {};
        self.state_filter = null;
        self.search_filter  = "";
        self.type_filters = [];
        self.source_toggled = false;
        self.load_transfers_pending = false;
        $(document).off('page_load.transfer');
        $('#main_section').off('click.transfer');
    }

    function select_device(device_uuid){
        device_uuid = device_uuid == "All" ? undefined : device_uuid;
        self.select_device_uuid = device_uuid;
        self.load_amount = 30;
        clearTimeout(sync_timeout);
        load_transfers();
        sync_timeout = setTimeout(update_transfers, self.update_display_frequency);
    }

    function load_transfers(){
        self.load_transfers_pending = true;
        self.transfers= {};
        helpers.ajax_call({
            url: '/tms/get_transfers_display',
            loader: {
                target: '#transfer_col_wrapper_wrapper',
                caption: gettext("Loading Transfers")
            },
            data: {
                "device_uuid": self.select_device_uuid,
                "state_filters": get_state_filters(),
                "type_filters": get_type_filters(),
                "search": get_search_filter(),
                "start": self.load_index,
                "length": self.load_amount
            },
            success_function: function(input){
                draw_transfers(input);
                self.load_transfers_pending = false;
            }, 
            error_function: function(){
                self.load_transfers_pending = false;
            }
        });
    }

    function get_search_filter(){
        return self.search_filter.length > 0 ? self.search_filter : null;
    }

    function get_type_filters(){
        return self.type_filters.length > 0 ? self.type_filters : null;
    }

    function get_state_filters(){
        return self.state_filters.length > 0 ? self.state_filters : null;
    }

    function draw_transfers(input){

        $("#transfer_queued_col, #transfer_active_col, #transfer_completed_col").empty();
        var transfers = input['data'];
        for(transfer_uuid in transfers['queue']){
            draw_transfer(transfers['queue'][transfer_uuid]);
        }
        for(transfer_uuid in transfers['active']){
            draw_transfer(transfers['active'][transfer_uuid]);
        }
        for(transfer_uuid in transfers['completed']){
            draw_transfer(transfers['completed'][transfer_uuid]);
        }
        if(input['data']['meta']['completed_count'] > self.load_amount){
            add_load_more();
        }
        update_hud(input['data']['meta']);
    }

    function add_load_more(){
        $("#load_more_tmpl").tmpl().appendTo("#transfer_completed_col");
        $("#load_more_button").click(function(){
            self.load_amount += 30;
            load_transfers();
        });
    }

    function update_transfers(){
        if (!self.load_transfers_pending){
            var known_transfers = {};
            for(transfer_uuid in self.transfers){
                var transfer = self.transfers[transfer_uuid];
                if(transfer['status'] == "completed" && transfer['info_missing'] == false){
                    continue;
                }
                known_transfers[transfer_uuid] = {
                    'status': transfer['status'],
                    'info_missing': transfer['info_missing']
                }
            }
            //console.log("known_transfers", known_transfers);
            helpers.ajax_call({
                url: '/tms/get_transfers_display_update',
                data: {
                    "device_uuid": self.select_device_uuid,
                    "known_transfers": known_transfers,
                    "state_filters": get_state_filters(),
                    "type_filters": get_type_filters(),
                    "search": get_search_filter()
                },
                success_function: function(input){
                    var updates = input.data;
                    apply_updates(updates);
                },
                complete_function: function() {
                    // Don't set the timeout until the call completes, otherwise slow calls can build up
                    // and lead to excessive CPU usage due to endless queued requests
                    sync_timeout = setTimeout(update_transfers, self.update_display_frequency);
                }
            });
        }
    }

    self.meta = {};

    function update_hud(meta){
        if(meta){
            self.meta = meta;
        }
        var queued_count = $('#transfer_queued_col .transfer_item').length || "";
        var active_count = $('#transfer_active_col .transfer_item').length || "";
        var completed_count = $('#transfer_completed_col .transfer_item').length;
        var complete_total = self.meta['completed_count'] ? "(" + self.meta['completed_count'] + ")" : "";
        $('#transfer_queued_status').text(queued_count);
        $('#transfer_active_status').text(active_count);
        $('#transfer_completed_status').text(completed_count + complete_total);
    }

    function apply_updates(updates){
        //console.log(updates);
        for(transfer_uuid in updates['added']){
            var new_transfer = updates['added'][transfer_uuid];
            self.transfers[transfer_uuid] = new_transfer;
            draw_transfer(new_transfer);
        }

        for(transfer_uuid in updates['moved']){
            var update = updates['moved'][transfer_uuid];
            for(key in update){
                self.transfers[transfer_uuid][key] = update[key];
            }
            move_transfer(self.transfers[transfer_uuid]);
        }

        for(transfer_uuid in updates['updated']){
            var update = updates['updated'][transfer_uuid];
            for(key in update){
                self.transfers[transfer_uuid][key] = update[key];
            }
            update_transfer(transfer_uuid, update);
        }

        for(transfer_uuid in updates['info']){
            var update = updates['info'][transfer_uuid];
            for(key in update){
                self.transfers[transfer_uuid][key] = update[key];
            }
            update_info(transfer_uuid, update);
        }

        for(transfer_uuid in updates['removed']){
            remove_transfer(transfer_uuid);
        }
        update_hud();
    }

    function update_info(transfer_uuid, update){
        var dom = $('#'+transfer_uuid);
        dom.find(".content_kind_icon").removeClass("unknown").addClass(update['content_kind']);
        dom.find(".jq_transfer_info_title").html(update['description']);
    }

    function update_transfer(transfer_uuid, update){
        var dom = $('#'+transfer_uuid);
        dom.find(".jq_transfer_progress").animate({'width': update['progress'] + "%"});
        var state = gettext("State") + ': ' + gettext("Unknown");
        var eta = gettext("Remaining Time") + ': '+ gettext("Unknown");
        if(update['state'] == "queued_on_device"){
            state = gettext("Queued on Device");
        }
        else if(update['progress']){
            state = gettext("Progress") + ': ' + update['progress'] + "%";
            if(!$.isEmptyObject(update['eta'])){
                eta = gettext("Remaining Time") + ': ' + update['eta'];
            }            
        }
        dom.find(".jq_transfer_progress_status").text(state);
        dom.find(".jq_transfer_progress_eta").text(eta);
    }

    function remove_transfer(transfer_uuid, callback){
        $('#'+transfer_uuid).fadeOut("slow", function(){
            $('#'+transfer_uuid).remove();
            if(callback)
                callback();
        });
    }

    function move_transfer(transfer){
        remove_transfer(transfer['id'], function(){
            draw_transfer(transfer);
        });
    }

    function draw_transfer(transfer){
        transfer['description'] = transfer['description'] || gettext("Title Unavailable");
        transfer['index'] = transfer['index'] || null;
        self.transfers[transfer.id] = transfer;
        var template = "";
        var target = "";
        var top = false;
        var pop = false;
        switch(transfer['status']){
            case "queue":
                template = "#queued_transfer_item_tmpl";
                target = $("#transfer_queued_col");
                break;
            case "active":
                template = "#active_transfer_item_tmpl";
                target = $("#transfer_active_col");
                break;
            case "completed":
                template = "#compeleted_transfer_item_tmpl";
                target = $("#transfer_completed_col");
                top = true;
                pop = true;
                break;
        }
        var dom = $(template).tmpl(transfer).css("display", "none");
        if(top){
            dom.prependTo(target);
            //If we have hit the show limit, then pop an item from the end
            if(pop && $('#load_more_button').length > 0){
                target.find(".transfer_item:last").remove();
            }
        }
        else{
            dom.appendTo(target);
        }
        if( self.source_toggled == true ){
            $(dom).find(".jq_transfer_info_title").hide();
            $(dom).find(".jq_transfer_info_finish").hide();
            $(dom).find(".jq_transfer_progress_eta").hide();
            $(dom).find(".jq_transfer_progress_status").hide();
            $(dom).find(".jq_transfer_source_overlay").show();
            $(dom).find(".jq_transfer_info_start").show();
        }
        dom.fadeIn("slow");
    }

    self._is_uuid = function(string){
        return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(string);
    }

    self._view_transfer_details = function(){
        if (self.transfers[$(this).attr('id')].message_code != null){
            if (TRANSFER_MESSAGE_CODES.hasOwnProperty(self.transfers[$(this).attr('id')].message_code)){
                //reassign the transfer message to make sure it is the translated string
                self.transfers[$(this).attr('id')]['message'] = TRANSFER_MESSAGE_CODES[self.transfers[$(this).attr('id')].message_code]
            }
        }
        dialog.open({
            'title': gettext('Transfer Details'),
            'template': '#transfer_info_tmpl',
            'data':self.transfers[$(this).attr('id')],
            'width':250
        })
    }

    self._clear_transfer_history = function(){
        var input = null
        var msg = null;
        // clear transfer history of currently selected server
        if(self.select_device_uuid){
            input = {device_ids:[self.select_device_uuid]}
            msg = gettext("Are you sure you want to clear the transfer history for the selected device?");
        }
        else{
            msg = gettext("Are you sure you want to clear the transfer history for all devices?")
        }
        if( confirm(msg) ){
            helpers.ajax_call({
                url:'/core/content/clear_transfer_history',
                loader: {
                    target: $('#main_section'),
                    caption: gettext("Clearing Transfer History")
                },
                data:input,
                success_function: function(input){
                    load_transfers();
                }
            });
        }
    }

    self._start_all_queued = function(){
        var uuids = [];
        $('#transfer_queued_col').find('.jq_transfer_item').each(function(){
            var uuid = $(this).attr("id");
            uuids.push(uuid);
        });
        __force_transfers(uuids);
    }

    self._cancel_all_active = function(){
        var uuids = [];
        $('#transfer_active_col').find('.jq_transfer_item').each(function(){
            var uuid = $(this).attr("id");
            uuids.push(uuid);
        });
        __cancel_transfers(uuids);
    }

    self._cancel_all_queued = function(){
        var uuids = [];
        $('#transfer_queued_col').find('.jq_transfer_item').each(function(){
            var uuid = $(this).attr("id");
            uuids.push(uuid);
        });
        __cancel_transfers(uuids);
    }

    self._can_retry = function(device_info) {
        if (device_info) {
            if ($device_store.devices[device_info]!== undefined) {
                return true;
            } else {
                for( device_id in $device_store.devices){
                    if($device_store.devices[device_id]['ftp_ip'] == device_info){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    function _get_server_by_id_or_ip(device_info){
        if (device_info) {
            if ($device_store.devices[device_info]!== undefined) {
                return device_info;
            }
            else {
                for( device_id in $device_store.devices){
                    if($device_store.devices[device_id]['ftp_ip'] == device_info){
                        return device_id;
                    }
                }
            }
        }
        return device_info;
    }

    self._retry_transfer = function(event){
        event.stopPropagation();
        var transfer_id = $(this).attr("transfer_id");
        transfer_info = self.transfers[transfer_id];
        if(!self._is_uuid(transfer_info['content_id']))
            return;
		if(transfer_info['type'] != "kdm") {
        	helpers.ajax_call({
            	url:'/core/content/transfer',
            	data:{
                	sending_device_id:_get_server_by_id_or_ip(transfer_info["source"]),
                	receiving_device_ids:[transfer_info["destination"]],
                	content_ids:[transfer_info["content_id"]]
            	}
        	});
        }
        else{
            helpers.ajax_call({
                url: '/core/content/retry_key_transfer',
                data: {
                    transfer_uuid: transfer_info.id
                }
            });
        }
    }

    self._force_transfer_handler = function(event){
        event.stopPropagation();
        __force_transfers([$(this).attr("transfer_id")]);
    }

    self._cancel_transfer_handler = function(event){
        event.stopPropagation();
        __cancel_transfers([$(this).attr("transfer_id")]);
    }

    self._move_up_transfer = function(event){
        event.stopPropagation();
        var transfer_id = $(this).attr("transfer_id");
        var transfer_dom = $('#'+transfer_id);
        var preceeding_transfer = transfer_dom.prev('.transfer_item:visible');

        if(preceeding_transfer.length > 0){
            _show_busy(transfer_dom);
            helpers.ajax_call({
                url:'/core/content/prioritize_transfer',
                data:{
                    transfer_id: transfer_id,
                    device_id: self.transfers[transfer_id].destination
                },
                success_function: function(input){
                    if(input['messages'][0]['type'] == "success"){
                        transfer_dom.prependTo("#transfer_queued_col");
                    }
                    show_active(transfer_dom);
                }
            });
        }
    };

    function __cancel_transfers(transfer_ids){
        cancellations = {}
        var destination, i;
        for(i = 0 ; i < transfer_ids.length ; i++){
            if( self.transfers[transfer_ids[i]] != undefined ){
                _show_busy(self.transfer_doms[transfer_ids[i]]);
            }
            destination = self.transfers[transfer_ids[i]].destination;
            if( cancellations[destination] == undefined){
                cancellations[destination] = [transfer_ids[i]];
            }else{
                cancellations[destination].push(transfer_ids[i]);
            }
        }
        for( device_uuid in cancellations ){
            helpers.ajax_call({
                url:'/core/content/cancel_transfers',
                data:{
                    transfer_ids : cancellations[device_uuid],
                    device_id : device_uuid
                }
            });
        }
    }

    function __force_transfers(transfer_ids){
        var force_transfer_dict = {};
        var transfer_id, device_id, i;
        for(i = 0 ; i < transfer_ids.length ; i++ ){
            transfer_id = transfer_ids[i];
            if( self.transfer_doms[transfer_id] != undefined){
                __validate_forced_transfer_dom(self.transfer_doms[transfer_id]);
            }
            device_id = self.transfers[transfer_id].destination;
            if( force_transfer_dict[device_id] == undefined ){
                force_transfer_dict[device_id] = [transfer_id];
            }else{
                force_transfer_dict[device_id].push(transfer_id);
            }
        }
        for( device_id in force_transfer_dict){
            helpers.ajax_call({
                url:'/core/content/force_transfers',
                data:{
                    transfer_ids : transfer_ids,
                    device_id : device_id
                }
            });
        }
    }

    function __validate_forced_transfer_dom(transfer_dom){
        var transfer_index = $(transfer_dom).index();
        var queued_transfers = $('#transfer_queued_col').children();
        $(transfer_dom).find(".jq_transfer_not_before").html(gettext("Queued"));
        $(transfer_dom).find(".jq_transfer_not_before").addClass("transfer_asap");
        $(transfer_dom).find(".jq_transfer_try_now_button").remove();
        $(transfer_dom).find(".jq_transfer_move_up_button").remove();
        $(transfer_dom).find(".jq_not_before").attr("not_before",null);
        queued_transfers.each(function(){
             if($(this).find(".jq_transfer_inner").attr("not_before") != null && $(this).index() < transfer_index){
                var queued_transfer = $(this);
                $(transfer_dom).fadeOut(self.transfer_fade_speed, function(){
                    $(transfer_dom).css({'display':'block','min-height':'0px','opacity':'0','padding':'0px','margin':'0px'});
                    $(transfer_dom).animate({height:0},self.transfer_fade_speed, function(){
                        $(transfer_dom).remove();
                        $(transfer_dom).insertBefore($(queued_transfer));
                        $(transfer_dom).css({'display':'block','height':'0px','opacity':'0','margin':'2% 2% 2% 2%','padding':'4px'});
                        $(transfer_dom).animate({height:28},self.transfer_fade_speed, function(){
                            $(transfer_dom).animate({opacity:'1'}, self.transfer_fade_speed);
                        });
                    });
                });
                return false; // break
             }
        });
    }

    function _add_transfer_event_handlers(){

        $('#transfer_text_filter_input').searcher(function(search_string){
            self.search_filter = search_string;
            load_transfers();
        });
        
        // cancel all active transfers
        $('#main_section').on(
            'click.transfer',
            '#transfer_cancel_all_active',
            self._cancel_all_active
        );

        // filter by KDM/CPL
        $('#main_section').on(
            'click.transfer',
            '#transfer_filter_box .type_filter',
            function(){
                if($(this).hasClass("selected")){
                    $(this).removeClass("selected");
                    filter_transfer_type([]);
                }
                else{
                    $("#transfer_filter_box .type_filter.selected").removeClass("selected");
                    $(this).addClass("selected");
                    var filter = $(this).attr("data-filter");
                    filter_transfer_type([filter]);
                }
            }
        );

        // Toggle transfer source
        $('#main_section').on(
            'click.transfer',
            '#transfer_filter_box .source_toggle',
            function(){
                if($(this).hasClass("selected")){
                    $(this).removeClass("selected");
                     _toggle_overlay(false);
                     self.source_toggled = false;
                }
                else{
                    $(this).addClass("selected");
                     _toggle_overlay(true);
                     self.source_toggled = true;
                }
            }
        );

        // clear transfer history
        $('#main_section').on(
            'click.transfer',
            '#transfer_clear_history',
            self._clear_transfer_history
        );

        // cancel all queued transfers
        $('#main_section').on(
            'click.transfer',
            '#transfer_cancel_all_queued',
            self._cancel_all_queued
        );

        // force transfer
        $('#main_section').on(
            'click.transfer',
            '.jq_transfer_try_now_button',
            self._force_transfer_handler
        );

        // move transfer up the queue
        $('#main_section').on(
            'click.transfer',
            '.jq_transfer_move_up_button',
            self._move_up_transfer
        );

        // retry transfer
        $('#main_section').on(
            'click.transfer',
            '.jq_transfer_retry_button',
            self._retry_transfer
        );

        // cancel transfer
        $('#main_section').on(
            'click.transfer',
            '.jq_transfer_delete_button',
            self._cancel_transfer_handler
        );

        // view transfer details
        $('#main_section').on(
            'click.transfer',
            '.jq_transfer_item',
            self._view_transfer_details
        );

        // filter transfers by state
        $("#main_section").on(
            'click.transfer',
            '#transfer_sorting .filter_button',
            function(){
                if($(this).hasClass("selected")){
                    $(this).removeClass("selected");
                    filter_transfers_state([]);
                }
                else{
                    var filter = $(this).attr("data-filter");
                    $("#transfer_sorting .filter_button").removeClass("selected");
                    $(this).addClass("selected");
                    switch(filter){
                        case "success":
                            filter_transfers_state(['success']);
                            break;
                        case "failed":
                            filter_transfers_state(['failed', 'cancelled']);
                            break;
                    }
                }
            }
        );
    }

    function filter_transfer_type(type_filters){
        self.type_filters = type_filters;
        load_transfers();
    }

    function filter_transfers_state(state_filters){
        self.state_filters = state_filters;
        load_transfers();
    }

    function _toggle_overlay(toggle){
        self.overlay = toggle;
        $(".jq_transfer_item:visible").find(".jq_transfer_info_title").toggle(!toggle);
        $(".jq_transfer_item:visible").find(".jq_transfer_info_finish").toggle(!toggle);
        $(".jq_transfer_item:visible").find(".jq_transfer_progress_eta").toggle(!toggle);
        $(".jq_transfer_item:visible").find(".jq_transfer_progress_status").toggle(!toggle);
        $(".jq_transfer_item:visible").find(".jq_transfer_source_overlay").toggle(toggle);
        $(".jq_transfer_item:visible").find(".jq_transfer_info_start").toggle(toggle);
    }

    function _show_progress(transfer, progress, transfer_state){
        if(progress != undefined){
            if(progress == 100){
                $(transfer).find(".jq_progress").html(gettext("Complete"));
                $(transfer).find(".jq_transfer_progress_eta").css("display","none");
                $(transfer).find(".jq_transfer_delete_button").css("display","none");
            }
            if(progress > 98){
                $(transfer).find(".jq_transfer_progress").css({borderTopRightRadius: 10, borderBottomRightRadius: 10});
            }
        }else{
            progress = 0;
        }
        // animate progress bar
        var current_progress = parseInt($(transfer).find('.jq_progress').text());
        if(isNaN(current_progress) || progress > current_progress){
            $(transfer).find(".jq_transfer_progress").animate({"width":progress+"%"}, self.transfer_fade_speed);
            if(transfer_state!=='queued' && progress < 100){
                $(transfer).find('.jq_progress').html(progress+"%");
            }
        }
    }

    function _show_busy(transfer){
        $(transfer).find('.transfer_control_panel').hide();
        $(transfer).find('.jq_transfer_inner').css('opacity','0.5');
    }

    function show_active(transfer){
        $(transfer).find('.transfer_control_panel').show();
        $(transfer).find('.jq_transfer_inner').css('opacity','1');
    }

    // REPLACE
    function _update_col_status(){
        return
        $("#queued_transfer_overall_status").html("(" + gettext("Showing") + " " + $("#transfer_queued_col").children(":visible").length + ")");
        $("#active_transfer_overall_status").html("(" + gettext("Showing") + " " + $("#transfer_active_col").children(":visible").length + ")");
        $("#completed_transfer_overall_status").html("(" + gettext("Showing") + " " + $("#transfer_completed_col").children(":visible").length + ")");
        _update_total_status();
    }

    //REPLACE
    function _update_total_status(){
        var queued, completed, active;
        queued = self.count_map.queued[self.selected_device.id] == undefined ? 0 : self.count_map.queued[self.selected_device.id];
        active = self.count_map.active[self.selected_device.id] == undefined ? 0 : self.count_map.active[self.selected_device.id];
        completed = self.count_map.completed[self.selected_device.id] == undefined ? 0 : self.count_map.completed[self.selected_device.id];
        $("#transfer_queued_status").text(" (" + gettext("Total") + " " + queued.toString() + ")");
        $("#transfer_active_status").text(" (" + gettext("Total") + " " +  + active.toString() + ")");
        $("#transfer_completed_status").text(" (" + gettext("Total") + " " +  + completed.toString() + ")");
        // warn if over 2000 in the history
        if( completed > 1500 ){
            $("#transfer_completed_status").addClass("transfer_history_warning").attr("title",gettext("Clearing the transfer history will improve the performance of this page."));
        }else{
            $("#transfer_completed_status").removeClass("transfer_history_warning").attr("title",null);
        }
    }
}
