var pack_edit_page = new PackEditPage();

function PackEditPage() {
    var self = this;
    //Templates
    self.main_tmpl = '#pack_edit_main_tmpl';
    self.pack_uuid = undefined;
    self.contents  = [];
    self.pack;
    self.form;
    self.patterns = [];
    self.placeholders;
    self.titles;
    self.mouse_x = 0;
    self.mouse_y = 0;
    self.changes_made = false;
    self.new_pack = false;
    self.original_pack_name;
    self.all_show_attribute_names;  // a list of the names of all configured show attribute

    //Methods
    self.open = function(pack_uuid) {
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load', _close_page);
        $(self.main_tmpl).tmpl().appendTo( $('#main_section').empty() );
        self.pack_uuid = pack_uuid;
        nav_select('content', 'pack');
        var buttons = [];
        if (helpers.is_allowed('tms_schedule_action')){
            buttons = [
                {text:gettext('Save'), image:'save', _class:"jq_save_pack_button", onClick: self.save_pack},
                {text:gettext('Save As'), image:'save', onClick: self.save_pack_as}
            ];
        }

        helpers.set_buttons('#pack_edit_action_buttons', buttons);

        var loading_funcs = [_load_patterns(), _load_placeholders(), _load_show_attributes(), _load_automations()];
        if (self.pack_uuid === undefined) {
            self.pack = new PackObject();
            self.new_pack = true;
        }
        else {
            loading_funcs.push(self._load_pack());
        }
        var loader = new Loader({target: "#main_section"});
        loader.show();
        $.when.apply($, loading_funcs).then(function(){
            $('#pack_edit_content_section').html($('#pack_edit_content_section_tmpl').tmpl());
            $('.pack_edit_content_tab').click(_select_content_tab);
            $('.pack_edit_content_tab:first').click();
            self.draw_pack();
            loader.hide();
            if(screenwriter_plus){
                _load_titles();                
            }
        });

        $('#main_section').on(
            'click.pack_edit',
            '#clear_filter_button',
            function(){
                $('#pack_content_search_input').val("");
                $("#pack_content_search_filter").val("").trigger("change");
            }
        );

        $("#button_0").addClass("disabled");
        _changes_made(false);
    };

    self._load_pack = function() {
        return helpers.ajax_call({
            url:'/tms/get_pack_detailed',
            data: {
                pack_uuid: self.pack_uuid
            },
            success_function:function(input){
                self.pack = new PackObject(input.data);
                self.original_pack_name = self.pack.name;
            }
        });
    };

    self.filter_drag_automation = function(){
        var search_string = $('#pack_content_search_input').val();
        var automation_filter = $('#pack_content_search_filter').val();

        $('.pack_edit_content_body_main > .jq_list_edit_drag_item_wrap').show();

        if (automation_filter !== '' && automation_filter !== undefined){
            $('.pack_edit_content_body_main > .jq_list_edit_drag_item_wrap').each(function(){
                if($(this).find('.screen_title[automation_device="'+automation_filter+'"]').length === 0){
                    $(this).hide();
                }
            });
        }

        if (search_string !== ''){
            $('.pack_edit_content_body_main > .jq_list_edit_drag_item_wrap:not([description*="'+search_string.toLowerCase()+'"])').hide();
        }
    };

    self.scroll_listener = function(){
        if (self.dragging) {
            var pes = $('#pack_edit_pack_section');
            var pes_scroll_top = pes.scrollTop();
            var pes_offset = pes.offset();
            var pes_height = pes.height();
            var move = false;
            if (self.mouse_x > pes_offset.left) {
                if (self.mouse_y -75 < pes_offset.top) {
                    pes_scroll_top -= 15;
                    move = true;
                }
                else if (self.mouse_y + 75 > pes_offset.top + pes_height) {
                    pes_scroll_top += 15;
                    move = true;
                }
                if (move) {
                    pes.scrollTop(pes_scroll_top);
                    //we'd love to put a pretend drag event in here... i've tried a few things below to make it happen but that didnt work out
                    //$('.playlist_edit_playlist_container').sortable('refreshPositions');
                    //$('.draggable_clone').trigger(self.mouse_event);
                }
            }
            setTimeout(self.scroll_listener,1000/30);
        }
    };

    function _load_titles() {
        return helpers.ajax_call({url:'/core/title/title', success_function:_update_titles});
    }

    function _update_titles(input) {
        self.titles = input.data;
        self.draw_pack();
    }

    function _load_contents() {
        return helpers.ajax_call({
            url:'/core/paginated/get_datatables_content',
            loader: {target: ".pack_edit_content_body_main", caption: gettext("Loading")},
            data: {
                iDisplayStart: 0,
                iDisplayLength: 50,
                sSearch: $('#pack_content_search_input').val(),
                type_filter: $('#pack_content_search_filter').val(),
                iSortingCols: 2,
                iSortCol_0: 7,
                iSortCol_1: 8,
                sSortDir_0: 'asc',
                sSortDir_1: 'asc',
                show_kdms: false,
                servers_only: true
            },
            success_function: function(input){
                _update_contents(input);
            }
        });
    }

    function _load_automations() {
        return helpers.ajax_call({url:'/core/automation/cues', success_function:_update_automations});
    }

    function _load_patterns() {
        return helpers.ajax_call({ data:{},url:'/core/content/pattern', success_function:_update_patterns});
    }

    function _update_patterns(data) {
        self.patterns = [];
        for(var pattern in data.data){
            if (data.data[pattern]['type'] === 'pattern'){
                delete data.data[pattern]['duration_in_frames'];
                self.patterns.push(data.data[pattern]);
            }
        }
    }

    function _load_placeholders() {
        return helpers.ajax_call({data:{sorted_list:true}, url:'/core/placeholder/placeholders', success_function:_update_placeholders});
    }

    function _update_placeholders(input) {
        self.placeholders = input.data;
    }

    function _load_show_attributes() {
        // retrieves a list of the names of all show attributes on the tms
        return helpers.ajax_call({url:'/core/configuration/show_attribute', success_function:_update_show_attributes});
    }

    function _update_show_attributes(input) {
        self.show_attributes = input.data;
    }

    function _select_content_tab(event){
        var tab_value = $(this).attr('tab_value');
        $(this).addClass('selected').siblings().removeClass('selected');
        if (tab_value === 'content'){
            $('.pack_edit_content_body_search').html($('#pack_edit_content_search_tmpl').tmpl());
            $('#pack_content_search_filter').change(_load_contents);
            $('#pack_content_search_input').searcher(_load_contents);
            _load_contents();
        }
        else if (tab_value === 'automation'){
            $('.pack_edit_content_body_search').html($('#pack_edit_automation_search_tmpl').tmpl());
            $('#pack_content_search_filter').change(self.filter_drag_automation);
            $('#pack_content_search_input').searcher(self.filter_drag_automation);
            draw_automation_list();
        }
        else if (tab_value === 'pattern'){
            $('.pack_edit_content_body_search').html($('#pack_edit_pattern_search_tmpl').tmpl());
            $('#pack_content_search_input').searcher(update_pattern_list);
            draw_pattern_list();
        }
    }

    function _update_contents(input) {
        self.contents = input.aaData;
        var i, cpl, translated_playback_mode, translated_subtitled, draggable, drag_list;
        drag_list = [];

        for (i=0; i<self.contents.length; i++) {
            cpl = self.contents[i];
            cpl.type = 'composition';
            draggable = {};
            draggable.content_kind  = cpl.content_kind;
            if (cpl.edit_rate){
                draggable.edit_rate = cpl.edit_rate;
            }
            draggable.encrypted     = cpl.encrypted;
            switch(cpl.playback_mode) {
                case '2D': translated_playback_mode = false; break;
                case '3D': translated_playback_mode = 'icon-three-d'; break;
            }
            if (translated_playback_mode){
                draggable.playback_mode = translated_playback_mode;
            }
            switch(cpl.subtitled) {
                case true: translated_subtitled = cpl.subtitle_language || 'XSUB'; break;
                case undefined, false: translated_subtitled = false;
            }

            if (translated_subtitled) {
                draggable.subtitled = translated_subtitled;
            }
            draggable.description = cpl.content_title_text; //text display
            draggable.cpl_uuid = cpl.uuid;
            draggable.duration_in_seconds = cpl.duration_in_seconds;
            drag_list.push(draggable);
        }
        drag_list.sort(function(a,b){
            try{
                var value = a.content_kind.toLowerCase().localeCompare(b.content_kind.toLowerCase());
                if (value == 0) {
                    return a.description.toLowerCase().localeCompare(b.description.toLowerCase());
                }
                else {
                    return value;
                }
            }catch(err){
            }
        });

        $('.pack_edit_content_body_main').html($('#content_drag_list_item_tmpl').tmpl({'drag_list':drag_list}));

        $('.pack_edit_content_body_main > div').draggable({
            helper : function(){return $(this).clone().css({'width': $(this).width()});},
            containment : '#main_section',
            connectToSortable :'.pack_edit_pack_container',
            appendTo :'#main_section',
            tolerance :'intersect',
            start :function(){
                $('#pack_edit_pack_section').addClass("drop_enabled");
                pack_edit_page.dragging = true;
                pack_edit_page.scroll_listener();
            },
            stop :function(){
                $('#pack_edit_pack_section').removeClass("drop_enabled");
                pack_edit_page.dragging = false;
            },
            drag: function(event, ui) {
                pack_edit_page.mouse_x = event.pageX;
                pack_edit_page.mouse_y = event.pageY;
            }
        });
        attach_double_click();
        if(input.iTotalDisplayRecords > drag_list.length){
            $('.pack_edit_content_body_main').append($('#playlist_edit_pack_filtered_info_tmpl').tmpl({'total': input.iTotalDisplayRecords, 'showing': drag_list.length}));
        }
    }

    function draw_automation_list(){
        var draggable, drag_list;
        drag_list = [];

        for (var device_id in self.automation) {
            for (var automation_id in self.automation[device_id]) {
                draggable = {};
                draggable.id = automation_id;
                draggable.name = self.automation[device_id][automation_id].name;
                draggable.automation_type = self.automation[device_id][automation_id].type;

                if(self.automation[device_id][automation_id].devices){
                    draggable.devices = self.automation[device_id][automation_id].devices;
                }

                draggable.is_intermission = false;
                draggable.is_show_start = false;

                if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name]) {
                    if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name].show_start) {
                        draggable.is_show_start = true;
                    }
                    if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name].intermission) {
                        draggable.is_intermission = true;
                    }
                }
                drag_list.push(draggable);
            }
        }
        drag_list.sort(function(a,b){
            var value = 1;
            if (a.automation_type.name < b.automation_type.name) {
                        value = -1;
                    }
                    else if (a.automation_type.name > b.automation_type.name) {
                        value = 1;
                    }
                    else if (a.name < b.name) {
                        value = -1;
                    }
                    return value;
        });

        $('#automation_drag_list_tmpl').tmpl2({drag_list: drag_list}, '.pack_edit_content_body_main');

        $('.pack_edit_content_body_main > div').draggable({
            helper : function(){return $(this).clone().css({'width': $(this).width()});},
            containment : '#main_section',
            appendTo :'#main_section',
            tolerance :'intersect',
            start :function(){
                pack_edit_page.dragging = true;
                pack_edit_page.scroll_listener();
            },
            stop :function(){
                pack_edit_page.dragging = false;
            },
            drag: function(event, ui) {
                pack_edit_page.mouse_x = event.pageX;
                pack_edit_page.mouse_y = event.pageY;
            }
        });
    }

    function _update_automations(input){
        self.automation = {aamlms: spo.merge_device_automations(input.data)};
    }

    function draw_pattern_list(){
        var drag_list = [];
        drag_list = self.patterns.slice(0);

        $('.pack_edit_content_body_main').html($('#pack_edit_pattern_drag_list_tmpl').tmpl({drag_list : drag_list}));

        $('.pack_edit_content_body_main > div').draggable({
            helper : function(){return $(this).clone().css({'width': $(this).width()});},
            containment : '#main_section',
            connectToSortable :'.pack_edit_pack_container',
            appendTo :'#main_section',
            tolerance :'intersect',
            start :function(){
                $('#pack_edit_pack_section').addClass("drop_enabled");
                pack_edit_page.dragging = true;
                pack_edit_page.scroll_listener();
            },
            stop :function(){
                $('#pack_edit_pack_section').removeClass("drop_enabled");
                pack_edit_page.dragging = false;
            },
            drag: function(event, ui) {
                pack_edit_page.mouse_x = event.pageX;
                pack_edit_page.mouse_y = event.pageY;
            }
        });
    }
    
    function update_pattern_list() {
        draglist_filter('.pack_edit_content_body_main', '#pack_content_search_input');
    }
    
    function draglist_filter(list_body, search_box) {
        var draglist = $(list_body).children('.jq_list_edit_drag_item_wrap');

        //        var search_dom = args.search_dom
        var search_string = ($(search_box).val() || '').toLowerCase();
        if(search_string.length > 1) {
            var search_list = search_string.split(' ');
            draglist.each(function() {
                var $drag_item = $(this);
                var reveal = true;
                var description = ($drag_item.attr("description") || '').toLowerCase();
                for (var i in search_list) {
                    if (description.indexOf(search_list[i]) === -1) {
                        reveal = false;
                        break;
                    }
                }
                $drag_item.toggle(reveal);
            });
        } else {
            draglist.show();
        }
    }

    function attach_double_click(){
        $('.pack_edit_content_body_main > div').dblclick(function(){
            add_pack_clip($(this), self.pack.clips.length);
            self.draw_pack();
            _changes_made();
        });
    }

    self.save_pack_as = function(){
        new SaveDialog({
            "save_function": _save_as,
            "text": self.pack.name
        }).open();
    };

    _save_as = function(title){
        self.pack.name = title;
        self.original_pack_name = ''; //forces duplicate name check
        self.pack.uuid = undefined;
        _save_pack(self.pack.return_saveable(), false);
    };

    self.save_pack = function(){
        if ($(this).button("option","disabled")){
            notification.info_msg(gettext('There are no changes'));
            return;
        }
        if(self.pack.issuer != null && self.pack.issuer !== "TMS"){
            alert(gettext('This pack is from an external source. Your changes may be overwritten if the pack is sent from that source again'));
        }
        _save_pack(self.pack.return_saveable(), !self.new_pack);
    };

    function _save_pack(pack, dont_validate){
         if (self.form.checkForm()) {
            helpers.ajax_call({
                url: '/core/pack/pack_name_exists',
                data: {'pack_name':pack.name},
                success_function:function(exists){
                    if( (self.original_pack_name === self.pack.name) || (!exists.data || dont_validate) || confirm(gettext("A pack with this name already exists. Are you sure you want to create another one?")) ){
                        self.new_pack = false;
                        helpers.ajax_call({
                            url: '/core/pack/save',
                            data:{
                                'packs':[pack]
                            },
                            success_function: function(input) {
                                if(input.messages.length > 0 && input.messages[0].uuid != undefined) {
                                    _changes_made(false);
                                    dialog.close();
                                    history.pushState(null, null, '#pack_page');
                                    pack_page.open();
                                }
                            }
                        });
                    }
                }
            });
        }
        else {
            notification.info_msg(gettext('Complete all required fields'));
            self.form.showErrors();
        }
    }

    self.draw_pack = function() {
        self.pack.calculate_start_times();

        $('#pack_edit_info_section').html($('#pack_info_tmpl').tmpl({
            'pack':self.pack,
            'placeholders' : self.placeholders,
            'titles':self.titles
        }));

        $('.pack_info.read_only input').attr("disabled", "disabled").attr("placeholder", "");
        $('.pack_info.read_only .ui-button').css("display", "none");

        helpers.attach_suggestion_tip({
            'dom': $('#pack_edit_title'),
            'items': self.titles,
            'text_field': "name",
            'change': function(title_uuid){
                self.pack.title_uuid = title_uuid;
                if(self.pack.title_uuid){
                    self.pack.title_name = self.titles[self.pack['title_uuid']]['name'];
                }
                else{
                    self.pack.title_name = null;
                }
                _changes_made();
            }
        });

        if(self.pack && self.pack.title_uuid && self.titles){
            if(self.titles[self.pack['title_uuid']] != undefined){
                $("#pack_edit_title").val(self.titles[self.pack['title_uuid']]['name']);
            }
        }
        $('#pack_edit_pack_section').html($('#pack_edit_pack_tmpl').tmpl({
            'pack':self.pack
        }));

        $('#pack_edit_name').on('enter.pack_edit', self.save_pack);

        /*
            set up the sortable jquery ui for the playlist
            this takes care of:
                Content fields being added
                Packs being added
                The playlist itself being sortable
        */
        $('.pack_edit_pack_container').sortable({
            start: function(event,ui) {
                //set temp_move_index so we know where we are moving from
                self.temp_move_index = $('.pack_edit_pack_container > div').index(ui.item);
            },
            update: function(event, ui) {
                var moved_event, target_position;
                if (self.temp_move_index == -2) {
                    return;
                }
                target_position = $('.pack_edit_pack_container > *').index(ui.item);

                if (self.temp_move_index !== -1) {
                    moved_event = self.pack.clips.splice(self.temp_move_index,1)[0];
                    self.pack.clips.splice(target_position, 0, moved_event);
                }
                else {
                    add_pack_clip(ui.item, target_position);
                }
            },
            receive: function(event, ui) {
                self.temp_move_index = -1;
            },
            stop: function(event, ui) {
                self.draw_pack();
                update_pack_info(true);
                _changes_made();
            },
            helper:'clone',
            appendTo:'.pack_edit_pack_container',
            containment:'.pack_edit_pack_container',
            tolerance:'pointer'
        });

        /*
            setup the droppable fields on each pack element
            this takes care of all automation that gets added directly to content fields
        */
        $('.pack_edit_pack_element_wrap').droppable({
            activeClass : 'drop_enabled',
            hoverClass : 'drop_hover',
            tolerance : 'intersect',
            accept : function($draggable) {
                var $droppable = $(this);
                if ($draggable.attr('type') !== 'automation') {
                    return false;
                }
                else if ($draggable.attr('automation_id') === 'GDC-START-CUE' && $droppable.data('has_gdc_start_cue')) {
                    return false;
                }
                else {
                    return true;
                }
            },
            drop:function(event, ui){
                var automation_id = ui.helper.attr('automation_id');
                var automation = spo.find_automation(self.automation, automation_id);

                var data = {
                    'automation': automation,
                    'automation_id': automation_id,
                    'target_event_id': $(this).index(),
                    'hours':0,
                    'minutes':0,
                    'seconds':0
                };

                spo.automation_dialog(data, gettext('Add Automation'), function() {
                    _save_automation();
                });
            }
        });

        $('.image.delete.content_attributes').click(_remove_from_pack);
        self.form = $('#pack_info_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            },
            highlight: function(element){
                $(element).addClass("error");
            },
            unhighlight: function(element){
                $(element).removeClass("error");
            }
        });

        $('.image.delete.automation_attributes').click(_remove_from_event);
        $('.image.edit.automation_attributes').click(_edit_automation);
        $('.image.edit.content_attributes').click(_edit_pattern);

        var current = [];
        for (var i = 0, len = self.pack.external_show_attribute_maps.length; i < len; i++) {
            var uuid = self.pack.external_show_attribute_maps[i].show_attribute_uuid;

            if(uuid != null){
                current[uuid] = true;
            }
        }
        var attribute_selector = new ShowAttributeSelector({
            dom: $('#pack_show_attributes'),
            current: current,
            show_attributes: self.show_attributes,
            read_only: !screenwriter_plus,
            click: function(){
                update_pack_info();
            }
        });

        var selected = Object.keys(self.pack.screens).length ? Object.keys(self.pack.screens) : "all";
        self.screen_selector = new ScreenSelector({
            all: true,
            dom: "#pack_screen_selector",
            selected: selected,
            change: function(){
                update_pack_info();
            }
        });

        $('.screen_btn').button().click(function(){
            if($(this).val() === "all"){
                $('.screen_btn').attr("checked", false).button("refresh");
                $(this).attr("checked", true).button("refresh");
            }else{
                $('.screen_btn[value=all]').attr("checked", false).button("refresh");
            }
            update_pack_info();
        });

        var update_pack_info = function(){
            // if the pack name was changed then treat this as a "save as" and validate the pack title against existing ones
            if(self.pack.name != $.val_or_undefined($('#pack_edit_name').val())){
                self.new_pack = true;
            }

            // pack attributes
            self.pack.name = $.val_or_undefined($('#pack_edit_name').val());
            self.pack.placeholder_uuid = $.val_or_undefined($('#pack_edit_pack_type_select').val());
            self.pack.title_uuid = $.val_or_undefined($('#pack_edit_title').attr("data-item_uuid"));
            self.pack.date_from = $.val_or_undefined($('#pack_edit_date_from').val());
            self.pack.date_to = $.val_or_undefined($('#pack_edit_date_to').val());
            self.pack.time_from = $.val_or_undefined($('#pack_edit_time_from').val());
            self.pack.time_to = $.val_or_undefined($('#pack_edit_time_to').val());
            self.pack.print_no = $.val_or_undefined($('#pack_edit_print_number').val());
            self.pack.priority = $.val_or_undefined($('#pack_edit_priority').val());
            self.pack.screen_type_uuid = $.val_or_undefined($('#pack_edit_screen_type_select').val());
            self.pack.show_type_uuid = $.val_or_undefined($('#pack_edit_show_type_select').val());
            self.pack.screens = {};

            var screens = self.screen_selector.get_selected();
            for(var i in screens){
                if(screens[i] === "all"){
                    break;
                }
                self.pack.screens[screens[i]] = true;
            }

            // external show attribute maps
            var ex_sams = [];
            var aam_ex_sam = null;

            // Add the selected (matched) show attributes
            //  - actually, adding the aam external show attribute map uuid of the selected show attributes
            $('#pack_show_attributes .show_attribute.selected').each(function(i, dom){
                var sa_uuid = $(dom).attr("data-uuid");
                aam_ex_sam = get_aam_ex_sam(self.show_attributes[sa_uuid]['external_show_attribute_maps']);
                if (aam_ex_sam) {
                    ex_sams.push({
                        "source": "aam",
                        "external_id": aam_ex_sam['external_id'],
                        "show_attribute_uuid": sa_uuid
                    });
                }
            });

            // Add the unmatched show attributes -   hidden/ can't be modified
            $('#pack_unknown_show_attributes .pack_show_attribute').each(
                function(i, dom){
                    var source = $(dom).attr("data-show_attribute_id");
                    var external_id = $(dom).attr("value");
                    ex_sams.push({
                                          'source':source,
                                          'external_id': external_id,
                                          "show_attribute_uuid": null
                                        });
            });
            self.pack.external_show_attribute_maps = ex_sams;

            _changes_made();
        };   // update_pack_info

        $('#pack_info_form').on('change keyup', function(){
            update_pack_info();
        });

        $('#pack_info_form .jq_date_select').datepicker({
            showAnim: 'slideDown',
            dateFormat:"yy-mm-dd",
            altFormat:"yy-mm-dd",
            minDate: new Date(),
            onSelect: function(date, obj){
                var id = $(this).attr("id");
                var date = $(this).datepicker("getDate");
                if(id === "pack_edit_date_from"){
                    $('#pack_edit_date_to').datepicker("option", "minDate", date);
                }
                else{
                    $('#pack_edit_date_from').datepicker("option", "maxDate", date);
                }
                update_pack_info();
            }
        });

        $('#pack_info_form .jq_time_select').each(function(){
            helpers.attach_time_tip($(this));
        });

        $('#time_clear').click(function(){
            $('.jq_time_select').val("");
            self.pack.time_to = undefined;
            self.pack.time_from = undefined;
            _changes_made();
        });

        $('#date_clear').click(function(){
            $('.jq_date_select').val("");
            self.pack.date_from = undefined;
            self.pack.date_to = undefined;
            $('#pack_edit_date_to').datepicker("option", "minDate", null);
            $('#pack_edit_date_from').datepicker("option", "maxDate", null);
            _changes_made();
        });

        $('#title_clear').click(function(){
            var title_field = $('#pack_edit_title');
            title_field.val("");
            title_field.attr('data-item_uuid', "");
            self.pack.title_uuid = null;
            self.pack.title_name = null;
            _changes_made();
        });
        
       title_edit_page.set_up_ratings(self.pack.ratings, _changes_made);

        helpers.hide_loader();
    };

    function get_aam_ex_sam(external_show_attribute_maps){
        for (var item in external_show_attribute_maps) {

            if (external_show_attribute_maps[item]['source'] === 'aam') {
                return external_show_attribute_maps[item];
            }
        }
        return null;
    }
    function add_pack_clip(ui_item, target_position){
        var itemtype = $(ui_item).attr('type');
        switch(itemtype){
        case 'content':
            var cpl_uuid = $(ui_item).attr('cpl_uuid');
            var clip = $.grep(self.contents, function(a){
                return a.uuid == cpl_uuid;
            })[0];
            self.pack.add_clip(clip, target_position);
            break;
        case 'pattern':
            var attrs = $(ui_item).attr_dict(['duration_in_seconds', 'description', 'pattern_id']);
            if(attrs['duration_in_seconds'] == ''){
                var template_data = {};
                template_data.target_position = target_position;
                template_data.description = attrs['description'];
                template_data.edit_pattern_position = null;
                template_data.pattern_id = attrs['pattern_id'];
                spo.pattern_dialog(template_data, gettext('Edit'), on_pattern_dialog_output);
            }
            else{
                var pattern = $.extend(true, {},self.patterns[attrs['pattern_id']]);
                pattern['text'] = pattern['description'];
                pattern['duration_in_seconds'] = attrs['duration_in_seconds'];
                self.pack.add_clip(pattern, target_position);
            }
            break;
        }

    }

    function _edit_pattern() {
        var template_data = {};
        var edit_index = $(this).closest('.pack_edit_pack_element_wrap').index();
        template_data.target_position = undefined;
        template_data.description = self.pack.clips[edit_index].title;
        template_data.edit_pattern_position = edit_index;

        var hms_settings = {};
        var tmp = parseInt(self.pack.clips[edit_index].duration_in_seconds,10);

        hms_settings.seconds  = tmp % 60;
        tmp  = parseInt(tmp / 60,10);
        hms_settings.minutes  = tmp % 60;
        tmp  = parseInt(tmp / 60,10);
        hms_settings.hours  = tmp;

        spo.pattern_dialog(template_data, gettext('Edit'), on_pattern_dialog_output, hms_settings);
    }

    function on_pattern_dialog_output(){
        var hours, minutes, seconds;
        var errors = [];
        var ok = true;
        var edit_position = $("#edit_pattern_position").val();
        var description = $("#add_pattern_description").val();
        var target_position = $("#add_pattern_target_position").val();
        var pattern_id = $("#pattern_id").val();
        var duration = $("#pattern_duration").hms("retrieve");

        if(duration == 0){
            ok = false;
            errors.push(gettext('Duration must not be zero'));
        }

        if (edit_position !== '') {
            var current_pattern_automations = self.pack.clips[edit_position].automation || [];
            $.each(current_pattern_automations, function(index, automation){
                if(duration < automation.type_specific.offset_in_seconds){
                    ok = false;
                    errors.push(gettext("The Duration of a Pattern must be more than the start times of its automations"));
                }
            });
        }

        if(!ok){
            $('#validation_error_tmpl').tmpl({'errors':errors}).appendTo($('.validation').empty());
        }else{
            if (edit_position !== '') {
                var tmp = self.pack.clips[edit_position];
                tmp.duration_in_seconds = duration;
                tmp.duration_in_frames = tmp.edit_rate != undefined ? (tmp.duration_in_seconds * tmp.edit_rate[0] / tmp.edit_rate[1]) : null;                
            }
            else {
                var pattern = $.extend(true, {},self.patterns[pattern_id]);
                pattern['text'] = pattern['description'];
                pattern['duration_in_seconds'] = duration;
                self.pack.add_clip(pattern, target_position);
            }
            self.draw_pack();
            _changes_made(true);
            dialog.close();
        }
    }

    function _changes_made(bool){
        bool = typeof bool != 'undefined' ? bool : true;
        self.changes_made = bool;
        g_prevent_navigation = bool;
        $('.jq_save_pack_button').button("option","disabled",!bool);
    }

    function _remove_from_pack() {
        self.pack.clips.splice($(this).closest('.pack_edit_pack_element_wrap').index(), 1);
        _changes_made(true);
        self.draw_pack();
    }

    function _remove_from_event() {
        self.pack.clips[$(this).closest('.pack_edit_pack_element_wrap').index()].automation.splice($(this).closest('.playlist_event_cue_wrapper').index()-1, 1);
        _changes_made();
        self.draw_pack();
    }

    function _edit_automation() {
        var element_index, automation_index, automation;

        element_index = $(this).closest('.pack_edit_pack_element_wrap').index();
        automation_index = $(this).closest('.playlist_event_cue_wrapper').index()-1;
        automation = self.pack.clips[element_index].automation[automation_index];

        var data = {
            'automation': automation,
            'target_event_id': element_index,
            'edit_automation_index': automation_index
        };

        var time_param = automation.type_specific.offset_in_seconds || automation.type_specific.wait_duration;
        if (time_param) {
            var seconds, minutes, hours;
            var tmp = automation.type_specific.offset_in_seconds;
            tmp = parseInt(tmp,10);
            seconds  = tmp % 60;
            tmp  = parseInt(tmp / 60,10);
            minutes  = tmp % 60;
            tmp  = parseInt(tmp / 60,10);
            hours  = tmp;
            data['seconds'] = seconds;
            data['minutes'] = minutes;
            data['hours']   = hours;
        }

        var hms_settings = {
            seconds: data['seconds'],
            minutes: data['minutes'],
            hours: data['hours']
        };

        spo.automation_dialog(data, gettext('Edit'), function() {
            _save_automation();
        }, hms_settings);
    }

    function _save_automation(){
        var event_drop_target;

        var target_event_id = $('#target_event_id').val();
        event_drop_target = self.pack.clips[target_event_id];

        spo.save_automation_dialog_input(event_drop_target, self.automation, null, function(){
            dialog.close();
            _changes_made();
            self.draw_pack();
        });
    }

    function _close_page() {
        $(document).off('page_load');
        self.contents = [];
        self.automation = {};
    }

}
