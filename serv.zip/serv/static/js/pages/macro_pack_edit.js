var macro_pack_edit_page = new MacroPackEditPage();

function MacroPackEditPage() {
    var self = this;
    self.macro_pack_uuid = undefined;

    self.macro_pack;
    self.device_uuid;
    self.macro_placeholder_uuid;

    self.macro_placeholders;
    self.contents;
    self.automation;
    self.mouse_x = 0;
    self.mouse_y = 0;

    self.load_max = 100;

    self.drag_list = null;

    //Methods
    self.open = function(device_uuid, macro_placeholder_uuid, macro_pack_uuid) {
        var doc;
        doc = $(document);
        doc.trigger('page_load');
        doc.one('page_load.macro_pack_edit', _close_page);
        self.automation = {};

        $('#main_section').html($('#macro_pack_edit_main_tmpl').tmpl());

        self.macro_placeholder_uuid = macro_placeholder_uuid;
        self.macro_pack_uuid = macro_pack_uuid;
        self.device_uuid = device_uuid;

        nav_select('config', 'macro_pack');

        var content_tabs = [];
        content_tabs.push({'tab_value':'content', 'tab_translated_title': gettext('Content')});
        if (helpers.supported('playlist_pattern',$device_store.devices[self.device_uuid].type)) {
            content_tabs.push({'tab_value':'pattern', 'tab_translated_title': gettext('Pattern')});
        }
        content_tabs.push({'tab_value':'automation', 'tab_translated_title': gettext('Automation')});

        $('#macro_pack_edit_content_section').html($('#macro_pack_edit_content_section_tmpl').tmpl({
            'content_tabs': content_tabs
        }));

        self.drag_list = new DragList({
            search_dom: ".macro_pack_edit_content_body_search",
            search_input: "#search_input",
            list_dom: ".macro_pack_edit_content_body_main",
            device_id: device_uuid,
            draggable_defaults: draggable_defaults
        });
        self.automation_load = load_automation();
        self.pattern_load = load_patterns();

        $.when(load_macro_placeholders()).done(load_macro_pack);
        _changes_made(false);
    };

    function load_patterns(){
        return helpers.ajax_call({
            url: '/core/content/pattern',
            success_function: function(data){
                self.patterns = [];
                for(var item in data.data){
                    if (data.data[item].type === 'pattern'){
                        self.patterns.push(data.data[item]);
                    }
                }
            }
        });
    }

    function scroll_listener(){
        if (self.dragging) {
            var pes = $('#macro_pack_edit_macro_pack_section');
            var pes_scroll_top = pes.scrollTop();
            var pes_offset = pes.offset();
            var pes_height = pes.height();
            var move = false;
            if(self.mouse_x > pes_offset.left){
                if (self.mouse_y -75 < pes_offset.top){
                    pes_scroll_top -= 15;
                    move = true;
                }
                else if(self.mouse_y + 75 > pes_offset.top + pes_height){
                    pes_scroll_top += 15;
                    move = true;
                }
                if(move){
                    pes.scrollTop(pes_scroll_top);
                }
            }
            setTimeout(scroll_listener,1000/30);
        }
    }

    function load_macro_pack() {
        if(self.macro_pack_uuid){
            helpers.ajax_call({
                url: '/tms/get_macro_pack_detailed',
                data: {
                    macro_pack_uuid: self.macro_pack_uuid
                },
                success_function: function(input){
                    self.macro_pack = new MacroPackObject(input.data);
                    draw_macro_pack();
                }
            });
        }
        else{
            self.macro_pack = new MacroPackObject({
                device_uuid: self.device_uuid,
                has_content: true,
                macro_placeholder_uuid: self.macro_placeholder_uuid
            });
            draw_macro_pack();
        }
    }

    function draw_macro_pack() {
        $('.macro_pack_edit_content_tab').click(select_content_tab);
        if(!self.macro_placeholders[self.macro_placeholder_uuid]['has_content']){
            $('.macro_pack_edit_content_tab[tab_value!="automation"]').remove();
            if(self.macro_pack.event_list.length === 0){
                self.macro_pack.event_list.push(new MacroPlacementEvent());
            }
        }
        $('.macro_pack_edit_content_tab:first-child').click();

        redraw_macro_pack();
        $('#macro_pack_edit_info_section').html($('#macro_pack_info_tmpl').tmpl({
            macro_placeholder_name : self.macro_placeholders[self.macro_placeholder_uuid].name,
            macro_device_name : helpers.get_device_name(self.device_uuid)
        }));
        self.button_text = gettext('Save');
        helpers.set_buttons('#macro_pack_edit_action_buttons', [{
                text: self.button_text,
                image:'save',
                onClick: save_macro_pack
            }]
        );
    }

    function load_automation(){
        return helpers.ajax_call({
            url: '/core/automation/cues',
            data: {
                device_ids: [self.device_uuid]
            },
            success_function: function(input){
                delete input.data.message;
                self.automation = input.data;
            }
        });
    }

    function load_macro_placeholders() {
        return helpers.ajax_call({
            url: '/core/macro_pack/macro_placeholders',
            success_function: function(input){
                self.macro_placeholders = input.data;
            }
        });
    }

    function select_content_tab(mouse_event) {
        var tab_value = $(this).attr('tab_value');
        $(this).addClass('selected').siblings().removeClass('selected');

        switch(tab_value) {
            case 'content':
                draw_content_tab();
                break;

            case 'pattern':
                $.when(self.pattern_load).done(function(){
                    var drag_list = self.patterns.slice(0);
                    self.drag_list.draw({
                        main_template: '#playlist_edit_pattern_drag_list_tmpl',
                        drag_list: drag_list
                    });
                });
                break;

            case 'automation':
                $.when(self.automation_load).done(function(){
                    draw_automations_tab();
                });
                break;

            default:
                $('.macro_pack_edit_content_body_main').empty();
                $('.macro_pack_edit_content_body_search').empty();
        }
    }

    function draw_automations_tab(){
        var drag_list = [];
        for (var device_id in self.automation) {
            for (var automation_id in self.automation[device_id]) {
                if (self.automation[device_id][automation_id].type === 'trigger')
                    continue;
                var draggable = {};
                draggable.id = automation_id;
                draggable.name = self.automation[device_id][automation_id].name;
                draggable.automation_type = self.automation[device_id][automation_id].type;
                draggable.is_intermission = false;
                draggable.is_show_start = false;
                if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name] !== undefined) {
                    if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name].show_start) {
                        draggable.is_show_start  = true;
                    }
                    if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name].intermission) {
                        draggable.is_intermission  = true;
                    }
                    if (AUTOMATION_CONFIGURATION.automation_configuration[draggable.name].credits) {
                        draggable.is_credits  = true;
                    }
                }
                drag_list.push(draggable);
            }
        }

        self.drag_list.draw({
            main_template_hb: '#automation_drag_list_tmpl',
            search_template: '#macro_pack_edit_automation_search_tmpl',
            drag_list: drag_list,
            drag_params: {
                helper : function(){
                    return $(this).clone().css({
                        'width': $(this).width(),
                        'margin':0
                    }).addClass('automation');
                },
                appendTo:'#main_section',
                tolerance:'intersect',
                refreshPositions: true,
                drag: drag_function,
                start: function(){
                    macro_pack_edit_page.dragging = true;
                    scroll_listener();
                },
                stop: stop_function
            },
            sort_func: function(a,b){
                var value = 1;
                if (a.automation_type.name < b.automation_type.name){
                    value = -1;
                }
                else if (a.automation_type.name > b.automation_type.name){
                    value = 1;
                }
                else if (a.name < b.name) {
                    value = -1;
                }
                return value;
            },
            filter_func: self.filter_drag_automation
        });
        $('#macro_edit_automation_search_input').keyup(filter_drag_automation);

    }

    function double_click(){
        var ui_attributes = $(this).attr_dict(['cpl_uuid', 'type', 'uuid', 'description', 'duration_in_seconds', 'pack_uuid']);
        alter_rendered_playlist(ui_attributes, self.playlist.events.length);
        self.draw_playlist();
        self.changes_made(true);
    }

    function load_tab(getter, callback){
        var loader = new Loader({target: $(".macro_pack_edit_content_body")});
        loader.show(function(){
            getter(function(){
                callback();
                loader.hide();
            });
        });
    }

    function get_contents(callback){
        var type_filter = 'transitional';
        var filter_dom = $('#playlist_content_search_filter');
        if(filter_dom.length){
            type_filter = filter_dom.val();
        }
        helpers.ajax_call({
            url: '/core/paginated/get_draglist_content',
            data: {
                iDisplayLength: self.load_max,
                sSearch: $('#search_input').val(),
                type_filter: type_filter,
                device_uuid: self.device_uuid
            },
            success_function: function(data){
                for (var i=0; i<data.aaData.length; i++) {
                    data.aaData[i].validation = data.aaData[i].devices[self.device_uuid];
                    delete data.aaData[i].devices;
                }
                self.contents = data.aaData;
                self.contents_count = data.iTotalDisplayRecords;
                callback();
            }
        });
    }

    function draw_content_tab(){
        $('.playlist_search_filter').val("");

        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.draw({
                main_template: '#playlist_edit_content_drag_list_tmpl',
                search_template: '#playlist_edit_content_search_tmpl',
                drag_list: drag_list,
                filter_func: update_content_tab,
                double_click_func: double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });
            var filter_dom = $('#playlist_content_search_filter');
            filter_dom.find("option[value='transitional']").prop("selected", true);
            filter_dom.on('change', update_content_tab);
        });
    }

    function update_content_tab(){
        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.update({
                main_template: '#playlist_edit_content_drag_list_tmpl',
                drag_list: drag_list,
                double_click_func: double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });
        });
    }

    function gen_content_list(){
        var drag_list = [];
        for (var index = 0; index < self.contents.length; index++) {
            var content = self.contents[index];
            if (content.validation.validation_code == 4)
                continue;
            if (content.validation.error_messages === undefined){
                var draggable = $.extend(true, content, {});

                //draggable.playback_mode = (content.playback_mode === '3D') ? 'icon-three-d' : 'icon-two-d';
                draggable.subtitled = content.subtitled ? content.subtitle_language || 'XSUB' : false;
                draggable.description = content.content_title_text;
                draggable.cpl_uuid = content.uuid;
                drag_list.push(draggable);
            }
        }
        return drag_list;
    }

    /* DRAG LIST DRAWINING */

    $('.macro_pack_edit_content_body_main > .jq_draggable').draggable(draggable_defaults);

    var draggable_defaults = {
        helper: draggable_helper,
        cursorAt: {
            top: 2
        },
        containment : '#main_section',
        connectToSortable :'.macro_pack_edit_macro_pack_container',
        appendTo :'#main_section',
        tolerance :'intersect',
        drag: drag_function,
        start: start_function,
        stop: stop_function
    };

    function draggable_helper(){
        return $(this).clone().css({
            'width': $(this).width(),
            'margin': 0
        });
    }

    function drag_function(event, ui){
        macro_pack_edit_page.mouse_x = event.pageX;
        macro_pack_edit_page.mouse_y = event.pageY;
    }

    function start_function(event, ui){
        $('#macro_pack_edit_macro_pack_section').addClass("drop_enabled");
        macro_pack_edit_page.dragging = true;
        scroll_listener();
    }

    function stop_function(event, ui){
        $('#macro_pack_edit_macro_pack_section').removeClass("drop_enabled");
        macro_pack_edit_page.dragging = false;
    }

    function filter_drag_automation(){
        var search_string = $('#macro_edit_automation_search_input').val();
        $('.macro_pack_edit_content_body_main > .jq_list_edit_drag_item_wrap').show();

        if (search_string !== '') {
            $('.macro_pack_edit_content_body_main > .jq_list_edit_drag_item_wrap:not([description*="'+search_string.toLowerCase()+'"])').hide();
        }
    }

    function save_macro_pack() {
        helpers.ajax_call({
            url: '/core/macro_pack/save',
            data: {
                'macro_packs':[self.macro_pack.return_saveable()]
            },
            success_function: saved
        });
        _changes_made(false);
    }

    function saved(input) {
        _changes_made(false);
        history.pushState(null, null, '#macro_pack_page');
        macro_pack_page.open();
    }

    function redraw_macro_pack(){
        var container = $('#macro_pack_edit_macro_pack_section');

        self.macro_pack.calculate_start_times();
        var event_list = new EventList({
            list: self.macro_pack.event_list,
            dom: container,
            tmpl: $('#macro_pack_edit_macro_pack_tmpl'),
            tmpl_data: {
                macro_pack: self.macro_pack
            },
            changes: _changes_made
        });

        container.find(".playlist_event_cue .image.edit").click(edit_automation);
        container.find(".playlist_event_cue .image.delete").click(remove_automation);

        container.find('.macro_pack_edit_macro_pack_element .image.delete').click(function(){
            var position = $(this).closest('.macro_pack_edit_macro_pack_element_wrap').index();
            event_list.remove_item(position);
        });

        container.find('.macro_pack_edit_macro_pack_element .image.edit').click(function(){
            var edit_index = $(this).closest('.macro_pack_edit_macro_pack_element_wrap').index();
            var data = {};

            data.description = $(this).closest('.macro_pack_edit_macro_pack_element').find('.element_title').text();
            data.target_position = undefined;
            data.edit_pattern_position = edit_index;

            var mom_dur = moment.duration(self.macro_pack.event_list[edit_index].duration_in_seconds, 'seconds');
            var hms_settings = {
                hours: mom_dur.hours(),
                minutes: mom_dur.minutes(),
                seconds: mom_dur.seconds()
            };
            $("#pattern_duration").hms(hms_settings);

            spo.pattern_dialog(data, gettext('Edit Pattern'), on_pattern_dialog_output, hms_settings);
        });
    }

    function EventList(args) {
        var dom = args.dom;
        var tmpl = args.tmpl;
        var tmpl_data = args.tmpl_data;
        var changes = args.changes;
        var list = args.list;

        var sortable_dom = '.macro_pack_edit_macro_pack_container';
        var temp_move_index = 0;

        //Function bindings
        this.remove_item = remove_item;

        //Init
        dom.html(tmpl.tmpl(tmpl_data));

        sortable_dom = $(sortable_dom);

        //Setup sortable
        sortable_dom.sortable({
            start: function(event,ui) {
                //set temp_move_index so we know where we are moving from
                temp_move_index = sortable_dom.children('div').index(ui.item);
            },
            update: function(event, ui) {
                var target_position = sortable_dom.children('div').index(ui.item);

                if (temp_move_index == -1) {
                    add_item(ui, target_position);
                }
                else {
                    move_item(temp_move_index, target_position);
                }
            },
            receive: function(event, ui) {
                temp_move_index = -1;
            },
            stop: function(event, ui) {
                redraw_macro_pack();
            },
            helper: 'clone',
            appendTo: sortable_dom,
            containment: sortable_dom,
            tolerance: 'pointer'
        });

        //Make list items droppable for automation
        $('.macro_pack_edit_macro_pack_element_wrap').droppable({
            activeClass: 'drop_enabled',
            hoverClass: 'drop_hover',
            accept: function($draggable) {
                var $droppable = $(this);
                if ($draggable.attr('type') !== 'automation') {
                    return false;
                }
                else if ($draggable.attr('automation_id') === 'GDC-START-CUE' && $droppable.data('has_gdc_start_cue')) {
                    return false;
                }
                else {
                    return true;
                }
            },
            drop: function(event, ui){
                var automation_id = ui.helper.attr('automation_id');
                var automation = spo.find_automation(self.automation, automation_id);

                var data = {
                    'automation': automation,
                    'automation_id': ui.helper.attr('automation_id'),
                    'target_event_id': $(this).index()
                };

                spo.automation_dialog(data, gettext('Add Automation'), save_automation);
            }
        });

        function add_item(ui, target_position){
            switch(ui.item.attr('type')) {
                case('content'):
                    var cpl_uuid = ui.item.attr('cpl_uuid');
                    var cpl = $.grep(self.contents, function(e){
                        return e.uuid == cpl_uuid;
                    })[0];
                    var moved_event = new PlaylistCompositionEvent(cpl);
                    list.splice(target_position, 0, moved_event);
                    break;
                case('pattern'):
                    if(!ui.item.attr('duration_in_seconds')){
                        var data = {};
                        data.target_position = target_position;
                        data.description = ui.item.attr('description');
                        data.edit_pattern_position = undefined;
                        spo.pattern_dialog(data, gettext('Add Pattern'), on_pattern_dialog_output);
                    }
                    else {
                        var moved_event = new PlaylistPatternEvent({
                            'text': ui.item.attr('description'),
                            'duration_in_seconds': ui.item.attr('duration_in_seconds')
                        });
                        list.splice(target_position, 0, moved_event);
                    }
                    break;
            }
            changes();
        }

        function remove_item(pos){
            list.splice(pos, 1);
            changes();
            redraw_macro_pack();
        }

        function move_item(old_pos, new_pos){
            var moved_event = list.splice(old_pos, 1)[0];
            list.splice(new_pos, 0, moved_event);
            changes();
        }
    }

    function edit_automation() {
        var element_index = $(this).closest('.jq_event').index();
        var automation_index = $(this).closest('.jq_cue').index()-1;
        var automation = self.macro_pack.event_list[element_index].automation[automation_index];

        var data = {
            'automation': automation,
            'target_event_id': element_index,
            'edit_automation_index': automation_index
        };

        if (automation.type_specific.offset_in_seconds) {
            var mom_dur = moment.duration(automation.type_specific.offset_in_seconds, 'seconds');
            data['seconds'] = mom_dur.seconds();
            data['minutes'] = mom_dur.minutes();
            data['hours']   = mom_dur.hours();
        }

        spo.automation_dialog(data, gettext('Edit Automation'), save_automation);

        if(!isNaN(automation.type_specific.offset_in_seconds))
           $("#automation_offset").hms({'seconds' : automation.type_specific.offset_in_seconds});
        if(!isNaN(automation.type_specific.wait_duration != undefined))
            $("#automation_wait_duration").hms({'seconds' : automation.type_specific.wait_duration});
    }

    function save_automation() {
        var target_event_id = $('#target_event_id').val();
        var event_drop_target = self.macro_pack.event_list[target_event_id];

        spo.save_automation_dialog_input(event_drop_target, self.automation, self.device_automation_dict, function(){
            dialog.close();
            redraw_macro_pack();
            _changes_made();
        });
    }

    function remove_automation() {
        var event_index = $(this).closest('.jq_event').index();
        var automation_index = $(this).closest('.playlist_event_cue_wrapper').index() - 1;
        self.macro_pack.event_list[event_index].automation.splice(automation_index, 1);
        redraw_macro_pack();
        _changes_made();
    }

    function on_pattern_dialog_output(){
        var errors = [];
        var ok = true;
        var edit_position = $("#edit_pattern_position").val();
        var duration = $('#pattern_duration').hms("retrieve");

        if(duration == 0){
            ok = false;
            errors.push(gettext('Duration cannot be zero'));
        }

        if(edit_position !== ''){
            var current_pattern_automations = self.macro_pack.event_list[edit_position].automation || [];
            $.each(current_pattern_automations, function(index, automation){
                if(duration < automation.type_specific.offset_in_seconds){
                    ok = false;
                    errors.push(gettext("The duration of a Pattern must be greater than the start times of its Automations"));
                }
            });
        }

        if(ok){
            var description = $("#add_pattern_description").val();
            var target_position = $("#add_pattern_target_position").val();

            if (edit_position !== ''){
                var tmp = self.macro_pack.event_list[edit_position];
                tmp.duration_in_seconds = duration;
                tmp.duration_in_frames = (duration * tmp.edit_rate[0] / tmp.edit_rate[1]);
            }
            else {
                self.macro_pack.event_list.splice(
                    target_position,
                    0,
                    new PlaylistPatternEvent({
                        'text':description,
                        'duration_in_seconds':duration
                    })
                );
            }
            redraw_macro_pack();
            dialog.close();
            _changes_made();
        }
        else {
            $('#validation_error_tmpl').tmpl({'errors':errors}).appendTo($('.validation').empty());
        }
    }

    function _changes_made(bool){
        bool = $.val_or_default(bool, true);
        self.changes_made = bool;
        g_prevent_navigation = bool;
        if(bool){
            $('#button_0').button("option", "label", "*" + self.button_text);
        }
    }

    function _close_page() {
        $(document).off('.macro_pack_edit');
		self.device_uuid = undefined;
    }
}
