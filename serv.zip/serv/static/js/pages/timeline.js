function Timeline(sms_list) {
	var timeline = { //Core properties, in seconds
		original: { //Defaults for 100% zoom (NB: specified in minutes)
			view_size: 180, //Total viewable period
			interval: 30, //Step size for displaying times
			min_buffer: 19, //Minimum viewable historical period (obscure number reduces chance of redraw at show start)
			pos_calc_step: 1  //For POS-based footfall calculation
		}
	};
	var update_rate = 1000; //ms refresh rate (for all time-related DOM)

	var now;
	var update_handle;
	var last_schedule_sync;
	
	var screens;
	var shows;
	var reminders;
	var deferreds;
	var settings;
	var shows_drawn;
	var shrunk_pane_width;

	//Timeline panes
	var timebar = new Timebar();
	var show_pane = new ShowPane();
	var device_pane = new DevicePane();
	var pos_pane = new PosPane();
	var events_pane = new EventsPane();
	var reminder_alerts_pane = new ReminderAlertsPane();
	var notes_pane = new NotesPane();
	var settings_pane = new SettingsPane();
	var rightbar_pane = new RightbarPane();

	function draw() {
		shows = {};
		reminders = {};
		deferreds = {};
		auto_tooltip_thresholds = {};
		
		//Needed for drawing the main shell
		device_pane.get_devices(sms_list.filter(function(d){return d.enabled;}));
		//Build shell of individual panes, and whatever content doesn't require updating
		$('#timeline_shell_tmpl').tmpl2({
			devices: screens,
			pos_enabled: $complex_status.pos.enabled
		}, '#main_section');

		$('#timeline_pospane_toggle').click(pos_pane.toggle);
		settings_pane.get_settings();
		device_pane.draw();
		settings_pane.draw();
		rightbar_pane.draw();

		//Need the TMS time to be able to choose the correct timeline scale and schedules
		if($complex_status.core_time) {
			initial_shows_draw();
		} else {
			$complex_status.on('time_loaded', initial_shows_draw);
		}
		update_handle = setInterval(update, update_rate);
	}

	function update() {
		now = get_tms_time();
		if(last_schedule_sync !== $complex_status.sched_sync_stamp) {
			redraw();
		} else {
			timebar.update();
			show_pane.update();
			reminder_alerts_pane.update();
			pos_pane.update();
			events_pane.update();
			//Device pane is subscribed to the monitor.update_views fn (onLoad of playback status) 
		}
	}

	function kill() {
		shows = null;
		screens = null;
		reminders = null;
		deferreds = null;
		settings = null;
		
		clearInterval(update_handle);

		timebar = null;
		show_pane = null;
		device_pane = null;
		pos_pane = null;
		events_pane = null;
		reminder_alerts_pane = null;
		notes_pane = null;
		settings_pane = null;
		rightbar_pane= null;
	}

	function initial_shows_draw() {
		timebar.draw();
		shrunk_pane_width = $('#timeline_rightpane').width();
		var cached_shows = monitor_page.cached_timeline_shows_raw_data;
		//If the timeline has been open recently, reshow that state whilst waiting for new data.
		if(cached_shows && ((now - monitor_page.cached_timeline_cache_time) < timeline.interval)) {
			show_pane.update_shows(cached_shows);
			device_pane.update(true);
		}
		redraw(true);
	};
	function redraw(first) {
		if(!first) {
			timebar.draw();
		}
		deferreds = {
			shows: $.Deferred(),
			reminders: $.Deferred()
		};
		last_schedule_sync = $complex_status.sched_sync_stamp;
		//Wait for these calls to complete their success_fn before drawing certain things
		show_pane.ajax_get();
		reminder_alerts_pane.ajax_get();
		$.when(deferreds.shows, deferreds.reminders).done(function() {
			device_pane.update(true);
			pos_pane.draw();
		});
	}


	function Timebar() {
		var start = 0;
		this.start_time = function() {
			return start;
		};

		this.draw = function() {
			now = get_tms_time();
			update_start();
			$('#timeline_timebar_tmpl').tmpl2({times: get_times()}, '#timeline_timebar_pane');
			this.update_position();
			update_nowbar();
		};

		this.update = function() {
			var old_start = start;
			update_start();
			update_nowbar();
			//Redraw the timebar and show_pane with new schedules if the start_time has changed
			if(old_start !== start) {
				redraw();
			}
		};
		
		// Scrollbar hax
		var base_pixel_offset = 0;
		this.update_position = function() {
			var wrap = $('#timeline_wrapper');
			var show_pane_has_scrollbar = wrap.get(0).scrollHeight > wrap.height();
			if(show_pane_has_scrollbar) {
				//Simulate scrollbar effect
				$('#timeline_timebar_pane').css('overflow-x', 'hidden');
				base_pixel_offset = 2;
			} else {
				$('#timeline_timebar_pane').css('overflow-x', 'visible');
				base_pixel_offset = 0;
			}
		};
		
		this.get_period = function(iso) {
			update_start();
			var period = {
				start_time: start,
				end_time: (start + timeline.view_size)
			};
			if(iso) {
				period.start_time = new Date(period.start_time * 1000).toISOString() + ' +0000';
				period.end_time = new Date(period.end_time * 1000).toISOString() + ' +0000';
			}
			return period;
		};
		
		/** Time in seconds between now and the end of the timebar */
		this.viewable_future = function() {
			return (timeline.view_size + start - now) - 30; //Best have a few pixels visible
		};
		/** Time in seconds between now and the start of the timebar */
		this.viewable_past = function() {
			return (now - start);
		};

		function update_start() {
			//Adjust for desired buffer
			var rough_start = new Date((now - timeline.min_buffer) * 1000);
			//Round down to nearest interval so the time bar looks neat
			var interval_in_mins = timeline.interval / 60;
			rough_start.setMinutes( Math.floor(rough_start.getMinutes() / interval_in_mins) * interval_in_mins );
			rough_start.setSeconds(0);
			start = rough_start.setMilliseconds(0)/ 1000;
		}

		function get_times() {
			var times = [];
			
			var number_of_steps = timeline.view_size / timeline.interval;
			//Tick marks between time steps
			// 1 or 2 between each time_step, depending on what divisibility works
			var tick_step = (timeline.interval % 180 === 0) ? 3 : 2;
			var tick_step_offset = 100 / number_of_steps / tick_step;
			
			for(var step = 0; step <= number_of_steps; step++) {
				var time = start + (timeline.interval * step);
				var position = step / number_of_steps * 100;
				var time_step = {
					value: unixtime_24hr_format(time),
					position: position,
					ticks: []
				};
				for(var tick = 1; tick < tick_step; tick++) {
					time_step.ticks.push(position + (tick_step_offset * tick));
				}
				times.push(time_step);
			}
			return times;
		}

		function update_nowbar() {
			var position = (now - start) * 100 / timeline.view_size;
			//Pixel offsets - needed to account for the element widths
			$('#timeline_nowbar').css('left', 'calc('+ position +'% - '+ (2 + base_pixel_offset) +'px');
			$('#timeline_nowblock').css('left', 'calc('+ position + '% - '+ (11 + base_pixel_offset) +'px');
		}
	}

	function PosPane() {
		var smoothing_level = 3; //Number of consectutive steps to average over and combine into a 'block'
		var gappyness = 0.6; //fractional width to leave clear between consecutive blocks; 
		var min_busyness = 3; //% busyness below which to disable pos bar if no blocks are above this
		var global_coeff = 1; //Adjusts the height of every POS busyness bar by this factor

		var active;

		this.draw = function() {
			if(!$complex_status.pos.enabled) {
				active = false;
				return;
			}
			var pos_shows = [];
			$.each(shows, function(i, show) {
				if(show.valid_pos) {
					pos_shows.push( new Pos(show) );
				}
			});
			active = (pos_shows.length > 0);
			if(!active) {
				return;
			}
			active = false;

			var num_calcs = timeline.view_size / timeline.pos_calc_step;
			var screen_count_scale_factor = 1 / Object.keys(screens).length;

			var blocks = [];
			var time_scale_factor;
			var block = {
				width: 100 / num_calcs * smoothing_level * gappyness
			};
			var base_height = 100 * screen_count_scale_factor / smoothing_level;
			
			for(var i = 0; i < num_calcs; i++) {
				var time = timebar.start_time() + (i * timeline.pos_calc_step);

				if(i % smoothing_level === 0) {
					//start of smoothed block
					time_scale_factor = 0;
					block.left = i / num_calcs * 100;
					block.start_time = time;
				}

				$.each(pos_shows, function(i, pos) {
					var time_weight = pos.time_weighting(time);
					time_scale_factor += pos.fraction_full  * time_weight;
				});

				if(i % smoothing_level === smoothing_level-1) {
					//end of smoothed block
					block.end_time = time + timeline.pos_calc_step;
					block.height = time_scale_factor * base_height;
					block.level = 'low';
					if(block.height > 50) {
						block.level = (block.height > 75) ? 'high' : 'mid';
					}
					if(!active && block.height > min_busyness) {
						active = true;
					}

					blocks.push($.extend({}, block));
				}
			}
			if(!active) {
				return;
			}
			if(!monitor_page.timeline_pospane_hidden) {
				$('#timeline_pos_bar').show(300);
				$('#timeline_wrapper').addClass('pos_enabled');
			}
			$('#timeline_pospane_toggle').show();
			//Draw the blocks
			$('#timeline_pos_tmpl').tmpl2({pos_shows: blocks}, '#timeline_pos_blocks');
			//Explanatory tooltip
			var $footfall = $('#pos_bar_footfall');
			$footfall.qtip( tooltip_options( $footfall.find(':first').text(),
				'qtip-dark', {at: 'top right', my: 'left center'} ) );
			this.update();
			
			timebar.update_position();
		};

		this.update = function() {
			if(!active) {
				return;
			}
			//Highlight the currently active block
			$('#timeline_pos_blocks').find('div')
				.removeClass('block_active')
				.filter(function(){
					return ($(this).attr('data-start_time') < now) && ($(this).attr('data-end_time') > now);
				})
				.addClass('block_active');
		};
		
		function toggle() {
			$('#timeline_pos_bar').toggle(700);
			$('#timeline_wrapper').toggleClass('pos_enabled');
			$('#timeline_pospane_toggle').toggleClass('icon-arrow-up icon-arrow-down');
			// Store in the JS session to give temporary memory of the toggle position
			monitor_page.timeline_pospane_hidden = !monitor_page.timeline_pospane_hidden;
		};

		function Pos(show) {
			var pos_show = show.pos;

			this.start = show.start;
			this.end = show.start + show.duration;
			this.duration = show.duration;
			this.fraction_full = pos_show.seats_sold / pos_show.seats_available * global_coeff;
			//Settings for determining when to apply a contribution to the busyness block from the pos show
			//Times are in seconds, and determine when to start contributions
			//Distribution will determine how to spread the audience load around the event (show start/end)
			//Weightings are relative to the largest (show end)
			var active = {
				show_start: {
					//Activity around the start of a show
					before: 300,
					after: 1000,
					distribution: 'uniform'
					//weight: depends on duration of the active window
				},
				show_end: {
					before: 600,
					after: 30,
					distribution: 'linear-decay',
					weight: 1
				},
				background: {
					//Activity in the middle of a show (latecomers, toilet-goers etc.)
					distribution: 'uniform',
					weight: 0.05
				}
			};

			//Improve some of the above estimates based on playlist details
			$.each(show.playlist, function(i, block) {
				if(block.is_feature) {
					active.show_start.after = show.duration - block.duration; //up to start of feature
					active.show_end.before = (block.credits_length || 600); //credits start, else 10mins
					return false;
				}
			});
			active.show_start.duration = active.show_start.after + active.show_start.before;
			active.show_end.duration = active.show_end.after + active.show_end.before;
			//Weight the show start according to how much longer the start is compared to the end
			active.show_start.weight = active.show_end.duration / active.show_start.duration;

			this.time_weighting = function(time) {
				var offset = {
					show_start: {
						before: time - (this.start - active.show_start.before),
						after: time - (this.start + active.show_start.after),
						fraction: (time - (this.start - active.show_start.before)) / active.show_start.duration
					},
					show_end: {
						before: time - (this.end - active.show_end.before),
						after: time - (this.end + active.show_end.after),
						fraction: (time - (this.end - active.show_end.before)) / active.show_end.duration
					}
				};

				if(offset.show_start.before > 0 && offset.show_start.after < 0) {
					//apply weighting due to show start
					return distribution(active.show_start, offset.show_start);
				} else if(offset.show_end.before > 0 && offset.show_end.after < 0) {
					//apply weighting due to show end
					return distribution(active.show_end, offset.show_end);
				} else if(offset.show_start.before > 0 && offset.show_end.after < 0) {
					//apply weighting due to background
					return distribution(active.background);
				} else {
					//No weighting required
					return 0;
				}
			};

			function distribution(settings, offset) {
				var type = settings.distribution;
				var weight = settings.weight;
				var scaler = 1;
				if(type === 'uniform') {
					//Default scaler
				} else if(type === 'linear-decay') {
					//total movement/area/integral should be the same regardless of distribution
					scaler = 2 * (1 - offset.fraction);
				}
				return weight * scaler;
			}
		}
		this.toggle = toggle;
	}

	function DevicePane() {
		var issues_show_prewarn_time = 1800; //time before a scheduled show start to warn if the show or device has issues
		var minimum_intermission_percent = 8; //Assume intermission is over if after this and playback says not in intermission
		var dead_show_tolerance = 30; //time in s to allow a seemingly unplayable show to start playing before hiding it
		var resync_threshold = 15; //resync the show position and times if the diff with realtime playback exceeds this

		var redraw_required = false;
		var $devices;

		this.get_devices = function(sms_list) {
			screens = {};
			//objectify the devices
			$.each(sms_list, function(i, sms) {
				screens[sms.id] = new Screen(sms.id);
			});
		};

		this.draw = function() {
			$('#timeline_device_pane').find('[title]').each(function(i) {
				$(this).qtip( tooltip_options( $(this).attr('title'),
						'qtip-dark', {at: 'bottom center', my: 'top center'} ) );
			});
			$devices = $('#timeline_device_pane').find('.timeline_device');
		};

		/**
		 * Syncs the shows and device indicators wth actual playback data
		 * @param {Boolean} force_redraw set true to force a redraw of the shows pane,
		 *		else redraw only if required due to the playback data
		 */
		this.update = function(force_redraw) {
			redraw_required = force_redraw;
			if(!screens) {
				return;
			}

			$devices.each(function(i) {
				var $device = $(this);
				var device_id = $device.attr('data-device');
				screens[device_id].update($device.find('.timeline_device_number'));
			});
			if(redraw_required) {
				show_pane.draw();
				events_pane.draw();
			}
		};

		function Screen(device_id) {
			 //Frequencies (in playback_status update cycles) to give strong UI warnings about device errors
			var maximum_ui_warn_rate = 6;
			var minimum_ui_warn_rate = 150;

			var id = device_id;
			this.id = id;

			var update_count = 0;
			var notify_frequency = 1;

			//Status indicators
			var schedule_mode_off = false;
			var is_playing = false;
			var is_playing_or_paused = false;
			var is_intermission = false;
			var playlist_id;

			var show_status = {};
			var playback;
			var $shows;

			this.update = function(device_indicator) {
				show_status.should_be_playing = false;
				show_status.near = false;
				show_status.dead = false;
				show_status.wrong_playlist = false;
				show_status.key_error = false;

				playback = $playback_store.devices[id];
				if(!playback) {
					return;
				}
				schedule_mode_off = playback.modes ? (playback.modes.scheduler_enabled === false) : false;
				is_playing = (playback.playback_state === 'play');
				is_playing_or_paused = is_playing || (playback.playback_state === 'pause');
				is_intermission = playback.intermission;
				playlist_id = playback.spl_uuid;
				
				var $show_wrapper = $('#timeline_shows_pane').find('.timeline_show_wrapper[data-device="'+ id +'"]');
				$shows = $show_wrapper.find('.timeline_show').not('.timeline_placeholder');
				
				$show_wrapper.find('.schedule_manual_mode').toggle(schedule_mode_off && !$shows.length);

				var active_show;
				var $active_show;
				var next_show;
				var manual_show;
				var $manual_show;
				//Only consider the next show if it is starting reasonably soon
				var nearest_show_start = issues_show_prewarn_time;

				for(var i = 0; i < $shows.length; i++) {
					var $show = $($shows[i]);
					var show = shows[$show.attr('data-id')];
					if(!show) {
						$show.remove();
					} else if(show.unscheduled) {
						manual_show = show;
						$manual_show = $show;
					} else {
						if(show.is_playing()) {
							//Ignore possible overlap.
							active_show = show;
							$active_show = $show;
						} else if(show.is_unstarted() && (show.time_to_start < nearest_show_start)) {
							next_show = show;
							nearest_show_start = show.time_to_start;
						}
					}
				}
				var priority_show = false;
				if(active_show) {
					sync_show_with_playback_data(active_show, $active_show);
					priority_show = active_show;
				} else if(next_show) {
					show_status.near = true;
					priority_show = next_show;
				}
				if(priority_show) {
					show_status.key_error = priority_show.issues.kdm;
				}

				var issues_notifiable = (show_status.near || show_status.should_be_playing);
				var warning = (schedule_mode_off || show_status.key_error) && show_status.near;
				var error = show_status.dead;

				//Update the device indicators
				device_indicator
					.toggleClass('playing', is_playing)
					.toggleClass('play_error', error)
					.toggleClass('play_warning', warning)
				;
				//specific indicators
				device_indicator.find('.schedule_error').toggle(schedule_mode_off && issues_notifiable);
				device_indicator.find('.playlist_error').toggle(show_status.wrong_playlist && issues_notifiable);

				//Give stronger UI warning to user every so often
				if(priority_show && ((update_count % notify_frequency) === 0)) {
					if(error) {
						device_indicator.show('pulsate', {times:4}, 250);
					} else if(warning) {
						device_indicator.effect('pulsate', {times:2}, 500);
					}
					//Calculate ideal frequency based on time to/from show start
					var next_notify_base = Math.round(Math.abs(priority_show.time_to_start) / 10);
					//Limit the frequency between set bounds
					notify_frequency = Math.max(Math.min(minimum_ui_warn_rate, next_notify_base), maximum_ui_warn_rate);
					update_count = 1;
				}
				update_count++;

				//Check for manual playback
				var man_id = 'manual-' + id; //a device can only have one manual playback at a time
				var show = shows[man_id];
				if(show) {
					if(is_playing) {
						sync_timings(manual_show, $manual_show);
					}
					//playback stopped, or end of show but looped playback keeps the is_playing true, or playlist changed
					if(!is_playing_or_paused || show.is_finished() || (show.playlist_id !== playlist_id)) {
						delete shows[man_id];
						redraw_required = true;
					}
				} else if(settings.allow_manual_shows && shows_drawn && is_playing && playback.playlist) {
					//Beware: manual playback can occur when a device is in schedule mode (turned on mid-playback),
					//and manual shows can come from a scheduled show (schedule mode turned off mid-playback),
					//so only create a manual show if there isn't a currently scheduled show or the scheduled show is not playing
					if(!priority_show || (playlist_id !== priority_show.playlist_id && priority_show.time_to_start > dead_show_tolerance)) {
						shows[man_id] = new Show({
							start_timestamp: now - playback.spl_position,
							device_information: {device_uuid: id, device_playlist_uuid: playlist_id},
							type: 'manual',
							duration: playback.spl_duration,
							display_name: playback.spl_title,
							uuid: man_id,
							unscheduled: true,
							playlist: playback.playlist.events,
							templating_issues: []
						});
						redraw_required = true;
					}
				}
			};

			function sync_show_with_playback_data(show, $show) {
				var correct_playlist = (show.playlist_id === playlist_id) ||
										(show.intermission_playlist_id === playlist_id) ||
										is_intermission; //playlist changes in this scenario
				show_status.wrong_playlist = is_playing && !correct_playlist && playlist_id && playback.playlist;
				//Determine whether it is really playing (with some tolerance at show start to allow for device time diff)
				show_status.should_be_playing = (show.seconds_in() > dead_show_tolerance);
				var possibly_dead = (!is_playing_or_paused || !correct_playlist);
				show_status.dead = possibly_dead && show_status.should_be_playing;

				$show.toggleClass('dead', show_status.dead);
				if(show_status.dead !== show.died) { //change has occured in death status
					show.died = show_status.dead;
					redraw_required = true;
				}
				if(!possibly_dead) {
					//Special intermission handling
					if(show.has_intermission) {
						//Must allow time for intermission to load so we don't think it's over before it's even begun
						if(!is_intermission && (show.intermission_percent_complete() > minimum_intermission_percent)){
							show.intermission_complete = true;
						} else if(is_intermission) {
							show.intermission_complete = false;
						}
					}
					//Sync schedule-derived timings with those of the realtime playback data
					if(!is_intermission) {
						sync_timings(show, $show);
					}
				}
			}

			function sync_timings(show, $show) {
				var time_diff = (playback.spl_position > 0) ? (playback.spl_position - show.seconds_in()) : 0;
				if(Math.abs(time_diff) > resync_threshold) {
					//Resync
					show.adjust(time_diff);
					$show.css('left', show.left +'%');
					// #DEBUG
//					console.log('Adjusted screen '+ helpers.get_device_name(this.id) +' by ' + time_diff);
				}
			}
		}
	}

	function ShowPane() {
		var credits_countdown_percent = 70; //How far into the feature to start showing the credits-start time
		var min_time_dom_clearance = 5; //Hide pack times if they don't fit in their block by this many pixels

		var gaps = {};

		this.ajax_get = function() {
			helpers.ajax_call({
				url: '/tms/get_timeline_shows',
				data: timebar.get_period(true),
				success_function: function(shows_obj) {
					update_shows(shows_obj);
					//Long call, so cache in case of near-future tab re-click
					monitor_page.cached_timeline_shows_raw_data = shows_obj;
					monitor_page.cached_timeline_cache_time = now;
				},
				complete_function: function(){
					deferreds.shows.resolve();
				}
			});
		};

		this.draw = function() {
			var device_shows = {};

			$('.timeline_show, .timeline_cleaning').empty().remove();

			$.each(shows, function(i, show) {
				show.update();
				$('.timeline_show_wrapper[data-device="'+ show.device_id +'"]')
					.append( $('#timeline_show_tmpl').tmpl2(show) );

				//prep for getting the show gaps
				if(device_shows[show.device_id]) {
					device_shows[show.device_id].push(show);
				} else {
					device_shows[show.device_id] = [show]; 
				}
			});

			//Find cleaning windows between succesive shows on each screen
			$.each(device_shows, function(did, shows) {
				var gap_start;
				var gap_end;

				//order by start time
				shows.sort(function(a,b) {
					return (a.start < b.start) ? -1 : 1;
				});

				$.each(shows, function(sid, show) {
					gap_end = show;
					if(gap_start) {
						var len = gap_end.start - gap_start.end;
						if(len > 0) {
							gaps[did + sid] = {
								id: sid,
								device_id: did,
								duration: len,
								show_before: gap_start,
								show_after: gap_end,
								width: len / timeline.view_size * 100,
								left: (gap_start.end - timebar.start_time()) * 100 / timeline.view_size
							};
							$('.timeline_show_wrapper[data-device="'+ did +'"]')
								.append( $('#timeline_showgap_tmpl').tmpl2(gaps[did + sid]) );
						}
					}
					gap_start = show;
				});
			});

			this.update(true);
			
			//If updating from settings, have to prevent overzealous pack time hiding 
			var full_width = $('#timeline_pane').width();
			var expanded_pane_width = $('#timeline_rightpane').width();
			var pane_shrink_coeff = 1 - (full_width - shrunk_pane_width) / (full_width - expanded_pane_width);

			//Attach tooltips
			$('.showtip_wrapper').empty().remove();
			$('#timeline_shows_pane').find('.timeline_show').each(function(i) {
				var $show = $(this);
				var show = shows[$show.attr('data-id')];
				
				var tip_data = show.get_tooltip_data();
				$show.qtip( tooltip_options(
					$('#timeline_show_tip_tmpl').tmpl2(tip_data),
					'qtip-show'+ ((tip_data.has_issue) ? ' problems' : '') + ((settings.shrunk) ? ' shrunk' : ''),
					tip_data.position,
					true
				));
				$( $show.find('.timeline_pack') ).each(function(i) {
					var $pack = $(this);
					//trigger hover event on the Event to which this $pack corresponds
					$pack.hover(function(e) {
						events_pane.hover_reveal(e, $pack);
					});
					//Remove pack times if they don't fit in their pack block
					var $pack_time = $pack.children('.timeline_pack_time');
					var pack_width = $pack.width();
					var clearance = pack_width * pane_shrink_coeff + min_time_dom_clearance;
					if((pack_width - $pack_time.width()) < clearance) {
						$pack_time.remove();
						show.playlist[$pack.attr('data-id')].time_removed = true;
					}
				});
			});
			this.update();
			
			$('#no_valid_shows_warning').toggle($.isEmptyObject(shows));
			shows_drawn = true;
		};

		this.update = function(force) {
			var force_dom_time;
			
			var max_time = timebar.viewable_future();
			var min_time = -timebar.viewable_past();
			
			$('#timeline_shows_pane').find('.timeline_show').each(function(i) {
				var $show = $(this);
				var show = shows[$show.attr('data-id')];
				
				if(!show) {
					return true;
				}
				force_dom_time = force || show.recently_adjusted;

				show.update();
				//Not currently used but maybe later
//				$show.toggleClass('finished', show.is_finished());
				
				var previous_valid_pack = {}; //Only set for packs which have a DOM time.
				
				$.each(show.playlist, function(j, pack) {
					if((pack.time_to_start > max_time) || (pack.time_to_end < min_time) || pack.is_fleeting) {
						//Not visible on screen; don't update
						return true;
					}
					//update UI with updated pack data
					var $pack; //Perf - only get dom object if it's going to be used
					if(force_dom_time || pack.active_changed()) {
						$pack = get_dom_pack($show, pack.id);
						$pack.toggleClass('pack_active', pack.active);
					}
					//Check whether UI pack times need updating
					if(!settings.show_pack_times || !pack.eventable() || pack.time_removed || show.died) {
						return true;
					}
					$pack = $pack || get_dom_pack($show, pack.id);
					update_dom_time($pack, '.timeline_pack_time_start', pack.time_to_start, pack.hide_time(previous_valid_pack) && !force);
					if(pack.is_feature) {
						update_dom_time($pack, '.timeline_pack_time_end', pack.time_to_end, !pack.active);
						if(pack.intermission) {
							update_dom_time( $pack.find('.timeline_intermission'), '.timeline_pack_time_start',
								pack.time_to_intermission, !pack.active );
						}
						if(pack.has_credits) {
							update_dom_time( $pack.find('.timeline_credit_offset'), '.timeline_pack_time_start',
								 pack.time_to_credits, (pack.percent_complete < credits_countdown_percent) || !pack.active ||  settings.shrunk);
						}
					}
					previous_valid_pack = pack;
				});
			});
			
			function update_dom_time(dom, selector, time, force_hide) {
				var $time = dom.children(selector);

				if($time.length === 0) {
					return;
				}
				if(force_hide) {
					//Using the attribute cache to check whether it's already hidden
					// is massively quicker (> x5) than just hiding it regardless
					if($time.attr('data-hidden') !== 't') {
						$time.hide();
						$time.attr('data-hidden', 't');
					}
					return;
				}
				//Update the time
				if(force_dom_time || dom_time_needs_updating(time)) {
					$time.text(helpers.pretty_duration_string(time))
							.toggleClass('time_near', time >= 0 && time <= settings.auto_tooltip_start)
							.toggleClass('time_past', time < 0)
							.attr('data-hidden', 'f')
							.show()
					;
				}
				//Not currently used but maybe later
	//			tip_autoshow(dom, time, force_dom_time);
			}
			function get_dom_pack($show, pack_id) {
				return $show.find('.timeline_pack[data-id="'+ pack_id +'"]');
			}
			
		};
		function update_shows(shows_obj) {
			var show_ids = [];

			$.each(shows_obj.data, function(id, show) {
				show_ids.push(id);
				//Check for new shows, and refresh existing ones (Timebar may have changed)
				if(shows[id]) {
					shows[id].refresh();
				} else {
					// POS bar debug only!
//					$.extend(show.pos_information || {}, {seats_sold: Math.round(Math.random()*180), seats_available: 60});
					shows[id] = new Show(show);
				}
			});
			//Check for deleted/expired shows
			$.each(shows, function(id, s) {
				if(!$._in(id, show_ids)) {
					delete shows[id];
				}
			});
		}
		this.update_shows = update_shows;
	}

	function EventsPane() {
		var max_time;
		var events;

		this.draw = function() {
			events = [];
			max_time = timebar.viewable_future();

			$.each(shows, function(i, show) {
				if(show.died) {
					//Don't show events for a dead show
					return true;
				}
				$.each(show.playlist, function(j, pack) {
					//Restrict events to most useful pack types
					if(pack.eventable()) {
						pack.get_events();
					}
				});
			});
			$.each(reminders, function(i, reminder) {
				reminder.get_events();
			});
			events.sort(function(a,b) {
				return (a.time > b.time) ? 1 : -1;
			});
			$('#timeline_event_tmpl').tmpl2(events, '#timeline_events tbody');

			$('#timeline_events tbody tr').hover(function(e) {
				//trigger hover event on the DOM to which this event corresponds
				$('#timeline_pane').find('[data-event_id="'+ $(this).attr('data-id') +'"]')
					.trigger(e.type) //toggle the tooltip
					.toggleClass('hover', e.type === 'mouseenter');
			});

			check_no_events();
			this.update();
		};

		this.add = function(id, screen, name, get_time, class_name) {
			//First check that the event is unexpired and displayable
			var time = get_time();
			if(time > settings.event_kill && time < max_time) {
				events.push({
					id: id,
					screen: screen,
					name: name,
					time: time - 10, // Offset to trigger forced DOM update during this.update
					level: '',
					get_time: get_time,
					class: class_name || ''
				});
			}
		};

		this.update = function() {
			$('#timeline_events').find('tbody tr').each(function() {
				var $event = $(this);
				var i = parseInt($event.attr('data-sort_id'));
				
				var event = events[i];
				if(!event) {
					return true;
				}
				var old_time = event.time;
				var time = event.get_time();
				event.time = time;
				
				var old_level = event.level;
				event.level = '';
				if(time < settings.event_kill)
					event.level = 'kill';
				else if(time < settings.event_alert)
					event.level = 'alert';
				else if(time >= settings.event_alert && time < settings.event_warn)
					event.level = 'warn';
				
				// Force update DOM if a big jump has occurred or the event level has changed
				var force = (Math.abs(old_time - time) > 1) || (old_level !== event.level);
				
				if(force || dom_time_needs_updating(time)) {
					$event
						.toggleClass('time_warn', event.level === 'warn')
						.toggleClass('time_alert', time < settings.event_alert)
						.find('.event_time').text(helpers.pretty_duration_string(time));

					if(event.level === 'kill') {
						$event.fadeOut(3000, function(){
							$event.remove();
							check_no_events();
						});
					}
				}
			});
		};

		this.hover_reveal = function(e, dom) {
			$('#timeline_events')
				.find('tbody > tr[data-id="'+ dom.attr('data-event_id') +'"]')
				.toggleClass('hover', e.type === 'mouseenter');	
		};

		function check_no_events() {
			$('#timeline_events').find('tfoot').toggle($('#timeline_events').find('tbody tr').length === 0);
		}
	}

	function ReminderAlertsPane() {
		this.ajax_get = function() {
			helpers.ajax_call({
				url: '/core/note/notes',
				data: timebar.get_period(),
				success_function: function(reminders_obj) {
					reminder_alerts_pane.draw(reminders_obj.data.notes);
					deferreds.reminders.resolve();
				}
			});
		};

		this.draw = function(reminders_obj) {
			reminders = {};
			$('.reminder_alert_tip').empty().remove();
			$.each(reminders_obj, function(i, reminder) {
				reminders[reminder.id] = new Reminder(reminder);
			});
			$('#timeline_reminder_alerts_tmpl').tmpl2(reminders, '#timeline_reminder_alerts');
			$('#timeline_reminder_alerts').find('.reminder_alert').each(function() {
				var $reminder = $(this);
				//tooltips
				$reminder.qtip( tooltip_options(
						$('#timeline_reminder_alert_tip_tmpl').tmpl2(reminders[$reminder.attr('data-event_id')]),
						'qtip-dark',
						{at: 'bottom center', my: 'top center'}
				));
				//hover-link to events pane
				$reminder.hover(function(e) {
					events_pane.hover_reveal(e, $reminder);
				});
			});
			this.update();
		};

		this.update = function() {
			$.each(reminders, function(i, reminder) {
				reminder.update();
				tip_autoshow($('#timeline_reminder_alerts').find('[data-event_id="'+ reminder.id +'"]'), reminder.time_left);
			});
		};

		function Reminder(args) {
			var reminder = this;
			this.raised = args.remind.next;
			this.icon = args.icon;
			this.group = args.group;
			this.subject = args.subject;
			this.detail = args.detail;
			this.id = args.id;
			this.left = (reminder.raised - timebar.start_time()) * 100 / timeline.view_size;
			this.repeat_type = (args.repeat_type || 'once');
			this.time_pretty = unixtime_24hr_format(this.raised);

			this.update = function() {
				reminder.time_left = reminder.raised - now;
			};

			this.get_events = function() {
				events_pane.add(reminder.id, '', reminder.subject,
					function(){return reminder.time_left;}, 'note_group_'+ reminder.group);
			};
		}
	}

	function NotesPane() {
		//Limited set of icons that should potentially mean something, vaguely at least
		var icon_set = ['flag', 'settings', 'remove', 'star', 'megaphone', 'eye',
			'clipboard', 'user', 'key', 'wand', 'clock', 'light-bulb', 'pencil'];
		var repeat_types = {
			none: gettext('Do Not Repeat'),
			day: gettext('Daily'),
			week: gettext('Weekly')
		};
		var note_groups = ['', 'red', 'green', 'blue']; //Need a CSS style for each
					
		var all_notes;
		var new_id = 0;
		var sort_down;
		var sort_col;
		
		this.draw = function() {
			if(!all_notes) {
				//Initial setup
				$('#notes_list_add_btn').click(function() {notes_pane.draw_add();});			
				$('#notes_wrapper').on('click', '.note_summary', function() {
					notes_pane.draw_add($(this).attr('data-id'));
				});
				$('#notes_filter input').searcher(filter);
				$('#notes_sorting > span').click(sort);
				all_notes = {};
			}
			
			helpers.ajax_call({
				url: '/core/note/notes',
				data: {},
				success_function: function(notes_obj) {
					$.each(notes_obj.data.notes, function(i, note) {
						if(all_notes[note.id]) {
							//Update note if next_raised has changed
							if(note.remind && (all_notes[note.id].remind.next !== note.remind.next)) {
								ui_note(note);
								all_notes[note.id] = note;
								$('#notes_wrapper').find('.note_summary[data-id="'+ note.id +'"]')
									.attr('data-sort_alarm', get_next_stamp(note))
									.find('.note_raised').text(note.remind.next_pretty)
								;
							}
						} else {
							ui_note(note);
							all_notes[note.id] = note;
							$('#notes_wrapper').append(draw_note(note));
						}
					});
					sort_down = !sort_down; //Remember previous sort dir
					$('#notes_sorting >:first').trigger('click');
				}
			});
		};
		
		//If passed an ID, it's an edit form
		this.draw_add = function(id) {
			var id_full = id || ('new_'+ new_id);
			
			var note = (all_notes[id] || {id: id_full});
			var repeat_reminder = note.remind && note.remind.repeat;
			
			//Assign defaults and simplify reminder obj
			note.remind_date = note.remind ? new Date(note.remind.date) : new Date();
			note.repeat_type = repeat_reminder ? note.remind.repeat.type : 'none';
			note.repeat_days = repeat_reminder ? note.remind.repeat.days : [];
			note.repeat_frequency = repeat_reminder ? note.remind.repeat.frequency : 1;
			note.repeat_from = repeat_reminder ? new Date(note.remind.repeat.starting * 1000) : new Date();
			if(note.remind) {
				note.remind_time = note.remind.repeat ? note.remind.repeat.at : note.remind.time;
			} else {
				note.remind_time = '00:00:00';
			}
			
			//Build the form
			var $form = $('#timeline_note_form_tmpl').tmpl2({
				note: note,
				repeat_types: repeat_types,
				days: days
			});
			if(id) {
				var $old_note = $('#notes_wrapper').find('[data-id="'+ id +'"]')
						.hide()
						.before($form);
			} else {
				$('#notes_wrapper').prepend($form);
				new_id++;
			}
			
			//Attach listeners
			form_get('add_remind_tgl').click(function() {
				form_get('remind_options').toggle();
			});
			form_get('date').datepicker({showAnim: 'slideDown',	dateFormat: 'yy-mm-dd'});
			form_get('repeat_from').datepicker({showAnim: 'slideDown',	dateFormat: 'yy-mm-dd'});
			
			form_get('select_boxes > span').click(function() {
				//state toggle
				var $box = $(this);
				var $box_group = $box.parent();
				var box_value = $box.attr('data-value');

				var multi_select = $box_group.hasClass('note_select_multi');
				if(multi_select) {
					$box.toggleClass('selected');
				} else {
					$box.addClass('selected')
						.siblings().removeClass('selected');
				}

				//repeat type toggle options
				if($box_group.hasClass('note_repeat_type')) {
					form_get('date').toggle(box_value === 'none');
					form_get('repeat_from').parent().toggle(box_value !== 'none');
					form_get('repeat_frequency').parent().toggle(box_value === 'week');
					form_get('repeat_days').toggle(box_value === 'week');
				} else if($box_group.hasClass('note_remind')) {
					form_get('remind_options').toggle(box_value === '1');
				}
			});
			helpers.attach_time_tip(form_get('time'));
			//Colour-switcher
			form_get('group').click(function() {
				var group_current = $(this).attr('data-value');
				var group_future = note_groups[(note_groups.indexOf(group_current) + 1) % note_groups.length];
				$form.removeClass('note_group_'+ group_current).addClass('note_group_'+ group_future);
				$(this).attr('data-value', group_future);
			});
			//Icon-picker
			var $icon = form_get('icon');
			$icon.qtip(tooltip_options(
				$('#timeline_note_form_icon_picker_tmpl').tmpl2({icons: icon_set}),
				'note_icon_picker',
				'bottom-center right-center',
				true
			));
			$icon.qtip('api').set('events.render', function(e, api) {
				api.elements.content.find('span').click(function() {
					var new_icon = $(this).attr('data-value');
					$icon.attr('data-value', new_icon).attr('class', 'note_icon icon-'+ new_icon);
					api.hide();
				});
			});
			var buttons = [{
					id: 'note_submit_'+ id_full,
					text: gettext('Save'),
					image: 'save',
					onClick: submit_form
				},
				{
					id: 'note_close'+ id_full,
					text: gettext('Cancel'),
					onClick: function() {
						close_form(0);
						if(id) {
							$old_note.show();
						}
					}
			}];
			if(id) {
				buttons.push({
					id: 'note_delete'+ id_full,
					text: gettext('Delete'),
					image: 'delete',
					onClick: function() {
						remove(id);
						close_form(500);
						$old_note.remove();
					}
				});
			}
			helpers.set_buttons('#note_buttons_'+ id_full, buttons);
			
			//Set the form state
			form_get('remind span[data-value="'+ (note.remind ? 1 : 0)  +'"]').click();
			form_get('repeat_type span[data-value="'+ note.repeat_type  +'"]').click();
			form_get('date').datepicker('setDate', note.remind_date);
			form_get('repeat_from').datepicker('setDate', note.repeat_from);
			form_get('subject').focus();
			

			function submit_form() {
				var note = {
					subject: form_get('subject').val(),
					detail: form_get('detail').val(),
					icon: form_get('icon').attr('data-value'),
					group: form_get('group').attr('data-value')
				};
				if(get_span_selected_val('remind') === '1') {
					//Reminder set
					var note_time = form_get('time').val();
					var repeat_type = get_span_selected_val('repeat_type');
					if(repeat_type === 'none') {
						var date = new Date(form_get('date').val() +' '+ note_time).getTime();
						note.raised_at = (date || $.now()) / 1000;
						note.repeat_type = null;
					} else {
						note.repeat_type = repeat_type;
						note.raised_at = null;
						//Sanitise time
						var time_is_good = new Date('1991-07-04 '+ note_time).getTime();
						note.repeat_at = time_is_good ? note_time : '12:00:00';
						//Sanitise date
						var repeat_from = form_get('repeat_from').val();
						var date_is_good = new Date(repeat_from + ' 10:0:0').getTime();
						note.repeat_from = date_is_good ? repeat_from : '2012-01-01';
						if(repeat_type !== 'day') {
							note.repeat_days = get_span_selected_multival('repeat_days');
							note.repeat_frequency = parseInt(form_get('repeat_frequency').val()) || 1;
						}
					}
				}
				$form.html(gettext('Loading'));
				if(id) {
					note.id = id;
					save_edit(gettext('Edit'), 'edit', note);
					$old_note.remove();
				} else {
					save_edit(gettext('Create'), 'create', note);
				}
			}
			
			function get_span_selected_val(parent_name) {
				return form_get(parent_name + ' .selected').attr('data-value');
			}
			function get_span_selected_multival(parent_name) {
				var vals = [];
				form_get(parent_name + ' .selected').each(function(){
					vals.push( $(this).attr('data-value') );
				});
				return vals;
			}
			function form_get(name) {
				return $form.find('.note_' + name);
			}
			function close_form(time) {
				$form.fadeOut(time, function(){$(this).remove();});
			}

			function save_edit(name, path, note) {
				helpers.ajax_call({
					url: '/core/note/'+ path,
					data: { note: note },
					success_function: function(new_note_obj) {
						if(new_note_obj.data.note) {
							var new_note = new_note_obj.data.note;
							ui_note(new_note);
							$form.after(draw_note(new_note));
							close_form(0);
							all_notes[new_note.id] = new_note;
							reminder_alerts_pane.ajax_get();
						} else {
							$form.remove();
						}
					}
				});
			}
			function remove(note_id) {
				helpers.ajax_call({
					url: '/core/note/delete',
					data: { ids: [note_id] },
					success_function: function() {
						delete all_notes[note_id];
						reminder_alerts_pane.ajax_get();
					}
				});
			}
		};
		
		function draw_note(note) {
			note.created_stamp = +new Date(note.created);
			note.next_stamp = get_next_stamp(note);
			// Extra repeat text info needed
			if(note.remind && note.remind.repeat) {
                note.repeat_text = gettext("Repeat");
                if(note.remind.repeat.days && note.remind.repeat.days.length > 0)
					note.repeat_days_text = note.remind.repeat.days.map(function(day){return days[day];}).join(', ');
			}
			return $('#timeline_note_tmpl').tmpl2(note);
		}

		var dt_format = 'ddd DD MMM YYYY HH:mm';
		function ui_note(note) {
			note.created = moment(note.created * 1000).format(dt_format);
			if(note.remind) {
				note.remind.next_pretty = (note.remind.next > 0) ?
					moment(note.remind.next * 1000).format(dt_format) : gettext('Done');
			}
		}
		
		function get_next_stamp(note) {
			 //Shove non-reminders to the end of the sorting list, and
			// ensure the default sort shows the most pressing reminders first
			var apocalypse = 9999999999999;
			return note.remind ? -(note.remind.next || apocalypse-1) : -apocalypse;
		}
			
		function sort(e) {
			var $sort = $(e.target);
			var $notes = $('#notes_wrapper').children();
			var sort_col_new = $sort.attr('data-sort');
			var sort_integer = $sort.attr('data-sort_type') === 'number';
			
			if(sort_col_new === sort_col) {
				//Change sort direction
				sort_down = !sort_down;
			} else {
				//Change sort column
				sort_col = sort_col_new;
				$sort.addClass('sorting')
							.siblings().removeClass('sorting');
			}
			//Sort arrows
			$sort.children().attr('class', 'icon-arrow-'+ (sort_down ? 'down':'up'));
			$sort.siblings().children().attr('class', '');
			
			var sort_attr = 'data-sort_'+ sort_col;
			$notes.sort(function(a, b) {
				var va = sort_integer ? parseInt(a.getAttribute(sort_attr)) : a.getAttribute(sort_attr);
				var vb = sort_integer ? parseInt(b.getAttribute(sort_attr)) : b.getAttribute(sort_attr);
				if(sort_down) {
					return (va < vb) ? 1 : -1;
				} else {
					return (va < vb) ? -1 : 1;
				}
			});
			$('#notes_wrapper').append($notes);
		}
		
		function filter(search) {
			var notes_list = $('#notes_wrapper').children();
			if(search.length > 1) {
				var search_list = search.toLowerCase().split(' ');
				notes_list.each(function() {
				  var $note = $(this);
				  var note = all_notes[$note.data('id')];
				  var description = ((note.subject || '') +' '+ (note.detail || '')).toLowerCase();
				  var reveal = true;
				  for(var i in search_list) {
					if(description.indexOf(search_list[i]) === -1) {
					  reveal = false;
					  break;
					}
				  }
				  $note.toggle(reveal);
				});
			} else {
				notes_list.show();
			}
		}
	}
	
	function RightbarPane() {
		var transition_duration = 900; //ms duration for toggle/slide effects
		
		this.draw = function() {
			$('#timeline_rightpane_toggle').click(toggle);

			$('#timeline_right_tabs div').click(function() {
				//Tab change
				var $tabs = $(this).parent();
				$(this).addClass('selected')
					.siblings('.selected').removeClass('selected');
				var new_tab = $tabs.find('div.selected').attr('data-tab');
				$('#timeline_rightpane_toggle, #timeline_rightpane')
						.toggleClass('expanded', new_tab !== 'events', transition_duration/2);
				$('#timeline_superwrapper').toggleClass('shrunk', new_tab !== 'events', transition_duration/2);
				//Tab content change
				$tabs.siblings().addClass('tab_hidden')
					.filter('#timeline_'+ new_tab).removeClass('tab_hidden');
				//Draw the pane inner-content
				switch(new_tab) {
					case 'events':
						events_pane.draw();
						break;
					case 'notes':
						notes_pane.draw();
						break;
					case 'settings':
						settings_pane.draw_options();
				}
			});
			
			function toggle() {
				$('#timeline_rightpane_toggle').toggleClass('icon-arrow-right icon-arrow-left')
					   .toggleClass('timeline_rightpane_hidden', transition_duration);
				$('#timeline_rightpane').toggle('slide', {direction: 'right'}, transition_duration);
				$('#timeline_superwrapper').toggleClass('expanded', transition_duration);
				monitor_page.timeline_rightpane_hidden = !monitor_page.timeline_rightpane_hidden;
			}
			
			if(monitor_page.timeline_rightpane_hidden) {
				monitor_page.timeline_rightpane_hidden = false; //gets toggled below
				toggle();
			}
		};
	}
	
	function SettingsPane() {
		var cookie_name = 'monitor_timeline_settings';
		
		var good_intervals = [5,10,15,20,30,60]; //in minutes (for the time steps)
		var zoom_values = [50, 75, 100, 150, 200]; //in %
		//Content kinds that can be eventised
		this.eventable_content_types = ['advertisement', 'feature', 'trailer', 'placeholder'];
		
		//Read-only defaults
		var configurable_settings = {
			shrunk: false,
			zoom_level: 100,
			show_pack_times: true,
			trailer_is_event: false,
			advertisement_is_event: true,
			credits_is_event: true,
			preshow_breakdown: true,
			allow_manual_shows: false,
			event_kill: -20,
			event_alert: 300,
			event_warn: 900
		};
		
		this.get_settings = function() {
			//Configurable settings are read from cookies and merged into here;
			//a separate list is maintained as some settings are derived
			settings = {};
			
			var cookies = JSON.parse($.cookie('read', cookie_name)) || {};
			$.each(configurable_settings, function(setting_name, setting) {
				var cookie_val = cookies[setting_name];
				if(cookie_val !== undefined) {
					switch(typeof setting) {
						case('boolean'):
							setting = (cookie_val === true);
							break;
						case('number'):
							setting = parseFloat(cookie_val);
							break;
						default:
							setting = cookie_val;
					}
				}
				settings[setting_name] = setting;
			});
			update_derived();
		};
		
		this.draw = function() {
			update_zoom();
		};
		
		//Draws the options pane (for changing settings)
		this.draw_options = function() {
			$('#timeline_settings_tmpl').tmpl2(settings, '#timeline_settings_form');
			$('.setting_boolean > span').switch();
            $('#timeline_setting_zoom_level').multi({
                options: zoom_values.map(function(val){return {value: val, text: val};}),
                selected: settings.zoom_level
            });
			helpers.set_buttons('#timeline_settings_buttons', [
				{
					id: 'timeline_settings_save',
					text: gettext('Save'),
					image: 'save',
					onClick: write_settings
				},
				{
					id: 'timeline_settings_defaults',
					text: gettext('Restore Defaults'),
					onClick: restore_defaults
				}
			]);
		};
		
		function write_settings() {
			$.each(configurable_settings, function(setting_name, setting) {
				var $setting = $('#timeline_setting_'+ setting_name);
				if(!$setting.length) {
					//Not configurable through the dedicated settings area
					return true;
				}
				if($setting.attr('id') === 'timeline_setting_zoom_level') {
					//Special case
					setting = parseInt($setting.multi('val'));
					update_zoom(setting);
				} else {
					//Sanitise them first
					switch(typeof setting) {
						case('boolean'):
							setting = $setting.switch('on');
							break;
						case('number'):
							setting = parseFloat($setting.val());
							if(!isNaN(setting)) {
								if($setting.hasClass('shadow_negative')) {
									//When user is shown an inverted number for ease of understanding
									setting = -setting;
								}
							} else {
								setting = settings[setting_name];
							}
							break;
						default:
							setting = $setting.val();
					}
				}
				settings[setting_name] = setting;
			});
			common_save();
		};

		function restore_defaults() {
			$.each(configurable_settings, function(setting_name, setting) {
				settings[setting_name] = setting;
			});
			update_zoom();
			common_save();
		}
		
		function common_save() {
			// Persists configurable settings to disk
			var cookie_settings = {};
			$.each(configurable_settings, function(setting_name) {
				cookie_settings[setting_name] = settings[setting_name];
			});
			$.cookie('write', cookie_name, JSON.stringify(cookie_settings), 10000);
			
			update_derived();
			notification.info_msg(gettext('Saved'), gettext('Save'));
			settings_pane.draw_options();
		}
		
		function update_derived() {
			//Non-cofigurable settings that are nonetheless convenient to store on the settings obj
			settings.zoom_values = zoom_values;
			settings.feature_is_event = true;
			settings.placeholder_is_event = true;
			settings.auto_tooltip_start = 30;
			settings.auto_tooltip_end = -5;
			settings.auto_tooltip_trigger_rate = Math.min(
					Math.ceil(settings.auto_tooltip_start + settings.auto_tooltip_end) / 5,
					10
			);
			// Update stuff affected by settings
			$('#timeline_pane').toggleClass('small', settings.shrunk);
			$('#timeline_shows_pane').toggleClass('no_preshow_breakdown', !settings.preshow_breakdown);
			timebar.update_position();
		}
		
		function update_zoom(zoom) {
			var scale_factor = (zoom || settings.zoom_level) / 100;
			$.each(timeline.original, function(key, val) {
				timeline[key] = val * 60 / scale_factor;
			});
			//Make sure the interval is a multiple of a nice number
			var interval_in_mins = timeline.interval / 60;
			if(!$._in(interval_in_mins, good_intervals)) {
				var nearest = 99999;
				//Find the nearest nice interval
				$.each(good_intervals, function(i, good_interval) {
					var diff = Math.abs(interval_in_mins - good_interval);
					if(diff < nearest) {
						timeline.interval = good_interval * 60;
						nearest = diff;
					}
				});
			}
			if(timebar.start_time()) {
				redraw();
			}
		}
	}

	function Show(schedule) {
		var merged_content_kind = 'transitional';
		var mergeable_content_kinds = ['psa', 'pattern', 'policy', 'rating', 'unknown'];
		var max_mislabelled_feature_duration = 300; //Features shorter than this are considered ads
		var max_merge_duration = 15; //Max duration for a potentially mergeable merge-type CPL
		var max_fleeting_duration = 120; //Max duration for fleeting 'transitional' packs
		
		var show = this;
		
		show.unscheduled = schedule.unscheduled; //Shows can also come from manual playback
		show.device_id = schedule.device_information.device_uuid;
		
		var adj = show.unscheduled ? 0 : ($device_store.devices[show.device_id].time_ref - $device_store.devices[show.device_id].time) / 1000;
		show.start = schedule.start_timestamp + (adj || 0);
		show.duration = 0;
		show.end = show.start + show.duration;
		
		show.playlist_id = schedule.device_information.device_playlist_uuid;
		show.type = schedule.type;
		show.title = schedule.display_name;
		show.id = schedule.uuid;
		show.pos = schedule.pos_information;
		show.valid_pos = (show.pos && show.pos.seats_sold > 0 && show.pos.seats_available > 0);
		show.issues = {
			kdm: schedule.kdm_issue,
			content: schedule.content_issue,
			playlist: schedule.playlist_issue
		};
		show.has_issue = (show.issues.kdm || show.issues.content || show.issues.playlist);
		show.left = get_left();
		show.died = false;
		show.has_intermission = false;
		show.intermission_complete = false;
		show.content_kinds = [];

		show.playlist = {};
		var cpls = [];
		var cumulative_block_duration = 0;
		//Add the playlist
		if(schedule.playlist) {
			show.duration_cpls = 0;
			for(var id = 0; id < schedule.playlist.length; id++) {
				var event = schedule.playlist[id];
				var next_event = schedule.playlist[id+1];
				var next_event_kind = null;
				if(next_event) {
					next_event_kind = _sanitise_content_kind(next_event);
				}

				var cpl = new Cpl(event, id);
				cpls.push(cpl);
				show.duration_cpls += (cpl.duration || 0);

				if( next_event_kind === null ||
				   (cpl.content_kind !== next_event_kind && !(cpls.length === 1 && cpl.mergeable()))
				   ) {
					var pack = new Pack(cpls);
					show.playlist[id] = pack;
					cpls.length = 0;
					show.content_kinds.push(cpl.content_kind);
				}
			};
			show.duration += show.duration_cpls;
			show.end = show.start + show.duration;
//			show.duration_schedule_diff = Math.round(show.duration_cpls - schedule.duration);
//			console.log('Diff for ' + show.title +' #'+ show.id +': '+ show.duration_schedule_diff +' sched');
		} else {
			// Event Placeholder
			show.placeholder = schedule.placeholder_information.placeholder_type;
			show.duration = schedule.duration;
			show.end = show.start + show.duration;
			var text = placeholder_types[show.placeholder];
			var fake_cpl = new Cpl({
				content_title: text,
				content_kind: 'placeholder',
				duration_in_seconds: show.duration,
				automation: null
			}, 0);
			show.playlist[0] = new Pack([fake_cpl]);
			show.playlist[0].placeholder_text = text;
		}
		
		//Try to get the proper feature Title
		if(show.pos && show.pos.feature_title) {
			show.feature_title = show.pos.feature_title;
		} else { //Final ditch: look in templating issues for title matching message
			for(var i = 0; i < (schedule.templating_issues || []).length; i++) {
				var message = schedule.templating_issues[i].message;
				if(message === 'Title specified' || message.indexOf('Matched Title') !== -1) {
					show.feature_title = schedule.templating_issues[i].text;
					break;
				}
			}
		}

		show.update = function() {
			show.time_to_start = show.start - now;
			show.percent_complete = -show.time_to_start / show.duration * 100;

			$.each(show.playlist, function(id, pack) {
				pack.update();
			});
			show.recently_adjusted = false;
		};

		show.recalculate_widths = function() {
			show.width = get_width();
			cumulative_block_duration = 0;
			$.each(show.playlist, function(id, pack) {
				pack.recalculate_width();
			});
		};
		show.recalculate_widths();

		show.seconds_in = function() {
			var in_secs = -show.time_to_start;
			if(show.has_intermission && show.intermission_ended()) {
				//playback spl position data ignores intermission
				in_secs -= show.intermission_duration;
			}
			return in_secs;
		};

		show.is_playing = function() {
			return show.percent_complete >= 0 && show.percent_complete <= 100;
		};
		show.is_finished = function() {
			return show.percent_complete > 100;
		};
		show.has_finished = show.is_finished();
		show.is_unstarted = function() {
			return show.percent_complete < 0;
		};

		show.adjust = function(adjustment) {
			show.start -= adjustment;
			show.left = get_left();
			show.end = show.start + show.duration;
			show.recently_adjusted = true;
		};

		show.refresh = function() {
			show.left = get_left();
			show.width = get_width();
		};
		
		show.get_tooltip_data = function() {
			var position;
			//Smart positioning
			var show_midpoint = show.start + show.duration / 2;
			var period = timebar.get_period();
			var safety = timeline.interval * 0.5;
			//Don't know why, but qtip doesn't handle this very well so have to force it
			if(show_midpoint < period.start_time + safety) {
				position = show.has_issue ? {at: 'right center', my: 'center'} : {at: 'top right', my: 'bottom left'};
			} else if(show_midpoint > period.end_time - safety) {
				position = show.has_issue ? {at: 'left center', my: 'center'} : {at: 'top left', my: 'bottom right'};
			} else {
				position = show.has_issue ? {at: 'center', my: 'center'} : {at: 'top center', my: 'bottom center'};
			}
			
			if(show.placeholder) {
				return {placeholder: show.duration, position: position};
			}
			
			var data = {
				preshow_length: 0,
				issues: show.issues,
				has_issue: show.has_issue,
				position: position
			};
			
			var feature_encountered;
			$.each(show.playlist, function(id, pack) {
				if(pack.is_feature) {
					feature_encountered = true;
					data.feature = pack;
				}
				if(!feature_encountered) {
					data.preshow_length += pack.duration;
				}
			});
			return data;
		};
		
		function get_left() {
			return (show.start - timebar.start_time()) * 100 / timeline.view_size;
		}
		function get_width() {
			return show.duration / timeline.view_size * 100;
		}

		function Pack(cpls) {
			var pack = this;
			var end_cpl = cpls[cpls.length-1];

			pack.content_kind = end_cpl.content_kind;
			pack.id = end_cpl.id;
			pack.event_id = show.id +'-'+ pack.id;
			pack.title = end_cpl.title;

			pack.duration = 0;
			for(var i = 0; i < cpls.length; i++) {
				pack.duration += cpls[i].duration;
			}
			if(pack.content_kind === merged_content_kind && pack.duration < max_fleeting_duration) {
				pack.content_kind = 'fleeting';
				pack.is_fleeting = true;
			}
			
			var first_of_kind = !$._in(pack.content_kind, show.content_kinds);
			pack.ever_eventable = first_of_kind && $._in(pack.content_kind, settings_pane.eventable_content_types);
			
			if(pack.content_kind === 'feature') {
				pack.is_feature = true;
				//Get relevant cues - intermission and credit offset
				if(end_cpl.automation.length > 0) {
					add_cue_specifics();
				}
			}
			pack.cumulative_duration = cumulative_block_duration;
			cumulative_block_duration += pack.duration;

			var old_active;
			pack.update = function() {
				var starting_in = show.time_to_start + pack.cumulative_duration;
				var ending_in = starting_in + pack.duration;
				pack.time_to_start = starting_in;
				pack.time_to_end = ending_in;
				pack.percent_complete = (pack.duration > 0) ? (-starting_in / pack.duration * 100) : 0;
				old_active = pack.active;
				pack.active = starting_in < 0 && ending_in > 0;
				if(pack.is_feature) {
					if(pack.has_credits) {
						pack.time_to_credits = ending_in - pack.credits_length;
					}
					if(pack.intermission) {
						pack.time_to_intermission = starting_in + pack.intermission.offset;
						pack.time_to_intermission_end = pack.time_to_intermission + pack.intermission.duration;
					}
				}
			};
			//Purely for performance
			pack.active_changed = function() {
				return old_active !== pack.active;
			};
			
			pack.eventable = function() {
				return pack.ever_eventable && settings[pack.content_kind + '_is_event'];
			};
			pack.initially_eventable = pack.eventable();
			
			pack.hide_time = function(previous_pack) {
				return !pack.active && ( //allow display for active packs
					pack.time_to_end < 0 || //pack finished
					previous_pack.time_to_start > 0 //preceding pack unstarted
				);
			};

			pack.recalculate_width = function() {
				pack.left = (cumulative_block_duration / show.duration) * 100;
				pack.width = pack.duration / show.duration * 100;
				cumulative_block_duration += pack.duration;
			};

			pack.get_events = function() {
				var id = pack.event_id;
				var screen = helpers.get_device_name(show.device_id);
				// Pack start
				var start_event_name = gettext('%content_kind% start').replace('%content_kind%', content_kind_reference[pack.content_kind] || pack.title);
				events_pane.add(id, screen, start_event_name, function(){return pack.time_to_start;});
				if(pack.is_feature) {
					// Credits start
					if(pack.has_credits && settings.credits_is_event) {
						events_pane.add(id, screen, gettext('Credits'), function(){return pack.time_to_credits;});
					}
					// Feature end
					events_pane.add(id, screen, gettext('Feature end'), function(){return pack.time_to_end;});
					// Intermission start
					if(pack.intermission) {
						events_pane.add(id, screen, gettext('Intermission'), function(){return pack.time_to_intermission;});
						//End of an intermission is flaky so best not to eventise it.
					}
				}
				// Placeholder end
				if(show.placeholder) { 
					events_pane.add(id, screen, gettext('%placeholder% end'.replace('%placeholder%', pack.title)), function(){return pack.time_to_end;});
				}
			};
			
			function add_cue_specifics() {
				for(var i = 0; i < end_cpl.automation.length; i++) {
					var automation = end_cpl.automation[i];
					//Credits offset
					var automation_store = AUTOMATION_CONFIGURATION.automation_configuration[automation.name];
					if(automation_store && automation_store.credits) {
						pack.has_credits = true;
						pack.credits_length = (automation.type_specific.offset_from === 'start') ? 
												(end_cpl.duration - automation.type_specific.offset_in_seconds) :
												automation.type_specific.offset_in_seconds;
						pack.credits_width = pack.credits_length / pack.duration * 100;
					} //Intermission
					else if(automation.type.indexOf('intermission') !== -1) {
						pack.intermission = {
							offset: automation.type_specific.offset_in_seconds,
//							restart: parseInt(automation.type_specific.restart_in_seconds),
							duration: automation.type_specific.duration_in_seconds
						};
						var excess_duration = pack.intermission.duration;
						pack.duration += excess_duration;
						show.duration += excess_duration;

						pack.intermission.left = pack.intermission.offset / pack.duration * 100;
						pack.intermission.width = pack.intermission.duration / pack.duration * 100;
						
						show.has_intermission = true;
						show.intermission_duration = pack.intermission.duration;
						show.intermission_playlist_id = automation.type_specific.spl_uuid;
						
						show.intermission_percent_complete = function() {
							return -pack.time_to_intermission / pack.intermission.duration * 100;
						};
						show.intermission_ended = function() {
							return show.intermission_complete || pack.time_to_intermission_end < 0;
						};
					}
				}
			}
		}
		
		function Cpl(cpl, id) {
			this.title = cpl.content_title || show.title;
			this.content_kind = _sanitise_content_kind(cpl);
			this.duration = cpl.duration_in_seconds;
			this.id = id;
			this.automation = cpl.automation;
			
			this.mergeable = function() { //Don't count as separate pack
				return this.content_kind === merged_content_kind && this.duration <= max_merge_duration;
			};
		}
		function _sanitise_content_kind(cpl) {
			var ck = cpl.content_kind || 'unknown';
			// Reduce set of content_kinds for better merging
			if(ck === 'teaser') {
				ck = 'trailer';
			} else if($._in(ck, mergeable_content_kinds)) {
				ck = merged_content_kind;
			} // Special case for mislabelled CPLs, which are probably ads
			else if(ck === 'feature' && cpl.duration_in_seconds < max_mislabelled_feature_duration) {
				ck = 'advertisement';
			}
			return ck;
		}
		
		show.update();
	}

	function tip_autoshow($tip, time, force_show) {
		time = Math.round(time);
		var tip = $tip.qtip('api');
		var triggerable = force_show ||
						((time % settings.auto_tooltip_trigger_rate) === 0)
						|| (time === settings.auto_tooltip_end)
						|| (time === settings.auto_tooltip_start);
		if(tip && triggerable) {
			if((time > settings.auto_tooltip_end) && (time <= settings.auto_tooltip_start)) {
				$tip.trigger('mouseenter');
				//Ensure it hides, but only once
			} else if((time <= settings.auto_tooltip_end) && 
						(time >= (settings.auto_tooltip_end - settings.auto_tooltip_trigger_rate))) {
				$tip.trigger('mouseleave');
			}
		}
	}
	
	function dom_time_needs_updating(time) {
		time = Math.round(time);
		//Purely for performance reasons, limit frequent updates if not required
		return (Math.abs(time) < 60) || ((time % 60) === 59) || (((time % 60) === 0) && time < 0);
	}

	function tooltip_options(content, styles, position, fix) {
		var opts = {
			content: content,
			position: position,
			show: {
				event: 'click mouseenter',
				effect: false,
				delay: 20
			},
			hide: {
				event: 'mouseleave',
				delay: 40,
				fixed: fix || false,
				effect: false
			},
			style: {
				classes: 'qtip-shadow qtip-rounded '+ styles,
				tip: {
					height: fix ? 1 : 5
				}
			}
		};
		opts.position.viewport = $(window);
		return opts;
	}
	
	function get_tms_time() {
		return ($complex_status.core_time + Date.parse(new Date()) - $complex_status.browser_time_ref) / 1000;
	}
	
	function unixtime_24hr_format(unix_timestamp) {
		var time = new Date(unix_timestamp * 1000);
		return time.getHours() + ':' + $.time_helper(time.getMinutes());
	}
	
	this.draw = draw;
	this.update = device_pane.update;
	this.kill = kill;
}
