var playlist_edit_page = new PlaylistEditPage();

function PlaylistEditPage() {
    var self = this;
    self.playlist = {};
    self.load_max = 150;
    self.contents = [];
    self.contents_count = 0;
    self.content_availability = {};
    self.automation = {};
    self.device_automation_dict = {};
    self.packs = {};
    self.patterns = [];
    self.placeholders = {};
    self.macro_packs = {};
    self.titles = {};
    self.server_id;
    self.playlist_uuid;
    self.playlist_matches = {};

    //Templates
    self.main_tmpl = '#playlist_edit_tmpl';

    self.temp_move_index;
    self._changes_made = false;
    self.transfer_dialog = null;
    self.mouse_x = 0;
    self.mouse_y = 0;

    self.drag_list = null;


    //Methods
    self.open = function(server_id, playlist_uuid, playlist_title) {
        var doc = $(document);
        doc.trigger('page_load');
        doc.one('page_load', _close_page);
        
        self.server_id = server_id;
        self.playlist_uuid = playlist_uuid;
        self.playlist_title = playlist_title;
        self.content_availability = {};

        nav_select('content', 'playlists');

        $('#main_section').html($(self.main_tmpl).tmpl({selected_device: $device_store.devices[server_id]}));

        var content_tabs = [
            {'tab_value':'content', 'tab_translated_title':gettext('Content')},
            {'tab_value':'automation', 'tab_translated_title':gettext('Automation')},
        ];

        content_tabs.push({'tab_value':'pack', 'tab_translated_title':gettext('Pack')});

        if (helpers.supported('playlist_pattern',$device_store.devices[self.server_id].type) && $complex_status.patterns_enabled)
            content_tabs.push({'tab_value':'pattern', 'tab_translated_title':gettext('Pattern')});

        if( screenwriter_plus ){
            if (helpers.supported('playlist_title',$device_store.devices[self.server_id].type))
                content_tabs.push({'tab_value':'title', 'tab_translated_title':gettext('Title')});

            if (helpers.supported('playlist_placeholder',$device_store.devices[self.server_id].type))
                content_tabs.push({'tab_value':'placeholder', 'tab_translated_title':gettext('Placeholders')});
        }

        if (helpers.supported('playlist_macro_placeholder',$device_store.devices[self.server_id].type))
            content_tabs.push({'tab_value':'macro_pack', 'tab_translated_title':gettext('Macro Packs')});

        $('#playlist_edit_content_section').html($('#playlist_edit_content_section_tmpl').tmpl({
            'content_tabs': content_tabs
        }));

        $('#main_section').on('change.playlist_edit','.jq_playlist_display_mode', function(){
            self.playlist.is_3d = $('#playlist_edit_display_mode_3d').is(':checked');
            self.playlist.is_hfr = $('#playlist_edit_display_mode_hfr').is(':checked');
            self.playlist.is_4k = $('#playlist_edit_display_mode_4k').is(':checked');
            self.changes_made(true);
        });

        $(document).trigger('page_loaded');

        var buttons = [];
        if(helpers.is_allowed('tms_schedule_action')){
            buttons.push({text:gettext('Save'), image:'save', onClick: self.save, disabled: true, _class:'jq_enable_on_changes text_hideable'});
            buttons.push({text:gettext('Save As'), image:'save', onClick: self.save_as});
            if($device_store.devices[server_id].type == "aamlms"){
                buttons.push({text:gettext('Save and Sync'), image:"sync", onClick: self._save_and_sync, disabled: true, _class:'jq_enable_on_changes'});
            }
            buttons.push({title:gettext('Transfer'), image:'transfer', onClick: self.transfer, _class:'jq_disable_on_changes jq_disable_on_template text_hideable'});
            buttons.push({title:gettext('Change cue offset view'), image:'cue_offset', type: 'toggle', onClick: cue_offset_toggle, _class:"jq_cue_toggle float_right"});
        }

        helpers.set_buttons('#playlist_actions', buttons);

        if (eval($.cookie('read', 'cue_offset_on'))){
            $("#"+$(".jq_cue_toggle").attr("for")).attr("checked", "checked").button("refresh");
            cue_offset_toggle();
        }

        self.drag_list = new DragList({
            search_dom: ".playlist_edit_content_body_search",
            search_input: "#search_input",
            list_dom: ".playlist_edit_content_body_main",
            device_id: server_id,
            draggable_defaults: draggable_defaults
        });

        _load_automation();
        _load_patterns();

        if (helpers.supported('playlist_macro_placeholder',$device_store.devices[self.server_id].type))
            _load_macro_packs();

        if( screenwriter_plus ){
            _load_placeholders();
        }

        self._changes_made = false;

        _load_playlist();
        $('.playlist_edit_content_tab').click(_select_content_tab);
        $('.playlist_edit_content_tab:first').click();

        $('#main_section').on(
            'click.playlist_edit',
            '#clear_filter_button',
            function(){
                var selected_tab = $(".playlist_edit_content_tab.selected").attr("tab_value");
                $('#search_input').val("");
                $("#playlist_edit_pack_date").val("");
                $("#playlist_"+selected_tab+"_search_filter").val("").trigger("change");
            }
        );

    };

    function cue_offset_toggle() {
        var checked = $("#"+$(".jq_cue_toggle").attr("for")).is(":checked");
        $('#playlist_edit_playlist_section').toggleClass('cue_offset_on', checked);
        $.cookie('write', 'cue_offset_on',checked,0);
    }

    function availability_tip(dom, cpl_uuid){
        dom = $(dom).children('div');
        if(!self.content_availability[cpl_uuid]){
            helpers.attach_availability_tip({
                dom: dom,
                cpl_uuid: cpl_uuid,
                viewport: $('#playlist_edit_content_section'),
                ready: true
            });
            self.content_availability[cpl_uuid] = true;
        }
    }

    self.changes_made = function(changes) {
        self._changes_made = changes;
        $('.jq_enable_on_changes').button('option', 'disabled', !changes);
        $('.jq_disable_on_changes').button('option', 'disabled', changes);
        g_prevent_navigation = changes;
        $('#playlist_edit_display_mode_3d').attr("checked", self.playlist.is_3d).button("refresh");
        $('#playlist_edit_display_mode_4k').attr("checked", self.playlist.is_4k).button("refresh");
        $('#playlist_edit_display_mode_hfr').attr("checked", self.playlist.is_hfr).button("refresh");
    };

    self.save = function() {
        if (!self._changes_made) {
            notification.info_msg(gettext('There are no changes'));
            return;
        }else if( !_validate_placeholders() ){
            notification.error_msg(gettext("Remove duplicate Placeholders from the Playlist"));
            return;
        }else{
            var is_3d_override = undefined,
                is_hfr_override = undefined;
            if(helpers.supported('doremi_3d_mode', $device_store.devices[self.server_id].type))
                is_3d_override = self.playlist.is_3d;
            if (helpers.supported('doremi_hfr_mode', $device_store.devices[self.server_id].type))
                is_hfr_override = self.playlist.is_hfr;
            var buttons = [];
            var save_playlist_call = helpers.ajax_call({
                url:'/core/playlist/save',
                data:{'device_id': self.server_id, 'playlist':self.playlist.return_saveable(is_3d_override, is_hfr_override)},
                success_function:self._save_callback,
                complete_function:function(){
                    $('.jq_enable_on_success').toggleClass('disabled',false);
                }
            });
        }
    };

    function _validate_placeholders(){
        var present_placeholders = [];
        for(var event_index in self.playlist.events){
            if(self.playlist.events[event_index].type == "placeholder"){
                if( present_placeholders.indexOf(self.playlist.events[event_index].title) == -1){
                    present_placeholders.push(self.playlist.events[event_index].title);
                }else{
                    $(".jq_event.placeholder").each(function(){
                        if( $(this).find(".element_title").text() == self.playlist.events[event_index].title){
                            $(this).effect('pulsate', {times:2}, 400);
                        }
                    });
                    return false;
                }
            }
        }
        return true;
    }

    self._save_callback = function(input) {
        input = input.messages[0];
        if (input['action_id'] != undefined) {
            $('#playlist_edit_save_state').attr('action_id', input['action_id']);
            $action_store.actions[input['action_id']].callback = function(action_id, success) {
                if (success) {
                    self.playlist_uuid = self.playlist.uuid = input['playlist_uuid'];
                    history.replaceState(null, null, '#playlist_edit_page#'+self.server_id+'#'+self.playlist_uuid);
                    _load_playlist();
                    self.changes_made(false);
                }
            };
        }
    };


    self.save_as = function(){
        if( !_validate_placeholders() ){
            notification.error_msg(gettext("Remove duplicate Placeholders from the Playlist"));
        }else{
            new SaveDialog({
                "save_function": _save_as,
                "text": self.playlist.title
            }).open();
        }
    };

    self._save_and_sync = function(){
        if (!self._changes_made) {
            notification.info_msg(gettext("There are no changes"));
            return;
        }else if( !_validate_placeholders() ){
            notification.error_msg(gettext("Remove duplicate Placeholders from the Playlist"));
            return;
        }else{
            helpers.ajax_call({
                url: '/core/playlist/playlist',
                data: {
                    playlist_ids : [self.playlist.uuid]
                },
                success_function:function(input){
                    var show_these_devices = [];
                    var hide_these_devices = [];
                    var selected_content = [{'title' : self.playlist.title, 'id' : self.playlist.uuid}];

                    if(self.playlist_uuid){
                        $.each(input.data, function(device_id, device){
                            if (!device[self.playlist_uuid].error_messages){
                                show_these_devices.push(device_id);
                            }else{
                                hide_these_devices.push(device_id);
                            }
                        });
                    }

                    var save_this = function(){
                        var is_3d_override = undefined,
                            is_hfr_override = undefined;
                        if(helpers.supported('doremi_3d_mode', $device_store.devices[self.server_id].type))
                            is_3d_override = self.playlist.is_3d;
                        if (helpers.supported('doremi_hfr_mode', $device_store.devices[self.server_id].type))
                            is_hfr_override = self.playlist.is_hfr;
                        return helpers.ajax_call({
                            url:'/core/playlist/save',
                            data:{'device_id': self.server_id, 'playlist':self.playlist.return_saveable(is_3d_override, is_hfr_override)},
                            success_function:self._save_callback,
                            complete_function:function(){$('.jq_enable_on_success').toggleClass('disabled',false);}
                        });
                    };

                    if(show_these_devices.length < 2){
                        save_this();
                    }else{
                        buttons = [{
                            'text': gettext('Save and Sync'),
                            'action': function()
                            {
                                var not_before = self.transfer_dialog.dialog_get_transfer_time();
                                if (!not_before)
                                    return false;

                                var selected_devices = self.transfer_dialog.dialog_selected_devices();
                                if(selected_devices.length === 0)
                                    return false;

                                // save the playlist
                                $.when(
                                    save_this()
                                ).done(
                                    function(){
                                        self.feedback_dialog = new AAMFeedbackDialog({
                                            'title' :  'Syncing Playlists',
                                            'selected_device_ids' : selected_devices,
                                            'selected_content' : selected_content
                                        });
                                        self.feedback_dialog.open();
                                        helpers.ajax_call({
                                            url:'/core/playlist/transfer',
                                            data:
                                            {
                                                'not_before': not_before,
                                                'sending_device_id': self.server_id,
                                                'receiving_device_ids': selected_devices,
                                                'playlist_ids': [self.playlist.uuid]
                                            },
                                            success_function: self.feedback_dialog._global_content_callback
                                        });
                                    }
                                );
                            }
                        }];
                        self.transfer_dialog = new AAMTransferDialog({
                            'title': gettext('Save and Sync'),
                            'buttons': buttons,
                            hbtemplate: '#glob_transfer_tmpl',
                            'pre_selected_ids': show_these_devices,
                            'hidden_device_ids': hide_these_devices,
                            'selected_content': selected_content,
                            'selected_devices_caption': gettext("Devices on which this Playlist exists"),
                        });
                        self.transfer_dialog.open(true);
                    }
                }
            });
        }
    };

    function check_title(title){
        var exists = false;
        helpers.ajax_call({
            url: '/core/playlist/playlist',
            data:{request_data_items: ['title']},
            success_function:function(data){
                for( var device_uuid in data.data){
                    for(var playlist_uuid in data.data[device_uuid]){
                        if(title.toLowerCase() == data.data[device_uuid][playlist_uuid].title.toLowerCase()){
                            exists = true;
                            break;
                        }
                    }
                }
                if(!exists || confirm(gettext("A playlist with this name already exists. Do you want to create another one?"))) {
                    create_playlist(title);
                }
            }
        });
    }

    function _save_as(title) {
        self.playlist.title = title;
        self.playlist.uuid = undefined;
        var exists = false;
        helpers.ajax_call({
            url: '/core/playlist/playlist',
            data:{request_data_items: ['title']},
            success_function:function(data){
                for( var device_uuid in data.data){
                    for(var playlist_uuid in data.data[device_uuid]){
                        if(title.toLowerCase() == data.data[device_uuid][playlist_uuid].title.toLowerCase()){
                            exists = true;
                            break;
                        }
                    }
                }
                if(!exists || confirm(gettext("A playlist with this name already exists. Do you want to create another one?"))) {
                    helpers.ajax_call({
                        url:'/core/playlist/save',
                        data:{'device_id': self.server_id, 'playlist':self.playlist.return_saveable(self.playlist.is_3d, self.playlist.is_hfr)},
                        success_function: function(param){
                            dialog.close();
                            var message = param['messages'][0];
                            self.playlist_uuid = message.playlist_uuid;
                            $action_store.actions[message.action_id] = {
                                callback: function(input){
                                    self.changes_made(false);
                                    window.location.hash = '#playlist_edit_page#'+self.server_id+'#'+self.playlist_uuid+'#'+self.playlist.title;
                                },
                                show_pending: true
                            };
                        }
                    });
                }
            }
        });
    }

    self.transfer= function() {
        if (self._changes_made) {
            notification.info_msg('Please save changes first.');
            return;
        }
        helpers.ajax_call({
            url: '/core/playlist/playlist',
            data: {
                playlist_ids : [self.playlist.uuid]
            },
            success_function:function(input)
            {
                var selected_content = [{'title' : self.playlist.title, 'id' : self.playlist.uuid}];
                var playlist_exists = [self.server_id];
                var buttons = [{
                    'text': gettext('Transfer'),
                    'action': function()
                    {
                        var not_before = self.transfer_dialog.dialog_get_transfer_time();
                        if (!not_before)
                            return false;

                        var selected_devices = self.transfer_dialog.dialog_selected_devices();
                        if(selected_devices.length === 0)
                            return false;

                        self.feedback_dialog = new AAMFeedbackDialog({
                            'title' :  gettext('Transferring'),
                            'selected_device_ids' : selected_devices,
                            'selected_content' : selected_content
                        });
                        self.feedback_dialog.open();

                        helpers.ajax_call({
                            url:'/core/playlist/transfer',
                            data:
                            {
                                'not_before': not_before,
                                'sending_device_id': self.server_id,
                                'receiving_device_ids': selected_devices,
                                'playlist_ids': [self.playlist.uuid]
                            },
                            success_function: self.feedback_dialog._global_content_callback
                        });
                    }
                }];

                self.transfer_dialog = new AAMTransferDialog({
                    'title': gettext('Transfer'),
                    'buttons': buttons,
                    hbtemplate: '#glob_transfer_tmpl',
                    'hidden_device_ids': playlist_exists,
                    'selected_content': selected_content
                });
                self.transfer_dialog.open(true);
            }
        });
    };

    function _transfer() {
        //get target device ids
        var transfer_targets = [];
        $('.playlist_transfer_server_button.selected').each(function(){
            transfer_targets.push($(this).attr('device_id'));
        });
        //update success failed transfers on display
        var playlist_json = self.playlist.return_saveable();
        for (var i = 0, transfer_targets_length = transfer_targets.length; i < transfer_targets_length; i++) {
            var tmp_device_id = transfer_targets[i];
            $('.playlist_transfer_server_button[device_id='+tmp_device_id+']').addClass('processing');
            helpers.ajax_call({
                url:'/core/playlist/save',
                data:{'device_id': tmp_device_id, 'playlist':playlist_json},
                complete_variables:{'device_id': tmp_device_id},
                success_function: function(param, cv){
                    var message = param['messages'][0];
                    $('.playlist_transfer_server_button[device_id='+cv.device_id+']').attr('action_id', message.action_id);
                    $action_store.actions[message.action_id] = {
                        show_pending: true,
                        success_class:'success',
                        failure_class:'failed',
                        current_class:'processing'
                    };
                },
                error_function: function(cv) {
                    $('.playlist_transfer_server_button[device_id='+cv.device_id+']').addClass('failed');
                }
            });
        }
    }

    self.filter_drag_generic = function(){
        var search_string = $('#search_input').val();
        $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap').show();
        if (search_string !== ''){
            $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap:not([description*="'+search_string.toLowerCase()+'"])').hide();
        }
    };

    self.filter_drag_pattern = function(){
        var search_string = $('#search_input').val().toLowerCase();
        if (search_string !== '' && search_string.length > 1){
            $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap').hide();
            var search_list = search_string.split(" ");
            $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap').each(function(){
               var show = true;
               var pattern = $(this).attr("description").toLowerCase() + " " + $(this).find(".duration").text().toLowerCase();
               for(var i in search_list){
                   if( pattern.indexOf(search_list[i]) == -1){
                       show = false;
                       break;
                   }
               }
               $(this).toggle(show);
            });
        }else{
            $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap').show();
        }
    };

    self.filter_drag_automation = function(){

        var search_string = $('#search_input').val();
        var automation_filter = $('#playlist_automation_search_filter').val();

        $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap').show();

        if (automation_filter !== '' && automation_filter !== undefined){
            $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap').each(function(){
                if($(this).find('.screen_title[automation_device="'+automation_filter+'"]').length == 0){
                    $(this).hide();
                }
            });
        }

        if (search_string !== ''){
            $('.playlist_edit_content_body_main > .jq_list_edit_drag_item_wrap:not([description*="'+search_string.toLowerCase()+'"])').hide();
        }
    };

    self.scroll_listener = function(){
        if (self.dragging) {
            var pes = $('#playlist_edit_playlist_section');
            var pes_offset = pes.offset();
            if (pes_offset && self.mouse_x > pes_offset.left) {
                var move = false;
                var pes_height = pes.height();
                var pes_scroll_top = pes.scrollTop();

                if (self.mouse_y -75 < pes_offset.top) {
                    pes_scroll_top -= 15;
                    move = true;
                }
                else if (self.mouse_y + 75 > pes_offset.top + pes_height) {
                    pes_scroll_top += 15;
                    move = true;
                }
                if (move) {
                    pes.scrollTop(pes_scroll_top);
                    //we'd love to put a pretend drag event in here... i've tried a few things below to make it happen but that didnt work out
                    //$('.playlist_edit_playlist_container').sortable('refreshPositions');
                    //$('.draggable_clone').trigger(self.mouse_event);
                }
            }
            setTimeout(self.scroll_listener,1000/30);
        }
    };

    function _close_page() {
        $('#main_section').off('.playlist_edit');
        self.contents = [];
        self.packs = {};
        self.placeholders = {};
        self.macro_packs = {};
        self.titles = {};
        self.automation = {};
        self.server_id = undefined;
    }

    function _load_macro_packs(){
        return helpers.ajax_call({ url:'/core/macro_pack/macro_placeholders', success_function:_update_macro_packs});
    }

    function _update_macro_packs(input){
        self.macro_packs = input.data;
    }

    function _load_patterns(){
        return helpers.ajax_call({data:{},url:'/core/content/pattern', success_function:_update_patterns});
    }

    function _update_patterns(data){
        self.patterns = [];
        for(var item in data.data){
            if (data.data[item]['type'] == 'pattern'){
                self.patterns.push(data.data[item]);
            }
        }
    }

    function _load_placeholders() {
        return helpers.ajax_call({data:{sorted_list:true}, url:'/core/placeholder/placeholders', success_function:_update_placeholders});
    }

    function _update_placeholders(input) {
        for(i in input.data){
            var placeholder = input.data[i];
            self.placeholders[placeholder['uuid']] = placeholder;
        }
    }

    function _load_screen_types() {
        return helpers.ajax_call({url:'/core/configuration/screen_type', success_function:_update_screen_types});
    }

    function _update_screen_types(input) {
        self.screen_types = input.data;
    }

    function _load_automation() {
        var request = {
            url: '/core/automation/cues',
            success_function: _update_automation
        };
        //if we are the lms, we want the automation for all devices
        if($device_store.devices[self.server_id].type !== 'aamlms') {
            request.data = {device_ids: [self.server_id]};
        }
        return helpers.ajax_call(request);
    }

    function _update_automation(input) {
        if($device_store.devices[self.server_id].type === 'aamlms'){
            self.automation[self.server_id] = spo.merge_device_automations(input.data);
            self.device_automation_dict = null;
        } else {
            self.automation = input.data;
            self.device_automation_dict = {};
            if (self.automation[self.server_id]) {
                for (var automation_id in self.automation[self.server_id]) {
                    self.device_automation_dict[self.automation[self.server_id][automation_id].name + self.automation[self.server_id][automation_id].type] = true;
                }
            }
            if ($device_store.devices[self.server_id].type === 'gdc') {
                self.automation[self.server_id]['GDC-START-CUE'] = {
                    duration: 0,
                    type: 'gdc_start_cue',
                    name: 'GDC-START-CUE'
                };
            };
        }
    }

    function drag_function(event, ui){
        playlist_edit_page.mouse_x = event.pageX;
        playlist_edit_page.mouse_y = event.pageY;
    }

    function start_function(event, ui){
        $('#playlist_edit_playlist_section').addClass("drop_enabled");
        playlist_edit_page.dragging = true;
        playlist_edit_page.scroll_listener();
    }

    function stop_function(event, ui){
        $('#playlist_edit_playlist_section').removeClass("drop_enabled");
        playlist_edit_page.dragging = false;
    }

    function draggable_helper(){
        return $(this).clone().css({
            'width': $(this).width(),
            'margin': 0
        });
    }

    var draggable_defaults = {
        helper: draggable_helper,
        cursorAt: {
            top: 0
        },
        containment : '#main_section',
        connectToSortable :'.playlist_edit_playlist_container',
        appendTo :'#main_section',
        tolerance :'intersect',
        drag: drag_function,
        start: start_function,
        stop: stop_function
    };

    function draw_titles_tab(){
        $('.playlist_search_filter').val("");
        load_tab(get_titles, function(){
            var drag_list = gen_titles_list();
            self.drag_list.draw({
                main_template: '#playlist_edit_generic_drag_list_tmpl',
                search_template: '#playlist_edit_generic_search_tmpl',
                drag_list: drag_list,
                filter_func: update_titles_tab,
                double_click_func: double_click,
                filter_info: {
                    'total': self.titles_count
                }
            });
        });
    }

    function update_titles_tab(){
        load_tab(get_titles, function(){
            var drag_list = gen_titles_list();
            self.drag_list.update({
                main_template: '#playlist_edit_generic_drag_list_tmpl',
                drag_list: drag_list,
                double_click_func: double_click,
                filter_info: {
                    'total': self.titles_count
                }
            });
        });
    }

    function gen_titles_list(){
        var drag_list = [];
        $.each(self.titles, function(index, item){
            draggable = {
                id : item.uuid,
                name : item.name,
                type : 'title'
            };
            drag_list.push(draggable);
        });
        return drag_list;
    }

    function get_titles(callback){
        helpers.ajax_call({
            url:'/core/paginated/get_datatables_titles',
            data:{
                iDisplayLength: self.load_max,
                sSearch: $('#search_input').val(),
                iSortingCols: 1,
                iSortCol_0: 1,
                sSortDir_0: 'asc'
            },
            success_function: function(data){
                self.titles = data.aaData;
                self.titles_count = data.iTotalDisplayRecords;
                callback();
            }
        });
    }

    function draw_content_tab(){
        $('.playlist_search_filter').val("");
        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.draw({
                main_template: '#playlist_edit_content_drag_list_tmpl',
                search_template: '#playlist_edit_content_search_tmpl',
                drag_list: drag_list,
                filter_func: update_content_tab,
                double_click_func: double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });
            $('#playlist_content_search_filter').on('change', update_content_tab);
            attach_avail_tips();
        });
    }

    function update_content_tab(){
        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.update({
                main_template: '#playlist_edit_content_drag_list_tmpl',
                drag_list: drag_list,
                double_click_func: double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });
            self.content_availability = {};
            attach_avail_tips();
        });
    }

    function attach_avail_tips(){
        $('.jq_playlist_availability_check').each(function(){
            var cpl_uuid = $(this).attr("data-cpl_uuid");
            $(this).mouseover(function(){
                availability_tip(this, cpl_uuid);
            });
        });
    }

    //CAN BE SIMPLIFIED, returned data is now almost exactly right for display
    function gen_content_list(){
        var drag_list = [];
        for (var index = 0; index < self.contents.length; index++) {
            var content = self.contents[index];
            if (content.validation.validation_code == 4)
                continue;
            if (content.validation.error_messages === undefined){
                var draggable = {};
                draggable.content_kind = content.content_kind;

                var validation_code = content.validation.validation_code;

                if (validation_code !== 0) {
                    var validation_info = helpers.content_status_info(validation_code, self.server_id);
                    draggable.validation_error = validation_info.status;
                    draggable.validation_info = validation_info.info;
                }
                if (content.encrypted) {
                    draggable.encrypted = helpers.get_kdm_icon_class(content.validation.valid_now,
                        content.validation.valid_in_future, content.validation.expires_in_24);
                }

                draggable.playback_mode = (content.playback_mode === '3D') ? 'icon-three-d' : 'icon-two-d';
                draggable.subtitled = content.subtitled ? content.subtitle_language || 'XSUB' : false;
                draggable.rating = content.rating;
                draggable.territory = content.territory;
                draggable.description   = content.content_title_text; //text display
                draggable.cpl_uuid      = content.uuid;
                draggable.duration_in_seconds = content.duration_in_seconds;
                draggable.duration_in_frames = content.duration_in_frames;
                draggable.edit_rate = content.edit_rate;
                draggable.video_encoding = content.video_encoding;
                drag_list.push(draggable);
            }
        }
        return drag_list;
    }

    function get_contents(callback){
        helpers.ajax_call({
            url:'/core/paginated/get_draglist_content',
            data:{
                iDisplayLength: self.load_max,
                sSearch: $('#search_input').val(),
                type_filter: $('#playlist_content_search_filter').val(),
                device_uuid: self.server_id
            },
            success_function: function(data){
                for (var i=0; i<data.aaData.length; i++) {
                    data.aaData[i].validation = data.aaData[i].devices[self.server_id];
                    delete data.aaData[i].devices;
                }
                self.contents = data.aaData;
                self.contents_count = data.iTotalDisplayRecords;
                callback();
            }
        });
    }

    function draw_pack_tab(){
        load_tab(get_packs, function(){
            var drag_list = gen_pack_list();
            self.drag_list.draw({
                main_template: '#playlist_edit_pack_drag_list_tmpl',
                search_template: '#playlist_edit_pack_search_tmpl',
                drag_list: drag_list,
                sort_func: _sort_by_name,
                filter_func: update_packs_tab,
                double_click_func: double_click,
                search_params: {'screens': helpers.get_screen_list()},
                filter_info: {
                    'total': self.total_packs
                }
            });
            $('#playlist_pack_search_filter').on('change', update_packs_tab);

            var edit_pack_date = $('#playlist_edit_pack_date');

            edit_pack_date.datepicker({
                showAnim: 'slideDown',
                dateFormat: "yy-mm-dd",
                defaultDate: null,
                altFormat: "yy-mm-dd",
                onSelect: update_packs_tab
            });

            $(window).resize(function(){
                edit_pack_date.datepicker('hide');
            });

        });
    }

    function update_packs_tab(){
        load_tab(get_packs, function(){
            self.drag_list.update({
                main_template: '#playlist_edit_pack_drag_list_tmpl',
                drag_list: gen_pack_list(),
                double_click_func: double_click,
                filter_info: {
                    'total': self.total_packs
                }
            });
        });
    }

    function get_packs(callback){
        helpers.ajax_call({
            data: {
                screen_uuid : $('#playlist_pack_search_filter').val(),
                date: $('#playlist_edit_pack_date').val(),
                search_string: $('#search_input').val(),
                limit: self.load_max
            },
            url:'/tms/get_playlist_edit_packs',
            success_function:function(input){
                self.packs = input.data.pack_list;
                self.total_packs = input.data.total;
                $('#main_section').trigger('pack_change');
                callback();
            }
        });
    }

    function gen_pack_list(){
        var drag_list = [];
        for (var pack_id in self.packs){
            var draggable = new PackObject(self.packs[pack_id]);
            drag_list.push(draggable);
        }
        return drag_list;
    }

    function load_tab(getter, callback){
        var loader = new Loader({target: $(".playlist_edit_content_body")});
        loader.show(function(){
            getter(function(){
                callback();
                loader.hide();
            });
        });
    }

    function _select_content_tab(mouse_event) {
        var cpl_uuid, translated_playback_mode, translated_subtitled, draggable, drag_list;
        drag_list = [];
        var tab_value = $(this).attr('tab_value');
        $(this).addClass('selected').siblings().removeClass('selected');
        if (tab_value === 'content'){
            draw_content_tab();
        }
        else if (tab_value === 'automation'){
            for (var device_id in self.automation) {
                for (var automation_id in self.automation[device_id]) {
                    draggable = {};
                    draggable.id = automation_id;
                    draggable.name = self.automation[device_id][automation_id].name;
                    draggable.automation_type = self.automation[device_id][automation_id].type;

                    if(self.automation[device_id][automation_id].devices){
                        draggable.devices = self.automation[device_id][automation_id].devices;
                    }

                    draggable.is_intermission = false;
                    draggable.is_show_start = false;
                    if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name]) {
                        if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name].show_start) {
                            draggable.is_show_start = true;
                        }
                        if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name].intermission) {
                            draggable.is_intermission = true;
                        }
                        if (AUTOMATION_CONFIGURATION['automation_configuration'][draggable.name].credits) {
                            draggable.is_credits = true;
                        }
                    }

                    drag_list.push(draggable);
                }
            }

            self.drag_list.draw({
                main_template_hb: '#automation_drag_list_tmpl',
                search_template: '#playlist_edit_automation_search_tmpl',
                search_params: {
                    server_id:self.server_id
                },
                drag_list: drag_list,
                drag_params: {
                    helper: function(){
                        return $(this).clone().css({'width': $(this).width(),'margin':0}).addClass('automation');
                    },
                    appendTo:'#main_section',
                    tolerance:'intersect',
                    cursorAt: {
                        top: 0
                    },
                    refreshPositions: true,
                    drag: drag_function,
                    start: function(){
                        playlist_edit_page.dragging = true;
                        playlist_edit_page.scroll_listener();
                    },
                    stop: stop_function
                },
                sort_func: function(a,b){
                    var value = 1;
                    if (a.automation_type.name < b.automation_type.name) {
                        value = -1;
                    }
                    else if (a.automation_type.name > b.automation_type.name) {
                        value = 1;
                    }
                    else if (a.name < b.name) {
                        value = -1;
                    }
                    return value;
                },
                filter_func: self.filter_drag_automation
            });
            $('#playlist_automation_search_filter').change(self.filter_drag_automation);
        }
        else if (tab_value === 'pattern'){
            drag_list = self.patterns.slice(0);
            self.drag_list.draw({
                main_template: '#playlist_edit_pattern_drag_list_tmpl',
                search_template: '#playlist_edit_generic_search_tmpl',
                drag_list: drag_list,
                filter_func: self.filter_drag_pattern
            });
        }
        else if (tab_value === 'pack'){
            draw_pack_tab();
        }
        else if (tab_value === 'title'){
            draw_titles_tab();
        }
        else if (tab_value === 'placeholder' || tab_value === 'macro_pack'){
            $.each(_get_items(tab_value), function(index, item){
                draggable = {
                    id : item.uuid,
                    name : item.name,
                    type : tab_value
                };
                drag_list.push(draggable);
            });

            //Mega credit offset hack, pull out credit offset from list
            var i = drag_list.length;
            var credit_offset = null;
            while(i){
                i--;
                var thing = drag_list[i];
                if(thing.type == "macro_pack" && thing.name == "Credit Offset"){
                    var credit_offset = drag_list.splice(i, 1)[0];
                }
            }

            self.drag_list.draw({
                main_template: '#playlist_edit_generic_drag_list_tmpl',
                search_template: '#playlist_edit_generic_search_tmpl',
                search_params: {server_id: self.server_id},
                drag_list: drag_list,
                sort_func: _sort_by_name,
                filter_func: self.filter_drag_generic,
                double_click_func: double_click,
                type: tab_value
            });

            //Re-add the credit offset draggable
            if(credit_offset){
                $('#playlist_edit_generic_drag_list_tmpl').tmpl({'drag_list': [credit_offset], 'type': 'macro_pack'}).appendTo('.playlist_edit_content_body_main');
                $('.jq_list_edit_drag_item_wrap[uuid="'+credit_offset.id+'"]').draggable({
                    helper : function(){return $(this).clone().css({'width': $(this).width(),'margin':0}).addClass('automation');},
                    appendTo:'#main_section',
                    tolerance:'intersect',
                    refreshPositions: true,
                    drag: drag_function,
                    start: function(){
                        playlist_edit_page.dragging = true;
                        playlist_edit_page.scroll_listener();
                    },
                    stop: stop_function
                });
            }
        }
        else{
            $('.playlist_edit_content_body_main').empty();
            $('.playlist_edit_content_body_search').empty();
        }
    }

    function double_click(){
        var ui_attributes = $(this).attr_dict(['cpl_uuid', 'type', 'uuid', 'description', 'duration_in_seconds', 'pack_uuid']);
        alter_rendered_playlist(ui_attributes, self.playlist.events.length);
        self.draw_playlist();
        self.changes_made(true);
    }

    function _get_items(type){
        switch(type){
            case 'title' : return self.titles;
            case 'placeholder' : return self.placeholders;
            case 'macro_pack' : return self.macro_packs;
        }
    }

    function _sort_by_name(a, b)
    {
        if (a.name < b.name){
            return -1;
        }
        return 1;
    }

    function _load_playlist() {
        if (!self.playlist_uuid){
            playlist_object = {
                title: self.playlist_title
            };
            self.playlist = new Playlist(playlist_object);
            self.draw_playlist();
            self.changes_made(true);
        }
        else{
            helpers.ajax_call({
                url: '/tms/get_playlist_detailed',
                data: {
                    device_uuid : self.server_id,
                    playlist_uuid : self.playlist_uuid
                },
                loader: {target: "#playlist_edit_playlist_section", caption: gettext("Loading")},
                success_function: function(data){
                    _update_playlist(data);
                }
            });
        }
    }

    function _update_playlist(input) {
        self.playlist = new Playlist(input.data, self.device_automation_dict);
        self.draw_playlist();
    }

    self.draw_playlist = function(){
        self.playlist.calculate_start_times();
        var show_3d = helpers.supported('doremi_3d_mode',$device_store.devices[self.server_id].type),
            show_hfr = helpers.supported('doremi_hfr_mode', $device_store.devices[self.server_id].type);
        $('#playlist_actions #display_mode').remove();

        $('#playlist_edit_info_section').html($('#playlist_info_tmpl').tmpl({
            'current_playlist' : {
                'server_number': helpers.get_device_name(self.server_id),
                'title': self.playlist.title,
                'duration_in_seconds': $.seconds_to_duration_string(self.playlist.duration_in_seconds),
                'is_3d': self.playlist.is_3d,
                'is_hfr': self.playlist.is_hfr,
                'is_4k': self.playlist.is_4k,
                'show_3d': show_3d,
                'show_hfr': show_hfr
            }
        }));

        $('#edit_playlist_trigger_section').html($('#edit_playlist_trigger_section_tmpl').tmpl({
            playlist: self.playlist
        }));
        $('#playlist_edit_playlist_section').html($('#playlist_edit_playlist_tmpl').tmpl({
            'playlist':self.playlist,
            'selected_device': $device_store.devices[self.server_id]
        }));

        $('.jq_playlist_display_mode').button();
        $('#display_mode').appendTo($('#playlist_actions'));
        //has template stuff
        var has_playlist_template = ($('.playlist_edit_playlist_element_wrap.title, .playlist_edit_playlist_element_wrap.placeholder').length > 0);

        if(has_playlist_template){
            $('.jq_disable_on_not_template').show();
            $('.jq_disable_on_template').hide();
        }
        else{
            $('.jq_disable_on_template').show();
            $('.jq_disable_on_not_template').hide();
        }

        /*
            set up the sortable jquery ui for the playlist
            this takes care of:
                Content fields being added
                Packs being added
                The playlist itself being sortable
        */
        $('.playlist_edit_playlist_container').sortable({
            start: function(event,ui) {
                //set temp_move_index so we know where we are moving from
                self.temp_move_index = $('.playlist_edit_playlist_container > div').index(ui.item);
            },
            update: function(event, ui) {
                if (self.temp_move_index === -2) {
                    return;
                }
                var target_position = $('.playlist_edit_playlist_container > *').index(ui.item);

                if (self.temp_move_index !== -1) {
                    var moved_event = self.playlist.events.splice(self.temp_move_index,1)[0];
                    self.playlist.add_event(target_position, moved_event);
                }
                else {
                    var ui_attributes = ui.item.attr_dict(['cpl_uuid', 'type', 'uuid', 'description', 'duration_in_seconds', 'pack_uuid']);
                    alter_rendered_playlist(ui_attributes, target_position);
                }
            },
            receive: function(event, ui) {
                self.temp_move_index = -1;
            },
            stop: function(event, ui) {
                self.draw_playlist();
                self.changes_made(true);
            },
            helper:'clone',
            appendTo:'.playlist_edit_playlist_container',
            containment:'.playlist_edit_playlist_container',
            tolerance:'touch'
        });
        /*
            setup the droppable fields on each playlist element
            this takes care of all automation that gets added directly to content fields
        */
        $('.playlist_edit_playlist_container').find('.composition, .pattern, .title').droppable({
            activeClass : 'drop_enabled',
            hoverClass : 'drop_hover',
            tolerance : 'intersect',
            accept : function($draggable) {
                var $droppable = $(this);
                // More credit offset hacking
                if ($draggable.attr('type') == 'macro_pack' && $draggable.attr('description') == 'credit offset'){
                    return true;
                }
                if ($draggable.attr('type') != 'automation') {
                    return false;
                }
                else if ($draggable.attr('automation_id') == 'GDC-START-CUE' && $droppable.data('has_gdc_start_cue')) {
                    return false;
                }
                else {
                    return true;
                }
            },
            drop:function(event, ui){
                // Credit offset handling
                if (ui.helper.attr('type') == 'macro_pack'){
                    var index = $(this).index();
                    if($(this).hasClass('title')) {
                        //Title credit offset is handled at concrete spl generation time
                        self.playlist.events[index].credit_offset = true;
                        self.draw_playlist();
                        self.changes_made(true);
                        return;
                    }
                    var playlist_event = self.playlist['events'][index];
                    var tmpl_data = {
                        'automation': {
                            'type_specific':{
                                'offset_in_seconds': playlist_event.credit_offset
                            }
                        },
                        'target_event_id': index
                    };
                    spo.credit_offset_dialog(tmpl_data, gettext("Add Credit Offset"), function(){
                        save_credit_offset();
                        dialog.close();
                    });
                    return;
                }

                var automation_id = ui.helper.attr('automation_id');
                var automation = spo.find_automation(self.automation, automation_id);

                var data = {
                    'automation': automation,
                    'automation_id': automation_id,
                    'target_event_id': $(this).index()
                };

                spo.automation_dialog(data, gettext('Add Automation'), function() {
                    _save_automation(false);
                });
            }
        });

        if (CONFIG.app.global_triggers_enabled && ($device_store.devices[self.server_id].type == 'aamlms' || $device_store.devices[self.server_id].type == 'doremi')) {
            $('#playlist_edit_playlist_section').css("top", "calc(103px + 11%)");
            $('#edit_playlist_trigger_section').droppable({
                activeClass: 'drop_enabled',
                hoverClass: 'drop_hover',
                tolerance: 'intersect',
                accept: function($draggable) {
                    if ($draggable.attr('type') != 'automation') {
                        return false;
                    }
                    for (var device_id in self.automation) {
                        if (self.automation[device_id][$draggable.attr('automation_id')] && self.automation[device_id][$draggable.attr('automation_id')].type == 'trigger') {
                            return true;
                        }
                    }
                    return false;
                },
                drop: function(event, ui) {
                    var automation_id = ui.helper.attr('automation_id');
                    var automation = spo.find_automation(self.automation, automation_id);

                    var data = {
                        'automation': automation,
                        'automation_id': automation_id
                    };

                    spo.automation_dialog(data, gettext('Add Automation'), function() {
                        _save_automation(true);
                    });
                }
            });
        }

        $('.image.delete.content_attributes').click(_remove_from_playlist);
        $('.image.edit.content_attributes').click(_edit_pattern);

        $('#playlist_edit_playlist_section .delete_title_credit_offset').click(_remove_title_credit_offset);
        $('#playlist_edit_playlist_section .image.delete.automation_attributes').click(_remove_from_event);
        $('#playlist_edit_playlist_section .image.edit.automation_attributes').click(function() { _edit_automation.call(this, false);});
        $('#edit_playlist_trigger_section .image.delete.automation_attributes').click(_remove_global_trigger_from_playlist);
        $('#edit_playlist_trigger_section .image.edit.automation_attributes').click(function() { _edit_automation.call(this, true);});
    };

    function save_credit_offset(){
        var target = self.playlist.events[$('#credit_offset_target').val()];
        var offset_in_seconds = $('#credit_offset_hms').hms('retrieve');

        //There can be only one.....
        var i = target.automation.length;
        while(i){
            i--;
            if(target.automation[i].type == "credit_offset"){
                target.automation.pop(i);
            }
        }
        target.automation.push(new PlaylistCompositionAutomation({
            name: 'Credit Offset',
            type: 'credit_offset',
            type_specific: {
                'offset_in_seconds': offset_in_seconds
            }
        }));
        self.draw_playlist();
        self.changes_made(true);
    }

    function _save_automation(is_global_trigger){
        var event_drop_target;

        if (is_global_trigger) {
            event_drop_target = self.playlist;
        } else {
            var target_event_id = $('#target_event_id').val();
            event_drop_target = self.playlist.events[target_event_id];
        }

        spo.save_automation_dialog_input(event_drop_target, self.automation, self.device_automation_dict, function(){
            dialog.close();
            self.draw_playlist();
            self.changes_made(true);
        });
    }

    function alter_rendered_playlist(event_dict, target_position){
        var moved_event;
        switch(event_dict.type){
            case('content'):
                var cpl = $.grep(self.contents, function(e){return e.uuid == event_dict.cpl_uuid;})[0];
                moved_event = new PlaylistCompositionEvent(cpl);
                self.playlist.add_event(target_position, moved_event);
                break;
            case('title'):
                var title = $.grep(self.titles, function(e){ return e.uuid == event_dict.uuid; })[0];
                moved_event = new PlaylistEvent('title', title);
                self.playlist.add_event(target_position, moved_event);
                break;
            case('macro_pack'):
                var macro_pack = self.macro_packs[event_dict.uuid];
                moved_event = new PlaylistEvent('macro_pack', macro_pack);
                self.playlist.add_event(target_position, moved_event);
                break;
            case('placeholder'):
                var placeholder = self.placeholders[event_dict.uuid];
                moved_event = new PlaylistEvent('placeholder', placeholder);
                self.playlist.add_event(target_position, moved_event);
                break;
            case('pattern'):
                if(event_dict.duration_in_seconds === ''){
                    var data = {
                        target_position : target_position,
                        description : event_dict.description,
                        edit_pattern_position : null
                    };
                    spo.pattern_dialog(data, gettext('Add Pattern'), on_pattern_dialog_output);
                }
                else{
                    moved_event = new PlaylistPatternEvent({
                        'text':event_dict.description,
                        'duration_in_seconds':event_dict.duration_in_seconds
                    });
                    self.playlist.add_event(target_position, moved_event);
                }
                break;
            case('pack'):
                helpers.ajax_call({
                    data: {
                        pack_uuid: event_dict.pack_uuid,
                        device_uuid: self.server_id
                    },
                    url: "/tms/get_pack_detailed",
                    success_function: function(input){
                        open_pack_dialog(input, target_position);
                    }
                });

        }
    }

    function open_pack_dialog(pack, target_position){
        var buttons = [];
        buttons.push({
            'text': gettext('Add'),
            'action': function() {
                _add_pack(pack.data.clips, target_position);
            }
        });

        var pack_obj = new PackObject(pack.data);
        dialog.open({
            'width':'600px',
            'title': gettext('Add Pack'),
            'buttons': buttons,
            'template': '#playlist_edit_add_pack_tmpl',
            'data':{'pack': pack_obj}
        });
    }

    function _add_pack(pack_content, start){
        var index = start;
        var pack_event;
        for (var i =0 ; i < pack_content.length; i++) {
            if(pack_content[i].type == "pattern"){
                pack_event = new PlaylistPatternEvent(pack_content[i]);
            }
            else{
                pack_event = new PlaylistCompositionEvent(pack_content[i]);
            }
            self.playlist.add_event(index, pack_event);
            index++;
        }
        self.draw_playlist();
        dialog.close();
    }

    function _edit_pattern() {
        var template_data = {};
        var edit_index = $(this).closest('.playlist_edit_playlist_element_wrap').index();
        template_data.target_position = undefined;
        template_data.description = self.playlist.events[edit_index].title;
        template_data.edit_pattern_position = edit_index;

        var hms_settings = {};
        var tmp = parseInt(self.playlist.events[edit_index].duration_in_seconds,10);

        hms_settings.seconds  = tmp % 60;
        tmp  = parseInt(tmp / 60,10);
        hms_settings.minutes  = tmp % 60;
        tmp  = parseInt(tmp / 60,10);
        hms_settings.hours  = tmp;

        spo.pattern_dialog(template_data, gettext('Edit Pattern'), on_pattern_dialog_output, hms_settings);
    }

    function _edit_automation(global_trigger) {
        var element_index, automation_index, automation;

        if (global_trigger) {
            element_index = -1;
            automation_index = $(this).closest('.jq_cue').index();
            automation = self.playlist.automation[automation_index];
        }
        else {
            element_index = $(this).closest('.jq_event').index();
            automation_index = $(this).closest('.jq_cue').index()-1;
            //Fix for gdc start cue
            if(automation_index === -1){
                automation_index = 0;
            }
            automation = self.playlist.events[element_index].automation[automation_index];
        }

        var data = {
            'automation': automation,
            'target_event_id': element_index,
            'edit_automation_index': automation_index
        };

        //More credit offset hackery
        if(automation.type == 'credit_offset'){
            spo.credit_offset_dialog(data, gettext('Edit Credit Offset'), function(){
                save_credit_offset();
                dialog.close();
            });
        }
        else{
            spo.automation_dialog(data, gettext('Edit Automation'), function() {
                _save_automation(global_trigger);
            });
        }
    }

    function _remove_from_playlist() {
        self.playlist.remove_event($(this).closest('.playlist_edit_playlist_element_wrap').index());
        self.draw_playlist();
        self.changes_made(true);
    }

    function _remove_from_event() {
        self.playlist.events[$(this).closest('.playlist_edit_playlist_element_wrap').index()].automation.splice($(this).closest('.playlist_event_cue_wrapper').index()-1, 1);
        self.draw_playlist();
        self.changes_made(true);
    }
    function _remove_title_credit_offset() {
        self.playlist.events[$(this).closest('.playlist_edit_playlist_element_wrap').index()].credit_offset = false;
        self.draw_playlist();
        self.changes_made(true);
    }

    function _remove_global_trigger_from_playlist() {
        self.playlist.automation.splice($(this).closest('.jq_cue').index(), 1);
        self.draw_playlist();
        self.changes_made(true);
    }

    function on_pattern_dialog_output(){
        var hours, minutes, seconds;
        var errors = [];
        var ok = true;
        var edit_position = $("#edit_pattern_position").val();
        var description = $("#add_pattern_description").val();
        var target_position = $("#add_pattern_target_position").val();
        var duration = $("#pattern_duration").hms("retrieve");

        if(duration == 0){
            ok = false;
            errors.push(gettext('Duration must not be zero'));
        }

        if (edit_position !== '') {
            var current_pattern_automations = self.playlist.events[edit_position].automation || [];
            $.each(current_pattern_automations, function(index, automation){
                if(duration < automation.type_specific.offset_in_seconds){
                    ok = false;
                    errors.push(gettext("The Duration of a Pattern must be more than the start times of its automations"));
                }
            });
        }

        if(!ok){
            $('#validation_error_tmpl').tmpl({'errors':errors}).appendTo($('.validation').empty());
        }
        else{
            if (edit_position !== '') {
                var tmp = self.playlist.events[edit_position];
                tmp.duration_in_seconds = duration;
                tmp.duration_in_frames = (duration*tmp.edit_rate[0]/tmp.edit_rate[1]);
            }
            else {
                self.playlist.add_event(
                    target_position,
                    new PlaylistPatternEvent({
                        'text':description,
                        'duration_in_seconds':duration
                    })
                );
            }
            self.draw_playlist();
            self.changes_made(true);
            dialog.close();
        }
    }
}
