var general_config_page = new GeneralConfigPage();
function GeneralConfigPage() {
    var self = this;

    //Templates
    self.main_tmpl = '#general_config_tmpl';

    // Other stuff
    self.automation_store = {};
    self.user_details;
    self.ignored_drives = [];
    self.show_attributes = {};
    self.external_show_attribute_maps = {};
    self.unmatched_external_show_attribute_maps;
    self.prevent_navigation = false;
    self.transfer_forecast_update_timer = null;
    self.pos_auto_playlist_name_timer = null;
    self.pos_device_maps_updated = {};
    self.pos_configuration = {};
    self.current_user = null;
    self.drag_list = undefined;
    self.set_contact_info = set_contact_info;
    self.delete_contact = delete_contact;
    self.get_contacts = get_contacts;
    self.set_address_info = set_address_info;
    self.delete_address = delete_address;
    self.placeholder_names = [];

    /*for getting content search data for title CPL editing.*/
    self.content_call_data = {
        iDisplayLength: 50,
        sSearch: null,
        type_filter: null
    };

    self.draggable_defaults = {
        helper: function(){
            return $(this).clone().css({
                'width': $(this).width(),
                'margin': 0
            });
        },
        cursorAt: {
            top: 2
        },
        containment : '#main_section',
        connectToSortable :'#trailer_rating_edit_section',
        appendTo :'#main_section',
        tolerance :'intersect',
        drag: function(){

        },
        start: function(){
            $('#trailer_rating_edit_section').addClass("drop_enabled");
        },
        stop: function(){
            $('#trailer_rating_edit_section').removeClass("drop_enabled");
        }
    }

    //Methods
    self.open = function(tab) {
        var $document, devices;
        $document = $(document);
        $document.trigger('page_load');
        $document.on('page_load.general_config', close_page);

        self.automation_store = {};
        self.pos_configuration = {};
        nav_select('config', 'general');
        $(self.main_tmpl).tmpl().appendTo($('#main_section').empty());

        if( helpers.is_allowed('tms_pos_info')){
            helpers.ajax_call({
                url: '/core/pos/get_configuration',
                success_function: function(input){
                    self.pos_configuration = input.data
                }
            });
            helpers.ajax_call({
                url: '/core/configuration/external_device_maps',
                data: {
                    source_type : "pos"
                },
                success_function:function(input){
                    self.pos_configuration.device_map = {};
                    for( var source in input.data.pos){
                        self.pos_configuration.device_map[source] = [];
                        for( var ext_id in input.data.pos[source]){
                            self.pos_configuration.device_map[source].push({
                                "ext_id" : ext_id,
                                "device_uuid" : input.data.pos[source][ext_id],
                            });
                        }
                    }
                    for(source in self.pos_configuration.device_map){
                        self.pos_configuration.device_map[source].sort_screens('ext_id');
                    }
                }
            });
        }

        helpers.ajax_call({
            url:'/get_user_information',
            success_function: function(input) {
                self.current_user = input['username'];
            }
        });

        helpers.ajax_call({
            url: '/core/configuration/get_kdm_email_configuration',
            success_function: function(input){
                self.kdm_email_configuration = input.data;
            }
        });

        helpers.ajax_call({
            url: '/core/configuration/log_settings',
            success_function: function(input){
                self.log_configuration = input.data;
            }
        });

        add_event_listeners();
        add_tab_event_listeners();
        $(document).trigger('page_loaded');
        self.prevent_navigation = false;
        self.pos_device_maps_updated = {};
        if(tab){
            $('#menu .tab[config="'+tab+'"]').click();
        }
    };

    function close_page() {
        $(document).off('.general_config', close_page);
        self.automation_store = {};
        self.user_details;
        self.ignored_drives = [];
        self.show_attributes = {};
        self.external_show_attribute_maps = {};
        self.unmatched_external_show_attribute_maps;
        self.prevent_navigation = false;
        self.transfer_forecast_update_timer = null;
        self.pos_auto_playlist_name_timer = null;
        self.pos_device_maps_updated = {};
        self.pos_configuration = {};
        helpers.ajax_call({
            url: '/tms/get_automation_configuration',
            success_function: _update_automation_configuration
        });
        $('#main_section').off('.config');
        $(window).off("resize");
    }

    function add_event_listeners(){
        $('#main_section').on(
            'click.config',
            '#pos_settings_table .pos_day',
            toggle_pos_setting
        );
        $('#main_section').on(
            'click.config',
            '#pos_settings_table .pos_enabled, #pos_settings_table .pos_auto_transfer_time, #kdm_email_settings_table .kdm_email_enabled',
            toggle_pos_setting
        );
        $('#main_section').on(
            'keyup.config',
            '#jq_sod_filter',
            filter_sod_playlists
        );
        $('#main_section').on(
            'keyup.config',
            '#jq_eod_filter',
            filter_eod_playlists
        );
        $('#main_section').on(
            'click.config',
            '#back_me_up',
            backup_db
        );
        $('#main_section').on(
            'click.config',
            '#restore_me',
            restore_db
        );
    }

    function add_tab_event_listeners() {
        $('.tab').clickOrEnter(change_tab);
        $('.tab:first-child').click();
    }

    function change_tab(mouseclick_event) {
        if( _navigate() ){
            var selected_tab = $(this).attr('config');
            $(this).addClass('selected').siblings().removeClass('selected');
            var data = {};
            switch(selected_tab){
                case 'complex_config':{
                    load_complex_config();
                    break;
                }
                case 'quick_cues':{
                    load_quick_cues();
                    break;
                }
                case 'show_start':{
                    load_show_start();
                    break;
                }
                case 'pos':{
                    load_pos();
                    break;
                }
                case 'kdm_email':{
                    load_kdm_email();
                    break;
                }
                case 'bookends' : {
                    load_bookends();
                    break;
                }
                case 'users':{
                    load_users();
                    break;
                }
                case 'ignored_drives':{
                    load_ignored_drives();
                    break;
                }
                case 'placeholders':{
                    load_placeholder_config();
                    break;
                }
                case 'sync':{
                    load_sync_config();
                    break;
                }
                case 'trailer_ratings':{
                    load_trailer_ratings_config();
                    break;
                }
                case 'show_attributes':{
                    load_show_attributes();
                    break;
                }
                case 'database':{
                    load_database();
                    break;
                }
                case 'logs':{
                    load_log_settings();
                    break;
                }
                case 'auto_cleanup':{
                    load_auto_cleanup_settings();
                    break;
                }
                case 'auto_playlist_generation':{
                    load_auto_playlist_generation();
                    break;
                }
                default: {
                    $('#panes').html('implement me!');
                }
            }
        }
    }

    function load_show_start(){
        $.when(get_grouped_automations(false)).done(function(input){
            $('#show_start_tmpl').tmpl({'device_types': input}).appendTo($('#panes').empty());
            $("#ss_tabs .ss_tab").click(function(){
                var device_type = $(this).attr("data-device_type");
                $("#ss_tabs .ss_tab.selected").removeClass("selected");
                $(this).addClass("selected");
                $('#show_start_list_tmpl').tmpl({'automations': input[device_type]['automations']}).appendTo($("#ss_list").empty());
                $('.automation_actions .automation_action').click(function(){
                    var $this = $(this);
                    $this.toggleClass("inactive").toggleClass("active");
                    $this.siblings(".automation_action").removeClass("active").addClass("inactive");
                    var name = $this.attr("data-automation_name");
                    var key = $this.attr("data-key");
                    var value = $this.hasClass("active");
                    var index = $this.attr("data-index");
                    input[device_type]['automations'][index]['config']["show_start"] = false;
                    input[device_type]['automations'][index]['config']["intermission"] = false;
                    input[device_type]['automations'][index]['config']["credits"] = false;
                    input[device_type]['automations'][index]['config'][key] = value;
                    set_show_start_config(name, key, value);
                });
            });
            $("#ss_tabs .ss_tab:first-child").click();
        });
    }

    function set_show_start_config(name, key, value){
        helpers.ajax_call({
            url: '/tms/set_automation_configuration',
            data: {
                automation_name: name,
                key: key,
                value: value
            }
        });
    }

    function load_quick_cues(){
        helpers.ajax_call({
            url: "/tms/get_quick_cues",
            success_function: function(input){
                //Replace object with list for screen alphanumeric sort
                for(var i in input){
                    var quick_cue = input[i];
                    var autos = [];
                    $.each(quick_cue.automations, function(device_uuid, automation_uuid){
                        var automation_name = '';
                        $.each(AUTOMATION_CONFIGURATION.quick_cues[device_uuid] || {}, function(j, qc){
                            if(automation_uuid === qc.automation_uuid) {
                                automation_name = qc.automation_name;
                            }
                        });
                        autos.push({device_uuid: device_uuid, name: automation_name, screen_id: helpers.get_device_name(device_uuid)});
                    });
                    autos.sort_screens('screen_id');
                    input[i]['automations'] = autos;
                }
                $('#quick_cues_tmpl').tmpl({'quick_cues': input}).appendTo($('#panes').empty());
                $('#qc_new').click(function(){
                    quick_cue_edit();
                });
                $('#qc_list').sortable({
                    cursor: 'move',
                    containment: 'parent',
                    tolerance: 'pointer',
                    stop: function(){
                        save_order();
                    }
                });
                $("#qc_list").disableSelection();
                $('.qc_action.qc_edit').click(function(){
                    var uuid = $(this).attr("data-uuid");
                    quick_cue_edit(uuid);
                });
                $('.qc_action.qc_delete').click(function(){
                    var uuid = $(this).attr("data-uuid");
                    quick_cue_delete(uuid);
                });
            }
        });
    }

    function save_order(uuid, move){
        var data = {};
        $('#qc_list .quick_cue_row').each(function(i, item){
            var dom = $(item);
            data[dom.attr("data-uuid")] = dom.index();
        });
        helpers.ajax_call({
            url: "/tms/update_quick_cue_index",
            data: {'data': data},
            notify: false,
            loader: {
                target: '#qc_list',
                caption: gettext("Saving order")
            }
        });
    }

    function quick_cue_delete(uuid){
        helpers.ajax_call({
            url: "/tms/delete_quick_cue",
            data: {'uuid': uuid},
            success_function: function(){
                load_quick_cues();
            }
        });
    }

    function quick_cue_edit(uuid){
        if(uuid){
            helpers.ajax_call({
                url: "/tms/get_quick_cues",
                data: {'uuid': uuid},
                success_function: function(input){
                    load_quick_cue_edit(input[0]);
                }
            });
        }
        else{
            var quick_cue = {
                'icon': null,
                'automations': {}
            };
            load_quick_cue_edit(quick_cue);
        }
    }

    function load_quick_cue_edit(quick_cue){
        $.when(get_grouped_automations(true), get_available_icons()).done(function(a, b){
            var device_types = a[0];
            var icons = b[0]['quick_cue_list'];
            if(quick_cue['icon']){
                icons.unshift(quick_cue['icon']);
            }
            $('#quick_cue_edit_tmpl').tmpl({"device_types": device_types, "quick_cue": quick_cue}).appendTo($('#qc_view').empty());
            $('.icon_picker .icon').click(function(){
                show_quick_cue_tip($(this), icons);
            });
            $('#quick_cue_save').click(function(){
                if(!$(this).hasClass('ui-state-disabled')) {
                    save_quick_cue(quick_cue);
                }
            });
            $('#quick_cue_cancel').click(function(){
                 load_quick_cues();
            });
            $('.device_type_tab').click(function(){
                $('.device_type_tab.selected').removeClass("selected");
                $(this).addClass("selected");
                var device_type = $(this).attr("data-device_type");
                $('#quick_cues_automations_tmpl').tmpl({'quick_cue': quick_cue, 'automations': device_types[device_type]['automations']}).appendTo($('#qc_body').empty());
                //Allow pointer events on in-use quick cue if it's the one being edited
                $('.automation_row.in_use').each(function() {
                    if($(this).find('.device_toggle.selected').length) {
                        $(this).removeClass('in_use');
                    }
                });
                $('.select_all').click(function(){
                    $(this).closest(".automation_row").find('.device_toggle.configured').removeClass("selected").click();
                });
                $('.automation_row:not(.in_use)').find('.device_toggle.configured').click(function(){
                    var $device = $(this);
                    var device_uuid = $device.attr("data-device_uuid");
                    if($device.hasClass("selected")){
                        delete quick_cue.automations[device_uuid];
                    }
                    else {
                        $('.device_toggle.configured.selected[data-device_uuid="'+device_uuid+'"]').removeClass("selected");
                        quick_cue.automations[device_uuid] = $device.attr("data-automation_uuid");
                    }
                    $device.toggleClass('selected');
                    enable_qc_save();
                });
                enable_qc_save();
            });
            $('.device_type_tab:first-child').click();
        });
    }

    function get_grouped_automations(hide_quick_cue_autos){
        return helpers.ajax_call({
            url: "/tms/get_grouped_automations",
            data: {"hide_quick_cue_autos": hide_quick_cue_autos}
        });
    }

    function get_available_icons(){
        return helpers.ajax_call({
            url: '/tms/quick_cue_names',
            data: {'available': true}
        });
    }

    function show_quick_cue_tip(dom, icons){
        dom.qtip({
            content: {
                text: $('#quick_cue_icons_tmpl').tmpl({'icons': icons}).html()
            },
            position: {
                my: "bottom left",
                at: "top right",
                viewport: $("#main_section")
            },
            show: {
                event: 'click',
                ready: true
            },
            hide: {
                delay: 100,
                event: 'unfocus',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light'
            },
            events: {
                show: function(event, api){
                    api.elements.content.find(".qc_icon").click(function(){
                        var icon = $(this).attr("data-qc_icon");
                        var current = $('.icon_picker .icon');
                        current.removeClass(current.attr("data-icon")).addClass(icon).attr("data-icon", icon);
                        api.hide();
                        enable_qc_save();
                    });
                }
            }
        });
    }

    function enable_qc_save() {
        var device_selected = $('#qc_body').find('.device_toggle.configured.selected').length;
        var icon_selected = $('#qc_header').find('.icon.quick_cue').attr('data-icon').length;
        $('#quick_cue_save').toggleClass('ui-state-disabled', !(icon_selected && device_selected));
    }

    function save_quick_cue(quick_cue){
        var icon = $('.icon_picker .icon').attr("data-icon");
        quick_cue['icon'] = icon;
        helpers.ajax_call({
            url: "/tms/save_quick_cue",
            data: {"quick_cue": quick_cue},
            success_function: function(input){
                var uuid = input['data'];
                load_quick_cues();
            }
        });
    }


    /******** Start of Trailer rating*********/

    function load_trailer_ratings_config(){
        $('#general_config_trailer_ratings_tmpl').tmpl().appendTo($('#panes').empty());
        helpers.set_buttons('#trailer_ratings_save', [{
           text: gettext('Save'),
           image: 'save',
           disabled: true,
           _class: 'jq_enable_on_select',
           onClick: function(){
               trailer_ratings_save();
           }
       }]);

        $('#trailer_rating_edit_section').droppable({
            activeClass : 'drop_enabled',
            drop:function(event, ui) {
                add_rating_cpl(ui.helper.attr('cpl_uuid'));
            }
        });

        self.drag_list = new DragList({
            search_dom: ".title_edit_content_body_search",
            search_input: "#title_content_search_input",
            list_dom: ".title_edit_content_body_main",
            device_id: undefined,
            draggable_defaults: self.draggable_defaults
        });

        // listeners
        $('.title_edit_content_tab').click(_select_content_tab);
        $('.title_edit_content_tab:first-child').click();

        helpers.ajax_call({
            url: '/tms/get_trailer_rating_detailed',
            success_function: function(input){
                self.rating_cpls = input.data.cpls;
                draw_trailer_ratings();
            }
        });
    }

    function draw_trailer_ratings(){
        $('#trailer_rating_cpl_tmpl').tmpl({"cpls": self.rating_cpls}).appendTo($('#trailer_rating_edit_section').empty());
        $('.cpl_delete').click(function(event){
            var cpl_uuid = $(event.target).attr("data-cpl_uuid");
            for(var i in self.rating_cpls){
                var cpl = self.rating_cpls[i];
                if(cpl.uuid === cpl_uuid){
                    self.rating_cpls.splice(i, 1);
                    _changes_made(true);
                    $('#trailer_rating_edit_section').find('[data-cpl_uuid="'+ cpl_uuid +'"]').fadeOut(250, function() {
                        $(this).remove();
                    });
                    break;
                }
            }
        });
    }

    function trailer_ratings_save(){
        var cpls = [];
        for(var i in self.rating_cpls){
            var cpl = self.rating_cpls[i];
            cpls.push(cpl.uuid);
        }
        helpers.ajax_call({
            url: "/core/configuration/save_trailer_rating_content",
            data: {"cpls": cpls},
            success_function: function(input){
                load_trailer_ratings_config();
                _changes_made(false);
            }
        });
    }

    function _select_content_tab(mouse_event) {
        var tab_value = $(this).attr('tab_value');
        $(this).addClass('selected').siblings().removeClass('selected');
        set_filter_values();
        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.draw({
                main_template: '#title_edit_content_drag_list_tmpl',
                search_template: '#title_edit_content_search_tmpl',
                drag_list: drag_list,
                filter_func: update_content_tab,
                double_click_func: rating_double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });
            $('#title_content_search_filter').change(update_content_tab);
            if (tab_value == 'content'){
                $('#title_content_search_filter').show();
                $('#clear_filter_button').show();
            } else {
                $('#title_content_search_filter').hide();
                $('#clear_filter_button').hide();
            }
        });
    }

    function set_filter_values(){
        var tab_value = $('.jq_content_selection.selected').attr("tab_value");
        if (tab_value == 'content'){
            self.content_call_data['type_filter'] = $('#title_content_search_filter').val();
            self.content_call_data['orphaned'] = false;
        }else{
            self.content_call_data['type_filter'] = tab_value;
            self.content_call_data['orphaned'] = false;
        }

        self.content_call_data['sSearch'] = $('#title_content_search_input').val();
    }

    function get_contents(callback){
        helpers.ajax_call({
            url: '/core/paginated/get_draglist_content',
            data: self.content_call_data,
            success_function: function(data){
                self.contents = data.aaData;
                self.contents_count = data.iTotalDisplayRecords;
                callback();
            }
        });
    }

    function update_content_tab(){
        set_filter_values();
        load_tab(get_contents, function(){
            var drag_list = gen_content_list();
            self.drag_list.update({
                main_template: '#title_edit_content_drag_list_tmpl',
                drag_list: drag_list,
                double_click_func: rating_double_click,
                filter_info: {
                    'total': self.contents_count
                }
            });
        });
    }

    function rating_double_click(){
        add_rating_cpl($(event.target).closest(".list_edit_drag_item_wrap").attr('cpl_uuid'));
    }

    function add_rating_cpl(cpl_uuid){
        //don't add twice
        var cpl = $.grep(self.rating_cpls, function(cpl){
            return cpl.uuid == cpl_uuid;
        })[0];
        if (cpl == undefined){
            //where are we adding?
            var cpl = $.grep(self.contents, function(item){
                return item.uuid == cpl_uuid;
            })[0];
            self.rating_cpls.push(cpl);
            draw_trailer_ratings();
            _changes_made(true);
        }
        else {
            alert(gettext('The CPL has already been added'));
        }
    }

    function parse_cpl(cpl){
        var translated_playback_mode = false;
        switch(cpl.playback_mode) {
            case '2D': translated_playback_mode = 'icon-two-d'; break;
            case '3D': translated_playback_mode = 'icon-three-d'; break;
        }
        if (translated_playback_mode !== false){
            cpl.playback_mode = translated_playback_mode;
        }
        cpl.subtitled = cpl.subtitled ? cpl.subtitle_language?cpl.subtitle_language:'XSUB' : '';
        return cpl;
    }

    function gen_content_list(){
        var drag_list = [];
        var len = self.contents.length;
        var i = 0;
        while(i < len){
            var cpl = self.contents[i];
            cpl = parse_cpl(cpl);
            drag_list.push(cpl);
            i++;
        }
        return drag_list;
    }

    function load_tab(getter, callback){
        var loader = new Loader({target: $(".title_edit_content_body_main")});
        loader.show(function(){
            getter(function(){
                callback();
                loader.hide();
            });
        });
    }

    /******** End of Trailer rating*********/


    function load_placeholder_config(){
        helpers.ajax_call({
            url: '/core/placeholder/placeholders',
            data: {sorted_list:true},
            success_function: function(input){
                self.placeholder_names = input.data.map(function(p){return p.name.toUpperCase();});
                $('#general_config_placeholders_tmpl').tmpl({"placeholders": input['data']}).appendTo($('#panes').empty());
                $('.placeholder_add').click(function(){
                    var name = $("#placeholder_name_input").val();
                    if(name != "")
                        add_placeholder(name);
                });
                $('.placeholder_delete').click(function(){
                    var placeholder_uuid = $(this).attr("data-placeholder_uuid");
                    delete_placeholder(placeholder_uuid);
                });
                $('.placeholder_edit').click(placeholder_edit_click);
            }
        });
    }

    function placeholder_edit_click(){
        $(this).removeClass("icon-document-alt-fill").addClass("icon-disk");
        var placeholder_uuid = $(this).attr("data-placeholder_uuid");
        var placeholder_name_dom = $(".placeholder_name[data-placeholder_uuid='" + placeholder_uuid + "']");
        var old_name = placeholder_name_dom.text();
        var input = $("<input type='text' value='" + old_name + "' />");
        placeholder_name_dom.html(input);
        $(this).off("click").click(function(){
            var new_name = input.val();
            if(new_name !== old_name){
                edit_placeholder(placeholder_uuid, new_name);
            }
        });
    }

    function edit_placeholder(placeholder_uuid, placeholder_name){
        var placeholder = {
            'uuid': placeholder_uuid,
            'name': placeholder_name
        };
        save_placeholder(placeholder);
    }

    function add_placeholder(placeholder_name){
        var placeholder = {
            'name': placeholder_name
        };
        save_placeholder(placeholder);
    }

    function save_placeholder(placeholder){
        if($._in(placeholder.name.toUpperCase(), self.placeholder_names)) {
            notification.warning_msg(gettext('Name already in use'), gettext('Duplicate Name'));
            return;
        }
        helpers.ajax_call({
            url: '/core/placeholder/save',
            data: {
                'placeholders': [placeholder]
            },
            success_function: function(input){
                load_placeholder_config();
            }
        });
    }

    function delete_placeholder(placeholder_uuid){
        helpers.ajax_call({
            url: '/core/placeholder/delete',
            data: {
                'placeholder_uuids': [placeholder_uuid]
            },
            success_function: function(input){
                load_placeholder_config();
            }
        });
    }

    function load_ignored_drives(){
        $('#ignored_drive_error').hide();
        helpers.ajax_call({
            url: '/tms/get_ignored_drives',
            success_function: function(input)
            {
                self.ignored_drives = input.data.ignored_drives;
                $('#ignored_drives_tmpl').tmpl({'drives' : self.ignored_drives}).appendTo($('#panes').empty());
                $('#add').clickOrEnter(add_ignored_drive);
                $('#drive_path').on("keypress", function(e){
                    if(e.charCode == 13){
                        add_ignored_drive();
                    }
                }).focus();

                $('.jq_drive .jq_delete').clickOrEnter(function(){
                    var index = $(this).attr("data_index");
                    remove_ignored_drive(index);
                });
            }
        });
    }

    function add_ignored_drive(){
        var path = $("#drive_path").val();
        if(!($.trim(path)).length == 0){
            $('#ignored_drive_error').hide();
            var index = $.inArray(path, self.ignored_drives);
            if(index > -1){
                $(".jq_drive[data_index="+index+"]").addClass("error").delay(1000).queue(function(next){
                    $(this).removeClass("error");
                    next();
                });
                return;
            }
            self.ignored_drives.push(path);
            save_ignored_drives();
        }
    }

    function remove_ignored_drive(index){
        if(index > -1)
            self.ignored_drives.splice(index, 1);
        $(".jq_drive[data_index="+index+"]").animate({"height" : 0, "padding-top": 0, "padding-bottom": 0}, 500, function(){
            save_ignored_drives();
        });
    }

    function save_ignored_drives(dont_refresh_display){
        var success_function = (dont_refresh_display != undefined) ? null : load_ignored_drives;
        helpers.ajax_call({
            url: '/tms/set_ignored_drives',
            data: {"ignored_drives": self.ignored_drives},
            success_function: success_function
        });
    }

    function load_complex_config() {
        get_addresses();
        get_contacts();
        $('#general_config_type_tmpl').tmpl().appendTo($('#panes').empty());

        $('#general_config_lower_page_elements_tmpl').tmpl().appendTo($('#panes'));
        $('#complex_details_save').clickOrEnter(save_complex);

        $('#contact_list_plus').click(function(){
            edit_contact_dialog();
        });
        $('#address_list_plus').click(function(){
            edit_address_dialog();
        });

        $('#transfer_settings_save').clickOrEnter(save_transfer_settings);

        $('#transfer_settings .jq_auto_transfer_clickable').click(function(e){
            _changes_made(true);
            $(this).addClass("selected").siblings().removeClass("selected");
        });
        $('#transfer_tonight input').live('keydown', function(){
            if(self.transfer_forecast_update_timer){
                clearTimeout(self.transfer_forecast_update_timer);
                self.transfer_forecast_update_timer = null;
            }
            self.transfer_forecast_update_timer = setTimeout(update_transfer_forecast, 300);
        });

        $('#migrate_complex').clickOrEnter(migrate_complex_information);

        $('#complex_auto_setup_button').click(auto_setup_complex);
        $('#kdm_generator').click(generate_kdms);

        $('#general_config_chat_email_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            },
            highlight: function(element){
                $(element).addClass("error");
            },
            unhighlight: function(element){
                $(element).removeClass("error");
            }
        });

        if(!core_only){
            helpers.ajax_call({
                url: '/core/configuration/get_chat_email_configuration',
                success_function: function(input) {
                    var settings = input.data;
                    $('#chat_email_server').val(settings.server);
                    $('#chat_email_port').val(settings.port);
                    $('#chat_email_to').val(settings.to);
                    $('#chat_email_cc').val(settings.cc);
                    $('#chat_email_from').val(settings.from);
                    //Trigger validation display update
                    $('#general_config_chat_email_form').valid();
                    $('#chat_email_save').clickOrEnter(save_chat_email);
                }
            });
            load_transfer_settings();
        }

        $('.complex_details_values .auto_select').clickOrEnter(function() {
            $(this).select();
        });
    }

    function save_chat_email(){
        if ($('#general_config_chat_email_form').valid()) {
            var settings = {};
            settings.server = $('#chat_email_server').val();
            settings.port = parseInt($('#chat_email_port').val(), 10);
            settings.to = $('#chat_email_to').val();
            settings.cc = $('#chat_email_cc').val();
            settings.from_ = $('#chat_email_from').val();
            helpers.ajax_call({
                url: '/core/configuration/set_chat_email_configuration',
                data: settings
            });
        }
    }

    function load_pos(){

        // Grab the screens that have configured servers and grab the uuids of those servers
        var screen_map = [];
        var server_uuid;
        var scrn;
        for( var scr_id in $device_store.screens ){
            server_uuid = null;
            scrn = $device_store.screens[scr_id];
            for( var index in scrn.devices ){
                if( scrn.devices[index].category == "sms"){
                    server_uuid = scrn.devices[index].id;
                    break;
                }
            }
            if( server_uuid != undefined ){
                screen_map.push({"screen_id":scrn.identifier,"device_uuid":server_uuid});
            }
        }
        screen_map.sort_screens('screen_id');

        // Draw
        $('#general_config_pos_tmpl').tmpl({
            pos_config: self.pos_configuration,
            screen_map: screen_map
        }).appendTo($('#panes').empty());

        var len = full_days.length - 1;
        var days = [];
        for(var i = 0; i <= len; i++){
            days.push({
                value: i,
                text: full_days[i]
            });
        }

        $('#pos_day_select').multi({
            options: days,
            selected: self.pos_configuration.pos_first_day_of_week,
            click: function(){
                _changes_made(true);
            }
        });
        $('#pos_enabled_switch, #pos_auto_transfer_switch').switch({changed: _changes_made});
        $('#pos_enabled_switch, #pos_vista_feature_switch').switch({changed: _changes_made});
        $("#pos_save_config_changes").on("click", apply_pos_configuration);
        $('#pos_settings_table').on('enter.general_config', 'input', apply_pos_configuration);
        $('#pos_settings_table input').bind('change keyup',function(e){ _changes_made(true); });
        $('#pos_settings_table .jq_pos_clickable').click(function(e){ _changes_made(true); });

        // POS device matrix handlers
        $(".pos_screen_match").on("click", function(){
            $(this).toggleClass("pos_screen_matched icon-checkmark icon-cross-2");
            $(this).parent().siblings().children(".pos_screen_match").removeClass("pos_screen_matched icon-checkmark").addClass("icon-cross-2");
            var ext_id = $(this).closest("tr").attr("external_id");
            var device_id = $(this).closest("table").attr("device_uuid");
            if( self.pos_device_maps_updated[device_id] == undefined){
                self.pos_device_maps_updated[device_id] = [];
            }
            if( self.pos_device_maps_updated[device_id].indexOf(ext_id) == -1 ){
                self.pos_device_maps_updated[device_id].push(ext_id);
            }
            _changes_made(true);
        });

    }

    function load_kdm_email(){
        $('#general_config_kdm_email_tmpl').tmpl(self.kdm_email_configuration).appendTo($('#panes').empty());
        $('#kdm_email_switch').switch({changed: _changes_made});
        $("#kdm_email_save_config_changes").on("click", apply_kdm_email_configuration);
        $('#kdm_email_settings_table').on('enter.general_config', 'input', apply_kdm_email_configuration);
        $('#kdm_email_settings_table input').bind('change keyup', function(e){ _changes_made(true); });
        $('#kdm_email_settings_table .jq_kdm_email_clickable').click(function(e){ _changes_made(true); });
        $('#kdm_email_protocol').change(function(e){ _changes_made(true); });
    }

    function load_bookends(){
        helpers.ajax_call({
            url: '/core/configuration/get_bookend_settings',
            success_function: function(input){

                var playlists_obj = input.data.playlists;
                var playlists = [];
                for(playlist_uuid in playlists_obj){
                    var playlist = playlists_obj[playlist_uuid];
                    playlist.id = playlist_uuid;
                    playlists.push(playlist);
                }
                playlists.sort(function(a,b){
                    return a.title.toLowerCase().localeCompare(b.title.toLowerCase());
                });
                input.data.playlists = playlists;

                // template
                $('#general_config_bookend_tmpl').tmpl({'data' : input.data}).appendTo($('#panes').empty());

                // enable start/end
                $('#jq_bookends_toggle_start').switch({
                    changed: function(on){
                        _validate_start_bookend();
                        _changes_made();
                    }
                });
                $('#jq_bookends_toggle_end').switch({
                    changed: function(on){
                        _validate_end_bookend();
                        _changes_made();
                    }
                });

                // HMS
                $('#start_spl_hms').hms({'seconds' : input.data.start_of_day.spl_offset, 'disabled' : !input.data.start_of_day.active}).keydown(function(event){_changes_made(true);});
                $('#end_spl_hms').hms({'seconds' : input.data.end_of_day.spl_offset, 'disabled' : !input.data.end_of_day.active}).keydown(function(event){_changes_made(true);});

                // Schedule Objects
                start_of_day_title = (input.data.start_of_day != undefined && input.data.start_of_day.spl_uuid && playlists_obj[input.data.start_of_day.spl_uuid] != undefined) ? playlists_obj[input.data.start_of_day.spl_uuid].title : "[" + gettext("Select a playlist") + "]";
                end_of_day_title = (input.data.end_of_day != undefined && input.data.end_of_day.spl_uuid && playlists_obj[input.data.end_of_day.spl_uuid] != undefined) ? playlists_obj[input.data.end_of_day.spl_uuid].title : "[" + gettext("Select a playlist") + "]";

                // Handlers
                $(".jq_start_bookend_list > div").on("click", function(){
                    if($('#jq_bookends_toggle_start').switch("on")){
                        _select_bookend_playlist($(this));
                    }
                });
                $(".jq_end_bookend_list > div").on("click", function(){
                    if( $('#jq_bookends_toggle_end').switch('on') ){
                        _select_bookend_playlist($(this));
                    }
                });

                $('.global_playlist_object[selected="selected"]').each(function(){
                    var offset_top = $(this).offset().top;
                    var list = $(this).closest('.bookend_playlist_list');
                    list.animate({scrollTop: ($(this).offset().top - list.offset().top - (list.height()/2) + ($(this).height()/2))}, 300, "easeInOutQuad");
                });

                function save_bookends(){
                    var data = {};
                    data['start_active'] = $("#jq_bookends_toggle_start").switch("on");
                    data['start_spl_offset'] = $('#start_spl_hms').hms('retrieve');
                    data['start_spl_uuid'] = $('.jq_start_bookend_list > div[selected=selected]').attr("playlist_id") != undefined ? $('.jq_start_bookend_list > div[selected=selected]').attr("playlist_id") : "";
                    data['end_active'] = $("#jq_bookends_toggle_end").switch("on");
                    data['end_spl_offset'] = $('#end_spl_hms').hms('retrieve');
                    data['end_spl_uuid'] = $('.jq_end_bookend_list > div[selected=selected]').attr("playlist_id") != undefined ? $('.jq_end_bookend_list > div[selected=selected]').attr("playlist_id") : "";

                    if( data['start_spl_uuid'] == "" && data['start_active'] == true ){
                        notification.error_msg(gettext("Select a Start-of-Day Playlist"));
                    }else if( data['end_spl_uuid'] == "" && data['end_active'] == true ){
                        notification.error_msg(gettext("Select an End-of-Day Playlist"));
                    }else{
                        helpers.ajax_call({
                            url: '/core/configuration/save_bookend_settings',
                            data: data
                        });
                        _changes_made(false);
                    }
                }
                $('#jq_bookends_body_start, #jq_bookends_body_end').on('enter.general_config', 'input, select', save_bookends);
                $('#bookend_save_button').click(save_bookends);
                $('#jq_bookends_body_end input.inactive, #jq_bookends_body_end.inactive select').attr('disabled', 'disabled');
                $('#jq_bookends_body_start input.inactive, #jq_bookends_body_start.inactive select').attr('disabled', 'disabled');

                _validate_start_bookend();
                _validate_end_bookend();
            }
        });
    }

    function _select_bookend_playlist(bookend){
        $(bookend).siblings().attr("selected",false);
        if($(bookend).attr("selected") != undefined){
            $(bookend).attr("selected",false);
        }else{
            $(bookend).attr("selected","selected");
        }
        _changes_made(true);
    }

    function _validate_start_bookend(){
        if(!$('#jq_bookends_toggle_start').switch('on')){
            $('#jq_bookends_body_start .jq_bookend_offset').switchClass('active', 'inactive');
            $('#jq_bookends_body_start .jq_bookend_list').switchClass('active', 'inactive');
            $('#jq_bookends_body_start .jq_bookend_offset input').attr('disabled', 'disabled');
            $('.bookend_start_enabled_text').removeClass("enabled");
            $('.bookend_start_enabled_text').text(gettext("Disabled"));
            $("#jq_sod_filter").attr("disabled",true);
            $("#jq_sod_filter").val("");
            $(".jq_start_bookend_list > div").show();
        }else{
            $('#jq_bookends_body_start .jq_bookend_offset').switchClass('inactive', 'active');
            $('#jq_bookends_body_start .jq_bookend_list').switchClass('inactive', 'active');
            $('#jq_bookends_body_start .jq_bookend_offset input').removeAttr('disabled');
            $('.bookend_start_enabled_text').addClass("enabled");
            $('.bookend_start_enabled_text').text(gettext("Enabled"));
            $("#jq_sod_filter").removeAttr("disabled");
        }
    }

    function _validate_end_bookend(){
        if(!$('#jq_bookends_toggle_end').switch('on')){
            $('#jq_bookends_body_end .jq_bookend_offset').switchClass('active', 'inactive');
            $('#jq_bookends_body_end .jq_bookend_list').switchClass('active', 'inactive');
            $('#jq_bookends_body_end .jq_bookend_offset input').attr('disabled', 'disabled');
            $('.bookend_end_enabled_text').removeClass("enabled");
            $('.bookend_end_enabled_text').text(gettext("Disabled"));
            $("#bookend_schedule_end_object").fadeOut("slow");
            $("#jq_eod_filter").attr("disabled",true);
            $("#jq_eod_filter").val("");
            $(".jq_end_bookend_list > div").show();
        }else{
            $('#jq_bookends_body_end .jq_bookend_offset').switchClass('inactive', 'active');
            $('#jq_bookends_body_end .jq_bookend_list').switchClass('inactive', 'active');
            $('#jq_bookends_body_end .jq_bookend_offset input').removeAttr('disabled');
            $('.bookend_end_enabled_text').text(gettext("Enabled"));
            $('.bookend_end_enabled_text').addClass("enabled");
            $("#bookend_schedule_end_object").fadeIn("slow");
            $("#jq_eod_filter").removeAttr("disabled");
        }
    }

    function load_users(){
        helpers.ajax_call({
            url: '/get_user_accounts',
            success_function: function(input) {
                self.user_details = input;

                $('#user_management_tmpl').tmpl(input).appendTo($('#panes').empty());

                helpers.set_buttons('#user_management_controls', [{
                        text: gettext('New'),
                        image: 'new',
                        onClick: function(){
                            user_dialog(null);
                        }
                    },{
                        text: gettext('Edit'),
                        image: 'edit',
                        disabled: true,
                        _class: 'jq_edit_user_btn',
                        onClick: function(){
                            var user_id = $('.jq_user_details.selected').attr("user_id");
                            user_dialog(user_id);
                        }
                    },{
                        text:gettext('Delete'),
                        image:'delete',
                        disabled:true,
                        _class:'jq_delete_user_btn',
                        onClick: delete_user
                    }
                ]);

                $('.jq_user_details').on('click', function(){
                    var $this = $(this);
                    $this.toggleClass('selected',true).siblings().toggleClass('selected',false);
                    $('.jq_edit_user_btn').button('option', 'disabled', false);

                    var user = $.grep(self.user_details.users, function(user){
                        return user.user_id == $this.attr("user_id");
                    })[0];

                    if(user.display_name != self.current_user){
                        $('.jq_delete_user_btn').button('option', 'disabled', false);
                    }
                    else{
                        $('.jq_delete_user_btn').button('option', 'disabled', true);
                    }
                });
            }
        });
    }

    function user_dialog(user_id){
        var user = $.grep(self.user_details.users, function(user){
            return user.user_id == user_id;
        })[0];

        var buttons = [];
        buttons.push({
            'text': gettext('Save'),
            'action': function(){
                $('#add_user_name, #current_password, #add_password, #add_display_name, #add_user_group').removeClass('error');
                var user = {
                    user_id: user_id,
                    username: $('#add_user_name').val(),
                    current_password: $('#current_password').val(),
                    new_password: $('#add_password').val().trim(),
                    confirm_new_password: $('#confirm_add_password').val().trim(),
                    display_name: $('#add_display_name').val(),
                    group: $('#add_user_group').val()
                };
                if($('#add_user_form').valid()){
                    edit_user(user);
                }
            }
        });
        dialog.open({
            'data': {
                'groups': self.user_details.groups,
                'user': user
            },
            'title':  user ? gettext('Edit User') : gettext("New User"),
            'template': '#general_config_edit_user_tmpl',
            'buttons': buttons,
            'height': 400,
            'focus': true
        });

        $('#add_user_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            },
            highlight: function(element){
                $(element).addClass("error");
            },
            unhighlight: function(element){
                $(element).removeClass("error");
            },
            rules: {
                add_password: {
                    minlength: 5
                }
            }
        });
    }

    function edit_user(user){
        helpers.ajax_call({
            url: '/edit_user',
            data: {
                user: user
            },
            success_function: function(input) {
                dialog.close();
                $('.tab[config=users]').click();
            }
        });
    }

    function delete_user(){
        var user_id = $('.jq_user_details.selected').attr("user_id");
        var user = $.grep(self.user_details.users, function(user){
            return user.user_id == user_id;
        })[0];

        var buttons = [];
        buttons.push({
            'text': gettext('Delete'),
            'action': function(){
                if($('#delete_user_form').valid()){
                    helpers.ajax_call({
                        url: '/delete_user',
                        data: {
                            user_id: user_id
                        },
                        success_function: function(input) {
                            dialog.close();
                            $('.tab[config=users]').click();
                        }
                    });
                }
            }
        });

        dialog.open({
            'data': {
                'user': user
            },
            'title': gettext('Delete'),
            'template': '#general_config_delete_user_tmpl',
            'buttons': buttons,
            'width': 300,
            'height': 150
        });

        $('#current_password').keypress(function(event){
            if(event.which == 13){
                event.preventDefault();
                $('#at_button_0').click();
            }
        });

        $('#delete_user_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            },
            highlight: function(element){
                $(element).addClass("error");
            },
            unhighlight: function(element){
                $(element).removeClass("error");
            }
        });
    }

    function toggle_pos_setting(){
        $(this).addClass("selected").siblings().removeClass('selected');
    }

    function filter_sod_playlists(){
        var filter = $(this).val().toLowerCase();
        if( filter.length > 1){
            $(".jq_start_bookend_list > div").each(function(){
                $(this).toggle(_filter_playlist($(this),filter));
            });
        }else{
            $(".jq_start_bookend_list > div").show();
        }
    }

    function filter_eod_playlists(){
        var filter = $(this).val().toLowerCase();
        if( filter.length > 1){
            $(".jq_end_bookend_list > div").each(function(){
                $(this).toggle(_filter_playlist($(this),filter));
            });
        }else{
            $(".jq_end_bookend_list > div").show();
        }
    }

    function _filter_playlist(dom, filter){
        var split = filter.split(" ");
        var title = $(dom).text().toLowerCase();
        var uuid = $(dom).attr("playlist_id").toLowerCase();
        if( uuid.indexOf(filter) != -1){
            return true;
        }
        for(var i in split ){
            if(title.indexOf(split[i]) == -1){
                return false;
            }
        }
        return true;
    }

    function pos_auto_playlist_change(){
        self.pos_auto_playlist_name_timer = null;
        helpers.ajax_call({
            url: '/core/configuration/test_naming_pattern',
            data:{
                'pos_auto_playlist_name_pattern': $('#pos_auto_playlist_name_select_box').val(),
                'pos_auto_playlist_date_format': $('#pos_date_choice_select_box').val()
            },
            success_function : function(input){
                $('#auto_playlist_name_testing').html(input.data.title);
            }
        });
    }

    function pos_auto_playlist_reset(){
        helpers.ajax_call({
            url: '/core/configuration/get_default_naming_pattern',
            success_function: function(input){
                $('#pos_auto_playlist_name_select_box').val(input.data.pattern);
                $('#pos_date_choice_select_box').val(input.data.date_format);
                if(self.pos_auto_playlist_name_timer){
                    clearTimeout(self.pos_auto_playlist_name_timer);
                    _changes_made(true);
                }
                self.pos_auto_playlist_name_timer = setTimeout(pos_auto_playlist_change, 800);
            }
        });
    }

    function apply_pos_configuration(){
        if(!$.isEmptyObject(self.pos_device_maps_updated) && !confirm(gettext("POS Device configuration changed. POS Sessions will be reset. Continue?"))){
            return;
        }
        pos_config = {};
        pos_config["pos_feed_type"] = $("#pos_feed_type_config").val();
        pos_config["pos_week_offset"] = $("#pos_week_offset_config").val();
        pos_config["pos_first_day_of_week"] = $('#pos_day_select').multi("val");
        pos_config["pos_cinema_identifier"] = $("#pos_cinema_identifier_config").val();
        pos_config["pos_default_session_length"] = $("#pos_default_session_length").val();

        pos_config["pos_enabled"] = $("#pos_enabled_switch").switch("on");
        pos_config["pos_auto_transfer_time"] = $("#pos_auto_transfer_switch").switch("on");
        pos_config["pos_vista_feature_stamp"] = $("#pos_vista_feature_switch").switch("on");

        $complex_status.pos["enabled"] = pos_config["pos_enabled"] ? true : false;

        // re draw nav to include the POS tab
        build_main_nav();
        $("#main_nav_config").addClass('selected');

        // Update POS device map
        if(!$.isEmptyObject(self.pos_device_maps_updated)){
            var device_map_updates = {
                "pos":{}
            };
            $("div.pos_screen_match_wrapper").each(function(){
                var ext_device_uuid = $(this).find(".pos_screen_match_table").attr("device_uuid");
                var ext_id;
                $(this).find("tbody tr").each(function(){
                    ext_id = $(this).attr("external_id");
                    if(self.pos_device_maps_updated[ext_device_uuid] != undefined && self.pos_device_maps_updated[ext_device_uuid].indexOf(ext_id) != -1 ){
                        var match = $(this).find(".pos_screen_matched");
                        if(device_map_updates.pos[ext_device_uuid] == undefined){
                            device_map_updates.pos[ext_device_uuid] = {};
                        }
                        if(match.length > 0){
                            device_map_updates.pos[ext_device_uuid][$(this).attr("external_id")] = $(match).parent().attr("device_uuid");
                        }
                        else{
                            device_map_updates.pos[ext_device_uuid][$(this).attr("external_id")] = null;
                        }
                    }
                });
            });
            helpers.ajax_call({
                url: '/core/configuration/save_external_device_maps',
                data: {
                    device_maps:device_map_updates
                },
                notify: false
            });
            self.pos_device_maps_updated = {};
        }

        // send request
        helpers.ajax_call( {
            url: '/core/pos/set_configuration',
            data: {pos_config: pos_config},
            success_function: function(){
                helpers.ajax_call({
                    url: '/core/pos/get_configuration',
                    success_function: function(input){
                        self.pos_configuration = input.data;
                    }
                });
            }
        });

        _changes_made(false);
    }

    function apply_kdm_email_configuration(){
        kdm_email_config = {};
        kdm_email_config["username"] = $("#kdm_username_config").val();
        kdm_email_config["password"] = $("#kdm_password_config").val();
        kdm_email_config["server"] = $("#kdm_server_config").val();
        kdm_email_config["protocol"] = $("#kdm_email_protocol").val();
        kdm_email_config["enabled"] = $('#kdm_email_switch').switch("on");
        self.kdm_email_configuration = kdm_email_config;
        helpers.ajax_call({
            url:'/core/configuration/set_kdm_email_configuration',
            loader: {
                'target': $("#main_section")
            },
            data:{
                'user': kdm_email_config["username"],
                'passw': kdm_email_config["password"],
                'server': kdm_email_config["server"],
                'protocol': kdm_email_config["protocol"],
                'enabled': kdm_email_config["enabled"]
            }
        });

        _changes_made(false);
    }

    function save_complex(){
         var data = {
            'name':$('#complex_name').val().trim(),
            'audio_lang':$('#complex_audio_lang').val(),
            'sub_lang':$('#complex_sub_lang').val(),
            'timezone':$('#complex_timezone').val(),
        };
        helpers.ajax_call({
            url: '/core/configuration/save_complex_settings',
            data: data,
            success_function: function(){
                sync_complex_infos();
                sync_device_infos();
                sync_complex_status(false, null);
            }
        });
    }

    function load_database(){
        $("#panes").empty().append($("#database_tmpl").tmpl());
    }

    function edit_timeframe(uuid){
        var timeframe = $.grep(self.timeframes, function(x){
            return x['uuid'] == uuid;
        })[0] || {screens: {}, start: moment(0), end: moment(0)};

        var screens;
        var def = timeframe['screens']['default'] !== undefined;

        dialog.open({
            title: gettext('Edit'),
            hbtemplate: "#general_config_timeframe_edit_tmpl",
            data: {"default": def},
            buttons: [{
                text: gettext("Save"),
                action: function(){
                    save_timeframe({
                        uuid: uuid,
                        "default": def,
                        screens: screens.get_selected(),
                        start: $('#timeframe_start').hms('retrieve'),
                        end: $('#timeframe_end').hms('retrieve')
                    });
                    dialog.close();
                }
            }]
        });

        screens = new ScreenSelector({
            dom: '#timeframe_screen_selector',
            selected: Object.keys(timeframe['screens'])
        });

        $('#timeframe_start').hms({
            minutes: timeframe['start'].minutes(),
            hours: timeframe['start'].hours(),
        });
        $('#timeframe_end').hms({
            minutes: timeframe['end'].minutes(),
            hours: timeframe['end'].hours(),
        });
    }

    function save_timeframe(data){
        helpers.ajax_call({
            url: '/core/configuration/save_log_timeframe',
            data: data,
            success_function: function(){
                $.when(load_timeframes()).done(function(timeframes){
                    self.timeframes = timeframes;
                    draw_timeframes(timeframes);
                });
            }
        });
    }

    function load_timeframes(){
        var def = $.Deferred();
        helpers.ajax_call({
            url: '/core/configuration/get_log_timeframes',
            success_function: function(input){
                var start = moment(self.log_configuration.start_hours + " : " + self.log_configuration.start_minutes, "HH:mm");
                var end = moment(self.log_configuration.end_hours + " : " + self.log_configuration.end_minutes, "HH:mm");
                var timeframes = [];
                for(var i in input['data']){
                    var x = input['data'][i];
                    x['start'] = moment().startOf('day').add('s', x['start']);
                    x['end'] = moment().startOf('day').add('s', x['end']);
                    x['undeletable'] = x['uuid'] === "default";
                    timeframes.push(x);
                }
                def.resolve(timeframes);
            }
        });
        return def.promise();
    }

    function delete_timeframe(uuid){
        helpers.ajax_call({
            url: '/core/configuration/delete_log_timeframe',
            data: {uuid: uuid},
            success_function: function(){
                $.when(load_timeframes()).done(function(timeframes){
                    self.timeframes = timeframes;
                    draw_timeframes(timeframes);
                });
            }
        });
    }

    function draw_timeframes(timeframes){
        $('#general_config_timeframes_tmpl').tmpl2({
            timeframes: timeframes
        }, "#log_collection_timeframes");
        
        $('#timeframes_table .edit_action').click(function(e){
            var uuid = $(e.target).closest('.actions').attr("data-uuid");
            edit_timeframe(uuid);
        });
        $('#timeframes_table .delete_action').click(function(e){
            var uuid = $(e.target).closest('.actions').attr("data-uuid");
            delete_timeframe(uuid);
        });
        $('#timeframes_table .add_button').click(function(){
            edit_timeframe();
        });
    }

    function load_log_settings(){
        var usb_paths = [];
        for(var device in $device_store.devices){
            if($device_store.devices[device]['type'] == "usb" || $device_store.devices[device]['type'] == "drive"){
                usb_paths.push($device_store.devices[device]['path']);
            }
        }
        $("#panes").empty().append($("#logs_export_tmpl").tmpl({
            usb_paths: usb_paths,
            log_conf: self.log_configuration
        }));

        $(".usb_path").on("click",function(){
            $('#logs_path').val($(this).text());
        });
        $("#store_device_logs").switch();

        $.when(load_timeframes()).done(function(timeframes){
            self.timeframes = timeframes;
            draw_timeframes(timeframes);
        });

        $("#download_logs_btn").on("click", download_logs);
        $("#save_log_time_btn").on("click", save_log_time);

        $('.log_time input').on('keyup', update_log_settings);

        var limit = self.log_configuration['storage_limit'];
        var avg = parseInt(self.log_configuration['log_day_average']) || 0;
        var low = Math.round(((avg * 30) / 1000 / 1000 / 1000) * 100);
        var med = Math.round(((avg * 365 * 10) / 1000 / 1000 / 1000) * 100);

        $('#error_range').css({left: "0%", width: low + "%"});
        $('#warning_range').css({left: low + "%", width: med + "%"});
        $('#ideal_range').css({left: low + med + "%", right: "0%"});

        function update_limit(limit){
            update_slider(limit);
            var units = "MB";
            if(limit >= 1000){
                limit /= 1000;
                units = "GB";
            }
            $('#log_limit_text').text(limit + " " + units);
        }

        function update_slider(limit){
            var per = (limit / 10000) * 100;
            var klass = "ideal";
            if(per <= low){
                klass = 'error';
            }
            else if (per <= med){
                klass = 'warning';
            }
            $('#log_limit_slider .ui-slider-handle').removeClass('ideal').removeClass('warning').removeClass('error').addClass(klass);
        }

        update_limit(limit);
        $('#log_limit_slider').slider({
            value: limit,
            min: 1000,
            max: 10000,
            step: 1000,
            slide: function(e, ui){
                update_limit(ui.value);
            }
        });
        update_slider(limit);
        update_log_settings();
    }

    function update_log_settings(){
        $("#log_start_value").text(gettext("Collection Starts at") + " " + $("#log_start").find(".hms_hours").find("input").val() + ":" + $("#log_start").find(".hms_minutes").find("input").val());
        $("#log_end_value").text(gettext("Collection Ends at") + " " + $("#log_end").find(".hms_hours").find("input").val() + ":" + $("#log_end").find(".hms_minutes").find("input").val());
    }

    function save_log_time(){
        var store_device_logs = $("#store_device_logs").switch("on");
        var storage_limit = parseInt($('#log_limit_slider').slider("option", "value"));
        var retry_days = $('#log_retry').val();

        $("#log_collection_validation").empty();
        data = {
            'store_device_logs': store_device_logs,
            'storage_limit': storage_limit,
            retry_days: $.val_or_default(retry_days, self.log_configuration.retry_days)
        };
        helpers.ajax_call({
            url: '/core/configuration/save_log_settings',
            data: data,
            success_function: function(){
                $.extend(self.log_configuration, data);
                load_log_settings();
            }
        });
    }

    function download_logs(){
        var cheat_form = '<form style="display: none" action="/tms/download_logs" method="POST" id="form">';
        cheat_form += '</form>';
        //in firefox, the form must be appended to the DOM before it is submitted
        $('#main_section').append(cheat_form);
        $('#form').submit();
        $('#form').remove();
    }

    function save_auto_cleanup_settings(){
        var cleanupsettings = {};
        cleanupsettings['core_auto_cleanup_kdms'] = $('#core_auto_cleanup_kdms').switch("on");
        cleanupsettings['core_auto_cleanup_packs'] = $('#core_auto_cleanup_packs').switch("on");
        cleanupsettings['core_auto_cleanup_schedules'] = $('#core_auto_cleanup_schedules').switch("on");
        cleanupsettings['core_auto_cleanup_pos'] = $('#core_auto_cleanup_pos').switch("on");
        cleanupsettings['core_auto_cleanup_titles'] = $('#core_auto_cleanup_titles').switch("on");
        cleanupsettings['core_auto_cleanup_transfers'] = $('#core_auto_cleanup_transfers').switch("on");
        cleanupsettings['core_auto_cleanup_log_files'] = $('#core_auto_cleanup_log_files').switch("on");
        cleanupsettings['core_auto_cleanup_playlists'] = $('#core_auto_cleanup_playlists').switch("on");
        cleanupsettings['core_auto_cleanup_watchfolder'] = $('#core_auto_cleanup_watchfolder').switch("on");
        cleanupsettings['core_auto_cleanup_playlists_expiry_days'] = Number($('#core_auto_cleanup_playlists_expiry_days').val().trim());
        helpers.ajax_call({
            url: '/core/configuration/save_auto_cleanup_settings',
            data: {'settings': cleanupsettings},
        });
    }

    function load_auto_cleanup_settings(){
        helpers.ajax_call({
            url: '/core/configuration/get_auto_cleanup_settings',
            success_function: function(cleanupsettings){
                $('#panes').empty().html($('#general_config_auto_cleanup_tmpl').tmpl(cleanupsettings));
                $('#auto_cleanup_settings_save').click(save_auto_cleanup_settings);
                $('.toggle_switch').switch();
            }
        });
    }

    function save_auto_playlist_generation(){
        var settings = {};
        settings["core_templated_playlist_name"] = $('#pos_auto_playlist_name_select_box').val();

        settings["core_templated_playlist_date_format"] = $('#pos_date_choice_select_box').val();

        helpers.ajax_call({
            url: '/core/configuration/save_auto_playlist_generation_settings',
            data: {settings: settings},
            success_function: function(response){
                _changes_made(false);
            }
        });
    }

    function load_auto_playlist_generation(){
        helpers.ajax_call({
            url: '/core/configuration/get_auto_playlist_generation_settings',
            success_function: function(settings){
                $('#panes').html($('#auto_playlist_generation_tmpl').tmpl(settings['data']));
                pos_auto_playlist_change();
                $('#pos_auto_playlist_name_select_box').change(function(){
                    if(self.pos_auto_playlist_name_timer){
                        clearTimeout(self.pos_auto_playlist_name_timer);
                    }
                    _changes_made(true);
                    self.pos_auto_playlist_name_timer = setTimeout(pos_auto_playlist_change, 800);
                });
                $('#pos_auto_playlist_reset').click(pos_auto_playlist_reset);
                $('#pos_date_choice_select_box').change(function(){
                    if(self.pos_auto_playlist_name_timer){
                        clearTimeout(self.pos_auto_playlist_name_timer);
                    }
                    _changes_made(true);
                    self.pos_auto_playlist_name_timer = setTimeout(pos_auto_playlist_change, 800);
                });
                $('#save_auto_playlist_generation_settings').click(save_auto_playlist_generation);
            }
        });

    }

    function load_transfer_settings(){
        return helpers.ajax_call({
            url: '/core/configuration/transfer_settings',
            success_function: update_transfer_settings
        });
    }

    function load_show_attributes(){
        if($("#show_attributes_pane").length == 0){
            $("#show_attributes_tmpl").tmpl2({}, "#panes");
        }
        var sa_call = helpers.ajax_call({
            url: '/core/configuration/show_attribute',
            loader: {
                target: "#matched_wrapper"
            }
        });
        var exsam_call = helpers.ajax_call({
            url: '/core/configuration/external_show_attribute_maps',
            loader: {
                target: "#unmatched_wrapper"
            }
        });

        $.when(sa_call, exsam_call).done(function(sa_data, exsam_data){
            // self.show_attributes = sa_data[0]['data'];
            self.show_attributes = $.map(sa_data[0]['data'], function(value, index){
                value['uuid'] = index;
                return [value];
            });
            self.show_attributes.sort(function(a, b){
                if(a['custom']){
                    return 1;
                }
                return -1;
            })
            self.external_show_attribute_maps = group_matched(exsam_data[0]['data']);
            draw_show_attribute_matcher();
        })
    }

    function group_matched(external_show_attribute_maps) {
        // groups a dictionary of external_show_attribute_maps
        // into a new dictionary keyed on 'matched' and 'unmatched'
        ex_sams  = {
            'unmatched': [],
            'matched': {},
        }
        $.each(external_show_attribute_maps, function(key, val){
            val['key'] = key
            if(!val.show_attribute_uuid){
                ex_sams['unmatched'].push(val);
            }
            else{
                ex_sams['matched'][key] = val;
            }
        });
        helpers.key_sort(ex_sams['unmatched'], 'source')
        return ex_sams;
    }

    function draw_show_attribute_matcher() {
        $('#general_config_unmatched_type_list_tmpl').tmpl2({
            'exsams': self.external_show_attribute_maps
        }, "#unmatched_wrapper");

        $('#general_config_type_list_tmpl').tmpl2({
            'show_attributes': self.show_attributes
        }, '#jq_current_show_attributes');

        $('.jq_matched_show_attribute').on('click','.delete', function(){
            var uuid = $(this).attr('uuid');
            unmatch_show_attribute(uuid);
        });
        $('.custom_show_attribute_delete').click(function(){
            var uuid = $(this).attr('uuid');
            delete_custom_show_attribute(uuid);
        });

        $('.exsam_match_button').click(function(e){
            show_match_tip($(e.target))
        });
        $('.exsam_new_button').click(function(e){
            show_new_tip($(e.target))
        });
    }

    var def_tip = {
        show: {
            event: 'none',
            ready: true
        },
        hide: {
            event: 'unfocus',
            fixed: true
        },
        position: {
            my: "bottom middle",
            at: "top middle"
        },
        style: {
            classes: 'qtip-shadow qtip-rounded qtip-tms'
        }
    }

    function show_new_tip(dom){
        def_tip['content'] = $('#sa_new_tmpl').tmpl2({
            show_attributes: self.show_attributes
        })
        def_tip['events'] = {
            render: function(e, api){
                $('#sa_screen_slider .slider_switch').switch({
                    options: [{
                        text: gettext("Yes")
                    },{
                        text: gettext("No")
                    }]
                });
                $('#sa_new_button').click(function(){
                    var exsam_uuid = dom.attr("data-uuid");
                    var is_screen = $('#sa_screen_slider .slider_switch').switch('on');
                    create_show_attribute(exsam_uuid, is_screen)
                });
            },
            hide: function(e, api){
                api.destroy();
            }
        }
        dom.qtip(def_tip);
    }


    function show_match_tip(dom){
        def_tip['content'] = $('#sa_match_tmpl').tmpl2({
            show_attributes: self.show_attributes
        })
        def_tip['events'] = {
            render: function(e, api){
                var button = $('#sa_match_button').button({'disabled': true});
                var select = $('#sa_match_select');
                select.change(function(){
                    button.button('option', 'disabled', $(this).val() === '');
                });
                button.click(function(){
                    var sa_uuid = select.find(":selected").val();
                    var exsam_uuid = api.elements.target.attr("data-uuid");
                    match_show_attribute(sa_uuid, exsam_uuid);
                });
            },
            hide: function(e, api){
                api.destroy();
            }
        }
        dom.qtip(def_tip);
    }

    function unmatch_show_attribute(uuid){
        helpers.ajax_call({
            url: '/core/configuration/unmatch_show_attribute',
            data: {
                'uuid': uuid
            },
            success_function: load_show_attributes
        });
    }

    function delete_custom_show_attribute(uuid){
        helpers.ajax_call({
            url: '/core/configuration/delete_show_attribute',
            data: {
                'uuid': uuid
            },
            success_function: load_show_attributes
        });
    }

    function match_show_attribute(sa_uuid, exsam_uuid){
        helpers.ajax_call({
            url: '/core/configuration/match_show_attribute',
            data: {
                'show_attribute': {
                    'show_attr_uuid': sa_uuid,
                    'uuid': exsam_uuid
                }
            },
            success_function: load_show_attributes
        });
    }

    function create_show_attribute(exsam_uuid, is_screen){
        var exsam = $.grep(self.external_show_attribute_maps['unmatched'], function(x){
            if(x['key'] == exsam_uuid){
                return x;
            }
        })[0]

        helpers.ajax_call({
            url: '/core/configuration/save_show_attribute',
            data: {
                'show_attribute': {
                    'external_show_attr': exsam_uuid,
                    'screen_attribute': is_screen,
                    'custom': true,
                    'name': exsam['external_id']
                }
            },
            success_function: load_show_attributes
        });
    }

    function update_transfer_settings(input){
        $('#transfer_tonight').hms({
            seconds: 0,
            minutes: parseInt(input.data.tonight_minutes),
            hours: parseInt(input.data.tonight_hours)
        });
        $('#transfer_tonight .hms_seconds').hide();
        $('#auto_transfer_time_multi').multi({
            options: [{
                text: gettext("Now"),
                value: "asap"
            },{
                text: gettext("Tonight"),
                value: "tonight"
            }],
            selected: input['data']['auto_transfer_asap'] ? "asap" : "tonight"
        });
        $('#auto_transfer_switch').switch();
        $("#auto_transfer_switch").toggleClass("on", input.data.auto_transfer_enabled);

        update_transfer_forecast();
    }

    function update_transfer_forecast(){
        var seconds_chosen = $('#transfer_tonight').hms('retrieve');
        chosen_hours = parseInt($("#transfer_tonight").find(".hms_hours").find("input").val());
        chosen_minutes = parseInt($("#transfer_tonight").find(".hms_minutes").find("input").val());

        var tmp_time = helpers.core_now();
        var seconds_now = tmp_time.getHours()*60*60 + tmp_time.getMinutes()*60;
        var forecast_time = new Date(tmp_time.getFullYear(), tmp_time.getMonth(), tmp_time.getDate(), chosen_hours, chosen_minutes);

        forecast_time = moment(forecast_time);

        if(seconds_now > seconds_chosen){
            forecast_time.add('d',1);
        }

        $('#transfer_forecast').html(gettext('Next transfer') + ': ' + moment(forecast_time).format('YYYY-MM-DD HH:mm'));
    }

    function save_transfer_settings(){
        helpers.ajax_call({
            url: '/core/configuration/save_transfer_settings',
            data: {
                'tonight_hours': $("#transfer_tonight").find(".hms_hours").find("input").val(),
                'tonight_minutes': $("#transfer_tonight").find(".hms_minutes").find("input").val(),
                'auto_transfer_enabled': $('#auto_transfer_switch').switch("on"),
                'auto_transfer_asap': $('#auto_transfer_time_multi').multi("is_selected", 'asap'),
            },
        });
        _changes_made(false);
    }

    function backup_db() {
        if(!confirm(gettext("Are you sure you want to back up your database?")))
            return;
        helpers.ajax_call({
            url: '/tms/backup_db',
            loader: {
                'target': $("#main_section"),
                'caption': "Backing up database. Please wait..."
            },
            timeout: 120000,
            data: {}
        });
    }

    function restore_db() {
        if(!confirm(gettext("Are you sure you want to restore your database?")))
            return;
        helpers.ajax_call({
            url: '/tms/restore_db',
            loader: {
                'target': $("#main_section"),
                'caption': "Restoring database. This could take a few minutes..."
            },
            timeout: 120000,
            data: {}
        });
    }

    function generate_kdms(){
        helpers.ajax_call({
            url: '/core/generate_kdms',
            loader: {
                "target": "#main_section",
                "caption": "Generating..."
            },
            timeout: 180000
        });
    }

    function auto_setup_complex(){
        var mode = $("#auto_setup_mode").val();
        helpers.ajax_call({
            url: '/core/auto_configure',
            data: { 'mode': mode },
            loader: {
                "target": "#main_section",
                "caption": gettext("Configuring...")
            },
            timeout: 180000
        });
    }

    function migrate_complex_information(){
        var cfg = $("#complex_migration_cfg_file").val();
        $("#migrate_complex_input").remove();
        $("#migrate_complex").remove();
        helpers.ajax_call({
            url: '/tms/migrate_system',
            data: {
                'config_dir':cfg
            },
            loader: {
                "target": "#complex_migration",
                "caption": gettext("Migrating complex. This may take a few minutes...")
            },
            timeout: 480000,
            success_function:function(input){
                $('#migration_result_tmpl').tmpl(input).appendTo($("#general_config_complex_migration_form").find("tbody"));
            },
            error_function:function(input){
                $('#migration_result_tmpl').tmpl(input).appendTo($("#general_config_complex_migration_form").find("tbody"));
            }
        });
    }

    function _changes_made(bool){
        if(bool === undefined){
            bool = true;
        }
        g_prevent_navigation = bool;
        self.prevent_navigation = bool;
        $('.jq_enable_on_select').button('option', 'disabled', !bool);
    }

    function _navigate(){
        if(self.prevent_navigation == false || confirm(gettext("There are unsaved changes on this page.\n Are you sure you want to leave?"))){
            _changes_made(false);
            return true;
        }else{
            return false;
        }
    }

    function edit_address(address_id){
        edit_address_dialog(address_id);
        set_address_info(address_id);
    }

    function edit_contact(contact_id){
        edit_contact_dialog(contact_id);
        set_contact_info(contact_id);
    }

    function set_address_info(address_id){
        var address = self.address_type[address_id];

        $('#address_type').val(address.type);
        $('#address_addressee').val(address.addressee);
        $('#address_streetaddress').val(address.streetaddress);
        $('#address_streetaddress2').val(address.streetaddress2);
        $('#address_city').val(address.city);
        $('#address_province').val(address.province);
        $('#address_postcode').val(address.postcode);
        $('#address_country option').filter(function() {
            return this.value == address.country;
        }).attr('selected', true);
    }

    function edit_address_dialog(address_id){
        dialog.open({
            title: gettext('Edit Address'),
            template: '#general_address_pane_type_tmpl',
            buttons: [{
                text: gettext("Save"),
                action: function(){
                    if(!validate_address()){
                        return
                    }
                    save_address(address_id);
                    dialog.close();
                }
            }]
        });

    }

    function edit_contact_dialog(contact_id){
        dialog.open({
            title: gettext('Edit Contact'),
            template: '#general_contact_pane_type_tmpl',
            buttons: [{
                text: gettext("Save"),
                action: function(){
                    if(!validate_contact()){
                        return
                    }
                    save_contact(contact_id);
                    dialog.close();
                }
            }]
        });
    }

    function delete_contact(contact_id){
        helpers.ajax_call({
            url: '/core/configuration/delete_contact/' + contact_id,
            success_function: function(response) {
                get_contacts();
            }
         });
    }

    function delete_address(address_id) {
        helpers.ajax_call({
            url: '/core/configuration/delete_address/' + address_id,
            success_function: function(response) {
                get_addresses();
            }
        });
    }

    function set_contact_info(contact_id){
        var contact = self.contact_type[contact_id]
        $('#contact_name').val(contact.name);
        $('#contact_email').val(contact.email);
        $('#contact_phone1').val(contact.phone1);
        $('#contact_type').val(contact.type);
    }

    function get_contacts(){
         helpers.ajax_call({
            url: '/core/configuration/get_contacts',
            success_function: function(contacts) {
                self.contact_type = contacts['data'];
                $('#general_contact_list_type_tmpl').tmpl({"contact_type": self.contact_type}).appendTo($('#contact_select').empty());

                $('.contact_list_edit').click(function(){
                    var contact_id = $(this).attr('data-id');
                    edit_contact(contact_id);
                });
                $('.contact_list_delete').click(function(){
                    var contact_id = $(this).attr('data-id');
                    delete_contact(contact_id);
                });
            }
        });
    }

    function get_addresses() {
        helpers.ajax_call({
            url: '/core/configuration/get_addresses',
            success_function: function (addresses) {
                self.address_type = addresses['data'];
                $('#general_address_list_type_tmpl').tmpl({"address_type": self.address_type}).appendTo($('#address_select').empty());

                $('.address_list_edit').click(function(){
                    var address_id = $(this).attr('data-id');
                    edit_address(address_id);
                });
                $('.address_list_delete').click(function(){
                    var address_id = $(this).attr('data-id');
                    delete_address(address_id);
                });
            }
        });
    }

    function validate_contact() {
        self.contact_validator = $("#contact_form").validate({
            onfocusout: function(element) {
                $(element).valid();
            },
            errorClass: "contact_error",
            errorElement: "div",
            errorPlacement: function(error, element) {
                error.insertAfter(element);
            },
            rules: {
                contact_name: {
                    required: true,
                },
                contact_email: {
                    required: function(element) {
                        return ($("#contact_phone1").val().length<=0);
                    },
                    email: true,
                },
                contact_phone1: {
                    required: function(element) {
                        return ($("#contact_email").val().length<=0);
                    },
                }
            },
            messages: {
                contact_name: gettext('Type a name'),
                contact_phone1: gettext('An email address or a phone number is required'),
                contact_email: {
                   email: gettext('Type a valid email address'),
                   required: gettext('An email address or a phone number is required')
                }
            },
        });

        // Worst function name ever...
        return self.contact_validator.form();
    }

    function clear_contact_input(){
        $('#contact_name').val('');
        $('#contact_email').val('');
        $('#contact_phone1').val('');
        $('#contact_type').val('');
        if (self.contact_validator)
            self.contact_validator.resetForm();
        $(".contact_error").remove();
        self.edit_contact_id = -1;
    }

    function save_contact(contact_id){
        var datum = {
            'name': $('#contact_name').val().trim(),
            'phone1': $('#contact_phone1').val().trim(),
            'email': $('#contact_email').val().trim(),
            'type': $('#contact_type').val().trim()
        };
        if(contact_id){
            datum['contact_id'] = contact_id
        }
        helpers.ajax_call({
            url: '/core/configuration/save_contact',
            data: datum,
            success_function: function(response){
                get_contacts();
            }
        });
    }

    function save_address(address_id) {
        var datum = {
            'type': $('#address_type').find(':selected').val(),
            'addressee': $('#address_addressee').val().trim(),
            'streetaddress': $('#address_streetaddress').val().trim(),
            'streetaddress2': $('#address_streetaddress2').val().trim(),
            'city': $('#address_city').val().trim(),
            'province': $('#address_province').val().trim(),
            'postcode': $('#address_postcode').val().trim(),
            'country': $('#address_country').find(':selected').val()
        };
        if(address_id){
            datum['address_id'] = address_id
        }
        helpers.ajax_call({
            url: '/core/configuration/save_address',
            data: datum,
            success_function: function(response){
                get_addresses();
            }
        });
    }

    function validate_address(){
        self.address_validator = $("#address_form").validate({
            onfocusout: function(element) {
                $(element).valid();
            },
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            }
        });
        return self.address_validator.form();
    }

    function clear_address_input() {
        $('#address_type:selected').removeAttr("selected");
        $('#address_addressee').val('');
        $('#address_streetaddress').val('');
        $('#address_streetaddress2').val('');
        $('#address_city').val('');
        $('#address_province').val('');
        $('#address_postcode').val('');
        $('#address_country').val('');
        if (self.address_validator)
            self.address_validator.resetForm();
        $(".address_error").remove();
        $(".address").removeClass('selected');
        self.edit_address_id = -1;
    }


    function load_sync_config(){
        $('#panes').html($("#general_config_sync_tmpl").tmpl());
        helpers.set_buttons('.general_config_sync_controls', [
            {text: gettext('Save'), image: 'save', disabled: true, _class: 'jq_enable_on_select', onClick: function(){
                set_sync_settings(collect_sync_preferences());
            }},
            {text: gettext('Reset'), image: 'sync',  disabled: true, _class: 'jq_enable_on_select', onClick: function(){
                get_sync_settings();
            }},
        ]);
        get_sync_settings();
    }

    function collect_sync_preferences(){
        var preferences = {};
        $(".general_config_sync_setting_display").each(function(){
            preferences[$(this).attr("config_name")] = parseInt($(this).find(".general_config_sync_slider").slider("option", "value"));
        });
        return preferences;
    }

    function get_sync_settings(){
        helpers.ajax_call({
            url: '/core/configuration/get_sync_settings',
            success_function: draw_sync_settings
        });
    }

    function draw_sync_settings(input){
        $(".general_config_sync_settings").empty();

        // Preset buttons
        $(".general_config_sync_settings").append($("#general_config_sync_presets_tmpl").tmpl({"selected": input.data.presets.selected, "options": input.data.presets.options}));

        var options = [];
        $.each(input.data.presets.options, function(key, value){
            options.push({
                value: value['id'],
                text: value['name']
            })
        })

        $('#sync_presets').multi({
            options: options,
            selected: input.data.presets.selected,
            click: function(val){
                set_sync_settings({}, val);
            }
        })

        // Config Sliders
        for( var index in input.data.configs ){
            var conf = input.data.configs[index];
            var slider_name = conf.name + "_slider";
            var slider_value_name = conf.name + "_slider_value";
            $('#general_config_sync_setting_tmpl').tmpl({
                "slider_name": slider_name,
                "slider_value_name": slider_value_name,
                "config": conf,
                "config_name": conf.name
            }).appendTo($(".general_config_sync_settings"));
            $("#"+slider_name).slider({
                value: conf.value,
                min: conf.min,
                max: conf.max,
                step: conf.inc,
                slide: function(e, ui){
                    $("#"+$(this).attr("value_field")).text(formatSeconds(ui.value));
                    _changes_made(true);
                }
            });
        }
        _changes_made(false);
    }

    function set_sync_settings(settings, preset_name){
        helpers.ajax_call({
            url: '/core/configuration/set_sync_settings',
            data:{
                "settings": settings,
                "preset": preset_name
            },
            success_function: function(){
                get_sync_settings();
                _changes_made(false);
            }
        });
    }
}
