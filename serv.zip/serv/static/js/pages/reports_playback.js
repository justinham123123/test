var report_playback_page = new ReportPlaybackPage();

function ReportPlaybackPage() {
    var self = this;

    self.open = function(){
        $document.trigger('page_load');
        $document.one('page_load', self.close);

        $("#report_p_tmpl").tmpl().appendTo($('#main_section').empty());
        $document.trigger('page_loaded');
        nav_select('report', "playback");

        self.filter_data = {};
        self.page_active = true;

        // Server Selectors   
        self.server_selector = self.get_server_selector('playback', init_table, function(device_uuid) {
            $('#smpte_action_screens .smpte_input').text(
               (device_uuid === 'All') ? gettext('All') : $device_store.devices[device_uuid].screen().identifier
            );
            // Toggle the 'screen' column
            self.datatable.fnSetColumnVis(6, device_uuid === 'All', false);
        });
        self.server_selector.init();
        $("#main_section").resize(function(){
            if(self.datatable) self.datatable.fnAdjustColumnSizing(false);
        });
        self.toggle_sidebar(self);
    };

    self.close = function() {
        self.datatable = undefined;
        self.page_active = false;
        self.last_device = (self.filter_data || {}).device_uuid;
        self.filter_data = self.filter_defaults;
        $("#main_section").off("resize");
    };
    

    /* Shared by reports_audit.js, returns correct instance to use in common functions below */
    function get_instance() {
        return (report_playback_page.page_active) ? report_playback_page : report_audit_page;
    }
    
    self.get_server_selector = function(supported_fn, tbl_init, post_draw, include_all_tab) {
        var inst = get_instance();
        function select_device(device_uuid){
            inst.filter_data.device_uuid = (device_uuid === 'All') ? undefined : device_uuid;
            if(!inst.datatable) {
                tbl_init();
            } else {
                inst.datatable.fnDraw();
            }
            if(typeof post_draw === 'function') {
                post_draw(device_uuid);
            }
        }
        return new DeviceSelector({
            append_to: $('#screen_selector'),
            on_click: select_device,
            include_all: true,
            initial_selected : inst.last_device || null,
            supported_function: supported_fn
        });
    };
    
    self.toggle_sidebar = function() {
        // Toggle for the filters sidebar
        var transition_duration = 750; //ms duration for toggle/slide effects
        $('#timeline_rightpane_toggle').click(function() {
            $(this).toggleClass('icon-arrow-right').toggleClass('icon-arrow-left')
                .toggleClass('filters_hidden', transition_duration);
            $('#reports_filters').toggle('slide', {direction: 'right'}, transition_duration, function() {
                get_instance().datatable.fnAdjustColumnSizing(false);
            });
            $('#reports_table_wrap').toggleClass('expanded', transition_duration);
            $('#screen_selector').toggleClass('expanded', transition_duration);
        });
    };
    
    self.server_data = function(sSource, aoData, fnCallback){
        var data = {};
        for (var i in aoData) {
            data[aoData[i].name] = aoData[i].value;
        }
        $.extend(data, get_instance().filter_data);
        var loader = new Loader({
            target: '#reports_table_wrap .dataTables_scroll'
        });
        loader.show();

        $.ajax({
            type: 'POST', 
            url: sSource, 
            data: $.toJSON(data),
            dataType: 'json',
            processData: false,
            contentType: 'application/json',
            success: function(input){
                loader.hide();
                fnCallback(input);
            }
        });
    };

    function get_datetime_html(timestamp) {
        var html = "<div class='when'>";
        if(timestamp) {
            var date = new Date(timestamp * 1000);
            html += "<div class='time'>" + date.toLocaleTimeString() + "</div>";
            html += "<div class='date'>" + date.toDateString() + "</div>";
        } else {
            html += "<div class='time'>" + gettext('Unknown') + "</div>";
        }
        return html += "</div>";
    }

    function gen_columns(){
        var cols = [];
        cols.push({
            "mDataProp": function(oData, type) {
                return '<div class="heighter"></div><div class="content_kind"><div class="content_kind_icon image ' + oData["content_kind"] + '" title="'+oData["content_kind"]+'"></div><div class="content_kind_text content_color_'+oData["content_kind"]+'">' + content_kind_reference[oData["content_kind"]] + '</div></div>';
            },
            "bSortable": false
        });
        cols.push({
            "mDataProp": function(oData, type) {
                return '<div class="content_title content_color_'+oData["content_kind"]+'"" title="'+oData['cpl_uuid']+'">' + oData['content_title'] + '</div>';
            },
            "bSortable": false
        });
        cols.push({
            "sClass": 'events_col',
            "mDataProp": function(oData, type) {
                var dom = "<div class='playlist_details'>"
                if(oData['titles'].length > 0){
                    var title = oData['titles'][0];
                    dom += '<div class="global_content_object global_playlist_object" title="'+ title +'">'+ title +'</div>'
                }
                if(oData['feature']){                    
                    dom += '<div class="global_content_object global_feature_object" title="'+ oData['feature'] +'">'+ oData['feature'] + '</div>'
                }
                dom += "</div>"
                return dom
            },
            "bSortable": false
        });
        cols.push({
            "sClass": 'start_col',
            "mDataProp": function(oData, type) {
                var date = moment.unix(oData['start_ts']);
                var html = "<div class='when'>";
                html += "<div class='time'>" + date.format('HH:mm:ss') + "</div>";
                html += "<div class='date'>" + date.format('ddd MMM DD YYYY') + "</div>";
                html += "</div>";
                return html;
            }
        });
        cols.push({
            "sClass": 'end_col',
            "mDataProp": function(oData, type) {
                var date = moment.unix(oData['end_ts']);
                var html = "<div class='when'>";
                html += "<div class='time'>" + date.format('HH:mm:ss') + "</div>";
                html += "<div class='date'>" + date.format('ddd MMM DD YYYY') + "</div>";
                html += "</div>";
                return html;
            }
        });
        cols.push({
            "mDataProp": function(oData, type) {
                return '<div class="duration">' + $.seconds_to_duration_string(oData['duration']) + "</div>";
            },
            "bVisible": false
        });
        cols.push({
            sClass: 'screen_col',
            mDataProp: function(oData, type) {
                return '<div class="device_name_small">'+ oData.screen + '</div>';
            },
            bVisible: self.filter_data.device_uuid,
            bSortable: false
        });
        cols.push({
            "sClass": 'sources_col',
            "mDataProp": function(oData, type) {
                return $('#playback_sources_tmpl').tmpl({'uuid': oData['playback_uuid'], 'live': oData['live_log'], 'smpte': oData['smpte_logs']}).html()
            },
            "bSortable": false,
            "bVisible": true
        });
        return cols;
    }

    function init_table(){
        var today = new Date();
        //add the datepicker
        $('.playback_date_picker').datepicker({
            showAnim: 'slideDown',
            dateFormat:"yy-mm-dd",
            maxDate: today,
            beforeShowDay: function(date){
                if(date.toString() == new Date(self.today).toString()){
                    return [true, 'datepicker_custom_day_select'];
                }
                else{
                    return [true, '']
                }
            },
            onSelect: function(event) {
                $(this).change();
            }
        });
        $('.playback_date_picker').change(function(){
            var input = $(this)
            input.datepicker('hide');
            var field = input.attr("data-field");
            filter(field, Date.parse(input.datepicker("getDate")) / 1000);
        });

        $('#playback_start').datepicker('setDate', -7)
        $('#playback_end').datepicker('setDate', today)
        $('.playback_date_picker').each(function(){
            var input = $(this)
            input.datepicker('hide');
            var field = input.attr("data-field");
            self.filter_data[field] = Date.parse(input.datepicker("getDate")) / 1000;
        });

        var columns = gen_columns();
        var column_toggler = new ColumnToggler({
            table: '#playback_table',
            columns: columns
        });
        
        self.datatable = $('#playback_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_playback",
            "aoColumns": columns,
            "bServerSide": true,
            "sScrollY": '100%',
            "bAutoWidth": false,
            "bDestroy": true,
            "aaSorting": [[ 3, "desc" ]],
            "sDom": 't<".dataTables_pages"ip>',
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            oLanguage: DATATABLES_LANG,
            "fnServerData": self.server_data,
            fnInitComplete: function(){
                column_toggler.init(self.datatable);
            },
            "fnRowCallback": function(row, oData){                
                var titles = oData['titles']
                if(titles.length <= 1) return
                titles.splice(0,1)
                $(row).find(".title_name .first_text").qtip({
                    content:{
                        text: $('#titles_list_tmpl').tmpl({'titles': titles})
                    },
                    position:{
                        viewport: $('#playback_table'),
                        at: 'top left',
                        my: 'bottom right'
                    },
                    style: {
                        classes: 'qtip-shadow qtip-rounded qtip-light'
                    }
                })
            },
            "fnDrawCallback": function() {
                $('#reports_table_wrap .dataTables_scrollBody').scrollTop(0);
                $('#playback_table .source.active .smpte_button').click(function(e){
                    var uuid = $(e.target).attr("date-uuid")
                    load_smpte_playouts(uuid)
                });
            }
        });
        self.datatable.fnSetFilteringDelay(800);

        $('#playback_search').searcher(function(search){
            filter("sSearch", search);
        });
        $('#playback_content_kind').change(function(){
            filter('content_kind', $(this).find(":selected").attr("data-value"));
        });
        $('.clear_button').click(function(){
            var dom = $($(this).attr("data-target"));
            dom.val("").trigger( $(this).attr("data-target_event") );
        });
        $('#download_logs').button().click(download);
        $('#download_smpte_logs').button().click(download_xml);
        
        init_smpte_actions();
    }
    
    function init_smpte_actions() {
        //Add the datepickers
        $('.smpte_date_picker').datepicker({
            showAnim: 'slideDown',
            dateFormat:"yy-mm-dd",
            maxDate: -1
        }).datepicker('setDate', -1);
        
        //Add manual collection button
        helpers.set_buttons('#smpte_manual_collection', [{
            id: 'smpte-trigger_collect',
            text: gettext('Run Collection Now'),
            onClick: smpte_trigger_collect
        }]);
        
        //Add action buttons
        helpers.set_buttons('#smpte_action_actions', [
            {
                id: 'smpte-recollect',
                text: gettext('Retry Collect'),
                onClick: smpte_recollect
            },
            {
                id: 'smpte-reparse',
                text: gettext('Retry Parse'),
                onClick: smpte_reparse
            },
            {
                id: 'smpte-remerge',
                text: gettext('Retry Merge'),
                onClick: smpte_remerge
            }
        ]);
    }
    
    function get_smpte_action_data() {
        var data = {
            start_timestamp: $('#smpte_action_start').datepicker('getDate').getTime() / 1000,
            end_timestamp: $('#smpte_action_end').datepicker('getDate').getTime() / 1000
        };
        var screen_title = $('#smpte_action_screens .smpte_input').text();
        if(screen_title !== 'All') {
            data.screen_identifiers = [screen_title];
        }
        return data;
    }
    
    function smpte_action(action) {
        var filters = get_smpte_action_data();
        dialog.open({
            title: gettext('SMPTE Response'),
            template: '#playback_smpte_actions_tmpl',
            data: {
                duration: 1 + (filters.end_timestamp - filters.start_timestamp) / 86400,
                action: action
            }
        });
        var response = $('#smpte_response');
        var spinner = new Spinner({dom: response});
        spinner.spin();
        helpers.ajax_call({
            url: '/core/logging/'+ action +'_smpte_logs',
            data: filters,
            timeout: 60000 * 20, //20 Mins
            success_function: function(result) {
                spinner.stop();
                response.html($('#playback_smpte_actions_'+ action +'_tmpl').tmpl({
                    response: result.data,
                    dateifier: function(d){return new Date(d*1000).toDateString()}
                }));
            },
            error_function: function() {
                spinner.stop();
                response.html(gettext('Unknown Error'));
            }
        });
    }
    
    function smpte_reparse() {
        smpte_action('reparse');
    }
    function smpte_recollect() {
        smpte_action('recollect');
    }
    function smpte_remerge() {
        smpte_action('remerge');
    }
    function smpte_trigger_collect() {
        smpte_action('trigger_collect');
    }

    function filter(field, value){
        self.filter_data[field] = value;
        self.datatable.fnDraw();
    }

    function load_smpte_playouts(playback_uuid){
        var buttons = [];
        buttons.push({
            'text': gettext('Close'), 
            'action': function() {
                dialog.close();
            }
        });

        dialog.open({
            title: gettext('SMPTE Playouts'), 
            template: '#playback_smpte_playout_tmpl',
            buttons: buttons,
            data: {
            },
        });

        helpers.ajax_call({
            url: '/core/paginated/get_parsed_playouts',
            data: {
                playback_uuid: playback_uuid
            },
            loader: {
                target: $('#playout_dialog_wrapper')
            },
            success_function: function(input){
                $('#playback_playout_list_tmpl').tmpl({info: input}).appendTo($('#playout_dialog_wrapper').empty())
                $('.log_tab').click(function(e){
                    $('.log_tab_content').hide();
                    $('.log_tab.selected').removeClass('selected')
                    $($(e.target).attr("data-target")).show();
                    $(e.target).addClass('selected')
                })
                $('.log_tab:first-child').click()
                if(input.length < 2){
                    $("#logs_tabs").hide();
                }
                $('#playout_dialog_wrapper .file_path').click(function(e){
                    download_smpte_log($(this).attr("data-path"));
                })
            }
        });
    }
  
    function download_smpte_log(path){
        var data = {
            'path': path
        }
        download_call("/tms/download_smpte_playback_log", data)
    }

    function download_xml(){
        download_call("/tms/download_smpte_playback_logs", self.filter_data);
    }

    function download(){
        download_call("/tms/download_playback_logs", self.filter_data);
    }

    function download_call(path, data){
        var cheat_form = '<form style="display: none" action="'+path+'" method="POST" id="form">';
        for(var param in data){
            if(data[param]){
                cheat_form += '<input name="'+param+'" value="'+data[param]+'" ></input>';
            }
        }
        cheat_form += '</form>';
        //in firefox, the form must be appended to the DOM before it is submitted
        $('#main_section').append(cheat_form);
        $('#form').submit();
        $('#form').remove();
    }
}
