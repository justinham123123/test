var playlist_page = new PlaylistPage();
function PlaylistPage() {
    var self = this;

    self.playlists = {};
    self.device_id;
    self.device_selector;
    self.selected_playlists = [];
    self.selected_templates = [];
    self.select_all_toggled = false;
    self.tmp_delete_store = undefined;
    self.playlist_dialog = undefined;
    self.syncing_playlists = false;
    self.playlist_table = null;

    //Templates
    self.main_tmpl = '#playlist_main_tmpl';
    self.reset_filter_button_tmpl = '#playlist_reset_filter_button_tmpl';
    self.cleanup_filter_tmpl = '#playlist_cleanup_filter_tmpl';

    //Methods
    self.open = function(device_id) {
        self.device_id = device_id;
        var doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load.playlist', self._close_page);

        nav_select('content', 'playlists');

        $('#main_section').html($(self.main_tmpl).tmpl());

        self.filter_text = '';
        if (history.state != null){
            self.filter_text = history.state['filter_text'];
        }

        self.device_selector = new DeviceSelector({
            'append_to': $('#playlist_screen_selector'),
            'on_click': select_device,
            "supported_function":"playlist",
            "initial_selected": device_id || g_last_selected_device.id
        });
        self.device_selector.init();

        var buttons = [];

        if (helpers.is_allowed('tms_schedule_action')){
            buttons = [
                {text:gettext('New'), image:'new', onClick: new_playlist},
                {text:gettext('Delete'), image:'delete', onClick: delete_playlists, _class:'disabled jq_enable_on_select'},
                {text:gettext('Transfer'), image:'transfer', onClick: transfer, _class:'disabled jq_enable_on_select'},
                {text:gettext('Download'), image:'download', onClick: download, _class:'disabled jq_enable_on_select'}
            ];
        }

        helpers.set_buttons('#playlist_index_action_buttons', buttons);

        self.select_all_toggled = false;
        self.selected_playlists = [];
        self.selected_templates = [];
        self.syncing_playlists = false;

        enable_disable_buttons();
        attach_event_listeners();

        $(document).trigger('page_loaded');

        $("#playlist_table_filter input").val(self.filter_text);
    };

    self._close_page = function() {
        self.playlist_table = null;
        $(window).off('.playlist');
        $('#main_section').off();
        $(document).off('.playlist');
        self.device_selector.destroy();
        self.playlists = {};
        self.selected_playlists = [];
        self.selected_templates = [];
    };

    function attach_event_listeners() {

        $('#playlist_toggle_select_all').click(select_all_click);

        $('#playlist_table').on(
            'change.content',
            '.jq_playlist_checkbox',
            playlist_checkbox_click
        );

        $('#playlist_table tbody').on('click', 'td.no_prop', function(event) {
            event.stopPropagation();
        });

        $('#playlist_table tbody').on('click', 'tr', function(event) {
            var playlist_uuid = $(this).find('input').attr('playlist_uuid');
            history.pushState({"filter_text": $("#playlist_table_filter input").val()}, null, '#playlist_page');
            history.pushState(null, null, '#playlist_edit_page#'+self.device_id+'#'+playlist_uuid);
            playlist_edit_page.open(self.device_id, playlist_uuid);
        });

        $("#main_section").on('resize.playlist', resize);

        $('#playlist_cleanup_filter_dropdown').on('change',_update_table);

        $('#main_section').on(
            'click.playlist',
            '#clear_filter_button',
            clear_filters
        );
    }

    function _update_table(){
        self.playlist_table.fnDraw();
    }

    function select_device(device_id) {
        /*
            internal function used by the server_selector
        */
        self.playlists = {};
        self.selected_playlists = [];
        self.device_id = device_id;
        if(!self.playlist_table){
            initialise_data_table();
        }
        else{
            self.playlist_table.fnDraw();
        }
    }

    function clear_filters(){
        self.playlist_table.fnFilterClear();
    }

    function resize() {
        /*
            the resize.
            there must be a better way of doing this. this is pretty much waht we do in tms1:
                use the sScrolly feature to add a copy of the table header, and set a height for the body
                then window resize listen to adjsut the dimensions of the scrollbody.

            tried out the datatables fixedheader plugin, but taht duplicates ids etc, making it pretty useless

            other alternative is to do some css layout monstrosity, got into it a little bit, but there are quite a few pitfalls in this
        */
        $('.dataTables_scrollBody').height($('#playlist_table_wrapper_wrapper').innerHeight()-$('.dataTables_scrollHead').outerHeight() - $('.dataTables_info').outerHeight());
        self.playlist_table.fnDraw();
    }

    function enable_disable_buttons(){
        var disable_transfer = true;
        var disable_delete = true;
        var disable_download = true;

        if (self.selected_templates.length > 0) {
            disable_delete = false;
        }
        else if (self.selected_playlists.length > 0) {
            disable_delete = disable_transfer = disable_download = false;
        }

        $('#button_1').button('option', 'disabled', disable_delete);
        $('#button_2').button('option', 'disabled', disable_transfer);
        $('#button_3').button('option', 'disabled', disable_download);
    }

    function clear_selected() {
        self.select_all_toggled = true;
        select_all_click();
    }

    function select_all_click(){
        if (!self.select_all_toggled){
            $('#playlist_table input[type="checkbox"]').prop('checked', true).each(playlist_checkbox_click);
            $('#playlist_toggle_select_all').addClass("selected");
        }
        else{
            self.selected_playlists = [];
            self.selected_templates = [];
            $('input', self.playlist_table.fnGetNodes()).prop('checked', false).each(playlist_checkbox_click);
            $('#playlist_toggle_select_all').removeClass("selected");
        }
        self.select_all_toggled = !self.select_all_toggled;
    }

    function playlist_checkbox_click(){
        var playlist_uuid = $(this).attr('playlist_uuid');
        if($(this).prop("checked")){
            if ($.inArray(playlist_uuid, self.selected_playlists) == -1){
                self.selected_playlists.push(playlist_uuid);
            }
            if (self.playlists[playlist_uuid].is_template) {
                if ($.inArray(playlist_uuid, self.selected_templates)){
                    self.selected_templates.push(playlist_uuid);
                }
            }
        }
        else{
            var index = self.selected_playlists.indexOf(playlist_uuid);
            if (index != -1) self.selected_playlists.splice(index, 1);
            if (self.playlists[playlist_uuid].is_template) {
                index = self.selected_templates.indexOf(playlist_uuid);
                if (index != -1) self.selected_templates.splice(index, 1);
            }
        }
        update_checkbox_count();
        enable_disable_buttons();
    }

    function update_checkbox_count(){
        var selected = self.selected_playlists.length;
        $('.jq_enable_on_select').toggleClass('disabled', (selected == 0));
        $('#playlist_toggle_select_all').html(selected);
    }

    function initialise_data_table() {
        var dt_cols = [];
        _config_datatables_functions();
        dt_cols.push({
            "mDataProp": function (oObj, type) {
                return '<input type="checkbox" class="jq_playlist_checkbox" playlist_uuid="'+oObj.uuid+'" />';
            },
            "bSortable": false,
            "bSearchable": false,
            "bUseRendered": false,
            "sClass": 'no_prop'
        });
        dt_cols.push({
            "bSearchable": false,
            "bSortable": false,
            "mDataProp": function (oObj, type) {
                var tmp = [];
                if(oObj.validation == undefined){
                    console.log(oObj);
                }
                if(oObj.is_template)
                    tmp.push({name: "icon-playlist-template", additional_class:'playlist_table', title: gettext("Playlist Template")});
                if(oObj.is_3d)
                    tmp.push({name: "icon-three-d", additional_class:'playlist_table', title: gettext("3D Playlist")});
                if(oObj.is_hfr)
                    tmp.push({name: "icon-high-framerate", additional_class:'playlist_table', title: gettext("High Frame Rate")});
                if(oObj.validation.kdm_issue)
                    tmp.push({name: "kdm_issue", additional_class:'playlist_table', title: gettext("Issue with KDM")});
                if(oObj.validation.content_issue)
                    tmp.push({name: "content_issue", additional_class:'playlist_table', id:'errors_for_'+oObj.uuid});
                if(oObj.validation.playlist_issue)
                    tmp.push({name: "playlist_issue", additional_class:'playlist_table', id:'errors_for_'+oObj.uuid});
                if(oObj.has_show_start)
                    tmp.push({name: "show_start", additional_class:'playlist_table', title: gettext("Contains Show Start")});
                if(oObj.has_intermission)
                    tmp.push({name: "intermission", additional_class:'playlist_table', title: gettext("Contains intermission")});
                return $('#image_list_tmpl').tmpl({image_items:tmp}).html();
            }
        });
        dt_cols.push({
            "mDataProp": function (oObj, type) {
                return '<div class="global_content_object global_playlist_object">' + oObj.title.escape() + '</div>';
            }
        });
        dt_cols.push({
            "bSearchable": false,
            "bSortable": false,
            "mDataProp": function (oObj, type) {
                var content_items = [];
                for (var i = oObj.features.length - 1; i >= 0; i--){
                    content_items.push({content_title: oObj.features[i], content_kind:"feature"});
                }
                return $('#content_list_tmpl').tmpl2({content_items: content_items}).html();
            }
        });
        dt_cols.push({
            "bSearchable": false,
            "mDataProp": function (oObj, type) {
                return $.seconds_to_duration_string(oObj.duration_in_seconds);
            }
        });
        index = 0;

        var column_toggler = new ColumnToggler({
            table: '#playlist_table',
            columns: dt_cols
        });

        self.playlist_table = $('#playlist_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_playlists",
            "aoColumns": dt_cols,
            "bServerSide": true,
            "sScrollY": "100%",
            "bAutoWidth": false,
            "bDestroy": true,
            "oSearch": {
                "sSearch": self.filter_text
            },
            "aaSorting": [[ 2, "asc" ]],
            "sDom": '<"#playlist_table_filtering" f>t<".dataTables_pages" ip>',
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            oLanguage: DATATABLES_LANG,
            "fnServerData": server_data,
            "fnInitComplete": function(){
                column_toggler.init(self.playlist_table);
            },
            "fnDrawCallback": function() {
                self.selected_templates = [];
                self.selected_playlists = [];
                self.select_all_toggled = false;
                $('#playlist_toggle_select_all').removeClass("selected");
                update_checkbox_count();
                $("#playlist_table .content_issue, #playlist_table .playlist_issue").each(function(){
                    var item = self.playlists[$(this).attr("id").replace("errors_for_", "")];
                    if(item != undefined){
                        var detailed_issues = item.validation.detailed_issues;
                        helpers.attach_playlist_validation_tip(this, detailed_issues);
                    }
                });
            }
        });

        $(self.cleanup_filter_tmpl).tmpl().appendTo($('#playlist_table_filter'));
        $(self.reset_filter_button_tmpl).tmpl().appendTo($('#playlist_table_filter'));

        self.playlist_table.fnSetFilteringDelay(800);
        $("#table_controls").append($("#playlist_table_filtering"));
        $('.dataTables_scrollBody').height(
            $('#playlist_table_wrapper_wrapper').innerHeight() -
            $('.dataTables_scrollHead').outerHeight() -
            $('.dataTables_pages').outerHeight()
        );
    }

    function server_data(sSource, aoData, fnCallback){
        if(!self.syncing_playlists){
            self.syncing_playlists = true;
            if(!self.device_id)
                return;
            var data = {};
            for (var i in aoData) {
                data[aoData[i].name] = aoData[i].value;
            }
            data['device_uuid'] = self.device_id;
            var loader = new Loader({target: '#playlist_table_wrapper .dataTables_scroll', caption: gettext("Loading")});
            loader.show();

            data.cleanup_filter = $("#playlist_cleanup_filter_dropdown").val();
            $.ajax({
                "dataType": 'json',
                "type": "POST",
                "url": sSource,
                "data": $.toJSON(data),
                "dataType": "json",
                "processData": false,
                "contentType": "application/json",
                "success": function(input){
                    for(var i = input.aaData.length - 1; i >=0; i--){
                        self.playlists[input.aaData[i].uuid] = input.aaData[i];
                    }
                    fnCallback(input);
                    loader.hide();
                    self.syncing_playlists = false;
                }
            });
        }
    }

    function _config_datatables_functions(){
        // clear filters and reload table
        $.fn.dataTableExt.oApi.fnFilterClear = function(oSettings)
        {
            /* Remove global filter */
            oSettings.oPreviousSearch.sSearch = "";

            // // reset filter dropdown
            var filter_cleanup_select = $('#playlist_cleanup_filter_dropdown');
            $(filter_cleanup_select).val(jQuery('options:first', filter_cleanup_select).val());
            $('#playlist_table_filter input').val(undefined);

            /* Remove the text of the global filter in the input boxes */
            if (typeof oSettings.aanFeatures.f != 'undefined'){
                $(oSettings.aanFeatures.f).find('input:first-child').val('');
            }
            /* Remove the search text for the column filters - NOTE - if you have input boxes for these
             * filters, these will need to be reset
             */
            for(var i=0, iLen=oSettings.aoPreSearchCols.length ; i<iLen ; i++){
                oSettings.aoPreSearchCols[i].sSearch = "";
            }
            /* Redraw */
            oSettings.oApi._fnReDraw( oSettings );
        };
    }

    function download() {
        var selected_content = self.selected_playlists;
        clear_selected();
        if(selected_content.length > 0){
            var cheat_form = '<form style="display: none" action="/tms/download_playlists" method="POST" id="form">';
            cheat_form += '<input name="device_uuid" value="'+self.device_id+'" ></input>';
            cheat_form += '<select name="playlist_uuids" multiple="multiple">';
            for (var playlist_id in selected_content){
                cheat_form += '<option value="'+selected_content[playlist_id]+'" selected></option>';
            }
            cheat_form += '</select></form>';
            //in firefox, the form must be appended to the DOM before it is submitted
            $('#main_section').append(cheat_form);
            $('#form').submit();
            $('#form').remove();
        }
        else{
            notification.info_msg(gettext("There are no items selected"));
        }
    }

    function new_playlist() {
        var buttons = [];
        var data;
        buttons.push({
            'text': gettext('Create'),
            'action': _new_playlist
        });
        dialog.open({
            'title': gettext('New'),
            'buttons': buttons,
            'template': '#playlist_new_playlist_tmpl',
            'data': data,
            'focus': true
        });
        $('#playlist_new_playlist_title').keypress(function(event){
            if( event.keyCode == 13){
                event.preventDefault();
                _new_playlist();
            }
        });
    }

    function _new_playlist(e){
        var form = $('#playlist_new_playlist_form').validate({
            errorPlacement: function(error, element) {
                $(element).attr({"title": error.text()});
            },
            highlight: function(element){
                $(element).addClass("error");
            },
            unhighlight: function(element){
                $(element).removeClass("error");
            }
        }).form();
        if( form ){
            check_title($('#playlist_new_playlist_title').val());
        }
    }

    function check_title(title){
        var exists = false;
        helpers.ajax_call({
            url: '/core/playlist/playlist',
            data:{request_data_items: ['title']},
            success_function:function(data){
                for( var device_uuid in data.data){
                    for(var playlist_uuid in data.data[device_uuid]){
                        if(title.toLowerCase() == data.data[device_uuid][playlist_uuid].title.toLowerCase()){
                            exists = true;
                            break;
                        }
                    }
                }
                var message = gettext("A playlist with this name already exists on at least one screen. Continue?");
                if(!exists || confirm(message)) {
                    create_playlist(title);
                }
            }
        });
    }

    function create_playlist(title){
        dialog.close();
        history.pushState(null, null, '#playlist_page#'+self.device_id);
        playlist_edit_page.open(self.device_id, null, title);
    }

    function delete_playlists() {
        var playlist_ids = self.selected_playlists;
        self.tmp_delete_store = null;
        if (playlist_ids.length > 0) {
            helpers.ajax_call({
                url: '/core/playlist/playlist',
                data: {
                    playlist_ids : playlist_ids,
                    request_data_items: ['title']
                },
                success_function:function(input){
                    var data = input.data;
                    var buttons = [];
                    var selected_playlists = [];
                    var selected_playlists_obj = {};
                    var playlist_ids = [];
                    var tmp = {};

                    //This really needs to change.
                    for (var device_id in data) {
                        for (var playlist_id in data[device_id]){
                            var title = data[device_id][playlist_id].title;
                            if(title && !tmp[playlist_id]){
                                tmp[playlist_id] = 'ignore';
                                playlist_ids.push(playlist_id);
                                selected_playlists.push({
                                    id: playlist_id,
                                    title: title
                                });
                                selected_playlists_obj[playlist_id] = title;
                            }
                        }
                    }

                    buttons.push({
                        'text': gettext('Delete'),
                        'action': function() {
                            clear_selected();
                            var selected_devices = self.playlist_dialog.dialog_selected_devices();
                            if(selected_devices.length === 0){
                                return false;
                            }
                            //Check that none of the playlists are currently scheduled
                            helpers.ajax_call({
                                url: '/core/scheduling/get_playlist_schedules',
                                notify: false,
                                loader: {
                                    target: '#dialog_contents',
                                    caption: gettext('Validating')
                                },
                                data:{
                                    device_uuids: selected_devices,
                                    playlist_uuids: playlist_ids
                                },
                                success_function: function(schedule_list){
                                    //This is where the actual deletion happens
                                    var do_delete = function(){
                                        // feedback dialog
                                        self.feedback_dialog = new AAMFeedbackDialog({
                                            title: 'Deleting Playlists',
                                            selected_device_ids : selected_devices,
                                            selected_content : selected_playlists,
                                            close_function : function() {
                                                self.playlist_table.fnDraw();
                                            }
                                        });
                                        self.feedback_dialog.open();

                                        helpers.ajax_call({
                                            notify: false,
                                            url: '/core/playlist/delete',
                                            data: {
                                                playlist_ids: playlist_ids,
                                                device_ids: selected_devices
                                            },
                                            complete_variables: {
                                                playlist_id: playlist_id
                                            },
                                            success_function: self.feedback_dialog._global_content_callback
                                        });
                                    };
                                    //If any schedules were found, require confirmation
                                    if(Object.keys(schedule_list.data).length > 0){
                                        dialog.open({
                                            data: {
                                                schedules_affected: schedule_list.data,
                                                playlists: selected_playlists_obj
                                            },
                                            title: gettext('Delete'),
                                            template: '#playlist_delete_content_confirmation_tmpl',
                                            buttons: [{
                                                text: gettext('Delete'),
                                                action: function(){
                                                    do_delete();
                                                }
                                                },{
                                                text: gettext('Cancel'),
                                                action: function(){
                                                    dialog.close();
                                                }
                                            }]
                                        });
                                    } else {
                                        do_delete();
                                    }
                                }
                            });
                        }
                    });

                    self.playlist_dialog = new AAMTransferDialog({
                        'title': gettext('Delete'),
                        'buttons': buttons,
                        hbtemplate: '#global_delete_dialog_tmpl',
                        'close':self._load_playlists,
                        'selected_content': selected_playlists,
                        'pre_selected_ids':[self.device_id],
                        height: 200
                    });
                    self.playlist_dialog.open(false);
                }
            });
        }
        else {
            notification.info_msg(gettext("There are no items selected"));
        }
    }

    function transfer() {
        var playlist_ids = self.selected_playlists;
        if (playlist_ids.length > 0) {
            helpers.ajax_call({
                url: '/core/playlist/playlist',
                data: {
                    playlist_ids : playlist_ids,
                    request_data_items: ['title']
                },
                success_function:function(input){
                    var buttons = [], selected_content = [], selected_playlist_ids = [];

                    //need to reorganize the return for this
                    data = input.data;
                    for (var device_id in data) {
                        for (var playlist_id in data[device_id]) {
                            if ($.inArray(playlist_id, selected_playlist_ids) === -1 && data[device_id][playlist_id].title) {
                                selected_playlist_ids.push(playlist_id);
                                selected_content.push({
                                    'title' : data[device_id][playlist_id].title,
                                    'id' : playlist_id
                                });
                            }
                        }
                    }

                    buttons.push({
                        'text': gettext('Transfer'),
                        'action': function() {
                            clear_selected();
                            var not_before = self.playlist_dialog.dialog_get_transfer_time();
                            if (!not_before)
                                return;
                            var sending_device_id = self.device_id;
                            var selected_devices = self.playlist_dialog.dialog_selected_devices();
                            if(selected_devices.length === 0){
                                return false;
                            }

                            self.feedback_dialog = new AAMFeedbackDialog({
                                'title':  gettext('Transferring'),
                                'selected_device_ids': selected_devices,
                                'selected_content': selected_content,
                            });
                            self.feedback_dialog.open();

                            helpers.ajax_call({
                                notify : false,
                                url:'/core/playlist/transfer',
                                data:{'not_before' : not_before,
                                    'sending_device_id':sending_device_id,
                                    'receiving_device_ids': selected_devices,
                                    'playlist_ids': selected_playlist_ids},
                                success_function: self.feedback_dialog._global_content_callback
                            });
                        }
                    });
                    var hidden_device_ids = [self.device_id];
                    for (var device in $device_store.devices){
                        if($.inArray($device_store.devices[device]['type'], ['usb', 'local', 'drive', 'watchfolder']) != -1){
                            hidden_device_ids.push($device_store.devices[device]['id']);
                        }
                    }
                    self.playlist_dialog = new AAMTransferDialog({
                        'title': gettext('Transfer'),
                        'buttons': buttons,
                        hbtemplate: '#glob_transfer_tmpl',
                        'selected_content': selected_content,
                        'hidden_device_ids': hidden_device_ids
                    });
                    self.playlist_dialog.open(true);
                }
            });
        }
        else {
            notification.info_msg(gettext("There are no items selected"));
        }
    }
}
