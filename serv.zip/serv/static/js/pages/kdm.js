var kdm_page = new KDMPage();
function KDMPage() {
    var self = this;

    //Templates
    self.main_tmpl = '#kdm_main_tmpl';

    var select_all_toggled = false;
    var select_all_disabled = false;

    var server_selector;
    var selected_device;
    var selected_device_category;

    //Methods
    self.open = function(device_id) {
        var doc;

        self.kdm_uuid = null;

        doc = $(document);
        doc.trigger('page_load');
        doc.on('page_load', _close_page);
        nav_select('content', 'kdms');

        $('#main_section').empty();

        $('#main_section').html($(self.main_tmpl).tmpl());

        // Server Selectors
        server_selector = new DeviceSelector({
            'append_to':$('#screen_selector'),
            'on_click':select_device,
            'included_device_types': ['lms','sms'],
            'include_all':false,
            'initial_selected' : device_id || g_last_selected_device.id
        });
        server_selector.init();

        var to;
        $(window).on('resize.kdm-table', function(){
            clearTimeout(to);
            to = setTimeout(function(){
                _resize();
            }, 200);
        });

        _initialise_data_table();

        $document.trigger('page_loaded');

        // buttons
        var buttons = [];
        if (helpers.is_allowed('tms_playback_action')) {
            buttons =[
                {text:gettext('Delete'),id:'btn_content_delete', image:'delete', onClick: delete_kdm, disabled:true, _class:'jq_enable_on_select red'},
                {text:gettext('Ingest'),id:'btn_content_transfer', image:'transfer', onClick: transfer_kdm, disabled:true, _class:'jq_enable_on_select green'},
                {text:gettext('Upload Kdm'),id:'btn_upload_kdm', image:'upload_kdm', onClick: upload_kdm},
                {text:gettext('Hide orphaned/expired'),id:'btn_hide_orphan', image:'orphan_kdm', onClick: hide_orphan_kdms, _class:"jq_btn_hide_orphan float_right", type: 'toggle'},
            ];
        }
        helpers.set_buttons('#kdm_table_controls', buttons);

        if($.cookie('read', 'hide_orphan_kdms') === 'true'){
            $('#btn_hide_orphan').attr("checked", "checked").button("refresh");
        }

        add_event_handlers();
    };

    function delete_kdm() {
        var kdm_info = _get_selected_kdms(true);
        var kdms_to_delete = $(kdm_info).map(function(){return this.id;}).get();
        helpers.ajax_call({
            url: '/core/content/delete_key_check',
            data:{
                'device_id': selected_device,
                'key_ids': kdms_to_delete
            },
            success_function: function(response){
                function do_delete(){

                    self.feedback_dialog = new AAMFeedbackDialog({
                        'title': gettext('Delete'),
                        'selected_device_ids' : [selected_device],
                        'selected_content' : kdm_info,
                        'close_function' : function(){
                            _update_table();
                        }
                    });

                    self.feedback_dialog.open();

                    helpers.ajax_call({
                        url: '/core/content/delete_key',
                        notify: false,
                        data: {
                            device_id: selected_device,
                            key_ids: kdms_to_delete
                        },
                        success_function: self.feedback_dialog._global_kdm_callback
                    });
                }
                var confirmation_buttons = [{
                    'text': gettext('Delete'),
                    'action': function(){
                        dialog.close();
                        do_delete();
                    }
                },{
                    'text': gettext('Cancel'),
                    'action': function(){
                        dialog.close();
                    }
                }];
                dialog.open({
                    data:{
                        affected_content: response.data,
                        affected_content_length: Object.keys(response.data).length,
                        kdm_count: kdms_to_delete.length
                    },
                    title: gettext('Delete'),
                    template: '#kdm_delete_kdm_confirmation_dialog',
                    buttons: confirmation_buttons
                });
            }
        });
    }

    function transfer_kdm() {
        var selected_kdms = _get_selected_kdms();
        var transferbuttons = [];
        transferbuttons.push({
            'text': gettext('Ingest'),
            'action': function(){
                var screen = $device_store.screens[$('#screen_dropdown').val()];
                var selected_device_to_transfer_to = null;

                for(var device_index in screen.devices){
                    var device = screen.devices[device_index];
                    if(device.category === 'sms'){
                        selected_device_to_transfer_to = device.id;
                        break;
                    }
                }
                if (selected_device_to_transfer_to){
                    for(var i=0;i<selected_kdms.length;i++){
                        //And this is not nice but I didn't want to create another bulk API call for this.
                        helpers.ajax_call({
                            url: '/core/content/reload_key_from_lms',
                            data: {
                                key_uuid: selected_kdms[i],
                                device_uuid: selected_device_to_transfer_to
                            }
                        });
                    }
                }
                dialog.close();
            }
        });
        transferbuttons.push({
            'text': gettext('Cancel'),
            'action': function(){
                dialog.close();
            }
        });

        dialog.open({
            'title': gettext('Transfer'),
            'template': '#kdm_kdm_reupload_form',
            'data': {selected_kdm_count: selected_kdms.length},
            'width': '200px',
            'buttons': transferbuttons
        });
    }

    function upload_kdm() {
        //We call here the upload kdm implementation from the content page
        content_page.upload_kdm();
    }

    function hide_orphan_kdms(){
        var hide_orphan = $('#btn_hide_orphan').attr("checked") === "checked";
        $.cookie('write', 'hide_orphan_kdms', hide_orphan);
        _update_table();
    }

    function _close_page() {
        $(document).off('page_load', _close_page);
    }

    function select_device(device_id){
        selected_device = device_id;
        self.kdm_uuid = null;
        $('#kdm_sidebar_body').empty();
        $('#little_helper').removeClass('hide');
        $('#kdm_static_kdm_title').empty();
        // We introduce a little timeout giving time for the browser to draw :)
        setTimeout(function(){
            if(!self.kdm_table){
                _initialise_data_table();
            }
            else{
                _update_table();
            }
        }, 100);
    }

    function _initialise_data_table() {
        _config_datatables_functions();
        self.kdm_table = _gen_table(_gen_columns());

        $('#kdm_table tbody').on('click.kdm', 'input.no_prop', function(event) {
            event.stopPropagation();
        });

        $('#kdm_table tbody').on('click.kdm', 'tr', function(event) {
            event.stopPropagation();

            var temp_kdm_uuid = self.kdm_uuid;
            self.kdm_uuid = $(this).find('input').attr('kdm_uuid');

            if (self.kdm_uuid) {
                $(self.kdm_table.fnGetNodes()).removeClass('kdm_table_row_selected');
                $(this).addClass('kdm_table_row_selected');
                //For some reason this event handler runs twice. I don't know why. Investigate later. In the meantime I prevent double execution of the ajax call.
                if (self.kdm_uuid !== temp_kdm_uuid){
                    _load_kdm_details(self.kdm_uuid);
                }
            }
        });

        $('#kdm_table_wrapper .dataTables_scrollBody').height(
            $('#kdm_table_wrapper_wrapper').innerHeight()-
            $('#kdm_table_wrapper .dataTables_scrollHead').outerHeight() -
            $('#kdm_table_controls').outerHeight() -
            $('#kdm_table_filter').outerHeight() -
            $('#kdm_table_wrapper .dataTables_pages').outerHeight()
        );
    }

    function _update_table() {
        self.kdm_table.fnDraw();
    }

    function _config_datatables_functions(){
        // clear filters and reload table
        $.fn.dataTableExt.oApi.fnFilterClear = function(oSettings)
        {
            /* Remove global filter */
            oSettings.oPreviousSearch.sSearch = "";

            /* Remove the text of the global filter in the input boxes */
            if (typeof oSettings.aanFeatures.f !== 'undefined'){
                $(oSettings.aanFeatures.f).find('input:first-child').val('');
            }
            /* Remove the search text for the column filters - NOTE - if you have input boxes for these
             * filters, these will need to be reset
             */
            for(var i=0, iLen=oSettings.aoPreSearchCols.length; i<iLen; i++){
                oSettings.aoPreSearchCols[i].sSearch = "";
            }
            /* Redraw */
            oSettings.oApi._fnReDraw( oSettings );
        };
    }

    function _gen_columns(){
        var dt_cols = [];

        dt_cols.push({
            "bVisible": false,
            "bSortable": false,
            "bSearchable": true,
            "mDataProp": "uuid"
        });
        dt_cols.push({
            "sClass": 'type-selection',
            "mDataProp": function(oData, type) {
                return '<input type="checkbox" class="no_prop jq_kdm_checkbox" kdm_uuid="'+oData.uuid+'" />';
            },
            "bSortable": false,
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            "sClass": 'c_status',
            "bVisible": true,
            "bSearchable": false,
            "bSortable": true,
            "bUseRendered": false,
            "mDataProp": function (oData, type) {
                var toReturn = '';
                if(oData.expires_in_24){
                    toReturn = '<div class="status_icon icon-key kdm_icon_expires_in_24"></div>';
                }else if(oData.expired){
                    toReturn = '<div class="status_icon icon-key kdm_icon_expired"></div>';
                }else if(oData.valid_in_future){
                    toReturn = '<div class="status_icon icon-key kdm_icon_valid_in_future"></div>';
                }else{
                    toReturn = '<div class="status_icon icon-key kdm_icon_ok"></div>';
                }
                if(selected_device_category === 'sms'){
                    if(oData.orphaned){
                        toReturn = '<div class="status_icon icon-key kdm_icon_nomatch" title="Associated CPL is not registered on this screen server!"></div>';
                    }
                }
                if(oData.status === 'error'){
                    toReturn += '<div class="status_icon image icon-warning " title="There are problems with this KDM"></div>';
                }
                return toReturn;
            }
        });
        dt_cols.push({
            "bVisible": false,
            "bSortable": true,
            "bSearchable": false,
            "mDataProp": "cpl_uuid"
        });
        dt_cols.push({
            "mDataProp": "cpl_title",
            "sClass": "cpl_title_column",
            "bSortable": true,
            "bSearchable": true,
            "bUseRendered": false
        });
        dt_cols.push({
            "sClass": 'c_version',
            "mDataProp": "version",
            "bSortable": true,
            "bSearchable": false
        });
        dt_cols.push({
            "sClass": 'screen-column',
            "mDataProp": function (oData, type) {
                return '<div class="screen_number screen_number_generic_small ">'+oData['screen']+'</div>';
            },
            "bSortable": true,
            "bUseRendered": false
        });
        dt_cols.push({
            "sClass": 'c_serial',
            "bSortable": true,
            "bVisible": true,
            "bSearchable": false,
            "mDataProp": "device_serial_number"
        });
        dt_cols.push({
            "sClass": 'validfrom-column datetime_column',
            "mDataProp": function(oData, type) {
                var date = moment.unix(oData['not_valid_before']);
                var html = "<div>";
                html += "<div class='date'>" + date.format('ddd MMM DD YYYY') + "</div>";
                html += "<div class='time'>" + date.format('HH:mm:ss') + "</div>";
                html += "</div>";
                return html;
            },
            "bSortable": true,
            "bSearchable": false
        });
        dt_cols.push({
            "sClass": 'validto-column datetime_column',
            "mDataProp": function(oData, type) {
                var date = moment.unix(oData['not_valid_after']);
                var html = "<div>";
                html += "<div class='date'>" + date.format('ddd MMM DD YYYY') + "</div>";
                html += "<div class='time'>" + date.format('HH:mm:ss') + "</div>";
                html += "</div>";
                return html;
            },
            "bSortable": true,
            "bSearchable": false
        });

        return dt_cols;
    }

    function _gen_table(dt_cols){
        var column_toggler = new ColumnToggler({
            table: '#kdm_table',
            columns: dt_cols
        });
        var ready = false;
        var table = $('#kdm_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_kdm",
            "aoColumns": dt_cols,
            "bServerSide": true,
            "sScrollY": '100%',
            "bAutoWidth": false,
            "bDestroy": true,
            "aaSorting": [[ 6, "asc" ],[ 4, "asc" ]],
            "sDom": 'f<"#kdm_table_controls">t<".dataTables_pages"ip>',
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            oLanguage: DATATABLES_LANG,
            "fnServerData": _server_data,
            "fnInitComplete": function(){
                column_toggler.init(table);
                ready = true;
            },
            "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ){
                if(aData.screen === '?'){
                    $(nRow).addClass('absent');
                }
            },
            "fnDrawCallback": function() {
                $('#kdm_toggle_select_all').removeClass('selected');
                select_all_toggled = false;
                if(self.kdm_table !== null){
                    update_checkbox_count();
                }

                var is_lms = $device_store.devices[selected_device].category === 'lms';
                $('#btn_upload_kdm').toggle(is_lms);
                $('#btn_content_transfer').toggle(is_lms);
                $('.jq_btn_hide_orphan').toggle(!is_lms);

                var override = {
                    6: is_lms,
                    7: (is_lms && $complex_status.doremi_features)
                };
                if(ready){
                    column_toggler.override(override);
                }
                //Now it's time to remove some checkboxes because of lovely Dolby.
                if(helpers.supported_uuid(selected_device, 'no_kdm_deletion')){
                    select_all_disabled = true;
                    $('.jq_kdm_checkbox').attr('disabled',true);
                }
                else{
                    select_all_disabled = false;
                    $('#kdm_toggle_select_all').show();
                }
                $('#kdm_table_wrapper .dataTables_scrollBody').scrollTop("0px");
                //select the first table row
                $('#kdm_table tbody tr:first-child').click();
            }
        });
        table.fnSetFilteringDelay(800);
        return table;
    }

    function add_event_handlers(){
        $('#main_section').on(
            'change.kdm',
            '.jq_kdm_checkbox',
            update_checkbox_count
        );

        $('#kdm_toggle_select_all').on('click.kdm',function(){
            if(select_all_disabled) return;
            select_all_toggled = !select_all_toggled;
            $('#kdm_toggle_select_all').toggleClass('selected', select_all_toggled);
            $('#kdm_table input').attr("checked", select_all_toggled);
            update_checkbox_count();
        });
    }

    function _server_data(sSource, aoData, fnCallback){
        var data = {};
        for (var i in aoData) {
            data[aoData[i].name] = aoData[i].value;
        }
        data['device_uuids'] = [selected_device];
        data['hide_orphan_kdms'] = ($('#btn_hide_orphan').attr("checked") === "checked");
        var loader = new Loader({target: '#kdm_table_wrapper .dataTables_scroll', caption: gettext("Loading")});
        loader.show();
        $.ajax({
            "dataType": 'json',
            "type": "POST",
            "url": sSource,
            "data": $.toJSON(data),
            "processData": false,
            "contentType": "application/json",
            "success": function(input){
                fnCallback(input);
                _resize();
                loader.hide();
            }
        });
    }

    function _get_selected_kdms(with_title){
        var include_title = (with_title != undefined)?true:false;
        var checked_content = [];
        $('#kdm_table input:checked').each(function(i, checkbox){
            var current_checkbox = $(checkbox);
            var uuid = current_checkbox.attr('kdm_uuid');
            if(!include_title){
                checked_content.push(uuid);
            }else{
                checked_content.push({
                    'id': uuid,
                    'title': current_checkbox.parent('td').siblings('.cpl_title_column').text()
                });
            }
        });
        return checked_content;
    }

    function update_checkbox_count(){
        var selected = $('input:checkbox:checked', self.kdm_table.fnGetNodes()).length;
        $('.jq_enable_on_select').button('option', 'disabled', selected === 0);
        $('#kdm_toggle_select_all').html(selected);
    }

    function _resize() {
        $('#kdm_table_wrapper .dataTables_scrollBody').height(
            $('#kdm_table_wrapper_wrapper').innerHeight()-
            $('#kdm_table_wrapper .dataTables_scrollHead').outerHeight() -
            $('#kdm_table_controls').outerHeight() -
            $('#kdm_table_filter').outerHeight() -
            $('#kdm_table_wrapper .dataTables_pages').outerHeight()
        );
        if(self.kdm_table){
            self.kdm_table.fnAdjustColumnSizing(false);
        }
    }

    function _load_kdm_details(kdm_uuid) {
        //Taka a copy of the device uuid here to prevent epileptic user from breaking the system if the backend takes things slow.
        var current_selected_device = selected_device;
        helpers.ajax_call({
            url: '/core/content/keys',
            data: {
                device_ids: [current_selected_device],
                key_ids: [kdm_uuid],
                hide_expired: false
            },
            success_function: function(response){
                try{
                    //Try to get the kdm info from the response. Hopefully backend wasn't lying and the kdm exists :)
                    var kdm_info = response.data[current_selected_device][kdm_uuid];
                    kdm_info.kdm_uuid = kdm_uuid;
                    $('#little_helper').addClass('hide');
                    $('#kdm_sidebar_body').html($('#kdm_kdm_info').tmpl({kdm: kdm_info, device_uuid: current_selected_device}));
                    $('#kdm_static_kdm_title').html(kdm_info.cpl_title);
                }catch(err){
                    //Try to prevent the browser from crashing the loading of stuff.
                }
            }
        });
    }
}
