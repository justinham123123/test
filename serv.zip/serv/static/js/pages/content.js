var content_page = new ContentPage();
function ContentPage() {
    var self = this;

    self.content = {};
    self.titles = {};
    self.content_table = null;
    self.scan_content_table = null;

    // availability
    self.month = new Date().getMonth();
    self.year = new Date().getFullYear();

    self.calendars_shown = false;
    self.current_cpl_availability = {};
    self.current_cpl_validity = {};

    // Templates
    self.main_tmpl = '#content_main_tmpl';
    self.info_pane_tmpl = '#content_info_pane_tmpl';
    self.static_title_tmpl = '#content_static_title_tmpl';
    self.device_status_tmpl = '#content_device_status_tmpl';
    self.availability_pane_tmpl = '#content_availability_pane_tmpl';
    self.watch_log_message_tmpl = '#watch_log_message_tmpl';
    self.watch_log_action_tmpl = '#watch_log_action_tmpl';
    self.titles_pane_tmpl = '#content_titles_pane_tmpl';
    self.packs_pane_tmpl = '#content_packs_pane_tmpl';
    self.disk_usage_tmpl = '#global_disk_usage_tmpl';
    self.raid_status_tmpl = '#content_raid_status_tmpl';
    self.raid_status_hover_tmpl = '#content_raid_hover_tmpl';
    self.type_filter_tmpl = '#content_type_filter_tmpl';
    self.cleanup_filter_tmpl = '#content_cleanup_filter_tmpl';
    self.reset_filter_button_tmpl = '#content_reset_filter_button_tmpl';
    self.extra_buttons_tmpl = '#content_extra_buttons_tmpl';
    self.kdm_tmpl = '#content_kdm_tmpl';
    self.no_kdm_tmpl = '#content_no_kdm_tmpl';
    self.kdm_stats_tab_tmpl = '#content_kdm_stats_tab_tmpl';
    self.dcp_stats_tab_tmpl = '#content_dcp_stats_tab_tmpl';
    self.pack_stats_tab_tmpl = '#content_pack_stats_tab_tmpl';

    self.content_dialog;
    self.scan_content_table;

    // Current Server
    self.server_title; //only used if we need to alert that the selected server has been removed

    // Current CPL UUID
    self.cpl_uuid = null;

    //Timeouts
    self.mouseovertimeout = null;

    var select_all_toggled = false;

    var server_selector;
    var selected_device = "All";

    var last_detailed_content_request;
    var auto_update_content_list = false;
    var auto_updating_content_list = false;
    var autoupdate_timeout = null;

    //Methods
    self.open = function(device_id) {
        // load server details
        self.playback_device_list = helpers.get_device_list("playback");
        self.content_device_list = helpers.get_device_list("content");

        // DOM stuff
        $document.trigger('page_load');
        $document.one('page_load.content', close_page);

        nav_select('content', 'content');
        $(self.main_tmpl).tmpl().appendTo($('#main_section').empty());
        // initialise templates
        _initialise_sidebar_tabs();

        // Server Selectors
        server_selector = new DeviceSelector({
            'append_to':$('#screen_selector'),
            'on_click':select_device,
            'include_all':true,
            'initial_selected' : device_id || g_last_selected_device.id
        });
        server_selector.init();

        // page loaded

        var to;
        $(window).on('resize.content-table', function(){
            clearTimeout(to);
            to = setTimeout(function(){
                _resize();
            }, 200);
        });

        $document.trigger('page_loaded');

        // buttons
        var buttons = [];
        if (helpers.is_allowed('tms_base_action') || helpers.is_allowed('tms_schedule_action')){
            buttons =[
                {text:gettext('Delete'),id:'btn_content_delete', image:'delete', onClick: delete_selected, disabled:true, _class:'jq_enable_on_select red'},
                {text:gettext('Transfer'),id:'btn_content_transfer', image:'icon-transfer', onClick: transfer_content_selected, disabled:true, _class:'jq_enable_on_select green'},
                {text:gettext('Ingest'),id:'btn_content_ingest', image:'icon-transfer', onClick: transfer_content_selected, _class:'jq_enable_on_select green'},
                {text:gettext('Ingest All'),id:'btn_content_ingest_all', image:'icon-transfer', onClick: ingest_content_all, _class:'jq_disable_on_empty green'},
                {text:gettext('Upload KDM'),id:'btn_upload_kdm', image:'upload_kdm', onClick: upload_kdm},
                {text:gettext('Delete with Deadlist'),id:'btn_deadlist', image:'deadlist', onClick: upload_deadlist},
                {text:gettext('Encrypted only/KDMs'),id:'btn_orphan_kdms', image:'orphan_kdm', id: 'show_kdms_toggle', type: 'toggle', onClick: show_kdms_toggle, _class:"jq_show_kdm_toggle float_right"},
                {text:gettext('Watchfolder Log'),id:'btn_watch_log', image:'sync', onClick: show_watch_log, _class:"float_right"},
            ];
        }
        helpers.set_buttons('#content_table_controls', buttons);

        if($.cookie('read', 'show_kdms') == "true"){
            $('#show_kdms_toggle').attr("checked", "checked").button("refresh");
            show_kdms_toggle();
        }

        // add buttons
        add_buttons();

        // add event listeners
        add_content_event_handlers();
    };

    function close_page(){
        if(self.content_table){
            self.content_table = null;
        }
        if(self.scan_content_table){
            self.scan_content_table = null;
        }
        $(".dataTables_scroll").add(window).off('resize.content-table');
        $(document).off('.content');
        $('#main_section').off('.content');
        $device_store.off('change');
        server_selector.destroy();
        auto_update_content_list = false;
        self.content = {};
    }

    function show_kdms_toggle(){
        var show = $('#show_kdms_toggle').attr("checked") == "checked";
        $.cookie('write', 'show_kdms', show);
        _update_table();
    }

    function get_selected_device(){
        var device = (selected_device === 'All') ? all_devices : $device_store.devices[selected_device];
        return device;
    }

    function add_buttons(){
        //some devices are read only!
        var selected_device_type = get_selected_device().type;
        var is_special = $._in(selected_device_type, ['local', 'ftp', 'watchfolder', 'cd']);
        var is_watchfolder = (selected_device_type === 'watchfolder');
        
        auto_update_content_list = is_watchfolder;
        $('#btn_content_transfer').toggle(!is_special);
        $('#btn_upload_kdm').toggle(!is_special);
        $('#btn_deadlist').toggle(!is_special);
        $('#btn_content_ingest').toggle(is_special);
        $('#btn_content_ingest_all').toggle(is_special);
        $("#btn_watch_log").toggle(is_watchfolder);
        $("#content_drive_error_report").toggle(is_special && !is_watchfolder);
        $('#btn_content_delete').toggle(!is_special || selected_device_type === 'local');

        clearTimeout(autoupdate_timeout);
        if(is_watchfolder && !auto_updating_content_list){
            autoupdate_timeout = setTimeout(auto_update_display, 30000);
        }
    }

    function select_device(device_id) {
        _clear_info_pane();
        self.cpl_uuid = null;
        selected_device = device_id;
        if(!self.content_table){
            _initialise_data_table();
        }
        else{
            _update_table();
        }
        update_checkbox_count();
        if(device_id === "All"){
            $('#content_disk_usage_raid_status_wrapper').hide();
        }
        else{
            // get server disk status
            helpers.ajax_call({
                url:'/core/monitoring/info',
                data:{
                    device_ids:[selected_device]
                },
                complete_variables : {
                    device_id: selected_device
                },
                success_function:_update_disk_usage_and_raid_status
            });
        }
        add_buttons();
        self.server_title = $(this).html();
    }

    function validate_content_action(selected_cpl_uuids){
        // return false if performing action on content that only exists on a drive/folder
        var valid_action = false;
        for(var uuid_index in selected_cpl_uuids){
            for(var device_uuid in self.content[selected_cpl_uuids[uuid_index]]["devices"]){
                if($device_store.devices[device_uuid] != undefined && ['ftp'].indexOf($device_store.devices[device_uuid].type) == -1){
                    valid_action = true;
                    return valid_action;
                }
            }
        }
        return valid_action;
    }

    function _get_selected_content_info(content_ids, content){
        var selected_content = [];
        var content_total_size = 0;
        var cpl_size;
        for(var content_id_index in content_ids){
            var devices_found = {};

            //Count required space - Taking the first device in content.devices at the moment
            cpl_size = null;
            for(var device_index in content[content_ids[content_id_index]].devices){
                var device = content[content_ids[content_id_index]].devices[device_index];
                if( ( device.validation_code != -1 && device.validation_code != 4) && !cpl_size && device.cpl_size != undefined){
                    cpl_size = device.cpl_size;
                }
                devices_found[device_index] = device;
            }
            if (cpl_size != undefined && !isNaN(cpl_size)){
                content_total_size += parseInt(cpl_size);
            }
            selected_content.push({
                'devices' : devices_found,
                'kind' : content[content_ids[content_id_index]]["content_kind"],
                'title' : content[content_ids[content_id_index]]["content_title"],
                'title_text': content[content_ids[content_id_index]]["content_title_text"],
                'id' : content_ids[content_id_index]
            });
        }
        var content_size_string;
        if( content_total_size == 0){
            content_size_string = gettext("Unknown");
        }
        else{
            var content_size_in_gb = content_total_size/1073741824;
            content_size_string = content_size_in_gb > 1 ? content_size_in_gb.toFixed(2) + 'GB' : (content_size_in_gb * 1024).toFixed(2) + 'MB';
        }
        return {"selected_content" : selected_content, "content_size_string" : content_size_string};
    }

    function load_cpl_location_details(content_ids){
        self.cpl_location_details;
        return helpers.ajax_call({
            url: '/core/content/content',
            data: {
                content_ids: content_ids
            },
            success_function: function(input){
                self.cpl_location_details = input.data;
            }
        });
    }

    function delete_selected(){
        var content_ids = _get_selected_cpls();
        var valid_action = validate_content_action(content_ids);
        if(content_ids.length > 0 && valid_action){
            delete_content(content_ids, self.content);
        }
        else if(valid_action == false){
            notification.info_msg(gettext("Cannot delete this CPL because it only exists in a FTP Folder."), gettext('Delete'));
        }
        else{
            notification.info_msg(gettext("There are no items selected"));
        }
    }

    function upload_deadlist(){
        var data;
        var buttons = [];
        var dead_uuids = [];
        var dead_content = [];
        var dom_feedback;

        buttons.push({
            text: gettext("Add files"),
            action: function(){
                $("#file_upload_button").click();
            }
        });

        // Open Dialog
        dialog.open({
            title: gettext('Delete with Deadlist'),
            hbtemplate: '#upload_file_dialog',
            buttons: buttons,
            data: {
                api_call: '/tms/upload_deadlist'
            }
        });

        // Attach fileuploader
        $('#fileuploader').fileupload({
            dataType: 'json',
            dropZone: $('#file_dropzone'),
            done: function(e, data){
                var result = data['result'];
                var dead_content = result['to_delete'];

                if(result.state.empty == false && result.state.parsable == true && dead_content.length > 0){
                    delete_content(Object.keys(dead_content), dead_content);
                }
                else{
                    $("#upload_file_feedback").tmpl2(result).appendTo($("#file_upload_response_wrapper"));
                }
            },
            dragover : function(e){
                $('#file_dropzone').addClass('accept');
                clearTimeout(self.mouseovertimeout);
                self.mouseovertimeout = setTimeout(function(){
                    $('#file_dropzone').removeClass('accept');
                    self.mouseovertimeout = null;
                }, 500);
            }
        });
    }

    function delete_content(content_ids, content){
        var selected_content_output = _get_selected_content_info(content_ids, content);
        var selected_content = selected_content_output.selected_content;
        var content_dict = {};
        var content_size_string = selected_content_output.content_size_string;

        //When the Delete button is clicked:
        var delete_action = function() {
            //Disable delete button to prevent multiple clicks
            $('#at_button_0').addClass('content_tranfer_btn_disabled ui-state-disabled');
            $.when(load_cpl_location_details(content_ids)).done(function(){

                var selected_devices = self.content_dialog.dialog_selected_devices();
                var deleted_from_complex = [];
                for (var i=0;i<selected_content.length;i++){
                    content_dict[selected_content[i]['id']] = selected_content[i];
                    var found_on_devices = [];
                    var cpl_device_info = self.cpl_location_details[selected_content[i]['id']]['devices'];
                    for (var device_id in cpl_device_info){
                        if (cpl_device_info[device_id]["error_messages"] == undefined){
                            found_on_devices.push(device_id);
                        }
                    }
                    if (helpers.intersect_array(selected_devices, found_on_devices).length == found_on_devices.length){
                        //This means that the content will be deleted from all possible places
                        deleted_from_complex.push(selected_content[i]);
                    }
                }

                var affected_schedules = {};
                helpers.ajax_call({
                    url: '/core/scheduling/get_content_schedules',
                    notify: false,
                    loader: {
                        target: '#dialog_contents',
                        caption: gettext('Validating')
                    },
                    data:{
                        device_uuids: selected_devices,
                        content_uuids: content_ids,
                        ids_only: false
                    },
                    success_function: function(schedule_list){
                        //This is where the actual deletion happens
                        var do_delete = function(){
                            if(selected_devices.length == 0){
                                return false;
                            }
                            self.feedback_dialog = new AAMFeedbackDialog({
                                title: gettext('Delete'),
                                selected_device_ids: selected_devices,
                                selected_content: selected_content,
                                close_function: function(){
                                    clear_selection();
                                    _clear_info_pane();
                                    _update_table();
                                }
                            });
                            self.feedback_dialog.open();

                            helpers.ajax_call({
                                url: '/core/content/delete',
                                notify: false,
                                data: {
                                    device_ids: selected_devices,
                                    content_ids: content_ids
                                },
                                success_function: self.feedback_dialog._global_content_callback
                            });
                        };
                        //If there are some issues that require user confirmation
                        var number_of_schedules_affected = Object.keys(schedule_list.data).length;
                        if(deleted_from_complex.length || Object.keys(schedule_list.data).length){
                            var confirmation_buttons = [{
                                text: gettext('Delete'),
                                action: function(){
                                    do_delete();
                                }
                            }];
                            dialog.open({
                                data: {
                                    deleted_from_complex: deleted_from_complex,
                                    schedules_affected: schedule_list.data,
                                    number_of_schedules_affected: number_of_schedules_affected,
                                    content_dict: content_dict
                                },
                                title: gettext('Delete'),
                                template: '#content_delete_content_confirmation_template',
                                buttons: confirmation_buttons
                            });
                        }
                        else{
                            do_delete();
                        }
                    }
                });

            });

        };

        //Here we construct the Delete dialog
        var buttons = [];
        buttons.push({
            'text': gettext('Delete'),
            'action': delete_action
        });
        buttons.push({
            'text': gettext('Cancel'),
            'action': function(){ dialog.close();}
        });
        var pre_selected_device_ids = get_selected_device()["id"] == "All" ? [] : [get_selected_device()["id"]];
        self.content_dialog = new AAMTransferDialog({
            'title': gettext('Delete'),
            hbtemplate: '#global_delete_dialog_tmpl',
            'selected_content':selected_content,
            'height':200,
            'buttons':buttons,
            'pre_selected_ids':pre_selected_device_ids,
            'content_total_size': content_size_string
        });

        self.content_dialog.open(false);
    }

    function update_checkbox_count(){
        var selected = $('input:checkbox:checked', self.content_table.fnGetNodes()).length;
        $('.jq_enable_on_select').button('option', 'disabled', selected == 0);
        $('#content_toggle_select_all').html(selected);
    }

    function add_content_event_handlers(){

        $('#content_toggle_select_all').on('click.content',function(){
            select_all_toggled = !select_all_toggled;
            $('#content_toggle_select_all').toggleClass('selected', select_all_toggled);
            $('#content_table input').attr("checked", select_all_toggled);
            update_checkbox_count();
        });

        $('#content_type_filter_dropdown').on('change',_update_table);
        $('#content_cleanup_filter_dropdown').on('change',_update_table);

        $('#main_section').on(
            'change.content',
            '.jq_content_checkbox',
            update_checkbox_count
        );

        $('#main_section').on(
            'click.content',
            '#content_availability_calendar_month_decrement',
            decrement_calendar_by_month
        );

        $('#main_section').on(
            'click.content',
            '#content_availability_calendar_month_increment',
            increment_calendar_by_month
        );

        $('#main_section').on(
            'click.content',
            '#content_availability_calendar_year_decrement',
            decrement_calendar_by_year
        );

        $('#main_section').on(
            'click.content',
            '#content_availability_calendar_year_increment',
            increment_calendar_by_year
        );

        $('#main_section').on(
            'click.content',
            '.jq_content_kdm_info_element',
            load_kdm_details
        );

        $('#main_section').on(
            'click.content',
            '#clear_filter_button',
            clear_filters_click
        );

        $device_store.on('change',  function(){
            //need to refresh the content device list because a new device has been added
            self.content_device_list = helpers.get_device_list("content");}
        );
    }

    function force_reupload_kdm() {
        var key_uuid = $(this).attr("key_uuid");
        var device_uuid = null;
        // Get the screen uuid from the selected screen
        var screen_uuid = $('#screen_dropdown').val();
        // Get the screen object from the uuid and then find its screen server
        var screen = $device_store.screens[screen_uuid];

        for(var device_index in screen.devices){
            var device = screen.devices[device_index];
            if(device.category === 'sms'){
                device_uuid = device.id;
                break;
            }
        }
        if(device_uuid) {
            _call_reload_key_from_lms(key_uuid, device_uuid);
        }
        else {
            notification.error_msg(gettext('The selected screen does not have a screen server configured'), 'Reload key from LMS');
        }
    }

    function reupload_kdm() {
        var key_uuid = $(this).attr("key_uuid");
        var device_uuid = $(this).attr("device_uuid");
        _call_reload_key_from_lms(key_uuid, device_uuid);
    }

    function _call_reload_key_from_lms(key_uuid, device_uuid) {
        helpers.ajax_call({
            url:'/core/content/reload_key_from_lms',
            data: {
                key_uuid: key_uuid,
                device_uuid: device_uuid
            }
        });
    }

    function upload_kdm() {
        var data, buttons;
        var ie9browser = helpers.is_ie9();

        buttons = [];
        buttons.push({
            'text': gettext('Done'),
            'action': function() {
                dialog.close();
            }
        });

        buttons.push({
            text: gettext("Add files"),
            action: function(){
                $("#file_upload_button").click();
            }
        });

        dialog.open({
            'title': gettext('Upload KDM'),
            hbtemplate: '#upload_file_dialog',
            'buttons': buttons,
            'data':{"api_call":'/tms/upload_kdm'},
        });
        $("#at_button_0").button('option', 'disabled', true);

        $('#fileuploader').fileupload({
            dataType: 'json',
            dropZone: $('#file_dropzone'),
            done: function (e, data) {
                $.each(data.result.messages, function (index, message) {
                    feedback_info = {};
                    if(message.type == 'error'){
                        feedback_info["status"] = 'error';
                    }
                    else{
                        feedback_info["status"] = 'success';
                    }
                    feedback_info["filename"] = message.filename;
                    feedback_info["upload_message"] = message.message;
                    $("#upload_file_feedback").tmpl2(feedback_info).appendTo($("#file_upload_response_wrapper"));
                });
                $("#at_button_0").button('option', 'disabled', false);
            },
            dragover : function(e){
                if (!$('#file_dropzone').hasClass('accept')){
                    $('#file_dropzone').addClass('accept');
                }
                if (self.mouseovertimeout){
                    clearTimeout(self.mouseovertimeout);
                }
                self.mouseovertimeout = setTimeout(function(){$('#file_dropzone').removeClass('accept'); self.mouseovertimeout = null;}, 500);
            }
        });

        if(ie9browser){
            $('#file_upload_button').show();
            $('#file_dropzone').hide();
            $("#at_button_1").hide();
        }
    }

    /*Expose this function to other pages*/
    self.upload_kdm = upload_kdm;

    function transfer_content_selected(e){
        var is_ingest = e.currentTarget.id.indexOf('ingest') > -1;
        var content_ids = _get_selected_cpls();
        var valid_action = validate_content_action(content_ids);
        if(content_ids.length <= 0){
            notification.info_msg(gettext("There are no items selected"), (is_ingest?gettext('Ingest'):gettext("Transfer")));
            return;
        }
        else if(!valid_action && !is_ingest){
            notification.info_msg(gettext("Cannot transfer this CPL because it only exists in a FTP Folder."), gettext('Transfer'));
            return;
        }
        transfer_content(content_ids, self.content, is_ingest);
    }

    function ingest_content_all(){
        var selected_device_id = get_selected_device()['id'];
        helpers.ajax_call({
            url:'/core/paginated/get_draglist_content',
            data:{
                device_uuid: selected_device_id
            },
            success_function: function(input){
                var content_ids = [];
                var content = {};
                for(var i in input['aaData']){
                    var c = input['aaData'][i];
                    content_ids.push(c['uuid']);
                    content[c['uuid']] = c;
                }
                transfer_content(content_ids, content, true);
            }
        });
    }

    function transfer_content(content_ids, content, is_ingest){
        var selected_content_output = _get_selected_content_info(content_ids, content);
        var selected_content = selected_content_output.selected_content;
        var content_size_string = selected_content_output.content_size_string;

        var buttons = [];
        var selected_device = get_selected_device();
        var hidden_device_ids = [selected_device.id];

        if(!is_ingest && selected_device.id !== 'All'){
            var content_devices = helpers.get_device_list('content');
            for(var i =0; i < content_devices.length; i++){
                var match = false;
                for(var k=0; k < selected_device.transfer_methods.length; k++){
                    for(var j=0; j < content_devices[i].transfer_methods.length; j++){
                        if (selected_device.transfer_methods[k] == content_devices[i].transfer_methods[j]){
                            match = true;
                            break;
                        }
                    }
                    if(match){
                        break;
                    }
                }
                if(!match){
                    hidden_device_ids.push(content_devices[i].id);
                }
            }
        }

        buttons.push({
            'text': is_ingest?gettext('Ingest'): gettext('Transfer'),
            'action': function() {
                // look for checked checkboxes and kick off appropriate transfers
                var not_before = self.content_dialog.dialog_get_transfer_time();
                if (not_before == undefined && !is_ingest)
                    return;
                var sending_device_id = get_selected_device()["id"] == "All" ? 'Auto' : get_selected_device()["id"];
                var selected_devices = self.content_dialog.dialog_selected_devices();

                if(selected_devices.length == 0){
                    return false;
                }

                self.feedback_dialog = new AAMFeedbackDialog({
                    'title' :  gettext('Transferring'),
                    'selected_device_ids' : selected_devices,
                    'selected_content' : selected_content,
                    'close_function' : clear_selection
                });
                self.feedback_dialog.open();

                helpers.ajax_call({
                    url: '/core/content/transfer',
                    notify: false,
                    data: {
                        not_before:not_before,
                        sending_device_id:sending_device_id,
                        receiving_device_ids:selected_devices,
                        content_ids: content_ids
                    },
                    success_function: function(input) {
                        self.feedback_dialog._global_content_callback(input);
                        $('.jq_global_dialog_feedback_wrapper').css("cursor", "pointer");
                        $('#global_dialog_feedback_table').on('click.content', '.jq_global_dialog_feedback_wrapper', function() {
                            dialog.close();
                            window.location.hash = '#transfer_page#';
                        });
                    }
                });
            }
        });
        buttons.push({
            'text': gettext('Cancel'),
            'action': function(){ dialog.close();}
        });
        self.content_dialog = new AAMTransferDialog({
            'title': is_ingest?gettext('Ingest CPL'):gettext('Transfer CPL'),
            buttons: buttons,
            hbtemplate: '#glob_transfer_tmpl',
            'selected_content':selected_content,
            'hidden_device_ids': hidden_device_ids,
            'content_total_size': content_size_string
        });

        self.content_dialog.open(true, !is_ingest);
    }

    function clear_selection(){
        $("input[type=checkbox]:checked").removeAttr("checked");
        update_checkbox_count();
    }

    function clear_filters_click(){
        self.content_table.fnFilterClear();
    }

    function toggle_controls_click(target) {
        var open = $('#content_sidebar_wrapper').hasClass("open");
        if (!open){
            show_controls();
            $('.collapse_expand').removeClass('rotate');
        }
        else if(open && ($(target).hasClass('selected') || $(target).hasClass('collapse_expand'))){
            hide_controls();
            $('.collapse_expand').addClass('rotate');
        }
    }

    function show_controls(){
        $('#content_sidebar_wrapper').css({'right':'0px'}).addClass('open');
        $('#content_table_wrapper_wrapper').css({'right':'332px'});
        $(this).addClass('sidebar-open');
        _resize();
    }

    function hide_controls(){
        $('#content_sidebar_wrapper').css({'right':'-300px'}).removeClass('open');
        $('#content_table_wrapper_wrapper').css({'right':'33px'});
        $(this).removeClass('sidebar-open');
        _resize();
    }

    function increment_calendar_by_month(){
        self.month += 1;
        _validate_month_index();
        update_calendar();
    }

    function increment_calendar_by_year(){
        self.year += 1;
        update_calendar();
    }

    function decrement_calendar_by_month(){
        self.month -= 1;
        _validate_month_index();
        update_calendar();
    }

    function decrement_calendar_by_year(){
        self.year -= 1;
        update_calendar();
    }

    function show_watch_log(){
        var watch_log_dialog = dialog.open({
            'title': gettext("Watchfolder Log"),
            'template': '#watch_log_dialog',
        });
        helpers.show_loader($("#watch_log_info"));
        update_watch_log();
    }

    function update_watch_log(){
        if( $device_store.devices[selected_device] != undefined && $device_store.devices[selected_device].type == "watchfolder" ){
            if( $("#watch_log_info").length > 0 ){
                helpers.ajax_call({
                    url:'/tms/get_watchfolder_logs',
                    data:{
                        device_uuid: selected_device,
                    },
                    notify: false,
                    success_function:_get_watchfolder_logs_callback
                });
            }
        }
    }

    function auto_update_display(){
        if(get_selected_device().type === 'watchfolder' &&  auto_update_content_list){
            auto_updating_content_list = true;
            if(_display_idle()){
                _update_table();
            }
            setTimeout(auto_update_display, 30000);
        }else{
            auto_updating_content_list = false;
        }
    }

    function content_error_report_clicked(){
        dialog.open({
            'title': gettext('CPL Scan Report'),
            'template': '#content_content_report_dialog',
            'data':{},
        });
        $('.d_tabs .d_tab').click(function(){
            var target = $(this).attr("data-target");
            $('.d_tabs .d_tab.selected').removeClass("selected");
            $(this).addClass("selected");
            $('.tab_contents').hide();
            $('#'+target).show();
        });
        $('.d_tabs .d_tab:first-child').click();

        var ajaxcall = helpers.ajax_call({
            url: '/core/content/get_sync_report',
            data: {device_id: get_selected_device()["id"]},
            success_function: function(input){
                $('#kdm_report_tab').html($(self.kdm_stats_tab_tmpl).tmpl(input.data.stats.kdms));
                $('#dcp_report_tab').html($(self.dcp_stats_tab_tmpl).tmpl(input.data.stats.dcps));
                $('#pack_report_tab').html($(self.pack_stats_tab_tmpl).tmpl(input.data.stats.packs));
            }
        });
    }

    function _display_idle(){
        // has a CPL been selected
        if( _get_selected_cpls().length > 0 ){
            return false;
        // has the user scrolled
        }else if($(".dataTables_scrollBody").scrollTop() > 0){
            return false;
        // if the user has paginated
        }else if(Math.ceil(self.content_table.dataTable().fnSettings()._iDisplayStart / self.content_table.dataTable().fnSettings()._iDisplayLength) > 0){
            return false;
        // is user viewing CPL details
        }else if(self.cpl_uuid != undefined){
            return false;
        }
        return true;
    }

    function _get_watchfolder_logs_callback(input){
        $("#watch_log_info").empty();
        $("#watch_log_actions").empty();
        helpers.hide_loader();
        for(var i in input.data.watch_log){
            $("#watch_log_info").append($(self.watch_log_message_tmpl).tmpl(input.data.watch_log[i]));
        }
        if(input.data.action_log.length > 0){
            for(var i in input.data.action_log){
                $("#watch_log_actions").append($(self.watch_log_action_tmpl).tmpl(input.data.action_log[i]));
            }
        }
        else{
            $("#watch_log_actions").append(gettext("No Recent Actions"));
        }
        setTimeout(update_watch_log, 10000);
    }

    function update_calendar(){
        $('#content_availability_pane_framework_tmpl').tmpl().appendTo($('#content_availability_pane').empty());
        // if a month's first day isn't sunday then we pad the calendar with empty day divs...
        var weekday_offset = [];
        for( var i = 0; i < new Date(self.year, self.month, 1).getDay(); i++){
            weekday_offset.push("");
        }

        // append template
        var data = {"month":self.month,"year":self.year,"day_limit":new Date(self.year, self.month+1, 0).getDate(),"weekday_offset":weekday_offset,"servers":self.content_device_list};

        $(self.availability_pane_tmpl).tmpl(data).appendTo($('#content_availability_calendar_body').empty());

        // update static calendar controls
        $("#content_availability_calendar_current_month").text(full_months[self.month]);
        $("#content_availability_calendar_current_year").text(self.year);

        // check availability for newly displayed date if a cpl has been clicked
        if( self.cpl_uuid != null){
            _check_availability();
            _update_kdms();
        }
    }

    function _validate_month_index(){
        if (self.month == -1){
            self.month = 11;
            self.year -= 1;
        }else if (self.month == 12){
            self.month = 0;
            self.year += 1;
        }
    }

    function _get_selected_cpls(){
        var checked_content = [];
        $('#content_table input:checked').each(function(i, checkbox){
            var uuid = $(checkbox).attr('cpl_uuid');
            checked_content.push(uuid);
        });
        return checked_content;
    }

    function _get_selected_cpl_table_row(cpl_uuid){
        return $('#content_table').find("input[type=checkbox][cpl_uuid=" + cpl_uuid + "]").parent();
    }

    function _resize() {

        $('#content_table_wrapper .dataTables_scrollBody').height(
            $('#content_table_wrapper_wrapper').innerHeight()-
            $('#content_table_wrapper .dataTables_scrollHead').outerHeight() -
            $('#content_table_controls').outerHeight() -
            $('#content_table_filter').outerHeight() -
            $('#content_table_wrapper .dataTables_pages').outerHeight()
        );

        if(self.content_table){
            self.content_table.fnAdjustColumnSizing(false);
        }
    }

    function _initialise_sidebar_tabs(){
        // Assign click handler on tabs

        $('.toggle_content_info, .collapse_expand').on('click', function(){
            toggle_controls_click(this);
        });

        //#content_sidebar_header > .collapse_expand'
        $('#content_sidebar_header > ul > li').on("click" , function(e){
            var tab = $(e.target).closest('.toggle_content_info').attr("data-tab");
            select_tab(tab, self.cpl_uuid, get_selected_device()["id"]);

            // otherwise select the tab
            $($(this).attr('target')).show().siblings().hide();
            $('#content_static_cpl_title').show();
            $(this).addClass('selected').siblings().removeClass('selected');
        });

        //Don't show sidebar expanded if on a small screen; it borks the datatable
        if($(window).width() < 1130){
            toggle_controls_click($('.collapse_expand'));
        }
    }

    function reload_tab(){
        var tab = $('.toggle_content_info.selected').attr("data-tab");
        if(!tab){
            if($('#content_sidebar_wrapper').hasClass("open")) {
                $('#content_info_pane_tab').click();
                return;
            } else {
                return;
            }
        }
        // If the currently select tab is availability and the content we are updating to is not encrypted, reselect info tab
        if(tab == "availability" && !self.content[self.cpl_uuid]['encrypted']){
            $('#content_info_pane_tab').click();
            return;
        }
        select_tab(tab, self.cpl_uuid, get_selected_device()["id"]);
    }

    function select_tab(tab, cpl_uuid, device_uuid){
        if(tab == "info"){
            _load_cpl_details(cpl_uuid, device_uuid);
        }
        else if(tab =="availability"){
            get_availability_info(cpl_uuid, "#content_availability_pane");
        }
        else if(tab == "packs"){
            load_packs_pane(cpl_uuid);
        }
        else if(tab == "titles"){
            load_titles_pane(cpl_uuid);
        }
    }

    function get_availability_info(cpl_uuid, target){
        helpers.ajax_call({
            url:'/core/content/keys',
            loader: {
                target: target
            },
            data:{
                content_ids: [cpl_uuid]
            },
            success_function: _update_availability_info
        });
    }

    function load_packs_pane(cpl_uuid){
        $('#content_packs_pane').empty();
        helpers.ajax_call({
            url:'/core/pack/find_pack',
            loader: {
                target: "#content_packs_pane"
            },
            success_function: function(input){
                $(self.packs_pane_tmpl).tmpl({
                    packs: input.data
                }).appendTo('#content_packs_pane');
            },
            data: {
                cpl_uuid: cpl_uuid
            }
        });

    }

    function load_titles_pane(cpl_uuid){
        $('#content_titles_pane').empty();
        helpers.ajax_call({
            url:'/core/title/get_title_with_cpl',
            loader: {
                target: "#content_titles_pane"
            },
            success_function: function(input){
                $(self.titles_pane_tmpl).tmpl({
                    titles: input.data
                }).appendTo('#content_titles_pane');
            },
            data:{
                cpl_uuid: cpl_uuid
            }
        });
    }

    function _initialise_data_table() {
        var sorting_col, i;

        _config_datatables_functions();
        var columns = _gen_columns();

        self.content_table = _gen_table(columns);

        // content type filter
        $(self.type_filter_tmpl).tmpl().appendTo($('#content_table_filter'));
        $(self.cleanup_filter_tmpl).tmpl().appendTo($('#content_table_filter'));

        // clear filter button
        $(self.reset_filter_button_tmpl).tmpl().appendTo($('#content_table_filter'));

        // extra buttons in the filter area
        $(self.extra_buttons_tmpl).tmpl().appendTo($('#content_table_filter'));
        $('#content_drive_error_report').click(content_error_report_clicked);

        $('#content_table tbody').on('click.content', 'input.no_prop', function(event) {
            event.stopPropagation();
        });

        $('#content_table tbody').on('click.content', 'tr', function(event){
            select_row($(this));
        });

        $('#content_table_wrapper .dataTables_scrollBody').height(
            $('#content_table_wrapper_wrapper').innerHeight()-
            $('#content_table_wrapper .dataTables_scrollHead').outerHeight() -
            $('#content_table_controls').outerHeight() -
            $('#content_table_filter').outerHeight() -
            $('#content_table_wrapper .dataTables_pages').outerHeight()
        );
    }

    function select_row(row){
        self.cpl_uuid = row.find('input').attr('cpl_uuid');
        if (self.cpl_uuid != undefined){
            $(self.content_table.fnGetNodes()).removeClass('content_table_row_selected');
            row.addClass('content_table_row_selected');
            $('#little_helper').addClass('hide');

            // Static CPL Title
            $(self.static_title_tmpl).tmpl({
                title: self.content[self.cpl_uuid]['content_title']
            }).appendTo($('#content_static_cpl_title').empty());

            $('#content_availability_pane_tab').toggle(self.content[self.cpl_uuid]['encrypted']);
            reload_tab();
        }

    }

    function get_col_override(){
        var col_vis = {};
        if(selected_device == "All"){
            col_vis[9] = false;
            col_vis[10] = false;
            col_vis[11] = false;
        }
        else{
            if($device_store.devices[selected_device]['type'] == 'aamlms'){
                col_vis[9] = true;
                col_vis[10] = true;
            }
            else{
                col_vis[9] = false;
                col_vis[10] = false;
            }
            if(['drive','ftp','watchfolder','local'].indexOf($device_store.devices[selected_device]['type']) != -1){
                col_vis[11] = true;
            }
            else{
                col_vis[11] = false;
            }
        }
        return col_vis;
    }

    function _gen_columns(){
        var dt_cols = [];

        dt_cols.push({
            "bVisible": false,
            "bSortable": false,
            "mDataProp": "uuid"
        });
        dt_cols.push({
            "sClass": 'type-selection',
            "mDataProp": function(oData, type) {
                var on_server = false;
                var on_external = false;

                for(var device_uuid in oData.devices){
                    if($._in($device_store.devices[device_uuid].type, ['ftp'])){
                        on_external = true;
                    }
                    if($._in($device_store.devices[device_uuid].category, ['sms', 'lms'])){
                        on_server = true;
                    }
                }

                if(oData.validation_code  !== -1 && oData.validation_code !== 4){
                    if(selected_device === 'All' && on_server && on_external){
                        return '<input type="hidden" cpl_uuid="'+oData.uuid+'" />';
                    }
                    else{
                        return '<input type="checkbox" class="no_prop jq_content_checkbox" cpl_uuid="'+oData.uuid+'" />';
                    }
                }
                else{
                    return '<input type="hidden" cpl_uuid="'+oData.uuid+'" />';
                }
            },
            "bSortable": false,
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            "bVisible": true,
            "bSearchable": false,
            "bSortable": true,
            "bUseRendered": false,
            "sClass": "c_status",
            "mDataProp": function (oData, type) {
                if (type == 'display') {
                    var ret =  helpers.content_status_info(oData.validation_code,selected_device);
                    return $('#image_list_tmpl').tmpl({image_items:[{name: ret.icon, title: ret.info}]}).html();
                }
                else {
                    return oData.validation_code;
                }
            }
        });
        dt_cols.push({
            "bVisible": true,
            "bSortable": true,
            "bSearchable": false,
            "sClass": "c_kdm",
            "mDataProp": function(oData, type) {
                if (oData.encrypted) {
                    if(get_selected_device().category !== 'sms'){
                        return $('#image_list_tmpl').tmpl({image_items:[{name: "encrypted jq_encrypted", additional_class:'content_table', id: "availability_cpl_"+oData.uuid}]}).html();
                    }
                    else{
                        var encrypted_class;
                        if(selected_device != "All"){
                            var device = oData.devices[selected_device];
                            var validation_code = device.validation_code;
                            encrypted_class = helpers.get_kdm_icon_class(device.valid_now, device.valid_in_future,
                                device.expires_in_24);
                            encrypted_class += ' jq_encrypted ';
                        }
                        else
                            encrypted_class = 'jq_encrypted encrypted';
                        return $('#image_list_tmpl').tmpl({image_items:[{name: encrypted_class, additional_class:'content_table', id: "availability_cpl_"+oData.uuid}]}).html();
                    }
                }
                else return '&nbsp;';
            }
        });
        dt_cols.push({
            "sClass": "c_encoding",
            "bSortable": false,
            "bVisible": CONFIG.core.detect_content_video_encoding == true,
            "mDataProp": function(oData, type) {
                return oData.video_encoding;
            }
        });
        dt_cols.push({
            "sClass": "c_playback",
            "mDataProp": function (oData, type) {
                if (type == 'display') {
                    if (oData.playback_mode == "3D") {
                        return $('#image_list_tmpl').tmpl({image_items:[{name: 'icon-three-d', additional_class:'content_table', title: '3D'}]}).html();
                    } else {
                        return $('#image_list_tmpl').tmpl({image_items:[{name: 'icon-two-d', additional_class:'content_table', title: '2D'}]}).html();
                    }
                } else {
                    return oData.playback_mode;
                }
            },
            "bSortable": false,
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            "sClass": "c_subs",
            "mDataProp": function (oData, type) {
                var subtitled;
                if (oData.subtitled) {
                    if (oData.subtitle_language) {
                        subtitled = oData.subtitle_language;
                    } else {
                        subtitled = 'XSUB';
                    }
                } else {
                    subtitled = 'XX';
                }
                if (type == 'display') {
                    return $('#flag_tmpl_wrapped').tmpl({'flag_name':subtitled}).html();
                } else {
                    return subtitled;
                }
            },
            "bSortable": true,
            "bSearchable": false
        });
        dt_cols.push({
            "sClass": 'type-column',
            "mDataProp": function (oData, type) {
                if (type == 'display') {
                    // apply content type name as css class to display icon in row
                    return '<div class="content_kind_icon image ' + oData.content_kind + '"></div><div class="content_kind_text content_color_'+oData.content_kind+'">' + content_kind_reference[oData.content_kind] + '</div>';
                } else {
                    return oData.content_kind;
                }
            },
            "bUseRendered": false
        });
        dt_cols.push({
            "sClass": 'title-column',
            "mDataProp": function(oData, type) {
                if (type == 'display') {
                    return '<span class=content_color_'+oData.content_kind+'>'+ oData.content_title_text +'</span>';
                } else {
                    return oData.content_title_text;
                }
            }
        });
        dt_cols.push({
            "sClass": 'ingest-date-column',
            "mDataProp": function(oData, type) {
                if (type == 'display' && oData.ingest_date) {
                    return '<span>'+ oData.ingest_date.substr(2) +'</span>';
                }
                else {
                    return '';
                }
            },
            "bSortable": true,
            "bSearchable": false
        });
        dt_cols.push({
            "sClass": 'ingest-source-column',
            "mDataProp": function(oData, type) {
                var source_type = oData.ingest_source_type ? oData.ingest_source_type : '&nbsp;';
                if (type == 'display') {
                    var source_display;
                    if(pretty_device_types[source_type]){
                        source_display = pretty_device_types[source_type];
                    }
                    if(['doremi', 'dolby', 'gdc', 'christie', 'qube', 'sony', 'aam', 'barco'].indexOf(source_type) != -1){
                        source_type = "sms";
                        source_display = "Screen Server";
                    }
                    else if(['usb', 'drive', 'cd'].indexOf(source_type) != -1){
                        source_type = "physical_media";
                        source_display = "Physical Media";
                    }
                    else if(source_type == "network"){
                        source_type = "local";
                        source_display = "Local Folder";
                    }
                    else if(source_type == "pack"){
                        source_type = "pack";
                        source_display = "Pack";
                    }
                    return '<div title="'+source_display+'" class = "image '+ source_type+'"></div>';
                } else {
                    return source_type;
                }
            },
            "bSortable": true,
            "bSearchable": false
        });
        dt_cols.push({
            "sClass": 'on-lms-column',
            "mDataProp": function(oData, type) {
                if (oData.on_lms != undefined) {
                    if(oData.on_lms == true){
                        return '<div class="image on_lms" title="' + gettext("CPL on LMS") + '"></div>';
                    }else{
                        return '<div class="image not_on_lms" title="' + gettext("CPL not on LMS") + '"></div>';
                    }
                }else{
                    return '<span>&nbsp;</span>' ;
                }
            },
            "bSortable": true,
            "bSearchable": false,
        });
        dt_cols.push({
            "sClass": 'last-playback-date-column',
            "mDataProp": function(oData, type) {
                var last_playback = oData.last_playback ? oData.last_playback : '&nbsp;';
                if (type == 'display') {
                    return '<span>'+ last_playback +'</span>';
                }
                else {
                    return last_playback;
                }
            },
            bVisible: false,
            "bSortable": true,
            "bSearchable": false
        });
        dt_cols.push({
            "sClass": "c_duration",
            "mDataProp": function(oData, type) {
                if (type == 'display') {
                    return '<span>'+ $.seconds_to_duration_string(oData.duration_in_seconds, true) +'</span>';
                } else {
                    return oData.duration_in_seconds;
                }
            },
            "bUseRendered": false
        });
        return dt_cols;
    }

    function _gen_table(dt_cols){
        var column_toggler = new ColumnToggler({
            table: '#content_table',
            columns: dt_cols
        });

        var vis_data = column_toggler.get();

        var ready = false;
        var table = $('#content_table').dataTable({
            "sAjaxSource": "/core/paginated/get_datatables_content",
            "aoColumns": dt_cols,
            "bServerSide": true,
            "sScrollY": '100%',
            "bAutoWidth": false,
            "bDestroy": true,
            "aaSorting": [[ 7, "asc" ],[ 8, "asc" ]],
            "sDom": 'f<"#content_table_controls">t<".dataTables_pages"ip>',
            "bPaginate": true,
            "sPaginationType": "full_numbers",
            "bLengthChange": false,
            "iDisplayLength": 100,
            oLanguage: DATATABLES_LANG,
            "fnServerData": _server_data,
            "fnInitComplete": function(){
                column_toggler.init(table);
                column_toggler.override(get_col_override());
                self.last_playback = vis_data[12];
                ready = true;
            },
            "fnRowCallback": function(row){
                if($(row).find(".missing").length){
                    $(row).addClass('orphan_kdm');
                }
            },
            "fnDrawCallback": function() {
                if(ready){
                    column_toggler.override(get_col_override());
                    self.last_playback = vis_data[12];
                }
                $(".jq_encrypted").each(function(){
                    helpers.attach_availability_tip({
                        dom: $(this),
                        cpl_uuid: $(this).attr("id").replace("availability_cpl_", ""),
                        viewport: $("#content_table_wrapper")
                    });
                });
                $('#content_toggle_select_all').removeClass('selected');
                select_all_toggled = false;
                if (self.content_table !== null){
                    update_checkbox_count();
                }
                $('#content_table_wrapper .dataTables_scrollBody').scrollTop("0px");
                //select the first table row
                if(table.fnSettings().fnRecordsTotal() > 0){
                    $('#content_table tbody tr:first-child').click();
                    $("#jq_content_tabs").show();
                }
                else{
                    $("#jq_content_tabs").hide();
                }
            }
        });
        table.fnSetFilteringDelay(800);
        return table;
    }

    function _server_data(sSource, aoData, fnCallback){
        var data = {};
        for (var i in aoData) {
            data[aoData[i].name] = aoData[i].value;
        }
        if(selected_device && selected_device != "All"){
            data['device_uuid'] = selected_device;
        }
        data['last_playback'] = self.last_playback;
        data['show_kdms'] = ($('.jq_show_kdm_toggle').attr("aria-pressed") === "true");
        var loader = new Loader({target: '#content_table_wrapper .dataTables_scroll', caption: gettext("Loading")});
        loader.show(function(){
            data.type_filter = $("#content_type_filter_dropdown").val();
            data.cleanup_filter = $("#content_cleanup_filter_dropdown").val();
            $.ajax({
                "dataType": 'json',
                "type": "POST",
                "url": sSource,
                "data": $.toJSON(data),
                "processData": false,
                "contentType": "application/json",
                "success": function(input){
                    $('.jq_disable_on_empty').button('option', 'disabled', input['aaData'].length == 0);
                    for (var count = input.aaData.length - 1; count >= 0; count--){
                        self.content[input.aaData[count].uuid] = input.aaData[count];
                    }
                    fnCallback(input);
                    _resize();
                    loader.hide();
                }
            });
        });
    }

    function _config_datatables_functions(){
        // clear filters and reload table
        $.fn.dataTableExt.oApi.fnFilterClear = function(oSettings)
        {
            /* Remove global filter */
            oSettings.oPreviousSearch.sSearch = "";

            // // reset filter dropdown
            var select = $('#content_type_filter_dropdown');
            $(select).val(jQuery('options:first', select).val());
            $('#content_table_filter input').val(undefined);

            var filter_cleanup_select = $('#content_cleanup_filter_dropdown');
            $(filter_cleanup_select).val(jQuery('options:first', filter_cleanup_select).val());
            $('#content_table_filter input').val(undefined);

            /* Remove the text of the global filter in the input boxes */
            if (typeof oSettings.aanFeatures.f != 'undefined'){
                $(oSettings.aanFeatures.f).find('input:first-child').val('');
            }
            /* Remove the search text for the column filters - NOTE - if you have input boxes for these
             * filters, these will need to be reset
             */
            for(var i=0, iLen=oSettings.aoPreSearchCols.length ; i<iLen ; i++){
                oSettings.aoPreSearchCols[i].sSearch = "";
            }
            /* Redraw */
            oSettings.oApi._fnReDraw( oSettings );
        };
    }

    function _clear_info_pane(){
        $("#content_info_pane").empty();
        $("#content_static_cpl_title").empty();
    }

    function _load_cpl_details(cpl_uuid , device_id){
        if(!cpl_uuid) return;

        if(last_detailed_content_request && last_detailed_content_request.state() == 'pending'){
            // there is already a pending request
            last_detailed_content_request.abort();
        }

        last_detailed_content_request = helpers.ajax_call({
            url:'/tms/get_content_detailed',
            loader: {
                target: $('#content_info_pane')
            },
            data:{
                content_uuids: [cpl_uuid],
                key_info: true
            },
            success_function: function(input){
                _update_cpl_info(input);
            }
        });
    }

    function _validate_content(event){
        var device_uuid = $(this).attr('device_id');

        helpers.ajax_call({
            url:'/core/content/validate',
            data:{
                content_id: self.cpl_uuid,
                device_id: device_uuid
            },
        });
    }

    function _check_availability(){

        var device_id, valid_days, server_calendar_days;

        // for each server check availability and update the server-specific calendar
        for( var server_index in self.content_device_list){
            var current_device = self.content_device_list[server_index];
            if (current_device.category === 'sms'){
                device_id = self.content_device_list[server_index].id;

                // get each day div of the server's calendar
                server_calendar_days = $("#calendar_"+device_id).children('div').each(function(){
                    var kdm_id, kdm,
                        start_of_day = new Date($(this).attr('year') , $(this).attr('month'), $(this).attr('day'), 0).getTime()/1000,
                        end_of_day = new Date($(this).attr('year') , $(this).attr('month'), $(this).attr('day'), 24).getTime()/1000,
                        valid = false,
                        partial = false;

                    // validate
                    for(kdm_id in self.current_cpl_availability[device_id]){
                        kdm = self.current_cpl_availability[device_id][kdm_id];
                        if (kdm.status != 'ok' || kdm.matched_device_uuid != device_id) {
                            continue;
                        }

                        if (kdm["not_valid_before"] <= start_of_day && kdm["not_valid_after"] >= end_of_day){
                            valid = true;
                            break;
                        }else if(start_of_day < kdm["not_valid_before"] && kdm["not_valid_before"] < end_of_day){
                            partial = true;
                        }else if(start_of_day < kdm["not_valid_after"] && kdm["not_valid_after"] < end_of_day){
                            partial = true;
                        }
                    }

                    //update display
                    if( valid == true){
                        $(this).addClass('content_availability_calendar_valid_day');
                    }
                    else if( partial == true ){
                        $(this).addClass('content_availability_calendar_partial_day');
                        // Should show something like "Valid until 4:00pm" as a tooltip on partial day divs
                        $(this).attr("title",self.current_cpl_availability[device_id][kdm_id]["not_valid_after_string"]);
                    }
                    else{
                        $(this).removeClass('content_availability_calendar_valid_day');
                        $(this).removeClass('content_availability_calendar_partial_day');
                    }
                });
            }
        }
    }

    function _update_availability_info(input){
        self.current_cpl_availability = input.data;
        update_calendar();
        _check_availability();
        _update_kdms();
    }

    function _update_kdms(){
        var screen_obj_list = [], kdm_lookup = {}, data = {};
        var kdm_object, screen_object, unknown_object,
            server_index, server,
            kdm_id, kdm, count;
        count = 0;

        for(server_index in self.content_device_list){
            if(g_last_selected_device["id"] == "All" || g_last_selected_device["id"] == self.content_device_list[server_index]["id"]){
                server = self.content_device_list[server_index];
                if(server.category === 'sms' && self.current_cpl_availability[server.id]){
                    screen_object = {
                        screen_title: server.screen().title,
                        screen_identifier: server.screen().identifier,
                        kdms: [],
                        device_uuid: server.id
                    };
                    kdm_lookup[server.id] = {};
                    for(kdm_id in self.current_cpl_availability[server.id]){
                        kdm = self.current_cpl_availability[server.id][kdm_id];
                        kdm_object = {
                            kdm_uuid: kdm_id,
                            start: moment.unix(kdm.not_valid_before).format('ddd DD MMM YYYY HH:mm:ss'),
                            end: moment.unix(kdm.not_valid_after).format('ddd DD MMM YYYY HH:mm:ss'),
                            serial: kdm["device_serial_number"],
                            status: kdm.status,
                            matches: (kdm.matched_device_uuid == server.id),
                            on_device: true,
                            on_lms: false
                        };
                        screen_object.kdms.push(kdm_object);
                        count++;
                        kdm_lookup[server.id][kdm_id] = kdm_object;
                    }
                    screen_obj_list.push(screen_object);
                }
            }
        }

        unknown_object = {
            screen_title: '?',
            screen_identifier: '?',
            kdms: [],
            device_uuid: null
        };
        for(server_index in self.content_device_list){
            server = self.content_device_list[server_index];
            if(server.category === 'lms' && self.current_cpl_availability[server.id]){
                data.lms_uuid = server.id;
                data.lms_device_name = server.name;
                for(kdm_id in self.current_cpl_availability[server.id]){
                    kdm = self.current_cpl_availability[server.id][kdm_id];
                    if(kdm.matched_device_uuid && kdm_lookup[kdm.matched_device_uuid]) {
                        if (kdm_lookup[kdm.matched_device_uuid][kdm_id]){
                            kdm_lookup[kdm.matched_device_uuid][kdm_id].on_lms = true;
                        }
                        else{
                            for (var screen in screen_obj_list){
                                if(screen_obj_list[screen]['device_uuid'] == kdm.matched_device_uuid){
                                    kdm_object = {
                                    kdm_uuid: kdm_id,
                                    start: moment.unix(kdm.not_valid_before).format('ddd DD MMM YYYY HH:mm:ss'),
                                    end: moment.unix(kdm.not_valid_after).format('ddd DD MMM YYYY HH:mm:ss'),
                                    serial: kdm["device_serial_number"],
                                    status: kdm.status,
                                    matches: (kdm.matched_device_uuid == server.id),
                                    on_device: false,
                                    on_lms: true
                                    };
                                    screen_obj_list[screen].kdms.push(kdm_object);
                                    count++;
                                }
                            }
                        }
                    }
                    else{
                        kdm_object = {
                            kdm_uuid: kdm_id,
                            start: moment.unix(kdm.not_valid_before).format('ddd DD MMM YYYY HH:mm:ss'),
                            end: moment.unix(kdm.not_valid_after).format('ddd DD MMM YYYY HH:mm:ss'),
                            serial: kdm["device_serial_number"],
                            status: kdm.status,
                            matches: false,
                            on_device: false,
                            on_lms: true
                        };
                        unknown_object.kdms.push(kdm_object);
                        count++;
                    }
                }
            }
        }
        if (unknown_object.kdms.length > 0) {
            screen_obj_list.push(unknown_object);
        }
        data.kdms_on_device = screen_obj_list;
        data.count = count;

        // append template
        $(self.kdm_tmpl).tmpl(data).appendTo($('#content_info_pane_key_wrapper').empty());
    }

    function load_kdm_details(){
        var kdm_uuid = $(this).attr("kdm_uuid");
        var kdm_on_lms = $(this).attr("kdm_on_lms");
        var lms_uuid = $(this).attr("lms_uuid");
        var device_uuid = $(this).parent().attr("device_uuid");
        var device_number = $(this).parent().attr("device_number");
        var kdm = {};

        if (device_uuid === "" || self.current_cpl_availability[device_uuid][kdm_uuid] == undefined) {
            kdm = _create_kdm_info(kdm_uuid, kdm_on_lms, lms_uuid, device_number);
        }
        else {
            kdm = _create_kdm_info(kdm_uuid, kdm_on_lms, device_uuid, device_number);
        }
        var content_kdm_dialog = dialog.open({
            'title': gettext("KDM Details"),
            'template': '#content_kdm_dialog',
            'data':{"kdm": kdm, "device_uuid": device_uuid},
            'buttons':[],
        });

        $('#reupload_kdm_button').click(reupload_kdm);
        $('#force_reupload_kdm_button').click(force_reupload_kdm);
    }

    function _create_kdm_info(kdm_uuid, kdm_on_lms, device_uuid, device_number) {
        var kdm = {};

        if( self.current_cpl_availability[device_uuid] != undefined && self.current_cpl_availability[device_uuid][kdm_uuid] != undefined){
            kdm = self.current_cpl_availability[device_uuid][kdm_uuid];
            kdm.screen_number = device_number;
            kdm.kdm_uuid = kdm_uuid;
            kdm.on_lms = kdm_on_lms == 'true';
        }
        return kdm;
    }

    function _update_cpl_info(input){
        // Get cpl uuid from dict
        for (var cpl_uuid in input.data) break;
        var cpl = input.data[cpl_uuid];
        var device_validity = [];
        var server;

        // CPL info section
        if(get_selected_device()["id"] != "All" ){
            var cpl_metadata = input.data[cpl_uuid]["devices"][get_selected_device()["id"]];
            if( cpl_metadata["cpl_size"] != undefined ){
                cpl.size = helpers.display_bytes(cpl_metadata["cpl_size"]);
                //create date will only be specified for the LMS
                cpl.ingest_date = cpl_metadata["ingest_date"];
                cpl.ingest_source_type = null;
                var ingest_source_type = cpl_metadata["ingest_source_type"];
                if (ingest_source_type != null){
                    var ingest_source_type_display = pretty_device_types[ingest_source_type] != undefined ? pretty_device_types[ingest_source_type] : $.capitalise(ingest_source_type);
                    cpl.ingest_source_type = ingest_source_type_display;
                }
            }
        }
        cpl.uuid = cpl_uuid;

        // ensure the content kind is a valid one
        if(typeof content_kind_reference[cpl.content_kind] == "undefined")
            cpl.content_kind = self.content[cpl_uuid].content_kind;

        $(self.info_pane_tmpl).tmpl({cpl:cpl}).appendTo($('#content_info_pane').empty());

        // Check CPL's availability on each device
        for ( var server_key in self.content_device_list){
            server = self.content_device_list[server_key];
            // if cpl found on device
            if ( cpl['devices'][server.id] != undefined && 'validation_code' in cpl['devices'][server.id]){

                var valid_now = cpl['devices'][server.id]['valid_now'];
                var valid_in_future = cpl['devices'][server.id]['valid_in_future'];
                var expires_in_24 = cpl['devices'][server.id]['expires_in_24'];
                // device validity
                device_validity.push({
                    'name': helpers.get_device_name(server.id),
                    'validation': helpers.content_status_info(cpl['devices'][server.id]['validation_code'],selected_device),
                    'id': server.id,
                    'error_messages': cpl['devices'][server.id]["error_messages"],
                    'encrypted': cpl['encrypted'],
                    'kdm_status': helpers.get_kdm_icon_class(valid_now, valid_in_future, expires_in_24),
                    'is_playback': helpers.supported('playback',server.type)
                });
            }
        }
        self.current_cpl_validity = device_validity;

        if(device_validity.length == 0){
            $(self.device_status_tmpl).tmpl({devices:device_validity}).appendTo($('#content_info_pane_server_wrapper').empty());
            $('.jq_scan_devices').hide();
        }
        else{
            $(self.device_status_tmpl).tmpl({devices:device_validity}).appendTo($('#content_info_pane_server_wrapper').empty());
            $('.jq_scan_devices').show();
            $('.jq_scan_devices').on('click.content', scan_content_dialog);
            $('.jq_validate').on('click', _validate_content);
        }
        get_availability_info(cpl_uuid, "#content_info_pane_key_wrapper");
    }

    function _update_disk_usage_and_raid_status(input, cv){
        //always clear the states here, if we didnt get info we have nothing to show.
        $('#disk_usage').empty();
        $('#raid_status').empty();

        // if we can get can get disk_usage information, calculate it, throw it in and show the div. else hide it
        if (input.data[cv.device_id] !== undefined && input.data[cv.device_id]["disk_usage"] !== undefined && input.data[cv.device_id]["disk_usage"]["available"] !== undefined && input.data[cv.device_id]["disk_usage"]["total_size"] !== undefined) {
            var disk_usage = {
                available:input.data[cv.device_id]["disk_usage"]["available"],
                total_size:input.data[cv.device_id]["disk_usage"]["total_size"]
            };
            $(self.disk_usage_tmpl).tmpl2(disk_usage).appendTo($('#disk_usage').empty());

            $('#disk_usage_wrapper').show();
        }
        else {
            $('#disk_usage_wrapper').hide();
        }

        // if we can get can get raid status information, calculate it, throw it in and show the div. else hide it
        if (input.data[cv.device_id]["raid_status"].length) {
            $(self.raid_status_tmpl).tmpl({'raid_status' : input.data[cv.device_id]["raid_status"]}).appendTo($('#raid_status').empty());

            $('#raid_status').qtip({
                content: {
                    text: $(self.raid_status_hover_tmpl).tmpl({'raid_status' : input.data[cv.device_id]["raid_status"]})
                },
                position: {
                    my: "right center",
                    at: "left center"
                },
                style: {
                    classes: 'qtip-shadow qtip-rounded qtip-yellow'
                }
            });
            $('#raid_status_wrapper').show();
        }
        else {
            $('#raid_status_wrapper').hide();
        }

        $('#content_disk_usage_raid_status_wrapper').show();
    }

    function _update_table() {
        self.content_table.fnDraw();
    }

    function scan_content_dialog(){

        var device_ids = [];
        var device;
        for(var device_index in self.current_cpl_validity){
            device = self.current_cpl_validity[device_index];
            if(device.validation.code != 3 && device.validation.code != -1){
                device_ids.push(device.id);
            }
        }

        var scan_content_dialog = dialog.open({
            'title': gettext('Scan CPL on Devices'),
            'template': '#scan_content_dialog',
            'data':{"content": self.cpl_uuid, 'device_ids':device_ids},
            'width':600,
            'height':400,
            'onClose': function(){
            }
        });

        var dt_cols = [];
        dt_cols.push({
            "mDataProp": function (oData, type){
                if (type == 'display'){
                    return $('#image_list_tmpl').tmpl({image_items:[{name: oData.status}]}).html();
                }
                else{
                    return oData.status;
                }
            },
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            "mDataProp": function (oData, type) {
                //datatables doesn't like undefined for sorting
                return (oData.type === undefined) ? null : oData.type;
            },
            "bSearchable": false,
            "bUseRendered": false
        });
        dt_cols.push({
            "mDataProp": function (oData, type) {
                if (type == 'display') {
                    return oData.reel||'&nbsp;';
                } else {
                    return parseInt(oData.reel||0,10);
                }
            },
            "bSearchable": false,
            "bUseRendered": false
        });

        dt_cols.push({
            "mDataProp": function (oData, type) {
                return oData.message;
            },
            "bSearchable": false,
            "bUseRendered": false
        });

        dt_cols.push({
            "mDataProp": function (oData, type) {
                return oData.file_name;
            },
            "bSearchable": false,
            "bUseRendered": false
        });
        // init table
        self.scan_content_table = $('#scan_content_table').dataTable({
            "bDestroy": true,
            "bAutoWidth": true,
            "bFilter": false,
            "bAutoHeight": true,
            "aaSorting": [[ 2, "asc" ]],
            "bPaginate": false,
            "bInfo": false,
            "aoColumns": dt_cols,
            "sScrollY": 300,
            "oLanguage": {
                "sZeroRecords": '<span class="icon-info table_image"></span>'+ gettext('No matching items were found')
            }
        });
        //hide the datatable until the ajax call has completed and the table rows are drawn
        $('#scan_content_table_wrapper').hide();
        $('.jq_scan_drive').button().on('click.content', function(){
            // Needs to be anything but this
            $(".jq_scan_drive:checked").prop('checked', false).button("refresh");
            $(this).prop('checked', true).button("refresh");
            var content_id = $(this).attr('content_id');
            var device_id = $(this).attr('device_id');
            _scan_content(content_id, device_id);
        });
    }

    var scan_call;

    function _scan_content(content_id, device_id){
        $('#scan_content_validation_message').hide();

        $(".jq_scan_content_error").hide();
        $('#scan_content_table_wrapper').hide();
        $("#jq_scan_content_header").hide();

        self.scan_content_table.fnClearTable();
        if(scan_call){
            scan_call.abort();
        }
        scan_call = helpers.ajax_call({
            url:'/core/content/scan_content',
            loader: {
                target: "#scan_content_wrapper"
            },
            data: {
                content_id: content_id,
                device_id: device_id
            },
            success_function: function(input){
                scan_call = null;
                _scan_content_callback(input, device_id);
            },
            error_function: function(input){
                if(scan_call){
                    scan_call = null;
                    return;
                }
                $("#jq_scan_content_header").show();
                $("#jq_scan_content_header").text(gettext("Unknown Error"));
            }
        });
    }
    /*
     * Load the popup with the results of the scan
     */
    function _scan_content_callback(input, device_id){
        var device_id = $('.selected.jq_scan_drive').attr("device_id");

        if(input['data']["error"] != true){
            $('.fancybox-title').text(self.content[self.cpl_uuid].content_title_text);
            $('#scan_content_table_wrapper').show();
            var table_rows, table_row;
            table_rows = [];
            // is the content playable?
            var device_validation_status;
            for(var device in self.current_cpl_validity){
                if(self.current_cpl_validity[device].id == device_id){
                    device_validation_status = self.current_cpl_validity[device].validation.status;
                }
            }
            // are any of the files in error state?
            var file_error = false;
            for(var file_name in input['data']){
                var file = input['data'][file_name];
                if(file_name != "error"){
                    if (file['status'] == "error"){
                        file_error = true;
                    }
                    table_rows.push({
                        status: file['status'],
                        type: file['type'],
                        reel: file['reel'],
                        message: file['message'],
                        file_name: file_name
                    });
                }
            }
            if(file_error == true && device_validation_status == "ok"){
                $('#scan_content_validation_message').text("Content has sourced missing files from shared assets - ok to play");
                $('#scan_content_validation_message').show();
            }
            else if(file_error == false && device_validation_status == "error"){
                $('#scan_content_validation_message').text("Content is present but corrupt - cannot play");
                $('#scan_content_validation_message').show();
            }
            self.scan_content_table.fnAddData(table_rows);
        }
        else{
            $(".jq_scan_content_error").show();
            $(".jq_scan_content_error").text(input.messages[0]);
        }
    }
}
