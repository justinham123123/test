/*
 * Custom jQuery Utility functions
 * 
 */

(function( $ ){
    
    $.get_query_params = function() {
        var search_string, i, params, param, serialised_params, name, value;
        search_string = window.location.search.slice(1);
        serialised_params = search_string.split('&');
        params = {};
        for (i=0; i<serialised_params.length; i++) {
            param = serialised_params[i].split('=');
            name = param[0], value = param[1];
            if (name != '') {
                params[name] = value;
            }
        }
        return params;
    };
    
    $.keys = function(iterable) {
        var keys = [];
        for (var k in iterable) {
            keys.push(k);
        }
        return keys;
    }
    
    $.values = function(iterable) {
        var values = [];
        for (var k in iterable) {
            values.push(iterable[k]);
        }
        return values;
    }
    
    $.copy = function(object) {
        if ($.isArray(object)) {
            return $.extend(true, [], object);
        } else if (typeof object == 'object') {
            return $.extend(true, {}, object);
        } else {
            return object;
        }
    };
    
    $.reduce = function(array, callback) {
        if (array === null || array === undefined) throw new TypeError('Array object is null or undefined');
        var i=0, l=array.length >> 0, value;
        if (typeof callback !== 'function') throw new TypeError('Callback is not a function');
        if (arguments.length < 3) {
            if (l === 0) throw new TypeError('Array is empty and no initial value');
            value = array[0];
            i = 0;
        } else {
            value = arguments[2];
        }
        while (i < l) {
            if (i in array) value = callback.call(undefined, value, array[i], i, array);
            ++i;
        }
        return value;
    };
    
    $.any = function(iterable, test) {
        var i;
        if (typeof test != 'undefined') {
            for (i in iterable) {
                if (test(iterable[i])) return true;
            }
        } else {
            for (i in iterable) {
                if (iterable[i]) return true;
            }
        }
        return false;
    };
    
    $._in = function(value, iterable) {
        if ($.isArray(iterable)) {
            return $.inArray(value, iterable) != -1;
        } else if (typeof iterable == 'string') {
            return iterable.indexOf(value+'') != -1;
        } else {
            return false;
        }
    };
    
    $.is_empty = function(iterable){
        if (typeof iterable == 'object') {
            return $.isEmptyObject(iterable);
        } else if ($.isArray(iterable)) {
            return iterable.length == 0;
        } else {
            $.error('Object is not iterable');
        }
    };
    
    $.isNaN = function(x) {
        return x !== x;
    };
    
    $.is_object = function(x) {
        return $.type(x) == 'object';
    };
    
    $.capitalise = function(string) {
        if (string == undefined)
            return ""
        return string.replace(/(?:^|\s)\w/g, function(matched) {
            return matched.toUpperCase();
        });
    };
    
    $.code_to_name = function(string){
        return country_codes[string.toLowerCase()]
    }
    
    $.val_or_default = function(value, _default) {
        return (value == null || $.isNaN(value)) ? _default : value;
    };
    
    $.val_or_undefined = function(value) {
        return (value == '') ? undefined : $.val_or_default(value);
    };
    
    $.time_helper = function(input) {
        if (input <10 && input >=0)
            return '0'+input
        else return input
    };
    
    $.duration_string_to_seconds = function(duration) {
        var parts = duration.split(':');
        var hours = parseInt(parts[0], 10);
        var minutes = parseInt(parts[1], 10);
        var seconds = parseInt(parts[2], 10);
        return seconds + 60*minutes + 60*60*hours;
    };
    
    $.seconds_to_duration = function(seconds) {
        var duration = {};
        duration.hours = parseInt(seconds/3600,10);
        duration.minutes = parseInt((seconds%3600)/60,10);
        duration.seconds = parseInt(Math.round(seconds%60),10);
        return duration
    };
    
    $.seconds_to_duration_string = function(seconds, no_hours, unknownForNull) {
        if(unknownForNull && seconds === null){
            return 'Unknown';
        }
        var duration = $.seconds_to_duration(seconds);
        var duration_string = '';
        if(no_hours){
            duration.minutes += 60*duration.hours;
        } 
        else {
            var hour = $.time_helper(duration.hours);
            if(!isNaN(hour)){
                duration_string += hour + ':';
            }
            else{
                return ("Unknown");
            }
        }

        if(duration.seconds >= 60){
            duration.minutes += 1;
            duration.seconds = duration.seconds - 60;
        }
        if(!no_hours && duration.minutes >= 60){
            duration.hours += 1;
            duration.minutes = duration.minutes - 60;
        }

        var min = $.time_helper(duration.minutes);
        var sec = $.time_helper(Math.round(duration.seconds))

        if(sec == 60){
            min += 1;
            sec = 0;
        }

        if(!isNaN(min) && !isNaN(sec)){
            duration_string += min + ':';
            duration_string += sec;
        }
        else{
            return ("Unknown");
        }
        return duration_string;
    };
    
    $.DataStore = function() {
        var store = $({});
        var dfd = $.Deferred();
        store.has_loaded = function() {
            return dfd.promise();
        };
        store.set_loaded = function(loaded) {
            if (loaded) {
                dfd.resolve();
                store.trigger('loaded');
            } else if (dfd.state()!='pending'){
                //If setting loaded to false and deferred is already resolved or rejected replace 
                dfd = $.Deferred();
            }
        }
        return store;
    };
    
    function default_sort(a, b) {
        a = (a+'').toLowerCase();
        b = (b+'').toLowerCase();
        if (a < b) {
            return 1;
        } else if (a > b) {
            return -1;
        } else {
            return 0;
        }
    }
    
    $.fn.set_options = function(option_array, selected_value, sort) {
        var i, options;
        
        if (typeof sort == 'undefined') sort = default_sort;
        if (sort) {
            option_array.sort(sort)
        }
        
        options = [];
        for (i=0; i < option_array.length; i++) {
            options.push('<option class="%class" value="%value">%text</option>'.replace('%value', option_array[i].value).replace('%text', option_array[i].text).replace('%class', option_array[i]._class));
        }
        
        return this.filter('select').each(function() {
            $(this).html($(options.join(''))).val(selected_value);
        }).end();
    };
    
    $.fn.outer_html = function() {
        return $('<div/>').append($(this).clone()).remove().html();
    };

    $.fn.raw_tmpl = function(data){
        var source = this.html()
        var id = this.attr("id");
        if($compiled_templates[id] === undefined){
            $compiled_templates[id] = Handlebars.compile(source);
        }
        var template = $compiled_templates[id];
        var html = template(data)
        return html
    };

    $.fn.tmpl2 = function(data, dom){
        var source = this.html()
        var id = this.attr("id");
        if($compiled_templates[id] === undefined){
            $compiled_templates[id] = Handlebars.compile(source);
        }
        var template = $compiled_templates[id];
        var html = template(data)
        if(dom){
            $(dom).empty().append(html);
        }
        else{
            return $(html);
        }     
    };

    $.fn.tmpl_string = function(data){
        var source = this.html()
        var template = Handlebars.compile(source);
        var html = template(data)
        return html
    };

    $.fn.attr_dict = function(attr_list){
        output = {};
        for(var i = 0; i < attr_list.length; i++){
            output[attr_list[i]] = $(this).attr(attr_list[i]);
        }
        return output
    };
})( jQuery );

/**
 * jQuery.fn.sortElements
 * --------------
 * @param Function comparator:
 *   Exactly the same behaviour as [1,2,3].sort(comparator)
 *   
 * @param Function getSortable
 *   A function that should return the element that is
 *   to be sorted. The comparator will run on the
 *   current collection, but you may want the actual
 *   resulting sort to occur on a parent or another
 *   associated element.
 *   
 *   E.g. $('td').sortElements(comparator, function(){
 *      return this.parentNode; 
 *   })
 *   
 *   The <td>'s parent (<tr>) will be sorted instead
 *   of the <td> itself.
 */
jQuery.fn.sortElements = (function(){
 
    var sort = [].sort;
 
    return function(comparator, getSortable) {
 
        getSortable = getSortable || function(){return this;};
 
        var placements = this.map(function(){
 
            var sortElement = getSortable.call(this),
                parentNode = sortElement.parentNode,
 
                // Since the element itself will change position, we have
                // to have some way of storing its original position in
                // the DOM. The easiest way is to have a 'flag' node:
                nextSibling = parentNode.insertBefore(
                    document.createTextNode(''),
                    sortElement.nextSibling
                );
 
            return function() {
 
                if (parentNode === this) {
                    throw new Error(
                        "You can't sort elements if any one is a descendant of another."
                    );
                }
 
                // Insert before flag:
                parentNode.insertBefore(this, nextSibling);
                // Remove flag:
                parentNode.removeChild(nextSibling);
 
            };
 
        });
 
        return sort.call(this, comparator).each(function(i){
            placements[i].call(getSortable.call(this));
        });
 
    };
 
})();

(function($){
    var methods = {
        init : function(options){
            var hms_wrapper = $('<div class="hms_wrapper" />');
            hms_wrapper.append('<div class="hms_hours"><input type="text" title="Hours" /></div><div class="hms_minutes"><input type="text" title="Minutes" /></div><div class="hms_seconds"><input type="text" title="Seconds" /></div>');
            var settings = $.extend({ 
                seconds: 0,
                minutes: 0,
                hours: 0,
                disabled: false
            }, options);

            //Overwrite with dom values if present
            var dom_seconds = parseInt(this.attr("data-seconds"), 10);
            if(dom_seconds){
                settings['seconds'] = dom_seconds;
            }
            
            var duration = $.seconds_to_duration(settings.seconds + settings.minutes * 60 + settings.hours * 60 * 60);

            hms_wrapper.find('.hms_hours input').val($.time_helper(duration.hours));
            hms_wrapper.find('.hms_minutes input').val($.time_helper(duration.minutes));
            hms_wrapper.find('.hms_seconds input').val($.time_helper(duration.seconds));
            
            this.html(hms_wrapper);
            hms_wrapper.on('mouseup.hms', 'input', function(event){
                $(this).select();
            });
            hms_wrapper.on('blur.hms', 'input', function(event){
                var current_val = parseInt($(this).val(), 10);
                if(isNaN(current_val)){
                    $(this).val('00');
                }
                else{
                    $(this).val($.time_helper(current_val));
                }
            });
            hms_wrapper.on('keydown.hms', 'input', function(event){
                var kcode = event.keyCode
                var current_val = parseInt($(this).val(), 10);
                var max_val = $(this).parent().hasClass('hms_hours') ? 23 : 59;
                switch(true){
                    case kcode == 13:
                        if(settings.enter) settings.enter(); break;
                    case kcode == 38:
                        var new_val = (current_val == max_val) ? 0 : current_val + 1;
                        $(this).val($.time_helper(new_val));
                        return;
                    case kcode == 40:
                        var new_val = (current_val == 0) ? max_val : current_val - 1;
                        $(this).val($.time_helper(new_val));
                        return;
                    case 47 < kcode && kcode < 58:
                    case 95 < kcode && kcode < 106:
                    case (kcode == 46 || kcode == 8 || kcode == 9):
                        return;
                    default:
                        return false;
                }
            });
            hms_wrapper.on('keyup.hms', 'input', function(event){
                var now_val = parseInt($(this).val(), 10);
                var max_val = $(this).parent().hasClass('hms_hours') ? 23 : 59;
                if(now_val > max_val){
                    $(this).val($.time_helper(max_val));
                }
            });
            if(settings.disabled){
                hms_wrapper.find('input').attr('disabled', 'disabled');
            }
            return this;
        },
        retrieve : function(options){
            var seconds_from_hours = parseInt(this.find('.hms_hours input').val(), 10) * 3600;
            var seconds_from_minutes = parseInt(this.find('.hms_minutes input').val(), 10) * 60;
            var seconds_from_seconds = parseInt(this.find('.hms_seconds input').val(), 10);
            return seconds_from_hours + seconds_from_minutes + seconds_from_seconds;
        },
        retrieve_time : function(options){
            var hours = this.find('.hms_hours input').val() || "00";
            var minutes = this.find('.hms_minutes input').val() || "00";
            var seconds = this.find('.hms_seconds input').val() || "00";
            return hours +':' + minutes + ':' + seconds;
        },
        retrieve_datetime : function(options){
            var hours = this.find('.hms_hours input').val() || "00";
            var minutes = this.find('.hms_minutes input').val() || "00";
            var seconds = this.find('.hms_seconds input').val() || "00";
            var datetime = new Date();
            datetime.setSeconds(seconds);
            datetime.setMinutes(minutes);
            datetime.setHours(hours);
            return datetime
        },
        enable: function(){
            $(this).find('input').removeAttr('disabled');
        },
        disable: function(){
            $(this).find('input').attr('disabled', 'disabled');
        },
        destroy: function(){
            return this.empty();
        }
    };
    $.fn.hms = function(method){
        if ( methods[method] ) {
          return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
        } else if ( typeof method === 'object' || ! method ) {
          return methods.init.apply( this, arguments );
        } else {
          $.error( 'Method ' +  method + ' does not exist on jQuery.hms' );
        }
    };
})(jQuery);

(function($){
    var prev_search = null;

    var methods = {
        init: function(callback){
            var to = null;
            $(this).off("keyup");
            $(this).keyup(function(e){                
                var cur = $(this).val();
                if(cur != prev_search){
                    clearTimeout(to);
                    prev_search = cur;
                    if(e.keyCode == 13){
                        callback();
                    }
                    else{
                        to = setTimeout(function(){
                            callback(cur);
                        }, 800)
                    }                    
                }
            });
        }
    };

    $.fn.searcher = function(method){
        if(methods[method]){
          return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } 
        else if(typeof method === 'function' || !method){
          return methods.init.apply(this, arguments);
        } 
        else{
          $.error('Method ' +  method + ' does not exist on jQuery.hms' );
        }
    };
})(jQuery);

(function( $ ) {
    
    var methods = {
        write: function(name, value, days) {
            name = 'tms2_%user_%name'.replace('%user', global_user_information.username).replace('%name', name);
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days*24*60*60*1000));
                var expires = "; expires=" + date.toGMTString();
            } else {
                var expires = "";
            }
            document.cookie = name + "=" + value + expires + "; path=/";
        },
        read: function(name) {
            name = 'tms2_%user_%name'.replace('%user', global_user_information.username).replace('%name', name);
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for(var i = 0;i < ca.length;i++) {
                var c = ca[i];
                while(c.charAt(0) == ' ') {
                    c = c.substring(1, c.length);
                }
                if (c.indexOf(nameEQ) == 0) {
                    return c.substring(nameEQ.length, c.length);
                }
            }
            return null;
        },
        remove: function(name) {
            name = 'tms2_%user_%name'.replace('%user', global_user_information.username).replace('%name', name);
            document.cookie = name+'=;expires=0;path=/';
        }
    };
    
    $.cookie = function(method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else {
            $.error('Unsupported method');
        }
    };
    
})( jQuery );

(function( $, window) {
    
    if (window.history && window.history.pushState) {
        $.push_state = function(url) {
            window.history.pushState({}, 'TMS', url);
        }
    } else {
        var reference_hash;
        $.push_state = function(url) {
            reference_hash = url;
            window.location = url;
        }
        $(window).on('hashchange', function() {
            if (window.location.hash != reference_hash) {
                $(window).trigger('popstate', [{}]);
                reference_hash = window.location.hash;
            }
        });
    }
    
})( jQuery, window);


/*** DATATABLES ***/
//Check if DATATABLES is defined, allows us to use helpers on login page.
if($.fn.dataTableExt != undefined){
    (function( $ ) {
        
        $.fn.dataTableExt.oSort['attr_date-asc']  = function(x,y) {
            x = parseInt($(x).attr('date'));
            y = parseInt($(y).attr('date'));
            return ((x < y) ? -1 : ((x > y) ?  1 : 0));
        };

        $.fn.dataTableExt.oSort['attr_date-desc'] = function(x,y) {
            x = parseInt($(x).attr('date'));
            y = parseInt($(y).attr('date'));
            return ((x < y) ?  1 : ((x > y) ? -1 : 0));
        };
        
    })(jQuery);
}

//An implementation of a case-insensitive contains pseudo
//made for all versions of jQuery
(function( $ ) {

function icontains( elem, text ) {
 return (
     elem.textContent ||
     elem.innerText ||
     $( elem ).text() ||
     ""
 ).toLowerCase().indexOf( (text || "").toLowerCase() ) > -1;
}

$.expr[':'].icontains = $.expr.createPseudo ?
 $.expr.createPseudo(function( text ) {
     return function( elem ) {
         return icontains( elem, text );
     };
 }) :
 function( elem, i, match ) {
     return icontains( elem, match[3] );
 };

})( jQuery );


(function($){
    var methods = {
        init: function(args){
            args = args || {};
            var options = args['options'] || [{
                'text': gettext("On")
            },{
                'text': gettext("Off")
            }]
            var enabled = args['enabled'];
            var changed = args['changed'];
            var html = $('#switch_tmpl').tmpl2({
                enabled: enabled,
                options: options
            });

            $.each(this, function(x,v){
                var dom = $(this);
                var id = dom.attr("id");
                var classes = dom.attr("class") + " " + html.attr("class");
                var on = dom.hasClass("on");

                var obj = html.clone().attr("id", id).attr("class", classes);
                $(obj).on('click.multi_switch', function(){
                    obj.toggleClass('on');
                    if(changed){
                        changed();
                    }
                });
                $(v).replaceWith(obj);
            });
        },
        on: function(){
            return this.hasClass('on');
        },
        val: function(){
            var c = this.on() ? ".on_label" : ".off_label";
            return this.find(c).attr("data-val");
        }
    };
    $.fn.switch = function(method){
        if(methods[method]){
          return methods[ method ].apply(this, Array.prototype.slice.call(arguments, 1));
        } 
        else if(typeof method === 'object' || !method){
          return methods.init.apply(this, arguments);
        } 
        else{
          $.error('Method ' +  method + ' does not exist on jQuery.switch');
        }
    };
})(jQuery);

(function($){
    var methods = {
        init: function(args){
            var options = args['options'];
            var selected = args['selected'];

            var html = $('#multi_tmpl').tmpl2({
                options: options
            })

            if(selected !== undefined){
                html.find('.multi_select_option[data-val="'+selected+'"]').addClass('selected');
            }

            $.each(this, function(x,v){
                var dom = $(this);
                var id = dom.attr("id");
                var classes = dom.attr("class") || "" + " " + html.attr("class");

                var obj = html.clone().attr("id", id).attr("class", classes);
                $(obj).on('click.multi_select_option', function(e){
                    var target = $(e.target);
                    target.addClass('selected');
                    target.siblings().removeClass('selected');
                    if(args['click']){
                        args['click'](target.attr("data-val"));
                    }
                });
                $(v).replaceWith(obj);
            });
        },
        is_selected: function(val){
            return this.multi('val') === val;
        },
        selected: function(){
            return this.find('.selected');
        },
        val: function(){
            return this.multi('selected').attr("data-val");
        }
    };
    $.fn.multi = function(method){
        if(methods[method]){
          return methods[ method ].apply(this, Array.prototype.slice.call(arguments, 1));
        } 
        else if(typeof method === 'object' || !method){
          return methods.init.apply(this, arguments);
        } 
        else{
          $.error('Method ' +  method + ' does not exist on jQuery.switch');
        }
    };
})(jQuery);