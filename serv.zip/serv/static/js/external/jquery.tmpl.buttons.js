(function($) {
    //NOTE: this is only used by TMS. ETMS uses different templating and
    //      the following is done in the templates rather than in js code

    var old_tmpl = $.tmpl;
    $.tmpl = function( tmpl, data, options, parentItem ) {
        var ret = old_tmpl(tmpl, data, options, parentItem);
        $(ret).find('*').andSelf().filter('button').each(function() {
            var $this = $(this);
            var has_text = !!$this.html();
            $this.button({text: has_text});
            if (!has_text) {
                $this.button('option', 'label', 'nbsp;');//hack for height
            }
            if ($this.attr('img_cls')) {
                $this.button('option', 'icons', {primary: 'image '+$this.attr('img_cls')});
            }
        });
        return ret;
    };
    $.extend($.tmpl, old_tmpl);

})(jQuery);
