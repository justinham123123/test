(function(window, $) {
    var pop_state = true;
    if (typeof window.onpopstate == 'undefined') {
        $(window).on('hashchange', function() {
            if (pop_state) {
                $(window).trigger('popstate');
            }
        });
    }
    if (!window.history.pushState) {
        window.history.pushState = function(_, __, url) {
            var hash_pos = url.indexOf('#');
            pop_state = false;
            $(window).one('hashchange', function() {
                pop_state = true;
            });
            window.location.hash = (hash_pos==-1) ? '' : url.substr(hash_pos);
        }
    }
    if (!window.history.replaceState) {
        window.history.replaceState = function(_, __, url) {
            var hash_pos = url.indexOf('#');
            pop_state = false;
            $(window).one('hashchange', function() {
                pop_state = true;
            });
            window.location.hash = (hash_pos==-1) ? '' : url.substr(hash_pos);
        }
    }
})( window, jQuery );