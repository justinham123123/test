(function($){
    var methods = {
        init : function(options){
            var hms_wrapper = $('<div class="hms_wrapper" />');
            hms_wrapper.append('<div class="hms_hours"><input type="text" title="Hours" /></div><div class="hms_minutes"><input type="text" title="Minutes" /></div><div class="hms_seconds"><input type="text" title="Seconds" /></div>');

            var settings = $.extend({
                seconds: 0,
                minutes: 0,
                hours: 0,
                disabled: false
            }, options);

            var duration = $.seconds_to_duration(settings.seconds + settings.minutes * 60 + settings.hours * 60 * 60);

            hms_wrapper.find('.hms_hours input').val($.time_helper(duration.hours));
            hms_wrapper.find('.hms_minutes input').val($.time_helper(duration.minutes));
            hms_wrapper.find('.hms_seconds input').val($.time_helper(duration.seconds));

            this.html(hms_wrapper);
            hms_wrapper.on('mouseup.hms', 'input', function(event){
                $(this).select();
            });
            hms_wrapper.on('blur.hms', 'input', function(event){
                var current_val = parseInt($(this).val(), 10);
                if(isNaN(current_val)){
                    $(this).val('00');
                }
                else{
                    $(this).val($.time_helper(current_val));
                }
            });
            hms_wrapper.on('keydown.hms', 'input', function(event){
                var kcode = event.keyCode
                var current_val = parseInt($(this).val(), 10);
                var max_val = $(this).parent().hasClass('hms_hours') ? 23 : 59;
                switch(true){
                    case kcode == 13:
                        settings.enter(); break;
                    case kcode == 38:
                        var new_val = (current_val == max_val) ? 0 : current_val + 1;
                        $(this).val($.time_helper(new_val));
                        return;
                    case kcode == 40:
                        var new_val = (current_val == 0) ? max_val : current_val - 1;
                        $(this).val($.time_helper(new_val));
                        return;
                    case 47 < kcode && kcode < 58:
                    case 95 < kcode && kcode < 106:
                    case (kcode == 46 || kcode == 8 || kcode == 9):
                        return;
                    default:
                        return false;
                }
            });
            hms_wrapper.on('keyup.hms', 'input', function(event){
                var now_val = parseInt($(this).val(), 10);
                var max_val = $(this).parent().hasClass('hms_hours') ? 23 : 59;
                if(now_val > max_val){
                    $(this).val($.time_helper(max_val));
                }
            });
            if(settings.disabled){
                hms_wrapper.find('input').attr('disabled', 'disabled');
            }
            return this;
        },
        retrieve : function(options){
            var seconds_from_hours = parseInt(this.find('.hms_hours input').val(), 10) * 3600;
            var seconds_from_minutes = parseInt(this.find('.hms_minutes input').val(), 10) * 60;
            var seconds_from_seconds = parseInt(this.find('.hms_seconds input').val(), 10);
            return seconds_from_hours + seconds_from_minutes + seconds_from_seconds;
        },
        retrieve_time : function(options){
            var hours = this.find('.hms_hours input').val();
            var minutes = this.find('.hms_minutes input').val();
            var seconds = this.find('.hms_seconds input').val();
            return hours +':' + minutes + ':' + seconds;
        },
        enable: function(){
            $(this).find('input').removeAttr('disabled');
        },
        disable: function(){
            $(this).find('input').attr('disabled', 'disabled');
        },
        destroy: function(){
            return this.empty();
        }
    };
    $.fn.hms = function(method){
        if ( methods[method] ) {
          return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
        } else if ( typeof method === 'object' || ! method ) {
          return methods.init.apply( this, arguments );
        } else {
          $.error( 'Method ' +  method + ' does not exist on jQuery.hms' );
        }
    };
})(jQuery);