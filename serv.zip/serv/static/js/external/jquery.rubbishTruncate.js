(function ($) {

	$.fn.rubbishTruncate = function(text_length) {
	    return this.each(function() {
	        $this = $(this);
	        if ($this.html().length > text_length + 3) {
	            $this.attr('title', $this.html());
	            $this.html($this.html().substring(0, text_length) + '&hellip;');
	        }
	    });
	};
})(jQuery);
