function Notification(){
    var self = this;
    self.message_store = $({});
    self.message_store.messages = {};
    self.next_message_id = 0;
    self.unread_list = [];
    self.pop_up_list = [];
    self.pop_up_active = false;
    self.pop_up_timeout = 0;
    self.pop_up_active_message;
    
    $('#notifications_btn').live('click', function(){
        self.open_dialog();
    });
    $('#messages_close').live('click', function(){
        self.next_message();
    });
    self.message_store.on('update', function(){
        self.store_update_handler();
    });
    
    /****  ALIAS FUNCTIONS - THIS SHOULD BE THE ONLY FUNCTIONS USED OUTSIDE OF THIS FILE - IF YOU NEED TO USE MORE - IT'S BROKEN ****/
    self.warning_msg = function(message, title, id, stealth){
        return self.add_msg({'message' : message, 'title' : title, 'id' : id, 'type':'warning', 'stealth' : stealth});
    }
    self.error_msg = function(message, title, id, stealth){
        return self.add_msg({'message' : message, 'title' : title, 'id' : id, 'type':'error', 'stealth' : stealth});
    }
    self.progress_msg = function(message, title, id, stealth){
        return self.add_msg({'message' : message, 'title' : title, 'id' : id, 'type':'progress', 'stealth' : stealth});
    }
    self.info_msg = function(message, title, id, stealth){
        return self.add_msg({'message' : message, 'title' : title, 'id' : id, 'type':'info', 'stealth' : stealth});
    }
    self.success_msg = function(message, title, id, stealth){
        return self.add_msg({'message' : message, 'title' : title, 'id' : id, 'type':'success', 'stealth' : stealth});
    }
    self.queued_msg = function(message, title, id, stealth){
        return self.add_msg({'message' : message, 'title' : title, 'id' : id, 'type':'queued', 'stealth' : stealth});
    }
    self.completed_msg = function(message, title, id, stealth){
        return self.add_msg({'message' : message, 'title' : title, 'id' : id, 'type':'completed', 'stealth' : stealth});
    }
    
    /**** END OF ALIAS FUNCTIONS ****/
    
    /**** THIS FUNCTION IS THE ONLY INTERFACE WITH THE MESSAGE STORE ****/
    /**** THE FIRST RULE OF THE MESSAGE STORE IS THAT WE DON'T MENTION THE MESSAGE STORE(OUTSIDE OF THIS FUNCTION) ****/
    self.add_msg = function(m){
        //TO DO - Add message.timeoutlength, message.something_that_means_only_pop_up_and_not_in_table, message.link_action eg. chat messages open the chat thread.
        m.message_date = (new Date()).getTime();
        if(self.message_store.messages[m.id] !== undefined){
            //This message updates a past message
            self.message_store.messages[m.id].message = m.message;
            self.message_store.messages[m.id].type = m.type;
            self.message_store.messages[m.id].message_date = m.message_date;
        }else{
            //This adds a new message
            m.id = self.next_message_id;
            self.message_store.messages[self.next_message_id] = m;
            self.next_message_id++;
        }
        if(!m.stealth){
            if(m.id == self.pop_up_current){
                $('#messages_messsages .message_body').html(m.message);
            }else{
                self.pop_up_list.push(m.id);
            }
        }
        self.unread_list.push(m.id);
        self.message_store.trigger('update');
        return m.id
    }
    self.store_update_handler = function(){
        var table_data = [];
        for(index in self.message_store.messages){
            var message = self.message_store.messages[index];
            var message_display = (message.title != '' && message.title != undefined) ? message.title + ' - ' + message.message : message.message
            table_data.push([message.type, message.id, message_display, message.message_date]);
            self.pop_up_start();
            self.update_count_holders();
            //To do - Drop the oldest when we get newer ones. Max 50?
        }
        if(self.message_data_table !== undefined){
            self.message_data_table.fnClearTable();
            self.message_data_table.fnAddData(table_data);
        }
    }
    self.pop_up_start = function(){
        //If popup loop is already active - no need to run it, message is queued.
        if(!self.pop_up_active){
            //Prevents latter messages spoiling the party.
            self.pop_up_active = true;
            //Start the loop
            self.pop_up_message();
        }
    }
    var message_height = -200;
    self.pop_up_message = function (){
        var time = ''; //junk for now....
	    var message_wrapper = $('#message_wrapper');
	    
	    $('#messages_message').empty();
	    var current_message = self.message_store.messages[self.pop_up_list.shift()];
        $('#messages_message').append($('#message_template').tmpl({'message_data':current_message, 'remove_by':time}));
	        
	    if (parseInt(message_wrapper.css('top')) > message_height) {
	        message_wrapper.animate({top:message_height}, 300, function(){ $(this).css('top', message_height-1); });
	    }
        message_wrapper.toggleClass('info warning error queued success completed',false);
        message_wrapper.toggleClass(current_message.type,true);
        self.pop_up_timeout = setTimeout('notification.next_message()', 3000);
    };    
    /*** On to the next... ***/
    self.next_message = function(){
        if(self.pop_up_list.length == 0){
            self.close_message();
            self.pop_up_active = false;
        }else{
            self.pop_up_message();
        }
    };
    self.close_message = function(){
        $('#message_wrapper').animate({top:0}, 500);
    };
    /** Cut short the currently showing message if others are queued */
    self.cut_short_message = function() {
        if(self.pop_up_list.length > 0) {
            clearTimeout(self.pop_up_timeout); //stop next_message from running
            self.pop_up_message();
        }
    };
    self.open_dialog = function(){
        var buttons = [];
        dialog.open({
            'title': gettext('Notifications'), 
            'template': '#notification_table_holder_tmpl',
            'data': {},
            'buttons': buttons
        });
        var table_data = [];
        for(index in self.message_store.messages){
            msg = self.message_store.messages[index];
            var msg_display = (msg.title != '' && msg.title != undefined) ? msg.title + ' - ' + msg.message : msg.message
            table_data.push([msg.type, msg.id, msg_display, msg.message_date])
        }
        
        self.message_data_table = $('#message_dialog_table').dataTable({
            "aaData": table_data,
            "aaSorting": [[ 3, "desc" ]],
            "bAutoWidth": false,
            "bPaginate": false,
            "sDom": 't',
            oLanguage: DATATABLES_LANG,
            "aoColumns": [
                { "bVisible": false, "fnRender":function(oObj){return oObj.aData[0];}},
                { "bVisible": false},
                { "bSortable": false, "fnRender":function(oObj){return $('#message_text_tmpl').tmpl({'value':oObj}).html()}},
                { "bSortable": true, "sType":'attr_date', "sClass":'message_date', "fnRender":function(oObj){var tmp = new Date(oObj.aData[3]); return '<div date="'+oObj.aData[3]+'">'+$.time_helper(tmp.getHours())+':'+$.time_helper(tmp.getMinutes())+'</div>';}}
            ]
        });
        /*** Set up tabs to filter messaging ***/
        $('.notification_dialog_tab').on('click', function() {
            $(this).siblings().removeClass('active');
            $(this).addClass('active');
            $('#message_dialog_table').parent().toggleClass($(this).attr('add_class'),true);
            $('#message_dialog_table').parent().toggleClass($(this).siblings().attr('add_class'),false);
            self.message_data_table.fnFilter($(this).attr('filter'), null, true);
        });
        /*** Opens error tab if we have errors, otherwise info ***/
        if (self.check_for_type('error') || self.check_for_type('warning')){
            $('.notification_dialog_tab:first').click();
        }else{
            $('.notification_dialog_tab:last').click();
        }
        self.unread_list = [];
        self.update_count_holders();
    }
    self.check_for_type = function(type){
        for(index in self.message_store.messages){
            if(self.message_store.messages[index].type == type){
                return true;
            }
        }
        return false;
    }
    self.previous_message = function() {
        if (current_message.previous_message !== undefined)
            current_message = current_message.previous_message;
        pop_up_message();
    }
    self.clear_messages = function(){
        self.message_store.messages = {};
    }
    self.update_count_holders = function(){
        var type_count_dict = {};
        for(var i = 0; i < self.unread_list.length; i++){
            var unread_message = self.message_store.messages[self.unread_list[i]];
            if(type_count_dict[unread_message.type] == undefined){
                type_count_dict[unread_message.type] = 1;
            }else{
                type_count_dict[unread_message.type]++;
            }
        }
        $('.jq_notification_count_holder').each(function(){
            var count_list = $(this).attr('data-notification-types').split(' ');
            var current_count = 0;
            for(var j = 0; j < count_list.length; j++){
                if(type_count_dict[count_list[j]]){
                    current_count += type_count_dict[count_list[j]];
                }
            }
            if($(this).hasClass('fading_count') && current_count == 0){
                $(this).html('').fadeOut();
                $(this).parent().removeClass("active");
            }else{
                $(this).html(current_count).fadeIn();
                $(this).parent().addClass("active");
            }
        });
    }
}