/////////////////////////////////////////////////////////////////////////////
// Code shared between Playlist Edit page and the Macro Pack Edit Screen page and the Pack Edit page.
/////////////////////////////////////////////////////////////////////////////

/**
 * Screen Play Order
 *
 * Helper for both Playlists and Macro Packs Screens
 * @pattern Revealing Module Pattern (@see http://blog.alexanderdickson.com/javascript-revealing-module-pattern)
 */

var spo = (function(){

    /**
     * Display the dialog box used to add or edit a pattern
     *
     * @param template_data
     * @param text
     * @param action
     * @param hms_settings
     */
    function pattern_dialog(template_data, text, action, hms_settings /* optional */){
        _dialog('#playlist_edit_add_pattern_tmpl', template_data, text, action, hms_settings);
    }

    function credit_offset_dialog(template_data, text, action, hms_settings /* optional */){
        _dialog('#credit_offset_edit_dialog_tmpl', template_data, text, action, hms_settings);
    }

    /**
     * Display the dialog box used to add or edit an automation
     *
     * @param template_data
     * @param text
     * @param action
     * @param hms_settings
     */
    function automation_dialog(template_data, text, action, hms_settings /* optional */){
		template_data.cues = ['cue', 'wait_for_input', 'sony_cue', 'sony_function'];
        _dialog('#add_automation_dialog_tmpl', template_data, text, action, hms_settings);
		
		if($._in('intermission', template_data.automation.type)) {
			setup_intermission(template_data.automation);
		}
    }
	
	function setup_intermission(automation){
		// Get useful data from the page we are on
		if(macro_pack_edit_page.device_uuid) {
			var device_id = macro_pack_edit_page.device_uuid;
			var autos = macro_pack_edit_page.automation[device_id];
		} 
        else if(playlist_edit_page.server_id) {
			var device_id = playlist_edit_page.server_id;
			var autos = playlist_edit_page.automation[device_id];
		} 
        else if(pack_edit_page.automation.aamlms) {
			var device_id = 'all';
			var autos = pack_edit_page.automation.aamlms;
		} 
        else {
			throw 'Intermissions should only come from macropack, pack, or playlist edit page';
        }

        // Attach playlist suggestion tip
        helpers.ajax_call({
			url: '/core/playlist/playlist',
            data: {
                request_data_items: ['title'],
                flatten: true,
                device_ids: device_id !== 'all' ? [device_id] : undefined
            },
			success_function: function(input){
				helpers.attach_suggestion_tip({
					dom: $('#automation_spl_uuid'),
					items: input.data,
					text_field: 'title',
					tip_params: {
						position: {
							at: 'top right',
							my: 'bottom left'
						}
					}
				});
			}
        });

        // Add automation options
        if(automation.name === 'Christie Intermission'){
            $('#automation_start, #automation_end').each(function(){
				var automations = [];
				var current = $(this).attr('data-current');
				$.each(autos || {}, function(k, v){
					automations.push({
						name: v.name,
						selected: (v.name === current)
					});
				});
				$('#christie_intermission_playlists_tmpl').tmpl2(automations, this);
            });
        }
    }
    
    function merge_device_automations(all_device_automations) {
        var seen = [];
        var unique_autos = {};
        $.each(all_device_automations, function(device_id, automations) {
            if($device_store.devices[device_id]){
                $.each(automations, function(id, automation) {
                    // Merge if name and type are the same
                    var uid = automation.type + automation.name;
                    if(!$._in(uid, seen)) {
                        automation['id'] = id;
                        unique_autos[uid] = automation;
                        unique_autos[uid].devices = [];
                        seen.push(uid);
                    }
                    // Add the device to the set of devices this automation is on
                    unique_autos[uid].devices.push({
                        uuid: device_id,
                        identifier: helpers.get_device_name(device_id)
                    });
                });
            }
        });
        // Sort the device lists
        $.each(unique_autos, function(id, automation) {
            automation.devices.sort_screens();
        });
        return unique_autos;
    }

    /**
     * Open and set-up a dialog box
     */
    function _dialog(template, template_data, text, action, hms_settings){
        var buttons = [{
            'text': gettext("Save"),
            'action': action
        }];

        dialog.open({
            'title': text,
            'buttons': buttons,
            hbtemplate: template,
            'data': template_data
        });

        $(".hms").each(function(i, dom){
            $(dom).hms(hms_settings);
        });
    }

    /**
     * Search the automation inside the array of automations indexed by device
     */
    function find_automation(automations_by_device, automation_id){
        var automation;
        $.each(automations_by_device, function(index, device_automations){
            if(device_automations[automation_id]){
                automation = device_automations[automation_id];
                automation.id = automation_id;
            }
        });
        //Create the attr so we never get an attr of undefined
        automation['type_specific'] = {}
        return automation;
    }

    /**
     * Validate and save automation dialog input
     *
     * @param target
     * @param automations
     * @param device_automation_dict
     * @param on_success
     */
    function save_automation_dialog_input(target, automations, device_automation_dict, on_success) {

        var dialog_input = _extract_automation_dialog_input();
        var automation_item = _get_automation_item(automations, target, dialog_input);
        var errors = _validate_automation_dialog_input(automation_item.type, target.duration_in_seconds, dialog_input);

        if (errors.length){
            _render_automation_dialog_errors(errors);
        }else{
            var type_specific = _extract_type_specific_data(automation_item, dialog_input, target);
            _save_automation_on_target(automation_item, dialog_input, type_specific, target, device_automation_dict);
            on_success();
        }
    }

    /**
     * Extracts type specific data out of automation_item and dialog_input
     */
    function _extract_type_specific_data(automation_item, dialog_input, target){
        var type_specific = {};

        // All cues that use offset in seconds
        if ($._in(automation_item.type, ['cue', 'volume', 'wait_for_input', 'qube', 'sony_cue', 'sony_function', 'intermission'])) {
            type_specific.offset_from = dialog_input.offset_select;
            type_specific.offset_in_seconds = dialog_input.offset_in_seconds;

            if (target.edit_rate[0] && target.edit_rate[1]) {
                type_specific.offset_in_frames = type_specific.offset_in_seconds * (target.edit_rate[0] / target.edit_rate[1]);
            }
        }

        // extract actions and triggers

        switch (automation_item.type) {
            case 'volume': 
                type_specific.parameter = parseInt(parseFloat(dialog_input.volume_parameter)*10);
                type_specific.action = automation_item.name;
                break;
            case 'trigger':
                type_specific.action = dialog_input.trigger_action;
                type_specific.trigger = automation_item.name;
                break;

            case 'gdc_start_cue':
                type_specific.action = dialog_input.gdc_start_cue_action;
                type_specific.delay_in_seconds = dialog_input.offset_in_seconds;
                break;

            case 'qube': //TODO - is this redundant? Can't find any automations of this type
                type_specific.action = automation_item.name;
                type_specific.wait_duration = 0;

                if(automation_item.name === 'wait for ext trigger') {
                    type_specific.action = dialog_input.action;
                    type_specific.trigger = type_specific.action;
                }

                if(automation_item.name === 'wait for duration'){
                    type_specific.wait_duration = dialog_input.wait_duration;
                }

                break;

            case 'sony_cue':
                type_specific.action = automation_item.id;
                break;

            case 'sony_function':
                type_specific.action = dialog_input.sony_function_id;
                break;

            case 'intermission':
                if (automation_item.name == 'Doremi Intermission'){
                    type_specific.rewind_in_seconds = dialog_input.restart_in_seconds;
                    type_specific.spl_uuid = dialog_input.spl_uuid;
                    type_specific.spl_title = dialog_input.spl_title;
                    type_specific.offset_from = 'start';
                }
                else if (automation_item.name == 'Christie Intermission'){
                    type_specific.restart_in_seconds = dialog_input.restart_in_seconds;
                    type_specific.spl_title = dialog_input.spl_title;
                    type_specific.start_automation = dialog_input.start_automation || "";
                    type_specific.end_automation = dialog_input.end_automation || "";
                }
                else{
                    type_specific.duration_in_seconds = dialog_input.duration_in_seconds;
                    type_specific.restart_in_seconds = dialog_input.restart_in_seconds;
                    type_specific.spl_uuid = dialog_input.spl_uuid;
                    type_specific.spl_title = dialog_input.spl_title;
                }
                break;
            default:
                type_specific.action = automation_item.name;
        }

        return type_specific;
    }

    /**
     * Extract the automation item, depending on the dialog_input
     */
    function _get_automation_item(automations, target, dialog_input){
        if (dialog_input.edit_index) {
            return target.automation[dialog_input.edit_index];
        }else{
            return find_automation(automations, dialog_input.new_id);
        }
    }

    /**
     * Attach the automation to the target
     */
    function _save_automation_on_target(automation_item, dialog_input, type_specific, target, device_automation_dict){

        var automation_object = {name: automation_item.name, type: automation_item.type, type_specific : type_specific};
        var new_automation = new PlaylistCompositionAutomation(automation_object, device_automation_dict);

        if (dialog_input.edit_index) {
            target.automation.splice(dialog_input.edit_index, 1);
        }

        target.automation.push(new_automation);
        target.sort_automation();
    }

    /**
     * Validates that the input of an automation dialog is valid according to the automation type
     */
    function _validate_automation_dialog_input(automation_type, event_duration_in_seconds, dialog_input){
        var errors = [];

        // validate event duration
        if(dialog_input.offset_in_seconds > event_duration_in_seconds && automation_type !== 'gdc_start_cue'){
            errors.push(gettext("The automations offset must be less than or equal to this events duration"));
        }

        if(dialog_input.restart_in_seconds > dialog_input.offset_in_seconds){
            errors.push(gettext("Rewind must be less than or equal to the offset."));
        }

        if(automation_type === 'gdc_start_cue' && dialog_input.offset_in_seconds > 99){
            errors.push(gettext("The automations blank time must be 99 seconds or less"));
        }

        if (automation_type === 'volume') {
            var volume_parameter = dialog_input.volume_parameter;
            if (!helpers.bounded_float(volume_parameter,0,10)){
                errors.push(gettext('The parameter must be between 0.0 and 10.0'));
            }
        }

        if(automation_type === 'intermission'){
            if(!dialog_input.spl_uuid){
                errors.push(gettext('There is no playlist selected'));
            }
        }

        return errors;
    }

    /**
     * Just render an array of errors inside the dialog
     * @param errors
     * @private
     */
    function _render_automation_dialog_errors(errors){
        $('#validation_error_tmpl').tmpl({'errors':errors}).appendTo($('.validation').empty());
    }

    /**
     * Extract all the data out of an automation dialog input
     */
    function _extract_automation_dialog_input(){
        return {
            new_id: $('#automation_id').val(),
            action: $("#automation_action").val(),
            volume_parameter: $('#automation_volume_parameter').val(),
            trigger_action: $('#automation_trigger_action').val(),
            gdc_start_cue_action : $('#automation_gdc_start_cue_action').val(),
            wait_duration: $("#automation_wait_duration").hms('retrieve'),
            offset_select: $('#automation_offset_select').val(),
            offset_in_seconds: $('#automation_offset').hms('retrieve'),
            edit_index: $('#edit_automation_index').val(),
            spl_uuid: $('#automation_spl_uuid').attr("data-item_uuid"),
            spl_title: $('#automation_spl_uuid').val(),
            duration_in_seconds: $('#automation_duration').hms("retrieve"),
            restart_in_seconds: $('#automation_restart').hms("retrieve"),
            start_automation: $('#automation_start').val(),
            end_automation: $('#automation_end').val(),
            sony_function_id: $('#sony_function_id').val()
        };
    }

    // public interfaces
    return {
        pattern_dialog: pattern_dialog,
        automation_dialog: automation_dialog,
        credit_offset_dialog: credit_offset_dialog,
        find_automation: find_automation,
        save_automation_dialog_input: save_automation_dialog_input,
        merge_device_automations: merge_device_automations
    };
})();
