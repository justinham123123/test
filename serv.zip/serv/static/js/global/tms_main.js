/*****************
 * INITIALISATION
 *****************/

var dialog, global_user_information, screenwriter_plus, core_only, invalid_license, screen_device_metadata, complex_device_metadata;
var hash_location = "";
var $document = $(document);
var license_tip_drawn = false;
var ftp_server_error_tip_drawn = false;
var browser_tab_initialised = false;

$document.ready(function() {
    $document.on('keydown', function(e) {
        if (e.which == $.ui.keyCode.ENTER) {
            $(e.target).trigger('enter');
        }
    });

	$playback_store.on('loaded', update_playback_device_status_bar);
	$projection_status_store.on('loaded', update_projection_device_status_bar);
    $playback_store.on('new_playlist', sync_playback_playlist_composition);
    $playback_store.on('loaded', update_screen_status_bar);

    //This is needed because we need to prevent some event handler attachments based on user rights.
    $(licensed_and_authenticated).on('loaded',attach_event_listeners);

    $.when(
        helpers.ajax_load('/static/html/pages/monitor.html', 'monitor_template_holder'),
        helpers.ajax_load('/static/html/pages/timeline.html', 'timeline_template_holder'),
        helpers.ajax_load('/static/html/pages/content.html', 'content_template_holder'),
        helpers.ajax_load('/static/html/pages/kdm.html', 'kdm_template_holder'),
        helpers.ajax_load('/static/html/pages/title.html', 'title_template_holder'),
        helpers.ajax_load('/static/html/pages/title_edit.html', 'title_edit_template_holder'),
        helpers.ajax_load('/static/html/pages/complex_config.html', 'complex_config_template_holder'),
        helpers.ajax_load('/static/html/pages/general_config.html', 'general_config_template_holder'),
        helpers.ajax_load('/static/html/pages/advanced_config.html', 'advanced_config_template_holder'),
        helpers.ajax_load('/static/html/pages/playlist.html', 'playlist_template_holder'),
        helpers.ajax_load('/static/html/pages/playlist_edit.html', 'playlist_edit_template_holder'),
        helpers.ajax_load('/static/html/pages/template.html', 'template_template_holder'),
        helpers.ajax_load('/static/html/pages/template_edit.html', 'template_edit_template_holder'),
        helpers.ajax_load('/static/html/pages/transfer.html', 'transfer_template_holder'),
        helpers.ajax_load('/static/html/pages/schedule.html', 'schedule_template_holder'),
        helpers.ajax_load('/static/html/pages/pos.html', 'pos_template_holder'),
        helpers.ajax_load('/static/html/pages/reports_devices.html', 'report_template_holder'),
        helpers.ajax_load('/static/html/pages/reports_playback.html', 'report_playback_holder'),
        helpers.ajax_load('/static/html/pages/reports_audit.html', 'report_audit_holder'),
        helpers.ajax_load('/static/html/pages/pack.html', 'pack_template_holder'),
        helpers.ajax_load('/static/html/pages/pack_edit.html', 'pack_edit_template_holder'),
        helpers.ajax_load('/static/html/pages/macro_pack.html', 'macro_pack_template_holder'),
        helpers.ajax_load('/static/html/pages/messaging.html', 'messaging_template_holder'),
        helpers.ajax_load('/static/html/pages/macro_pack_edit.html', 'macro_pack_edit_template_holder'),
        helpers.ajax_load('/static/html/pages/notification.html', 'notification_template_holder'),
        helpers.ajax_load('/static/html/pages/license_agreement.html', 'license_agreement_template_holder')
    ).done(templates_ready);

    dialog = new AAMDialog('#dialog', '#fancybox_opener');
});

function attach_menu_listeners(){

    $('#header_right_menu_language').on('click', function() {
        dialog.open({
            'title': gettext('Select Language'),
            hbtemplate: '#global_chose_language_tmpl',
            'data':{'languages':['de','en','es','fr','it','ja','pt_BR','tr','zh_CN', 'ru', 'ko', 'uk']},
            'width':250,
            'height':50
        });
        $('.jq_flag').on('click',function(){
            window.location.replace("/set_language?lang_code="+$(this).attr('lang_code'));
        });
    });

    $('#header_right_menu_license').on('click', function(){

        var a = helpers.ajax_call({
            url:'/core/get_version'
        });

        var b = helpers.ajax_call({
            url:'/get_license'
        });

        $.when(a, b).done(function(version_info, license_info){
            var version_info = version_info[0]['data'];
            var license_info = license_info[0];
            var version_string = version_info.string;
            var version_stamp = version_info.stamp != undefined ? version_info.stamp.toString() : "" ;
            var licensed_features = [];
            if (jQuery.inArray('tms_general_license', license_info["license"].licensed) >= 0){
               licensed_features.push(gettext("General"));
            }
            if (jQuery.inArray('tms_pos_license', license_info["license"].licensed) >= 0){
               licensed_features.push("POS");
            }
            if (jQuery.inArray('tms_camera_license', license_info["license"].licensed) >= 0){
               licensed_features.push(gettext("Camera"));
            }
            if (jQuery.inArray('tms_smart_playlist_license', license_info["license"].licensed) >= 0){
               licensed_features.push(gettext("Smart Playlist"));
            }
            dialog.open({
                'title': gettext('Licence Information'),
                hbtemplate: '#license_info_tmpl',
                'width':300,
                'height':200,
                'data': {
                    'invalid' : $.isEmptyObject(license_info["license"]),
                    'license_string' : license_info["license"]["license_string"],
                    'screen_count' : license_info["license"].options != undefined ? license_info["license"].options.screen_count : -1,
                    'licensed_features': licensed_features,
                    'expires': moment.unix(license_info["license"].expiry).format('ddd, DD MMM YYYY HH:mm:ss z'),
                    'type': license_info["license"].product == "scr" ? gettext("Screenwriter") : license_info["license"].product == "scr+"? gettext("Screenwriter Plus"): gettext('Core'),
                    'tokens' : license_info["tokens"],
                    'version': version_string,
                    'version_stamp': version_stamp,
                }
            });
            $('#license_update_btn').button().click(function() {
                var license_string = $('#license_update_input').val();
                if (license_string) {
                    helpers.ajax_call({
                        url:'/save_license',
                        data: {
                            license: license_string
                        },
                    }).done(function(input) {
                        if(input.messages[0].type == "error"){
                            $('#license_update_feedback').show().text(input.messages[0].message);
                        }
                        else{
                            //Reload the page to get all the new vars loaded from the backend
                            window.location.reload();
                        }
                    });
                }
            });
        });
    });

    $('#header_right_menu_legend').on('click', function() {
        dialog.open({
            'title': gettext('Legend'),
            hbtemplate: '#legend_tmpl',
            'width':400
        });

        $('#legend_tabs .legend_tab').click(function(){
            $('#legend_tabs .legend_tab.selected').removeClass("selected");
            var target = "#" + $(this).addClass("selected").attr("data-target");
            $(target).tmpl2(content_kind_reference, '#legend_body');
        });
        $('#legend_tabs .legend_tab:first-child').click();
    });

    $('#header_right_menu_logout').on('click', function() {
        window.location = '/logout_user';
    });

    $('#header_right_menu_restart').on('click', function() {
        if(confirm(gettext("Are you sure? Active transfers to and from the LMS will fail."))){
            notification.info_msg(gettext('Restarting')+"...",gettext("Restart"));
            helpers.ajax_call({
                url: "/core/restart",
                success_function: function(input){
                    if(input.data.success == true){
                        window.location = '/logout_user';
                    }
                }
            });
        }
    });
}

function attach_event_listeners() {
    $(window).on('keyup',function(e){if (e.ctrlKey && e.keyCode == 96){$('body').toggleClass('show_screen_types');}});
    if(!core_only){
        $('#screen_status_bar').on('click','.jq_screen_status_bar',function(){
            var $this = $(this);
            var device_id = $this.find('.jq_playback_state').attr('screen_device_id');
            if (device_id != undefined) {
                if(!g_prevent_navigation || confirm("There are unsaved changes on this page.\n Are you sure you want to leave?")){
                    g_prevent_navigation = false;
                    dialog.close(); // close any open dialogs
                    monitor_page.open('large',device_id);
                }
            }
        });
    }

    // if we resize the window then the pos overview gets hidden and the tip doesnt know where to go
    $("#main_section").resize(function(e){
        if( $("#main_section").width() < 1150){
            $(".jq_pos_sync_tip_wrapper").hide();
        }else{
            $(".jq_pos_sync_tip_wrapper").show();
        }
    });
    if( helpers.is_allowed('tms_aam_only') ){
        $('#open_console').on('click', function() {
            var toggled = !$("#console").is(":visible");
            $("#console").slideToggle("fast");
            if( toggled ){
                poll_system_stats();
            }
        });
    }else{
        $('#open_console').hide();
    }
}

function poll_system_stats(){
    helpers.ajax_call({
        url:'/tms/system_stats',
        success_function:function(input){
            if(input.api_info[0]) input.api_info.title = 'Slow API calls (s)';
            if(input.api_size_info[0]) input.api_size_info.title = 'Heavy API calls (MB)';
            $('#console_tmpl').tmpl2(input, '#console');
            $('#console .console_tip').qtip({content: {text: false}, style: {classes: 'qtip-dark'}});
            $('#console .console_exception').on("click", function(){
                $(this).next(".traceback").toggle();
            });
        }
    });
}

function update_display_time() {
    var now_time = helpers.core_now();
    var mom = moment(now_time);
    $('#header_clock').html(days[now_time.getDay()] + ', ' + months[now_time.getMonth()] + ' ' + mom.format("DD HH:mm:ss"));
}

function update_pos_mapping_overview(){

    // if we have mapping info and POS is enabled we show the div
    if(!$.isEmptyObject($complex_status.pos.mapping) && $complex_status.pos.enabled == true ){

        // init
        $("#pos_overview").css("display","inline-block");
        var mappings = $complex_status.pos.mapping;
        var this_week = $('#pos_overview_this_week');
        var next_week = $('#pos_overview_next_week');

        // if we have info for the next 2 weeks
        if(mappings.this_week != undefined && mappings.next_week != undefined){

            // stick in the numbers
            $(this_week).find(".pos_overview_mapping").html(mappings.this_week.mapped + "/" + mappings.this_week.total);
            $(next_week).find(".pos_overview_mapping").html(mappings.next_week.mapped + "/" + mappings.next_week.total);

            // stick in the week numbers
            $(this_week).find(".pos_overview_week_number").html(mappings.this_week.week_number);
            $(next_week).find(".pos_overview_week_number").html(mappings.next_week.week_number);

            // green = fully mapped, red = not fully mapped
            if(mappings.this_week.mapped == mappings.this_week.total){
                $(this_week).addClass("pos_overview_mapped").removeClass("pos_overview_unmapped").attr("week_number", mappings.this_week.week_number);
            }
            else{
                $(this_week).addClass("pos_overview_unmapped").removeClass("pos_overview_mapped").attr("week_number", mappings.this_week.week_number);
            }
            if(mappings.next_week.mapped == mappings.next_week.total){
                $(next_week).addClass("pos_overview_mapped").removeClass("pos_overview_unmapped").attr("week_number", mappings.next_week.week_number);
            }
            else{
                $(next_week).addClass("pos_overview_unmapped").removeClass("pos_overview_mapped").attr("week_number", mappings.next_week.week_number);
            }

        // otherwise we're still trying to get it
        }
        else{
            $(this_week).find(".pos_overview_mapping").html(gettext("Loading")+"...");
            $(next_week).find(".pos_overview_mapping").html(gettext("Loading")+"...");
        }

        // check to see if any POS devices are still syncing and display gif if they are
        pos_devices_syncing = $complex_status.pos.syncing;
        var syncing = false;
        for( device_uuid in pos_devices_syncing){
            if(pos_devices_syncing[device_uuid] == true){
                syncing = true;
                break;
            }
        }

        // resync acknowledgment
        if(!$.isEmptyObject($complex_status.pos.latest_resync) && $complex_status.pos.latest_resync.success){
            if($(".jq_pos_sync_tip_wrapper").length == 0 || $(".jq_pos_sync_tip_wrapper .resync_timestamp").html() != $complex_status.pos.latest_resync.time_string ){
                destroy_pos_sync_tip();
                create_pos_sync_tip();
            }
        }
        else if($complex_status.pos.latest_resync.success == false && ( !$('#pos_resync_status_dialog_wrapper').is(':visible')) || $(".jq_pos_sync_tip_wrapper .resync_timestamp").html() != $complex_status.pos.latest_resync.time_string ){
            create_pos_sync_tip();
        }
        else if($.isEmptyObject($complex_status.pos.latest_resync) && $(".jq_pos_sync_tip_wrapper").length != 0){
            destroy_pos_sync_tip();
        }

        // Show error if most recent sync has failed
        if(syncing){
            $(".pos_overview_week").css("opacity","0.2");
            $("#pos_overview_sync").attr("title", gettext("Syncing with POS Feed")).addClass("syncing").removeClass("error").show();
        }
        else if($complex_status.pos.sync_error){
            $(".pos_overview_week").css("opacity","0.2");
            $("#pos_overview_sync").attr("title", $complex_status.pos.sync_error).addClass("error").removeClass("syncing").show();
        }
        else{
            $("#pos_overview_sync").hide();
            $(".pos_overview_week").css("opacity","1").removeClass('syncing').removeClass('error');
        }

    }
    else{
        $("#pos_overview").hide();
        destroy_pos_sync_tip();
    }

    setTimeout(update_pos_mapping_overview, 2500);
}

function update_kdm_email_status(){
    if ($complex_status.kdm_email_enabled == true && $complex_status.kdm_email_status != null){
        if ($complex_status.kdm_email_status == true){
            $("#kdm_email_status").removeClass('kdm_email_error kdm_email_disabled dark').addClass("kdm_email_ok");
            $("#kdm_email_status").attr('title', gettext('KDM Email account connected'));
        }
        else{
            $("#kdm_email_status").removeClass('kdm_email_ok kdm_email_disabled dark').addClass("kdm_email_error");
            $("#kdm_email_status").attr('title', gettext('KDM Email account not connected'));
        }
    }
    else{
        $("#kdm_email_status").removeClass('kdm_email_ok kdm_email_error').addClass("kdm_email_disabled dark");
        $("#kdm_email_status").attr('title', $complex_status.kdm_email_enabled ? gettext('KDM Email enabled') : gettext('KDM Email disabled'));
    }
    setTimeout(update_kdm_email_status, 2500);
}

function templates_ready() {
    s2s = new Site2SiteMessaging();
    notification = new Notification(); //Required before 'ajax_call' function can be used.



    var user_info = helpers.ajax_call({
        url:'/get_user_information',
        success_function:function(input){
            global_user_information = input;
            screenwriter_plus = input.license_type == "scr+" ? true : false;
            core_only = input.license_type == "scr-" ? true : false;
            invalid_license = input.invalid_license;
            $('#logged_in_user_name').html(input.username);
            for (var i=0; i< input.licensed_and_authenticated.length; i++) {
                licensed_and_authenticated[input.licensed_and_authenticated[i]] = true;
            }
            if( invalid_license ){
                notification.error_msg(input.invalid_license_reason, gettext("Invalid License"));
            }
            $(licensed_and_authenticated).trigger('loaded');
        }
    });

    var device_info = helpers.ajax_call({
        url:'/core/device_metadata',
        success_function:function(input){
            screen_device_metadata = input.data.screen_device_metadata;
            complex_device_metadata = input.data.complex_device_metadata;
        }
    });
    $.when(user_info, device_info).done(user_and_device_info_ready);
}

function user_and_device_info_ready(){
    $('#mini_menu_tmpl').tmpl2({
		show_status: !core_only,
		show_messages: !core_only && (global_user_information.enabled.live_chat_enabled || global_user_information.enabled.mail_enabled)
	}, '#mini_menu');

    helpers.attach_tip_menu({
        dom: '#header_right_menu_button',
        tmpl: '#menu_tmpl',
        tmpl_data: lang,
        classes: 'qtip-dark qtip-tms-dark',
        render: function(){
            attach_menu_listeners();
        }
    });

    $('.pos_overview_week').on("click",function(){
        if( $complex_status.pos["enabled"] == true ){
            var message = gettext("There are unsaved changes on this page.\n Are you sure you want to leave?");
            if(!g_prevent_navigation || confirm(message)){
                g_prevent_navigation = false;
                history.pushState(null, null, '#pos_page');
                pos_page.open($(this).attr("week_number"));
            }
        }
    });

    $('#kdm_email_status').on("click",function(){
        dialog.open({
            'title': gettext('KDM Email History'),
            hbtemplate: '#kdm_email_history_tmpl',
			data: $complex_status.kdm_email_history
        });
    });
    create_schedule_sync_tip();
    update_schedule_sync_tip(true);
    setInterval(update_schedule_sync_tip, 1066);

    $.when(
        sync_complex_infos(true),
        sync_device_infos(true),
        sync_complex_status(true),
        sync_action_store(true),
        load_automation_information()
    ).done(page_ready);

    setup_chat_status();
}

function load_automation_information() {
    return helpers.ajax_call({url:'/tms/get_automation_configuration', success_function:_update_automation_configuration});
}
function _update_automation_configuration(input) {
    AUTOMATION_CONFIGURATION = input;
}

/* Chrome fires an extra popstate on the window load
 * To ignore it we have to bind a timeout after the window load event */
$(window).on('load', function() {
    setTimeout(function() {
        $(window).on('popstate', refresh_display);
    }, 1);
});
/*
 * IE10 is a piece of shit and it stops firing the popstate event after the hashchange event.
 * So we try to detect if it is IE10 and make IE10 happy before sending a mailbomb to Redmond. Microsoft, why do you keep removing already working 
 * and consistent functionality????!!!!!!
 */
$(window).on('load', function() {
    setTimeout(function() {
        $(window).on('hashchange', function(){
            if (!!window.MSStream){
                refresh_display();
            }
        });
    }, 1);
});

function page_ready(){
    g_current_hash = window.location.hash;
    g_page_ready = true;
    build_main_nav();

    $('#loading_device').fadeOut(300, 'linear');

    helpers.ajax_call({
        url:'/core/get_time',
        success_function:function(input){
            $complex_status.core_time = input.data.time*1000;
            $complex_status.core_time_zone_offset = -input.data.timezone_offset_seconds*1000;
            $complex_status.browser_time_ref = Date.parse(new Date());
            $complex_status.browser_time_zone_offset = (new Date()).getTimezoneOffset()*60*1000;
            setInterval(update_display_time, 300);
			$complex_status.trigger('time_loaded');
        }
    });
    if(helpers.is_allowed('tms_pos_info') && !core_only){
        update_pos_mapping_overview();
    }
    else{
        $('#pos_overview').remove();
        destroy_pos_sync_tip();
    }

    // moment.js date/time strings can be translated by passing the language shortcode
    // we need to get this from the cookie so that it's not global
    moment.locale(helpers.get_cookie('serv_language'));

    refresh_display();

    update_kdm_email_status();
    var cookie_color = $.cookie('read', 'color_on');
    if(cookie_color == "true"){
        $('#color_toggle_btn').addClass("toggled");
        $('#main_section').addClass("color_on");
        $('#boxAT8').addClass('color_on');
    }

    $('#color_toggle_btn').click(function(){
        var btn = $(this);
        btn.toggleClass("toggled");
        var color_on = btn.hasClass("toggled");
        $.cookie('write', 'color_on', color_on, 5000);
        $('#main_section').toggleClass("color_on", color_on);
        $('#boxAT8').toggleClass('color_on', color_on);
    });

}



function build_main_nav() {
    var item, nav_item, nav_dom;
    //construct navigation structure
    g_nav_structure = {};

    if (helpers.is_allowed('tms_base_info') && !core_only) {
        g_nav_structure['monitor'] =  {
            'header': gettext('Screen'),
            'href': '#monitor_page',
            'sub_items': {
                'small': {
                    'header': gettext('Overview'),
                    'href': '#monitor_page#small'
                },
                'medium': {
                    'header': gettext('Detailed'),
                    'href': '#monitor_page#medium'
                },
                'large': {
                    'header': gettext('Playback'),
                    'href': '#monitor_page#large'
                },
                'timeline': {
                    'header': gettext('Timeline'),
                    'href': '#monitor_page#timeline'
                }
            }
        };
    }
    if (helpers.is_allowed('tms_base_info') && !core_only) {
        g_nav_structure['content'] = {
            'header': gettext('Content'),
            'href': '#content_page',
            'sub_items': {
                'content': {
                    'header': gettext('Content'),
                    'href': '#content_page'
                },
                'playlists': {
                    'header': gettext('Playlists'),
                    'href': '#playlist_page'
                },
                'kdms': {
                    'header': gettext('Keys'),
                    'href': '#kdm_page'
                }
            }
        };
    }
    if (helpers.is_allowed(['tms_base_info','tms_templating_info']) && !core_only) {
        g_nav_structure['content']['sub_items']['title'] = {
           'header': gettext('Titles'),
           'href': '#title_page'
        };
    }

    if (helpers.is_allowed('tms_base_info') && !core_only) {
        g_nav_structure['content']['sub_items']['pack'] =  {
            'header': gettext('Packs'),
            'href': '#pack_page'
        };
        g_nav_structure['content']['sub_items']['transfers'] =  {
            'header': gettext('Transfer Status'),
            'href': '#transfer_page'
        };
    }

    if (helpers.is_allowed('tms_base_info') && !core_only) {
        g_nav_structure['schedule'] = {
            'header': gettext('Schedule'),
            'href': '#schedule_page',
            'sub_items': {
                'schedule': {
                    'header': gettext('Schedule'),
                    'href': '#schedule_page'
                }
            }
        };
        if (helpers.is_allowed(['tms_pos_info']) && $complex_status.pos["enabled"] == true && !core_only){
            g_nav_structure['schedule']['sub_items']['pos'] =  {
                'header': gettext('POS'),
                'href': '#pos_page'
            };
        }
    }
    if (helpers.is_allowed('tms_base_info') && !core_only) {
        g_nav_structure['report'] = {
            'header': gettext('Reports'),
            'href': '#report_devices_page',
            'sub_items': {
                'devices': {
                    'header': gettext('Devices'),
                    'href': '#report_devices_page'
                }
            }
        };
        if(screenwriter_plus || helpers.is_allowed('tms_aam_only')){
            g_nav_structure['report']['sub_items']['playback'] ={
                'header': gettext('Playback'),
                'href': '#report_playback_page'
            };
        }
        if(global_user_information['enabled']['audit_log']){
            g_nav_structure['report']['sub_items']['audit'] = {
                'header': gettext('Audit'),
                'href': '#report_audit_page'
            };
        }
    }
    if (helpers.is_allowed(['tms_core_only_info'])) {
        g_nav_structure['config'] =  {
            'header': gettext('Configuration'),
            'href': '#complex_config_page',
            'sub_items': {
                'complex': {
                    'header': gettext('Complex'),
                    'href': '#complex_config_page'
                }
            }
        };
        if (helpers.is_allowed('tms_configuration_info')) {
            g_nav_structure['config']['sub_items']['general'] = {
                'header': gettext('General'),
                'href': '#general_config_page'
            };
        }
        if (!invalid_license) {
            if( !core_only ){
                g_nav_structure['config']['sub_items']['macro_pack'] = {
                    'header': gettext('Macro Pack'),
                    'href': '#macro_pack_page'
                };
            }
            if( screenwriter_plus && $complex_status.allow_auto){
                g_nav_structure['config']['sub_items']['template'] =  {
                    'header': gettext('Templates'),
                    'href': '#template_page'
                };
            }
        }
        if (helpers.is_allowed('tms_aam_only')) {
            g_nav_structure['config']['sub_items']['advanced'] = {
                'header': gettext('Advanced'),
                'href': '#advanced_config_page'
            };
        }
    }

    //draw the top menu headers
    $('#main_nav_bar').empty();
    $.each(g_nav_structure, function(i, nav_item)
    {
        nav_item.id = 'main_nav_%item'.replace('%item', i);
        nav_dom = $('#main_nav_tmpl').tmpl2(nav_item);
        $('#main_nav_bar').append(nav_dom);
    });
}

function nav_select(main, sub) {
    $('#main_nav_bar .nav_item').removeClass('selected');
    $('#main_nav_%page'.replace('%page', main)).addClass('selected');
    $('#sub_nav_bar').empty();
    if ( typeof g_nav_structure[main].sub_items == 'undefined') {
        $('#sub_nav_bar').css('visibility','hidden');
    } else {
        $('#sub_nav_bar').css('visibility','visible');
    }
    $.each(g_nav_structure[main].sub_items, function (index, nav_item) {
        nav_item.id = 'sub_nav_%item'.replace('%item', index);
		nav_item.href = nav_item.href || '#';
        $('#sub_nav_bar')
			.append($('#sub_nav_tmpl').tmpl2({nav_item: nav_item, selected:sub == index}));
    });
}

function refresh_display() {
    if (!g_page_ready || check_navigation()) {
        if (window.location.hash !== '') {
            var hash = window.location.hash.substring(1);
            var hash = hash.split('#');
            var function_name = hash.splice(0,1);
            if (hash.length == 0) {
                eval(function_name+'.open()');
            }
            else {
                eval(function_name+'.open("'+hash.join('","')+'")');
            }
        } else {
            if(core_only){
                complex_config_page.open();
            }else{
                monitor_page.open();
            }
        }
        g_current_hash = window.location.hash;
    } else {
        history.pushState(null, null, g_current_hash);
    }
}

function check_navigation() {
    if (!g_prevent_navigation || confirm(NAVIGATION_CHECK_TEXT)) {
        g_prevent_navigation = false;
        return true;
    } else {
        return false;
    }
}

window.onbeforeunload = function() {
    if (g_prevent_navigation) {
        return NAVIGATION_CHECK_TEXT;
    }
};



/*****************
 * BACKGROUND TASKS
 *****************/

function _check_actions_pending() {
    var pending = false, show = false;
    for (var action_id in $action_store.actions) {
        pending = true;
        if ($action_store.actions[action_id].show_pending) {
            show = true;
            break;
        }
    }
    return {pending: pending, show: show};
}

function setup_chat_status(){
    $complex_status.chat.events.on('updated', update_chat_status);
    $complex_status.chat.sync();
}

function update_chat_status(e, data) {
    $complex_status.chat.status = data['data']['status'];
    var count = Object.keys(data['data']['unread']).length;
    $('#message_count').html(count).toggle(count > 0);
    $('#s2s_btn').toggleClass('toggled', count > 0);
}


function sync_action_store() {
    var actions_pending = _check_actions_pending();

    if (actions_pending.show) {
        $('body').toggleClass('mouse_waiting', true);
    } else {
        $('body').toggleClass('mouse_waiting', false);
    }

    if (actions_pending.pending) {
        return helpers.ajax_call({
            url:'/core/monitoring/messages',
            data:{
                action_ids:$.keys($action_store.actions)
            },
            success_function:update_action_store,
            complete_function:function(){
                setTimeout(sync_action_store,$action_store.update_interval);
            }
        });
    } else {
        setTimeout(sync_action_store,$action_store.update_interval);
    }
}

/*We loop through the actions, update the elements with the given class, and remove it from the store...*/
function update_action_store(input) {
	//actions
	var manipulate_me;
    for (var action_id in input.data) {
        var message = input.data[action_id];
        var notify = $.val_or_default($action_store.actions[action_id].notify, true);

        if(notify){
            if(message.success){
                notification.completed_msg(message.message, '', $action_store.actions[action_id].message_id);
            }else{
                notification.error_msg(message.message, '', $action_store.actions[action_id].message_id);
            }
            //Bring this to attention immediately (replacing waiting-for-action type messages)
            notification.cut_short_message();
        }

        if($action_store.actions[action_id].current_class){
            manipulate_me = $('[action_id=%action_id]'.replace('%action_id', action_id));
            manipulate_me.removeClass($action_store.actions[action_id].current_class);
            manipulate_me.attr('title', message.message);
            if(message.success){
                manipulate_me.addClass($action_store.actions[action_id].success_class);
            }else{
                manipulate_me.addClass($action_store.actions[action_id].failure_class);
            }
        }
        if ($action_store.actions[action_id].callback != undefined) {
            $action_store.actions[action_id].callback(action_id, message.success, message.message);
        }
        if ($action_store.actions[action_id].deferred != undefined) {
            $action_store.actions[action_id].deferred.resolve();
        }
        delete $action_store.actions[action_id];
    }

    //Check if we cleared up all the outstanding actions
    if (!_check_actions_pending().show) {
        $('body').toggleClass('mouse_waiting', false);
    }
}

function sync_complex_status(repeat) {
	return helpers.ajax_call({
        url: '/core/complex/',
        success_function: update_complex_status,
        repeat: repeat,
        interval: $complex_status.update_interval
    });
}

function update_complex_status(input) {

    update_audio_status(input.data);
    update_projection_status(input.data);
    update_playback_status(input.data);

    for (device_id in input['data']['status']){
        var status = input['data']['status'][device_id];
        var device = $device_store.devices[device_id];
        if(device != undefined){
            if(status){
                device.update_status(status);
            }
            else if(!device.enabled){
                device.update_status({});
            }
            if (device && status != undefined && status.current_time) {
                device.time_ref = status.last_updated * 1000;
                device.time = status.current_time * 1000;
            }
        }
    }

    if(input.data.pos){
        $complex_status.pos = input.data.pos;
    }

    if(input.data.sched_sync != undefined){
        $complex_status.sched_sync = input.data.sched_sync;
    }

    if(input.data.sched_sync_stamp != undefined){
        if($complex_status.sched_sync_stamp !== input.data.sched_sync_stamp) {
            // Force update since sched sync has just run
            update_schedule_sync_tip(true);
        }
        $complex_status.sched_sync_stamp = input.data.sched_sync_stamp;
    }

    if(input.data['ftp_server_running'] != undefined){
        if(!input.data['ftp_server_running']){
            if(!ftp_server_error_tip_drawn){
                create_ftp_server_warning_tip();
            }
        }
        else if(ftp_server_error_tip_drawn){
            destroy_ftp_server_warning_tip();
            ftp_server_error_tip_drawn = false;
        }
    }
}

function sync_device_infos(repeat){
    return helpers.ajax_call({url:'/core/device_infos/', success_function: update_device_infos, repeat:repeat, interval:$device_store.update_interval});
}

function update_device_infos(input){
    //devices
    var device_id, device, need_mode_sync;
    need_mode_sync = false;
    for (device_id in input.data.devices) {
        if ($device_store.devices[device_id] === undefined) {
            device = new Device(input.data.devices[device_id]);
            $device_store.devices[device_id] = device;
            $device_store.trigger('change');
            need_mode_sync = true;
        }
        else {
            if ($device_store.devices[device_id].type != input.data.devices[device_id].type) need_mode_sync = true;
            $device_store.devices[device_id].update(input.data.devices[device_id]);
        }
    }

    //get rid of outdated devices.
    //Also check for patterns and device-specific features, which we have to accomodate on the UI.
    var sony_detected = false;
    var doremi_detected = false;
    for (device_id in $device_store.devices) {
        if (typeof input.data.devices[device_id] == 'undefined') {
            delete $device_store.devices[device_id];
            devices_changed = true;
            $device_store.trigger('change');
        }else{
            var dtype = $device_store.devices[device_id].type.toLowerCase();
            switch(dtype) {
            case 'sony':
                sony_detected = true;
                break;
            case 'doremi':
                doremi_detected = true;
                break;
            }
        }
    }
    if(doremi_detected){
        $complex_status.patterns_enabled = true;
        $complex_status.doremi_features = true;
    }else if(sony_detected){
        $complex_status.patterns_enabled = true;
        $complex_status.doremi_features = false;
    }else{
        $complex_status.patterns_enabled = false;
        $complex_status.doremi_features = false;
    }

    //now load screens
    var screen_uuid, screen_data, screen;
    for (screen_uuid in input.data.screens) {
        screen = new Screen(input.data.screens[screen_uuid]);
        $device_store.screens[screen_uuid] = screen;
    }

    //clean up deleted
    for (screen_uuid in $device_store.screens) {
        if (typeof input.data.screens[screen_uuid] == 'undefined') {
            delete $device_store.screens[screen_uuid];
        }
    }

    //If there are new devices or changed types then re-grab the supported modes for them (deferring the loaded so no page fubars)
    if (need_mode_sync) {
        sync_supported_modes().done(function() {
            $device_store.loaded = true;
            $device_store.trigger('loaded');
        });
    } else {
        $device_store.loaded = true;
        $device_store.trigger('loaded');
    }
}

function sync_complex_infos(repeat){
    return helpers.ajax_call({url:'/core/complex_infos/', success_function: update_complex_infos, repeat:repeat, interval:$complex_status.static_info_update_interval});
}

function update_complex_infos(input){
    if (input.data.version){
        $complex_status.version = input.data.version;
        if( $complex_status.complex_name && $complex_status.complex_name != "Unknown Complex Name"){
            $('#title').html($complex_status.complex_name + " (" + $complex_status.version + ")");
        }else{
            $('#title').html("Screenwriter (" + $complex_status.version + ")");
        }
    }

    if (input.data.servers_purged > 0){
        notification.error_msg(gettext('Licensed screen count has been exceeded. Removing %s Server(s).').replace("%s",input.data.servers_purged.toString()));
    }

    $complex_status.complex_name = input.data.name;
    $('#header_complex_name').html($complex_status.complex_name);
    $complex_status.timezone = input.data.timezone;
    $complex_status.audio_lang = input.data.audio_lang;
    $complex_status.sub_lang = input.data.sub_lang;

    if (input.data.license_expiry)
        $complex_status.license_expiry = input.data.license_expiry;

    $complex_status.territories = input.data.territories;
    $complex_status.country_code = input.data.country_code;

    if(!license_tip_drawn)
        create_license_warning_tip();

    // License agreement
    if( !invalid_license ){
        if( !input.data.license_agreement_accepted && ["AAM Support", "AAM Admin"].indexOf(global_user_information.username) == -1){
            show_license_agreement(input.data.language);
        }
        else if (!input.data.password_change_reminder_displayed){
            show_password_reminder();
        }
    }

    if(input.data.allow_server_reboot != undefined)
        $complex_status.allow_server_reboot = input.data.allow_server_reboot;

    if(input.data.allow_sync_page != undefined)
        $complex_status.allow_sync_page = input.data.allow_sync_page;

    $complex_status.kdm_email_enabled = input.data.kdm_email_enabled;
    $complex_status.kdm_email_status = input.data.kdm_email_status;
    $complex_status.kdm_email_history = input.data.kdm_email_history;
    $complex_status.allow_auto = input.data.allow_auto;
    $complex_status.log_collection_only = input.data.log_collection_only;

    $complex_status.lamp_threshold_unit = input.data.lamp_threshold_unit;
    $complex_status.lamp_yellow_threshold = input.data.lamp_yellow_threshold;
    $complex_status.lamp_red_threshold = input.data.lamp_red_threshold;
    $complex_status.disk_yellow_threshold = input.data.disk_yellow_threshold;
    $complex_status.disk_red_threshold = input.data.disk_red_threshold;

}

function show_license_agreement(lang){
    if(!$("#license_agreement_wrapper").is(":visible")){
        var buttons = [];
        buttons.push({
            'text': gettext('Agree'),
            'action': function(){
                helpers.ajax_call({
                    url:'/tms/confirm_license_agreement',
                    success_function:function(){
                        dialog.close();
                    },
                    notify: false
                });
            }
        });
        dialog.open({
            'title': gettext('License Agreement'),
            hbtemplate: '#license_agreement_tmpl',
            'width':500,
            'height':500,
            'buttons':buttons
        });
    }
}

function show_password_reminder(){
    var buttons = [];

    buttons.push({
        'text': gettext('OK'),
        'action': function(){
            helpers.ajax_call({
                url:'/tms/acknowledge_password_reminder',
                success_function:function(){
                    dialog.close();
                },
                notify: false
            });
            window.location.hash = '#general_config_page#users';
        }
    });

    dialog.open({
        'title': gettext('Reminder'),
        hbtemplate: '#password_reminder_tmpl',
        'width':250,
        'height':100,
        'buttons':buttons,
        'close': function(){
            helpers.ajax_call({
                url:'/tms/acknowledge_password_reminder',
                notify: false
            });
        }
    });
}

function update_projection_status(input){
    for (var device_id in input.projection) {
        //update our playback store
        $projection_status_store.devices[device_id] = input.projection[device_id];
    }
    for (var device_id in $projection_status_store.devices) {
        if (typeof input.projection[device_id] == 'undefined') {
            delete $projection_status_store.devices[device_id];
        }
    }
    $projection_status_store.loaded = true;
    $projection_status_store.trigger('loaded');
}

function update_audio_status(input){
    input = input['audio'];
    for(var device_uuid in input){
        var changed = {};
        if($aux_status_store['audio'][device_uuid] == undefined){
            $aux_status_store['audio'][device_uuid] = $({});
        }
        for(var key in input[device_uuid]){
            if($aux_status_store['audio'][device_uuid][key] != input[device_uuid][key]){
                $aux_status_store['audio'][device_uuid][key] = input[device_uuid][key];
                changed[key] = true;
            }
        }
        if(!$.isEmptyObject(changed)){
            $aux_status_store['audio'][device_uuid].trigger('changed', changed);
        }
    }
}

function update_playback_status(input){
    var device_id, new_playlist;
    for (device_id in input.playback) {
        new_playlist = false;

        if ($playback_store.devices[device_id] === undefined) {
            //This is a new device
            $playback_store.devices[device_id] = {
                'playlist': undefined,
                'events': $({}),
                'sync_status': ''
            };
        }
        //Check for a new playlist
        if ($playback_store.devices[device_id].spl_uuid !== input.playback[device_id].spl_uuid) {
            new_playlist = true;
        }
        else if(input.playback[device_id].spl_uuid !== null && $playback_store.devices[device_id].playlist == undefined){
            new_playlist = true;
        }

        //update our playback store
        $.extend(true, $playback_store.devices[device_id], input.playback[device_id]);

        //now that the playback store has been updated, fire events for the significant changes identified above.
        if (new_playlist) {
            $playback_store.trigger('new_playlist', {'device_id': device_id, 'playlist_uuid': input.playback[device_id].spl_uuid});
        }
    }
    for (device_id in $playback_store.devices) {
        if (typeof input.playback[device_id] == 'undefined') {
            delete $playback_store.devices[device_id];
        }
    }
    $playback_store.loaded = true;
    $playback_store.trigger('loaded');
}

function sync_supported_modes() {
    var update_deferred = new $.Deferred();
    var update_supported_modes = function (input) {
        for(var device_id in input.data) {
            if($device_store.devices[device_id] !== undefined) {
                $device_store.devices[device_id].supported_modes = input.data[device_id];
            }
        }
        update_deferred.resolve();
    };
    helpers.ajax_call({
        url:'/core/playback/supported_modes',
        success_function:update_supported_modes
    });
    return update_deferred.promise();
}

function sync_playback_playlist_composition(event, args) {
    // Playlist ejected
    var cur_status = $playback_store.devices[args.device_id]['sync_status'];
    if(!args.playlist_uuid){
        $playback_store.devices[args.device_id].playlist = undefined;
        $playback_store.devices[args.device_id]['sync_status'] = gettext("No Playlist loaded");
        $playback_store.devices[args.device_id].events.trigger('playlist_updated');
    }
    // New playlist loaded
    else{
        if($device_store.devices[args.device_id] == undefined){
            $playback_store.devices[args.device_id]['sync_status'] = gettext("Syncing device information");
        }
        else if($device_store.devices[args.device_id].sync_active){
            $playback_store.devices[args.device_id]['sync_status'] = gettext("Syncing Playlists");
        }
        else{
            $playback_store.devices[args.device_id]['sync_status'] = gettext("Loading");
            helpers.ajax_call({
                url:'/tms/get_playlist_detailed',
                data: {
                    device_uuid: args.device_id,
                    playlist_uuid: args.playlist_uuid,
                    playback: true
                },
                complete_variables: {
                    device_id: args.device_id,
                    playlist_uuid: args.playlist_uuid
                },
                success_function: update_playback_playlist_composition
            });
        }
        if(cur_status != $playback_store.devices[args.device_id]['sync_status']){
            $playback_store.devices[args.device_id].events.trigger('playlist_updated');
        }
    }
}

function update_playback_playlist_composition(input, complete_variables) {
    var playlist = input.data;
    if ($playback_store.devices[complete_variables.device_id] != undefined && playlist != undefined && !$.isEmptyObject(playlist)) {
        if(playlist.error_messages == undefined){
            $playback_store.devices[complete_variables.device_id].playlist = new Playlist(playlist);
            $playback_store.devices[complete_variables.device_id].playlist.calculate_start_times();
            $playback_store.devices[complete_variables.device_id].events.trigger('playlist_updated');
        }
        else{
            for(var i=0; i < playlist.error_messages.length; i++){
                notification.error_msg(playlist.error_messages[i], 'Sync Playlist');
            }
        }
    }
}

/*******************
 * GLOBAL GUI STUFF
 *******************/

function update_screen_status_bar() {
    var index, screen_dom, previous_dom;

    var screens = helpers.get_screen_list();
    //Loop through the screens to make sure the status bar is up to date
    for (var i=0; i< screens.length; i++) {
        var screen = screens[i];
        screen_dom = $('.jq_screen_status_bar[screen_uuid="%screen_uuid"]'.replace('%screen_uuid', screen.uuid));

        if (screen_dom.length > 0) {
            if($(screen_dom).find(".screen_number").text() != screen.identifier){
                $(screen_dom).find(".screen_number").text(screen.identifier);
            }
            if ($(screen_dom).find('.screen_type').text() != screen.screen_type) {
                $(screen_dom).find('.screen_type').text(screen.screen_type);
            }
        }
        else {
            //If the screen doesn't exist on the status bar yet, create it and then insert it at the correct position
            screen_dom = $('#screen_status_bar_screen_tmpl').tmpl2(screen);
            if(!previous_dom){
                $('#screen_status_bar').prepend(screen_dom);
            }
            else{
                screen_dom.insertAfter(previous_dom);
            }
            create_status_bar_tip(screen);
        }
        var has_error = false;
        //if any device has an error, so does the screen
        for(var device_id in screen.devices){
            if(screen.devices[device_id] != undefined && screen.devices[device_id].status == 'error'){
                has_error = true;
                break;
            }
        }
		if(has_error){
			if (!screen_dom.hasClass('error')) {
				screen_dom.addClass('error');
			}
		}
        else{
			screen_dom.removeClass('error');
		}
        previous_dom = screen_dom;
    }

    //now clean up what was removed
    var screens_dom = $('.jq_screen_status_bar');
    for(var i = 0; i < screens_dom.length; i++){
        if (!$device_store.screens[$(screens_dom[i]).attr('screen_uuid')]){
            $('.jq_screen_status_bar[screen_uuid="%screen_uuid"]'.replace('%screen_uuid',$(screens_dom[i]).attr('screen_uuid'))).remove();
        }
    }
}

function _get_tip_info(screen) {
	$.each(screen.devices, function(k, device) {
		device.status_tip_info = get_status_info(device);
		if(device.enabled && !device.sync_active && !device.custom) {
			if(device.category === 'projector' && device.status_info) {
				device.status_tip_info.device_msg = device.status_info.state_title;
			}
			if(device.category === 'sms' && $playback_store.devices[device.id].playback_state === 'projector_disconnected') {
				device.status_tip_info.device_msg = gettext('Projector is offline or disconnected');
			}
		}
		if(device.type) {
			device.status_tip_info.pretty_type = pretty_device_types[device.type];
		}
	});
	return {screen: screen, ie9: helpers.is_ie9()};


	function get_status_info(device) {
		if(device.sync_active) {
			return {
				class: 'syncing',
				msg: gettext('Syncing')
			};
		} else if(!$device_store.devices[device.id].alive && device.status !== 'unknown') {
			return {
				class: 'error',
				msg: gettext('Unreachable')
			};
		} else if(device.initial_sync_complete == false) {
			return {
				class: 'syncing',
				msg: gettext('Queued for Syncing')
			};
		} else if(device.status === 'ok') {
			return {
				class: 'ok',
				msg: gettext(device.status.toUpperCase())
			};
		} else if(device.status === 'error') {
			return {
				class: 'syncing',
				msg: gettext(helpers.toTitleCase(device.status))
			};
		} else if(device.status) {
			return {
				class: 'other',
				msg: gettext(helpers.toTitleCase(device.status))
			};
		}
		return {
			class: 'unknown',
			msg: gettext('Unknown')
		};
	}
}
function create_status_bar_tip(screen) {
    var screen_dom = $(".screen_status_bar_screen[screen_uuid=" + screen.uuid + "]");
    screen_dom.qtip({
        content: {
            text: $('#screen_status_bar_status_tip_tmpl').tmpl2(_get_tip_info(screen))
        },
        position: {
            my: "bottom center",
            at: "top center",
            viewport: $(window)
        },
        show: {
            event: 'mouseenter mouseover'
        },
        hide: {
            delay: 100,
            event: 'click mouseout',
            fixed: true
        },
        style: {
            classes: 'qtip-dark qtip-shadow qtip-rounded device_status_tip qtip-tms-dark'
        },
        events: {
            show: function(event, api){
                update_status_bar_tip($device_store.screens[screen.uuid]);
            }
        }
    });
}

function update_status_bar_tip(screen) {
    var disabled = true;
    screen['status'] = "ok";
    $.each(screen.devices, function(i, device){
        if(device.status === 'error'){
            screen['status'] = "error";
        }
        if(device.enabled == true){
            disabled = false;
        }
        if(device.category == "projector" && $projection_status_store.devices[device.id]){
            screen.devices[i]['status_info'] = helpers.get_projector_status(device.id);
        }
    });
    if(disabled){
        screen['status'] = "disabled";
    }
    var content_new = $('#screen_status_bar_status_tip_tmpl').tmpl2(_get_tip_info(screen));
    $(".screen_status_bar_screen[screen_uuid=" + screen.uuid + "]").qtip('option', 'content.text', content_new);
}

function create_license_warning_tip() {
    var expiry_stamp = $complex_status.license_expiry;
    var license_date = new Date(expiry_stamp*1000);
    var now_date = new Date();
    var expired = false;
    var offset = null;
    var date = null;
    var warning = true;
    if( expiry_stamp == undefined ){
        $("#license_warning").css("display","none");
    }else if (now_date.getTime() < license_date.getTime()){
        offset = parseInt((license_date.getTime() - now_date.getTime())/ (1000 * 60 * 60 * 24));
        if (offset <= 31){
            $("#license_warning").css("display","inline-block");
            if (offset <= 1){
                $("#license_warning").css('color', 'red');
            }
            else if (offset <= 7){
                $("#license_warning").css('color', '#FF9900');
            }
            else{
                $("#license_warning").css('color', '#FFCC33');
            }
        }else{
            if($("#license_warning").is(":visible") == true){
                $("#license_warning").css("display","none");
            }
            warning = false;
        }
    }
    else{
        $("#license_warning").css("display","inline-block");
        $("#license_warning").css('color', 'red');
        expired = true;
    }
    if( warning ){
        $("#license_warning").qtip({
            content: {
                text: $('#license_warning_tmpl').tmpl2({
					expire_msg: expired ? gettext('License has expired') : gettext("License will expire in %s day(s) !").replace("%s",offset),
					expiry_date: license_date.getTime() ? license_date.toDateString() : false
				})
            },
            position: {
                my: "top center",
                at: "bottom center",
                viewport: $(window)
            },
            show: {
                event: 'click mouseover',
                ready: false,
            },
            hide: {
                delay: 100,
                event: 'unfocus mouseleave',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light'
            },
        });
        license_tip_drawn = true;
    }
}

function create_ftp_server_warning_tip(){
    $("#notifications_btn").qtip({
		content: {
			text: $('#ftp_server_warning_tmpl').tmpl2()
		},
		position: {
			my: 'top center',
			at: 'bottom center',
			viewport: $(window)
		},
		show: {
			ready: true
		},
		hide: false,
		style: {
			classes: 'qtip-shadow qtip-rounded qtip-light'
		}
	});
    ftp_server_error_tip_drawn = true;

}

function destroy_ftp_server_warning_tip(){
    $("#notifications_btn").qtip('destroy');
}

function create_schedule_sync_tip(){
    $("#schedule_sync_status").qtip({
        content: {
            text: $('#schedule_sync_status_tmpl').tmpl2({syncing: false})
        },
        position: {
            my: "top center",
            at: "bottom center",
            viewport: $(window)
        },
        show: {
            event: 'click mouseover',
            ready: false,
        },
        hide: {
            delay: 100,
            event: 'unfocus mouseleave',
            fixed: true
        },
        style: {
            classes: 'qtip-shadow qtip-rounded qtip-light'
        },
    });
}

function create_pos_sync_tip(){
    if( $("#main_section").width() > 1150 && $complex_status.pos.latest_resync.sync_type ){
        $("#pos_overview").qtip({
            content: {
                text: $('#pos_sync_status_tmpl').tmpl2($complex_status.pos.latest_resync)
            },
            position: {
                my: "top center",
                at: "bottom center",
                viewport: $(window)
            },
            show: {
                ready: true,
            },
            hide: false,
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light jq_pos_sync_tip_wrapper'
            },
        });
        $("body").on("click.resync", ".jq_resync_info_close", function(event){
            event.preventDefault();
            event.stopPropagation();
            acknowledge_resync_message();
        });
        $("body").on("click.resync", "#pos_resync_status_dialog_wrapper", function(){
            if(window.location.hash != "#pos_page"){
                history.pushState(null, null, '#pos_page'); pos_page.open(null, true);
            }
            else{
                pos_page._show_last_sync();
            }
        });
    }
}

function destroy_pos_sync_tip(){
    $("#pos_overview").qtip('destroy');
    $("body").off("mouseenter.resync");
    $("body").off("mouseleave.resync");
    $("body").off("click.resync");
}

function acknowledge_resync_message(){
    destroy_pos_sync_tip();
    $complex_status.pos.latest_resync = {};
    helpers.ajax_call({
        url:'/core/pos/acknowledge_pos_resync',
        notify: false,
    });
}

function update_schedule_sync_tip(force){
    var overview_dom = $("#pos_overview");
    if(overview_dom.length > 0 && overview_dom.is(":visible") == true){

        var sync_dom = $('#schedule_sync_status');
        sync_dom.toggleClass('syncing', $complex_status.sched_sync == true);

        // Lame temporary fix for 2.4.1.x ONLY
        if(!force && !$("#schedule_sync_status_dialog_wrapper").is(":visible")) {
            return;
        }
        helpers.ajax_call({
            url: '/core/scheduling/sync_status',
            data: {
                short: true
            },
            success_function: function(input){
                if(true){
                    if(!input.data.syncing && $(".sched_syncing").is(":visible")){
                        $(".sched_status").addClass("done").removeClass("pending");
                        setTimeout(function(){
                            sync_dom.qtip('option', 'content.text', $('#schedule_sync_status_tmpl').tmpl2(input.data));
                        }, 1500);
                    }
                    else{
                        sync_dom.qtip('option', 'content.text', $('#schedule_sync_status_tmpl').tmpl2(input.data));
                    }
                }
                var error = !input.data.syncing && (input.data.errors != undefined && input.data.errors.length > 0);
                sync_dom.toggleClass("scheduling_error", error);
            },
        });
    }
}

function device_sorter(a, b) {
    return $(a).attr('order') < $(b).attr('order') ? -1 : 1;
}
//this ads the playback info for a device and the device objecs themselves for the screen
function update_playback_device_status_bar() {
    var device_id, device_dom, playback_state, device_state;

    //Loop through the playback info to make sure the status bar is up to date
    var playback_device_list = helpers.get_device_list('playback');
    for (var i =0; i < playback_device_list.length; i++) {
        device_id = playback_device_list[i].id;
		if($device_store.devices[device_id]){
            if ($playback_store.devices[device_id] != undefined){
                playback_state = $playback_store.devices[device_id].playback_state;
            }
            else{
                playback_state = 'error';
            }

            var screen_dom = $('.jq_screen_status_bar[screen_uuid=%screen_uuid]'.replace('%screen_uuid', $device_store.devices[device_id].screen_uuid));
			device_dom = $('.jq_device_status_bar_container[device_id="%device_id"]'.replace('%device_id', device_id));
			if (device_dom.length == 1) {
                device_dom = device_dom.find('.jq_playback_state');
				//If the playback state class is incorrect replace it
				if (!device_dom.hasClass(playback_state)) {
					device_dom.removeClass('playback_unknown play pause stop skip_backward skip_forward error').addClass(playback_state);
				}
			}
            else {
				//If the device doesn't exist on the status bar yet, create it and then insert it at the correct position
				var container = screen_dom.find('.screen_status_nav_icons');
				$('#screen_status_bar_screen_device_tmpl').tmpl2({
                    'id':$device_store.devices[device_id].id,
                    'playback_state':playback_state,
                    'state_title':playback_state,
                }).appendTo(container);

                container.find('.jq_device_status_bar_container').sortElements(device_sorter);
			}
		}
    }

    //now clean up what was removed
    var devices_dom = $('.jq_playback_state');
    var device_id = undefined;
    for(var i = 0; i < devices_dom.length; i++){
        device_id = $(devices_dom[i]).attr('screen_device_id');
    	if ($device_store.devices[device_id] == undefined || !$device_store.devices[device_id].enabled){
            $('.jq_device_status_bar_container[device_id="%device_id"]'.replace('%device_id', $(devices_dom[i]).attr('screen_device_id'))).remove();
    	}
    }
}


//this adds the projection info for a device and the device objects themselves for the screen
function update_projection_device_status_bar() {
    var device_id, status, dowser_status, lamp_status, device_dom;

    //Loop through the projection status info to make sure the status bar is up to date
    for (device_id in $projection_status_store.devices) {
		if($device_store.devices[device_id]){
			var re = helpers.get_projector_status(device_id);
            status = re['status'];
            dowser_status = re['dowser_status'];
            lamp_status = re['lamp_status'];

			device_dom = $('.jq_device_status_bar_container[device_id="%device_id"]'.replace('%device_id', device_id));
			if(device_dom.length == 1) {
                device_dom = device_dom.find('.jq_projector_state');
				//If the playback state class is incorrect replace it
				if(!device_dom.hasClass(status)) {
					device_dom.removeClass().addClass('jq_projector_state image tooltip').addClass(status);
				}
			}
            else {
				//If the device doesn't exist on the status bar yet, create it and then insert it at the correct position
				var container = $('.jq_screen_status_bar[screen_uuid=%screen_uuid]'.replace('%screen_uuid', $device_store.devices[device_id].screen_uuid)).find('.screen_status_nav_icons');
				$('#screen_status_bar_projector_device_tmpl').tmpl2({
					'id' : $device_store.devices[device_id].id,
					'status' : status
				}).appendTo(container);
			}
		}
    }

    //now clean up what was removed
    var devices_dom = $('.jq_projector_state');
    var device_id = undefined;
    for(var i=0; i < devices_dom.length; i++){
    	device_id = $(devices_dom[i]).attr('screen_device_id');
    	if ($device_store.devices[device_id] == undefined || !$device_store.devices[device_id].enabled){
            $('.jq_device_status_bar_container[device_id="%device_id"]'.replace('%device_id', $(devices_dom[i]).attr('screen_device_id'))).remove();
    	}
    }
}
