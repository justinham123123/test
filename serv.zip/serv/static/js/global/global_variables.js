/*GLOBAL VARS*/
var $action_store = $({});
$action_store.actions = {};
$action_store.update_interval = 1*1000;

var $complex_status = $({});
$complex_status.update_interval = 1*3000;
$complex_status.static_info_update_interval = 1*30000;
$complex_status.complex_name = gettext('Unknown Complex Name');
$complex_status.complex_time;
$complex_status.complex_time_ref;
$complex_status.territories = {};

$compiled_templates = {};

$complex_status.chat = {
    sync_frequency: 10*1000,
    sync_to: null,
    sync_call: null,
    status: {},
    set_frequency: function(freq){
        this.sync_frequency = freq*1000;
        this.sync();
    },
    reset_frequency: function(){
        this.set_frequency(10);
    },
    sync: function(){
        var self = this;
        if(self.sync_call){
            self.sync_call.abort();
        }
        if(self.sync_to){
            clearTimeout(self.sync_to);
        }
        self.sync_call = helpers.ajax_call({
            name: gettext('Get Message Count.'),
            url: '/core/messaging/status',
            success_function: function(data){
                self.events.trigger("updated", data);
            },
            complete_function: function(){
                self.sync_to = setTimeout(function(){
                    self.sync();
                }, self.sync_frequency);
            }
        });
    },
    events: $({})
}

$complex_status.sorted_territories = function(){return Object.keys($complex_status.territories).sort(function(a,b){
    if ($complex_status.territories[a].name == $complex_status.territories[b].name)
        return 0;
    if ($complex_status.territories[a].name < $complex_status.territories[b].name)
        return -1;
    else
        return 1;})};
        
var $address_type = $({});  

var contact_type = [];
		
		
/* DATA STORES */
var $device_store = $({});
$device_store.devices = {};
$device_store.screens = {};
$device_store.update_interval = 1*30000;
$device_store.get_lms_uuid = function() {
    for (var device_uuid in $device_store.devices) {
        if ($device_store.devices[device_uuid].type == 'aamlms') {
            return device_uuid;
        }
    }
    return null;
};

var $playback_store = $({});
$playback_store.devices = {};
$playback_store.$playlist_composition = $({});

var $projection_status_store = $({});
$projection_status_store.devices = {};

var $aux_status_store = {};
$aux_status_store.audio = {};

var enabled_functions = {};

var sa_icons = {
    "HFR": 'icon-high-framerate',
    "3D": 'icon-three-d',
    "2D": 'icon-two-d',
    "DBOX": 'icon-dbox',
    "SUB": 'icon-subtitles',
    "VI": 'icon-vi',
    "HI": 'icon-hoh',
    "HOH": 'icon-hoh',
    'CC': 'icon-cc'
};

var server_support = {
    'playlist_pattern':['doremi','aamlms', 'sony', 'imax', 'barco'],
    'playlist_title':['aamlms'],
    'playlist_placeholder':['aamlms'],
    'playlist_macro_placeholder':['aamlms'],
    'playlist':['doremi','dolby', 'gdc', 'christie', 'qube', 'aam', 'sony','aamlms', 'imax', 'barco'],
    'schedule':['doremi','dolby', 'gdc', 'christie', 'qube', 'aam', 'sony', 'imax', 'barco'],
    'automation':['doremi','dolby', 'gdc', 'christie', 'qube', 'aam', 'sony', 'imax', 'barco'],
    'content':['doremi','dolby','aamlms','drive','cd', 'gdc', 'christie', 'qube', 'aam', 'sony', 'usb', 'watchfolder', 'local', 'ftp', 'imax', 'barco'],
    'transfer':['doremi','dolby','aamlms','gdc', 'christie', 'qube', 'aam', 'sony', 'local', 'usb', 'drive', 'network', 'imax', 'barco'],
    'playback':['doremi','dolby', 'gdc', 'christie', 'qube', 'aam', 'sony', 'imax', 'barco'],
    'get_playback_mode': ['doremi', 'dolby', 'qube', 'aam', 'imax', 'barco'],
    'set_playback_mode': ['dolby'],
    'projector_monitor':['nec'], 
    'doremi_3d_mode':['doremi','aamlms', 'imax'],
    'doremi_hfr_mode':['doremi', 'aamlms', 'imax'],
    'reboot':['doremi','christie','qube','sony','aam'],
    'quick_cues':['doremi','dolby', 'gdc', 'christie', 'sony', 'imax', 'barco'],
    'no_eject':['sony'],
    'intermissions': ['aamlms', 'sony', 'christie'],
    'no_kdm_deletion': ['dolby']
};

var device_defaults = {
    'sms':{
        'christie':{
            'port':'4502',
            'api_username': 'service',
            'api_password': 'service',
            'ftp_port': '21',
            'ftp_username': 'ftpuser',
            'ftp_password': 'ftptms',
        },
        'dolby':{
            'port':'8080',
            'ftp_port':'21',
            'ftp_username':'dolbyftp',
            'ftp_password':'dolbyftp'
        },
        'doremi':{
            'port':'11730',
            'ftp_port':'21',
            'ftp_username':'manager',
            'ftp_password':'password',
        },
        'imax':{
            'port':'11738',
        },
        'sony':{
            'port':'443',
            'api_username': 'super',
            'api_password': '0955',
            'ftp_port':'21',
            'ftp_username':'s2suser',
            'ftp_password':'sahbicwd',
        },
        'qube':{
            'port':'8080',
            'ftp_port':'21',
            'ftp_username': 'anonymous',
            'ftp_password': 'anonymous',
        },
        'gdc':{
            'port':'49153',
            'ftp_port':'21',
            'ftp_username':'content',
            'ftp_password':'content',
        },        
        'aam':{
            'ip':'127.0.0.1',
        },
        'barco': {
            'port':'43758',
            'ftp_port':'21',
            'api_username': 'admin',
            'api_password': 'Admin1234',
            'ftp_username':'ftpcontent',
            'ftp_password':'icmp',
        }
    },
    'projector':{
        'christie':{
            'port':'5000',
        },
        'nec':{
            'port':'7142',
        },
        'barco':{
            'port':'5000',
        },
        'aam':{
            'ip':'127.0.0.1',
        },
        'sony':{
            'port':'443',
            'api_username': 'super',
            'api_password': '0955',
        },
        'imax':{
            'port':'11738',
        },
    },
    'camera':{
        'axis':{
            'port':80,
            'api_username':'root',
            'api_password':'root'
        },
        'foscam':{
            'port':80,
            'api_username':'aam',
            'api_password':'aam'
        }
    },    
    'audio':{
        'dolby':{
            'port': 61408
        }
    }
}

var pretty_device_types = {
    'content' : gettext('Content'),
    'qc' : 'QC',
    'usl' : 'USL',
    'pos' : gettext('Point of Sale'),
    'camera' : gettext('Camera'),
    'projector' : gettext('Projector'),
    'sms' : gettext('Screen Server / IMB'),
    'ftp' : gettext('FTP Folder'),
    'local' : gettext('Local Folder'),
    'watchfolder' : gettext('Watchfolder'),
    'compeso':'Compeso POS',
    'dolphin':'Dolphin POS',
    'dingxin':'DingXin POS',
    'generic':'General POS',
    'dx':'DX POS',
    'sarft':'SARFT POS',
    'markus':'Markus POS',
    'ebillet':'Ebillet POS',
    'kinodk':'KinoDK POS',
    'merlin':'Merlin POS',
    'onestepahead':'1StepAhead POS',
    'newman':'Newman POS',
    'vista':'Vista POS',
    'axis':'Axis',
    'foscam':'Foscam',
    'sony':'Sony',
    'christie':'Christie',
    'barco':'Barco',
    'nec':'NEC',
    'doremi':'Doremi',
    'dolby':'Dolby',
    'aam':'AAM',
    'qube':'Qube',
    'gdc':'GDC',
    'ucs':'UCS',
    'audio':gettext('Audio'),
    'imax':'IMAX',
    'emulator': 'AAM'
}
var all_devices = {"id":"All"};
var g_last_selected_device = all_devices;
var tonight_timestamp;
var licensed_and_authenticated = {};
var g_nav_structure;
var g_prevent_navigation = false;
var g_page_ready = false;
var g_current_hash;
var pos_devices_syncing = {};

var AUTOMATION_CONFIGURATION = {};

/**
 * Tiny helpers used to bind at the same time a click event and an enter keypress event
 * This is good to improve usability. The user can now perform the same action registerd on click
 * by focusin on the element and pressing enter.
 **/

jQuery.fn.clickOrEnter = function(callback) {
    return this.each(function() {
        jQuery(this).bind({
            keypress : function(e) {
                if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
                    return callback.apply(this, arguments);
                }
            },
            click : callback
        });
    });
};

jQuery.fn.onClickOrEnter = function(selector, callback) {
    return this.each(function() {
        jQuery(this).on({
            keypress : function(e) {
                if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
                    return callback.apply(this, arguments);
                }
            },
            click : callback
        }, selector);
    });
};
