var content_kind_reference = {
	'advertisement' : gettext('Advertisement'),
    'feature'       : gettext('Feature'),
	'pattern'       : gettext('Pattern'),
	'policy'        : gettext('Policy'),
	'psa'           : gettext('PSA'),
    'rating'        : gettext('Rating'),
    'short'         : gettext('Short'),
    'teaser'        : gettext('Teaser'),
    'test'          : gettext('Test'),
    'trailer'       : gettext('Trailer'),
    'transitional'  : gettext('Transitional'),
	'unknown'       : gettext('Unknown'),
};

var content_kind_reference_short = {
    'FTR'       : gettext('Feature'),
    'TLR'       : gettext('Trailer'),
    'TRL'       : gettext('Trailer'),
    'TST'          : gettext('Test'),
    'TSR'        : gettext('Teaser'),
    'RTG'        : gettext('Rating'),
    'ADV' : gettext('Advertisement'),
    'SHR'         : gettext('Short'),
    'SHT'         : gettext('Short'),
    'XSN'  : gettext('Transitional'),
    'PSA'           : gettext('PSA'),
    'POL'        : gettext('Policy'),
};

var screen_capabilities = {
    'cc':{display_name:'CC - ' + gettext('Close Captioned'), 'name':'cc'},
    'hi':{display_name:'HI - ' + gettext('Hearing Impared'), 'name':'hi'},
    'vi':{display_name:'VI - ' + gettext('Visually Impared'), 'name':'vi'},
    'audio':{display_name:gettext('Audio Capability'), 'name':'audio'}
};

// FPS above which we consider content to be HFR
var HFR_FPS = 30;

var days = [gettext('Sun'), gettext('Mon'), gettext('Tues'), gettext('Wed'), gettext('Thurs'), gettext('Fri'), gettext('Sat')];
var full_days = [gettext('Sunday'), gettext('Monday'), gettext('Tuesday'), gettext('Wednesday'), gettext('Thursday'), gettext('Friday'), gettext('Saturday')];
var days_short = [gettext('Sun'), gettext('Mo'), gettext('Tu'), gettext('We'), gettext('Th'), gettext('Fr'), gettext('Sa')];
var months =[gettext('Jan'),gettext('Feb'),gettext('Mar'),gettext('Apr'),gettext('May'),gettext('Jun'),gettext('Jul'),gettext('Aug'),gettext('Sep'),gettext('Oct'),gettext('Nov'),gettext('Dec')];
var full_months =[gettext('January'),gettext('February'),gettext('March'),gettext('April'),gettext('May'),gettext('June'),gettext('July'),gettext('August'),gettext('September'),gettext('October'),gettext('November'),gettext('December')];
var month_days = [ 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31 ];// jQuery template needs a list, cant do "i <= 31" loop

var loop_modes = {
    'doremi': [
        {'value':'do_not_loop','text':gettext('Do not loop')},
        {'value':'loop','text':gettext('Loop')},
        {'value':'play_then_rewind','text':gettext('Play then rewind')},
        {'value':'play_then_eject','text':gettext('Play then eject')}
    ],
    'christie': [
        {'value':'do_not_loop','text':gettext('Do not loop')},
        {'value':'loop','text':gettext('Loop')}
    ],
	barco: [
	    {value: 'do_not_loop', text: gettext('Do not loop')},
	    {value: 'loop', text: gettext('Loop')}
	],
    'qube': [
        {'value':'do_not_loop','text':gettext('Do not loop')},
        {'value':'loop','text':gettext('Loop')}
    ],
    'imax': [
        {'value':'do_not_loop','text':gettext('Do not loop')},
        {'value':'loop','text':gettext('Loop')},
        {'value':'play_then_rewind','text':gettext('Play then rewind')},
        {'value':'play_then_eject','text':gettext('Play then eject')}
    ]
};

var dolby_auto_playback_modes = [
    {'value':'AUTO_THREE_D','text':'Auto 3D'},
    {'value':'AUTO_DOLBY_3D','text':'Auto Dolby 3D'}
];

var dolby_playback_modes = [
    {'value':'2D','text':'2D'},
    {'value':'3D','text':'3D'},
    {'value':'DOLBY_3D','text':'Dolby 3D'}
];

var placeholder_types = {
    "dvdblueray" : gettext("DVD / Blu-Ray"),
    "35mm" : gettext("35mm"),
    "event" : gettext("Event"),
};

var country_codes = {
	"af" : "Afrikaans",
	"ar-sa" : "Arabic (Saudi Arabia)",
	"ar-eg" : "Arabic (Egypt)",
	"ar-dz" : "Arabic (Algeria)",
	"ar-tn" : "Arabic (Tunisia)",
	"ar-ye" : "Arabic (Yemen)",
	"ar-jo" : "Arabic (Jordan)",
	"ar-kw" : "Arabic (Kuwait)",
	"ar-bh" : "Arabic (Bahrain)",
	"eu" : "Basque",
	"be" : "Belarusian",
	"zh-tw" : "Chinese (Taiwan)",
	"zh-hk" : "Chinese (Hong Kong SAR)",
	"hr" : "Croatian",
	"da" : "Danish",
	"nl" : "Dutch",
	"nl-be" : "Dutch (Belgium)",
	"en" : "English",
	"en-us" : "English (United States)",
	"en-au" : "English (Australia)",
	"en-nz" : "English (New Zealand)",
	"en-za" : "English (South Africa)",
	"en-tt" : "English (Trinidad)",
	"fo" : "Faeroese",
	"fi" : "Finnish",
	"fr" : "French",
	"fr-be" : "French (Belgium)",
	"fr-ch" : "French (Switzerland)",
	"gd" : "Gaelic (Scotland)",
	"de" : "German (Standard)",
	"de-at" : "German (Austria)",
	"de-li" : "German (Liechtenstein)",
	"he" : "Hebrew",
	"hu" : "Hungarian",
	"id" : "Indonesian",
	"it" : "Italian",
	"it-ch" : "Italian (Switzerland)",
	"ko" : "Korean",
	"lv" : "Latvian",
	"mk" : "Macedonian (FYROM)",
	"mt" : "Maltese",
	"no" : "Norwegian (Nynorsk)",
	"pt" : "Portuguese",
	"pt-br" : "Portuguese (Brazil)",
	"rm" : "Rhaeto-Romanic",
	"ro-mo" : "Romanian (Republic of Moldova)",
	"ru-mo" : "Russian (Republic of Moldova)",
	"sr" : "Serbian (Cyrillic)",
	"sk" : "Slovak",
	"sb" : "Sorbian",
	"es" : "Spanish",
	"es-mx" : "Spanish (Mexico)",
	"es-cr" : "Spanish (Costa Rica)",
	"es-do" : "Spanish (Dominican Republic)",
	"es-co" : "Spanish (Colombia)",
	"es-ar" : "Spanish (Argentina)",
	"es-cl" : "Spanish (Chile)",
	"es-py" : "Spanish (Paraguay)",
	"es-sv" : "Spanish (El Salvador)",
	"es-ni" : "Spanish (Nicaragua)",
	"sx" : "Sutu",
	"sv-fi" : "Swedish (Finland)",
	"ts" : "Tsonga",
	"tr" : "Turkish",
	"ur" : "Urdu",
	"vi" : "Vietnamese",
	"ji" : "Yiddish"
};

NAVIGATION_CHECK_TEXT = gettext("There are unsaved changes on this page.\n Are you sure you want to leave?");

TRANSFER_STATES = {
    queued:             gettext('Queued'),
    request_sent:       gettext('Request Sent'),
    queued_on_device:   gettext('Queued on Device'),
    active:             gettext('Active'),
    paused:             gettext('Paused'),
    verifying:          gettext('Verifying'),
    success:            gettext('Success'),
    cancelled:          gettext('Cancelled'),
    failed:             gettext('Failed')
};

TRANSFER_MESSAGE_CODES = {
    0: gettext('CPL already exists and is valid'),
    1: gettext('Cannot determine the ingest location. The CPL is either not on the specified source or is in an invalid state'),
    2: gettext('Could not find a valid source to transfer the CPL from'),
    3: gettext('There is not enough free space to transfer the CPL'),
    4: gettext('Transfer started'),
    5: gettext('Unable to find transfer request'),
    6: gettext('Transfer cancelled'),
    7: gettext('Transfer is queued on the screen server'),
    8: gettext('Transfer is paused'),
    9: gettext('Transfer is in progress'),
    10: gettext('Transfer was successful'),
    11:gettext('Transfer failed')
};

var territory = {
    "AE": "UNITED ARAB EMIRATES",
    "AL": "ALBANIA",
    "AR": "ARGENTINA",
    "AT": "AUSTRIA",
    "AU": "AUSTRALIA",
    "BA": "BOSNIA/HERZ",
    "BE": "BELGIUM",
    "BG": "BULGARIA",
    "BH": "BAHRAIN",
    "BO": "BOLIVIA",
    "BR": "BRAZIL",
    "BY": "BELARUS",
    "CA": "CANADA",
    "CH": "SWITZERLAND",
    "CL": "CHILE",
    "CN": "CHINA",
    "CO": "COLOMBIA",
    "CS": "SERBIA",
    "CY": "CYPRUS",
    "CZ": "CZECH REPUBLIC",
    "DE": "GERMANY",
    "DK": "DENMARK",
    "DU": "DUBAI",
    "EC": "ECUADOR",
    "EE": "ESTONIA",
    "EG": "EGYPT",
    "ES": "SPAIN",
    "FI": "FINLAND",
    "FR": "FRANCE",
    "GR": "GREECE",
    "GT": "GUATEMALA",
    "HK": "HONG KONG",
    "HR": "CROATIA",
    "HU": "HUNGARY",
    "ID": "INDONESIA",
    "IE": "IRELAND",
    "IL": "ISRAEL",
    "IN": "INDIA",
    "IS": "ICELAND",
    "IT": "ITALY",
    "JO": "JORDAN",
    "JP": "JAPAN",
    "KE": "KENYA",
    "KR": "SOUTH KOREA",
    "KW": "KUWAIT",
    "KZ": "KAZAKHSTAN",
    "LB": "LEBANON",
    "LT": "LITHUANIA",
    "LU": "LUXEMBOURG",
    "LV": "LATVIA",
    "MD": "MOLDOVA",
    "ME": "MONTENEGRO",
    "MX": "MEXICO",
    "MY": "MALAYSIA",
    "NG": "NIGERIA",
    "NL": "NETHERLANDS",
    "NO": "NORWAY",
    "NZ": "NEW ZEALAND",
    "OM": "OMAN",
    "PA": "PANAMA",
    "PE": "PERU",
    "PH": "PHILIPPINES",
    "PK": "PAKISTAN",
    "PL": "POLAND",
    "PT": "PORTUGAL",
    "PY": "PARAGUAY",
    "QA": "QATAR",
    "RO": "ROMANIA",
    "RU": "RUSSIA",
    "SA": "SAUDI ARABIA",
    "SE": "SWEDEN",
    "SG": "SINGAPORE",
    "SI": "SLOVENIA",
    "SK": "SLOVAKIA",
    "SY": "SYRIAN ARAB REPUBLIC",
    "TH": "THAILAND",
    "TR": "TURKEY",
    "TT": "TRINIDAD",
    "TW": "TAIWAN",
    "UA": "UKRAINE",
    "UK": "UNITED KINGDOM",
    "US": "UNITED STATES",
    "UY": "URUGUAY",
    "VE": "VENEZUELA",
    "VN": "VIETNAM",
    "ZA": "SOUTH AFRICA",
};

var aspect_ratio = {
    "F" : "Flat (1.85:1)",
    "S" : "Scope (2.39:1)",
    "C" : "Full Container (1.90:1)",
};

var audio_type = {
    "51" : "5.1",
    "71" : "7.1",
    "Atmos" : "Atmos",
    "Auro" : "Auro",
};

var package_type = {
    "OV" : "Original Version",
    "VF" : "Version File",
};

var language_codes = {
    'AR': 'ARABIC',
    'BG': 'BULGARIAN',
    'BS': 'BOSNIAN',
    'CA': 'CATALAN',
    'CMN': 'CHINESE - MANDARIN PRC',
    'CS': 'CZECH',
    'DA': 'DANISH',
    'DE': 'GERMAN',
    'EL': 'GREEK',
    'EN': 'ENGLISH',
    'ES': 'SPANISH - CASTILIAN',
    'ET': 'ESTONIAN',
    'EU': 'EUSKARA',
    'FI': 'FINNISH',
    'FR': 'FRENCH',
    'GSW': 'GERMAN - SWISS',
    'HE': 'HEBREW',
    'HI': 'HINDI',
    'HR': 'CROATIAN',
    'HU': 'HUNGARIAN',
    'IND': 'INDONESIAN BAHASA',
    'IS': 'ICELANDIC',
    'IT': 'ITALIAN',
    'JA': 'JAPANESE',
    'KK': 'KAZAKH',
    'KO': 'KOREAN',
    'LAS': 'SPANISH - LATIN AMERICAN',
    'LT': 'LITHUANIAN',
    'LV': 'LATVIAN',
    'MN': 'MONGOLIAN',
    'MSA': 'MALAY BAHASA',
    'NAN': 'CHINESE - TAIWANESE',
    'NL': 'DUTCH',
    'NO': 'NORWEGIAN',
    'PL': 'POLISH',
    'PT': 'PORTUGUESE - EUROPEAN',
    'QBP': 'PORTUGUESE - BRAZILIAN',
    'QFC': 'FRENCH - CANADIAN',
    'QMS': 'CHINESE - MANDARIN SIMPLIFIED',
    'QMT': 'CHINESE - MANDARIN TRADITIONAL',
    'QSA': 'SPANISH - ARGENTINIAN',
    'QSM': 'SPANISH - MEXICAN',
    'QTM': 'CHINESE - TAIWANESE MANDARIN',
    'RO': 'ROMANIAN',
    'RU': 'RUSSIAN',
    'SK': 'SLOVAK',
    'SL': 'SLOVENIAN',
    'SQ': 'ALBANIAN',
    'SR': 'SERBIAN',
    'SV': 'SWEDISH',
    'TA': 'TAMIL',
    'TE': 'TELUGU',
    'TH': 'THAI',
    'TR': 'TURKISH',
    'UK': 'UKRAINIAN',
    'VI': 'VIETNAMESE',
    'VLS': 'FLEMISH',
    'YUE': 'CHINESE - CANTONESE'
};

var emojis = {
    0:"\ud83d\ude04",1:"\ud83d\ude03",2:"\ud83d\ude00",3:"\ud83d\ude0a",4:"\u263a\ufe0f",5:"\ud83d\ude09",6:"\ud83d\ude0d",7:"\ud83d\ude18",8:"\ud83d\ude1a",9:"\ud83d\ude17",10:"\ud83d\ude19",11:"\ud83d\ude1c",12:"\ud83d\ude1d",13:"\ud83d\ude1b",14:"\ud83d\ude33",15:"\ud83d\ude01",16:"\ud83d\ude14",17:"\ud83d\ude0c",18:"\ud83d\ude12",19:"\ud83d\ude1e",20:"\ud83d\ude23",
    21:"\ud83d\ude22",22:"\ud83d\ude02",23:"\ud83d\ude2d",24:"\ud83d\ude2a",25:"\ud83d\ude25",26:"\ud83d\ude30",27:"\ud83d\ude05",28:"\ud83d\ude13",29:"\ud83d\ude29",30:"\ud83d\ude2b",31:"\ud83d\ude28",32:"\ud83d\ude31",33:"\ud83d\ude20",34:"\ud83d\ude21",35:"\ud83d\ude24",36:"\ud83d\ude16",37:"\ud83d\ude06",38:"\ud83d\ude0b",39:"\ud83d\ude37",40:"\ud83d\ude0e",
    41:"\ud83d\ude34",42:"\ud83d\ude35",43:"\ud83d\ude32",44:"\ud83d\ude1f",45:"\ud83d\ude26",46:"\ud83d\ude27",47:"\ud83d\ude08",48:"\ud83d\udc7f",49:"\ud83d\ude2e",50:"\ud83d\ude2c",51:"\ud83d\ude10",52:"\ud83d\ude15",53:"\ud83d\ude2f",54:"\ud83d\ude36",55:"\ud83d\ude07",56:"\ud83d\ude0f",57:"\ud83d\ude11",58:"\ud83d\udc72",59:"\ud83d\udc73",60:"\ud83d\udc6e",
    61:"\ud83d\udc77",62:"\ud83d\udc82",63:"\ud83d\udc76",64:"\ud83d\udc66",65:"\ud83d\udc67",66:"\ud83d\udc68",67:"\ud83d\udc69",68:"\ud83d\udc74",69:"\ud83d\udc75",70:"\ud83d\udc71",71:"\ud83d\udc7c",72:"\ud83d\udc78",73:"\ud83d\ude3a",74:"\ud83d\ude38",75:"\ud83d\ude3b",76:"\ud83d\ude3d",77:"\ud83d\ude3c",78:"\ud83d\ude40",79:"\ud83d\ude3f",80:"\ud83d\ude39",
    81:"\ud83d\ude3e",82:"\ud83d\udc79",83:"\ud83d\udc7a",84:"\ud83d\ude48",85:"\ud83d\ude49",86:"\ud83d\ude4a",87:"\ud83d\udc80",88:"\ud83d\udc7d",89:"\ud83d\udca9",90:"\ud83d\udd25",91:"\u2728",92:"\ud83c\udf1f",93:"\ud83d\udcab",94:"\ud83d\udca5",95:"\ud83d\udca2",96:"\ud83d\udca6",97:"\ud83d\udca7",98:"\ud83d\udca4",99:"\ud83d\udca8",100:"\ud83d\udc42",
    101:"\ud83d\udc40",102:"\ud83d\udc43",103:"\ud83d\udc45",104:"\ud83d\udc44",105:"\ud83d\udc4d",106:"\ud83d\udc4e",107:"\ud83d\udc4c",108:"\ud83d\udc4a",109:"\u270a",110:"\u270c\ufe0f",111:"\ud83d\udc4b",112:"\u270b",113:"\ud83d\udc50",114:"\ud83d\udc46",115:"\ud83d\udc47",116:"\ud83d\udc49",117:"\ud83d\udc48",118:"\ud83d\ude4c",119:"\ud83d\ude4f",120:"\u261d\ufe0f",
    121:"\ud83d\udc4f",122:"\ud83d\udcaa",123:"\ud83d\udeb6",124:"\ud83c\udfc3",125:"\ud83d\udc83",126:"\ud83d\udc6b",127:"\ud83d\udc6a",128:"\ud83d\udc6c",129:"\ud83d\udc6d",130:"\ud83d\udc8f",131:"\ud83d\udc91",132:"\ud83d\udc6f",133:"\ud83d\ude46",134:"\ud83d\ude45",135:"\ud83d\udc81",136:"\ud83d\ude4b",137:"\ud83d\udc86",138:"\ud83d\udc87",139:"\ud83d\udc85",
    140:"\ud83d\udc70",141:"\ud83d\ude4e",142:"\ud83d\ude4d",143:"\ud83d\ude47",144:"\ud83c\udfa9",145:"\ud83d\udc51",146:"\ud83d\udc52",147:"\ud83d\udc5f",148:"\ud83d\udc5e",149:"\ud83d\udc61",150:"\ud83d\udc60",151:"\ud83d\udc62",152:"\ud83d\udc55",153:"\ud83d\udc54",154:"\ud83d\udc5a",155:"\ud83d\udc57",156:"\ud83c\udfbd",157:"\ud83d\udc56",158:"\ud83d\udc58",
    159:"\ud83d\udc59",160:"\ud83d\udcbc",161:"\ud83d\udc5c",162:"\ud83d\udc5d",163:"\ud83d\udc5b",164:"\ud83d\udc53",165:"\ud83c\udf80",166:"\ud83c\udf02",167:"\ud83d\udc84",168:"\ud83d\udc9b",169:"\ud83d\udc99",170:"\ud83d\udc9c",171:"\ud83d\udc9a",172:"\u2764\ufe0f",173:"\ud83d\udc94",174:"\ud83d\udc97",175:"\ud83d\udc93",176:"\ud83d\udc95",177:"\ud83d\udc96",
    178:"\ud83d\udc9e",179:"\ud83d\udc98",180:"\ud83d\udc8c",181:"\ud83d\udc8b",182:"\ud83d\udc8d",183:"\ud83d\udc8e",184:"\ud83d\udc64",185:"\ud83d\udc65",186:"\ud83d\udcac",187:"\ud83d\udc63",188:"\ud83d\udcad",189:"\ud83d\udc36",190:"\ud83d\udc3a",191:"\ud83d\udc31",192:"\ud83d\udc2d",193:"\ud83d\udc39",194:"\ud83d\udc30",195:"\ud83d\udc38",196:"\ud83d\udc2f",
    197:"\ud83d\udc28",198:"\ud83d\udc3b",199:"\ud83d\udc37",200:"\ud83d\udc3d",201:"\ud83d\udc2e",202:"\ud83d\udc17",203:"\ud83d\udc35",204:"\ud83d\udc12",205:"\ud83d\udc34",206:"\ud83d\udc11",207:"\ud83d\udc18",208:"\ud83d\udc3c",209:"\ud83d\udc27",210:"\ud83d\udc26",211:"\ud83d\udc24",212:"\ud83d\udc25",213:"\ud83d\udc23",214:"\ud83d\udc14",215:"\ud83d\udc0d",
    216:"\ud83d\udc22",217:"\ud83d\udc1b",218:"\ud83d\udc1d",219:"\ud83d\udc1c",220:"\ud83d\udc1e",221:"\ud83d\udc0c",222:"\ud83d\udc19",223:"\ud83d\udc1a",224:"\ud83d\udc20",225:"\ud83d\udc1f",226:"\ud83d\udc2c",227:"\ud83d\udc33",228:"\ud83d\udc0b",229:"\ud83d\udc04",230:"\ud83d\udc0f",231:"\ud83d\udc00",232:"\ud83d\udc03",233:"\ud83d\udc05",234:"\ud83d\udc07",
    235:"\ud83d\udc09",236:"\ud83d\udc0e",237:"\ud83d\udc10",238:"\ud83d\udc13",239:"\ud83d\udc15",240:"\ud83d\udc16",241:"\ud83d\udc01",242:"\ud83d\udc02",243:"\ud83d\udc32",244:"\ud83d\udc21",245:"\ud83d\udc0a",246:"\ud83d\udc2b",247:"\ud83d\udc2a",248:"\ud83d\udc06",249:"\ud83d\udc08",250:"\ud83d\udc29",251:"\ud83d\udc3e",252:"\ud83d\udc90",253:"\ud83c\udf38",
    254:"\ud83c\udf37",255:"\ud83c\udf40",256:"\ud83c\udf39",257:"\ud83c\udf3b",258:"\ud83c\udf3a",259:"\ud83c\udf41",260:"\ud83c\udf43",261:"\ud83c\udf42",262:"\ud83c\udf3f",263:"\ud83c\udf3e",264:"\ud83c\udf44",265:"\ud83c\udf35",266:"\ud83c\udf34",267:"\ud83c\udf32",268:"\ud83c\udf33",269:"\ud83c\udf30",270:"\ud83c\udf31",271:"\ud83c\udf3c",272:"\ud83c\udf10",
    273:"\ud83c\udf1e",274:"\ud83c\udf1d",275:"\ud83c\udf1a",276:"\ud83c\udf11",277:"\ud83c\udf12",278:"\ud83c\udf13",279:"\ud83c\udf14",280:"\ud83c\udf15",281:"\ud83c\udf16",282:"\ud83c\udf17",283:"\ud83c\udf18",284:"\ud83c\udf1c",285:"\ud83c\udf1b",286:"\ud83c\udf19",287:"\ud83c\udf0d",288:"\ud83c\udf0e",289:"\ud83c\udf0f",290:"\ud83c\udf0b",291:"\ud83c\udf0c",
    292:"\ud83c\udf20",293:"\u2b50\ufe0f",294:"\u2600\ufe0f",295:"\u26c5\ufe0f",296:"\u2601\ufe0f",297:"\u26a1\ufe0f",298:"\u2614\ufe0f",299:"\u2744\ufe0f",300:"\u26c4\ufe0f",301:"\ud83c\udf00",302:"\ud83c\udf01",303:"\ud83c\udf08",304:"\ud83c\udf0a",305:"\ud83c\udf8d",306:"\ud83d\udc9d",307:"\ud83c\udf8e",308:"\ud83c\udf92",309:"\ud83c\udf93",310:"\ud83c\udf8f",
    311:"\ud83c\udf86",312:"\ud83c\udf87",313:"\ud83c\udf90",314:"\ud83c\udf91",315:"\ud83c\udf83",316:"\ud83d\udc7b",317:"\ud83c\udf85",318:"\ud83c\udf84",319:"\ud83c\udf81",320:"\ud83c\udf8b",321:"\ud83c\udf89",322:"\ud83c\udf8a",323:"\ud83c\udf88",324:"\ud83c\udf8c",325:"\ud83d\udd2e",326:"\ud83c\udfa5",327:"\ud83d\udcf7",328:"\ud83d\udcf9",329:"\ud83d\udcfc",
    330:"\ud83d\udcbf",331:"\ud83d\udcc0",332:"\ud83d\udcbd",333:"\ud83d\udcbe",334:"\ud83d\udcbb",335:"\ud83d\udcf1",336:"\u260e\ufe0f",337:"\ud83d\udcde",338:"\ud83d\udcdf",339:"\ud83d\udce0",340:"\ud83d\udce1",341:"\ud83d\udcfa",342:"\ud83d\udcfb",343:"\ud83d\udd0a",344:"\ud83d\udd09",345:"\ud83d\udd08",346:"\ud83d\udd07",347:"\ud83d\udd14",348:"\ud83d\udd15",
    349:"\ud83d\udce2",350:"\ud83d\udce3",351:"\u23f3",352:"\u231b\ufe0f",353:"\u23f0",354:"\u231a\ufe0f",355:"\ud83d\udd13",356:"\ud83d\udd12",357:"\ud83d\udd0f",358:"\ud83d\udd10",359:"\ud83d\udd11",360:"\ud83d\udd0e",361:"\ud83d\udca1",362:"\ud83d\udd26",363:"\ud83d\udd06",364:"\ud83d\udd05",365:"\ud83d\udd0c",366:"\ud83d\udd0b",367:"\ud83d\udd0d",368:"\ud83d\udec1",
    369:"\ud83d\udec0",370:"\ud83d\udebf",371:"\ud83d\udebd",372:"\ud83d\udd27",373:"\ud83d\udd29",374:"\ud83d\udd28",375:"\ud83d\udeaa",376:"\ud83d\udeac",377:"\ud83d\udca3",378:"\ud83d\udd2b",379:"\ud83d\udd2a",380:"\ud83d\udc8a",381:"\ud83d\udc89",382:"\ud83d\udcb0",383:"\ud83d\udcb4",384:"\ud83d\udcb5",385:"\ud83d\udcb7",386:"\ud83d\udcb6",387:"\ud83d\udcb3",
    388:"\ud83d\udcb8",389:"\ud83d\udcf2",390:"\ud83d\udce7",391:"\ud83d\udce5",392:"\ud83d\udce4",393:"\u2709\ufe0f",394:"\ud83d\udce9",395:"\ud83d\udce8",396:"\ud83d\udcef",397:"\ud83d\udceb",398:"\ud83d\udcea",399:"\ud83d\udcec",400:"\ud83d\udced",401:"\ud83d\udcee",402:"\ud83d\udce6",403:"\ud83d\udcdd",404:"\ud83d\udcc4",405:"\ud83d\udcc3",406:"\ud83d\udcd1",
    407:"\ud83d\udcca",408:"\ud83d\udcc8",409:"\ud83d\udcc9",410:"\ud83d\udcdc",411:"\ud83d\udccb",412:"\ud83d\udcc5",413:"\ud83d\udcc6",414:"\ud83d\udcc7",415:"\ud83d\udcc1",416:"\ud83d\udcc2",417:"\u2702\ufe0f",418:"\ud83d\udccc",419:"\ud83d\udcce",420:"\u2712\ufe0f",421:"\u270f\ufe0f",422:"\ud83d\udccf",423:"\ud83d\udcd0",424:"\ud83d\udcd5",425:"\ud83d\udcd7",
    426:"\ud83d\udcd8",427:"\ud83d\udcd9",428:"\ud83d\udcd3",429:"\ud83d\udcd4",430:"\ud83d\udcd2",431:"\ud83d\udcda",432:"\ud83d\udcd6",433:"\ud83d\udd16",434:"\ud83d\udcdb",435:"\ud83d\udd2c",436:"\ud83d\udd2d",437:"\ud83d\udcf0",438:"\ud83c\udfa8",439:"\ud83c\udfac",440:"\ud83c\udfa4",441:"\ud83c\udfa7",442:"\ud83c\udfbc",443:"\ud83c\udfb5",444:"\ud83c\udfb6",
    445:"\ud83c\udfb9",446:"\ud83c\udfbb",447:"\ud83c\udfba",448:"\ud83c\udfb7",449:"\ud83c\udfb8",450:"\ud83d\udc7e",451:"\ud83c\udfae",452:"\ud83c\udccf",453:"\ud83c\udfb4",454:"\ud83c\udc04\ufe0f",455:"\ud83c\udfb2",456:"\ud83c\udfaf",457:"\ud83c\udfc8",458:"\ud83c\udfc0",459:"\u26bd\ufe0f",460:"\u26be\ufe0f",461:"\ud83c\udfbe",462:"\ud83c\udfb1",463:"\ud83c\udfc9",
    464:"\ud83c\udfb3",465:"\u26f3\ufe0f",466:"\ud83d\udeb5",467:"\ud83d\udeb4",468:"\ud83c\udfc1",469:"\ud83c\udfc7",470:"\ud83c\udfc6",471:"\ud83c\udfbf",472:"\ud83c\udfc2",473:"\ud83c\udfca",474:"\ud83c\udfc4",475:"\ud83c\udfa3",476:"\u2615\ufe0f",477:"\ud83c\udf75",478:"\ud83c\udf76",479:"\ud83c\udf7c",480:"\ud83c\udf7a",481:"\ud83c\udf7b",482:"\ud83c\udf78",
    483:"\ud83c\udf79",484:"\ud83c\udf77",485:"\ud83c\udf74",486:"\ud83c\udf55",487:"\ud83c\udf54",488:"\ud83c\udf5f",489:"\ud83c\udf57",490:"\ud83c\udf56",491:"\ud83c\udf5d",492:"\ud83c\udf5b",493:"\ud83c\udf64",494:"\ud83c\udf71",495:"\ud83c\udf63",496:"\ud83c\udf65",497:"\ud83c\udf59",498:"\ud83c\udf58",499:"\ud83c\udf5a",500:"\ud83c\udf5c",501:"\ud83c\udf72",
    502:"\ud83c\udf62",503:"\ud83c\udf61",504:"\ud83c\udf73",505:"\ud83c\udf5e",506:"\ud83c\udf69",507:"\ud83c\udf6e",508:"\ud83c\udf66",509:"\ud83c\udf68",510:"\ud83c\udf67",511:"\ud83c\udf82",512:"\ud83c\udf70",513:"\ud83c\udf6a",514:"\ud83c\udf6b",515:"\ud83c\udf6c",516:"\ud83c\udf6d",517:"\ud83c\udf6f",518:"\ud83c\udf4e",519:"\ud83c\udf4f",520:"\ud83c\udf4a",
    521:"\ud83c\udf4b",522:"\ud83c\udf52",523:"\ud83c\udf47",524:"\ud83c\udf49",525:"\ud83c\udf53",526:"\ud83c\udf51",527:"\ud83c\udf48",528:"\ud83c\udf4c",529:"\ud83c\udf50",530:"\ud83c\udf4d",531:"\ud83c\udf60",532:"\ud83c\udf46",533:"\ud83c\udf45",534:"\ud83c\udf3d",535:"\ud83c\udfe0",536:"\ud83c\udfe1",537:"\ud83c\udfeb",538:"\ud83c\udfe2",539:"\ud83c\udfe3",
    540:"\ud83c\udfe5",541:"\ud83c\udfe6",542:"\ud83c\udfea",543:"\ud83c\udfe9",544:"\ud83c\udfe8",545:"\ud83d\udc92",546:"\u26ea\ufe0f",547:"\ud83c\udfec",548:"\ud83c\udfe4",549:"\ud83c\udf07",550:"\ud83c\udf06",551:"\ud83c\udfef",552:"\ud83c\udff0",553:"\u26fa\ufe0f",554:"\ud83c\udfed",555:"\ud83d\uddfc",556:"\ud83d\uddfe",557:"\ud83d\uddfb",558:"\ud83c\udf04",
    559:"\ud83c\udf05",560:"\ud83c\udf03",561:"\ud83d\uddfd",562:"\ud83c\udf09",563:"\ud83c\udfa0",564:"\ud83c\udfa1",565:"\u26f2\ufe0f",566:"\ud83c\udfa2",567:"\ud83d\udea2",568:"\u26f5\ufe0f",569:"\ud83d\udea4",570:"\ud83d\udea3",571:"\u2693\ufe0f",572:"\ud83d\ude80",573:"\u2708\ufe0f",574:"\ud83d\udcba",575:"\ud83d\ude81",576:"\ud83d\ude82",577:"\ud83d\ude8a",
    578:"\ud83d\ude89",579:"\ud83d\ude9e",580:"\ud83d\ude86",581:"\ud83d\ude84",582:"\ud83d\ude85",583:"\ud83d\ude88",584:"\ud83d\ude87",585:"\ud83d\ude9d",586:"\ud83d\ude8b",587:"\ud83d\ude83",588:"\ud83d\ude8e",589:"\ud83d\ude8c",590:"\ud83d\ude8d",591:"\ud83d\ude99",592:"\ud83d\ude98",593:"\ud83d\ude97",594:"\ud83d\ude95",595:"\ud83d\ude96",596:"\ud83d\ude9b",
    597:"\ud83d\ude9a",598:"\ud83d\udea8",599:"\ud83d\ude93",600:"\ud83d\ude94",601:"\ud83d\ude92",602:"\ud83d\ude91",603:"\ud83d\ude90",604:"\ud83d\udeb2",605:"\ud83d\udea1",606:"\ud83d\ude9f",607:"\ud83d\udea0",608:"\ud83d\ude9c",609:"\ud83d\udc88",610:"\ud83d\ude8f",611:"\ud83c\udfab",612:"\ud83d\udea6",613:"\ud83d\udea5",614:"\u26a0\ufe0f",615:"\ud83d\udea7",
    616:"\ud83d\udd30",617:"\u26fd\ufe0f",618:"\ud83c\udfee",619:"\ud83c\udfb0",620:"\u2668\ufe0f",621:"\ud83d\uddff",622:"\ud83c\udfaa",623:"\ud83c\udfad",624:"\ud83d\udccd",625:"\ud83d\udea9",626:"\ud83c\uddef\ud83c\uddf5",627:"\ud83c\uddf0\ud83c\uddf7",628:"\ud83c\udde9\ud83c\uddea",629:"\ud83c\udde8\ud83c\uddf3",630:"\ud83c\uddfa\ud83c\uddf8",631:"\ud83c\uddeb\ud83c\uddf7",
    632:"\ud83c\uddea\ud83c\uddf8",633:"\ud83c\uddee\ud83c\uddf9",634:"\ud83c\uddf7\ud83c\uddfa",635:"\ud83c\uddec\ud83c\udde7",636:"1\u20e3",637:"2\u20e3",638:"3\u20e3",639:"4\u20e3",640:"5\u20e3",641:"6\u20e3",642:"7\u20e3",643:"8\u20e3",644:"9\u20e3",645:"0\u20e3",646:"\ud83d\udd1f",647:"\ud83d\udd22",648:"\u0023\u20e3",649:"\ud83d\udd23",650:"\u2b06\ufe0f",651:"\u2b07\ufe0f",
    652:"\u2b05\ufe0f",653:"\u27a1\ufe0f",654:"\ud83d\udd20",655:"\ud83d\udd21",656:"\ud83d\udd24",657:"\u2197\ufe0f",658:"\u2196\ufe0f",659:"\u2198\ufe0f",660:"\u2199\ufe0f",661:"\u2194\ufe0f",662:"\u2195\ufe0f",663:"\ud83d\udd04",664:"\u25c0\ufe0f",665:"\u25b6\ufe0f",666:"\ud83d\udd3c",667:"\ud83d\udd3d",668:"\u21a9\ufe0f",669:"\u21aa\ufe0f",670:"\u2139\ufe0f",671:"\u23ea",
    672:"\u23e9",673:"\u23eb",674:"\u23ec",675:"\u2935\ufe0f",676:"\u2934\ufe0f",677:"\ud83c\udd97",678:"\ud83d\udd00",679:"\ud83d\udd01",680:"\ud83d\udd02",681:"\ud83c\udd95",682:"\ud83c\udd99",683:"\ud83c\udd92",684:"\ud83c\udd93",685:"\ud83c\udd96",686:"\ud83d\udcf6",687:"\ud83c\udfa6",688:"\ud83c\ude01",689:"\ud83c\ude2f\ufe0f",690:"\ud83c\ude33",691:"\ud83c\ude35",
    692:"\ud83c\ude34",693:"\ud83c\ude32",694:"\ud83c\ude50",695:"\ud83c\ude39",696:"\ud83c\ude3a",697:"\ud83c\ude36",698:"\ud83c\ude1a\ufe0f",699:"\ud83d\udebb",700:"\ud83d\udeb9",701:"\ud83d\udeba",702:"\ud83d\udebc",703:"\ud83d\udebe",704:"\ud83d\udeb0",705:"\ud83d\udeae",706:"\ud83c\udd7f\ufe0f",707:"\u267f\ufe0f",708:"\ud83d\udead",709:"\ud83c\ude37",710:"\ud83c\ude38",
    711:"\ud83c\ude02",712:"\u24c2\ufe0f",713:"\ud83d\udec2",714:"\ud83d\udec4",715:"\ud83d\udec5",716:"\ud83d\udec3",717:"\ud83c\ude51",718:"\u3299\ufe0f",719:"\u3297\ufe0f",720:"\ud83c\udd91",721:"\ud83c\udd98",722:"\ud83c\udd94",723:"\ud83d\udeab",724:"\ud83d\udd1e",725:"\ud83d\udcf5",726:"\ud83d\udeaf",727:"\ud83d\udeb1",728:"\ud83d\udeb3",729:"\ud83d\udeb7",
    730:"\ud83d\udeb8",731:"\u26d4\ufe0f",732:"\u2733\ufe0f",733:"\u2747\ufe0f",734:"\u274e",735:"\u2705",736:"\u2734\ufe0f",737:"\ud83d\udc9f",738:"\ud83c\udd9a",739:"\ud83d\udcf3",740:"\ud83d\udcf4",741:"\ud83c\udd70",742:"\ud83c\udd71",743:"\ud83c\udd8e",744:"\ud83c\udd7e",745:"\ud83d\udca0",746:"\u27bf",747:"\u267b\ufe0f",748:"\u2648\ufe0f",749:"\u2649\ufe0f",
    750:"\u264a\ufe0f",751:"\u264b\ufe0f",752:"\u264c\ufe0f",753:"\u264d\ufe0f",754:"\u264e\ufe0f",755:"\u264f\ufe0f",756:"\u2650\ufe0f",757:"\u2651\ufe0f",758:"\u2652\ufe0f",759:"\u2653\ufe0f",760:"\u26ce",761:"\ud83d\udd2f",762:"\ud83c\udfe7",763:"\ud83d\udcb9",764:"\ud83d\udcb2",765:"\ud83d\udcb1",766:"\u00a9",767:"\u00ae",768:"\u2122",769:"\u274c",770:"\u203c\ufe0f",
    771:"\u2049\ufe0f",772:"\u2757\ufe0f",773:"\u2753",774:"\u2755",775:"\u2754",776:"\u2b55\ufe0f",777:"\ud83d\udd1d",778:"\ud83d\udd1a",779:"\ud83d\udd19",780:"\ud83d\udd1b",781:"\ud83d\udd1c",782:"\ud83d\udd03",783:"\ud83d\udd5b",784:"\ud83d\udd67",785:"\ud83d\udd50",786:"\ud83d\udd5c",787:"\ud83d\udd51",788:"\ud83d\udd5d",789:"\ud83d\udd52",790:"\ud83d\udd5e",
    791:"\ud83d\udd53",792:"\ud83d\udd5f",793:"\ud83d\udd54",794:"\ud83d\udd60",795:"\ud83d\udd55",796:"\ud83d\udd56",797:"\ud83d\udd57",798:"\ud83d\udd58",799:"\ud83d\udd59",800:"\ud83d\udd5a",801:"\ud83d\udd61",802:"\ud83d\udd62",803:"\ud83d\udd63",804:"\ud83d\udd64",805:"\ud83d\udd65",806:"\ud83d\udd66",807:"\u2716\ufe0f",808:"\u2795",809:"\u2796",810:"\u2797",
    811:"\u2660\ufe0f",812:"\u2665\ufe0f",813:"\u2663\ufe0f",814:"\u2666\ufe0f",815:"\ud83d\udcae",816:"\ud83d\udcaf",817:"\u2714\ufe0f",818:"\u2611\ufe0f",819:"\ud83d\udd18",820:"\ud83d\udd17",821:"\u27b0",822:"\u3030",823:"\u303d\ufe0f",824:"\ud83d\udd31",825:"\u25fc\ufe0f",826:"\u25fb\ufe0f",827:"\u25fe\ufe0f",828:"\u25fd\ufe0f",829:"\u25aa\ufe0f",830:"\u25ab\ufe0f",
    831:"\ud83d\udd3a",832:"\ud83d\udd32",833:"\ud83d\udd33",834:"\u26ab\ufe0f",835:"\u26aa\ufe0f",836:"\ud83d\udd34",837:"\ud83d\udd35",838:"\ud83d\udd3b",839:"\u2b1c\ufe0f",840:"\u2b1b\ufe0f",841:"\ud83d\udd36",842:"\ud83d\udd37",843:"\ud83d\udd38",844:"\ud83d\udd39",4:"\u263a",110:"\u270c",120:"\u261d",172:"\u2764",293:"\u2b50",294:"\u2600",295:"\u26c5",296:"\u2601",
    297:"\u26a1",298:"\u2614",299:"\u2744",300:"\u26c4",336:"\u260e",352:"\u231b",354:"\u231a",393:"\u2709",417:"\u2702",420:"\u2712",421:"\u270f",454:"\ud83c\udc04",459:"\u26bd",460:"\u26be",465:"\u26f3",476:"\u2615",546:"\u26ea",553:"\u26fa",565:"\u26f2",568:"\u26f5",571:"\u2693",573:"\u2708",614:"\u26a0",617:"\u26fd",620:"\u2668",650:"\u2b06",651:"\u2b07",652:"\u2b05",
    653:"\u27a1",657:"\u2197",658:"\u2196",659:"\u2198",660:"\u2199",661:"\u2194",662:"\u2195",664:"\u25c0",665:"\u25b6",668:"\u21a9",669:"\u21aa",670:"\u2139",675:"\u2935",676:"\u2934",689:"\ud83c\ude2f",698:"\ud83c\ude1a",706:"\ud83c\udd7f",707:"\u267f",712:"\u24c2",718:"\u3299",719:"\u3297",731:"\u26d4",732:"\u2733",733:"\u2747",736:"\u2734",747:"\u267b",748:"\u2648",
    749:"\u2649",750:"\u264a",751:"\u264b",752:"\u264c",753:"\u264d",754:"\u264e",755:"\u264f",756:"\u2650",757:"\u2651",758:"\u2652",759:"\u2653",770:"\u203c",771:"\u2049",772:"\u2757",776:"\u2b55",807:"\u2716",811:"\u2660",812:"\u2665",813:"\u2663",814:"\u2666",817:"\u2714",818:"\u2611",823:"\u303d",825:"\u25fc",826:"\u25fb",827:"\u25fe",828:"\u25fd",829:"\u25aa",
    830:"\u25ab",834:"\u26ab",835:"\u26aa",839:"\u2b1c",840:"\u2b1b"
};

var DATATABLES_LANG = {
    sZeroRecords: '<span class="icon-info inline-icon table_image"></span>'+ gettext('No matching items were found'),
    sInfo: gettext('_START_ to _END_ of _TOTAL_'),
    sInfoEmpty: gettext('0 to 0 of 0'),
    sInfoFiltered: gettext('(filtered from _MAX_)'),
    sSearch: '',
    oPaginate: {
        sNext: gettext('Next'),
        sLast: gettext('Last'),
        sPrevious: gettext('Previous'),
        sFirst: gettext('First')
    }
};
