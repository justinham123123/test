
// Hehe.
var enable_tetris = false;
var enable_octo = false;
var enable_robot = false;
var enable_self_destruct = false;
var enable_max = true;
var enable_nyan = true;
var enable_konami = true;
var enable_asteroids = true;
var enable_type_roulette = true;
var enable_napleon = true;
var score = 0;

/*
function gettext(string){
    var words = string.split(" ");
    var new_string = "";
    for(i in words){        
        if(words[i].indexOf("%") == -1)
            new_string += "blah ";
        else
            new_string += words[i] + " ";
    }
    new_string = new_string.slice(0, -1);
    return new_string;
}
*/

$(document).ready(function()
{
    if(getCookie('nyan') == "true")
    {
        //nyan_cat_to_the_rescue();
    }

    if (window.addEventListener){
        var kkeys = [];    
        var konami = "38,38,40,40,37,39,37,39,66,65";
        var asteroids = "38,38,40,40,37,39,37,39,65,66";
        var tpsreports = "38,38,40,40,65";
        var robo = "38,38,40,40,66";
        var destruct = "38,39,40,37,38,39,40,37";
        var tetris = "73,72,69,65,82,84,84,69,84,82,73,83";
        var max = "72,69,76,80,77,69";
        var the_talbot_challenge = "84,65,76,66,79,84,67,72,65,76,76,69,78,71,69";
        var nyannyan = "78,89,65,78,78,89,65,78";
		var roulette = "70,69,69,76,73,78,71,76,85,67,75,89";
        var kiril = "75,73,82,73,76";
        var napleon = "78,65,80,76,69,79,78";
        window.addEventListener("keydown", function(e){
            kkeys.push( e.keyCode );
            //Hehe 2
            if ( enable_octo && kkeys.toString().indexOf( tpsreports ) >= 0 ) {octo_popup(); kkeys = []}
            if ( enable_robot && kkeys.toString().indexOf( robo ) >= 0 ) {robot_popup(); kkeys = []}
            if ( enable_self_destruct && kkeys.toString().indexOf( destruct ) >= 0 ) {self_destruct(); kkeys = []}
            if ( enable_tetris && kkeys.toString().indexOf( tetris ) >= 0 ) {play_tetris(); kkeys = []}
            if ( enable_max && kkeys.toString().indexOf( max ) >= 0 ) {did_you_know(); kkeys = []}
            if ( enable_max && kkeys.toString().indexOf( the_talbot_challenge ) >= 0 ) {click_on_max(); kkeys = []}
            if ( enable_nyan && kkeys.toString().indexOf( nyannyan ) >= 0 ) {nyan_cat_to_the_rescue(); kkeys = []}
            if ( enable_nyan && kkeys.toString().indexOf( kiril ) >= 0 ) {nyan_cat_to_the_rescue({
                hero_class: "kiril",
                laser_class: "kiril_laser"
            }); kkeys = []}
            if ( enable_type_roulette && kkeys.toString().indexOf( roulette ) >= 0 ) {content_type_roulette(); kkeys = []}
            if ( enable_napleon && kkeys.toString().indexOf( napleon ) >= 0 ) {napleon_dynamite(); kkeys = []}
            if ( enable_konami && kkeys.toString().indexOf( konami ) >= 0 ) {
                ponies();
                kkeys = [];
            }
            if ( enable_asteroids && kkeys.toString().indexOf( asteroids ) >= 0 ) {
                asteroids_go();
                kkeys = [];
            }
            if( kkeys.length > 100){
                kkeys = [];
            }
        }, true);
    }

    function ponies(){
        $.getScript('http://www.cornify.com/js/cornify.js',function(){
            cornify_add();
            $(document).keydown(cornify_add);
        });    
    }

    function asteroids_go(){
        var KICKASSVERSION='2.0';
        var s = document.createElement('script');
        s.type='text/javascript';
        document.body.appendChild(s);
        s.src='//hi.kickassapp.com/kickass.js';void(0);
        kkeys = [];        
    }

    function content_type_roulette(){
        var const_content_kinds = [];
        var content_kinds = [];
        for(kind in content_kind_reference){
            content_kinds.push(kind);
            const_content_kinds.push(kind);
        }
        var i = setInterval(function(){
            var first = content_kinds.splice(0, 1);
            content_kinds.push(first[0]);
            $('.image.content_attributes').each(function(){
                var classes = $(this).attr("class");
                var old_class;
                var new_class;
                classes_list = classes.split(" ");
                for(class_i in classes_list){
                    old_class = classes_list[class_i];
                    var index = const_content_kinds.indexOf(old_class);
                    if(index != -1){
                        new_class = content_kinds[index];
                        break;
                    }
                }
                var classes = classes.replace(old_class, new_class);
                $(this).attr("class", classes);
            });
        }, 200);
    }

    function setCookie(c_name, value, exdays)
    {
        var exdate=new Date();
        exdate.setDate(exdate.getDate() + exdays);
        var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
        document.cookie=c_name + "=" + c_value;
    }

    function getCookie(c_name)
    {
        var i,x,y,ARRcookies=document.cookie.split(";");
        for (i=0;i<ARRcookies.length;i++)
        {
            x = ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
            y = ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
            x = x.replace(/^\s+|\s+$/g,"");
            if (x == c_name)
            {
                return unescape(y);
            }
        }
    }

    var nyan;
    function nyan_cat_to_the_rescue(args) {
        if(args == undefined){
            var args = {
                hero_class: 'nyan',
                laser_class: 'laser'
            }
        }

        if($('#fun').length > 0){
            if(nyan){
                nyan.begone();
            }
            setCookie('nyan', "false", 99);
            $('#fun').fadeOut(function(){
                $('#fun').remove();
            })
        }
        else{
            setCookie('nyan', "true", 99);
            nyan = new Nyan(args);
            nyan.come_forth($('#login_page_wrapper'));
        }   
    }

    function Nyan(args){
        var destination = new Destination(-200,-200);
        var direction = "right"
        var zep = null;
        var interval_id = null;
        var interval = null;
        var hero_class = args.hero_class;
        var laser_class = args.laser_class;

        this.come_forth = function(dom){
            var self = this;
            var nyan = $('<div id="fun"><div id="eye"><img src="/static/img/eye.png" /></div><a id="zeppelin" href="http://www.artsalliancemedia.com" target="_blank" title="Go to artsalliancemedia.com"></a><div id="robot1"><img src="/static/img/robot1.png"></div><div id="screen_play"><img src="/static/img/screen_play.png"></div><div id="hills"><img src="/static/img/hollywood_hills.png"></div><div id="city_back"><img src="/static/img/city_landscape_back.png"></div><div id="city_front"><img src="/static/img/city_landscape_front.png"></div></div>');            
            $(dom).append(nyan);
            zep = $('#zeppelin');
            zep.addClass(hero_class);

            interval = setInterval(function(){                
                self.set_sail();
            }, 100);

            $('#login_page_wrapper').on("mousemove.nyan", function(e){
                destination = new Destination(e.pageX, e.pageY);  
                self.inform_the_captain(destination);
            });
            $('#login_page_wrapper').on("mousedown.nyan", function(e){
                self.firing_me_laz0rs();
            });
            $('#login_page_wrapper').on("mouseup.nyan", function(e){
                self.cease_fire();
            }); 
        }

        this.begone = function(){
            this.cease_fire();
            $('#login_page_wrapper').off();
            clearInterval(interval);
        }
        
        this.inform_the_captain = function(destination)
        {
            destination = destination;
            this.change_bearing();
        }
        
        this.set_sail = function()
        {
            var new_direction  = ((zep.offset().left + (zep.width() / 2)) < destination.x) ? "right" : "left"            

            if (new_direction != direction)
            {
                direction = new_direction
                if(direction == "right")
                    zep.removeClass("left").addClass("right");
                else                        
                    zep.removeClass("right").addClass("left");
            }
            
            zep.stop().animate({"top" : destination.y, "left" : destination.x}, 400, "easeInOutCirc");          
        }
        
        this.change_bearing = function()
        {
            var center_x = (zep.offset().left) + ( zep.width() / 2 );
            var center_y = (zep.offset().top) + ( zep.height() / 2 );
            var mouse_x = destination.x; 
            var mouse_y = destination.y;

            var radians = Math.atan2(mouse_x - center_x, mouse_y - center_y);
            var degree = (radians * (180 / Math.PI) * -1) + 90; 
            
            zep.css('-moz-transform', 'rotate('+degree+'deg)');
            zep.css('-webkit-transform', 'rotate('+degree+'deg)');
            zep.css('-o-transform', 'rotate('+degree+'deg)');
            zep.css('-ms-transform', 'rotate('+degree+'deg)');
        }

        this.firing_me_laz0rs = function()
        {
            interval_id = window.setInterval(this.fire, 75);
        }

        this.cease_fire = function()
        {
            window.clearInterval(interval_id);
        }

        this.fire = function()
        {
            var center_x = (zep.offset().left) + ( zep.width() / 2 );
            var center_y = (zep.offset().top) + ( zep.height() / 2 );
            var mouse_x = destination.x; 
            var mouse_y = destination.y;

            var laser = $("<div />").addClass(laser_class).css({"left": center_x, "top": center_y});  
            $('body').append(laser);
            $(laser).animate({top: mouse_y, left: mouse_x}, 400);
        }
    }
    
    function Destination(x, y){
        this.x = x;
        this.y = y;
    }

    function octo_popup() {
        enable_octo = false
        $('#footer_wrapper').after('<div id="octo" style="float:left; position:relative; bottom:135px;left:-100px;z-index:10;"><img src="/static/img/base/octo.gif" /></div>')
        $('#octo').animate({'left': '+=200'},2700, function() {
            $('#octo').hide('explode', {pieces:18},1500, function() {$('#octo').remove()})
        })
        $('#footer_wrapper').before('<div id="bear" style="float:left; position:relative; bottom:2000px;left:200px;z-index:5;"><img onclick="octo_ouch()" src="/static/img/base/bear.png" /></div>')
        $('#bear').animate( {'bottom': '100'}, 2700, function() {
            $('#bear').effect('shake', {times:20},10, function() {})
        })
    }

    function octo_ouch() {
        setTimeout('octo_popdown()', 500);
    }
    function octo_popdown() {
        $('#bear').animate({"left":'2000'}, 500, function() {
            $('#bear').remove();
            enable_octo = true
        });
    }

    function robot_popup() {
        enable_robot = false
        $('#footer_wrapper').after('<div id="robot" style="float:left; position:relative; bottom:500px;"><img onclick="robot_ouch()" src="/static/img/base/too_far.gif" /></div>')
        $('#robot').show('slide', { direction: "left" }, 3000)
    }

    function robot_ouch() {
        setTimeout('robot_popdown()', 500)
    }
    function robot_popdown() {
        $('#robot').hide('slide', { direction: "down" }, 1500, function() {
            $('#robot').remove()
            enable_robot = true }
            )
    }
    function self_destruct() {
        enable_self_destruct = false;
        countdown(5);
        setTimeout('self_destruct_messages()', 6300);
        setTimeout('self_destruct_actions()',6300);
        setTimeout('fin()',25000);
    }

    function play_tetris() {
        $('<script type="text/javascript" src="/static/js/tetris.js"></script><link href="/static/css/tetris.css" rel="stylesheet" type="text/css" />').appendTo('head').ready(function() {   
            var buttons = {};
            buttons[gettext('Close')] = function() { $(this).dialog('close');}        
            $("#tetris_dialog").dialog({
                    bgiframe: true,
                    autoOpen: false,
                    height: 420,
                    width: 400,
                    modal: true,
                    title: "T(ms)ETRIS",
                    resizable: false,
                    draggable: true, 
                    buttons:buttons
                }
            )    
            $('#tetris_dialog').bind('dialogclose', function(event) {
                tetris.reset();
            });    
            $("#tetris_dialog").dialog('open');    
            var tetris = new Tetris();
            tetris.unit = 14;
            tetris.areaX = 12;
            tetris.areaY = 22;
        });     
    }

    function fin() {
        enable_self_destruct = true;
        $('html').css("background-color", 'black');
        $('body').hide("clip", 500);
    }

    function countdown(number) {
        if (number > 0 ) {
            warning_msg('Self destruct sequence initiated ...'+number,'self_destruct');
            number -= 1;
            setTimeout('countdown('+number+')',1000);
        }
        else if (number == 0) {
            warning_msg('Self destruct sequence initiated ... destruction imminent','self_destruct');
        }
    }

    function self_destruct_messages() {
        if (enable_self_destruct == false) {
            switch(Math.floor(Math.random()*8)) {
                case 0: error_msg('Critical Core failing, flashing backup devices.','self_destruct_'+Math.floor(Math.random()*4));break;
                case 1: warning_msg('Bunnies sighted, there are too many of them.','self_destruct_'+Math.floor(Math.random()*4));break;
                case 2: info_msg('Loading panic module.... please be paitient.','self_destruct_'+Math.floor(Math.random()*4));break;
                case 3: warning_msg('Activating chat, all frequencies','self_destruct_'+Math.floor(Math.random()*4));break;
                case 4: info_msg('The waitingsnake in your funktion has been terminated.','self_destruct_'+Math.floor(Math.random()*4));break;
                case 5: error_msg('Falsche sprache wo bin ich?','self_destruct_'+Math.floor(Math.random()*4));break;
                case 6: warning_msg('Centralized Certificate added.','self_destruct_'+Math.floor(Math.random()*4));break;
                case 7: info_msg('TMS is lonely, looking for LMS.','self_destruct_'+Math.floor(Math.random()*4));break;
            }
            setTimeout('self_destruct_messages()', 200);
        }
    }

    function self_destruct_actions() {
        if (enable_self_destruct == false) {
            act(select_tag_type());
            setTimeout('self_destruct_actions()', 50);
        }
    }

    function select_tag_type() {
        switch(Math.floor(Math.random()*5)) {
            case 0: return 'td';
            case 1: return 'div';
            case 2: return 'a';
            case 3: return 'span';
            case 4: return 'li';
        }
    }

    function random_color() {
        var color_elements = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'];
        var output = '';
        for (var i =0; i < 6; i++) {
            output += color_elements[Math.floor(Math.random()*color_elements.length)];
        }
        return '#'+output;
    }

    function colorize(victim) {
        if (enable_self_destruct == false) {
            var colorable_styles = ['color','background-color','border-color'];
            $(victim).css(colorable_styles[Math.floor(Math.random()*colorable_styles.length)],random_color());
            setTimeout(function(){colorize(victim)},35);
        }
    }

    function spacer(victim) {
        if (enable_self_destruct == false) {
            var sizable_styles = ['font-size','padding','margin','border'];
            $(victim).css(sizable_styles[Math.floor(Math.random()*sizable_styles.length)],Math.floor(Math.random()*20)+'px');
            setTimeout(function(){spacer(victim)},35);
        }
    }

    function bilby_attack() {
        var bilbies = ['smallbilbyweb.png'];
        var x = Math.floor(Math.random()*$(window).height()-400);
        var y = Math.floor(Math.random()*$(window).width()-400);
        $('#footer_wrapper').before('<div style="float:left; position:relative; bottom:'+x+'px;left:'+y+'px;z-index:5;"><img onclick="octo_ouch()" src="/static/img/base/'+bilbies[Math.floor(Math.random()*bilbies.length)]+'" /></div>')
    }

    function act(tag) {
        var victim = $(tag)[Math.floor(Math.random()*$(tag).length)];
        switch(Math.floor(Math.random()*8)) {
            case 0: $(victim).hide("explode", {pieces:10},500);break;
            case 1: $(victim).effect("bounce",500);break;
            case 2: $(victim).effect("shake",500);break;
            case 3: $(victim).effect("fold",500);break;
            case 4: $(victim).show("pulsate",500);break;
            case 5: colorize($(victim));break;
            case 6: spacer($(victim));break;
            case 7: bilby_attack();break;
        }
    }

    function did_you_know(){
        $('#did_you_know').remove();
        $('#did_you_know_text').remove();
        $("body").append("<div id='did_you_know'></div><div id='did_you_know_text'></div>");
        var max = $('#did_you_know');
        var hint = $("#did_you_know_text");
        var offset = Math.floor(Math.random()*70);
        var hints = [
            "You can use POS to automatically schedule playlists.",
            "You can see the progress of KDM uploads on the Transfer Status page.", 
            "Packs are a handy way to add Ads to your playlists.",
            "Using intermission cues are a handy way to schedule intermissions during playback.",
            "You can view the content on all your devices by going to the 'All' page in the Content section.",
            "You can specify which playlists are scheduled for the start and end of the day in the Bookend Schedules section",
        ];
        $(max).show();
        $(hint).html("<span>"+ gettext("Did you know?") +"</span>" + hints[Math.floor(Math.random()*hints.length)]);
        switch(Math.floor(Math.random()*4)){
            case(0): $(max).css("left",offset+"%").css("top","-260px").removeClass().addClass("didyouknow_top").stop().animate({'top' : "0px"}, "fast", function(){$(hint).show(); $(hint).css("top","270px"); $(hint).css("left",offset+"%");}); break;
            case(1): $(max).css("left",offset+"%").css("bottom","-260px").removeClass().addClass("didyouknow_bottom").stop().animate({'bottom' : "0px"}, "fast", function(){$(hint).show(); $(hint).css("bottom","270px"); $(hint).css("left",offset+"%");}); break;
            case(2): $(max).css("top",offset+"%").css("left","-260px").removeClass().addClass("didyouknow_left").stop().animate({'left' : "0px"}, "fast", function(){$(hint).show(); $(hint).css("left","270px"); $(hint).css("top",offset+10+"%");}); break;
            case(3): $(max).css("top",offset+"%").css("right","-260px").removeClass().addClass("didyouknow_right").stop().animate({'right' : "30px"}, "fast", function(){$(hint).show(); $(hint).css("right","300px"); $(hint).css("top",offset+10+"%");}); break;
        }
        $('#did_you_know').on('click',yes_i_did_know);
        $('#did_you_know_text').on('click',yes_i_did_know);
    }

    function yes_i_did_know(){
        var max = $('#did_you_know');
        $("#did_you_know_text").remove();
        if($(max).stop().hasClass("didyouknow_top") == true){ $(max).stop().animate({'top' : "-260px"}, "fast", function(){$(max).remove();});
        }else if($(max).hasClass("didyouknow_bottom") == true){$(max).stop().animate({'bottom' : "-260px"}, "fast", function(){$(max).remove();});
        }else if($(max).hasClass("didyouknow_left")){$(max).stop().animate({'left' : "-260px"}, "fast", function(){$(max).remove();});
        }else{ $(max).stop().animate({'right' : "-260px"}, "fast", function(){$(max).remove();});}
    }
    function click_on_max(){
        if( enable_max == true ){
            $("body").append("<div id='did_you_know'></div>");
            var max = $('#did_you_know');
            var offset = Math.floor(Math.random()*70);
            $(max).show();
            score++;
            switch(Math.floor(Math.random()*4)){
                case(0): $(max).css("left",offset+"%").css("top","-260px").removeClass().addClass("didyouknow_top").stop().animate({'top' : "0px"}, "fast", yes_i_did_know); break;
                case(1): $(max).css("left",offset+"%").css("bottom","-260px").removeClass().addClass("didyouknow_bottom").stop().animate({'bottom' : "0px"}, "fast", yes_i_did_know); break;
                case(2): $(max).css("top",offset+"%").css("left","-260px").removeClass().addClass("didyouknow_left").stop().animate({'left' : "0px"}, "fast", yes_i_did_know); break;
                case(3): $(max).css("top",offset+"%").css("ri ght","-260px").removeClass().addClass("didyouknow_right").stop().animate({'right' : "30px"}, "fast", yes_i_did_know); break;
            }
            $('#did_you_know').on('click',function(){show_score(); enable_max = false; $(max).stop().fadeOut(3000, function(){$(max).remove();})});
            setTimeout(click_on_max, 1500);
        }
        enable_max = true;
    }
    function show_score(){
        $("body").append("<div id='score'></div>");
        $('#score').text("Well done! You Scored: " + score);
        score=0;
        setTimeout(function(){$('#score').fadeOut(1000, function(){$("#score").remove();})},2000 )
    }

    function napleon_dynamite() {
        $('<script src="/static/js/external/parallax.js"></script><link rel="stylesheet" href="/static/css/external/napleon.css" />').appendTo('head');
        $('<iframe width="0" height="0" src="//www.youtube.com/embed/vE4VlA_9OrI?autoplay=1&t=4s" frameborder="0" allowfullscreen></iframe>\
            <ul class="scene"><li class="layer" data-depth="0.2"><div class="stage"></div></li>\
            <li class="layer" data-depth="1.0"><article class="napleon clearfix">\
                    <div class="head"><div class="hair hair_left"></div><div class="face"><div class="glasses clearfix"><div class="lens left_lens"></div><div class="lens right_lens"></div><div class="bridge"></div></div><div class="lips"></div></div><div class="hair hair_right"></div></div>\
                    <div class="neck"></div>\
                    <div class="body"><div class="arm left_arm"><div class="sleeve"></div></div><div class="torso">Vote for Pedro</div><div class="arm right_arm"><div class="sleeve"></div></div><div style="clear: left;"></div></div>\
                    <div class="legs"><div class="hips"></div><div class="leg left_leg"><div class="foot"></div></div><div class="leg right_leg"><div class="foot"></div></div></div>\
                </article></li></ul>\\').appendTo('body');
        $('.scene').parallax();
    }
});
