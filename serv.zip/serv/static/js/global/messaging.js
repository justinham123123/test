function Site2SiteMessaging(){
    var self = this;
    self.complex_map = {};
    self.complex_list = [];
    self.messages = {};
    self.conversations = {};

    self.roster = [];
    self.selected_username = null;
    self.convo_reload = null;
    self.emoji_tip = null;

    $('#s2s_btn').live('click', function(){
        var roster = self.load_roster;
        $.when(roster()).then(function(){
            self.open_dialog();
        });
    });

    self.open_dialog = function(){
        self.connected = null;
        dialog.open({
            'title': gettext('Messaging'),
            'hbtemplate': s2s_base2_tmpl,
            'data': {
                'connected': self.connected,
                'roster': self.roster
            },
            close: self.close
        });

        $('#chat_reconnect_button').click(self.connect)

        self.conversation_loader = new Loader({
            target: "#conversation_wrapper"
        });

        self.emoji_tip = new EmojiTip({
            anchor: '#emoji_button',
            target: '#message_box_text'
        });

        function send(){
            var message_input = $('#message_box_text');
            var message = message_input.val();
            self.send(self.selected_username, message);
            message_input.val("");
        }

        $('#send_button').click(send);
        $('#message_box_text').keyup(function(event){
            if (event.keyCode == 13 && !event.shiftKey){
                send()
            }
        })

        $('#contacts_list .contact').click(function(){
            var dom = $(this);
            $('#contacts_list .contact.selected').removeClass("selected");
            dom.addClass("selected").removeClass('unread');
            self.select_conversation(dom.attr("data-username"));
        });

        $('#contacts_list .contact:first-child').click();

        $complex_status.chat.events.on('updated.dialog', function(e, data){
            self.update_status(data['data']);
        });
        $complex_status.chat.set_frequency(1);
    };

    self.close = function(){
        self.messages = {};
        self.conversations = {};

        $complex_status.chat.events.off('updated.dialog');
        $complex_status.chat.set_frequency(10);
    }

    self.connect = function(){
        return helpers.ajax_call({
            notify: false,
            url:'/core/messaging/start'
        });
    }

    self.update_status = function(data){
        var connected = false;
        for(var index in data['status']){
            var status = data['status'][index];
            if(status[0] == "live"){
                connected = status[1];
            }
        }
        if(self.connected != connected){
            self.connected = connected;
            self.update_connected();
        }
        for(var username in data['unread']){
            var unread = data['unread'][username];
            var updated = self.update_unread(username, unread);
            if(username === self.selected_username){
                self.convo_reload();
            }
            else if(updated){
                var contact_dom = $('#contacts_list .contact[data-username="'+username+'"]');
                contact_dom.addClass('unread');
                contact_dom.find('.unread_message_count').text(unread);
            }
        }
    }

    self.update_connected = function(){
        var text = self.connected ? gettext("Connected") : gettext("Disconnected");
        $('#chat_status_bar').toggleClass("connected", self.connected);
        $('#chat_status').text(text);
    }

    self.update_unread = function(username, count){
        var convo = self.conversations[username];
        if(convo === undefined){
            convo = {'unread': count};
            return true;
        }
        else if(convo['unread'] !== count){
            convo['unread'] = count;
            return true;
        }
        else{
            return false;
        }
    }

    self.load_roster = function(){
        return helpers.ajax_call({
            notify: false,
            url:'/core/messaging/get_roster',
            success_function: function(input){
                self.roster = input['data']['roster'];
                for(var i in self.roster){
                    var r = self.roster[i];
                    self.update_unread(r['username'], r['unread']);
                }                
            }
        });
    }

    self.select_conversation = function(username){
        self.selected_username = username;
        self.update_unread(username, 0);
        $('#message_box_text').val("");
        self.open_conversation(username);
    }

    self.open_conversation = function(username){
        $('#conversation').off('click.resend').on('click.resend', '.message_resend', function(e){
            var message = $(e.target).siblings('.message_wrapper').text();
            self.send(username, $.trim(message));
        });

        self.conversation_loader.show();
        self.convo_reload = function(){
            self.load_conversation(username);    
        }
        self.convo_reload();
        self.conversation_loader.hide();
    }

    self.load_conversation = function(username){
        return helpers.ajax_call({
            notify: false,
            data: {
                username: username
            },
            url:'/core/messaging/get_conversation',
            success_function: function(input){
                var messages = input['data']['messages'];
                $('#s2s_conversation_tmpl').tmpl2({'messages': messages}, '#conversation');
                var conv_dom = $('#conversation');
                conv_dom.minEmoji();
                conv_dom.scrollTop(conv_dom[0].scrollHeight);

            }
        });
    }

    self.send = function(username, message){
        if(message.length === 0 || !message.trim()){
            return;
        }
        helpers.ajax_call({
            notify: false,
            data: {
                username: username,
                body: message
            },
            url:'/core/messaging/send_message',
            loader: {
                'target': "#new_thread_wrapper",
                'caption': gettext("Sending")
            },
            success_function: function(input){
                self.open_conversation(username);
            }
        });
    }
}