/**
 * All Handlebars helpers go here
 */
Handlebars.registerHelper('trans', function(string, options) {
    var trans = gettext(string);
    for(var o in options.hash){
        trans = trans.replace("%"+o, options.hash[o]);
    }
    return new Handlebars.SafeString(trans);
});

Handlebars.registerHelper('device_name', function(device_uuid) {
    return new Handlebars.SafeString(
        helpers.get_device_name(device_uuid)
    );
});

Handlebars.registerHelper('pretty_device_type', function(name) {
    return new Handlebars.SafeString(
        pretty_device_types[name]
    );
});

Handlebars.registerHelper('placeholder_types', function(name) {
    return new Handlebars.SafeString(
        placeholder_types[name].toUpperCase()
    );
});

Handlebars.registerHelper('seconds_to_duration', function(seconds) {
    return new Handlebars.SafeString(
        $.seconds_to_duration_string(seconds)
    );
});

Handlebars.registerHelper('join', function(list, separator) {
    return list.join(separator);
});

Handlebars.registerHelper('len', function(iter) {
    return iter.length;
});

Handlebars.registerHelper('sum', function() {
    var sum = 0, v;
    for(var i=0; i<arguments.length; i++){
        v = parseFloat(arguments[i]);
        if(!isNaN(v)){
            sum += v;
        }
    }
    return sum;
});

Handlebars.registerHelper('math', function(lvalue, operator, rvalue, options) {
    lvalue = parseFloat(lvalue);
    rvalue = parseFloat(rvalue);

    return {
        '+': lvalue + rvalue,
        '-': lvalue - rvalue,
        '*': lvalue * rvalue,
        '/': lvalue / rvalue,
        '%': lvalue % rvalue
    }[operator];
});

Handlebars.registerHelper('undef', function(x, options) {
   return  x === undefined ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('notundef', function(x, options) {
   return  x !== undefined ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('exists', function(variable, options) {
    return typeof variable !== 'undefined' ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('eq', function(x, y, options) {
    return x === y ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('uneq', function(x, y, options) {
    return x !== y ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('gt', function(x, y, options) {
    return x > y ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('notnull', function(x, options){
    return (x !== undefined && x !== null) ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('inarray', function(x, arr, options){
    return arr.indexOf(x) > -1 ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('emptyobj', function(obj, options){
    return Object.keys(obj).length === 0 ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('unemptyobj', function(obj, options){
    return Object.keys(obj).length > 0 ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('nan', function(num, options) {
    return isNaN(num) ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('valordef', function(x, def){
    return x === undefined || x === null ? def : x;
});

Handlebars.registerHelper('allowed', function(action, options){
    return helpers.is_allowed(action) ? options.fn() : options.inverse();
});

Handlebars.registerHelper('scw_plus', function(options){
    return screenwriter_plus ? options.fn() : options.inverse();
});

Handlebars.registerHelper('allow_auto', function(options){
    return $complex_status.allow_auto ? options.fn() : options.inverse();
});

Handlebars.registerHelper('lower', function(string){
    if(string){
        return new Handlebars.SafeString(
            string.toLowerCase()
        );
    }
});
Handlebars.registerHelper('upper', function(string){
    if(string){
        return new Handlebars.SafeString( string.toUpperCase() );
    }
});

Handlebars.registerHelper('print', function(string){
    console.log(string);
});

Handlebars.registerHelper('pretty_duration', function(duration) {
	return helpers.pretty_duration_string(duration);
});

Handlebars.registerHelper('or_eq', function(arg1, arg2) {
	return arg1 || arg2;
});
Handlebars.registerHelper('neg', function(num) {
	return -num;
});
Handlebars.registerHelper('div', function(num, divisor) {
	return num / divisor;
});

Handlebars.registerHelper('in_array', function(item, arr, options) {
	return $._in(item, arr) ? options.fn(this) : options.inverse(this);
});
Handlebars.registerHelper('nin_array', function(item, arr, options) {
	return !$._in(item, arr) ? options.fn(this) : options.inverse(this);
});
Handlebars.registerHelper('valid_array', function(arr, options) {
	return (arr && arr.length > 0) ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('truncate', function(str, len) {
	return new Handlebars.SafeString(str.slice(0, len));
});

Handlebars.registerHelper('get_property_equals', function(obj, property, eq, options) {
	return (obj && obj[property] === eq) ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('property', function(obj, property) {
    return obj[property];
});

Handlebars.registerHelper('tmpl', function(id, options){
    var data = {};
    var hash = options['hash'];
    if(Object.keys(hash).length === 1 && hash['context']){
        data = hash['context'];
    }
    else{
        data = hash;
    }
    return new Handlebars.SafeString($(id).tmpl2(data).outer_html());
});

Handlebars.registerHelper('oldtmpl', function(id, options){
    var data = {};
    var hash = options['hash'];
    if(Object.keys(hash).length === 1 && hash['context']){
        data = hash['context'];
    }
    else{
        data = hash;
    }
    return new Handlebars.SafeString($(id).tmpl(data).outer_html());
});

Handlebars.registerHelper('date', function(date, format){
    return date.getDate() + " " + months[date.getMonth()];
});

Handlebars.registerHelper('moment', function(date, format){
    var mom = moment(date);
    return mom.format(format);
});
Handlebars.registerHelper('unix', function(unix, format){
    var mom = moment.unix(unix);
    return mom.format(format);
});

Handlebars.registerHelper('round', function(val, dp){
    return val.toFixed(dp);
});

Handlebars.registerHelper('calendar', function(date, seconds){
    if(seconds === true){
        date = date * 1000;
    }
    return moment(date).calendar();
});

Handlebars.registerHelper('duration', function(duration){
    return $.seconds_to_duration_string(duration);
});

Handlebars.registerHelper('show_attribute', function(string){
    if(!string){
        return '';
    }
    var icon_class = string.toLowerCase();
    switch(string){
        case '3D': icon_class = 'icon-three-d'; break;
    }
    return icon_class ;
});

Handlebars.registerHelper('content_attribute', function(attribute, options){
    if(!attribute){
        return '';
    }
    switch(attribute){
        case '3D': attribute = 'icon-three-d'; break;
    }
    var html = $('#content_attribute_tmpl').raw_tmpl({
        attribute: attribute,
        title: options.hash.title
    });
    return new Handlebars.SafeString(html);
});

Handlebars.registerHelper('framerate', function(edit_rate){
    if(!edit_rate || !edit_rate[0] || edit_rate[0] == 24){
        return '';
    }
    var html = $('#content_attribute_tmpl').raw_tmpl({
        attribute: 'icon-framerate-' + edit_rate[0]
    });
    return new Handlebars.SafeString(html);
});

Handlebars.registerHelper('subtitled', function(country_code, options){
    if(!country_code){
        return '';
    }
    var html = $('#flag_tmpl').tmpl({
        flag_name: country_code
    }).outer_html();
    return new Handlebars.SafeString(html);
});

Handlebars.registerHelper('rating', function(rating, territory, hardlocked){
    var hardlock = hardlocked ? gettext("Rating Included") : '';
    if(!rating && rating !== 'XX'){
        return new Handlebars.SafeString(hardlock);
    }
    var html = $('#content_rating_tmpl').raw_tmpl({
        rate: rating,
        territory: territory,
        hardlock: hardlock
    });
    return new Handlebars.SafeString(html);
});

Handlebars.registerHelper('display_bytes', function(bytes) {
	return helpers.display_bytes(bytes);
});
Handlebars.registerHelper('img_tmpl', function(attr) {
	return $('#image_tmpl').tmpl(helpers._get_image_attribute(attr)).outer_html();
});

Handlebars.registerHelper('automation_trigger_list', function(automation, options) {
	var autos = [];
	var all_autos = $.isEmptyObject(playlist_edit_page.automation) ? pack_edit_page.automation : playlist_edit_page.automation;
	$.each(all_autos, function(d_id, automations) {
		$.each(automations, function(automation_id, _automation) {
			if(automation_id !== 'last_updated' && _automation.type === 'cue') {
				if(automation.type_specific && automation.type_specific.action === _automation.name) {
					_automation.selected = true;
				}
				autos.push(_automation);
			}
		});
	});
	var ret = '';
	for(var i=0; i < autos.length; i++) {
		ret += options.fn(autos[i]);
	}
	return ret;
});

Handlebars.registerHelper('automation_gdc_start_list', function(automation, options) {
	var autos = [];
	$.each(playlist_edit_page.automation[playlist_edit_page.server_id], function(automation_id, _automation) {
		if(_automation.type === 'cue') {
			if(automation.type_specific && automation.type_specific.action === _automation.name) {
				_automation.selected = true;
			}
			autos.push(_automation);
		}
	});
	var ret = '';
	for(var i=0; i < autos.length; i++) {
		ret += options.fn(autos[i]);
	}
	return ret;
});

Handlebars.registerHelper('disk_space_rgb', function(percentage, warn_level, full_level) {
    return new Handlebars.SafeString(helpers.disk_space_rgb(percentage, warn_level, full_level));
});

Handlebars.registerHelper('complex_status_attr', function(attr) {
    return $complex_status[attr];
});

Handlebars.registerHelper('percent_avail', function(num, divisor) {
    return Math.round(num * 100/divisor);
});

Handlebars.registerHelper('is_sms_lms', function(category, options) {
    return $._in(category, ['sms', 'lms']) ? options.fn(this) : options.inverse(this);
});
