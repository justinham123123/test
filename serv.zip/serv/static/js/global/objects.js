function Device(arguments)
{
    if (arguments === undefined) {
        arguments = {};
    }
    this.id = $.val_or_undefined(arguments.id);
    this.category = $.val_or_undefined(arguments.category);
    this.type = $.val_or_undefined(arguments.type);
    this.model = $.val_or_undefined(arguments.model);
    this.enabled = $.val_or_undefined(arguments.enabled);
    this.ip = $.val_or_undefined(arguments.ip);
    this.port = $.val_or_undefined(arguments.port);
    this.api_username = $.val_or_undefined(arguments.api_username);
    this.api_password = $.val_or_undefined(arguments.api_password);
    this.ftp_ip = $.val_or_undefined(arguments.ftp_ip);
    this.ftp_port = $.val_or_undefined(arguments.ftp_port);
    this.ftp_username = $.val_or_undefined(arguments.ftp_username);
    this.ftp_password = $.val_or_undefined(arguments.ftp_password);
    this.time = $.val_or_undefined(arguments.time);
    this.time_ref = $.val_or_undefined(arguments.time_ref);
    this.cert_path = $.val_or_undefined(arguments.cert_path);

    this.name = $.val_or_undefined(arguments.name);
    this.path = $.val_or_undefined(arguments.path);
    this.screen_uuid = $.val_or_undefined(arguments.screen_uuid);
    this.sync_active = $.val_or_undefined(arguments.sync_active);
    this.content_scan_active = arguments.content_scan_active;
    this.content_scan_stamp = arguments.content_scan_stamp;
    this.content_scan_remaining = arguments.content_scan_remaining;
    this.content_scan_done = arguments.content_scan_done;
    this.initial_sync_complete = arguments.initial_sync_complete;
    this.auto_sync = $.val_or_undefined(arguments.auto_sync);
    this.auto_ingest = $.val_or_undefined(arguments.auto_ingest);
    this.version = $.val_or_undefined(arguments.version);
    this.transfer_methods = $.val_or_default(arguments.transfer_methods, []);
    this.custom = $.val_or_undefined(arguments.custom);

    this.update_status = function(updates){
        this.status = $.val_or_undefined(updates.status);
        this.alive = $.val_or_default(updates.alive, true);
        this.current_time = $.val_or_undefined(updates.current_time);
        this.last_updated = $.val_or_undefined(updates.last_updated);
        this.messages = $.val_or_undefined(updates.messages);
        this.error_messages = $.val_or_undefined(updates.error_messages);
    }

    //Loaded by ajax separately. Left undefined here to make bugs more obvious
    this.supported_modes = undefined;

    //Add Device Power to device_info[projector_status]???
    this.projector_status = $.val_or_undefined(arguments.projector_status);

    //Serial number info etc...
    this.device_information = $.val_or_undefined(arguments.device_information);

    this.update = function(updates) {
        this.id = $.val_or_undefined(updates.id);
        this.type = $.val_or_undefined(updates.type);
        this.model = $.val_or_undefined(updates.model);
        this.enabled = $.val_or_undefined(updates.enabled);
        this.ip = $.val_or_undefined(updates.ip);
        this.port = $.val_or_undefined(updates.port);
        this.api_username = $.val_or_undefined(updates.api_username);
        this.api_password = $.val_or_undefined(updates.api_password);
        this.ftp_ip = $.val_or_undefined(updates.ftp_ip);
        this.ftp_port = $.val_or_undefined(updates.ftp_port);
        this.ftp_username = $.val_or_undefined(updates.ftp_username);
        this.ftp_password = $.val_or_undefined(updates.ftp_password);
        this.cert_path = $.val_or_undefined(updates.cert_path);
        if (updates.time !== undefined) {
            this.time = updates.time;
        }
        if (updates.time_ref !== undefined) {
            this.time_ref = $.val_or_undefined(updates.time_ref);
        }

        this.name = $.val_or_undefined(updates.name);
        this.path = $.val_or_undefined(updates.path);
        this.screen_uuid = $.val_or_undefined(updates.screen_uuid);
        this.sync_active = $.val_or_undefined(updates.sync_active);
        this.content_scan_remaining = updates.content_scan_remaining;
        this.content_scan_done = updates.content_scan_done;
        this.content_scan_active = updates.content_scan_active;
        this.content_scan_stamp = updates.content_scan_stamp;
        this.initial_sync_complete = updates.initial_sync_complete;
        this.auto_sync = $.val_or_undefined(updates.auto_sync);
        this.auto_ingest = $.val_or_undefined(updates.auto_ingest);
        if(updates.device_information){
            this.device_information = updates.device_information;
        }
        if(updates.version){
            this.version = updates.version;
        }
    }

    this.screen = function(){
        if(this.screen_uuid){
            return $device_store.screens[this.screen_uuid]
        }
    };

    //this is for displaying via tmpl only!
    this.attr = {'type':'device_id', 'value':this.id};

    if(this.sync_active){
        this.sync_attr = {name: 'sync_on', attr: this.attr};
    }else{
        this.sync_attr = {name: 'sync_off', attr: this.attr};
    }

    this.return_saveable = function() {
        var save_me = {}
        save_me.uuid = this.id;
        save_me.type = this.type;
        save_me.model = this.model;
        save_me.enabled = this.enabled;
        save_me.ip = this.ip;
        save_me.port = this.port;
        save_me.api_username = this.api_username;
        save_me.api_password = this.api_password;
        save_me.ftp_ip = this.ftp_ip;
        save_me.ftp_port = this.ftp_port;
        save_me.ftp_username = this.ftp_username;
        save_me.ftp_password = this.ftp_password;
        save_me.name = this.name;
        save_me.path = this.path;
        save_me.screen_uuid = this.screen_uuid;
        save_me.category = this.category;
        save_me.cert_path = this.cert_path;
        return save_me;
    };
}

function ScreenType(uuid, name){
    this.uuid = uuid;
    this.name = name;

    this.return_saveable = function() {
        var save_me = {}
        save_me.uuid = this.uuid;
        save_me.name = this.name;

        return save_me;
    };
}

function ShowType(uuid, name, colour){
    this.uuid = uuid;
    this.name = name;
    this.colour = colour;
    this.return_saveable = function() {
        var save_me = {}
        save_me.uuid = this.uuid;
        save_me.name = this.name;
        save_me.colour = this.colour;
        return save_me;
    };
}


/*
 * Screen
 * 3D and HOH are separate to the list of capabilities, since they are not ordered, they just are
 */

function Screen(screen_object)
{
    this.devices = [];
    this.capabilities = [];
    this.show_attributes = [];

    if(screen_object){
        this.uuid = screen_object.uuid;
        this.identifier = screen_object.identifier;
        this.title = screen_object.title;
        this.three_d = screen_object.three_d;
        this.screen_type_uuid = screen_object.screen_type_uuid;
        this.show_attributes = screen_object.show_attributes;
        this.capacity = screen_object.capacity;

        for (var i =0; i < screen_object.capabilities.length; i++) {
            this.capabilities.push(new ScreenCapability(screen_object.capabilities[i]));
        }

        for (var i =0; i < screen_object.devices.length; i++) {
            if($device_store.devices[screen_object.devices[i]] != undefined){
                this.devices.push($device_store.devices[screen_object.devices[i]]);
            }
        }
    }

    //this is for displaying via tmpl only!
    this.attr = {'type':'screen_uuid', 'value':this.uuid}

    this.has_capability = function(name){
        for (id in this.capabilities) {
            if(this.capabilities[id].name == name){
                return true;
            }
        }
        return false;
    }

    this.return_saveable = function() {
        var save_me = {}
        save_me.uuid = this.uuid;
        save_me.identifier = this.identifier;
        save_me.title = this.title;
        save_me.three_d = this.three_d;
        save_me.screen_type_uuid = this.screen_type_uuid;
        save_me.show_attributes = this.show_attributes;
        save_me.capacity = this.capacity;

        save_me.capabilities = [];
        for (id in this.capabilities) {
            save_me.capabilities.push(this.capabilities[id].return_saveable())
        }

        return save_me;
    }

    this.audio_device = function() {
        var i, device;
        for (i=0; i<this.devices.length; i++) {
            device = this.devices[i];
            if (device.category == 'audio' && device.enabled) {
                return device;
            }
        }
        return null;
    }

    this.active_camera = function() {
        var i, device;
        for (i=0; i<this.devices.length; i++) {
            device = this.devices[i];
            if (device.category == 'camera' && device.enabled) {
                return device;
            }
        }
        return null;
    }
}

/*
 * Screen capability : hi, vi, cc, audio
 * Only audio at this point has a value. We are goign to assume for now
 * if an audio capability is added the default is 5.1 Who knows if this is right?? i don't!
 * but i am doing it anyways.
 */
function ScreenCapability(capability_object){
    this.name = capability_object.name;
    if (capability_object.value){
        this.value = capability_object.value;
    }else{
        //default to 5.1 if this is audio
        if(capability_object.name == 'audio'){
            this.value = '5.1';
        }
    }
    this.display_name = screen_capabilities[this.name].display_name;

    this.return_saveable = function() {
        var save_me = {}
        save_me.name = this.name;
        save_me.value = this.value;

        return save_me;
    }
}

function Playlist(playlist_object, automation_dictionary){
    if (automation_dictionary == undefined) automation_dictionary = {};
    this.uuid = playlist_object.id || undefined;
    this.title = playlist_object.title || "";
    this.has_intermission = false;
    this.has_show_start = false;
    this.has_credits = false;
    this.duration_in_seconds = playlist_object.duration_in_seconds || 0;
    this.duration_in_frames = playlist_object.duration_in_frames || 0;
    this.show_start_offset = playlist_object.show_start_offset || 0;
    this.countdowns = {
        'major':[],
        'other':[]
    };
    this.is_template = false; //Set in events parsing
    this.templating_issues = playlist_object.templating_issues != undefined && playlist_object.templating_issues.length > 0 ? playlist_object.templating_issues : [];
    this.is_3d = playlist_object.is_3d || false;
    this.is_hfr = playlist_object.is_hfr || false;
    this.is_4k = playlist_object.is_4k || false;
    this.pos_match = playlist_object.pos_match || undefined;
    this.automation = [];
    this.events = [];

    if(playlist_object !== undefined){
        if(playlist_object.error_messages !== undefined){
            this.error_message = playlist_object.error_messages;
        }
    }

    if(playlist_object.automation != undefined){
        for (var i =0; i < playlist_object.automation.length; i++){
            this.automation.push(new PlaylistCompositionAutomation(playlist_object.automation[i], automation_dictionary));
        }
    }

    if(playlist_object.events != undefined){
        for (var i =0; i < playlist_object.events.length; i++){
            var event = playlist_object.events[i];
            switch(event.type){
                case 'composition':
                    this.events.push(new PlaylistCompositionEvent(event, automation_dictionary));
                    break;
                case 'pattern':
                    this.events.push(new PlaylistPatternEvent(event, automation_dictionary));
                    break;
                case 'placeholder':
                    this.events.push(new PlaylistEvent('placeholder', event));
                    this.is_template = true;
                    break;
                case 'title':
                    this.events.push(new PlaylistEvent('title', event));
                    this.is_template = true;
                    break;
                case 'macro_pack':
                    this.events.push(new PlaylistEvent('macro_pack', event));
                    break;
            }
        }
    }

    this.add_event = function(position, event){
        this.events.splice(position, 0, event);
        if(event['playback_mode'] && event['playback_mode'] == "three_d"){
            this.is_3d = true;
        }
        if(event['edit_rate'] && event['edit_rate'][0] > HFR_FPS){
            this.is_hfr = true;
        }
        // Check for _4K_ in the title just because our parser doesn't seem to always pick it up
        if((event['resolution'] && event['resolution'] == '4K') || this.title.indexOf('_4K_') != -1){
            this.is_4k = true;
        }
    };

    this.remove_event = function(position){
        this.events.splice(position, 1);
        var is_3d = false;
        var is_hfr = false;
        var is_4k = false;

        if(this.is_3d || this.is_hfr || this.is_4k){
            for(var i in this.events){
                var event = this.events[i];
                if(event['playback_mode'] && event['playback_mode'] == "three_d"){
                    is_3d = true;
                }
                if(event['edit_rate'] && event['edit_rate'][0] > HFR_FPS){
                    is_hfr = true;
                }
                if((event['resolution'] && event['resolution'] == '4K') || this.title.indexOf('_4K_') != -1){
                    is_4k = true;
                }
            }
            if(this.is_3d)
                this.is_3d = is_3d;
            if(this.is_hfr)
                this.is_hfr = is_hfr;
            if(this.is_4k)
                this.is_4k = is_4k;
        }
    };

    this.calculate_start_times = function() {
        var automation, start_time, added;
        //In seconds
        start_time = 0;
        for (var i =0 ; i < this.events.length; i++) {
            this.events[i].start_time = start_time;
            for (var j =0 ; j < this.events[i].automation.length; j++) {
                added = false;
                automation = this.events[i].automation[j];
                if ($.inArray(automation.type, ['cue','volume','wait_for_input', 'qube', 'sony_cue', 'sony_function', 'intermission']) !== -1) {
                    if (automation.type_specific.offset_in_seconds != null) {
                        if (automation.type_specific.offset_from == 'start') {
                            automation.start_time = start_time + automation.type_specific.offset_in_seconds;
                        } 
                        else if (automation.type_specific.offset_from == 'end') {
                            automation.start_time = start_time + this.events[i].duration_in_seconds - automation.type_specific.offset_in_seconds;
                        } 
                        // Assume offset from start if none specified
                        else {
                            automation.start_time = start_time + automation.type_specific.offset_in_seconds;
                        }
                    } 
                    else {
                        //TODO set some kind of error flag to 1) to show the user the info hasn't loaded yet/has an error  2) to prevent the null values being saved over the real ones
                        automation.start_time = null;
                    }

                    if (AUTOMATION_CONFIGURATION['automation_configuration'] && AUTOMATION_CONFIGURATION['automation_configuration'][automation.name] !== undefined) {
                        if (AUTOMATION_CONFIGURATION['automation_configuration'][automation.name].show_start) {
                            this.countdowns['major'].push({'name':gettext('Show Start'), 'type': 'show_start', 'relative_start': automation.start_time});
                            //only the first show_start cue can count.
                            if (this.has_show_start == false) {
                                this.show_start_offset = automation.start_time;
                            }
                            this.has_show_start = true;
                            added = true;
                        }
                        else if (AUTOMATION_CONFIGURATION['automation_configuration'][automation.name].intermission) {
                            this.countdowns['major'].push({'name':gettext('Intermission'), 'type': 'intermission', 'relative_start': automation.start_time});
                            this.has_intermission = true;
                            added = true;
                        }
                        else if (AUTOMATION_CONFIGURATION['automation_configuration'][automation.name].credits) {
                            this.countdowns['major'].push({'name':gettext('Credits'), 'type': 'credits', 'relative_start': automation.start_time});
                            this.has_credits = true;
                            added = true;
                        }
                    }
                    if (!added) {
                        this.countdowns['other'].push({'name':automation.name,'relative_start': automation.start_time});
                    }
                }
            }
            if (this.events[i].duration_in_seconds != undefined)
                start_time += this.events[i].duration_in_seconds;
            if (this.events[i].content_kind === 'feature') {
                this.countdowns['major'].push({
                    'name':gettext('Feature start'),
                    'type': 'feature_start',
                    'relative_start':this.events[i].start_time
                });
            }
        }
        this.duration_in_seconds = start_time;
    }

    this.sort_automation = function() {
        this.automation = this.automation.sort(helpers.automation_sort);
    };

    this.return_saveable = function(is_3d_override, is_hfr_override) {
        var save_me = {}
        save_me.id = this.uuid;
        save_me.duration_in_seconds = this.duration_in_seconds;
        save_me.title = this.title;
        save_me.events = [];
        var is_3d = false,
            is_hfr = false;
        for (var i =0; i < this.events.length; i++) {
            save_me.events.push(this.events[i].return_saveable())
            if(save_me.events[i].playback_mode == "3D")
                is_3d = true;
            if (save_me.events[i].edit_rate != null && save_me.events[i].edit_rate[0] > HFR_FPS)
                is_hfr = true;
        }
        if(is_3d_override != undefined){
            is_3d = is_3d_override;
        }
        if (is_hfr_override != undefined) {
           is_hfr = is_hfr_override;
        }
        save_me.is_3d = is_3d;
        save_me.is_hfr = is_hfr;
        save_me.is_4k = this.is_4k;
        save_me.automation = [];
        for (var i =0; i < this.automation.length; i++) {
            save_me.automation.push(this.automation[i].return_saveable())
        }
        
        if( this.pos_match != undefined){
            save_me.pos_match = this.pos_match;
        }
        return save_me;
    }
}

function PlaylistEvent(type, event)
{
    this.type = type;
    this.content_kind = type;
    this.title = event.text || event.name;
    this.uuid = event.uuid;
    this.credit_offset = event.credit_offset;

    this.automation = [];

    this.sort_automation = function()
    {
        this.automation = this.automation.sort(helpers.automation_sort);
    }

    if (event && event.automation != undefined)
    {
        for(var i=0; i < event.automation.length; i++)
        {
            this.automation.push(new PlaylistCompositionAutomation(event.automation[i]));
        }
        this.sort_automation();
    }

    this.return_saveable = function()
    {
        var save_me = {};
        save_me.type = this.type;
        save_me.uuid = this.uuid;
        save_me.text = this.title;
        save_me.credit_offset = this.credit_offset;
        save_me.automation = [];
        for (var i =0; i < this.automation.length; i++)
        {
            save_me.automation.push(this.automation[i].return_saveable())
        }
        return save_me;
    }
}

function PlaylistCompositionEvent(cpl, automation_dictionary) {
    this.type = 'composition';
    this.automation = [];
    this.cpl_id = cpl.cpl_id || cpl.uuid;
    this.duration_in_frames = cpl.duration_in_frames;
    this.duration_in_seconds = cpl.duration_in_seconds;
    this.title = cpl.content_title_text || cpl.text;
    this.edit_rate = cpl.edit_rate;
    this.content_kind = cpl.content_kind ? cpl.content_kind : 'unknown';
    this.credit_offset = cpl.credits_offset;
    this.rating = cpl.rating;
    this.territory = cpl.territory;
    this.resolution = cpl.resolution;
    this.subtitled = cpl.subtitled ? cpl.subtitle_language : undefined;
    
    if(this.duration_in_seconds === null && this.duration_in_frames !== undefined && this.edit_rate !== undefined){
        this.duration_in_seconds = this.duration_in_frames/(this.edit_rate[0]/this.edit_rate[1]);
    }
    
    if (cpl.rating){
        this.rating = cpl.rating;
    }

    if (cpl.territory){
        this.territory = cpl.territory;
    }
    
    if (cpl.rating_hardlocked){
        this.rating_hardlocked = cpl.rating_hardlocked;
    }   

    if (cpl.encrypted)
        this.encrypted = 'kdm_content_invalid';

    if (cpl.playback_mode === '3D') {
        this.playback_mode = 'three_d';
    }   
    else {
        this.playback_mode = 'two_d'
    }
    if (cpl.validation != undefined) {
        if (cpl.validation['error_messages']){
            this.validation_error = 'content_issue';
            this.validation_info = gettext("CPL does not exist on this server");
        }
        else{
            if (cpl.validation.validation_code !== 0){
                validation_code = cpl.validation.validation_code;
                validation_info = helpers.content_status_info(validation_code);
                this.validation_error = validation_info.status;
                this.validation_info = validation_info.info;
            }
            else{
                this.validation_error = undefined;
            }
        }

        if (cpl.encrypted) {
            this.encrypted = helpers.get_kdm_icon_class(cpl.validation.valid_now, cpl.validation.valid_in_future,
                cpl.validation.expires_in_24);
        }
    }
    //content is not on any server in complex
    else if (cpl['error_messages']){
        this.validation_error = 'content_issue';
        this.validation_info = gettext("CPL does not exist on any server in the complex");
    }

    this.sort_automation = function(){
        this.automation = this.automation.sort(helpers.automation_sort);
    }

    if (cpl.automation!== undefined) {
        for(var i=0; i < cpl.automation.length; i++) {
            this.automation.push(new PlaylistCompositionAutomation(cpl.automation[i], automation_dictionary));
        }
        this.sort_automation();
    }

    this.has_gdc_start_cue = function() {
        for (var i=0; i<this.automation.length; i++) {
            if (this.automation[i].type == 'gdc_start_cue') {
                return true
            }
        }
        return false;
    };

    this.return_saveable = function() {
        var save_me = {}
        save_me.type = this.type;
        save_me.cpl_id = this.cpl_id;
        save_me.duration_in_seconds = this.duration_in_seconds;
        save_me.duration_in_frames = this.duration_in_frames;
        save_me.edit_rate = this.edit_rate;
        save_me.text = this.title;
        save_me.playback_mode = (this.playback_mode == 'three_d')?'3D':'2D';
        save_me.content_kind = this.content_kind;
        if (this.subtitled){
            save_me.subtitled = this.subtitled;
            save_me.subtitle_language = this.subtitle_language;
        }
        save_me.automation = [];
        for (var i =0; i < this.automation.length; i++) {
            save_me.automation.push(this.automation[i].return_saveable())
        }
        return save_me;
    }
}

function PlaylistPatternEvent(playlist_event_object, automation_dictionary) {
    this.type = 'pattern';
    this.content_kind = 'pattern';
    this.automation = [];
    this.edit_rate = [24, 1];
    if (playlist_event_object.edit_rate && playlist_event_object.edit_rate[0] && playlist_event_object.edit_rate[1]) {
        this.edit_rate[0] = playlist_event_object.edit_rate[0];
        this.edit_rate[1] = playlist_event_object.edit_rate[1];
    } else if (playlist_event_object.text === 'Black 3D 48') {
        this.edit_rate[0] = 48;
        this.edit_rate[1] = 1;
    }
    this.duration_in_frames = (playlist_event_object.duration_in_frames===undefined)?(playlist_event_object.duration_in_seconds*this.edit_rate[0]/this.edit_rate[1]):playlist_event_object.duration_in_frames;

    this.title = playlist_event_object.text;
    this.playback_mode = (playlist_event_object.text==='Black 3D' || playlist_event_object.text==='Black 3D 48')?'icon-three-d':'icon-two-d';

    this.duration_in_seconds = this.duration_in_frames / (this.edit_rate[0] / this.edit_rate[1]);

    this.sort_automation = function(){
        this.automation = this.automation.sort(helpers.automation_sort);
    }

    if (playlist_event_object.automation!== undefined) {
        for(var i=0; i < playlist_event_object.automation.length; i++) {
            this.automation.push(new PlaylistCompositionAutomation(playlist_event_object.automation[i], automation_dictionary));
        }
        this.sort_automation();
    }

    this.return_saveable = function() {
        var save_me = {}
        save_me.type = this.type;
        save_me.duration_in_frames = this.duration_in_frames;
        save_me.duration_in_seconds = this.duration_in_seconds;
        save_me.edit_rate = this.edit_rate;
        save_me.text = this.title;
        save_me.automation = [];
        for (var i =0; i < this.automation.length; i++) {
            save_me.automation.push(this.automation[i].return_saveable())
        }
        return save_me;
    }
}

function PlaylistCompositionAutomation(playlist_automation_object, automation_dictionary) {
    //note we do not use id here, its meaningless to us. it is uniquely generated for each cue seperately,
    //id in this context does NOT mean automation id!
    this.name = playlist_automation_object.name;
    this.type = playlist_automation_object.type;
    this.is_intermission = false;
    this.is_show_start   = false;
    this.is_credits   = false;
    if(automation_dictionary != null && !$.isEmptyObject(automation_dictionary)){
        this.exists_on_device = automation_dictionary[this.name+this.type] ? true : false;
    }else{
        this.exists_on_device = true; // This is the LMS so we dont want to validate the automation
    }

    if (AUTOMATION_CONFIGURATION['automation_configuration'] && AUTOMATION_CONFIGURATION['automation_configuration'][this.name] !== undefined) {
        if (AUTOMATION_CONFIGURATION['automation_configuration'][this.name].show_start) {
            this.is_show_start = true;
        }
        if (AUTOMATION_CONFIGURATION['automation_configuration'][this.name].intermission) {
            this.is_intermission = true;
        }
        if (AUTOMATION_CONFIGURATION['automation_configuration'][this.name].credits) {
            this.is_credits = true;
        }
    }

    this.type_specific = playlist_automation_object.type_specific || {};

    this.return_saveable = function() {
        var save_me = {}
        save_me.name = this.name;
        save_me.type = this.type;
        save_me.type_specific = this.type_specific;
        return save_me;
    }
}

function PackObject(pack_object){
    var self = this;
    var pack_object = $.val_or_default(pack_object, {})
    $.extend(this, {
        uuid: null,
        duration_in_seconds: 0,
        name: null,
        title_uuid: null,
        title_name: null,
        priority: null,
        date_from: null,
        date_to: null,
        time_from: null,
        time_to: null,
        screen_type_uuid: null,
        show_type_uuid: null,
        screen_type: null,
        show_type: null,
        placeholder_uuid: null,
        placeholder_name: null,
        print_no: null,
        ratings: [],
        screen_external_ids: null,
        external_show_attribute_maps: [], 
        issuer: null
    }, pack_object);

    self.screens = {};
    for (var i =0; i < $.val_or_default(pack_object.screens, []).length; i++) {
        self.screens[pack_object.screens[i]] = true;
    }

    self.clips = [];
    for (var i =0; i < $.val_or_default(pack_object.clips, []).length; i++) {
        switch(pack_object.clips[i].type){
        case 'composition':
            var pack = new PlaylistCompositionEvent(pack_object.clips[i]);
            self.clips.push(pack);
            break;
        case 'pattern':
            var patt = new PlaylistPatternEvent(pack_object.clips[i]);
            self.clips.push(patt);
            break;
        }
    }

    this.calculate_start_times = function() {
        var start_time = 0;
        for (var i =0 ; i < this.clips.length; i++) {
            this.clips[i].start_time = start_time;
            start_time += this.clips[i].duration_in_seconds;
        }
        this.duration_in_seconds = start_time;
    }

    this.add_clip = function(clip, at){
        var clip_obj;
        switch(clip.type){
        case 'composition':
            clip_obj = new PlaylistCompositionEvent(clip);
            break;
        case 'pattern':
            clip_obj = new PlaylistPatternEvent(clip);
            break;
        }
        this.clips.splice(at, 0, clip_obj);
        this.calculate_start_times();
    }
    
    this.has_unknown_show_attr = function(){
        for (var uuid in this.external_show_attribute_maps) {
            if (this.external_show_attribute_maps[uuid].show_attribute_uuid == null) {
                return true;
            }
        }
        return false;
    }

    this.get_date_display = function(){
        ret = '';
        if (this.date_from == undefined && this.date_to == undefined) {
            ret = '';
        }else if (this.date_from == undefined) {
            ret = gettext('Before %date_end').replace(/%date_end/,this.date_to);
        }else if (this.date_to == undefined) {
            ret = gettext('After %date_from').replace(/%date_from/,this.date_from)
        }else {
            ret = gettext('%date_from - %date_end').replace(/%date_from/,this.date_from).replace(/%date_end/,this.date_to)
        }
        return ret;
     }

     this.get_time_display = function(){
        ret = '';
        if (this.time_from == undefined && this.time_to == undefined) {
            ret = '';
        }else if (this.time_from == undefined) {
            ret = ('Before %date_end').replace(/%date_end/,this.time_to)
        }else if (this.time_to == undefined) {
            ret = ('After %date_from').replace(/%date_from/,this.time_from)
        }else {
            ret = ('%date_from - %date_end').replace(/%date_from/,this.time_from).replace(/%date_end/,this.time_to)
        }

        return ret;
    }

    this.return_saveable = function() {
        var save_me = {}
        save_me.uuid = this.uuid;

        save_me.name = this.name;

        save_me.title_uuid = this.title_uuid;
        save_me.print_no = this.print_no;

        save_me.show_type_uuid = this.show_type_uuid;
        save_me.screen_type_uuid = this.screen_type_uuid;

        save_me.placeholder_uuid = this.placeholder_uuid;

        save_me.date_from = this.date_from;
        save_me.date_to = this.date_to;

        save_me.time_from = this.time_from;
        save_me.time_to = this.time_to;

        save_me.duration_in_seconds = this.duration_in_seconds;
        save_me.ratings = this.ratings;
        save_me.priority = this.priority;

        save_me.external_show_attribute_maps = this.external_show_attribute_maps;
        save_me.clips = [];
        for (var i =0; i < this.clips.length; i++) {
            save_me.clips.push(this.clips[i].return_saveable())
        }
        save_me.screen_uuids = [];
        for (var screen_uuid in this.screens) {
            if (this.screens[screen_uuid] === true) {
                save_me.screen_uuids.push(screen_uuid);
            }
        }

        return save_me;
    }
}

function PackClip(pack_clip) {
    $.extend(this, {
        cpl_id: null,
        text: null,
        duration_in_frames: null,
        duration_in_seconds: null,
        edit_rate: null,
        content_kind: null,
        playback_mode: null,
        automation: []
    }, pack_clip);

    if(!this.text){
        this.text = pack_clip.content_title_text;
    }
    if(!this.cpl_id){
        this.cpl_id = pack_clip.uuid;
    }
    if(!this.content_kind){
        this.content_kind = gettext("Unknown");
    }
    
    this.sort_automation = function()
    {
        this.automation = this.automation.sort(helpers.automation_sort);
    }

    this.return_saveable = function() {
        var save_me = {
            cpl_id: this.cpl_id,
            content_kind: this.content_kind,
            duration_in_frames: this.duration_in_frames,
            duration_in_seconds: this.duration_in_seconds,
            edit_rate: this.edit_rate != null ? this.edit_rate : null,
            text: this.text,
            type: 'composition', 
            automation: this.automation
        };
        return save_me;
    }
}

function MacroPlacementEvent(playlist_event_object, automation_dictionary) {
    if(!playlist_event_object){
        playlist_event_object = {};
    }
    this.type = 'placement';
    this.content_kind = 'placement';
    this.automation = [];
    this.edit_rate = [24, 0];

    this.title = gettext('Placeholder');

    this.sort_automation = function(){
        this.automation = this.automation.sort(helpers.automation_sort);
    }

    if (playlist_event_object.automation!== undefined) {
        for(var i=0; i < playlist_event_object.automation.length; i++) {
            this.automation.push(new PlaylistCompositionAutomation(playlist_event_object.automation[i], automation_dictionary));
        }
        this.sort_automation();
    }
    this.return_saveable = function() {
        var save_me = {}
        save_me.type = this.type;
        save_me.text = this.title;
        save_me.automation = [];
        for (var i =0; i < this.automation.length; i++) {
            save_me.automation.push(this.automation[i].return_saveable())
        }
        return save_me;
    }
}


function MacroPackObject(macro_pack_object){
    macro_pack_object = $.val_or_default(macro_pack_object,{});

    $.extend(this, {
        uuid: null,
        macro_placeholder_uuid: null,
        device_uuid: null,
        has_content: null
    }, macro_pack_object);

    this.event_list = [];

    if($.val_or_default(macro_pack_object.event_list, false)){
        for(var i =0; i < macro_pack_object.event_list.length; i++){
            var event = macro_pack_object.event_list[i];
            switch(event.type) {
                case 'composition':
                    this.event_list.push(new PlaylistCompositionEvent(event));
                    break;
                case 'pattern':
                    this.event_list.push(new PlaylistPatternEvent(event));
                    break;
                case 'placement':
                    this.event_list.push(new MacroPlacementEvent(event));
                    break;
            }
        }
    }

    this.return_saveable = function() {
        var output = {};
        output.uuid = this.uuid;
        output.macro_placeholder_uuid = this.macro_placeholder_uuid;
        output.device_uuid = this.device_uuid;
        output.event_list = []
        for (var i =0; i < this.event_list.length; i ++ ){
            output.event_list.push(this.event_list[i].return_saveable());
        }
        return output;

    }

    this.calculate_start_times = function() {
        var automation, start_time;
        //In seconds
        start_time = 0;
        for (var i=0; i < this.event_list.length; i++) {
            //Check for a gdc_start_cue first because it adjust the start time of the playlist event
            for (var j=0; j < this.event_list[i].automation.length; j++) {
                if (this.event_list[i].automation[j].type == 'gdc_start_cue') {
                    this.event_list[i].automation[j].start_time = start_time;
                    start_time += this.event_list[i].automation[j].type_specific.delay_in_seconds;
                    //Should only be 0-1 start cue per event
                    break;
                }
            }
            this.event_list[i].start_time = start_time;
            for (var j =0 ; j < this.event_list[i].automation.length; j++) {
                automation = this.event_list[i].automation[j];
                if ($.inArray(automation.type, ['cue','volume','wait_for_input', 'qube', 'sony_cue', 'sony_function']) !== -1) {
                    if (automation.type_specific.offset_in_seconds != null) {
                        if (automation.type_specific.offset_from == 'start') {
                            automation.start_time = start_time + automation.type_specific.offset_in_seconds;
                        } else if (automation.type_specific.offset_from == 'end') {
                            automation.start_time = start_time + this.event_list[i].duration_in_seconds - automation.type_specific.offset_in_seconds;
                        } else {
                            automation.start_time = null;
                        }
                    } else {
                        //TODO set some kind of error flag to 1) to show the user the info hasn't loaded yet/has an error  2) to prevent the null values being saved over the real ones
                        automation.start_time = null;
                    }
                }
            }
            if (this.event_list[i].duration_in_seconds != undefined)
                start_time += this.event_list[i].duration_in_seconds;
        }
        this.duration_in_seconds = start_time;
    }
}

function Loader(parameters){
    if(!parameters){
        parameters = {};
    }

    var target = $(parameters.target || 'body');
    var shroud = $('#loading_bar_tmpl').tmpl2({
        caption: parameters.caption || gettext('Loading'),
    });
    target.append(shroud);
    var spinner = new Spinner({'dom': shroud.find(".loader_text")});

    var timeout = null;

    function show(callback){
        // Timeout so loader doesn't show on quick loads
        shroud.hide();        
        target.css("overflow", "hidden").scrollTop(0);
        timeout = setTimeout(function(){
            shroud.show();
            spinner.spin();
        }, 80);
        if(callback){
            callback();
        }
    }

    function hide(){
        clearTimeout(timeout);
        spinner.stop();
        shroud.hide();
        target.css("overflow", "")
    }
	
	function kill() {
		shroud.remove();
		shroud = null;
	}

    this.show = show;
    this.hide = hide;
    this.kill = kill;
}

function Spinner(parameters){
    var dom = parameters['dom'];
    var speed = parameters['speed'] || 200;
    var classes = parameters['classes'] || "";
    var interval = null;
    var progress = 0;

    $('#spinner_tmpl').tmpl2({'classes': classes}).appendTo(dom);

    var spinner = dom.find(".loader_spinner");

    function spin(){
        progress = 0;
        interval = setInterval(function(){
            spinner.removeClass("icon-progress-"+progress);
            progress = (progress === 3) ? 0 : progress + 1;
            spinner.addClass("icon-progress-"+progress);
        }, 200);
    }

    function stop(){
        clearInterval(interval);
        spinner.removeClass("icon-progress-"+progress);
        progress = 0;
        spinner.addClass("icon-progress-"+progress);
    }

    this.spin = spin;
    this.stop = stop;
}

function DeviceSelector(parameters) {
	this.init = init;
	this.update = update;
	this.get_selected = get_selected;
	this.destroy = destroy;

	var force = $.val_or_default(parameters.force,false);
	var append_to = $.val_or_default(parameters.append_to, new Object());
	var on_click = $.val_or_default(parameters.on_click, function(){});
	var include_lms = $.val_or_default(parameters.include_lms,true);
	var include_global = $.val_or_default(parameters.include_global,false);
	var include_all = $.val_or_default(parameters.include_all,false);
	var supported_function = $.val_or_default(parameters.supported_function,undefined);
	var initial_selected = $.val_or_default(parameters.initial_selected,undefined);
	//This is a default parameter for the filtering of certain device types in the device selector. 
	var included_device_types = $.val_or_default(parameters.included_device_types,['external','lms','sms', 'directory']);

	var devices = helpers.get_device_list(supported_function);
	var _devices = null;
	var margin = 0;

	$device_store.on('loaded',  update_event);

	var doit;
	$(append_to).resize(function() {
		clearTimeout(doit);
		doit = setTimeout(check_scroll, 100);
	});

	function destroy() {
		$(append_to).off("resize");
		$device_store.off('loaded', update_event);
	}

	function update_event() {
		update(false);
	}

	function init() {
		var ordered_list = get_devices();

		$('#server_selector_tmpl').tmpl2(ordered_list, append_to);
		$('.server_selector').on('click.device_selector', '.server_item', function() {
			$('.server_selector .server_item.selected').removeClass("selected");
			$(this).addClass("selected");
			var selected_id = get_selected();
			g_last_selected_device = (selected_id === 'All') ? all_devices : $device_store.devices[selected_id];
			on_click(selected_id);
		});

		if(initial_selected != undefined) {
			var selected = $('.server_item[server_item_id="' + initial_selected +'"]');
		}

		if(selected && selected.length !== 0) {
			selected.click();
		} else {
			$('.server_selector .server_item:first-child').addClass("selected");
			on_click(get_selected());
		}

		check_scroll();

		$('#server_selector_scrollers .scroller_right').click(function() {
			var overflow_r = overflow_right();
			if(overflow_r <= 0)
				return;
			margin -= overflow_r;
			$('.server_selector').stop().animate({'margin-left': margin}, 300, 'easeOutQuad', function(){});
		});
		$('#server_selector_scrollers .scroller_left').click(function() {
			var overlow_l = overflow_left();
			if(overlow_l <= 0)
				return;
			margin += overlow_l;
			$('.server_selector').stop().animate({'margin-left': margin}, 300, 'easeOutQuad', function(){});
		});
	}

	function update(force) {
		if(force == undefined)
			force = false;

		devices = helpers.get_device_list(supported_function);
		if(force || devices_changed(devices))
			_devices = devices;
		else
			return 0;
		var previous_selection = $('.server_selector .server_item.selected').attr('server_item_id');

		var ordered_list = get_devices();
		$('#server_selector_bar_tmpl').tmpl2(ordered_list, '.server_selector');
		$('.server_selector .server_item.selected').removeClass("selected");

		var selected = $('.server_item[server_item_id="' + previous_selection +'"]');
		if(selected.length !== 0){
			selected.addClass("selected");
		}
		else{
			$('.server_selector .server_item:first-child').click();
		}
		check_scroll();
	}

	function get_devices() {
		var ordered_list = [];
		var server_id, selector_item;
		// 'All' button
		if (include_all) {
			selector_item = {};
			selector_item.id = 'All';
			selector_item.selected = false;
			selector_item.type = 'all';
			selector_item.name = gettext('All');
			ordered_list.push(selector_item);
		}

		var add_me = false;
		for (var device_index in devices) {
			server_id = devices[device_index].id;
			add_me = false;
			selector_item = {};
			selector_item.id = server_id;
			selector_item.type = $device_store.devices[server_id].category;
			selector_item.selected = false;

			switch ($device_store.devices[server_id].category){
				case 'projector':
				case 'pos':
					break;
				case 'lms':{
					if (include_lms || $._in('lms', included_device_types)) {
						selector_item.name = $device_store.devices[server_id].name;
						add_me = true;
					}
					break;
				}
				case 'sms':{
					if ($._in('sms', included_device_types)){
						selector_item.name = $device_store.devices[server_id].screen().identifier;
						add_me = true;
					}
					break;
				}
				case 'external':{
					if ($._in('external', included_device_types)){
						selector_item.name = ($device_store.devices[server_id].name != undefined) ? $device_store.devices[server_id].name : $device_store.devices[server_id].path;
						add_me = true;
					}
					break;
				}
				case 'content':{
					if ($._in('directory', included_device_types)){
						selector_item.name = ($device_store.devices[server_id].name != undefined) ? $device_store.devices[server_id].name : $device_store.devices[server_id].path;
						add_me = true;
					}
					break;
				}
			}
			if(add_me){
				ordered_list.push(selector_item);
			}
		}

		if (include_global) {
			ordered_list.splice(0,0,{id:'global',name:'TMS',type:'global', selected:false});
		}
		if(ordered_list.length > 0) {
			ordered_list[0].selected=true;
		}
		return ordered_list;
	}

	function get_selected() {
		var selected = null;
		var selected_id = $('.server_selector .server_item.selected').attr('server_item_id');
		if(selected_id)
			selected = selected_id;
		else
			selected = $('.server_selector .server_item:first-child').attr('server_item_id');
		return selected;
	}

	function check_scroll() {
		if(overflow_left() > 0 || overflow_right() > 0) {
			$('#server_selector_scrollers').show();
			fix_pos();
		}
		else
			$('#server_selector_scrollers').hide();
	}

	function fix_pos() {
		var bar_width = $(".server_selector").parent().outerWidth();
		$('#server_selector_scrollers').css("left", bar_width);
	}

	function overflow_right() {
		var bar_width = $(".server_selector").parent().outerWidth();
		var width = 0;
		var overflow = 0;
		$.each($('.server_selector .server_item'), function(k,v){
			if(overflow !== 0)
				return 0;
			width += $(v).outerWidth();
			if(margin + width > bar_width) {
				overflow = margin + width - bar_width;
			}
		});
		return overflow;
	}

	function overflow_left() {
		var width = 0;
		var overflow = 0;
		$.each($('.server_selector .server_item'), function(k,v){
			if(overflow !== 0)
				return 0;
			width += $(v).outerWidth();
			if(width >= -margin) {
				overflow = margin + (width - $(v).outerWidth());
				return 0;
			}
		});
		return -overflow;
	}

	function devices_changed(devices) {
		if(!_devices || _devices.length !== devices.length)
			return true;

		var bool = false;
		for(var i = 0; i < _devices.length; i++) {
			if(_devices[i].screen_uuid !== devices[i].screen_uuid)
				bool = true;
		}
		return bool;
	}
}

    function ViewBar(args){
        var parent = args.parent;
        var extra_options = args.extra_options || [];
        var zoom_list_tmpl = args.zoom_list_tmpl || "#zoom_list_tmpl";
        var zoom_values = args.zoom_values || ['100', '200', '300', '400'];
        var zoom_default = args.zoom_default || zoom_values[0];
        var zoom_callback = args.zoom_callback;
        var zoom_cookie = args.zoom_cookie;

        if(zoom_cookie){
            var cookie = $.cookie("read", zoom_cookie);
            if(cookie){
                zoom_default = cookie;
            }
        }

        $('#view_bar_tmpl').tmpl2({zoom_default: zoom_default, extra_options: extra_options}).appendTo(parent);

        var view_bar = $('#view_bar');
        var zoom_value = view_bar.find('#zoom_value');

        setup_bar();

        if(zoom_default){
            zoom_callback(zoom_default);
        }

        function setup_bar(){
            zoom_values.reverse();

            helpers.attach_tip_menu({
                dom: zoom_value,
                tmpl: zoom_list_tmpl,
                tmpl_data: zoom_values,
                position: {
                    my: "bottom center",
                    at: "top center"
                },
                classes: 'qtip-light',                
                render: function(event, api){
                    $('.jq_zoom_select').click(function() {
                        var new_value = $(this).text();
                        var new_value_int = new_value.replace("%", "");
                        zoom_value.text(new_value);
                        zoom_callback(new_value_int);
                        if(zoom_cookie){
                            $.cookie("write", zoom_cookie, new_value_int, 5000);
                        }
                    });
                }
            });

            var i = extra_options.length;
            while(i){
                i--;
                $('#view_bar_option_'+i).click(extra_options[i].action);
            }

            $('#zoom_button').click(function() {
                var height = $('#view_bar').outerHeight();
                $('#view_bar').animate({'margin-bottom': -height - 10}, 250, "easeInQuad", function()
                {
                    $(this).hide();
                    $('#view_bar_show').show().animate({'margin-bottom': -2}, 250, "easeOutQuint");
                });
            });
            $('#view_bar_show').click(function() {
                var height = $('#view_bar_show').outerHeight();
                $('#view_bar_show').animate({'margin-bottom': -height - 10}, 250, "easeInQuad", function() {
                    $(this).hide();
                    $('#view_bar').show().animate({'margin-bottom': 15}, 250, "easeOutQuint");
                });
            });
        }
    }

function DragList(args){
    var self = this;
    var search_dom = args.search_dom;
    var search_input = args.search_input;
    var list_dom = args.list_dom;
    var device_id = args.device_id;
    var selected_device = $device_store.devices[device_id];
    var draggable_defaults = args.draggable_defaults;

    this.draw = draw_draglist;
    this.update = update_draglist;
    this.current_search = null;

    function draw_draglist(params){
        var main_template = params.main_template;
        var search_template = params.search_template;
        var search_params = params.search_params;
        var drag_list = params.drag_list;
        var drag_params = params.drag_params || draggable_defaults;
        var sort_func = params.sort_func;
        var filter_func = params.filter_func;
        var type = params.type;
        var filter_info = params.filter_info;
        var double_click_func = params.double_click_func;
        var update = params.update;

        if(sort_func){
            drag_list.sort(sort_func);
        }
        if(search_template){
            $(search_dom).html($(search_template).tmpl($.extend({'selected_device': selected_device}, search_params)));
            $(search_input).searcher(filter_func);
        }
        else{
            $(search_dom).empty();
        }
        update_draglist(params);
    }

    function update_draglist(params){
        var main_template = params.main_template;
        var drag_list = params.drag_list;
        var drag_params = params.drag_params || draggable_defaults;
        var type = params.type;
        var double_click_func = params.double_click_func;
        var filter_info = params.filter_info;
		
		if(params.main_template_hb) { //handlebars
			$(params.main_template_hb).tmpl2({
				drag_list: drag_list,
				type: type,
				selected_device: selected_device
			}, list_dom);
		} else {
			$(list_dom).html($(main_template).tmpl({
				'drag_list': drag_list,
				'type': type,
				'selected_device': selected_device
			}));
		}

        $(list_dom).children('div').draggable(drag_params);
        if(double_click_func){
            $(list_dom).children('div').dblclick(double_click_func);
        }
        if(filter_info && filter_info.total > drag_list.length){
            $(list_dom).append($('#playlist_edit_pack_filtered_info_tmpl').tmpl({'total':filter_info.total, 'showing': drag_list.length}));
        }
    }
}
function TemplateObject(template_object){
    var self = this;
    var template_object = $.val_or_default(template_object, {})
    $.extend(this, {
        uuid: null,
        name: null,
        cpl_transitions: false,
    }, template_object);

    self.event_list = [];
    for (var i =0; i < $.val_or_default(template_object.event_list, []).length; i++) {
        self.event_list.push(template_object.event_list[i]);
    }

    this.add_event = function(tmpl_event, at){
        this.event_list.splice(at, 0, tmpl_event);
    }

    this.return_saveable = function() {
        var save_me = {}
        save_me.uuid = this.uuid;
        save_me.name = this.name;
        save_me.cpl_transitions = this.cpl_transitions;

        save_me.event_list = [];
        for (var i =0; i < this.event_list.length; i++) {
            save_me.event_list.push(this.event_list[i]);
        }

        return save_me;
    }
}

function ShowAttributeSelector(args){
    var dom = args['dom'];
    var show_screen = args['show_screen'];
    var current = args['current'] || [];
    var show_attributes = args['show_attributes'];
    var click = args['click'];
    var read_only = args['read_only'];

    var loader = new Loader({
        'target': dom
    });
    loader.show();


    if(read_only && $.isEmptyObject(current)){
        loader.hide();
        dom.append($('#show_attribute_selector_empty_tmpl').tmpl2());
    }
    else{
        $.when(load()).done(function(){
            for(var i in show_attributes){
                show_attributes[i].icon = sa_icons[show_attributes[i].name];
				show_attributes[i].selected = current[i] ? true : false;
            }
            var tmpl = $('#show_attribute_selector_tmpl').tmpl2(show_attributes);
            
            loader.hide();
            dom.append(tmpl);
            if(!read_only){
                $('.show_attribute').click(function(){
                    var toggledjqitem = $(this).toggleClass("selected");
                    if(click){
                        var uuid = toggledjqitem.attr("data-uuid");
                        click(toggledjqitem, show_attributes[uuid]);
                    }
                });
            }
            else{
                $('.show_attribute').css('cursor', 'default');
            }
        });
    }

    function load(){
        var def = $.Deferred();
        if(show_attributes == undefined){
            helpers.ajax_call({
                'url': '/core/configuration/show_attribute',
                success_function: function(input){
                    show_attributes = input['data'];
                    def.resolve();
                }
            });
        }
        else{
            def.resolve();
        }
        return def.promise();
    }

    function get_selected(){
        var selected = {};
        $(dom).find(".show_attribute.selected").each(function(){
            var uuid = $(this).attr("data-uuid");
            selected[uuid] = show_attributes[uuid];
        })
        return selected;
    }

    function get_selected_uuids(){
        var uuids = [];
        var selected = get_selected();
        for(uuid in selected){
            uuids.push(selected[uuid]['uuid']);
        }
        return uuids;
    }
    

    function get_selected_names(){
        var names = {};
        var selected = get_selected();
        for(uuid in selected){
            names[uuid] = selected[uuid]['name'];
        }
        return names;
    }

    this.get_selected = get_selected;
    this.get_selected_uuids = get_selected_uuids;
    this.get_selected_names = get_selected_names;
};

function ColumnToggler(args){
    var self = this;
    var table_id = args['table'];
    var cookie_id = table_id.replace("#", "") + "_" + "columns_vis_json"
    var table_dom = $(table_id);
    var columns = args['columns'];
    var columns_vis = {};
    var vis_data = {};
    var table;
    var set_col_i;

    setup();

    function setup(){
        table_dom.find("thead tr").append('<th width="30px"><span id="header_selector" class="icon icon-cog"></span></th>')
        columns.push({
            bVisible: true,
            bSortable: false,
            bUseRendered: false,
            mDataProp: function(){
                return ''
            }
        })
        set_col_i = columns.length - 1

        // Restore column visibility data from cookie
        var col_vis_data = load();
        if(col_vis_data){
            for(var i in columns){
                if(col_vis_data[i] != undefined){
                    columns[i]['bVisible'] = col_vis_data[i];
                }
            }
        }
    }

    function init(table){
        self.table = table;
        var columns = self.table.fnSettings().aoColumns
        for(var i = 0; i < columns.length; i++){
            var v = columns[i]
            var text = $($.parseHTML(v.sTitle)[0])
            if(i == set_col_i){
                continue
            }
            vis_data[i] = v.bVisible;
            columns_vis[i] = {
                text: text.html(),
                vis: v.bVisible
            }
        }

        $('#header_selector').qtip({
            content: $('#table_header_filter_tmpl').tmpl2({cols: columns_vis}),
            position: {
                my: "top center",
                at: "bottom center",
                viewport: $('#main_section')
            },
            show: {
                event: 'mouseover click',
                ready: false
            },
            hide: {
                delay: 100,
                event: 'mouseout',
                fixed: true
            },
            style: {
                classes: 'qtip-tms qtip-shadow qtip-rounded'
            },
            events: {
                render: function(event, api){
                    var data = {};
                    $('#header_filters .header_filter').click(function(e){
                        var dom = $(e.target);
                        var selected = !dom.hasClass('selected');
                        dom.toggleClass('selected', selected);
                        data[dom.attr("data-value")] = selected;
                    });
                    $('#header_filters #header_filters_apply').button().click(function(){
                        save(data);
                        update(true);
                    });
                }
            },
        });
        update(false);
    }

    function save(data){
        vis_data = data;
        var json = JSON.stringify(data);
        $.cookie('write', cookie_id, json, 5000);
    }

    function load(){
        var data = $.cookie('read', cookie_id);
        var success = false;
        if(data != undefined && data != 'undefined'){
            try{
                vis_data = JSON.parse(data);    
                success = true;
            }
            catch(ex){
                console.log("Problem parsing json cookie:", ex);
            }
        }
        if(success){
            return vis_data
        }
        vis_data = {};
        for(var i in columns){
            var vis = columns[i]['bVisible'];
            if(vis == undefined){
                vis = true
            }
            vis_data[i] = vis
        }
        return vis_data
    }

    function override(override){
        for(var col_no in vis_data){
            var vis = vis_data[col_no];
            var o = override[col_no];
            // If we are set to show something which is meant to be hidden, hide it
            if(o != undefined && o == false && vis){
                self.table.fnSetColumnVis(col_no, false, false);
            }
            else{
                self.table.fnSetColumnVis(col_no, vis_data[col_no], false);
            }
        }
    }

    function update(redraw){
        for(var col_no in vis_data){
            self.table.fnSetColumnVis(col_no, vis_data[col_no], false);
        }
        if(redraw){
            self.table.fnAdjustColumnSizing();
        }        
    }

    function get(){
        return vis_data;
    }

    self.init = init;
    self.override = override;
    self.get = get;
}

function EmojiTip(params){
    var anchor = params['anchor'];
    var _target = params['target'];

    var tip_content = $('#emoji_tip_tmpl').tmpl_string({
        emojis: emojis
    });

    if(_target){
        target(_target);
    }
    if(anchor){
        attach(anchor)
    }

    function target(t){
        _target = $(t);
    }

    function attach(a){
        anchor = $(a);
        anchor.qtip({
            content: tip_content,
            position: {
                at: 'top center',
                my: 'bottom center'
            },
            show: {
                ready: false,
                event: 'click'
            },
            hide: {
                event: 'unfocus click'
            },
            style: {
                classes: 'qtip-tms-dark'
            },
            events: {
                render: function(e, api){
                    $(api.elements.content).find('.emoji').click(function(){
                        var index = $(this).attr("data-index");
                        _target.val(_target.val() + emojis[index]);
                    });
                },
                show: function(){
                    anchor.addClass('selected');
                },
                hide: function(){
                    anchor.removeClass('selected');
                }
            }
        });
    }

    this.target = target;
    this.attach = attach;
}

function ScreenSelector(params){
    var dom = $(params['dom']);
    var screens = params['screens'] || helpers.get_screen_list();
    var selected = params['selected'] || [];
    var change = params['change'];
    var all = params['all'] || false;

    if(all){
        screens.unshift({uuid: 'all', identifier: 'All'});
    }
    var html = $('#screen_selector_tmpl').tmpl2({
        screens: screens,
        selected: selected
    });

    var id = dom.attr("id");
    var classes = dom.attr("class") || "" + " " + html.attr("class");
    var obj = html.clone().attr("id", id).attr("class", classes);
    var buttons = obj.find(".screen_button");
    var all_button = buttons.filter(".all");

    dom.replaceWith(obj);
    
    buttons.click(function(e){
        var button = $(this);
        if(all && button.hasClass("all")){
            buttons.removeClass('selected');
            button.addClass("selected");
        }
        else{
            all_button.removeClass('selected');
            button.toggleClass('selected');
        }       

        if(change){
            change(get_selected());
        }
    });

    function get_selected(t){
        var selected = $.map(buttons.filter(".selected"), function(x){
            var dom = $(x);
            if(dom.hasClass("selected")){
                return dom.attr("data-uuid")
            }
        });
        return selected;
    }

    this.get_selected = get_selected;
}
