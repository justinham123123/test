helpers = new Helpers();

function Helpers() {
    var self = this;

    self.attach_suggestion_tip = function(params){
        var dom = params['dom'];
        var items = params['items']; // List of things to suggest from, key will be used as uuid
        var text_field = params['text_field']; //Specified field in items to be used for display
        var change = params['change']; //Called when text field is changed
        var tip_params = params['tip_params'];
        var timeout = params.timeout || 500;
        var search_filter = params.search_filter || function(){return true;};

        var current_val = " ";
        var text_list = [];

        for(var uuid in items){
            text_list.push(items[uuid]);
        }
        text_list.sort(function(a,b){
            return a[text_field].localeCompare(b[text_field]);
        });
        var showing = false;

        var tip_data = {
            content: {
                text: " "
            },
            position: {
                my: "top right",
                at: "bottom right",
                viewport: $("#main_section")
            },
            show: {
                event: 'none',
                ready: false
            },
            hide: {
                event: 'unfocus',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-tms-dark'
            },
            events: {
                show: function(event, api){
                    $("#suggestions .suggestion:first-child").addClass("selected");
                    $('#suggestions .suggestion').click(function(){
                        $('#suggestions .suggestion.selected').removeClass("selected");
                        $(this).addClass("selected");
                        select_suggestion();
                    });
                }
            }
        }

        $.extend(true, tip_data, tip_params);

        dom.qtip(tip_data);

        dom.focus(function(){
            var val = dom.val();
            if(val){
                dom.keydown();
            }
        });

        var to = null;
        dom.keydown(function(e){
            var keycode = e.keyCode;
            if(keycode == 40){
                e.preventDefault();
                move_selection(1);
            }
            else if(keycode == 38){
                e.preventDefault();
                move_selection(-1);
            }
            else if(keycode == 13){
                if(showing) select_suggestion();
            }
            else{
                var _this = this;
                clearTimeout(to);
                to = setTimeout(function(){
                    var dom = $(_this);
                    var search = dom.val();
                    if(search && search_filter(search)){
                        var suggestions = get_suggestions(dom.val());
                        var tmpl = $("#suggestions_tip_tmpl").tmpl2(suggestions);
                        dom.qtip('option', 'content.text', tmpl);
                        dom.qtip("show");
                        showing = true;
                    }
                    else{
                        dom.qtip("hide");
                        showing = false;
                    }
                }, timeout);
            }
        });

        dom.keyup(function(e){
            var val = $(this).val();
            if(e.keyCode == 13){
                current_val = val;
                return;
            }
            if(current_val != val){
                dom.attr("data-item_uuid", null);
                current_val = val;
                if(change) change();
            }
        });

        function select_suggestion(){
            var selected = $("#suggestions .suggestion.selected");
            var item_uuid = selected.attr("data-item_uuid");
            if(item_uuid === undefined) return;
            var item = items[item_uuid];
            dom.val(item[text_field]).attr("data-item_uuid", item_uuid);
            if(change) change(item_uuid)
            dom.qtip("hide");
            showing = false;
        }

        function move_selection(direction){
            var selected = $("#suggestions .suggestion.selected");
            var new_selection = direction == 1 ? selected.next() : selected.prev();
            if(new_selection.length > 0){
                selected.removeClass("selected");
                new_selection.addClass("selected");
                $(".qtip-content").scrollTop(0).scrollTop(new_selection.offset().top - $(".qtip-content").offset().top - 10);
            }
        }

        function get_suggestions(search){
            var suggestions = [];
            for(var uuid in items){
                var item = items[uuid];
                var name = item[text_field].toLowerCase();
                var found = true;
                var words = search.split(" ");
                for(var i in words){
                    var word = words[i].toLowerCase();
                    if(name.indexOf(word) == -1){
                        found = false;
                    }
                }
                if(found == true){
                    suggestions.push({'uuid': uuid, 'text': item[text_field]});
                }
            }
            return suggestions;
        }
    }

    //Attaches a menu style tooltip to a dom element
    self.attach_tip_menu = function(params){
        var dom = params['dom']; //Menu anchor
        var tmpl = params['tmpl']; //Menu template
        var tmpl_data = params['tmpl_data']; //Template data
        var classes = params['classes']; //Classes for tip styling
        var render = params['render']; //Render callback function, use for attaching event listeners to menu items
        //Default positioning values
        var position = {
            my: "top center",
            at: "bottom center",  
            viewport: $("body"),
            adjust: {
                method: 'shift none'
            }
        }
        if(params['position']){
            $.extend(position, params['position']);
        }        

        $(dom).qtip({
            content: {
                text: $(tmpl).tmpl2(tmpl_data)
            },
            position: position,
            show: {
                event: 'mouseover',
                ready: false
            },
            hide: {
                delay: 160,
                event: 'mouseleave',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded ' + classes
            },
            events: {
                render: render
            }
        });
    }

    self.browser_tab_active = (function(){
        var stateKey, eventKey, keys = {
            hidden: "visibilitychange",
            webkitHidden: "webkitvisibilitychange",
            mozHidden: "mozvisibilitychange",
            msHidden: "msvisibilitychange"
        };
        for (stateKey in keys) {
            if (stateKey in document) {
                eventKey = keys[stateKey];
                break;
            }
        }
        return function(c) {
            if (c) document.addEventListener(eventKey, c);
            return !document[stateKey];
        }
    })();

    self.ajax_call = function(parameters) {
        var url = parameters.url;
        var name = parameters.name;
        var input_data = $.val_or_default(parameters.data,new Object());
        var success_function = $.val_or_default(parameters.success_function,function(){});
        var error_function = $.val_or_default(parameters.error_function,function(){});
        var complete_function = $.val_or_default(parameters.complete_function,function(){});
        var repeat = $.val_or_default(parameters.repeat,false);
        var interval = $.val_or_default(parameters.interval,10*1000);
        var display_progress = $.val_or_default(parameters.display_progress,false);
        var headers = $.val_or_default(parameters.headers,{});
        var complete_variables = $.val_or_default(parameters.complete_variables, {});
        var notify = $.val_or_default(parameters.notify, true);
        var remove_messages = $.val_or_default(parameters.remove_messages, true);
        var timeout = $.val_or_default(parameters.timeout, 60000);
        var loader = null;

        var active_tab = self.browser_tab_active();
        if( active_tab ){
            browser_tab_initialised = true;
        }

        // No looky, no ajax!
        // Disable all ajax requests when browser tab is inactive but the user has looked at tab at least once
        // This is so that when you CTRL click to open a new tab it actually initialises despite lack of focus
        if( active_tab == false && browser_tab_initialised == true && !parameters.force_call ){
            var wait = repeat == true ? interval : 5000;
            setTimeout(
                function(){
                    helpers.ajax_call(
                        {
                            name:name,
                            url:url,
                            data:input_data,
                            success_function:success_function,
                            complete_function:complete_function,
                            repeat:repeat,
                            interval:interval
                        }
                    )
                },
                wait
            );
            return null;
        }

        if(parameters['loader']){
            loader = new Loader(parameters['loader']);
            loader.show();
        }
        
        var action_id;
        var content_type, proccessed_input_data
        
        if(typeof(input_data) == 'string'){
            content_type = 'application/x-www-form-urlencoded';
            proccessed_input_data = input_data
        }else{
            content_type = 'application/json';
            proccessed_input_data = $.toJSON(input_data);
        }
        
        if (display_progress == true && typeof progress_display != 'undefined') {
            action_id = progress_display.add_action(name);
        }
        
        var helper = $.ajax({
            type: "POST",
            timeout:timeout,
            url: url,
            dataType: "json",
            cache: false,
            data: proccessed_input_data,
            processData: false,
            contentType: content_type,
            headers : headers,
            success: function(response_data, text_status, XMLHTTP)
            {
                if(notify && response_data.messages){
                    for(var i = 0; i < response_data.messages.length; i++){
                        if(response_data.messages[i].type == 'action'){
                            var msg_id = notification.queued_msg(response_data.messages[i].message, name);
                            $action_store.actions[response_data.messages[i].action_id] = {
                                message_id: msg_id,
                                notify: notify
                            };
                        }
                        if(response_data.messages[i].type == 'success'){
                            notification.info_msg(response_data.messages[i].message, name);
                        }
                        if(response_data.messages[i].type == 'error'){
                            notification.error_msg(response_data.messages[i].message, name);
                        }
                    }
                }
                if(loader) loader.hide();
                success_function(response_data, complete_variables, XMLHTTP);
            },
            error: function(XMLHTTP, text_status, error_thrown)
            {
                error_function(complete_variables);
                try{
                    if(XMLHTTP.status==401){
                        window.location.replace("/?redirect="+encodeURIComponent(window.location.pathname + window.location.search + window.location.hash));
                    }
                    else if(XMLHTTP.status==403){
                        notification.error_msg(gettext('Permission denied'), name);
                    } else if(XMLHTTP.status==0){
                        //Either a same origin policy violation (ho ho ho) or the window was reloaded during the ajax call
                    } else if(XMLHTTP.status === 408){
                        // Request timed out (http socket timeout error - see lib/cherrypy/wsgiserver/wsgiserver2.py#1325)
                        console.log('Timeout.', name);
                    } else {
                        notification.error_msg(gettext('Unable to complete the action because of ') + text_status, name);
                    }
                }
                catch(err) {
                    notification.error_msg(gettext('Javascript exception ') + err, name);
                }
                if(loader) loader.hide();
            },
            complete: function(XMLHTTP, text_status)
            {
                if (display_progress == true && typeof progress_display != 'undefined') {
                    progress_display.remove_action(action_id);
                }
                complete_function();
                if (repeat == true && XMLHTTP.kill === undefined)
                {
                    setTimeout(
                        function(){
                            helpers.ajax_call(
                                {
                                    name:name,
                                    url:url, 
                                    data:input_data, 
                                    success_function:success_function, 
                                    complete_function:complete_function, 
                                    repeat:repeat, 
                                    interval:interval
                                }
                            )
                        },
                        interval
                    );
                }
                if(loader) loader.hide();
            }
        });
        return helper
    };

    self.get_projector_status = function(device_id){
        var device_id, status, state_title, dowser_status, lamp_status;
        var projector = $device_store.devices[device_id];
        var projector_status = $projection_status_store.devices[device_id];
        /*DOWSER_STATUS = {
            '1' : 'Open',
            '2' : 'Closed'
        }

        LAMP_STATUS = {
            1: 'Lamp On',
            2: 'Lamp Off'
        }*/
        
        if(projector['version'] == 'unknown')
        {
            status = 'projector_unreachable';
            state_title = gettext("Projector Unreachable");
        }
        else
        {
            dowser_status = projector_status['dowser_status'];
            switch(dowser_status){
                case 'Open':{
                    status = 'dowser_open';
                    state_title = gettext("Dowser Open");
                    break;
                }
                case 'Closed':{
                    status = 'dowser_closed';
                    state_title = gettext("Dowser Closed");
                    break;
                }
                default: {
                    status = 'dowser_no_info';
                    state_title = gettext("Dowser Information Unavailable");
                }       
            }
            
            lamp_status = (projector_status['lamp_status']!==undefined) ? projector_status['lamp_status'] : 'nothing';
            switch(lamp_status){
                case 'Lamp On':{
                    status += '_lamp_on';
                    state_title += " - " + gettext("Lamp On");
                    break;
                }
                case 'Lamp Off':{
                    status += '_lamp_off';
                    state_title += " - " + gettext("Lamp Off");
                    break;
                }
                default: {
                    status += '_lamp_no_info';
                    state_title += " - " + gettext("Lamp Information Unavailable");
                }
            }
        }

        var re = {};
        re['status'] = status;
        re['state_title'] = state_title;
        re['dowser_status'] = dowser_status;
        re['lamp_status'] = lamp_status;
        return re;
    }

    self.match_height = function(ao, bo)
    {        
        var a = $(ao).height();
        var b = $(bo).height();
        var m = (a > b) ? a : b;
        $(ao).height(m);
        $(bo).height(m);
    }
    
    self.is_allowed = function(permission_group) {
        if (permission_group instanceof Array) {
            for (var i =0; i < permission_group.length; i++) {
                if (licensed_and_authenticated[permission_group[i]] !== undefined) {
                    if (!licensed_and_authenticated[permission_group[i]]){
                        return false;
                    }
                }
                else {
                    return false;
                }
            }
            return true
        }
        else if (licensed_and_authenticated[permission_group] !== undefined) {
            return licensed_and_authenticated[permission_group]
        }
        return false;
    }
    
    self.ajax_load = function(url,dom_id) {
        return $.ajax({
            timeout:60000,
            url: url,
            dataType: "html",
            success: function(response_data) {
                $('#'+dom_id).html(response_data);
            },
            complete:function(){}
        });
    };
    self.get_date_string = function(date) {
        var year = date.getFullYear();
        var month = date.getMonth()+1;
        var day = date.getDate();
        if (day < 10 ) {
            day = '0'+day;
        }
        if (month < 10 ) {
            month = '0'+month;
        }
        return year+'-'+month+'-'+day;
    };
    
    self.format_without_timezone = function(input_date) {
        return input_date.getFullYear()+'-'+((input_date.getMonth()<9)?'0':'')+(input_date.getMonth()+1)+'-'+((input_date.getDate()<10)?'0':'')+input_date.getDate() + ' '+((input_date.getHours()<10)?'0':'')+input_date.getHours()+':'+((input_date.getMinutes()<10)?'0':'')+input_date.getMinutes()+':'+((input_date.getSeconds()<10)?'0':'')+input_date.getSeconds(); 
    }
    self.small_date_format = function(input_date) {
        return ((input_date.getMonth()<9)?'0':'')+(input_date.getMonth()+1)+'-'+((input_date.getDate()<10)?'0':'')+input_date.getDate() + ' '+((input_date.getHours()<10)?'0':'')+input_date.getHours()+':'+((input_date.getMinutes()<10)?'0':'')+input_date.getMinutes()
    }
    
    self.get_device_name = function(device_info){
        
        var device = $device_store.devices[device_info];
        
        if( $device_store.devices[device_info] == undefined){
            for(var device_uuid in $device_store.devices){
                var current_device = $device_store.devices[device_uuid];
                var device_info_array = [current_device.ip, current_device.id, current_device.ftp_ip, current_device.path, current_device.screen_uuid, current_device.name];
                if($._in(device_info, device_info_array)){
                    device = current_device;
                    break;
                }
            }
        }
                
        if (device !== undefined) {
            if (device.category === 'lms'){
                return device.name;
            }else if (device.category === 'external'){
                return device.name || device.path;
            }else if(device.screen() != undefined){
                return device.screen().identifier;
            }else if(device.type === 'watchfolder' || device.type === 'ftp' || device.type === 'local'){
                return device.name;
            }else{
                return device.id;
            }
        }else{
            return device_info;
        }
    }    
    
    self.random_int = function(number) {
        return Math.floor(Math.random()*number)
    }
    
    self.get_device = function(device_id) {
        return $device_store.devices[device_id];
    };

    self.core_now = function(){        
        if($complex_status.core_time){
            return new Date($complex_status.core_time + Date.parse(new Date()) - $complex_status.browser_time_ref + $complex_status.browser_time_zone_offset + $complex_status.core_time_zone_offset)
        }
        else{
            return new Date();
        }        
    };
    
    //Turns an object into an array, then sorts it
    self.sorted_array = function(obj, key, sort){
        var array = [];
        for(var k in obj){
            var entry = obj[k];
            entry[key] = k;
            array.push(entry);
        }
        array.sort(sort);
        return array;
    }

    self.key_sort = function(array, key, dir){
        if(dir === undefined){
            dir = 1;
        }
        array.sort(function(a, b){
            if(a[key] < b[key]) return dir * -1;
            if(a[key] > b[key]) return dir;
            return 0;
        });
    }
    
    self.intersect_array = function(array1, array2){
        var result = array1.filter(function(n) {
            return array2.indexOf(n) != -1
        });
        return result;
    }
    
    //For browsers that don't implement webkit this funciton will cause any inputs with a placeholder attr to use that as their text while their value is ""
    self.activate_placeholders = function() {
        var detect = navigator.userAgent.toLowerCase(); 
        if (detect.indexOf('safari') > 0) 
            return false;
        var inputs = document.getElementsByTagName('input');
        for (var i=0;i<inputs.length;i++) {
            if (inputs[i].getAttribute('type') == 'text') {
                if (inputs[i].getAttribute('placeholder ') && inputs[i].getAttribute('placeholder').length > 0) {
                    inputs[i].value = inputs[i].getAttribute('placeholder');
                    inputs[i].onclick = function() {
                        if (this.value == this.getAttribute('placeholder')) {
                            this.value = '';
                        }
                        return false;
                    }
                    inputs[i].onblur = function() {
                        if (this.value.length < 1) {
                            this.value = this.getAttribute('placeholder');
                        }
                    }
                }
            }
        }
    };
    
    self.content_sorting_function = function(a,b) {
        return a.content_title_text.toLowerCase().localeCompare(b.content_title_text.toLowerCase());
    };
    
    self.cue_sorting_function = function(a,b) {
        var cue_a = a;
        var cue_b = b;
        if ((typeof(cue_a) == 'undefined') | (typeof(cue_b) == 'undefined'))
            return 0;
        if (cue_a.cue_type < cue_b.cue_type)
            return -1;
        if (cue_a.cue_type > cue_b.cue_type)
            return 1;
        if (cue_a.cue_name.toLowerCase() < cue_b.cue_name.toLowerCase())
            return -1;
        if (cue_a.cue_name.toLowerCase() > cue_b.cue_name.toLowerCase())
            return 1;
        return 0;
    };
    
    self.automation_sort = function(a,b) {
        var automation_types = ['cue','volume','sony_cue','sony_function', 'intermission'];
        if ($._in(a.type, automation_types) && $._in(b.type, automation_types)) {
            if (a.type_specific.offset_in_seconds != null && b.type_specific.offset_in_seconds != null) {
                return a.type_specific.offset_in_seconds - b.type_specific.offset_in_seconds;
            } 
            else if (a.type_specific.offset_in_frames != null && b.type_specific.offset_in_frames != null) {
                return a.type_specific.offset_in_frames - b.type_specific.offset_in_frames;
            }
        } 
        else if (a.type == 'trigger' && b.type == 'trigger') {
            return (a.type_specific.trigger + '').localeCompare(b.type_specific.trigger + '');
        } 
        else {
            var type_compare = (a.type + '').localeCompare(b.type + '');
            if (type_compare != 0) return type_compare;
        }
        //If not return here just compare names
        return (a.name + '').localeCompare(b.name + '');
    };
    
    self.screen_compare = function(a, b, sort_property) {
        if(sort_property) {
            var a_id = a[sort_property].toLowerCase(), b_id = b[sort_property].toLowerCase();
        } else {
            var a_id = a.toLowerCase(), b_id = b.toLowerCase();
        }
        var alpha_check = a_id.replace(/\d/g, '').localeCompare(b_id.replace(/\d/g, ''));
        return alpha_check || parseInt(a_id.replace(/\D/g, '')) - parseInt(b_id.replace(/\D/g, ''));
    };
    
    self.categorised_device_sorting_function = function(a,b) {
        if (a.category == b.category) {
            if (a.screen() && b.screen()) {
                return self.screen_compare(a.screen(), b.screen(), 'identifier');
            } else if (a.screen()) {
                return 1;
            } else if (b.screen()) {
                return -1;
            } else {
                return a.id.localeCompare(b.id);
            }
        } else if (a.category == 'lms') { return -1;
        } else if (b.category == 'lms') { return 1;
        } else if (a.category == 'sms') { return -1;
        } else if (b.category == 'sms') { return 1;
        } else if (a.category == 'external') { return -1;
        } else if (b.category == 'external') { return 1; 
        } else {
            return a.category.localeCompare(b.category);
        }
    };
    
    self.playlist_sorting_function = function(a,b) {
        return a.title.toLowerCase().localeCompare(b.title.toLowerCase());
    };
    
    self._get_image_attribute = function(attr_string, automation, title) {
    	//loser hack to deal wiht css
    	if(attr_string === '3d' || attr_string === '3D' || attr_string === 'three_d'){
    		attr_string = 'icon-three-d';
    	}
    	if(attr_string === '2D' || attr_string === '2d' || attr_string === 'two_d'){
            attr_string = 'icon-two-d';
        }
        if(attr_string === 'fps_48'){
            attr_string = 'icon-framerate-48';
        }
        if (automation !== undefined) {
            return {'image_item':{'name': attr_string, 'additional_class': 'automation_attributes', 'title': title}}
        }
        return {'image_item':{'name': attr_string, 'additional_class': 'content_attributes', 'title': title}}
    };

    self.content_status_info = function(status, selected_device) {
        switch (status)
        {
            case undefined:
            case -2:{
                var msg = gettext('CPL is not on server');
                return {status:'error', info:msg, code:status};
            }
            case -1:{
                var msg;
                if(selected_device != "All" && $device_store.devices[selected_device]['category'] == 'external'){
                    msg = gettext('CPL does not exist on this drive');
                }
                else{
                    msg = gettext('CPL does not exist on this server');
                }
                
                return {icon: 'missing', status:'missing', info:msg, code:status};
            }
            case 0:{
                return {icon: 'ok', status:'ok', info:gettext('CPL is OK'), code:status};
            }
            case 1:{
                return {icon: 'icon-incomplete', status:'incomplete', info:gettext('CPL does not have all required assets'), code:status};
            }
            case 2:{
                return {icon: 'icon-warning', status:'warning', info:gettext('CPL is corrupt'), code:status};
            }
            case 3:{
                return {status:'content_warning', info:gettext('CPL is currently ingesting'), code:status};
            }
            case 4:{
                return {status:'queued', info:gettext('CPL is queued to be ingested'), code:status};
            }
            case 5:{
                return {status:'not_validated', info:gettext('CPL is not validated'), code:status};
            }            
            default:{
                return {status:'', info:'', code:status};
            }
        }
    };
    
    self.construct_tabs = function(selection, callback) {
        var callback = $.val_or_undefined(callback);
        $(selection).each(function() {
            var headers, tabs;
            tabs = this;
            headers = $(tabs).find('.jq_tab_headers').children();
            //For each of the headers find their respective body and hide it
            headers.each(function() {
                var tab;
                tab = $(this).attr('tab');
                if (!$(this).hasClass('selected')) {
                    $(tabs).find('.jq_tab_body[tab="%tab"]'.replace('%tab', tab)).hide();
                }
            });
            //Attach the click handlers for selecting the active tab
            headers.on('click',
                function() {
                    var tab, tab_bodies;
                    tab = $(this).attr('tab');
                    $(this).addClass('selected').siblings().removeClass('selected');
                    tab_bodies = $(this).parent().siblings('.jq_tab_body');
                    tab_bodies.filter('[tab="'+tab+'"]').show();
                    tab_bodies.filter('[tab!="'+tab+'"]').hide();
                    if (callback!== undefined) {
                        callback($(this));
                    }
               }
            );
        });
    };

    //DEPRECIATED: Use the loader object instead
    //Creates a loading overlay, attaches to the dom element passed in, and trys to center itself
    //Callback is called after the loading bar has faded in, whilst its optional, not having it can cause short loads to look strange
    var loader = null;
    self.show_loader = function(dom, callback, caption){
        if(loader){
            loader.hide();
        }
        loader = new Loader({
            target: dom,
            caption: caption
        });
        loader.show(callback);
    };

    self.hide_loader = function(){
        if(loader){
            loader.hide();
            loader = null;
        }
    };
    
    self.screen_toggles = function(args){
        var dom = args.dom;
        var screens = args.screens || helpers.get_screen_list();

        $('#screen_toggles_tmpl').tmpl2(screens).appendTo(dom);

        $('.st_toggle input').button().click(function(){
            if($(this).attr("id") == "st_all_screens"){
                $(".st_screen input").attr("checked", false).button("refresh");
            }
            else{
                $('.st_all input').attr("checked", false).button("refresh");
            }
        });
    };
    
    self.get_screen_toggles = function(){
        var screens = [];
        if($('#st_all_screens').is(":checked")){
            $('.st_screen input').each(function(){
                var screen = $device_store.screens[$(this).val()];
                screens.push(screen);
            })
        }
        else{            
            $('.st_screen input:checked').each(function(){
                var screen = $device_store.screens[$(this).val()];
                screens.push(screen);
            });
        }
        return screens;
    };

    self.lazy_list = function(args){
        var scroller = args.scroller;
        var list = args.list;
        var data = args.data;
        var height = args.height;
        var buffer = args.buffer;
        var template = args.template;
        var template_data = args.template_data;
        var callback = args.callback;
        var debug = args.debug;

        var length = data.length;
        var loaded = buffer;
        var to_load = buffer;
        var load_point = 0;

        append(data.splice(0,to_load));

        $(list).append('<div id="lazy_list_padding"></div>');
        $('#lazy_list_padding').css("height", (length-loaded)*height + "px");

        $(scroller).scroll(function(e){
            if(to_load <= 0)
                return;

            var scroll = $(scroller).scrollTop();
            log(loaded + to_load, length)
            if(loaded + to_load > length){
                to_load = length - loaded;
            }

            log(scroll, load_point, $('.jq_load_playlist_option').length);
            if(scroll >= load_point){

                log("Loaded: " + loaded);
                log("Loading: " + to_load);
                log("To Load: " + length);

                $('#lazy_list_padding').remove();
                append(data.splice(0, to_load));
                loaded += to_load;
                $(list).append('<div id="lazy_list_padding"></div>');
                $('#lazy_list_padding').css("height", (length-loaded)*height + "px");
            }
        });

        function log(){
            if(debug)
                console.log(arguments);
        }

        function append(data){
            var temp = {}
            $.extend(temp, template_data, {'data': data})
            $(template).tmpl(temp).appendTo($(list));
            load_point = (loaded-buffer)*height + (to_load * height/2);
            callback();
        }
    };

    self.attach_playlist_validation_tip = function(dom, detailed_issues){
        $(dom).qtip({
            content: {
                text: $("#playlist_content_issues_tip_tmpl").tmpl({issues: detailed_issues})
            },
            position: {
                my: "bottom left",
                at: "top right",
                viewport: $("#main_section")
            },
            show: {
                event: 'click mouseover',
                ready: false,
            },
            hide: {
                delay: 100,
                event: 'unfocus mouseleave',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light'
            }
        });
    };

    self.attach_time_tip = function(dom){
        dom.qtip({
            content: {
                text: "<div class='hms_placeholder'></div><div class='hms_validation'></div>"
            },
            position: {
                my: "top center",
                at: "bottom center",
                viewport: $(window)
            },
            show: {
                event: 'focus',
                ready: false,
                effect: function() {
                    $(this).fadeIn(90, function() {
                        $('.hms_hours input').focus().select();
                    }); 
                }
            },
            hide: {
                event: 'unfocus',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-dark',
                width: 129
            },
            events: {
                show: function(event, api){
                    var current = $.duration_string_to_seconds(dom.val());
                    api.elements.content.find(".hms_validation").text("");
                    var options = {'enter' : function(){
                        var valid = self.time_valid(dom, api.elements.content.find(".hms_placeholder"));
                        if(valid === true){
                            api.hide();
                        }
                        else{
                            api.elements.content.find(".hms_validation").text(valid);
                        }
                    }};
                    if(current){
                        options['seconds'] = current;
                    }
                    api.elements.content.find(".hms_placeholder").hms(options);
                },
                hide: function(event, api){
                    var hms = api.elements.content.find(".hms_placeholder");
                    if(self.time_valid(dom, api.elements.content.find(".hms_placeholder")) === true){
                        dom.val(hms.hms("retrieve_time")).change();
                    }
                    hms.hms("destroy");
                }
            }
        });
    };

    self.time_valid = function(dom, hms){        
        if(dom.attr("id") == 'pack_edit_time_to' && hms.hms("retrieve") <= $.duration_string_to_seconds($('#pack_edit_time_from').val())){
            return "Less than From Time";
        }
        else if(dom.attr("id") == 'pack_edit_time_from' && hms.hms("retrieve") >= $.duration_string_to_seconds($('#pack_edit_time_to').val())){
            return "More than To Time";
        }
        else{
            return true;
        }
    };

    self.attach_availability_tip = function(options){
        var dom = options.dom;
        var cpl_uuid = options.cpl_uuid;
        var viewport = $(window);
        if(options.viewport != undefined)
            viewport = options.viewport;
        var ready = false;
        if(options.ready != undefined)
            ready = options.ready;
        var data = null;
        if(options.data != undefined)
            data = options.data;
        
        $(dom).qtip({
            content: {
                text: '<div class="availability_spinner_wrapper"><div id="spinner_'+cpl_uuid+'" class="availability_spinner"></div></div>'
            },
            position: {
                my: "bottom center",
                at: "top center",
                viewport: viewport
            },
            show: {
                event: 'mouseover',
                ready: ready,
                solo: true
            },
            hide: {
                delay: 100,
                event: 'unfocus mouseleave',
                fixed: true
            },
            style: {
                classes: 'qtip-shadow qtip-rounded qtip-light'
            },
            events: {
                render: function(){
                    //Should maybe readd some kind of loader here
                    //helpers.create_small_spinner("spinner_"+cpl_uuid, null)
                    if(data){
                        replace_content(data);
                    }
                    else{
                        helpers.ajax_call({
                            url:'/core/content/get_availability', 
                            data:{'content_uuid': cpl_uuid},
                            success_function:function(input){
                                replace_content(input);
                            }
                        });
                    }
                }
            }
        });

        function replace_content(devices){
            var avail_info = [];
            for(var device_id in devices){
                if (device_id === 'unknown' || !$device_store.devices[device_id]) {
                    //Don't show unknown KDMs, only ones that are valid for known screen servers
                    continue;
                }
                var keys = devices[device_id];
                var entry = {
					valid_now: false,
					valid_in_24: false,
					screen: $device_store.devices[device_id].screen().identifier
				};

				var t_id = 0;
                for(var key_uuid in keys){
                    var key = keys[key_uuid];
					keys[key_uuid].title_id = ++t_id;
					keys[key_uuid].availability_class = get_availability_class(key);
					keys[key_uuid].not_on_target = (entry.screen !== '?' && !key.on_target);
                    
					if (key.status !== 'ok') {
                        //Don't show bad KDMs
                        continue;
                    }
                    if(key.valid_now){
                        entry.valid_now = true;
                    }
                    if(key.valid_in_24){
                        entry.valid_in_24 = true;
                    }

                    //Replace uuids with device/screen names for templates
                    for(var i in key['on']){
                        var on = key['on'][i];
                        if(on in $device_store.devices){
                            var device = $device_store.devices[on];
                            keys[key_uuid]['on'][i] = device.screen_uuid ? device.screen().identifier : device.name;                            
                        }
                    }
                }
                entry.keys = keys;
                
                avail_info.push(entry);
            }
            avail_info.sort_screens('screen');
            var content = null;
            if(avail_info.length > 0){
                content = $('#content_availability_tip2_tmpl').tmpl2({devices: avail_info});
            }
            else{
                content = "<div class='availability_no_devices'>" + gettext("No KDMs were found for this CPL") + "</div>";
            }
            dom.qtip('option', 'content.text', content); 
			
			function get_availability_class(key) {
				if(key.valid_now && key.valid_in_24)
					return 'availability_valid';
				else if(!key.valid_now && key.valid_in_24 || key.valid_now && !key.valid_in_24)
					return 'availability_nearly_invalid';
				else if (!key.valid_now && !key.valid_in_24)
					return 'availability_invalid';
				return '';
			}
        }
    };
    
    self.bounded_integer = function(value,min,max) {
        var int_val = parseInt(value,10);
        if (isNaN(int_val)) {
            return false;
        }
        if (min <= int_val && int_val <= max) {
            return true;
        }
        return false;
    };
    
    self.bounded_float = function(value,min,max) {
        var val = parseFloat(value);

        if (isNaN(val)) {
            return false;
        }
        if (min <= val && val <= max) {
            return true;
        }
        return false;
    };
    
    self.set_buttons = function(append_to, button_list) {  
        $(append_to).empty();
        for (var i=0; i<button_list.length; i++) {
            var data = button_list[i];
            data.id = (data.id || 'button_' + i);
            var selector = "#"+data.id;
            if(data.type === 'toggle'){
                $("#toggle_button_tmpl").tmpl2(data).appendTo(append_to);
            }
            else{
                $("#normal_button_tmpl").tmpl2(data).appendTo(append_to);
            }
            $(selector).button({
                disabled: data.disabled,
                label: (data.text || '&nbsp;'),
                text: (!!data.text),
                icons: (data.image ? {primary: 'image ' + data.image} : {})
            }).click(button_list[i].onClick);
        }
    };

    self.supported_uuid = function(device_uuid, f){
        if(device_uuid in $device_store.devices){
            return self.supported(f, $device_store.devices[device_uuid]['type']);
        }
        else{
            return false;
        }        
    }

    self.supported = function(execute_function,server_type) {
        if (enabled_functions[execute_function]!== undefined && !enabled_functions[execute_function]){
            //if the function has been listed in the enabled section and is false return false.
            return false;
        }
        else if (server_support[execute_function]!== undefined && $.inArray(server_type, server_support[execute_function]) == -1) {
            //if the function is listed in server support and the server type does not exist as a supported device for the function return false.
            return false;
        }
        //if no restrictions have been placed on the function return true.
        return true;
    };
    
    self.display_bytes = function(bytes){
        // input - integer representation of bytes in file
        // result - string representation of bytes, eg. "100 GB"
        if(isNaN(bytes)) return 0;
        var number_of_bytes = Number(bytes);
        var result = "";
        
        if (number_of_bytes > 1000000000){
            result = Math.round(number_of_bytes / 1024 / 1024 / 1024 ).toString() + " GB";//.format((number_of_bytes / 1024 / 1024 / 1024 ).toString);
        }else if(number_of_bytes > 1000000){
            result = Math.round(number_of_bytes / 1024 / 1024 ).toString() + " MB";//.format((number_of_bytes / 1024 / 1024 ).toString);
        }else if(number_of_bytes > 1000){
            result = Math.round(number_of_bytes / 1024 ).toString() + " KB";//.format((number_of_bytes / 1024 ).toString);
        }else{
        result = number_of_bytes.toString() + " bytes";//.format(number_of_bytes.toString);
        }
        return result;
    };

    self.date_stamp_to_position = function(date, pixel_offset, pixel_depth) {
        return (Date.parse(date) - pixel_offset) * pixel_depth;
    };
    
    self.format_cpl_title = function(input){
        // Format CPL Title, eg. "COLD-SOULS" -> "Cold Souls"
        var newVal = '';
        if( input != undefined){
            input = input.split('-');
            for(var substring_index in input){
                newVal += input[substring_index].toLowerCase() + ' ';
            }
            return $.capitalise(newVal);
        }else{
            return input;
        }
    };

    self.get_screen_list = function(){
        var output = $.values($.copy($device_store.screens));
        output.sort_screens();
        return output;
    }

    self.get_enabled_screen_list = function(){
        var screens = helpers.get_screen_list();
        var e_screens = [];
        for(var i = 0; i < screens.length; i++){
            var screen = screens[i];
            for(var di = screen.devices.length-1; di>=0; di--){
                var device = screen.devices[di];
                if(device.category == "sms" && device.enabled){
                    e_screens.push(screen);
                }
            }
        }
        return e_screens;
    };
    
    self.get_device_list = function(supported_function, exclude_list) {
        var output = [];
        for (var device_id in $device_store.devices) {
            var supported = self.supported(supported_function, $device_store.devices[device_id].type);
            var enabled = $device_store.devices[device_id].enabled;
            var not_excluded = (exclude_list == undefined || (jQuery.inArray(device_id, exclude_list) == -1));
            // fix'd
            var not_projector = $device_store.devices[device_id].category != "projector";
            var not_audio = $device_store.devices[device_id].category != "audio";
            var not_pos = $device_store.devices[device_id].category != "pos";

            if (enabled && (not_pos && not_projector && not_audio && supported && not_excluded)) {
                output.push($device_store.devices[device_id]);
            }
        }
        output.sort(self.categorised_device_sorting_function);
        return output
    };
    
    self.disk_space_rgb = function(percentage, warn_level, full_level){
        function weight_color(first_color, second_color, first_weight){
            var new_rgb = {};
            new_rgb['r'] = Math.ceil(first_color['r'] * first_weight  + second_color['r'] * (1 - first_weight));
            new_rgb['g'] = Math.ceil(first_color['g'] * first_weight  + second_color['g'] * (1 - first_weight));
            new_rgb['b'] = Math.ceil(first_color['b'] * first_weight  + second_color['b'] * (1 - first_weight));
            return new_rgb;
        }
        var fine_rgb = {'r' : 136, 'g' : 255, 'b' : 108};
        var warn_rgb = {'r' : 255, 'g' : 205, 'b' : 84};
        var full_rgb = {'r' : 255, 'g' : 84, 'b' : 84};
        var warn_weight = Math.max(0, (full_level - percentage) / (full_level - warn_level))
        return_rgb = (percentage < warn_level) ? fine_rgb : weight_color(warn_rgb, full_rgb, warn_weight);
        
        return 'rgb(' + return_rgb['r'] + ','+ return_rgb['g'] + ',' + return_rgb['b'] + ')';
    };
	
	self.pretty_duration_string = function(seconds) {
		//Need to round due to a bug in $.seconds_to_duration_string(seconds) [test with a value of seconds = 3599.7];
		seconds = Math.round(seconds);
		
		var sign = (seconds < 0) ? '-' : '';
		seconds = Math.abs(seconds);

		var text = $.seconds_to_duration_string(seconds);
		
		if(seconds >= 86400){
			var d = new Date();
			d.setTime(d.getTime() + seconds);
			text = days[d.getDay()];
		}
		else if(seconds >= 3600){
			text = parseInt(text.substring(0,2)) + "h" + text.substring(3,5) + "m";
		}
		else if(seconds >= 60){
			text = parseInt(text.substring(3,5)) + "m";
		}
		else{
			text = parseInt(text.substring(6,8)) + "s";
		}
		return sign + text;
	};
	
	self.toTitleCase = function(str) {
		return str.charAt(0).toUpperCase() + str.slice(1);
	};
	
	self.is_ie9 = function() {
		return (navigator.appVersion.indexOf('MSIE 9') !== -1);
	};
    
    self.pretty_json = function(text) {
        //Modified from http://stackoverflow.com/questions/4810841/how-can-i-pretty-print-json-using-javascript
        function syntax_colour(json) {
            json = JSON.stringify(json, null, 5);
            json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
                var cls = 'int_val';
                if (/^"/.test(match)) {
                    if (/:$/.test(match)) {
                        cls = 'key_val';
                    } else {
                        cls = 'str_val';
                    }
                } else if (/true/.test(match)) {
                    cls = 'bool_val yes';
                } else if (/false/.test(match)) {
                    cls = 'bool_val no';
                } else if (/null/.test(match)) {
                    cls = 'null_val';
                }
                //Unix timestamps
                else if (/(1\d{9})/.test(match)) {
                    cls = 'dt_val';
                    match = moment(match * 1000).format('YYYY-MM-DD HH:mm:ss');
                }
                return '<span class="' + cls + '">' + match + '</span>';
            });
        }
        var json;
        try {
            json = JSON.parse(text);
        } catch(e) {
            json = {error: 'Invalid JSON', reason: e.message};
        }
        dialog.open({
            title: 'Pretty JSON',
            hbtemplate: '#pretty_json_tmpl',
            data: {json: syntax_colour(json)}
        });
    };

    self.get_cookie = function(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for(var i=0; i<ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1);
            if (c.indexOf(name) != -1) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    };

    self.get_kdm_icon_class = function(valid_now, valid_in_future, expires_in_24){
        if(valid_now){
            if(expires_in_24){
                return 'kdm_content_expires_24';
            }
            else{
                return 'kdm_content_ok';
            }
        }
        else{
            if(valid_in_future){
                return 'kdm_content_future';
            }
            else{
                return 'kdm_content_invalid';
            }
        }
    }
}


// Copied from handlebars, and defining outside of function scope for CPU++
helpers.private = {
    escape: {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&quot;',
        '"': '&#x27;',
        '`': '&#x60;'
    },
    badChars: /[&<>''`]/g,
    possible: /[&<>''`]/,
    escapeChar: function (chr) {
        return helpers.private.escape[chr] || '&amp;';
    }
};
Object.defineProperty(String.prototype, 'escape', {
    value: function() {
        if(!helpers.private.possible.test(this)) { return this; }
        return this.replace(helpers.private.badChars, helpers.private.escapeChar);
    },
    enumerable: false
});

//Syntactic sugar for sorting an array by screen_identifier
Object.defineProperty(Array.prototype, 'sort_screens', {
    value: function(sort_property) {
        //Default arg for sorting objects. Pass null if sorting strings
        if(sort_property === undefined) {
            sort_property = 'identifier';
        }
        this.sort(function(a,b) {
            return helpers.screen_compare(a, b, sort_property);
        });
        return this;
    },
    enumerable: false      
});
    
function BoxAT8(params){
    // Exposed functions
    this.open = open;
    this.close = close;
    this.update = update;
    var self = this;

    // Init
    var base_tmpl = $('#boxAT8_tmpl').tmpl2();
    $('body').append(base_tmpl);

    var dom = $('#boxAT8');
    var wrapper = $('#boxAT8_wrapper');
    var content_wrapper = $('#boxAT8_wrapper .content_wrapper');
    var content = $('#boxAT8_wrapper .at_content');
    var header = $('#boxAT8_wrapper .at_header');
    var buttons = $('#boxAT8_wrapper .at_buttons');
    var content_child = $('#dialog_contents');
    var onclose = null;
    var cool = false;
    $('#boxAT8_wrapper .at_close').click(close);
    $("#main_section").resize(function(e){
        position();
    });
    dom.hide();

    function open(params){
        params = parse_params(params);
        header.empty().append($('#boxAT8_header_tmpl').tmpl2(params));
        update_content(params);
        buttons.empty();
        render_buttons(params.buttons);
        
        self.customheight = params.customheight;
        self.customwidth = params.customwidth;
        self.stretchcontent = params.stretchcontent;
        
        wrapper.removeAttr("class");
        wrapper.addClass(params.wrapper_class);
        
        onclose = params.close;
        content.css("min-height", params.height);
        content.css("min-width", params.width);
        if(params.class){
            content.addClass(params.class)
        };
        dom.css({
            display: "block"
        });
        position();
        //Handle window resizing
        wrapper.resize(function(){
            position();
        });
        //Handle content resizing
        $('#dialog_contents').resize(function(){
            position();
        });
        // Make Draggable, remove if causes ANY issues
        wrapper.draggable({
            cursor: "move",
            scroll: false,
            handle: header
        })
        // Attach key bindings, mainly esc = close
        $(document).on('keyup.boxAT8', function(e){
            if (e.keyCode == 27){
                close();
            }
        });

        if(cool){
            $('#main_section, #header_wrapper, #screen_status_bar').css("-webkit-filter", "blur(1px) grayscale(0.8)");    
        }
		
        //Focus first text box if exists
		if(params.focus) {
            var dwq = $('#boxAT8_wrapper .at_content input[type="text"]:first')
			dwq.focus();
        }
    }

    function update_content(params){        
        if(params.template !== undefined){
            content.empty().append($('#boxAT8_content_tmpl').tmpl(params));
        }
        if(params.hbtemplate !== undefined){
            var wrapper = $('#boxAT8_hbcontent_tmpl').tmpl2();
            $(params.hbtemplate).tmpl2($.extend({wrapper_class: params.wrapper_class}, params.data), wrapper);
            content.empty().append(wrapper);
        }
    }
    
    function update(params){
        params = parse_params(params);
        if(params.title !== undefined){
            header.empty().append($('#boxAT8_header_tmpl').tmpl2(params));
        }
        update_content(params);
        if(params.height) $('#dialog_contents').css("min-height", params.height);
        if(params.width) $('#dialog_contents').css("min-width", params.width);
        render_buttons(params.buttons);
        position();
    }

    function close(){
        $(document).off('keyup.boxAT8');
        dom.hide();
        //Prevent leak of global variables
        header.empty();
        buttons.empty();
        content.empty();
        content.removeAttr("style");
        wrapper.off('resize');
        self.customheight = null;
        self.customwidth = null;
        self.stretchcontent = null;
        $('#dialog_contents').off('resize');
        if(onclose) {
            onclose();
            onclose = null;
        }

        if(cool){
            $('#main_section, #header_wrapper, #screen_status_bar').css("-webkit-filter", "");
        }
    }

    function render_buttons(btns){
        if(btns){
            content_wrapper.css("padding-bottom", "50px");
            buttons.css("display", "block");
            buttons.empty().append($('#boxAT8_buttons_template').tmpl2(btns));
            for (var i=0; i< btns.length; i++) {
                $('#at_button_'+i).button().click(btns[i].action);
            }
        }
        else{
            content_wrapper.css("padding-bottom", "10px");
            buttons.css("display", "none");
        }
    }

    function parse_params(params){
        if (params.data === undefined)
            params.data = {};

        return params;
    }

    function position(){
        if(self.customheight){
            wrapper.css({"height": self.customheight,
                         "min-height": self.customheight,
                         "max-height": self.customheight});
        }else{
            wrapper.css({"height": "auto",
                         "min-height": "",
                         "max-height": ""});
        }
        if(self.customwidth){
            wrapper.css({"width": self.customwidth,
                         "min-width": self.customwidth,
                         "max-width": self.customwidth});
        }else{
            wrapper.css({"width": "",
                         "min-width": "",
                         "max-width": ""});
        }
        if (self.stretchcontent){
            $('#dialog_contents').css("height", "93%");
        }else{
            $('#dialog_contents').css("height", "");
        }
		//account for padding too
        var content_height = content.outerHeight() + 100;
        var window_height = $('body').height()*0.8;
        if(content_height > window_height){
            wrapper.css("height", "80%");
        }
    }
}

function AAMDialog(dialog_contents_selector, fancy_box_selector) {
    var self = this;
    self.box = new BoxAT8();

    self.open = function(parameters) {
        /*
            {
                title : string,
                buttons : [{action=function,text=string}] add img later,
                template : sub_template to display,
                data : data for that sub tempate
                width:,
                height:,
                close: function,
		        focus: set true to autofocus the first text-box
            }
        */

        self.box.open(parameters);
    };    
    
    self.close = function() {
        self.box.close();
        return false;
    };
    
    self.update = function(parameters){
        self.box.update(parameters);
    };
}

RegExp.escape = function(text) {
    if (!arguments.callee.sRE)
    {
      var specials = ['/', '.', '*', '+', '?', '|',
        '(', ')', '[', ']', '{', '}', '\\',
        '^', '$', '!', '"', '%',
        ';', ':', '@', '~', '#', '<', '>',
        '/', "'", '`'];
      arguments.callee.sRE = new RegExp('(\\' + specials.join('|\\') + ')', 'g');
    }
    return text.replace(arguments.callee.sRE, '\\$1');
};

function ProgressDisplay() {
    var self = this;
    var status = 'hidden';
    var hide_timeout = undefined;
    var next_action_id = 0;
    var action_queue = [];
    var id_ref = {};
    var display = $('#progress_display');
    var message = $('#progress_message');
    var image = $('#progress_image');
    display.hide().css('height','0px');
    
    function _show() {
        if (status == 'hiding' || status == 'hidden' ) {
            display.stop(true);
            if (status == 'hiding') {
                clearTimeout(hide_timeout);
            }
            status = 'showing';
            display.show();
            message.textTruncate(120);
            display.animate({height:'150px'}, 500, 'swing', _shown);
        }
    }
    function _shown() {
        status = 'shown';
    }
    
    function _hide() {
        if (status == 'showing' || status == 'shown' ) {
            status = 'hiding';
            var animation = function() {
                display.stop(true);
                display.animate({height:'0px'}, 500, 'swing', _hidden);
            };
            hide_timeout = setTimeout(animation, 2000);
        }
    }
    function _hidden() {
        status = 'hidden';
        display.hide();
    }
    
    function _change_text(new_text) {
        message.stop(true,true);
        message.animate({opacity:'hide'}, 600, 'linear', function() {
            message.text(new_text);
            message.animate({opacity:'show'}, 300, 'linear');
        });
    }
    
    function _update_display() {
        if (action_queue.length > 0) {
            _change_text(action_queue[0].action);
            image.removeClass('done');
            _show();
        } else {
            _change_text('Complete');
            image.addClass('done');
            _hide();
        }
    }
    
    self.add_action = function(action) {
        var action = {action: action};
        action_queue.push(action);
        id_ref[next_action_id] = action;
        _update_display();
        return next_action_id++;
    };
    
    self.remove_action = function(id) {
        var action = id_ref[id];
        var index = $.inArray(action, action_queue);
        id_ref[id] = undefined;
        action_queue.splice(index, 1);
        _update_display();
    };
}

function AAMTransferDialog(parameters){
    var self = this;
    self.buttons = parameters.buttons; 
    self.template = parameters.template;
    self.hbtemplate = parameters.hbtemplate;
    self.data = parameters.data; 
    self.width = parameters.width; 
    self.height = parameters.height; 
    self.title = parameters.title;
    self.transfer_time = undefined; 
    self.content_total_size = parameters.content_total_size;
    
    self.selected_content = $.val_or_default(parameters.selected_content, []);
    self.pre_selected_ids = $.val_or_default(parameters.pre_selected_ids, []);
    self.pre_select_all = $.val_or_default(parameters.pre_select_all, false);
    self.hidden_device_ids = $.val_or_default(parameters.hidden_device_ids, []);
    self.selected_devices_caption = $.val_or_default(parameters.selected_devices_caption, gettext("Selected Devices"));
    
    self.open = function(transfer, time_selection) {
        time_selection = $.val_or_default(time_selection, true);
        dialog.open(self);
        if(transfer){
            self.setup_transfer_dialog(time_selection);
        }else{
            self.setup_delete_dialog();
        }
    }
    
    self.setup_transfer_dialog = function(time_selection){
        self.transfer_time = undefined;
        self._setup_device_selection();
        self._setup_content_list();
        if (time_selection) {
            self._setup_transfer_time_selection();
        }else{
            $('#global_transfer_time_select').remove();
        }
        if( self.pre_selected_ids.length == 0){
            $('#at_button_0').addClass('content_tranfer_btn_disabled ui-state-disabled');
        }
    }
    
    self.setup_delete_dialog = function(){
        self._setup_device_selection();
        self._setup_content_list();
        if( self.pre_selected_ids.length == 0){
            $('#at_button_0').addClass('content_tranfer_btn_disabled ui-state-disabled');
        }
    }
    self._setup_transfer_time_selection = function(){
        $('#global_transfer_time_select').transferTimePicker();
    }
    self._setup_device_selection = function(){
        $('.global_dialog_device_wrapper').selectedDeviceList({"pre_selected_ids" : self.pre_selected_ids, "hidden_device_ids" : self.hidden_device_ids, "pre_select_all" : self.pre_select_all, "selected_devices_caption":self.selected_devices_caption});
    }
    self._setup_content_list = function(){
        $('.global_content_list_wrapper').selectedContentList(self.selected_content, self.content_total_size);
    }
    self.dialog_selected_devices = function(){
        return $('.global_dialog_device_wrapper').selectedDeviceList('getSelectedServerIds');
    }
    self.dialog_get_transfer_time = function(){
        return $('#global_transfer_time_select').transferTimePicker('getTransferTime');
    }
}

function AAMFeedbackDialog(parameters){
    var self = this;
    self.title = $.val_or_default(parameters.title, gettext("Action Feedback"));
    self.selected_device_ids = $.val_or_default(parameters.selected_device_ids, []);
    self.selected_content = $.val_or_default(parameters.selected_content, []);
    self.close_function = parameters.close_function;
    self.open = function(){
        
        var total_actions = self.selected_device_ids.length * self.selected_content.length;
        var buttons = [];
        buttons.push({
            'text': gettext('Done'), 
            'action': function() { dialog.close();}
        });
        var selected_devices = [];
        for(var device_id in self.selected_device_ids){
            selected_devices.push(helpers.get_device(self.selected_device_ids[device_id]));
        }
        data = {'selected_devices' : selected_devices, 'selected_content' : self.selected_content, 'total_actions' : total_actions};
        var feedback_dialog = dialog.open({
            'title': self.title,
            'template' : '#global_feedback_dialog',
            'data' : data,
            'buttons' : buttons,
            'close': self.close_function
        });
    }
    
    //This is just a small modification on the content callback to make the kdm functions compatible with the feedback dialog...
    self._global_kdm_callback = function(input){
        for(var m_index in input.messages){
            exec_state = null;
            if (input.messages[m_index].state != undefined){
                exec_state = input.messages[m_index].state;
                $('#global_dialog_feedback_progress_bar_inner_wrapper').hide();
            }
            
            var key_id = input.messages[m_index].key_id;
            var device_id = input.messages[m_index].device_id;
            var message = input.messages[m_index].message;
            
            var feedback_item_wrapper = $('.jq_global_dialog_feedback_wrapper[data-device_id=' + device_id + '][data-content_id=' + key_id + ']');
            
            if(input.messages[m_index].type == 'action'){
                var action_id = input['messages'][m_index].action_id;
                $action_store.actions[action_id] = {
                    show_pending: true,
                    callback: self._global_content_action_handler
                };
                feedback_item_wrapper.attr('action_id', action_id);
            }else if(input.messages[m_index].type == 'success'){
                self._global_content_feedback_update_dom(feedback_item_wrapper, true, message, exec_state);
            }else if(input.messages[m_index].type == 'error'){
                self._global_content_feedback_update_dom(feedback_item_wrapper, false, message, exec_state);
            }
        }
    }
    
    self._global_content_callback = function(input){
        for(var m_index in input.messages){
            transfer_state = null;
            if (input.messages[m_index].state != undefined){
                transfer_state = input.messages[m_index].state;
                $('#global_dialog_feedback_progress_bar_inner_wrapper').hide()
            }

            var content_id = input.messages[m_index].content_id ? input.messages[m_index].content_id : input.messages[m_index].playlist_id;
            var device_id = input.messages[m_index].device_id;
            var message = input.messages[m_index].message;
                
            var feedback_item_wrapper = $('.jq_global_dialog_feedback_wrapper[data-device_id=' + device_id + '][data-content_id=' + content_id + ']');
            
            if(input.messages[m_index].type == 'action'){
                var action_id = input['messages'][m_index].action_id;
                $action_store.actions[action_id] = {
                    show_pending: true,
                    callback: self._global_content_action_handler
                };
                feedback_item_wrapper.attr('action_id', action_id);
            }else if(input.messages[m_index].type == 'success'){
                self._global_content_feedback_update_dom(feedback_item_wrapper, true, message, transfer_state);
            }else if(input.messages[m_index].type == 'error'){
                self._global_content_feedback_update_dom(feedback_item_wrapper, false, message, transfer_state);
            }
        }
    }
    
    self._global_content_action_handler = function(action_id, success, message){
        var feedback_item_wrapper = $('.jq_global_dialog_feedback_wrapper[action_id=' + action_id + ']');
        self._global_content_feedback_update_dom(feedback_item_wrapper, success, message);
    }
    
    self._global_content_feedback_update_dom = function(dom_element, success, message, transfer_state){
        var p_bar = $('#global_dialog_feedback_progress_bar'); //Progress bar
        
        //Update progress bar...
        p_bar.attr('completed_actions', parseInt(p_bar.attr('completed_actions')) + 1);
        p_bar.css({'width' : 100 * p_bar.attr('completed_actions')/p_bar.attr('total_actions_count') + '%'});
        p_bar.toggleClass('global_dialog_feedback_progress_bar_failed', !success);
        
        //Update individual states
        var class_to_assign = success ? 'global_dialog_action_success' : 'global_dialog_action_failed';
        if (transfer_state != "queued"){
            $('.global_dialog_action_pending', dom_element).switchClass('global_dialog_action_pending', class_to_assign, 'fast', function(){
                //Update per content (parent) states
                var content_id = dom_element.attr('data-content_id');
                var parent_indicator = $('.global_dialog_parent_action_status[data-content_id=' + content_id + ']');
                if(!success){
                    parent_indicator.switchClass('global_dialog_action_pending', 'global_dialog_action_failed', 'fast');
                };
                var pending_count = $('.global_dialog_child_action_status.global_dialog_action_pending[data-content_id=' + content_id + ']').length;
                
                if(success && pending_count == 0){
                    parent_indicator.switchClass('global_dialog_action_pending', 'global_dialog_action_success', 'fast');
                }
            });
        }
        $('.jq_feedback_text_status', dom_element).fadeOut('fast', function(){
                $(this).html(message).fadeIn('fast');
            });
    }
}

function formatSeconds(seconds){
    var t = new Date(1970,0,1);
    t.setSeconds(seconds);
    var s = t.toTimeString().substr(0,8);
    if(seconds > 86399)
    	s = Math.floor((t - Date.parse("1/1/70")) / 3600000) + s.substr(2);
    return s;
}

function SaveDialog(options){
    var save_function = options['save_function'];
    var callback = options['callback'];
    var text = options['text'];
    var buttons = [];
    var data = {"text": text};
    var callback = callback;

    var validate_and_execute = function(){
        if (!$(this).hasClass('disabled')) {
            var form = $('#save_as_form').validate({
                errorPlacement: function(error, element) {
                    $(element).attr({"title": error.text()});
                },
                highlight: function(element){
                    $(element).addClass("error");
                },
                unhighlight: function(element){
                    $(element).removeClass("error");
                }
            }).form();
            if( form ){
                save_function($('#save_as_text').val());
            }
        }
    }

    buttons.push({
        'text': gettext('Save'),
        'action': validate_and_execute,
        '_class':'jq_disable_on_complete'
    });
    
    this.open = function(){
        dialog.open({
            'title': gettext('Save As'), 
            'buttons': buttons, 
            'width': 'auto',
            'height': 'auto',
            hbtemplate: '#save_as_dialog_tmpl',
            'data':data,
            'close':callback
        });
        $('#save_as_text').keypress(function(event){
            if( event.keyCode == 13){
                event.preventDefault();
                validate_and_execute();
                return false;
            }
        });
        $('#save_as_form').submit(function(event){
            event.preventDefault();
            return false;
        });
    }
}

// Transfer Time Picker
(function( $ ){

  var methods = {
    init : function( options ) { 
        return this.each(function(){
            var $this = $(this), 
                data = $this.data('transferTimePicker')
            
            if (!data) {
                $('#global_transfer_time_select_tmpl').tmpl2().appendTo($this);
                
                $this.data('transferTimePicker', {
                    transferTime : undefined, 
                    transferTimePicker: $this
                });
                
                $("#content_transfer_dialog_date_picker").datetimepicker({
                    onSelect: function(){
                        var tmp = $this.data('transferTimePicker'); 
                        var some_time = $("#content_transfer_dialog_date_picker").datetimepicker('getDate');
                        tmp.transferTime = $.datepicker.formatDate('yy-mm-dd', some_time) +' '+ $.datepicker.formatTime('hh:mm:00', {hour:some_time.getHours(), minute:some_time.getMinutes(), second:some_time.getSeconds()})
                        $("#global_transfer_dialog_selected_date").html(tmp.transferTime);
                        $this.data('transferTimePicker', tmp);
                        time_selection_updated();
                    },
                    minDate: new Date()
                });
                $('#global_transfer_dialog_time_asap').on('click.transferTimePicker', function(){
                    var tmp = $this.data('transferTimePicker'); 
                    tmp.transferTime = 'ASAP'
                    $this.data('transferTimePicker', tmp);
                    $('#global_transfer_dialog_time_asap').addClass("content_transfer_dialog_time_clicked").siblings().removeClass('content_transfer_dialog_time_clicked');
                    $("#global_transfer_dialog_date_picker_wrapper").hide();
                    $("#global_transfer_dialog_selected_date").html(gettext('Now'));
                    $("#global_transfer_dialog_selected_date_wrapper").show();
                    $('.at_content').css({scrollTop: $('#dialog_contents').innerHeight()});
                    time_selection_updated();
                });
                $('#global_transfer_dialog_time_tonight').on('click.transferTimePicker', function(){
                    var tmp = $this.data('transferTimePicker'); 
                    tmp.transferTime = 'tonight';
                    $this.data('transferTimePicker', tmp);
                    $('#global_transfer_dialog_time_tonight').addClass("content_transfer_dialog_time_clicked").siblings().removeClass('content_transfer_dialog_time_clicked');
                    $("#global_transfer_dialog_date_picker_wrapper").hide();
                    $("#global_transfer_dialog_selected_date").html(gettext('Tonight'));
                    $("#global_transfer_dialog_selected_date_wrapper").show();
                    $('.at_content').css({scrollTop: $('#dialog_contents').innerHeight()});
                    time_selection_updated();
                });
                $('#global_transfer_dialog_time_future').on('click.transferTimePicker', function(){
                    var tmp = $this.data('transferTimePicker'); 
                    $('#global_transfer_dialog_time_future').addClass("content_transfer_dialog_time_clicked").siblings().removeClass('content_transfer_dialog_time_clicked');
                    $("#global_transfer_dialog_date_picker_wrapper").show();
                    $('#dialog_contents').css({'scrollTop' : $('.global_transfer_wrapper').height()})
                    if(tmp.transferTime == undefined || tmp.transferTime == 'tonight' || tmp.transferTime == 'ASAP'){
                        $("#content_transfer_dialog_date_picker").datetimepicker('setDate', (new Date()) );
                        tmp.transferTime = new Date();
                    }
                    else{
                        $("#content_transfer_dialog_date_picker").datetimepicker('setDate', (tmp.transferTime) );
                    }
                    
                    var some_time = $("#content_transfer_dialog_date_picker").datetimepicker('getDate');
                    some_time = $.datepicker.formatDate('yy-mm-dd', some_time) +' '+ $.datepicker.formatTime('hh:mm:00', {hour:some_time.getHours(), minute:some_time.getMinutes(), second:some_time.getSeconds()})
                    $("#global_transfer_dialog_selected_date").html(some_time);
                    $("#global_transfer_dialog_selected_date_wrapper").show();
                    $this.data('transferTimePicker', tmp);
                    $('.at_content').css({scrollTop: $('#dialog_contents').innerHeight()});
                    time_selection_updated();
                });
                function time_selection_updated(){
                    if($('#global_transfer_time_select').transferTimePicker('getTransferTime',false) == undefined){
                        $('#at_button_0').addClass('content_tranfer_btn_disabled ui-state-disabled');
                    }else{
                        if($('.global_dialog_device_wrapper').length == 0){
                            $('#at_button_0').removeClass('content_tranfer_btn_disabled ui-state-disabled');
                        }else if($('.global_dialog_device_wrapper').selectedDeviceList('getSelectedServerIds', false).length > 0){
                            $('#at_button_0').removeClass('content_tranfer_btn_disabled ui-state-disabled');
                        }
                    }
                }
                time_selection_updated();
            }
        })
    },
    getTransferTime : function( validate ) {
        if (this.data('transferTimePicker') == undefined) {
            return undefined;
        }
        var transferTime = this.data('transferTimePicker').transferTime
        if (transferTime != undefined) {
            return transferTime;
        }else{
            $('.at_content').css({scrollTop: $('#dialog_contents').innerHeight()});
            if( validate != false ){
                $('.global_dialog_time_wrapper').effect('pulsate', {times:2}, 500);
            }
            return undefined;
        }
    },
     destroy : function( ) {

       return this.each(function(){

         var $this = $(this),
             data = $this.data('transferTimePicker');

         // Namespacing FTW
         $(window).off('.transferTimePicker');
         data.transferTimePicker.remove();
         $this.removeData('transferTimePicker');

       })

     }
  };

  $.fn.transferTimePicker = function( method ) {
    
    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist on jQuery.transferTimePicker' );
    }    
  
  };

})( jQuery );

// Content list
(function( $ ){

  var methods = {
    init : function( selected_content , content_total_size ) { 
        return this.each(function(){
            var $this = $(this), 
                data = $this.data('selectedContentList')
            if (!data) {
                $this.html($('#global_dialog_content_list_tmpl').tmpl2(
					{selected_content: selected_content, content_total_size: content_total_size}
				));
            }
        })
     },
     destroy : function( ) {
       return this.each(function(){

         var $this = $(this),
             data = $this.data('selectedContentList');

         // Namespacing FTW
         $(window).off('.selectedContentList');
         data.selectedContentList.remove();
         $this.removeData('selectedContentList');

       })
     }
  };

  $.fn.selectedContentList = function( method ) {
    
    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist on jQuery.selectedContentList' );
    }    
  
  };

})( jQuery );

// Selected Devices
(function( $ ){

  var methods = {
    init : function( options ) {
        return this.each(function(){
            var $this = $(this), 
                data = $this.data('selectedDeviceList')
            if (!data) {
                // validate
                var pre_selected_ids = $.val_or_default(options.pre_selected_ids, []);
                var hidden_device_ids = $.val_or_default(options.hidden_device_ids, []);
                var selected_devices_caption = $.val_or_default(options.selected_devices_caption, gettext("Selected Devices"));
                
                // append devices template
                $this.html($('#global_dialog_device_list_tmpl').tmpl2({
					selected_devices_caption: selected_devices_caption,
					selected_devices: helpers.get_device_list("transfer", hidden_device_ids),
					ignored_device_types: ['ftp', 'watchfolder']
				}));
                
                // preselect devices if specified (for when a delete is called from a specific server page)
                if(options.pre_select_all == true){
                    for( var device_id in $device_store.devices ){
                        $('#jq_transfer_' + device_id).attr('checked', true);
                    }
                }else{
                    for (var i =0; i < pre_selected_ids.length; i++) {
                        $('#jq_transfer_' + pre_selected_ids[i]).attr('checked', true);
                    }
                }
                
                // jquery UI and handlers
                $('.global_dialog_device_wrapper .screen_btn').button();
                $('.global_dialog_device_wrapper .screen_btn').click(function(){
                    $('.dialog_screen_selection_error').hide();
                    device_selection_updated();
                });
                $('#global_dialog_device_all').button().click(function(){
                    $('.global_dialog_device_wrapper .screen_btn').attr('checked', true).button("refresh");
                    $('.dialog_screen_selection_error').hide();
                    device_selection_updated();
                });
                $('#global_dialog_device_none').button().click(function(){
                    $('.global_dialog_device_wrapper .screen_btn').attr('checked', false).button("refresh");
                    $('.dialog_screen_selection_error').hide();
                    device_selection_updated();
                });
                function device_selection_updated(){
                    var server_ids = []; 
                    $('.global_dialog_device_wrapper .screen_btn:checked').each(function(){
                        server_ids.push($(this).attr('server_id'));
                    });
                    if(server_ids.length === 0){
                        $('#at_button_0').addClass('content_tranfer_btn_disabled ui-state-disabled');
                    }
                    else{
                        if($('#global_transfer_time_select').length == 0){
                            $('#at_button_0').removeClass('content_tranfer_btn_disabled ui-state-disabled');
                        }else if( $('#global_transfer_time_select').transferTimePicker('getTransferTime',false) != undefined){
                            $('#at_button_0').removeClass('content_tranfer_btn_disabled ui-state-disabled');
                        }
                    }
                }
                device_selection_updated();
            }
        })
     },
     getSelectedServerIds : function( validate ){
            // grab selected server IDs
            var server_ids = [];
            $('.global_dialog_device_wrapper .screen_btn:checked').each(function(){
                server_ids.push($(this).attr('server_id'));
            });
            if(server_ids.length == 0 && validate != false){
                $('.global_dialog_device_wrapper').effect('pulsate', {times:2}, 500);
            }
            return server_ids;
     },
     destroy : function( ) {
       return this.each(function(){

         var $this = $(this),
             data = $this.data('selectedDeviceList');

         // Namespacing FTW
         $(window).off('.selectedDeviceList');
         data.selectedDeviceList.remove();
         $this.removeData('selectedDeviceList');

       })
     }
  };

  $.fn.selectedDeviceList = function( method ) {
    
    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist on jQuery.selectedDeviceList' );
    }    
  
  };

})( jQuery );
