# 2017.08.13 21:52:36 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\playback\migration\versions\001_everything.py
from serv.configuration import cfg
from serv.storage.database.primary import database as main_db
from sqlalchemy import *
from sqlalchemy.orm import sessionmaker
from serv.lib.utilities.helper_methods import console_status, safe_directory_name
from serv.core.tasks.reconcile_logs import CODE_START_AND_END_OFF
import json
import logging
import os
import uuid
import shutil
import time
meta = MetaData()
migrate_version = Table('migrate_version', meta, Column('repository_id', String(250), primary_key=True, nullable=False), Column('repository_path', Text()), Column('version', Integer()))
log_file_old = Table('log_file', meta, Column('uuid', String(36), nullable=False, primary_key=True), Column('created', Integer, nullable=False), Column('last_modified', Integer, nullable=False), Column('device_uuid', String(36), nullable=False), Column('full_path', String(200)), Column('start_date', Date, nullable=False), Column('parsed', Boolean, nullable=False), Column('parsed_date', Float), Column('error', String(200)), Column('thumbprint', String(50)), Column('serial', String(50)), Column('type', String(36), nullable=False))
log_file_new = Table('log_file_new', meta, Column('uuid', String(36), nullable=False, primary_key=True), Column('created', Integer, nullable=False), Column('last_modified', Integer, nullable=False), Column('date', Date, nullable=False), Column('device_ip_address', String(50), nullable=False), Column('screen_identifier', String(3), nullable=False), Column('dnqualifier', String(50)), Column('serial', String(50)), Column('unencrypted', Boolean, nullable=False), Column('pull_attempted', Boolean, nullable=False), Column('pulled', Boolean, nullable=False), Column('parse_attempted', Boolean, nullable=False), Column('parsed', Boolean, nullable=False), Column('repull_marked', Boolean, nullable=False), Column('absolute_file_path', String(200)), Column('error_message', String(200)), Column('no_playouts', Boolean), Column('signed', Boolean))
tms_playback_log = Table('tms_playback_log', meta, Column('id', Integer, nullable=False, primary_key=True), Column('created', Float, nullable=False), Column('last_modified', Float, nullable=False), Column('device_uuid', String(36), nullable=False), Column('thumbprint', String(36), nullable=False), Column('screen_identifier', String(3), nullable=False), Column('serial', String(36), nullable=True), Column('start_time', Float, nullable=True), Column('end_time', Float, nullable=True), Column('start_position', Float, nullable=True), Column('end_position', Float, nullable=True), Column('duration', Float, nullable=True), Column('state_changes', Text, nullable=True), Column('cpl_uuid', String(36), nullable=True))
live_log = Table('live_log', meta, Column('uuid', String(36), nullable=False, primary_key=True), Column('created', Integer, nullable=False), Column('last_modified', Integer, nullable=False), Column('start', Integer), Column('end', Integer), Column('cpl_uuid', String(50), nullable=False), Column('spl_uuid', String(50)), Column('state_changes', Text), Column('device_ip_address', String(50), nullable=False), Column('screen_identifier', String(3), nullable=False), Column('dnqualifier', String(50)), Column('serial', String(50)), Column('parsed', Boolean, nullable=False), Column('feature_cpl_uuid', String(50)), Column('content_kind', String(16)), Column('meta', Text))
playback = Table('playback', meta, Column('uuid', String(36), nullable=False, primary_key=True), Column('created', Integer, nullable=False), Column('last_modified', Integer, nullable=False), Column('deleted', Boolean, nullable=False, default=False), Column('start', Integer), Column('end', Integer), Column('duration', Integer), Column('intermission_start', Integer), Column('intermission_end', Integer), Column('screen_identifier', String(3), nullable=False), Column('dnqualifier', String(50)), Column('device_ip_address', String(50), nullable=False), Column('serial', String(50)), Column('complex_identifier', String(50), nullable=False), Column('feature_cpl_uuid', String(50)), Column('content_kind', String(16)), Column('cpl_uuid', String(50), nullable=False), Column('merge_error_code', Integer, nullable=True), Column('live_log_uuid', String(50), ForeignKey('live_log.uuid', onupdate='CASCADE', ondelete='SET NULL', deferrable=True)), Column('meta', String(500)))

def analyse_state_changes(log_entry):
    """
    Calculate total playout time (minus pauses) and verify whether we saw an intermission or not during a clip playback.
    We assume there is a max of 1 intermission per clip playback
    """

    def __is_intermission(stoppage_start, stoppage_end, clip_start, clip_end):
        """
        Validate stoppage; check to see if it looks intermission-y
        """
        CLIP_BUFFER = 10
        MIN_DURATION = 240
        clip_buffer = (clip_end - clip_start) / CLIP_BUFFER
        if stoppage_end - stoppage_start > MIN_DURATION:
            if stoppage_start - clip_start > clip_buffer:
                if clip_end - stoppage_end > clip_buffer:
                    if stoppage_start < stoppage_end:
                        return True
        return False

    output = {'intermission_start': None,
     'intermission_end': None}
    state_changes = json.loads(log_entry['state_changes'])
    clip_start = int(log_entry['start'])
    clip_end = int(log_entry['end'])
    total_stoppage_time = 0
    previous_state = {}
    start_of_stoppage = None
    end_of_stoppage = None
    for state_change in state_changes:
        if state_change['state'] in ('stop', 'pause', 'clip_unload') and previous_state.get('state') == 'play':
            start_of_stoppage = state_change['time']
        elif state_change['state'] in ('play', 'clip_unload') and start_of_stoppage:
            end_of_stoppage = state_change['time']
        elif previous_state.get('state') == 'clip_unload' and state_change['state'] == 'clip_load':
            start_of_stoppage = previous_state['time']
            end_of_stoppage = state_change['time']
        previous_state = state_change
        if start_of_stoppage and end_of_stoppage:
            total_stoppage_time += end_of_stoppage - start_of_stoppage
            if __is_intermission(start_of_stoppage, end_of_stoppage, clip_start, clip_end):
                output['intermission_start'] = start_of_stoppage
                output['intermission_end'] = end_of_stoppage
                break
            start_of_stoppage = None
            end_of_stoppage = None

    output['duration'] = clip_end - clip_start - total_stoppage_time
    return output


def generate_log_file_uuid(ip, date, unencrypted):
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, str(ip + str(date) + unencrypted)))


def upgrade(migrate_engine):
    print 'UPGRADING'
    logging.info('Upgrading playback db')
    meta.bind = migrate_engine
    conn = migrate_engine.connect()
    Session = sessionmaker(bind=migrate_engine)
    session = Session()
    session.execute('DROP TABLE IF EXISTS live_log')
    session.execute('DROP TABLE IF EXISTS playback')
    session.execute('DROP TABLE IF EXISTS log_file_new')
    session.execute('DROP TABLE IF EXISTS playback_log')
    main_db.set_up()
    try:
        device_info = {}
        screens = main_db.Session.query(main_db.Screen).join(main_db.Device).filter(main_db.Device.category == 'sms')
        for screen in screens:
            for device in screen.devices:
                device_info[device.uuid] = {'screen_identifier': screen.identifier,
                 'ip': device.ip_address}

        logging.info('Migrating log file entries')
        log_file_new.create()
        session.commit()
        lf_uuids = set()
        logs = session.query(log_file_old)
        total = int(logs.count())
        count = 0
        skipped = 0
        inserts = []
        for log in logs:
            device = device_info.get(log.device_uuid, {'screen_identifier': 'N/A',
             'ip': '0.0.0.0'})
            if log.full_path and os.path.exists(log.full_path):
                log.full_path = log.full_path.replace(log.device_uuid, safe_directory_name(device['screen_identifier']))
                lf_uuid = generate_log_file_uuid(device['ip'], log.start_date, log.type)
                if lf_uuid in lf_uuids:
                    skipped += 1
                    continue
                lf_uuids.add(lf_uuid)
                inserts.append({'uuid': lf_uuid,
                 'screen_identifier': device['screen_identifier'],
                 'device_ip_address': device['ip'],
                 'serial': log.serial or 'n/a',
                 'dnqualifier': log.thumbprint or 'n/a',
                 'created': log.created,
                 'last_modified': log.last_modified,
                 'absolute_file_path': log.full_path,
                 'parsed': False,
                 'date': log.start_date,
                 'unencrypted': log.type != 'encrypted',
                 'pulled': True,
                 'pull_attempted': True,
                 'parse_attempted': False,
                 'repull_marked': False,
                 'error_message': log.error})
            else:
                skipped += 1
            count += 1
            console_status(count, total, True)

        print
        if inserts:
            migrate_engine.execute(log_file_new.insert(), inserts)
        print 'Skipped: ' + str(skipped)
        print 'Migrated: ' + str(len(inserts))
        log_dir = os.path.join(cfg.lms_library_directory(), 'device_store')
        for device_uuid, info in device_info.iteritems():
            old_dir = os.path.join(log_dir, device_uuid)
            if os.path.exists(old_dir):
                new_dir = os.path.join(log_dir, safe_directory_name(info['screen_identifier']))
                print 'Renaming folder from ' + str(old_dir) + ' > ' + str(new_dir)
                if not os.path.exists(new_dir):
                    os.mkdir(new_dir)
                for filename in os.listdir(old_dir):
                    shutil.copy(os.path.join(old_dir, filename), os.path.join(new_dir, filename))

                shutil.rmtree(old_dir)

        logging.info('Log file entries migrated')
        logging.info('Migrating tms playback logs (live logs)')
        live_log.create()
        playback.create()
        session.commit()
        logs = session.query(tms_playback_log)
        total = int(logs.count())
        count = 0
        skipped = 0
        fixed = 0
        intermissiony = 0
        inserts = []
        pb_inserts = []

        def reduce_states(changes):
            re = []
            changes = json.loads(changes)
            prev_event = {}
            for change in changes:
                if change['state'] not in ['initialize_device', 'tms_shutdown', prev_event.get('state')]:
                    change['time'] = int(change['time'])
                    re.append(change)
                prev_event = change

            return json.dumps(re)

        ignore_these = ['00000000-0000-0000-0000-000000000000', '00000001-0000-0000-0000-000000000000', '00000002-0000-0000-0000-000000000000']

        def is_bad(log):
            return log.cpl_uuid in ignore_these or 'error' in log.state_changes or None in (log.start_time, log.end_time, log.duration)

        def sanitise_log(log):
            fixed = False
            if log.end_time - log.start_time > log.duration * 1.2:
                log.end_time = log.start_time + log.duration
                fixed = True
            return fixed

        for log in logs:
            count += 1
            if is_bad(log):
                skipped += 1
                continue
            fixed += int(sanitise_log(log))
            device = device_info.get(log.device_uuid, {'screen_identifier': 'N/A',
             'ip': '0.0.0.0'})
            ll_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, str(log.id)))
            int_now = int(time.time())
            ll = {'uuid': ll_uuid,
             'created': int(log.created),
             'last_modified': int_now,
             'cpl_uuid': log.cpl_uuid,
             'start': int(log.start_time),
             'end': int(log.end_time),
             'state_changes': reduce_states(log.state_changes),
             'parsed': True,
             'screen_identifier': device['screen_identifier'],
             'device_ip_address': device['ip'],
             'serial': log.serial or 'n/a',
             'dnqualifier': log.thumbprint or 'n/a'}
            pb = {'uuid': str(uuid.uuid4()),
             'created': int_now,
             'last_modified': int_now,
             'cpl_uuid': log.cpl_uuid,
             'start': int(log.start_time),
             'end': int(log.end_time),
             'screen_identifier': device['screen_identifier'],
             'device_ip_address': device['ip'],
             'serial': log.serial or 'n/a',
             'dnqualifier': log.thumbprint or 'n/a',
             'complex_identifier': cfg.complex_name(),
             'merge_error_code': CODE_START_AND_END_OFF,
             'live_log_uuid': ll_uuid}
            pb.update(analyse_state_changes(ll))
            if pb['duration'] <= 0:
                skipped += 1
                continue
            intermissiony += int(pb['intermission_start'] is not None)
            inserts.append(ll)
            pb_inserts.append(pb)
            console_status(count, total, True)
            if count % 1000 == 0:
                migrate_engine.execute(live_log.insert(), inserts)
                migrate_engine.execute(playback.insert(), pb_inserts)
                inserts = []
                pb_inserts = []

        print
        if inserts:
            migrate_engine.execute(live_log.insert(), inserts)
        if pb_inserts:
            migrate_engine.execute(playback.insert(), pb_inserts)
        logging.info('Tms playback logs migrated to live logs.')
        logging.info('Added: %d', count - skipped)
        logging.info('Skipped: %d', skipped)
        logging.info('Sanitised: %d', fixed)
        logging.info('Intermission found: %d', intermissiony)
        logging.info('SMPTE playouts will be migrated incrementally over the next few days by reparsing raw logs')
        log_file_old.drop()
        tms_playback_log.drop()
        log_file_new.rename('log_file')
        migrate_version.drop()
        session.commit()
        migrate_version.create()
        conn.execute(migrate_version.insert(values=dict(repository_id='screenwriter', repository_path='screenwriter', version=1)))
        session.commit()
        conn.close()
    except Exception as e:
        print e
        import traceback
        traceback.print_exc()
        raise

    return


def downgrade(migrate_engine):
    logging.error('Downgrade not yet implemented!')
# okay decompyling ./storage/database/playback/migration/versions/001_everything.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:38 CST
