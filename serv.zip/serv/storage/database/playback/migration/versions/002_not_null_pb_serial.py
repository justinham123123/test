# 2017.08.13 21:52:38 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\playback\migration\versions\002_not_null_pb_serial.py
"""
Make the Playback schema consistent with those of Logfile and Livelog
"""

def upgrade(migrate_engine):
    conn = migrate_engine.connect()
    conn.execute('ALTER TABLE playback ALTER COLUMN serial DROP NOT NULL;')
    conn.execute('ALTER TABLE playback ALTER COLUMN dnqualifier DROP NOT NULL;')


def downgrade(migrate_engine):
    conn = migrate_engine.connect()
    conn.execute('ALTER TABLE playback ALTER COLUMN serial SET NOT NULL;')
    conn.execute('ALTER TABLE playback ALTER COLUMN dnqualifier SET NOT NULL;')
# okay decompyling ./storage/database/playback/migration/versions/002_not_null_pb_serial.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:38 CST
