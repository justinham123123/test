# 2017.08.13 21:52:35 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\playback\database_sqlite.py
import json
import logging
import os
from sqlalchemy import Date, ForeignKey
from sqlalchemy.orm import scoped_session, sessionmaker, relationship, backref
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Float, Boolean, Integer, Text
from sqlalchemy.schema import Column
from serv.lib.utilities.helper_methods import make_uuid5
from sqlalchemy.types import String
from serv.storage.database.helpers import get_conn_str, get_engine, create_db, IdMixin, UuidMixin, DelMixin, DictMixin, IntModMixin, DictDumpMixin
from serv.configuration import cfg
PATH = cfg.playback_db_name()
REPO = os.path.join(os.path.dirname(__file__), 'migration')
DESCRIPTION = 'Playback Database Sqlite'
Base = declarative_base()
Session = scoped_session(sessionmaker())
engine = None

def close_session(function):
    """
    Decorator that ensures that the db scoped_session is closed after a function (only needed on non-request funcs)
    """

    def wrapped_function(*args, **kwargs):
        global Session
        try:
            return function(*args, **kwargs)
        finally:
            try:
                Session.remove()
            except:
                pass

    wrapped_function.__name__ = function.__name__ + '_db_conn_wrapper'
    return wrapped_function


def _get_db_params(user = None, password = None, name = None, type = None, port = None):
    return {'user': None,
     'password': None,
     'name': cfg.playback_db_name(),
     'type': 'sqlite3',
     'port': None}


def tear_down(**kwargs):
    db_params = _get_db_params(**kwargs)
    try:
        tear_down_engine = get_engine(**db_params)
        TearDownBase = declarative_base()
        TearDownBase.metadata.reflect(tear_down_engine)
        TearDownBase.metadata.drop_all(tear_down_engine)
        tear_down_engine.dispose()
    except OperationalError:
        logging.warning('Error dropping playback database.', exc_info=True)


def set_up(**kwargs):
    global engine
    db_params = _get_db_params(**kwargs)
    engine = get_engine(**db_params)
    Session.configure(bind=engine)
    create_tables(**db_params)


def create_tables(custom_engine = None, **kwargs):
    Base.metadata.create_all(custom_engine or engine)


def get_connection_string(**kwargs):
    return get_conn_str(**_get_db_params(**kwargs))


def get_temp_engine(**kwargs):
    return get_engine(**_get_db_params(**kwargs))


class LogFile(UuidMixin, IntModMixin, DictMixin, Base):
    __tablename__ = 'log_file'
    date = Column(Date, nullable=False)
    device_ip_address = Column(String(50), nullable=False)
    screen_identifier = Column(String(3), nullable=False)
    dnqualifier = Column(String(50))
    serial = Column(String(50))
    unencrypted = Column(Boolean, nullable=False)
    pull_attempted = Column(Boolean, nullable=False, default=False)
    pulled = Column(Boolean, nullable=False, default=False)
    parse_attempted = Column(Boolean, nullable=False, default=False)
    parsed = Column(Boolean, nullable=False, default=False)
    repull_marked = Column(Boolean, nullable=False, default=False)
    absolute_file_path = Column(String(200))
    error_message = Column(String(500))
    no_playouts = Column(Boolean)
    signed = Column(Boolean)
    playouts = relationship('LogFilePlayout', cascade='all,delete-orphan', backref=backref('log_file', uselist=False, single_parent=True, cascade='all,delete-orphan'))

    def generate_uuid(self):
        unencrypted = 'unencrypted' if self.unencrypted else 'encrypted'
        self.uuid = make_uuid5(self.device_ip_address, self.date, unencrypted)


class LogFilePlayout(IdMixin, IntModMixin, DelMixin, DictMixin, Base):
    __tablename__ = 'log_file_playout'
    log_file_uuid = Column(String(36), ForeignKey('log_file.uuid', ondelete='CASCADE'), nullable=False)
    cpl_uuid = Column(String(50), nullable=False)
    start_time = Column(Float)
    end_time = Column(Float)
    playback_uuid = Column(String(36), ForeignKey('playback.uuid', ondelete='SET NULL'))
    merge_confidence_level = Column(Integer)
    playback = relationship('Playback')


class Playback(UuidMixin, IntModMixin, DelMixin, DictMixin, Base):
    __tablename__ = 'playback'
    start = Column(Integer)
    end = Column(Integer)
    duration = Column(Integer)
    intermission_start = Column(Integer)
    intermission_end = Column(Integer)
    screen_identifier = Column(String(3), nullable=False)
    dnqualifier = Column(String(50), nullable=False)
    device_ip_address = Column(String(50), nullable=False)
    serial = Column(String(50), nullable=False)
    complex_identifier = Column(String(50), nullable=False)
    feature_cpl_uuid = Column(String(50))
    content_kind = Column(String(16))
    cpl_uuid = Column(String(50), nullable=False)
    merge_error_code = Column(Integer, nullable=True)
    playout_logs = relationship('LogFilePlayout')
    live_log_uuid = Column(String(50), ForeignKey('live_log.uuid', onupdate='CASCADE', ondelete='SET NULL', deferrable=True))
    live_log = relationship('LiveLog', backref=backref('playback'))
    meta = Column(Text)


class LiveLog(UuidMixin, IntModMixin, DictMixin, Base):
    __tablename__ = 'live_log'
    start = Column(Integer, nullable=False)
    end = Column(Integer)
    cpl_uuid = Column(String(50), nullable=False)
    spl_uuid = Column(String(50))
    state_changes = Column(String(500))
    device_ip_address = Column(String(50), nullable=False)
    screen_identifier = Column(String(3), nullable=False)
    dnqualifier = Column(String(50))
    serial = Column(String(50))
    parsed = Column(Boolean, nullable=False, default=False)
    feature_cpl_uuid = Column(String(50))
    content_kind = Column(String(16))
    meta = Column(Text)
# okay decompyling ./storage/database/playback/database_sqlite.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:36 CST
