# 2017.08.13 21:52:33 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\playback\database.py
import cStringIO
import json
import logging
import os
import psycopg2
from sqlalchemy import Date, ForeignKey
from sqlalchemy import Float, Boolean, Integer, Text
import sqlalchemy
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker, relationship, backref, mapper
from sqlalchemy.schema import Column, MetaData, Index
from sqlalchemy.sql.expression import insert
from sqlalchemy.types import String
from serv.configuration import cfg
from serv.lib.utilities.helper_methods import make_uuid5, Timer, console_status
from serv.storage.database import helpers
from serv.storage.database.helpers import get_conn_str, get_engine, create_db, IdMixin, UuidMixin, DelMixin, DictMixin, IntModMixin
from serv.storage.database.playback import database_sqlite as pldb_sq
PATH = None
REPO = os.path.join(os.path.dirname(__file__), 'migration')
DESCRIPTION = 'Playback Database'
Base = declarative_base()
Session = scoped_session(sessionmaker())
engine = None
init = False

def close_session(function):
    """
    Decorator that ensures that the db scoped_session is closed after a function (only needed on non-request funcs)
    """

    def wrapped_function(*args, **kwargs):
        global Session
        try:
            return function(*args, **kwargs)
        finally:
            try:
                Session.remove()
            except:
                pass

    wrapped_function.__name__ = function.__name__ + '_db_conn_wrapper'
    return wrapped_function


def _get_db_params(user = None, password = None, name = None, type = None, port = None):
    return {'type': type if type is not None else 'postgresql',
     'name': name if name is not None else cfg.db_pg_name(),
     'port': port if port is not None else cfg.db_port(),
     'user': user if user is not None else cfg.db_user(),
     'password': password if password is not None else cfg.db_password()}


def tear_down(**kwargs):
    db_params = _get_db_params(**kwargs)
    try:
        tear_down_engine = get_engine(**db_params)
        TearDownBase = declarative_base()
        TearDownBase.metadata.reflect(tear_down_engine)
        TearDownBase.metadata.drop_all(tear_down_engine)
        tear_down_engine.dispose()
    except OperationalError:
        logging.warning('Error dropping playback database.', exc_info=True)


def set_up(**kwargs):
    global engine
    db_params = _get_db_params(**kwargs)
    engine = get_engine(**db_params)
    Session.configure(bind=engine)
    create_tables(**db_params)


def create_tables(custom_engine = None, **kwargs):
    Base.metadata.create_all(custom_engine or engine)


def get_connection_string(**kwargs):
    return get_conn_str(**_get_db_params(**kwargs))


def get_temp_engine(**kwargs):
    return get_engine(**_get_db_params(**kwargs))


def migrate_sqlite():
    connection = engine.raw_connection()
    cur = connection.cursor()
    helpers.control_version(pldb_sq, 'sqlite3')
    pldb_sq.engine = pldb_sq.get_temp_engine()
    pldb_conn = pldb_sq.engine.connect()
    tbls_to_convert = [pldb_sq.LogFile,
     pldb_sq.LiveLog,
     pldb_sq.Playback,
     pldb_sq.LogFilePlayout]
    total_timer = Timer()
    for tbl in tbls_to_convert:
        bools = []
        ints = []
        cols = []
        for col in tbl.__table__.c:
            c = str(col).split('.')[1]
            cols.append(c)
            t = str(col.type)
            if t == 'BOOLEAN':
                bools.append(c)
            elif t == 'INTEGER':
                ints.append(c)

        rowcount = pldb_conn.execute('SELECT count(*) FROM %s' % tbl.__tablename__).fetchone()[0]
        print 'Migrating %s: %s rows' % (tbl.__tablename__, rowcount)
        chunk_size = 200000
        num = 0
        console_status(0, rowcount)
        while True:
            fetch = 'SELECT * FROM %s LIMIT %s OFFSET %s' % (tbl.__tablename__, chunk_size, num)
            rows = pldb_conn.execute(fetch).fetchall()
            if len(rows) == 0:
                break
            input = cStringIO.StringIO()
            for row in rows:
                vals = []
                for item in row.items():
                    val = item[1]
                    if val is None:
                        val = '\\N'
                    elif item[0] in bools:
                        val = 'true' if val == 1 else 'false'
                    elif item[0] in ints:
                        val = int(item[1])
                    else:
                        try:
                            val = val.replace('\\', '\\\\')
                        except:
                            pass

                    if hasattr(val, 'encode'):
                        val = val.encode('utf-8')
                    else:
                        val = str(val)
                    vals.append(val)

                vals = '\t'.join(vals) + '\n'
                input.write(vals)

            cols = '(%s)' % ', '.join(cols)
            input.seek(0)
            copy_sts = 'COPY %s FROM STDOUT' % tbl.__tablename__
            cur.copy_expert(copy_sts, input)
            cur.execute('COMMIT;')
            connection.commit()
            input.close()
            num += len(rows)
            console_status(num, rowcount)

    total_timer.lap('Total time')
    total_timer.stop()
    pldb_conn.close()
    pldb_sq.engine.dispose()
    cur.execute('SELECT MAX(id) FROM log_file_playout')
    max_id = cur.fetchone()[0]
    if max_id:
        cur.execute("SELECT setval('log_file_playout_id_seq', %s);" % max_id)
        seq_fix = cur.fetchone()
        logging.info('Reset log_file_playout sequence id to %s', seq_fix)
    print 'Migration complete'
    logging.info('Migration complete')
    return


def hack_in_support_for_ancient_postgres():
    version = engine.execute('SELECT version()').scalar()
    logging.info('Running %s', version)
    res = engine.execute("SELECT COUNT(*) FROM pg_proc WHERE proisagg AND proname='array_agg';")
    exists = res.scalar()
    if not exists:
        logging.warn('Detected very old postgres version. Consider upgrading. Please.')
        engine.execute("\n            CREATE AGGREGATE array_agg ( basetype = anyelement, sfunc = array_append, stype = anyarray, initcond = '{}' );\n        ")
        logging.info('Created missing array_agg function on legacy postgres version.')
    else:
        logging.info('Running acceptable version of postgres. No hack required.')


class LogFile(UuidMixin, IntModMixin, DictMixin, Base):
    __tablename__ = 'log_file'
    date = Column(Date, nullable=False)
    device_ip_address = Column(String(50), nullable=False)
    screen_identifier = Column(String(3), nullable=False)
    dnqualifier = Column(String(50))
    serial = Column(String(50))
    unencrypted = Column(Boolean, nullable=False)
    pull_attempted = Column(Boolean, nullable=False, default=False)
    pulled = Column(Boolean, nullable=False, default=False)
    parse_attempted = Column(Boolean, nullable=False, default=False)
    parsed = Column(Boolean, nullable=False, default=False)
    repull_marked = Column(Boolean, nullable=False, default=False)
    absolute_file_path = Column(String(200))
    error_message = Column(Text)
    no_playouts = Column(Boolean)
    signed = Column(Boolean)
    playouts = relationship('LogFilePlayout', cascade='all,delete-orphan', backref=backref('log_file', uselist=False, single_parent=True, cascade='all,delete-orphan'))

    def generate_uuid(self):
        unencrypted = 'unencrypted' if self.unencrypted else 'encrypted'
        self.uuid = make_uuid5(self.device_ip_address, self.date, unencrypted)


class LogFilePlayout(IdMixin, IntModMixin, DelMixin, Base):
    __tablename__ = 'log_file_playout'
    log_file_uuid = Column(String(36), ForeignKey('log_file.uuid', ondelete='CASCADE'), nullable=False)
    cpl_uuid = Column(String(50), nullable=False)
    start_time = Column(Float)
    end_time = Column(Float)
    playback_uuid = Column(String(36), ForeignKey('playback.uuid', ondelete='SET NULL'))
    merge_confidence_level = Column(Integer)
    playback = relationship('Playback')


class Playback(UuidMixin, IntModMixin, DelMixin, DictMixin, Base):
    __tablename__ = 'playback'
    start = Column(Integer)
    end = Column(Integer)
    duration = Column(Integer)
    intermission_start = Column(Integer)
    intermission_end = Column(Integer)
    screen_identifier = Column(String(3), nullable=False)
    dnqualifier = Column(String(50))
    device_ip_address = Column(String(50), nullable=False)
    serial = Column(String(50))
    complex_identifier = Column(String(50), nullable=False)
    feature_cpl_uuid = Column(String(50))
    content_kind = Column(String(16))
    cpl_uuid = Column(String(50), nullable=False)
    merge_error_code = Column(Integer, nullable=True)
    playout_logs = relationship('LogFilePlayout')
    live_log_uuid = Column(String(50), ForeignKey('live_log.uuid', onupdate='CASCADE', ondelete='SET NULL', deferrable=True))
    live_log = relationship('LiveLog', backref=backref('playback'))
    meta = Column(Text)
    __table_args__ = (Index('ix_playback_datatable', 'screen_identifier', 'start'), Index('ix_playback_last_played', 'cpl_uuid', 'start'))

    def to_dict(self):
        log = {}
        json_attributes = ['meta']
        for column in self.__table__.columns:
            if column.name in json_attributes and getattr(self, column.name):
                log[column.name] = json.loads(getattr(self, column.name))
            else:
                log[column.name] = getattr(self, column.name)

        return log


class LiveLog(UuidMixin, IntModMixin, Base):
    __tablename__ = 'live_log'
    start = Column(Integer, nullable=False)
    end = Column(Integer)
    cpl_uuid = Column(String(50), nullable=False)
    spl_uuid = Column(String(50))
    state_changes = Column(Text)
    device_ip_address = Column(String(50), nullable=False)
    screen_identifier = Column(String(3), nullable=False)
    dnqualifier = Column(String(50))
    serial = Column(String(50))
    parsed = Column(Boolean, nullable=False, default=False)
    feature_cpl_uuid = Column(String(50))
    content_kind = Column(String(16))
    meta = Column(Text)

    def to_dict(self):
        log = {}
        json_attributes = ['meta', 'state_changes']
        for column in self.__table__.columns:
            if column.name in json_attributes and getattr(self, column.name):
                log[column.name] = json.loads(getattr(self, column.name))
            else:
                log[column.name] = getattr(self, column.name)

        return log


global init ## Warning: Unused global
# okay decompyling ./storage/database/playback/database.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:35 CST
