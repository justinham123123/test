# 2017.08.13 21:52:30 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\audit\database.py
import datetime
import logging
import os
from sqlalchemy import ForeignKey, Text
from sqlalchemy.ext.associationproxy import association_proxy
from sqlalchemy.orm import scoped_session, sessionmaker, relationship
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.schema import Column
from sqlalchemy.types import String
import cherrypy
from serv.storage.database.helpers import get_conn_str, get_engine, UuidMixin, ModMixin
from serv.configuration import cfg
PATH = None
REPO = os.path.join(os.path.dirname(__file__), 'migration')
DESCRIPTION = 'Audit Log Database'
Base = declarative_base()
Session = scoped_session(sessionmaker())
engine = None

def close_session(function):
    """
    Decorator that ensures that the db scoped_session is closed after a function (only needed on non-request funcs)
    """

    def wrapped_function(*args, **kwargs):
        global Session
        try:
            return function(*args, **kwargs)
        finally:
            try:
                Session.remove()
            except:
                pass

    wrapped_function.__name__ = function.__name__ + '_db_conn_wrapper'
    return wrapped_function


def _get_db_params(user = None, password = None, name = None, type = None, port = None):
    return {'user': user if user is not None else cfg.db_user(),
     'password': password if password is not None else cfg.db_password(),
     'name': name if name is not None else cfg.audit_db_name(),
     'type': type if type is not None else cfg.db_engine(),
     'port': port if port is not None else cfg.db_port()}


def tear_down(**kwargs):
    db_params = _get_db_params(**kwargs)
    try:
        tear_down_engine = get_engine(**db_params)
        TearDownBase = declarative_base()
        TearDownBase.metadata.reflect(tear_down_engine)
        TearDownBase.metadata.drop_all(tear_down_engine)
        tear_down_engine.dispose()
    except OperationalError:
        logging.warning('Error dropping audit database.', exc_info=True)


def set_up(**kwargs):
    global engine
    db_params = _get_db_params(**kwargs)
    engine = get_engine(**db_params)
    Session.configure(bind=engine)
    create_tables(**db_params)


def create_tables(custom_engine = None, **kwargs):
    Base.metadata.create_all(custom_engine or engine)


def get_connection_string(**kwargs):
    return get_conn_str(**_get_db_params(**kwargs))


def get_temp_engine(**kwargs):
    return get_engine(**_get_db_params(**kwargs))


def sub_meta(msg, meta):
    meta_json = {}
    import re
    for found in re.findall('\\{.*?\\}', msg):
        tag, type = found[1:-1].split(':')
        if tag in meta:
            obj = meta[tag]
            m = {'type': type}
            if type == 'device_uuid':
                m['uuid'] = obj
                m['display'] = cherrypy.core.get_pretty_name(obj)
            elif type == 'screen':
                m['uuid'] = obj['uuid']
                m['display'] = obj['identifier']
            elif type == 'schedule':
                m['uuid'] = obj.get('uuid', '')
                m['display'] = obj.get('display_name', 'Unknown')
                m['other'] = obj
            elif type == 'timestamp':
                m['uuid'] = ''
                m['display'] = datetime.datetime.fromtimestamp(obj).strftime('%H:%M:%S %Y-%m-%d')
            elif type == 'playlist':
                m['uuid'] = obj.get('id', '')
                m['display'] = obj.get('title', 'Unknown')
            elif type == 'cpl_uuid':
                content = cherrypy.core.contents.get(obj, {})
                m['uuid'] = obj
                m['display'] = content.get('content_title_text', None)
                m['other'] = {'content_kind': content.get('content_kind', 'unknown')}
            elif type == 'macro_pack':
                m['uuid'] = obj['uuid']
                m['display'] = obj['placeholder_name']
            elif type in ('macro_placeholder', 'pack', 'template', 'title'):
                m['uuid'] = obj.get('uuid', '')
                m['display'] = obj.get('name', 'Unknown')
            meta_json[tag] = m
            msg = msg.replace(found, '{' + tag + '}')

    return (msg, meta_json)


class Log(Base, UuidMixin, ModMixin):
    __tablename__ = 'log'
    ip = Column(String(255), nullable=True, default='')
    user = Column(String(255), nullable=True, default='')
    message = Column(String(255), nullable=False)
    meta = Column(Text, nullable=True, default='')
    _tags = relationship('Tag', secondary='tag_map', backref='log', collection_class=set, cascade='all')
    tags = association_proxy('_tags', 'name', creator=lambda name: Tag(name=name))


class TagMap(Base, UuidMixin):
    __tablename__ = 'tag_map'
    log = Column(String(36), ForeignKey('log.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), primary_key=True, index=True, nullable=False)
    tag = Column(String(36), ForeignKey('tag.name', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), primary_key=True, index=True, nullable=False)


class Tag(Base):
    __tablename__ = 'tag'
    name = Column(String(255), primary_key=True, nullable=False, index=True)

    def __init__(self, name):
        self.name = name
# okay decompyling ./storage/database/audit/database.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:31 CST
