# 2017.08.13 21:52:31 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\audit\migration\manage.py
from migrate.versioning.shell import main
from serv.configuration import cfg
if __name__ == '__main__':
    main(url='sqlite:///%s' % cfg.audit_db_name(), debug='False', repository='.')
# okay decompyling ./storage/database/audit/migration/manage.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:31 CST
