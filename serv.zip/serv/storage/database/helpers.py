# 2017.08.13 21:52:32 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\helpers.py
import logging
import os
from uuid import uuid4
import time
import shutil
import traceback
import datetime
from sqlalchemy.sql import expression
from serv.configuration import cfg
from serv.configuration.constants import DB_BACKUP_COUNT
from sqlalchemy import Float, Boolean, Integer, func
from sqlalchemy.orm import object_session
from sqlalchemy.orm.util import has_identity
from sqlalchemy.exc import OperationalError
from sqlalchemy.schema import Column
from sqlalchemy.types import String
import migrate.versioning.api as sa_migrate
from sqlalchemy.event import listen
import sqlalchemy
import cherrypy
POOL_SIZE = 20
OVERFLOW = 40

def get_conn_str(user, password, name, type, port):
    if type == 'postgresql':
        return '%s://%s:%s@127.0.0.1:%s/%s' % (type,
         user,
         password,
         port,
         name)
    if type == 'mysql':
        return '%s://%s:%s@127.0.0.1/%s' % (type,
         user,
         password,
         name)
    if type == 'sqlite3':
        return 'sqlite:///%s?timeout=30000' % name
    if type == 'sqlite3_memory':
        return 'sqlite:///:memory:'
    raise Exception('Database type not supported: %s' % str(type))


def push_executing_stmt(conn, cursor, statement, params, context, executemany):
    context._query_start_time = time.time()


def pop_executing_stmt(conn, cursor, statement, params, context, executemany):
    cherrypy.engine.publish('log_query', {'statement': statement,
     'traceback': traceback.extract_stack(),
     'time_taken': time.time() - context._query_start_time})


def create_db(user, password, name, type, port):
    tmp_create_engine = get_engine(user, password, '', type, port)
    if type == 'postgresql':
        conn = tmp_create_engine.connect()
        conn.execute('commit')
        conn.execute(expression.text("CREATE DATABASE %s WITH OWNER = %s ENCODING 'UTF8'" % (name, user)))
        conn.close()
    elif type == 'mysql':
        tmp_create_engine.execute(expression.text('CREATE DATABASE %s CHARACTER SET utf8 COLLATE utf8_bin' % name))
    elif type == 'sqlite3' or type == 'sqlite3_memory':
        pass
    else:
        raise Exception('Database type not supported: %s' % str(type))
    tmp_create_engine.dispose()
    del tmp_create_engine


def control_version(database, dbms):
    temp_engine = database.get_temp_engine()
    pg_tbl_exists = True
    if dbms == 'postgresql':
        try:
            temp_engine.connect()
        except OperationalError:
            create_db(**database._get_db_params())
            pg_tbl_exists = False

    connection_string = database.get_connection_string()
    if dbms == 'sqlite3' and os.path.exists(database.PATH) or dbms == 'postgresql' and pg_tbl_exists:
        try:
            if not temp_engine.dialect.has_table(temp_engine.connect(), 'migrate_version'):
                logging.info('Setting up %s with initial version [%s]' % (database.DESCRIPTION, '0'))
                sa_migrate.version_control(connection_string, database.REPO, 0)
            migrate(connection_string, database.REPO, database.DESCRIPTION, database.PATH)
        except Exception:
            logging.critical('Problem versioning %s', database.DESCRIPTION, exc_info=True)
            raise

        database.set_up()
    else:
        database.set_up()
        latest_version = sa_migrate.version(database.REPO)
        logging.info('Setting up %s with latest version [%s]' % (database.DESCRIPTION, latest_version))
        sa_migrate.version_control(connection_string, database.REPO, latest_version)
    if dbms == 'postgresql':
        version = database.engine.execute('SELECT version()').scalar()
        logging.info('Running %s', version)
    if not pg_tbl_exists:
        if os.path.exists(cfg.playback_db_name()):
            try:
                database.migrate_sqlite()
            except Exception:
                logging.critical('Problem migrating sqlite to postgres', exc_info=True)
                raise

        try:
            database.hack_in_support_for_ancient_postgres()
        except Exception:
            logging.critical('Failed to hack in support for ancient (pre-8.4) postgres', exc_info=True)

    temp_engine.dispose()


def migrate(connection_string, repo_path, database_description, database_path):
    target_version = sa_migrate.version(repo_path)
    current_version = sa_migrate.db_version(connection_string, repo_path)
    is_sqlite = 'sqlite' in connection_string
    is_pldb = 'Playback' in database_description
    if is_sqlite and is_pldb:
        target_version = 1
    if target_version > 0 and current_version < target_version:
        logging.info('Migrating %s to latest version [%s]' % (database_description, str(target_version)))
        if is_sqlite:
            back_up(current_version, database_description, database_path)
        sa_migrate.upgrade(connection_string, repo_path, version=target_version)


def get_engine(user, password, name, type, port):
    conn_str = get_conn_str(user, password, name, type, port)
    logging.info('Creating db engine with conn [%s]', conn_str)
    if type == 'postgresql':
        return sqlalchemy.create_engine(conn_str, echo=False, pool_size=POOL_SIZE, max_overflow=OVERFLOW, client_encoding='utf8')
    if type == 'mysql':
        return sqlalchemy.create_engine(conn_str, echo=False, pool_size=POOL_SIZE, max_overflow=OVERFLOW)
    if type == 'sqlite3':
        db_dir = os.path.dirname(name)
        if not os.path.exists(db_dir):
            os.makedirs(db_dir)
        engine = sqlalchemy.create_engine(conn_str, echo=False, connect_args={'check_same_thread': False})

        def enforce_fkeys(dbapi_con, con_record):
            dbapi_con.execute('PRAGMA foreign_keys=ON')
            dbapi_con.execute('PRAGMA cache_size = 60000')
            dbapi_con.execute('PRAGMA journal_mode = TRUNCATE')
            dbapi_con.execute('PRAGMA page_size = 32768')
            dbapi_con.execute('PRAGMA temp_store = 2')
            dbapi_con.execute('PRAGMA count_changes = OFF')

        listen(engine, 'connect', enforce_fkeys)
        if cfg.core_monitor_dbs.get():
            listen(engine, 'before_cursor_execute', push_executing_stmt)
            listen(engine, 'after_cursor_execute', pop_executing_stmt)
        return engine
    if type == 'sqlite3_memory':
        engine = sqlalchemy.create_engine(conn_str, echo=False, connect_args={'check_same_thread': False,
         'timeout': 20})

        def enforce_fkeys(dbapi_con, con_record):
            dbapi_con.execute('PRAGMA foreign_keys=ON')

        listen(engine, 'connect', enforce_fkeys)
        return engine
    raise Exception('Database type not supported: %s' % str(type))


def back_up(current_version, database_description, database_path):
    logging.info('Backing up %s before migration' % database_description)
    db_dir = os.path.dirname(cfg.db_name())
    db_name = database_path.split(os.path.sep)[-1]

    def __comparator(a, b):
        return a['index'] - b['index']

    filtered_filenames = []
    for filename in os.listdir(db_dir):
        if db_name in filename and 'journal' not in filename:
            fname = os.path.join(db_dir, filename)
            try:
                filtered_filenames.append({'filename': fname,
                 'index': int(fname.split('.')[-1]) if len(fname.split('.')) > 2 else 0})
            except ValueError:
                logging.warn('Skipping unexpected file %s', fname)

    filtered_filenames.sort(__comparator, reverse=True)
    for file in filtered_filenames:
        filename = file['filename']
        index = file['index']
        if index == 0:
            if current_version:
                final_file = database_path + '_v' + str(current_version) + '.1'
            else:
                final_file = database_path + '.1'
            shutil.copyfile(database_path, final_file)
        elif 0 < index < DB_BACKUP_COUNT:
            os.rename(filename, filename.strip('.' + str(index)) + '.' + str(index + 1))
        else:
            os.remove(filename)


def timestamp_default():
    return time.time()


def int_timestamp_default():
    return int(time.time())


def datetime_default():
    return datetime.datetime.now()


class IdMixin(object):
    """
    Adds a id (Integer) column to a table as a primary key
    """
    id = Column(Integer, nullable=False, primary_key=True)


class UuidMixin(object):
    """
    Adds a uuid (string) column to a table as a primary key
    """
    uuid = Column(String(36), nullable=False, primary_key=True, default=lambda : str(uuid4()), index=True)


class ModMixin(object):
    """
    Adds a 'created' and 'last_modified' column to a table
    """
    created = Column(Float, nullable=False, default=timestamp_default)
    last_modified = Column(Float, nullable=False, default=timestamp_default)

    def _state(self):
        in_session = object_session(self) is not None
        got_identity = has_identity(self)
        if in_session:
            if got_identity:
                return 'persistent'
            else:
                return 'pending'
        else:
            if got_identity:
                return 'detached'
            return 'transient'
        return

    def timestamp_default(self):
        return time.time()

    def set_modified(self, timestamp = None, force_override = False):
        """
        Function used to safely update the last_modified timestamp.
        If the existing value is already later then it will be left as that.
        
        # Force override causes last_modified to be set regardless of object state.
        # With force_override=False, for new titles last_modified wouldn't be set
        # to the last_modified value from circuit core
        """
        if timestamp == None:
            timestamp = self.timestamp_default()
        if force_override:
            self.last_modified = timestamp
        elif self._state() in ('persistent', 'detached'):
            self.last_modified = timestamp if timestamp > self.last_modified else self.last_modified
        else:
            self.last_modified = timestamp
        return


class IntModMixin(ModMixin):
    """
    Adds a 'created' and 'last_modified' column to a table
    """
    created = Column(Integer, nullable=False, default=int_timestamp_default)
    last_modified = Column(Integer, nullable=False, default=int_timestamp_default)

    def timestamp_default(self):
        return int(time.time())


class DelMixin(ModMixin):
    """
    Adds a 'deleted', 'created' and 'last_modified' column to a table
    """
    deleted = Column(Boolean, nullable=False, default=False)

    def mark_deleted(self, timestamp = None):
        if timestamp is None:
            timestamp = func.strftime('%s', 'now')
        self.last_modified = timestamp
        self.deleted = True
        return


class DictMixin(object):

    def from_dict(self, d):
        """
        Updates the object using the dictionary provided.
        """
        for column in self.__table__.columns:
            if column.name in d:
                setattr(self, column.name, d[column.name])

    def to_dict(self):
        """
        Returns a plain python dictionary from the model
        with column names as keys.
        """
        d = {}
        for column in self.__table__.columns:
            d[column.name] = getattr(self, column.name)

        return d


class DictDumpMixin(object):

    def to_dump_dict(self):
        """
        Returns a plain python dictionary from the model
        with column names as keys.
        """
        d = {}
        for column in self.__table__.columns:
            d[column.name] = getattr(self, column.name)

        return d
# okay decompyling ./storage/database/helpers.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:33 CST
