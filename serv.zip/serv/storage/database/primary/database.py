# 2017.08.13 21:52:39 CST
# Embedded file name: build\bdist.win32\egg\serv\storage\database\primary\database.py
import json
import datetime
import logging
import os
import time
from sqlalchemy import ForeignKeyConstraint, Unicode, Date, Time, DateTime, LargeBinary, ForeignKey, Text
from sqlalchemy.ext.associationproxy import association_proxy
from sqlalchemy.orm import scoped_session, sessionmaker, relationship, backref
from sqlalchemy.schema import UniqueConstraint
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Float, Boolean, Integer, func
from sqlalchemy.schema import Column
from sqlalchemy.types import String
from serv.storage.database.helpers import get_conn_str, get_engine, create_db, IdMixin, UuidMixin, ModMixin, DelMixin, DictMixin, datetime_default
from serv.lib.utilities import helper_methods
from serv.configuration import cfg
PATH = None
REPO = os.path.join(os.path.dirname(__file__), 'migration')
DESCRIPTION = 'Primary Database'
Base = declarative_base()
Session = scoped_session(sessionmaker())
engine = None
logging.getLogger('sqlalchemy.orm.mapper.Mapper').setLevel(logging.WARNING)

def close_session(function):
    """
    Decorator that ensures that the db scoped_session is closed after a function (only needed on non-request funcs)
    """

    def wrapped_function(*args, **kwargs):
        global Session
        try:
            return function(*args, **kwargs)
        finally:
            try:
                Session.remove()
            except:
                pass

    wrapped_function.__name__ = function.__name__ + '_db_conn_wrapper'
    return wrapped_function


def _get_db_params(user = None, password = None, name = None, type = None, port = None):
    return {'user': user if user is not None else cfg.db_user(),
     'password': password if password is not None else cfg.db_password(),
     'name': name if name is not None else cfg.db_name(),
     'type': type if type is not None else cfg.db_engine(),
     'port': port if port is not None else cfg.db_port()}


def tear_down(**kwargs):
    db_params = _get_db_params(**kwargs)
    try:
        tear_down_engine = get_engine(**db_params)
        TearDownBase = declarative_base()
        TearDownBase.metadata.reflect(tear_down_engine)
        TearDownBase.metadata.drop_all(tear_down_engine)
        tear_down_engine.dispose()
    except OperationalError:
        logging.warning('Error dropping primary database.', exc_info=True)


def set_up(**kwargs):
    global engine
    db_params = _get_db_params(**kwargs)
    engine = get_engine(**db_params)
    Session.configure(bind=engine)
    create_tables(**db_params)


def create_tables(custom_engine = None, **kwargs):
    try:
        Base.metadata.create_all(custom_engine or engine)
    except OperationalError:
        create_db(**kwargs)
        Base.metadata.create_all(custom_engine or engine)


def get_connection_string(**kwargs):
    return get_conn_str(**_get_db_params(**kwargs))


def get_temp_engine(**kwargs):
    return get_engine(**_get_db_params(**kwargs))


class CameraImage(IdMixin, Base):
    __tablename__ = 'camera_image'
    camera_id = Column(String, nullable=False, index=True)
    timestamp = Column(Float, nullable=False, index=True, default=func.strftime('%s', 'now'))
    image = Column(LargeBinary, nullable=False)
    sequence_number = Column(Integer, nullable=False)


class Title(UuidMixin, ModMixin, Base):
    """ Represents a feature film
            - used by Packs & POS
            - Titles contain a number of CPLs
            - the different 'versions' of the movie (E.g. 3d version, 2d version perhaps)
    """
    __tablename__ = 'title'
    name = Column(String(255), nullable=False, default='')
    year = Column(String(4), nullable=False, default=lambda : str(datetime.datetime.now().year))
    credits_offset = Column(Integer, nullable=True)
    ratings = relationship('TitleRatingMap', back_populates='title', cascade='all,delete')
    external_ids = relationship('ExternalTitleMap', back_populates='title')
    title_cpl_maps = relationship('TitleCplMap', cascade='all, delete, delete-orphan')


class TitleRatingMap(Base):
    """Maps Ratings to a Title
    """
    __tablename__ = 'title_rating_map'
    rating = Column(String(36), nullable=False)
    territory = Column(String(36), nullable=False, primary_key=True, index=True)
    title_uuid = Column(String(36), ForeignKey('title.uuid', onupdate='CASCADE', ondelete='RESTRICT', deferrable=True), primary_key=True, index=True)
    title = relationship('Title', back_populates='ratings')


class ExternalTitleMap(UuidMixin, Base):
    """Maps a identifier used by a third party vendor to a Title
    """
    __tablename__ = 'external_title_map'
    __table_args__ = (UniqueConstraint('source', 'external_id'),)
    source = Column(String(50), nullable=False)
    external_id = Column(String(200), nullable=False, index=True)
    title_uuid = Column(String(36), ForeignKey('title.uuid', onupdate='CASCADE', deferrable=True), nullable=True, index=True)
    name = Column(String(255), nullable=True)
    producer_last_modified = Column(Float, nullable=True)
    title = relationship('Title', back_populates='external_ids', lazy='joined')


class TitleCplMap(Base):
    """Maps CPLs to a Title
    """
    __tablename__ = 'title_cpl_map'
    cpl_uuid = Column(String(36), nullable=False, primary_key=True, index=True)
    title_uuid = Column(String(36), ForeignKey('title.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), primary_key=True, index=True)
    title = relationship('Title')


class Placeholder(UuidMixin, ModMixin, Base):
    __tablename__ = 'placeholder'
    name = Column(String(255))


class MacroPlaceholder(UuidMixin, Base):
    __tablename__ = 'macro_placeholder'
    name = Column(String(255), nullable=False)
    transition = Column(Boolean, default=False, nullable=False)
    has_content = Column(Boolean, default=True, nullable=False)
    can_delete = Column(Boolean, default=True, nullable=False)
    macro_packs = relationship('MacroPack')


class MacroPack(UuidMixin, ModMixin, Base):
    __tablename__ = 'macro_pack'
    event_list = Column(String(1500), nullable=False)
    device_uuid = Column(String(36), ForeignKey('device.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True))
    device = relationship('Device')
    macro_placeholder_uuid = Column(String(36), ForeignKey('macro_placeholder.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True))
    deleted = Column(Boolean, nullable=False, default=False)
    producer_last_modified = Column(Float, nullable=True)
    macro_placeholder = relationship('MacroPlaceholder')

    def __repr__(self):
        return 'Macro Pack,' + unicode(self.uuid) + ',' + unicode(self.macro_placeholder.name) + ',' + unicode(self.device.uuid)


class PackRatingMap(Base):
    """Maps Ratings to a Title
    """
    __tablename__ = 'pack_rating_map'
    rating = Column(String(36), nullable=False)
    region = Column(String(36), nullable=False, primary_key=True)
    pack_uuid = Column(String(36), ForeignKey('pack.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), primary_key=True)
    pack = relationship('Pack', back_populates='ratings')


class Pack(UuidMixin, ModMixin, Base):
    """
    Packs (e.g. Advertising Pack)
    """
    __tablename__ = 'pack'
    name = Column(String(255), nullable=False)
    issuer = Column(String(100), default='TMS', nullable=False)
    issue_date = Column(DateTime, nullable=False, default=datetime_default())
    version = Column(Integer)
    title_external_ids = Column(Text, nullable=True)
    print_no = Column(Integer)
    priority = Column(Integer, default=1000)
    screen_maps = relationship('PackScreenMap', cascade='delete')
    ratings = relationship('PackRatingMap', back_populates='pack', cascade='all,delete')
    screen_external_ids = Column(Text)
    placeholder_uuid = Column(String(36), ForeignKey('placeholder.uuid', onupdate='CASCADE', ondelete='RESTRICT', deferrable=True), index=True)
    placeholder = relationship('Placeholder')
    playback_date_range_start = Column(Date, nullable=True)
    playback_date_range_end = Column(Date, nullable=True)
    playback_time_range_start = Column(Time, nullable=True)
    playback_time_range_end = Column(Time, nullable=True)
    clips = Column(Text, nullable=False)
    duration = Column(Integer, nullable=True)
    external_title_map_uuid = Column(String(36), ForeignKey('external_title_map.uuid'), nullable=True)
    pack_attribute_maps = relationship('PackAttributeMap', passive_deletes=True, cascade='all, delete, delete-orphan')
    external_show_attribute_maps = association_proxy('pack_attribute_maps', 'external_show_attribute_maps')
    external_title_map = relationship('ExternalTitleMap')

    def __repr__(self):
        return 'Pack,' + unicode(self.uuid) + ',' + unicode(self.external_title_map.title if self.external_title_map and self.external_title_map.title else None)

    def show_attributes(self):
        """
        Returns a list of 'matched' show attributes for this pack.
        Note: unmatched external show attribute maps are ignored
        e.g.
            [ '3D', 'GOLD CLASS']
        """
        ret = []
        for ex_sam in self.external_show_attribute_maps:
            if ex_sam and ex_sam.show_attribute_uuid and ex_sam.show_attribute:
                ret.append(ex_sam.show_attribute.name)

        return ret

    def to_dict(self):
        """Returns a dictionary representing the pack
        """
        ex_sams = []
        if self.external_show_attribute_maps:
            for ex_sam in self.external_show_attribute_maps:
                if ex_sam:
                    ex_sams.append({'source': ex_sam.source,
                     'external_id': ex_sam.external_id,
                     'show_attribute_uuid': ex_sam.show_attribute_uuid})

        return {'uuid': self.uuid,
         'name': self.name,
         'title_uuid': self.external_title_map.title_uuid if self.external_title_map and self.external_title_map.title_uuid else None,
         'title_name': self.external_title_map.title.name if self.external_title_map and self.external_title_map.title else None,
         'priority': self.priority,
         'print_no': self.print_no,
         'date_from': self.playback_date_range_start.strftime('%Y-%m-%d') if self.playback_date_range_start else None,
         'date_to': self.playback_date_range_end.strftime('%Y-%m-%d') if self.playback_date_range_end else None,
         'time_from': self.playback_time_range_start.strftime('%H:%M:%S') if self.playback_time_range_start else None,
         'time_to': self.playback_time_range_end.strftime('%H:%M:%S') if self.playback_time_range_end else None,
         'external_show_attribute_maps': ex_sams,
         'placeholder_uuid': self.placeholder_uuid,
         'placeholder_name': self.placeholder.name if self.placeholder else None,
         'screens': [ screen_map.screen_uuid for screen_map in self.screen_maps ],
         'screen_external_ids': json.loads(self.screen_external_ids) if self.screen_external_ids else [],
         'ratings': [ {'rating': r.rating,
                     'territory': r.region} for r in self.ratings ],
         'clips': json.loads(self.clips),
         'issuer': self.issuer}

    def to_datatables_dict(self):
        """Returns a dictionary representing the pack - in a format suitable for datatables
        """
        return {'uuid': self.uuid,
         'name': self.name,
         'ext_title_name': json.loads(self.title_external_ids)[0]['name'] if self.title_external_ids else None,
         'title_name': self.external_title_map.title.name if self.external_title_map and self.external_title_map.title else None,
         'date_from': self.playback_date_range_start.strftime('%Y-%m-%d') if self.playback_date_range_start else None,
         'date_to': self.playback_date_range_end.strftime('%Y-%m-%d') if self.playback_date_range_end else None,
         'time_from': self.playback_time_range_start.strftime('%H:%M') if self.playback_time_range_start else None,
         'time_to': self.playback_time_range_end.strftime('%H:%M') if self.playback_time_range_end else None,
         'show_attributes': self.show_attributes(),
         'placeholder_uuid': self.placeholder_uuid,
         'placeholder_name': self.placeholder.name if self.placeholder_uuid else None,
         'screens': [ screen_map.screen_uuid for screen_map in self.screen_maps ],
         'last_modified': self.last_modified}


class PackScreenMap(Base):
    """
    Maps Packs to screens
    """
    __tablename__ = 'pack_screen_map'
    pack_uuid = Column(String(36), ForeignKey('pack.uuid', ondelete='CASCADE', deferrable=True), primary_key=True)
    screen_uuid = Column(String(36), ForeignKey('screen.uuid', deferrable=True), primary_key=True)


class Schedule(UuidMixin, DelMixin, Base):
    """
    Schedule model contains data about various different types of schedules including:
    POS items for pack matching, placeholders and normal schedules from screen servers
    """
    __tablename__ = 'schedule'
    __table_args__ = (UniqueConstraint('device_schedule_id', 'device_uuid', 'start_timestamp'),)
    screen_uuid = Column(String(36), ForeignKey('screen.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), nullable=True)
    display_name = Column(String(255), nullable=True)
    start_timestamp = Column(Float, nullable=False)
    end_timestamp = Column(Float, nullable=False)
    type = Column(String(50), nullable=False)
    error = Column(Boolean, nullable=False, default=False)
    pos_id = Column(String(36), ForeignKey('pos.uuid', deferrable=True, onupdate='CASCADE', ondelete='CASCADE'), nullable=True, index=True)
    pos_duration = Column(Float, nullable=True)
    pos = relationship('POSItem')
    device_uuid = Column(String(36), ForeignKey('device.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), nullable=True)
    device = relationship('Device')
    device_schedule_id = Column(String(36), nullable=True)
    device_playlist_uuid = Column(String(36), nullable=True)
    device_playlist_duration = Column(Float, nullable=True)
    source_playlist_uuid = Column(String(36), nullable=True)
    is_template = Column(Boolean, default=False)
    templating_issues = Column(Text, nullable=True)
    print_no = Column(Integer)
    show_attribute_maps = relationship('ScheduleShowAttributeMap')
    placeholder_type = Column(String(50), nullable=True)
    placeholder_duration = Column(Float, nullable=True)
    published_show_time = Column(Float, nullable=True)

    def to_dict(self):
        d = {}
        for column in self.__table__.columns:
            if column.name == 'templating_issues' and getattr(self, 'templating_issues'):
                d['templating_issues'] = json.loads(getattr(self, 'templating_issues'))
            else:
                d[column.name] = getattr(self, column.name)

        return d


class QuickCue(UuidMixin, Base):
    __tablename__ = 'quick_cue'
    index = Column(Integer(), nullable=True)
    icon = Column(String(36), nullable=False)
    automations = relationship('QuickCueMap')


class QuickCueMap(Base):
    __tablename__ = 'quick_cue_map'
    qc_uuid = Column(String(36), ForeignKey('quick_cue.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), nullable=False, primary_key=True)
    device_uuid = Column(String(36), ForeignKey('device.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), nullable=True, primary_key=True)
    automation_uuid = Column(String(36), nullable=False)


class AutomationConfiguration(Base):
    __tablename__ = 'automation_configuration'
    automation_name = Column(String(50), nullable=False, primary_key=True)
    automation_group = Column(String(50), nullable=True)
    _flags = relationship('AutomationFlag', secondary='automation_flag_map', collection_class=set, cascade='all')
    flags = association_proxy('_flags', 'name', creator=lambda name: AutomationFlag(name=name))

    def has_flag(self, flag):
        return flag in self.flags

    def to_dict(self):
        return {'automation_name': self.automation_name,
         'flags': self.flags}


class AutomationFlagMap(Base):
    __tablename__ = 'automation_flag_map'
    automation = Column(String(36), ForeignKey('automation_configuration.automation_name', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), primary_key=True, index=True, nullable=False)
    flag = Column(String(50), ForeignKey('automation_flag.name', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), primary_key=True, index=True, nullable=False)


class AutomationFlag(Base):
    __tablename__ = 'automation_flag'
    name = Column(String(50), nullable=False, primary_key=True)

    def __init__(self, name):
        self.name = name


class PackAttributeMap(Base):
    """
    Maps a pack to show attributes
        - packs can be associated with 0+ show attributes
    """
    __tablename__ = 'pack_attribute_map'
    pack_uuid = Column(String(36), ForeignKey('pack.uuid', ondelete='CASCADE', onupdate='CASCADE', deferrable=True), nullable=False, primary_key=True)
    external_show_attribute_map_uuid = Column(String(36), ForeignKey('external_show_attribute_map.uuid', ondelete='CASCADE', onupdate='CASCADE', deferrable=True), nullable=False, primary_key=True)
    pack = relationship('Pack')
    external_show_attribute_maps = relationship('ExternalShowAttributeMap')

    def to_dict(self):
        d = {}
        for column in self.__table__.columns:
            d[column.name] = getattr(self, column.name)

        return d

    def from_dict(self, data):
        for column in self.__table__.columns:
            if column.name in data:
                setattr(self, column.name, data[column.name])


class ShowAttribute(UuidMixin, Base):
    """
    #todo:
    """
    __tablename__ = 'show_attribute'
    name = Column(String(255), nullable=False, unique=True)
    screen_attribute = Column(Boolean, default=False)
    cpl_attribute = Column(Boolean, default=False)
    custom = Column(Boolean, default=True)
    external_show_attribute_maps = relationship('ExternalShowAttributeMap')

    def to_dict(self):
        d = {}
        for column in self.__table__.columns:
            d[column.name] = getattr(self, column.name)

        return d

    def from_dict(self, some_dict):
        for column in self.__table__.columns:
            if column.name in some_dict:
                setattr(self, column.name, some_dict[column.name])


class ExternalShowAttributeMap(UuidMixin, Base):
    """Maps an identifier used by a third party vendor to a Show attribute.
      so you are either putting stuff in here from POS, or from
       a pack. Then it needs to be mapped to an actual show attribute
    """
    __tablename__ = 'external_show_attribute_map'
    __table_args__ = (UniqueConstraint('source', 'external_id'),)
    source = Column(String(100), nullable=False)
    external_id = Column(String(200), nullable=False)
    show_attribute_uuid = Column(String(255), ForeignKey('show_attribute.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), nullable=True)
    show_attribute = relationship('ShowAttribute', lazy='joined')
    pack_attribute_maps = relationship('PackAttributeMap', backref=backref('external_show_attribute_map', lazy='noload'))

    def to_dict(self):
        d = {}
        for column in self.__table__.columns:
            d[column.name] = getattr(self, column.name)

        return d

    def from_dict(self, d):
        for column in self.__table__.columns:
            if column.name in d:
                setattr(self, column.name, d[column.name])


class Screen(UuidMixin, ModMixin, Base):
    __tablename__ = 'screen'
    identifier = Column(String(3))
    title = Column(String(255))
    hi = Column(Integer, nullable=True)
    vi = Column(Integer, nullable=True)
    cc = Column(Integer, nullable=True)
    audio = Column(Integer, nullable=True)
    audio_level = Column(String(25), nullable=True)
    capacity = Column(Integer, nullable=True)
    devices = relationship('Device')
    screen_show_attribute_maps = relationship('ScreenShowAttributeMap', passive_deletes=False, cascade='all, delete, delete-orphan', collection_class=set)
    show_attributes = association_proxy('screen_show_attribute_maps', 'show_attribute')


class ScreenShowAttributeMap(UuidMixin, Base):
    """
    Maps a screen to show attributes
    """
    __tablename__ = 'screen_show_attribute_map'
    screen_uuid = Column(String(36), ForeignKey('screen.uuid', ondelete='CASCADE', onupdate='CASCADE', deferrable=True), nullable=False, primary_key=True)
    show_attribute_uuid = Column(String(36), ForeignKey('show_attribute.uuid', ondelete='CASCADE', onupdate='CASCADE', deferrable=True), nullable=False, primary_key=True)
    show_attribute = relationship('ShowAttribute', cascade='all')
    screen = relationship('Screen')


class Device(UuidMixin, ModMixin, Base):
    __tablename__ = 'device'
    category = Column(String(25))
    type = Column(String(25))
    model = Column(String(25), default='default')
    name = Column(String(200))
    path = Column(Unicode(200))
    ip_address = Column(String(200))
    port = Column(Integer)
    api_username = Column(String(200))
    api_password = Column(String(200))
    ftp_ip_address = Column(String(200))
    ftp_port = Column(Integer)
    ftp_username = Column(String(200))
    ftp_password = Column(String(200))
    cert_path = Column(String(500))
    auto_sync = Column(Boolean)
    auto_ingest = Column(Boolean)
    enabled = Column(Boolean, default=True, nullable=False)
    screen_uuid = Column(String(36), ForeignKey('screen.uuid', onupdate='CASCADE', ondelete='RESTRICT', deferrable=True), nullable=True)
    screen = relationship('Screen')


class MonitoringType(UuidMixin, ModMixin, Base):
    __tablename__ = 'monitoring_type'
    name = Column('name', String(100), nullable=False, index=True)
    type = Column(String, nullable=False)
    parent_uuid = Column(String, ForeignKey('monitoring_type.uuid', ondelete='CASCADE'), nullable=True)
    critical = Column('critical', Boolean, default=False, nullable=False)
    default = Column('default', Boolean, default=False, nullable=False)
    oids = relationship('MonitoringOid')

    def from_dict(self, d):
        for column in self.__table__.columns:
            if column.name in d:
                setattr(self, column.name, d[column.name])


class MonitoringOid(UuidMixin, ModMixin, Base):
    __tablename__ = 'monitoring_oid'
    monitoring_type_uuid = Column(String(36), ForeignKey('monitoring_type.uuid', ondelete='CASCADE'), nullable=False)
    category = Column(String(25), nullable=False)
    type = Column(String(25), nullable=False)
    model = Column(String(25), default='default', nullable=False)
    oid = Column(String(100), nullable=False)
    frequency = Column(Integer, nullable=True)
    version = Column(Integer, nullable=False)
    transform = Column(Text, nullable=True)

    def from_dict(self, d):
        for column in self.__table__.columns:
            if column.name in d:
                setattr(self, column.name, d[column.name])
            elif column.name == 'category':
                self.category = d['device_category']
            elif column.name == 'type':
                self.type = d['device_make']
            elif column.name == 'model':
                self.model = d['device_model']


class User(IdMixin, Base):
    __tablename__ = 'user'
    username = Column(String(32), nullable=False, unique=True)
    password = Column(String(128), nullable=False)
    display_name = Column(String(32), nullable=False)
    group = Column(String(32), nullable=False)


class ExternalDeviceMap(Base):
    """Maps an external Device identifier to a Device in the complex
    """
    __tablename__ = 'external_device_map'
    external_id = Column(String(200), primary_key=True, nullable=False)
    source = Column(String(50), primary_key=True, nullable=True)
    source_type = Column(String(50), nullable=False)
    device_uuid = Column(String(36), ForeignKey('device.uuid', onupdate='CASCADE', ondelete='RESTRICT', deferrable=True), nullable=True)
    device = relationship('Device', lazy='joined')

    def update_device_mapping(self, device_uuid):
        setattr(self, 'device_uuid', device_uuid)


class POSItem(UuidMixin, ModMixin, Base):
    __tablename__ = 'pos'
    external_id = Column(String(36), nullable=False)
    screen_identifier = Column(String(36), nullable=False)
    complex_identifier = Column(String(32), nullable=True)
    start = Column(DateTime, nullable=False)
    end = Column(DateTime, nullable=False)
    source_start = Column(DateTime, nullable=False)
    week_number = Column(Integer, nullable=False)
    overall_duration = Column(Integer, nullable=True)
    feature_title = Column(String(200), nullable=False)
    feature_id = Column(String(100), nullable=True)
    feature_duration = Column(Integer, nullable=True)
    state = Column(String(16), nullable=False)
    message = Column(String(250), nullable=True)
    schedule = relationship('Schedule')
    seats_available = Column(Integer, nullable=True)
    seats_sold = Column(Integer, nullable=True)
    print_number = Column(String(36), nullable=True)
    rating = Column(String(36), nullable=True)
    modified = Column(Boolean, default=False, nullable=False)
    moved = Column(Boolean, default=False, nullable=False)
    playlist_uuid = Column(String(36), nullable=True)
    description = Column(String(100), nullable=True)
    placeholder_type = Column(String(50), nullable=True)
    device_uuid = Column(String(36), ForeignKey('device.uuid', onupdate='CASCADE', ondelete='SET NULL', deferrable=True), nullable=True)
    external_title_map_uuid = Column(String(36), ForeignKey('external_title_map.uuid', onupdate='CASCADE', ondelete='CASCADE'), nullable=True)
    device = relationship('Device')
    pos_attribute_maps = relationship('PosShowAttributeMap')
    ex_show_attributes = relationship('ExternalShowAttributeMap', secondary='pos_show_attribute_map')
    show_attributes = association_proxy('ex_show_attributes', 'show_attribute')
    transfer_not_before = Column(String(32), nullable=True)
    external_device_map = relationship('ExternalDeviceMap')
    external_title_map = relationship('ExternalTitleMap')
    __table_args__ = (ForeignKeyConstraint([screen_identifier, device_uuid], ['external_device_map.external_id', 'external_device_map.source']), {})

    def to_dict(self, source = None):
        d = {}
        for column in self.__table__.columns:
            if column.name in ('start', 'end', 'source_start'):
                d[column.name] = time.mktime(getattr(self, column.name).timetuple())
                if column.name == 'start':
                    d['short_start_time'] = str(self.start.hour) + ':' + str(self.start.minute) if len(str(self.start.minute)) == 2 else str(self.start.hour) + ':' + '0' + str(self.start.minute)
            elif column.name in ('show_attributes',):
                d[column.name] = json.loads(getattr(self, column.name))
            else:
                d[column.name] = getattr(self, column.name)

        if source:
            d['source'] = source
        else:
            d['source'] = self.device.type
        return d

    def add_error(self, message):
        if self.state == 'error' and self.message and len(self.message) > 0:
            if self.message.find(message) != -1:
                self.message = self.message + ' | ' + message
        else:
            self.message = 'ERRORS: ' + str(message)

    def is_target_configured(self):
        try:
            return self.external_device_map.source == None or self.external_device_map.device.enabled
        except Exception:
            return False

        return None

    def feature_start(self):
        if self.feature_duration:
            return self.end - datetime.timedelta(seconds=self.feature_duration)
        return self.start + datetime.timedelta(minutes=20)

    def tms_screen_id(self):
        try:
            return self.external_device_map.device.screen.identifier
        except:
            return None

        return None

    def device_type(self):
        try:
            return self.device.type
        except AttributeError:
            return None

        return None

    def valid_show_attribute_uuids(self):
        uuids = []
        for map in self.pos_attribute_maps:
            if map.show_attribute and not map.deleted:
                uuids.append(map.show_attribute.uuid)

        return uuids


class PosShowAttributeMap(Base):
    __tablename__ = 'pos_show_attribute_map'
    pos_item_uuid = Column(String(36), ForeignKey('pos.uuid', onupdate='CASCADE', ondelete='CASCADE'), nullable=False, primary_key=True)
    external_show_attribute_uuid = Column(String(36), ForeignKey('external_show_attribute_map.uuid', onupdate='CASCADE', ondelete='CASCADE'), nullable=False, primary_key=True)
    external_show_attribute = relationship('ExternalShowAttributeMap', lazy='joined')
    show_attribute = association_proxy('external_show_attribute', 'show_attribute')
    manual = Column(Boolean, nullable=False, default=False)
    deleted = Column(Boolean, nullable=False, default=False)


class ScheduleShowAttributeMap(Base):
    __tablename__ = 'schedule_show_attribute_map'
    schedule_uuid = Column(String(36), ForeignKey('schedule.uuid', onupdate='CASCADE', ondelete='CASCADE'), nullable=False, primary_key=True)
    show_attribute_uuid = Column(String(36), ForeignKey('show_attribute.uuid', onupdate='CASCADE', ondelete='CASCADE'), nullable=False, primary_key=True)
    show_attribute = relationship('ShowAttribute')
    schedule = relationship('Schedule')


class Message(UuidMixin, Base):
    __tablename__ = 'message'
    recieved_time = Column(Integer, nullable=False, default=time.time)
    jid = Column(String(100), nullable=False)
    body = Column(String(1000), nullable=False)
    unread = Column(Boolean, nullable=False, default=False)
    sent = Column(Boolean, nullable=False, default=False)
    success = Column(Boolean, nullable=False, default=True)


class ProducerComplex(Base):
    __tablename__ = 'producer_complex'
    name = Column(String(50), nullable=False)
    external_id = Column(Integer, nullable=False, primary_key=True)
    current = Column(Boolean, nullable=False, default=False)


class Transfer(UuidMixin, ModMixin, Base):
    __tablename__ = 'transfer'
    device_transfer_uuid = Column(String(50), nullable=True)
    content_uuid = Column(String(200), nullable=True)
    source = Column(String(200), nullable=True)
    not_before = Column(Float, nullable=True)
    destination_device_uuid = Column(String(50), nullable=False)
    description = Column(String(200), nullable=True)
    state = Column(String(20), nullable=False)
    start = Column(Float, nullable=True)
    end = Column(Float, nullable=True)
    type = Column(String(5), nullable=False)
    message = Column(Text, nullable=True)
    core = Column(Boolean, nullable=False, default=False)
    playlist_uuid = Column(String(50), nullable=True)
    playlist_json = Column(Text, nullable=True)
    kdm_xml = Column(String(65000), nullable=True)
    message_code = Column(Integer, nullable=True)
    kdm_uuid = Column(String(200), nullable=True)

    def to_dict(self):
        """Returns a dictionary representing the Transfer
        """
        transfer_dict = {'state': self.state,
         'description': self.description,
         'source': self.source,
         'content_id': self.content_uuid,
         'not_before': self.not_before,
         'not_before_string': helper_methods.format_timestamp(self.not_before),
         'id': self.uuid,
         'message': self.message,
         'message_code': self.message_code,
         'type': self.type,
         'playlist_uuid': self.playlist_uuid,
         'playlist_json': self.playlist_json,
         'server_transfer_id': self.device_transfer_uuid,
         'kdm_uuid': self.kdm_uuid}
        if self.state in ('success', 'cancelled', 'failed'):
            if self.start:
                transfer_dict['start_time'] = self.start
                transfer_dict['start_time_string'] = helper_methods.format_timestamp(self.start)
            if self.end:
                transfer_dict['end_time'] = self.end
                transfer_dict['end_time_string'] = helper_methods.format_timestamp(self.end)
            if self.start and self.end:
                transfer_dict['total_time'] = helper_methods.format_time(int(transfer_dict['end_time'] - transfer_dict['start_time']))
        return transfer_dict


class GeneratedPlaylist(UuidMixin, ModMixin, Base):
    __tablename__ = 'generated_playlist'
    start_timestamp = Column(Float, nullable=False)


class Note(IdMixin, Base):
    __tablename__ = 'note'
    created = Column(DateTime, nullable=False, default=datetime_default)
    subject = Column(String(80), nullable=False, default='')
    detail = Column(String(500), nullable=True)
    icon = Column(String(32), nullable=True)
    group = Column(String(32), nullable=True)
    confirm = Column(Boolean, nullable=True)
    complete = Column(Boolean, nullable=True)
    raised_at = Column(DateTime, nullable=True)
    repeat_type = Column(String(8), nullable=True)
    repeat_at = Column(String(8), nullable=True)
    repeat_from = Column(Date, nullable=True)
    repeat_frequency = Column(Integer, nullable=True)
    repeat_days = relationship('RepeatReminderDay', backref=backref('note'), passive_deletes=True)

    def is_reminder(self):
        return bool(self.raised_at or self.repeat_type)

    def is_repeat(self):
        return self.repeat_type is not None

    def is_variable_repeat(self):
        return self.repeat_type == 'week'


class RepeatReminderDay(Base):
    __tablename__ = 'repeat_reminder_day'
    day = Column(Integer, primary_key=True)
    note_id = Column(Integer, ForeignKey('note.id', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), primary_key=True)


class Contact(DictMixin, Base):
    __tablename__ = 'contact'
    id = Column(Integer, primary_key=True)
    name = Column(String(80), nullable=True)
    phone1 = Column(String(20), nullable=True)
    type = Column(String(30), nullable=True)
    email = Column(String(30), nullable=True)


class Address(DictMixin, Base):
    __tablename__ = 'address'
    id = Column(Integer, nullable=False, primary_key=True)
    type = Column(String(15), nullable=False)
    addressee = Column(String(80), nullable=True)
    streetaddress = Column(String(80), nullable=False)
    streetaddress2 = Column(String(80), nullable=True)
    city = Column(String(40), nullable=False)
    province = Column(String(30), nullable=False)
    postcode = Column(String(20), nullable=True)
    country = Column(String(30), nullable=False)


class TimeframeMap(UuidMixin, Base):
    __tablename__ = 'timeframe_map'
    screen_uuid = Column(String(32), ForeignKey('screen.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), nullable=False)
    screen = relationship(Screen)
    timeframe_uuid = Column(String(32), ForeignKey('timeframe.uuid', onupdate='CASCADE', ondelete='CASCADE', deferrable=True), nullable=False)
    timeframe = relationship('Timeframe')


class Timeframe(UuidMixin, DictMixin, Base):
    __tablename__ = 'timeframe'
    start_time = Column(Integer, nullable=False)
    end_time = Column(Integer, nullable=False)
    screens = relationship(Screen, uselist=True, backref='log_timeframe', secondary='timeframe_map')
# okay decompyling ./storage/database/primary/database.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.08.13 21:52:43 CST
